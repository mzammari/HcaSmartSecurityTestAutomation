﻿using AventStack.ExtentReports;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.DevTools;
using System.Reflection;
using System.Diagnostics;
using ISAS_Regression_Automation.Utilities;
using OpenQA.Selenium.Remote;
using NUnit.Framework;
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using AutomationCoreLite.Reporting;
using Microsoft.Extensions.Configuration;
using Autofac;
using System.Threading.Tasks;
using Evinced.SDK;
using System.Net.Http;
using Microsoft.Extensions.Options;


namespace ISAS_Regression_Automation
{
    public class Driver
    {
        protected static string userRole;
        // public static IWebDriver Instance;
        public static IEvincedDriver EvDriver;
        public static IWebDriver Instance;
        // protected  IWebDriver Instance;
        ExtentReports extent = new ExtentReports();
        public static ExtentTest Test;
        public static string dir = AppDomain.CurrentDomain.BaseDirectory;
        public static string testResultPath = dir.Replace("bin\\Debug\\net8.0", "TestResults");
        //public static string Url = SettingData.Url ;
        //public static string Username = "hcaqa\\opt6590"; //QA
        // public static string Username = SettingData.Username;
        // public static string Pwd = SettingData.Pwd;
        public static string Domain = SettingData.Domain;
        //public static string Username;
        // public static string Pwd;

        private const string AdoBaseUrl = "https://dev.azure.com/PWSCollection/";
        private const string AdoProject = "ISAS_Git";
        private const string AdoTestPlan = "WFT Journeys";
        //private static string PAT = SettingData.PAT;

        public static double navigatonTimeSpanFromSeconds { get; set; }
        public static double waitTime { get; set; }

        public static void Wait(TimeSpan timeSpan)
        {
            Thread.Sleep((int)(timeSpan.TotalSeconds * 6000));
        }
        static Driver()
        {
            navigatonTimeSpanFromSeconds = Convert.ToDouble(0.5);
            waitTime = Convert.ToDouble(30);
        }


        [SetUp]
        public static async Task Method()
        {
            RunData.Domain = Get<string>("DOMAIN");
            RunData.UserName = Get<string>("USERNAME");
            RunData.Password = Get<string>("PWD");
            RunData.PAT = Get<string>("PAT");
            RunData.Url = Get<string>("URL");
            RunData.DatabaseName = Get<string>("DatabaseName");
            RunData.ServerName = Get<string>("SERVERNAME");
            RunData.SecurityDB = Get<string>("SECURITYDB");

            RunData.EvincedAccountID = Get<string>("SECURITYDB");
            RunData.EvincedOfflineKey = Get<string>("SECURITYDB");

            string fpcServerName = Get<string>("FPCSERVERNAME");
            string fpcDatabaseName = Get<string>("FPCDATABASENAME");
            string fpcPassword = Get<string>("FPCPWD");

            // In CI, FPC-specific secrets may be omitted. Fall back to the primary DB settings.
            RunData.FpcServerName = string.IsNullOrWhiteSpace(fpcServerName) ? RunData.ServerName : fpcServerName;
            RunData.FpcDatabaseName = string.IsNullOrWhiteSpace(fpcDatabaseName) ? RunData.DatabaseName : fpcDatabaseName;
            RunData.FpcPassword = string.IsNullOrWhiteSpace(fpcPassword) ? RunData.Password : fpcPassword;

            if (string.IsNullOrWhiteSpace(fpcServerName) || string.IsNullOrWhiteSpace(fpcDatabaseName) || string.IsNullOrWhiteSpace(fpcPassword))
            {
                Console.WriteLine("Warning: FPCSERVERNAME/FPCDATABASENAME/FPCPWD missing; using fallback DB credentials.");
            }
            bool useRemoteWebDriver = Get<bool>("USEREMOTEWEBDRIVER");
            bool runHeadless = Get<bool>("RUNHEADLESS");
            string gridHubUrl = Get<string>("GRIDHUBURL");
            string EvincedAccountID = RunData.EvincedAccountID;
            string EvincedToken = RunData.EvincedOfflineKey;

            if (File.Exists(SettingData.OutputFile))
            {
                File.Delete(SettingData.OutputFile);
            }

            ExtentReporting.CreateTest(TestContext.CurrentContext.Test.MethodName);
            //Begin test steps
            Steps.BeginTestSteps(RunData.AdoTestCaseName);
            Steps.AddTestStep($"Start Date and Time: {CommonFunctions.getTestcaseTimeStamp()} - {Environment.MachineName} \n" +
                $"{RunData.AdoTestCaseName}", $"{RunData.AdoTestCaseName}");
            //Selenium Grid
            Console.WriteLine(useRemoteWebDriver.ToString());
            if (useRemoteWebDriver)
            {
                if (!string.IsNullOrEmpty(gridHubUrl))
                {

                    //Install chromedriver that matches current borwser                    
                    // new DriverManager().SetUpDriver(new ChromeConfig(), VersionResolveStrategy.MatchingBrowser);
                    var parent = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;

                    ChromeOptions option = new ChromeOptions();
                    option.AcceptInsecureCertificates = true;
                    Instance = new RemoteWebDriver(new Uri(gridHubUrl), option.ToCapabilities(), TimeSpan.FromSeconds(180));

                    //if(Instance is RemoteWebDriver remoteDriver)
                    //{
                    //    try
                    //    {

                    //        string sessionId = remoteDriver.SessionId.ToString();
                    //        string nodeUrl = await GetNodeUrl(gridHubUrl, sessionId);
                    //        Console.WriteLine($"Session Id: {sessionId}");
                    //        Console.WriteLine($"Hub Url: {gridHubUrl}");
                    //        Console.WriteLine($"Node Url: {nodeUrl}");
                    //        Console.WriteLine($"Browser: {remoteDriver.Capabilities.GetCapability("browserName")}");

                    //    }
                    //    catch(Exception ex ) 
                    //    {
                    //        Console.WriteLine($"couldn't get session info\n {ex.Message}");
                    //    }
                    //}

                    // Pinned-CDP auth (replaces the old Manage().Network + NetworkAuthenticationHandler block).
                    // Must run after Instance is created and BEFORE NavigateToIsas() so the handler is
                    // listening when the 401 fires.
                    await SetupPinnedAuth();
                    string loginCred = $"{RunData.Domain}\\{RunData.UserName}";
                    var handler = new NetworkAuthenticationHandler()
                    {
                        UriMatcher = uri => uri.AbsoluteUri.Contains(SettingData.SiteDomain),
                        Credentials = new PasswordCredentials(loginCred, RunData.Password)
                    };
                    var networkInterceptor = Instance.Manage().Network;
                    networkInterceptor.AddAuthenticationHandler(handler);
                    Thread.Sleep(10000);
                    bool isNetworkMonitoringStarted = await TryStartNetworkMonitoring(networkInterceptor);
                    Thread.Sleep(10000);
                    NavigateToIsas();
                    await StopNetworkMonitoring(networkInterceptor, isNetworkMonitoringStarted);
                    //Insert WFT Freeze Administrator role
                    CommonFunctions.InsertWftFreezeAdministrator();

                }
                else
                {
                    throw new ArgumentException("gridHubUrl must be provided when using Remote WebDriver.");
                }
            }
            else //Local
            {
                var parent = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;

                ChromeOptions option = new ChromeOptions();
                option.AddArgument("--no-sandbox");
                option.AddExcludedArgument("enable-automation");
                option.AcceptInsecureCertificates = true;
                if (runHeadless)
                {
                    option.AddArguments("--headless=new");
                }
                string driverPath = new WebDriverManager.DriverManager().SetUpDriver(
                    new WebDriverManager.DriverConfigs.Impl.ChromeConfig(),
                    WebDriverManager.Helpers.VersionResolveStrategy.MatchingBrowser);
                var service = ChromeDriverService.CreateDefaultService(Path.GetDirectoryName(driverPath));
                string logDirectory = Path.Combine(TestContext.CurrentContext.WorkDirectory, "ChromeDriverLogs");
                Directory.CreateDirectory(logDirectory);
                service.EnableVerboseLogging = true;
                service.LogPath = Path.Combine(logDirectory, $"chromedriver-{Guid.NewGuid():N}.log");
                Console.WriteLine($"ChromeDriver startup log: {service.LogPath}");
                try
                {
                    Instance = new ChromeDriver(service, option, TimeSpan.FromSeconds(180));
                }
                catch
                {
                    service.Dispose();
                    throw;
                }

                // Pinned-CDP auth (replaces the old Manage().Network + NetworkAuthenticationHandler block).
                await SetupPinnedAuth();
                NavigateToIsas();
                //Insert WFT Freeze Administrator role
                //add an If statement for the env (prod, uat)
                //CommonFunctions.InsertWftFreezeAdministrator();
            }
        }

        /// <summary>
        /// Answers the ISAS NTLM/Basic auth challenge via a CDP Fetch session pinned to
        /// protocol version 144, so Selenium's DevTools auto-detect never negotiates the
        /// installed Chrome version and throws "DevTools version is not in the supported range".
        /// Direct replacement for the old Manage().Network + NetworkAuthenticationHandler block.
        /// Unlike the old block there is no Start/StopMonitoring lifecycle: the handlers stay
        /// registered for the whole session, which also prevents the credential dialog from
        /// reappearing on later navigations.
        /// </summary>
        private static async Task SetupPinnedAuth()
        {
            string loginCred = $"{RunData.Domain}\\{RunData.UserName}";

            var session = ((IDevTools)Instance)
                .GetDevToolsSession(new DevToolsOptions { ProtocolVersion = 144 });
            var domains = session.GetVersionSpecificDomains<OpenQA.Selenium.DevTools.V144.DevToolsSessionDomains>();

            // Enable Fetch and opt in to handling auth challenges.
            await domains.Fetch.Enable(new OpenQA.Selenium.DevTools.V144.Fetch.EnableCommandSettings
            {
                HandleAuthRequests = true,
                Patterns = new[]
                {
                    new OpenQA.Selenium.DevTools.V144.Fetch.RequestPattern { UrlPattern = "*" }
                }
            });

            // With Fetch enabled, EVERY request pauses waiting for an instruction.
            // Non-auth requests must be continued or the page will hang.
            domains.Fetch.RequestPaused += async (s, e) =>
            {
                try
                {
                    await domains.Fetch.ContinueRequest(
                        new OpenQA.Selenium.DevTools.V144.Fetch.ContinueRequestCommandSettings
                        {
                            RequestId = e.RequestId
                        });
                }
                catch
                {
                    // Request may already be resolved/gone by the time we continue it; safe to ignore.
                }
            };

            // Answer the 401 challenge with the domain credentials.
            domains.Fetch.AuthRequired += async (s, e) =>
            {
                await domains.Fetch.ContinueWithAuth(
                    new OpenQA.Selenium.DevTools.V144.Fetch.ContinueWithAuthCommandSettings
                    {
                        RequestId = e.RequestId,
                        AuthChallengeResponse = new OpenQA.Selenium.DevTools.V144.Fetch.AuthChallengeResponse
                        {
                            Response = OpenQA.Selenium.DevTools.V144.Fetch.AuthChallengeResponseResponseValues.ProvideCredentials,
                            Username = loginCred,
                            Password = RunData.Password
                        }
                    });
            };
        }

        private static async Task<bool> TryStartNetworkMonitoring(INetwork networkInterceptor)
        {
            try
            {
                await networkInterceptor.StartMonitoring();
                return true;
            }
            catch (WebDriverException ex) when (IsUnsupportedDevToolsVersion(ex))
            {
                Console.WriteLine($"Warning: Selenium network authentication was skipped because the installed Selenium DevTools support does not match the browser version. {ex.Message}");
                return false;
            }
        }

        private static bool IsUnsupportedDevToolsVersion(WebDriverException ex)
        {
            return ex.ToString().Contains("DevTools version is not in the supported range", StringComparison.OrdinalIgnoreCase);
        }

        private static async Task StopNetworkMonitoring(INetwork networkInterceptor, bool isNetworkMonitoringStarted)
        {
            if (!isNetworkMonitoringStarted)
            {
                return;
            }

            await networkInterceptor.StopMonitoring();
        }
        
        private static void NavigateToIsas()
        {
            Instance.Navigate().GoToUrl(RunData.Url);
            Instance.Manage().Window.Maximize();
            CommonFunctions.IsElementDisplayed("//span[@class='page-title']", 180);
            CommonFunctions.WaitUntilPageIsAcive();
            //Ensure the WFT freeze admin is added
            CommonFunctions.InsertWftFreezeAdministrator();
        }

        private static async Task<string> GetNodeUrl(string hubUrl, string sessionId)
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // For Selenium Grid 3
                    string apiUrl = $"{hubUrl}/grid/api/testsession?session={sessionId}";
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string content = await response.Content.ReadAsStringAsync();

                        // Parse JSON response
                        var json = Newtonsoft.Json.Linq.JObject.Parse(content);
                        string proxyId = json["proxyId"]?.ToString();

                        if (!string.IsNullOrEmpty(proxyId))
                        {
                            return proxyId;
                        }
                    }

                    // If Grid 3 API fails, try Grid 4 GraphQL
                    return await GetNodeUrlGrid4(hubUrl, sessionId);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error getting node URL: {ex.Message}");
                    return "Unknown Node";
                }
            }
        }

        private static async Task<string> GetNodeUrlGrid4(string hubUrl, string sessionId)
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // Remove /wd/hub if present
                    string baseHubUrl = hubUrl.Replace("/wd/hub", "").TrimEnd('/');

                    // Grid 4 GraphQL endpoint
                    string graphqlUrl = $"{baseHubUrl}/graphql";

                    Console.WriteLine($"Querying Grid 4 at: {graphqlUrl}");
                    Console.WriteLine($"For Session ID: {sessionId}");

                    // GraphQL query for Grid 4
                    var requestBody = new
                    {
                        query = @"
                    query($sessionId: ID!) {
                        session(id: $sessionId) {
                            id
                            nodeId
                            nodeUri
                            sessionDurationMillis
                            slot {
                                id
                                stereotype
                            }
                        }
                    }",
                        variables = new
                        {
                            sessionId = sessionId
                        }
                    };

                    string jsonRequest = Newtonsoft.Json.JsonConvert.SerializeObject(requestBody);
                    Console.WriteLine($"Request: {jsonRequest}");

                    var content = new StringContent(jsonRequest, System.Text.Encoding.UTF8, "application/json");

                    HttpResponseMessage response = await client.PostAsync(graphqlUrl, content);
                    string result = await response.Content.ReadAsStringAsync();

                    Console.WriteLine($"Response Status: {response.StatusCode}");
                    Console.WriteLine($"Response: {result}");

                    if (response.IsSuccessStatusCode)
                    {
                        var jsonResponse = Newtonsoft.Json.Linq.JObject.Parse(result);

                        // Check for errors
                        var errors = jsonResponse["errors"];
                        if (errors != null)
                        {
                            Console.WriteLine($"GraphQL Errors: {errors}");
                            return "GraphQL Query Error";
                        }

                        // Extract node information
                        var sessionData = jsonResponse["data"]?["session"];
                        if (sessionData != null)
                        {
                            string nodeUri = sessionData["nodeUri"]?.ToString();
                            string nodeId = sessionData["nodeId"]?.ToString();

                            Console.WriteLine($"Node URI: {nodeUri}");
                            Console.WriteLine($"Node ID: {nodeId}");

                            if (!string.IsNullOrEmpty(nodeUri))
                            {
                                return nodeUri;
                            }
                            else if (!string.IsNullOrEmpty(nodeId))
                            {
                                return $"Node ID: {nodeId}";
                            }
                        }
                        else
                        {
                            Console.WriteLine("Session data is null - session might not be registered yet");
                        }
                    }

                    return "Could not retrieve node information";
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                    Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                    return $"Error: {ex.Message}";
                }
            }
        }


        /// <summary>
        /// Get secrets values (username, pwd, PAT...etc) from either the 
        /// environment variable or secrets file
        /// </summary>
        /// <param name="key"></param>
        /// <returns>value</returns>
        public static string Get(string key)
        {
            //Access the secrets file locally
            var config = new ConfigurationBuilder()
              .AddUserSecrets(Assembly.GetExecutingAssembly(), true).Build();

            var value = Environment.GetEnvironmentVariable(key);
            if (!string.IsNullOrEmpty(value))
            {
                return value;
            }
            else
            {
                return config[key];
            }
        }

        public static T Get<T>(string key) where T : IConvertible
        {
            // First try environment variables (GitHub Actions, Docker, etc.)
            string envValue = Environment.GetEnvironmentVariable(key);

            if (!string.IsNullOrEmpty(envValue))
            {
                Console.WriteLine($"Found {key} in environment variables");
                return ConvertValue<T>(envValue, key, "environment variable");
            }

            // Fall back to user secrets (local development)
            var config = new ConfigurationBuilder()
                .AddUserSecrets(Assembly.GetExecutingAssembly(), true)
                .Build();

            string configValue = config[key];

            if (!string.IsNullOrEmpty(configValue))
            {
                Console.WriteLine($"Found {key} in user secrets");
                return ConvertValue<T>(configValue, key, "user secrets");
            }

            // Final fallback - could also check appsettings.json
            Console.WriteLine($"Warning: {key} not found in environment variables or user secrets, returning default");
            return default(T);
        }

        private static T ConvertValue<T>(string value, string key, string source) where T : IConvertible
        {
            // For boolean values with flexible parsing
            if (typeof(T) == typeof(bool))
            {
                if (bool.TryParse(value, out bool result))
                    return (T)(object)result;

                string lower = value.ToLowerInvariant();
                bool boolValue = lower == "true" || lower == "1" || lower == "yes" || lower == "on";
                return (T)(object)boolValue;
            }

            // For other types
            try
            {
                return (T)Convert.ChangeType(value, typeof(T));
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    $"Cannot convert {source} '{key}' value '{value}' to type {typeof(T).Name}", ex);
            }
        }

        private static ChromeOptions CreateChromeOptionsCLI() //headlessChrome Driver
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArguments("start-maximized");
            //options.AddArguments("chrome.switches", "--headless --disable-gpu --window-size=1920,1080 --no-sandbox --timeout 15000 --disable-translate --disable-extensions --remote-debugging-port=9222 --disable-notifications");
            options.AddArguments("chrome.switches",
                "--headless " +
                "--disable - software - rasterizer" +
                "--no-gpu " +
                "--window-size=1920,1080 " +
                "--no-sandbox " +
                "--timeout 15000 " +
                "--disable-translate " +
                "--disable-extensions " +
                "--remote-debugging-port=9222 " +
                "--disable-notifications");
            //--no - gpu --disable - software - rasterizer--headless--mute - audio--hide - scrollbars--remote - debugging - port = 9222
            options.AddUserProfilePreference("credentials_enable_service", false);
            return options;
        }

        public static JsonReader getDataParser()
        {
            return new JsonReader();
        }

        private static void UpdateTascMetrics()
        {
            var _tascBaseUrl = SettingData.TascUrl;
            var _applicationId = int.Parse(SettingData.ApplicationId);
            var TestName = RunData.AdoTestCaseName ?? TestContext.CurrentContext.Test.MethodName;
            var TimeSaved = RunData.TimeSaved;

            if (string.IsNullOrEmpty(_tascBaseUrl) || string.IsNullOrWhiteSpace(TestName)) return;

            var tm = new TascUpdater(_tascBaseUrl);
            var result = tm.SendTestMetricsResult(_applicationId, TestName, "Local Machine", TimeSaved);
            Console.WriteLine($"TASC Updater Result: {result}");
        }


        [TearDown]
        public static async Task AfterTest()
        {
            try
            {
                //DeleteWftPlan();
                EndTest();
                ExtentReporting.EndReporting();
                if (Instance != null)
                {
                    CloseAllTab();
                }
                Thread.Sleep(5000);
                Instance?.Quit();
                CloseProcess();
                Steps.EndTestSteps();
                Steps.TestSteps.Clear();
                RunData.RallyScreenShots?.Clear();
                UpdateTascMetrics();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"The catch block \n {ex.Message}");
                Instance?.Quit();
                CloseProcess();
                Steps.EndTestSteps();
                Steps.TestSteps.Clear();
                RunData.RallyScreenShots?.Clear();
            }
        }

        private static void DeleteWftPlan()
        {
            var homePage = new HomePage(Driver.Instance);
            var categories = TestContext.CurrentContext.Test.Properties["Category"];
            if (categories.Contains("Wft") ||
                categories.Contains("WFT"))
            {
                homePage.SwitchToWindow("Workload Forecast");
                DeptForecastButtonPanel.GoToAdmin();
                AdminMenu.DeleteDefaultPlan();
            }
        }

        private static void CloseProcess()
        {
            foreach (var process in Process.GetProcessesByName("chromedriver"))
            {
                process.Kill();
            }
            //foreach (var process in Process.GetProcessesByName("chrome"))
            //{
            //    process.Kill();
            //}
            //Delete all pdf and excel files from the download folder.
            string filePath = @"C:\Users\opt6590\Downloads";
            GetFilesAndDelete(filePath, ".xls", ".pdf", ".xlsx", ".txt", ".crdownload", ".tmp", ".xlsm");
        }

        public static void CloseAllTab()
        {
            CommonFunctions.WaitUntilPageIsAcive();
            var windowHandleSet = Driver.Instance.WindowHandles;
            List<string> tabs = new List<string>(windowHandleSet);
            foreach (var tab in tabs)
            {
                Driver.Instance.SwitchTo().Window(tab);
                // Driver.Instance.Close();
                if (isAlertPresent())
                {
                    Driver.Instance.SwitchTo().Alert().Accept();
                    Thread.Sleep(2000);
                }
                Driver.Instance.Close();
            }
        }

        public static bool isAlertPresent()
        {
            //try
            //{
            //    var alert = Driver.Instance.SwitchTo().Alert();
            //    String str = alert.Text;
            //    return true;
            //}
            //catch (NoAlertPresentException Ex)
            //{
            //    return false;
            //}
            return false;
        }

        private static void EndTest()
        {
            Steps.EndTestSteps();
            string? errMsg;
            var testStatus = TestContext.CurrentContext.Result.Outcome.Status;
            var message = TestContext.CurrentContext.Result.Message;
            switch (testStatus)
            {
                case TestStatus.Failed:
                    ExtentReporting.LogFail($"Test has failed {message}");
                    RunData.testResult = "failed";
                    RunData.isPass = false;
                    ExtentReporting.LogScreenshot("Ending test", getScreenshot());
                    errMsg = TestContext.CurrentContext.Result.Message;
                    CommonFunctions.AddTestStep("Test failed", errMsg);
                    AdoUpdaer.SetAdoResult();
                    break;
                case TestStatus.Passed:
                    ExtentReporting.LogPass($"Test has passed");
                    RunData.testResult = "passed";
                    RunData.isPass = true;
                    ExtentReporting.LogScreenshot("Ending test", getScreenshot());
                    AdoUpdaer.SetAdoResult();
                    break;
                case TestStatus.Skipped:
                    // ExtentReporting.LogInfo($"Test skipped {message}");
                    break;
            }
        }

        private static void GetFilesAndDelete(string path, params string[] extensions)
        {
            List<FileInfo> list = new List<FileInfo>();
            if (Directory.Exists(path))
            {
                foreach (string ext in extensions)
                {
                    list.AddRange(new DirectoryInfo(path).GetFiles("*" + ext).Where(p =>
                          p.Extension.Equals(ext, StringComparison.CurrentCultureIgnoreCase))
                          .ToArray());
                }

                foreach (var file in list)
                {
                    try
                    {
                        file.Attributes = FileAttributes.Normal;
                        File.Delete(file.FullName);
                    }
                    catch
                    {
                        continue;
                    }

                }
            }
        }

        public MediaEntityModelProvider captureScreenshot(String screenShotName)
        {
            ITakesScreenshot ts = (ITakesScreenshot)Driver.Instance;
            var screenshot = ts.GetScreenshot().AsBase64EncodedString;
            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(screenshot).Build();
        }

        public static string getScreenshot()
        {
            ITakesScreenshot ts = (ITakesScreenshot)Driver.Instance;
            var screenshot = ts.GetScreenshot().AsBase64EncodedString;
            return screenshot;
        }

        public static void setUserRole(string role)
        {
            DatabaseUtility.ChangeWftRole(role);
        }
    }
}