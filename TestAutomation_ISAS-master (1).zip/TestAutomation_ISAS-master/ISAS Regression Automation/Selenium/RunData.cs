﻿using AutomationCoreLite.Reporting;
using ISAS_Regression_Automation.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class RunData
    {
        public static string CurrentPlusTarget { get; set; }
        public static string CurrentPlanName { get; set; }
        public static int TimeSaved { get; set; }
        public static string PlanID { get; set; }
        public static string PlanTwoID { get; set; }
        public static string Deptartment { get; set; }
        public static string ComparisonFile { get; set; }
        public static string SecurityDB { get; set; }
        public static string ServerName { get; set; }
        public static string DatabaseName { get; set; }
        public static string FpcServerName { get; set; }
        public static string FpcDatabaseName { get; set; }
        public static string FpcPassword { get; set; }
        public static string Url { get; set; }
        public static string Domain { get; set; }
        public static string UserName { get; set; }
        public static string PAT { get; set; }
        public static string Password { get; set; }
        public static string Facility { get; set; }
        public static string AdoTestCaseName { get; set;} 
        public static string testResult { get; set; }
        public static string EvincedAccountID { get; set; }
        public static string EvincedOfflineKey { get; set; }
        public static readonly List<string>? RallyScreenShots = new();
        public static string AdoTestPlan { get; set; }
        public static bool isPass {  get; set; }
        public static DirectoryInfo BaseFolder = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;
        public static string NewPlanDataComprisonBaseFolder = @$"{RunData.BaseFolder}{SettingData.NewPlanDataComparison}";
    }
    public class AdoUpdaer
    {
        public static void SetAdoResult() 
        {
            try
            {
                Steps.EndTestSteps();
                string folderPath, screenshotLocation;
                var parent = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;
                string AdoBaseUrl = SettingData.AdoBaseUrl;
                string AdoProject = SettingData.AdoProject;
                string TestPlan = RunData.AdoTestPlan?.Trim() ?? "Unknown Test Plan";
                string TestCaseName = RunData.AdoTestCaseName?.Trim() ?? "Unknown Test Case";
                string TestResult = RunData.testResult;
                string PAT = RunData.PAT;
                

                var ado = new AdoTestCasePlugin.AzureDevOpsQa(AdoBaseUrl, AdoProject, PAT, 1);
                ado.CreateTestCaseResult(TestPlan, TestCaseName, TestResult, ReportOutput.ReportOut,
                    RunData.RallyScreenShots, Steps.TestTotalTime.Milliseconds, null);

                folderPath = GetFolderName();
                
                screenshotLocation = $"{folderPath}\\{TestCaseName}";                
                var rg = new ReportGenerator("ISAS"
                                    , TestCaseName
                                    , "UAT"
                                    , DateTime.Now
                                    , RunData.isPass);
                var htmlFilePath = rg.GenerateReport(Steps.TestSteps, screenshotLocation);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ado section");
                Console.WriteLine(ex.ToString());
            }
        }

        /// <summary>
        /// Create a folder for a reprot and screenshots with today's date
        /// </summary>
        /// <returns></returns>
        public static string GetFolderName()
        {
            string Passed = "Passed";
            string Failed = "Failed";
            DateTime now = DateTime.Now;
            string folderName = $"{now:dddd_MMddyyyy}";
            string screenshotLocation = $"{SettingData.ISASScreenshotFolder}";
            string parentfolderPath = Path.Combine(SettingData.ISASScreenshotFolder, folderName);
            string PassedSubfolder = Path.Combine(parentfolderPath, Passed);
            string FailedSubfolder = Path.Combine(parentfolderPath, Failed);
            // Create the parent folder if it doesn't exist
            if (!Directory.Exists(parentfolderPath))
            {
                Directory.CreateDirectory(parentfolderPath);
            }

            if (!Directory.Exists(PassedSubfolder))
            {
                Directory.CreateDirectory(PassedSubfolder);
            }

            if (!Directory.Exists(FailedSubfolder))
            {
                Directory.CreateDirectory(FailedSubfolder);
            }

            if (RunData.isPass)
            {               
                return PassedSubfolder;
            }
            else
            {               
                return FailedSubfolder;
            }
        }
    }
}
