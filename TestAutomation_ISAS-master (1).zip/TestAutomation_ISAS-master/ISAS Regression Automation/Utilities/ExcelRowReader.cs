﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using ExcelDataReader;

namespace ISAS_Regression_Automation.Utilities
{

    public class ExcelRowReader
    {
        /// <summary>
            /// Reads an Excel file and returns all rows as objects with properties matching column headers.
            /// </summary>
            /// <param name="filePath">Path to the Excel file</param>
            /// <param name="useDynamicType">If true, returns compiled objects; if false, returns ExpandoObjects</param>
            /// <param name="sheetIndex">Sheet index to read (0-based, default is 0 for first sheet)</param>
            /// <returns>A list of objects representing each row with properties for each column header</returns>
        public static List<object> ReadExcelAsObjects(
        string filePath,
        bool useDynamicType = true,
        int sheetIndex = 0)
        {
            // Try to register encoding provider
            try
            {
                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Couldn't register encoding provider: {ex.Message}");
                Console.WriteLine("Please install the System.Text.Encoding.CodePages NuGet package");
            }

            var allRows = ReadExcelSheet(filePath, sheetIndex);

            if (allRows.Count == 0)
                return new List<object>();

            // Get the first row to use as a template for our dynamic type
            var firstRow = allRows[0];

            if (useDynamicType)
            {
                // Create a compiled type at runtime based on the dictionary keys
                Type generatedType = CreateDynamicType(firstRow);

                // Convert all rows to this type
                return allRows.Select(rowData =>
                {
                    var obj = Activator.CreateInstance(generatedType);
                    MapDictionaryToObject(rowData, obj);
                    return obj;
                }).ToList();
            }
            else
            {
                // Create ExpandoObjects instead
                return allRows.Select(rowData => CreateDynamicObject(rowData)).Cast<object>().ToList();
            }
        }

        /// <summary>
            /// Gets the Type of the dynamically generated object based on the Excel headers.
            /// </summary>
        public static Type GetDynamicObjectType(string filePath, int sheetIndex = 0)
        {
            // Try to register encoding provider
            try
            {
                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Couldn't register encoding provider: {ex.Message}");
                Console.WriteLine("Please install the System.Text.Encoding.CodePages NuGet package");
            }

            // Get first row to determine structure
            var allRows = ReadExcelSheet(filePath, sheetIndex);
            if (allRows.Count == 0)
                throw new Exception("No data found to determine object structure");

            return CreateDynamicType(allRows[0]);
        }

        /// <summary>
            /// Reads all data from a specific Excel sheet and returns as list of dictionaries.
            /// </summary>
        private static List<Dictionary<string, object>> ReadExcelSheet(string filePath, int sheetIndex)
        {
            var allRows = new List<Dictionary<string, object>>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = (_) => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = false
                        }
                    });

                    if (result.Tables.Count > sheetIndex)
                    {
                        var worksheet = result.Tables[sheetIndex];
                        var sections = FindSections(worksheet);

                        foreach (var section in sections)
                        {
                            var sectionRows = GetRowsFromSection(worksheet, section);
                            allRows.AddRange(sectionRows);
                        }
                    }
                }
            }

            return allRows;
        }

        /// <summary>
            /// Finds all sections (header + data blocks) in a worksheet.
            /// </summary>
        private static List<(int HeaderRowIndex, int DataStartRowIndex, int DataEndRowIndex)> FindSections(DataTable worksheet)
        {
            var sections = new List<(int, int, int)>();
            int rowCount = worksheet.Rows.Count;
            int currentRow = 0;

            while (currentRow < rowCount)
            {
                // Skip empty rows
                while (currentRow < rowCount && IsEmptyRow(worksheet.Rows[currentRow]))
                {
                    currentRow++;
                }

                if (currentRow >= rowCount) break;

                // This is a potential header row
                int headerRow = currentRow;
                currentRow++;

                // Skip empty rows after header
                while (currentRow < rowCount && IsEmptyRow(worksheet.Rows[currentRow]))
                {
                    currentRow++;
                }

                if (currentRow >= rowCount) break;

                // Data rows start here
                int dataStartRow = currentRow;

                // Find the end of this data section
                while (currentRow < rowCount && !IsEmptyRow(worksheet.Rows[currentRow]))
                {
                    currentRow++;
                }

                // Data rows end at the row before
                int dataEndRow = currentRow - 1;

                // Add this section
                sections.Add((headerRow, dataStartRow, dataEndRow));
            }

            return sections;
        }

        /// <summary>
            /// Gets all rows from a specific section as dictionaries.
            /// </summary>
        private static List<Dictionary<string, object>> GetRowsFromSection(
        DataTable worksheet,
        (int HeaderRowIndex, int DataStartRowIndex, int DataEndRowIndex) section)
        {
            var rows = new List<Dictionary<string, object>>();

            // Get the headers for this section
            var headers = new List<string>();
            var headerRow = worksheet.Rows[section.HeaderRowIndex];

            for (int col = 0; col < headerRow.ItemArray.Length; col++)
            {
                var headerValue = headerRow[col]?.ToString() ?? $"Column_{col}";
                headers.Add(headerValue);
            }

            // Get all data rows from this section
            for (int rowIndex = section.DataStartRowIndex; rowIndex <= section.DataEndRowIndex; rowIndex++)
            {
                var row = worksheet.Rows[rowIndex];
                var rowData = new Dictionary<string, object>();

                // Add all headers and values for this row
                for (int col = 0; col < Math.Min(headers.Count, row.ItemArray.Length); col++)
                {
                    // Use a unique key if there are duplicate header names
                    string key = headers[col];
                    if (rowData.ContainsKey(key))
                    {
                        key = $"{headers[col]}_{col}";
                    }

                    rowData[key] = row.ItemArray[col];
                }

                rows.Add(rowData);
            }

            return rows;
        }

        /// <summary>
            /// Determines if a row is empty.
            /// </summary>
        private static bool IsEmptyRow(DataRow row)
        {
            for (int i = 0; i < row.ItemArray.Length; i++)
            {
                if (row.ItemArray[i] != null && !string.IsNullOrWhiteSpace(row.ItemArray[i].ToString()))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
            /// Creates a dynamic ExpandoObject from a dictionary.
            /// </summary>
        private static dynamic CreateDynamicObject(Dictionary<string, object> dictionary)
        {
            dynamic obj = new ExpandoObject();
            var expandoDict = (IDictionary<string, object>)obj;

            foreach (var kvp in dictionary)
            {
                string propertyName = MakeValidPropertyName(kvp.Key);
                expandoDict[propertyName] = kvp.Value;
            }

            return obj;
        }

        /// <summary>
            /// Creates a compiled Type at runtime based on dictionary keys.
            /// </summary>
        private static Type CreateDynamicType(Dictionary<string, object> dictionary)
        {
            // Create a unique type name using a GUID to avoid conflicts
            string typeName = "ExcelRow_" + Guid.NewGuid().ToString("N");

            // Create a dynamic assembly and module
            AssemblyName assemblyName = new AssemblyName("DynamicExcelAssembly");
            AssemblyBuilder assemblyBuilder = AssemblyBuilder.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder = assemblyBuilder.DefineDynamicModule("DynamicExcelModule");

            // Create a new type
            TypeBuilder typeBuilder = moduleBuilder.DefineType(
          typeName,
          TypeAttributes.Public | TypeAttributes.Class | TypeAttributes.AutoClass |
          TypeAttributes.AnsiClass | TypeAttributes.BeforeFieldInit | TypeAttributes.AutoLayout,
          typeof(object));

            // Add properties for each dictionary key
            foreach (var key in dictionary.Keys)
            {
                string propertyName = MakeValidPropertyName(key);
                Type propertyType = GetAppropriateType(dictionary[key]);

                // Create a private field
                FieldBuilder fieldBuilder = typeBuilder.DefineField(
            "_" + propertyName,
            propertyType,
            FieldAttributes.Private);

                // Create property
                PropertyBuilder propertyBuilder = typeBuilder.DefineProperty(
            propertyName,
            PropertyAttributes.HasDefault,
            propertyType,
            null);

                // Define the getter method
                MethodBuilder getMethodBuilder = typeBuilder.DefineMethod(
            "get_" + propertyName,
            MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig,
            propertyType,
            Type.EmptyTypes);

                ILGenerator getIL = getMethodBuilder.GetILGenerator();
                getIL.Emit(OpCodes.Ldarg_0);
                getIL.Emit(OpCodes.Ldfld, fieldBuilder);
                getIL.Emit(OpCodes.Ret);

                // Define the setter method
                MethodBuilder setMethodBuilder = typeBuilder.DefineMethod(
            "set_" + propertyName,
            MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig,
            null,
            new[] { propertyType });

                ILGenerator setIL = setMethodBuilder.GetILGenerator();
                setIL.Emit(OpCodes.Ldarg_0);
                setIL.Emit(OpCodes.Ldarg_1);
                setIL.Emit(OpCodes.Stfld, fieldBuilder);
                setIL.Emit(OpCodes.Ret);

                // Set the accessor methods
                propertyBuilder.SetGetMethod(getMethodBuilder);
                propertyBuilder.SetSetMethod(setMethodBuilder);
            }

            // Create the type
            return typeBuilder.CreateType();
        }

        /// <summary>
            /// Maps dictionary values to an object's properties.
            /// </summary>
        private static void MapDictionaryToObject(Dictionary<string, object> dictionary, object obj)
        {
            Type type = obj.GetType();

            foreach (var kvp in dictionary)
            {
                string propertyName = MakeValidPropertyName(kvp.Key);
                PropertyInfo property = type.GetProperty(propertyName);

                if (property != null)
                {
                    try
                    {
                        // Convert the value to the property type
                        object convertedValue = ConvertToType(kvp.Value, property.PropertyType);
                        property.SetValue(obj, convertedValue);
                    }
                    catch
                    {
                        // If conversion fails, try to set a default value
                        try
                        {
                            property.SetValue(obj, property.PropertyType.IsValueType ?
                              Activator.CreateInstance(property.PropertyType) : null);
                        }
                        catch
                        {
                            // Ignore if we can't set a value
                        }
                    }
                }
            }
        }

        /// <summary>
            /// Converts a string into a valid C# property name.
            /// </summary>
        private static string MakeValidPropertyName(string input)
        {
            if (string.IsNullOrEmpty(input))
                return "EmptyProperty";

            // Remove invalid characters
            string valid = new string(input.Where(c => char.IsLetterOrDigit(c) || c == '_').ToArray());

            // Ensure it starts with a letter or underscore
            if (valid.Length == 0 || !char.IsLetter(valid[0]) && valid[0] != '_')
                valid = "_" + valid;

            return valid;
        }

        /// <summary>
            /// Determines the appropriate .NET type for a property based on its value.
            /// </summary>
        private static Type GetAppropriateType(object value)
        {
            if (value == null)
                return typeof(object);

            Type type = value.GetType();

            // For DB null or special types, use object
            if (type == typeof(DBNull) || type == typeof(DataColumn))
                return typeof(object);

            return type;
        }

        /// <summary>
            /// Converts a value to the specified type.
            /// </summary>
        private static object ConvertToType(object value, Type targetType)
        {
            if (value == null || value is DBNull)
                return null;

            if (targetType.IsAssignableFrom(value.GetType()))
                return value;

            try
            {
                return Convert.ChangeType(value, targetType);
            }
            catch
            {
                // If conversion fails, return null or default
                return targetType.IsValueType ? Activator.CreateInstance(targetType) : null;
            }
        }
    }

   
}