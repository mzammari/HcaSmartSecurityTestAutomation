﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.ForecastView_ContractPercent;

namespace ISAS_Regression_Automation
{
    public class NewPlanLatestQMIRSMonth
    {
        public static string LatestQMIRSMonth { get; set; }
    }

    public class NewPlanElements
    {
        public static bool Jan { get; set; }
        public static bool Feb { get; set; }
        public static bool Mar { get; set; }
        public static bool Apr { get; set; }
        public static bool May { get; set; }
        public static bool Jun { get; set; }
        public static bool Jul { get; set; }
        public static bool Aug { get; set; }
        public static bool Sep { get; set; }
        public static bool Oct { get; set; }
        public static bool Nov { get; set; }
        public static bool Dec { get; set; }
        public static string Approvers { get; set; }
        public static bool NonProductiveQMIRSAvgNpPercent { get; set; }
        public static bool NonProductivePLUSAvgNpPercent { get; set; }
        public static bool NonProductiveMostRecentApprovedPlan { get; set; }
        public static bool NonProductiveMostRecentApprovedAndReleasedPlan { get; set; }
        public static bool StatisticMappingSystemDefault { get; set; }
        public static bool StatisticMappingMostRecentApprovedPlan { get; set; }
        public static bool StatisticMappingMostRecentApprovedAndReleasedPlan { get; set; }
        public static bool ClPercent { get; set; }
        public static bool FixedFTEs { get; set; }
        public static string LatestQMIRSMonth { get; set; }
    }

}
