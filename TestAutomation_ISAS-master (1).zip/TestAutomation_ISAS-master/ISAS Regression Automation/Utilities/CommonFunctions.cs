﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using ISAS_Regression_Automation.Utilities;
using Microsoft.AspNetCore.Hosting;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System.Drawing;
using static System.Net.Mime.MediaTypeNames;
using static ISAS_Regression_Automation.ForecastView_Volume;
using RazorEngine.Templating;
using AutomationCoreLite.Reporting;
using System.Text.RegularExpressions;
using MongoDB.Driver.Core.Configuration;
using DocumentFormat.OpenXml.Bibliography;
using System.Threading.Tasks;
using System.Diagnostics;
using AngleSharp.Dom;
using System.Reflection;
using SharpCompress.Common;
using System.Net.Http;
using System.Runtime.CompilerServices;

namespace ISAS_Regression_Automation
{ 

    public static class CommonFunctions
    {

        public static List<string> ToList(string commaDelemited)
        {
            return commaDelemited.Split(',')
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrEmpty(s))
                .ToList();
        }

        /// <summary>
        /// Reads a text file where each line is an item, 
        /// trims whitespace, and returns a comma-separated string of non-empty lines.
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static string FromFile(string filePath)
        {
            return string.Join(", ", File.ReadAllLines(filePath)
                .Select(line => line.Trim())
                .Where(line => !string.IsNullOrEmpty(line)));
        }
    

        public static string getDownloadedFile(string fileName)
        {
            // Get the Downloads folder path
            string downloadsPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads"
            );

            // Construct full file path
            return Path.Combine(downloadsPath, fileName);
        }

        /// <summary>
        /// Waits for a downloaded file to exist and be non-empty, then returns its full path.
        /// The download directory is resolved from the TEST_DOWNLOAD_DIR environment variable
        /// if set; otherwise the current user's Downloads folder is used.
        /// </summary>
        /// <param name="fileName">Name of the file to wait for (e.g. "budftp.txt").</param>
        /// <param name="timeoutSeconds">Maximum seconds to wait before throwing. Default is 60.</param>
        /// <returns>Full path to the downloaded file once it exists and is non-empty.</returns>
        /// <exception cref="FileNotFoundException">Thrown when the file is not found within the timeout.</exception>
        public static string GetDownloadedFile(string fileName, int timeoutSeconds = 60)
        {
            string downloadDirectory = Environment.GetEnvironmentVariable("TEST_DOWNLOAD_DIR");

            if (string.IsNullOrWhiteSpace(downloadDirectory))
            {
                downloadDirectory = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                    "Downloads");
            }

            string fullPath = Path.Combine(downloadDirectory, fileName);
            var stopwatch = Stopwatch.StartNew();

            while (stopwatch.Elapsed.TotalSeconds < timeoutSeconds)
            {
                if (File.Exists(fullPath) && new FileInfo(fullPath).Length > 0)
                    return fullPath;

                Thread.Sleep(1000);
            }

            throw new FileNotFoundException(
                $"Downloaded file was not found after {timeoutSeconds}s: {fullPath}", fullPath);
        }

        public static string getElementValue(By by)
        {
            return (getElement(by).GetAttribute("value"));
        }

        public static string getElementText(By by)
        {
            return (getElement(by).Text);
        }
        /// <summary>
        /// Get previous and next items in a list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static (string previous, string next) GetPreviousAndNextItemsInList<T>(List<string> list, string value)
        {
            int index = list.IndexOf(value);
            string previous = index > 0 ? list[index - 1] : null;
            string next = index < list.Count - 1 ? list[index + 1] : null;
            return (previous, next);
        }

        public static List<string> GetDropdownOptionByValue(By bySelect)
        {
            var optionLst = new List<string>();
            var DropdownList = getElements(bySelect);
            foreach (var option in DropdownList)
            {
                optionLst.Add(option.GetAttribute("value"));
            }
            return optionLst;
        }

        public static List<string> GetDropdownOptionByText(By bySelect)
        {
            var optionLst = new List<string>();
            var DropdownList = getElements(bySelect);
            foreach (var option in DropdownList)
            {
                optionLst.Add(option.Text);
            }
            return optionLst;
        }
        public static bool WaitForElementValueToBeNonEmpty(By byElement)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
                var element = wait.Until(driver =>
                {
                    var value = getElement(byElement).GetAttribute("value");
                    return !string.IsNullOrEmpty(value) ? true : false;
                });
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            return false;
        }

        public static void WriteToFile(string outputValue)
        {
            //var outputFile = SettingData.OutputFile;
            var outputFile = @"C:\Users\opt6590\OneDrive - HCA Healthcare\Desktop\New folder\WFT\PrnFailedCases.txt";
            if (File.Exists(outputFile))
            {                
                using (StreamWriter writer = (File.Exists(outputFile)) ? File.AppendText(outputFile) : File.CreateText(outputFile))
                {
                    writer.WriteLine(outputValue);
                }
            }            
        }

        public static void WriteToFile(string FileLocation, string outputValue)
        {            
            if (File.Exists(FileLocation))
            {
                using (StreamWriter writer = (File.Exists(FileLocation)) ? File.AppendText(FileLocation) : File.CreateText(FileLocation))
                {
                    writer.WriteLine(outputValue);
                }
            }
        }

        public static void DeleteFile(string FileLocation)
        {
            if (File.Exists(FileLocation))
            {
                File.Delete(FileLocation);
            }
        }



        public static bool GetFileContentLength()
        {
            bool bDatafound;
            var outputFile = SettingData.OutputFile;
            if (File.Exists(outputFile))
            {
                bDatafound = (new FileInfo(outputFile).Length > 0) ? false : true;
                return bDatafound;
            }
            return true;
        }

        public static bool IsCurrentTestInReportCategory()
        {
            var categories = TestContext.CurrentContext.Test.Properties["Category"];
            return categories?.Cast<string>().Any(c => c.Contains("Reports", StringComparison.OrdinalIgnoreCase)) == true;
        } 

        public static async Task LoginToHelpServerAsync()
        {
            string loginCred = $"{RunData.Domain}\\{RunData.UserName}";
            var handler = new NetworkAuthenticationHandler()
            {
                UriMatcher = uri => uri.AbsoluteUri.Contains(SettingData.HelpDomain),
                Credentials = new PasswordCredentials(loginCred, RunData.Password)
            };
            var networkInterceptor = Driver.Instance.Manage().Network;
            networkInterceptor.AddAuthenticationHandler(handler);
            await networkInterceptor.StartMonitoring();
            Thread.Sleep(1000);
            await networkInterceptor.StopMonitoring();
        }

        public static int FindDeptRow(string searchedWord, List<object[]> allRows)
        {
            for (int i = 0; i < allRows.Count; i++)
            {
                var cellValue = allRows[i].Length > 0 ? allRows[i][0]?.ToString() : null;
                if (!string.IsNullOrEmpty(cellValue) && cellValue.Contains(searchedWord))
                {
                    return i;
                }
            }
            return -1;
        }

        public static bool IsEmptyRow(object[] row)
        {
            foreach (var item in row)
            {
                if (item != null && !string.IsNullOrWhiteSpace(item.ToString()))
                    return false;
            }
            return true;
        }

        public static string GetStringValue(object[] row, int columnIndex)
        {
            if (columnIndex >= row.Length)
                return string.Empty;

            return row[columnIndex]?.ToString() ?? string.Empty;
        }

        public static decimal GetDecimalValue(object[] row, int columnIndex)
        {
            if (columnIndex >= row.Length)
                return 0;

            var value = row[columnIndex];

            if (value == null)
                return 0;

            if (decimal.TryParse(value.ToString(), out decimal result))
                return result;

            return 0;
        }

        public static double GetdoubleValue(object[] row, int columnIndex)
        {
            if (columnIndex >= row.Length)
                return 0;

            var value = row[columnIndex];

            if (value == null)
                return 0;

            if (double.TryParse(value.ToString(), out double result))
                return result;

            return 0;
        }

        public static decimal ConvertToDecimal(string value, int roundingDecimal = 2)
        {
            if (string.IsNullOrEmpty(value))
                return 0;
            if (decimal.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal result))
            {
                return Math.Round(result, roundingDecimal, MidpointRounding.AwayFromZero);
            }
            return 0;
        }


        public static double ConvertToDouble(string value, int roundingDecimal = 2)
        {
            if (string.IsNullOrEmpty(value))
                return 0;
            if (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out double result))
            {
                return Math.Round(result, roundingDecimal, MidpointRounding.AwayFromZero);
            }
            return 0;
        }
        /// <summary>
        /// Verify a dialog is open or panel is expanded
        /// </summary>
        /// <param name="byButton"></param>
        /// <param name="ExpectedVisibleElement"></param>
        /// <returns>True: if visible; otherwise, false. </returns>
        public static bool VerifyDialogVisible(By byButton, By ExpectedVisibleElement)
        {
            bool bDisplayed;
            for (int i = 0; i <= 6; i++)
            {
                getElement(byButton).Click();
                Thread.Sleep(2000);
                bDisplayed = IsElementDisplayed(ExpectedVisibleElement, 5);
                if (bDisplayed)
                {
                    return true;
                }
            }
            return false;
        }
        public static decimal GetDecimalValue(IWebElement element)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)Driver.Instance;
            // Try to get as number first (most accurate for decimals)
            object numValue = js.ExecuteScript("return arguments[0].valueAsNumber;", element);
            if (numValue != null && !double.IsNaN((double)numValue))
            {
                return Convert.ToDecimal(numValue);
            }

            // Fallback to string value
            string stringValue = (string)js.ExecuteScript("return arguments[0].value;", element);
            return decimal.Parse(stringValue);
        }

        public static string getElapsedTimeForthePageToBecomeActive(By byVariable)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            DateTime timeout = DateTime.Now.AddMinutes(15);
            bool isElementEnabled;

            while (DateTime.Now < timeout)
            {
                CommonFunctions.WaitUntilPageIsAcive();

                isElementEnabled = CommonFunctions.IsElementDisplayed(byVariable, 1);
                if (isElementEnabled)
                {
                    stopwatch.Stop();

                    // Get the elapsed time
                    TimeSpan elapsedTime = stopwatch.Elapsed;

                    // Convert the elapsed time to minutes and seconds
                    int minutes = elapsedTime.Minutes;
                    int seconds = elapsedTime.Seconds;

                    return $"The page was reloaded in {minutes} minute(s) and {seconds} second(s)";
                }
            }
            return null;
        }

        private static string getElapsedTimeForthePageTobeEnabled(By byVariable)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            DateTime timeout = DateTime.Now.AddMinutes(15);
            bool isElementEnabled;

            while (DateTime.Now < timeout)
            {
                CommonFunctions.WaitUntilPageIsAcive();

                isElementEnabled = CommonFunctions.IsElementDisplayed(byVariable, 1);
                if (isElementEnabled)
                {
                    stopwatch.Stop();

                    // Get the elapsed time
                    TimeSpan elapsedTime = stopwatch.Elapsed;

                    // Convert the elapsed time to minutes and seconds
                    int minutes = elapsedTime.Minutes;
                    int seconds = elapsedTime.Seconds;

                    return $"The page was reloaded in {minutes} minute(s) and {seconds} second(s)";
                }
            }
            return null;
        }

        public static List<string> GetNonEmptyTextFiles(string folderPath)
        {
            List<string> nonEmptyFiles = new List<string>();

            try
            {
                // Check if the directory exists
                if (!Directory.Exists(folderPath))
                {
                    throw new DirectoryNotFoundException($"Directory not found: {folderPath}");
                }

                // Get all text files in the directory
                string[] textFiles = Directory.GetFiles(folderPath, "DataComparison*",SearchOption.TopDirectoryOnly);

                foreach (string filePath in textFiles)
                {
                    // Check if the file has content (length > 0)
                    if (new FileInfo(filePath).Length > 0)
                    {
                        // Add the file name (not the full path) to the list
                        string fileName = Path.GetFileName(filePath);
                        nonEmptyFiles.Add(fileName);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing files: {ex.Message}");
            }

            return nonEmptyFiles;
        }

        public static void InsertWftFreezeAdministrator()
        {
            CommonFunctions.AddTestStep("Insert WftFreezeAdministrator", "Insert WftFreezeAdministrator");
            string InsertWftFreezeAdmin = "insert into  [ISAS_Security].[dbo].[SecurityAssignment] values( 'opt6590@hca.corpad.net',    'WftFreezeAdministrator',    'Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',    1,    NULL);";
            string DB = RunData.SecurityDB;
            RunQuery(InsertWftFreezeAdmin, DB);
        }

        public static void DeleteWftFreezeAdministrator()
        {       
            CommonFunctions.AddTestStep("Delete WftFreezeAdministrator role", "Delete WftFreezeAdministrator role");
            string DeleteWftFreezeAdmin = "delete from [ISAS_Security].[dbo].[SecurityAssignment] where UserIdentity = 'opt6590@hca.corpad.net'  and role like 'WftFreezeAdministrator';";
            string DB = RunData.SecurityDB;
            RunQuery(DeleteWftFreezeAdmin, DB);
        }

        public static string FormatDate(string inputDate)
        {
            // Parse the date
            DateTime date = DateTime.ParseExact(inputDate, "dddd, MMMM d, yyyy", CultureInfo.InvariantCulture);
            // Format the date as "M/d/yyyy"
            string formattedDate = date.ToString("M/d/yyyy");
            return formattedDate;
        }

        public static string getTestcaseTimeStamp()
        {
            DateTime now = DateTime.Now;
            string timeSamp = $"{now:dddd MM/dd/yyyy hh:mm tt}";
            return timeSamp;
        }

        public static void AddTestStep(string action, string expected)
        {
            Steps.AddTestStep(action, expected);

            try
            {
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
            }
            catch (WebDriverException ex)
            {
                Console.WriteLine($"Screenshot skipped for test step because browser window was not available: {ex.Message}");
            }
        }

        public static void AddTestStep(string TestValue, string sField, bool? bTestValue)
        {
            string fieldName = AddSpaceAndCapitalize(sField);
            string Action = $"Verify a user can set {TestValue} in the {fieldName} field";
            string Expected = $"The {TestValue} is set correctly";
            Steps.AddTestStep(Action, Expected);
            Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
        }

        public static void AddTestStep(bool TestValue, string sField, bool? bTestValue)
        {
            string fieldName = AddSpaceAndCapitalize(sField);
            string setValue;
            if(TestValue)
            {
                setValue = "ON";
            }
            else
            {
                setValue = "Off";
            }

            string Action = $"Verify a user can tick the {fieldName} {setValue}";
            string Expected = $"The {fieldName} is set correctly";
            Steps.AddTestStep(Action, Expected);
            Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
        }

        public static void AddTestStep(string sField)
        {
            string fieldName = AddSpaceAndCapitalize(sField);
            string Action = $"Verify a user can click the {fieldName} field";
            string Expected = $"The {fieldName} field is enabled";
            Steps.AddTestStep(Action, Expected);
            Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
        }

        public static string GetBase64ScreenshotFromWrappedDriver(IWebDriver driver)
        {
            // Try IWrapsDriver first (if Evinced implements it)
            if (driver is IWrapsDriver wrapsDriver) 
            { 
                var wrappedDriver = wrapsDriver.WrappedDriver; 
                if (wrappedDriver is ITakesScreenshot screenshotDriver)
                { 
                    return screenshotDriver.GetScreenshot().AsBase64EncodedString; 
                } 
            }
            // Fallback to reflection
            return null;
        }

        private static string AddSpaceAndCapitalize(string input)
        {
            if(string.IsNullOrEmpty(input)) return input;
            string spacedString = Regex.Replace(input, "(?!^)([A-Z])", " $1");
            return char.ToUpper(spacedString[0]) + spacedString.Substring(1);
        }

        /// <summary>
        /// return date format as Friday, December 27, 2024
        /// </summary>
        /// <param name="path"></param>
        /// <returns>return date format as Friday, December 27, 2024</returns>
        /// 
        public static string getCurrentDate()
        {
            DateTime currentDate = DateTime.Now;
            string formattedDate = currentDate.ToString("ddd, MMMM, dd, yyyy");
            return formattedDate;   
        }

        public static IWebElement getElement(By byPath)
        {            
            IWebElement element = Driver.Instance.FindElement(byPath);
            return element;           
        }

        public static IList<IWebElement> getElements(By path)
        {
            IList<IWebElement> lstElement = Driver.Instance.FindElements(path);
            return lstElement;
        }
        

        public static string GetItemRankInList(MonthlyForcastView firstDataSet, string rank)
        {
            string month;
            Dictionary<string, double> rankList = new Dictionary<string, double>()
            {
                {"January",firstDataSet.Jan },
                {"February",firstDataSet.Feb},
                {"March",firstDataSet.Mar},
                {"April",firstDataSet.Apr},
                {"May",firstDataSet.May},
                {"June",firstDataSet.Jun},
                {"July",firstDataSet.Jul},
                {"August",firstDataSet.Aug},
                {"September",firstDataSet.Sep},
                {"October",firstDataSet.Oct},
                {"November",firstDataSet.Nov},
                {"December",firstDataSet.Dec}
            };

            switch (rank.Trim())
            {
                case "Lowest UOS Month":
                    return rankList.OrderBy(x => x.Value).Skip(0).FirstOrDefault().Key;
                case "2nd Lowest UOS Month":
                    return rankList.OrderBy(x => x.Value).Skip(1).FirstOrDefault().Key;
                case "3nd Lowest UOS Month":
                    return rankList.OrderBy(x => x.Value).Distinct().Skip(2).FirstOrDefault().Key;
                //case "Avg of 2 Lowest UOS Months":
                //    return rankList.OrderBy(x => x.Value).Take(2);
                //case "Avg of 3 Lowest UOS Months":
                //    return rankList.OrderBy(x => x.Value).Take(3);
                case "Highest UOS Month":
                    return rankList.OrderByDescending(x => x.Value).Distinct().Skip(0).FirstOrDefault().Key;
                case "2nd Highest UOS Month":
                    return rankList.OrderByDescending(x => x.Value).Distinct().Skip(1).FirstOrDefault().Key;
                case "3nd Highest UOS Month":
                    return rankList.OrderByDescending(x => x.Value).Distinct().Skip(2).FirstOrDefault().Key;
                //case "Avg of 2 Highest UOS Months":
                //    return rankList.OrderByDescending(x => x.Value).Take(2);
                //case "Avg of 3 Highest UOS Months":
                //    return rankList.OrderByDescending(x => x.Value).Take(3);
                default:
                    break;
            }
            return null;


        }

        public static MonthElements getRowElements(string xpath)
        {
            return new MonthElements()
            {
                Jan = getElement(By.XPath($"{xpath}/input[1]")),
                Feb = getElement(By.XPath($"{xpath}/input[2]")),
                Mar = getElement(By.XPath($"{xpath}/input[3]")),
                Apr = getElement(By.XPath($"{xpath}/input[4]")),
                May = getElement(By.XPath($"{xpath}/input[5]")),
                Jun = getElement(By.XPath($"{xpath}/input[6]")),
                Jul = getElement(By.XPath($"{xpath}/input[7]")),
                Aug = getElement(By.XPath($"{xpath}/input[8]")),
                Sep = getElement(By.XPath($"{xpath}/input[9]")),
                Oct = getElement(By.XPath($"{xpath}/input[10]")),
                Nov = getElement(By.XPath($"{xpath}/input[11]")),
                Dec = getElement(By.XPath($"{xpath}/input[12]")),
                Total = getElement(By.XPath($"{xpath}/input[13]"))

            };
        }

        public static MonthElements getTargetDetailsElements(string xpath)
        {
            return new MonthElements()
            {
                Jan = getElement(By.XPath($"{xpath}[1]")),
                Feb = getElement(By.XPath($"{xpath}[2]")),
                Mar = getElement(By.XPath($"{xpath}[3]")),
                Apr = getElement(By.XPath($"{xpath}[4]")),
                May = getElement(By.XPath($"{xpath}[5]")),
                Jun = getElement(By.XPath($"{xpath}[6]")),
                Jul = getElement(By.XPath($"{xpath}[7]")),
                Aug = getElement(By.XPath($"{xpath}[8]")),
                Sep = getElement(By.XPath($"{xpath}[9]")),
                Oct = getElement(By.XPath($"{xpath}[10]")),
                Nov = getElement(By.XPath($"{xpath}[11]")),
                Dec = getElement(By.XPath($"{xpath}[12]"))

            };
        }

        public static MonthlyForcastView getTargetDetailsCategoryData(string xpath)
        {
            return new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[1]")).GetAttribute("value"), 4),
                Feb = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[2]")).GetAttribute("value"), 4),
                Mar = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[3]")).GetAttribute("value"), 4),
                Apr = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[4]")).GetAttribute("value"), 4),
                May = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[5]")).GetAttribute("value"), 4),
                Jun = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[6]")).GetAttribute("value"), 4),
                Jul = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[7]")).GetAttribute("value"), 4),
                Aug = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[8]")).GetAttribute("value"), 4),
                Sep = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[9]")).GetAttribute("value"), 4),
                Oct = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[10]")).GetAttribute("value"), 4),
                Nov = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[11]")).GetAttribute("value"), 4),
                Dec = CommonFunctions.ToDouble(getElement(By.XPath($"{xpath}[12]")).GetAttribute("value"), 4)

            };
        }

        public static MonthlyForcastView getMonthlyData(string xpath, int roundingDecimal)
        {
            try
            {
                var list = getElements(By.XPath($"{xpath}/input"));
                if (list.Count > 12)
                {
                    IWebElement Jan = getElement(By.XPath($"{xpath}/input[1]"));
                    IWebElement Feb = getElement(By.XPath($"{xpath}/input[2]"));
                    IWebElement Mar = getElement(By.XPath($"{xpath}/input[3]"));
                    IWebElement Apr = getElement(By.XPath($"{xpath}/input[4]"));
                    IWebElement May = getElement(By.XPath($"{xpath}/input[5]"));
                    IWebElement Jun = getElement(By.XPath($"{xpath}/input[6]"));
                    IWebElement Jul = getElement(By.XPath($"{xpath}/input[7]"));
                    IWebElement Aug = getElement(By.XPath($"{xpath}/input[8]"));
                    IWebElement Sep = getElement(By.XPath($"{xpath}/input[9]"));
                    IWebElement Oct = getElement(By.XPath($"{xpath}/input[10]"));
                    IWebElement Nov = getElement(By.XPath($"{xpath}/input[11]"));
                    IWebElement Dec = getElement(By.XPath($"{xpath}/input[12]"));
                    IWebElement Total = getElement(By.XPath($"{xpath}/input[13]"));

                    var data = new MonthlyForcastView()
                    {
                        Jan = ToDouble(Jan.GetAttribute("value"), roundingDecimal),
                        Feb = ToDouble(Feb.GetAttribute("value"), roundingDecimal),
                        Mar = ToDouble(Mar.GetAttribute("value"), roundingDecimal),
                        Apr = ToDouble(Apr.GetAttribute("value"), roundingDecimal),
                        May = ToDouble(May.GetAttribute("value"), roundingDecimal),
                        Jun = ToDouble(Jun.GetAttribute("value"), roundingDecimal),
                        Jul = ToDouble(Jul.GetAttribute("value"), roundingDecimal),
                        Aug = ToDouble(Aug.GetAttribute("value"), roundingDecimal),
                        Sep = ToDouble(Sep.GetAttribute("value"), roundingDecimal),
                        Oct = ToDouble(Oct.GetAttribute("value"), roundingDecimal),
                        Nov = ToDouble(Nov.GetAttribute("value"), roundingDecimal),
                        Dec = ToDouble(Dec.GetAttribute("value"), roundingDecimal),
                        Total = ToDouble(Total.GetAttribute("value"), roundingDecimal)
                    };
                    return data;
                }
                else
                {
                    IWebElement Jan = getElement(By.XPath($"{xpath}/input[1]"));
                    IWebElement Feb = getElement(By.XPath($"{xpath}/input[2]"));
                    IWebElement Mar = getElement(By.XPath($"{xpath}/input[3]"));
                    IWebElement Apr = getElement(By.XPath($"{xpath}/input[4]"));
                    IWebElement May = getElement(By.XPath($"{xpath}/input[5]"));
                    IWebElement Jun = getElement(By.XPath($"{xpath}/input[6]"));
                    IWebElement Jul = getElement(By.XPath($"{xpath}/input[7]"));
                    IWebElement Aug = getElement(By.XPath($"{xpath}/input[8]"));
                    IWebElement Sep = getElement(By.XPath($"{xpath}/input[9]"));
                    IWebElement Oct = getElement(By.XPath($"{xpath}/input[10]"));
                    IWebElement Nov = getElement(By.XPath($"{xpath}/input[11]"));
                    IWebElement Dec = getElement(By.XPath($"{xpath}/input[12]"));

                    var data = new MonthlyForcastView()
                    {
                        Jan = ToDouble(Jan.GetAttribute("value"), roundingDecimal),
                        Feb = ToDouble(Feb.GetAttribute("value"), roundingDecimal),
                        Mar = ToDouble(Mar.GetAttribute("value"), roundingDecimal),
                        Apr = ToDouble(Apr.GetAttribute("value"), roundingDecimal),
                        May = ToDouble(May.GetAttribute("value"), roundingDecimal),
                        Jun = ToDouble(Jun.GetAttribute("value"), roundingDecimal),
                        Jul = ToDouble(Jul.GetAttribute("value"), roundingDecimal),
                        Aug = ToDouble(Aug.GetAttribute("value"), roundingDecimal),
                        Sep = ToDouble(Sep.GetAttribute("value"), roundingDecimal),
                        Oct = ToDouble(Oct.GetAttribute("value"), roundingDecimal),
                        Nov = ToDouble(Nov.GetAttribute("value"), roundingDecimal),
                        Dec = ToDouble(Dec.GetAttribute("value"), roundingDecimal)
                    };
                    return data;
                }
            }
            catch
            {
                var list = getElements(By.XPath($"{xpath}"));
                if (list.Count > 12)
                {
                    IWebElement Jan = getElement(By.XPath($"{xpath}[1]"));
                    IWebElement Feb = getElement(By.XPath($"{xpath}[2]"));
                    IWebElement Mar = getElement(By.XPath($"{xpath}[3]"));
                    IWebElement Apr = getElement(By.XPath($"{xpath}[4]"));
                    IWebElement May = getElement(By.XPath($"{xpath}[5]"));
                    IWebElement Jun = getElement(By.XPath($"{xpath}[6]"));
                    IWebElement Jul = getElement(By.XPath($"{xpath}[7]"));
                    IWebElement Aug = getElement(By.XPath($"{xpath}[8]"));
                    IWebElement Sep = getElement(By.XPath($"{xpath}[9]"));
                    IWebElement Oct = getElement(By.XPath($"{xpath}[10]"));
                    IWebElement Nov = getElement(By.XPath($"{xpath}[11]"));
                    IWebElement Dec = getElement(By.XPath($"{xpath}[12]"));
                    IWebElement Total = getElement(By.XPath($"{xpath}[13]"));

                    var data = new MonthlyForcastView()
                    {
                        Jan = ToDouble(Jan.GetAttribute("value"), roundingDecimal),
                        Feb = ToDouble(Feb.GetAttribute("value"), roundingDecimal),
                        Mar = ToDouble(Mar.GetAttribute("value"), roundingDecimal),
                        Apr = ToDouble(Apr.GetAttribute("value"), roundingDecimal),
                        May = ToDouble(May.GetAttribute("value"), roundingDecimal),
                        Jun = ToDouble(Jun.GetAttribute("value"), roundingDecimal),
                        Jul = ToDouble(Jul.GetAttribute("value"), roundingDecimal),
                        Aug = ToDouble(Aug.GetAttribute("value"), roundingDecimal),
                        Sep = ToDouble(Sep.GetAttribute("value"), roundingDecimal),
                        Oct = ToDouble(Oct.GetAttribute("value"), roundingDecimal),
                        Nov = ToDouble(Nov.GetAttribute("value"), roundingDecimal),
                        Dec = ToDouble(Dec.GetAttribute("value"), roundingDecimal),
                        Total = ToDouble(Total.GetAttribute("value"), roundingDecimal)
                    };
                    return data;
                }
                else
                {
                    IWebElement Jan = getElement(By.XPath($"{xpath}[1]"));
                    IWebElement Feb = getElement(By.XPath($"{xpath}[2]"));
                    IWebElement Mar = getElement(By.XPath($"{xpath}[3]"));
                    IWebElement Apr = getElement(By.XPath($"{xpath}[4]"));
                    IWebElement May = getElement(By.XPath($"{xpath}[5]"));
                    IWebElement Jun = getElement(By.XPath($"{xpath}[6]"));
                    IWebElement Jul = getElement(By.XPath($"{xpath}[7]"));
                    IWebElement Aug = getElement(By.XPath($"{xpath}[8]"));
                    IWebElement Sep = getElement(By.XPath($"{xpath}[9]"));
                    IWebElement Oct = getElement(By.XPath($"{xpath}[10]"));
                    IWebElement Nov = getElement(By.XPath($"{xpath}[11]"));
                    IWebElement Dec = getElement(By.XPath($"{xpath}[12]"));

                    var data = new MonthlyForcastView()
                    {
                        Jan = ToDouble(Jan.GetAttribute("value"), roundingDecimal),
                        Feb = ToDouble(Feb.GetAttribute("value"), roundingDecimal),
                        Mar = ToDouble(Mar.GetAttribute("value"), roundingDecimal),
                        Apr = ToDouble(Apr.GetAttribute("value"), roundingDecimal),
                        May = ToDouble(May.GetAttribute("value"), roundingDecimal),
                        Jun = ToDouble(Jun.GetAttribute("value"), roundingDecimal),
                        Jul = ToDouble(Jul.GetAttribute("value"), roundingDecimal),
                        Aug = ToDouble(Aug.GetAttribute("value"), roundingDecimal),
                        Sep = ToDouble(Sep.GetAttribute("value"), roundingDecimal),
                        Oct = ToDouble(Oct.GetAttribute("value"), roundingDecimal),
                        Nov = ToDouble(Nov.GetAttribute("value"), roundingDecimal),
                        Dec = ToDouble(Dec.GetAttribute("value"), roundingDecimal)
                    };
                    return data;
                }
            }
        }


        public static MonthlyForcastView getRowValues(MonthElements row)
        {
            var data = new MonthlyForcastView()
            {
                Jan = ToDouble(row.Jan.GetAttribute("value")),
                Feb = ToDouble(row.Feb.GetAttribute("value")),
                Mar = ToDouble(row.Mar.GetAttribute("value")),
                Apr = ToDouble(row.Apr.GetAttribute("value")),
                May = ToDouble(row.May.GetAttribute("value")),
                Jun = ToDouble(row.Jun.GetAttribute("value")),
                Jul = ToDouble(row.Jul.GetAttribute("value")),
                Aug = ToDouble(row.Aug.GetAttribute("value")),
                Sep = ToDouble(row.Sep.GetAttribute("value")),
                Oct = ToDouble(row.Oct.GetAttribute("value")),
                Nov = ToDouble(row.Nov.GetAttribute("value")),
                Dec = ToDouble(row.Dec.GetAttribute("value")),
                Total = ToDouble(row.Total.GetAttribute("value"))
            };
            return data;
        }

        public static void DoubleClickMonth(By ByValue)
        {
            var Element = getElement(ByValue);
            DoubleClickUsingWebElement(Element);
            WaitUntilPageIsAcive();
            DeptForecastMenu.clickSaveAndRecalc();
            AdminMenu.Save();
            FacilityStats.CancelUpdatePlan();
            WaitUntilPageIsAcive();
            WaitSaveToastMsgDisappeared();
        }

        public static double GetDoubleRandomNumber()
        {
            double minimum = 1.011;
            double maximum = 10.999;
            Random random = new Random();
            return Math.Round((random.NextDouble() * (maximum - minimum) + minimum), 3, MidpointRounding.AwayFromZero);
        }

        public static bool CompareWeeklyObjectsByText(WeeklyElements firstObj, WeeklyElements secondObj)
        {
            bool ismatched;
            return ismatched = string.Equals(firstObj.Sun.Text, secondObj.Sun.Text, StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Sun.Text, secondObj.Sun.Text, StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Mon.Text, secondObj.Mon.Text, StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Tue.Text, secondObj.Tue.Text, StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Wed.Text, secondObj.Wed.Text, StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Thu.Text, secondObj.Thu.Text, StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Fri.Text, secondObj.Fri.Text, StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Sat.Text, secondObj.Sat.Text, StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.ProdMinFTEs.Text, secondObj.ProdMinFTEs.Text, StringComparison.CurrentCultureIgnoreCase);
        }

        public static bool CompareWeeklyObjectsByValue(WeeklyElements firstObj, WeeklyElements secondObj)
        {
            bool ismatched;
            return ismatched = 
                string.Equals(firstObj.Sun.GetAttribute("value"), secondObj.Sun.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Mon.GetAttribute("value"), secondObj.Mon.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Tue.GetAttribute("value"), secondObj.Tue.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Wed.GetAttribute("value"), secondObj.Wed.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Thu.GetAttribute("value"), secondObj.Thu.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Fri.GetAttribute("value"), secondObj.Fri.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Sat.GetAttribute("value"), secondObj.Sat.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.ProdMinFTEs.GetAttribute("value"), secondObj.ProdMinFTEs.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase);
        }

        public static bool CompareWeekObjectsByTextAndValue(WeeklyElements firstObj, WeeklyElements secondObj)
        {
            bool ismatched;
            return ismatched = string.Equals(firstObj.Sun.GetAttribute("value"), secondObj.Sun.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Sun.Text, secondObj.Sun.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Mon.Text, secondObj.Mon.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Tue.Text, secondObj.Tue.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Wed.Text, secondObj.Wed.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Thu.Text, secondObj.Thu.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Fri.Text, secondObj.Fri.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase) &&
                string.Equals(firstObj.Sat.Text, secondObj.Sat.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase);
               
        }

        public static bool CompareWeekDaysValues(StepTargetsWeekDays firstObj, WeekElementsValues secondObj)
        {
            bool bMatched =
                ToDouble(firstObj.Sun.GetAttribute("value")) == secondObj.Sun &&
                ToDouble(firstObj.Mon.GetAttribute("value")) == secondObj.Mon &&
                ToDouble(firstObj.Tue.GetAttribute("value")) == secondObj.Tue &&
                ToDouble(firstObj.Wed.GetAttribute("value")) == secondObj.Wed &&
                ToDouble(firstObj.Thu.GetAttribute("value")) == secondObj.Thu &&
                ToDouble(firstObj.Fri.GetAttribute("value")) == secondObj.Fri &&
                ToDouble(firstObj.Sat.GetAttribute("value")) == secondObj.Sat;

            return bMatched;
        }

        public static WeekElementsValues AddTwoWeekObjectsByText(WeeklyElements firstObj, WeeklyElements secondObj)
        {
            return new WeekElementsValues()
            {
               Sun = ToDouble(firstObj.Sun.Text) + ToDouble(secondObj.Sun.Text),
               Mon = ToDouble(firstObj.Mon.Text) + ToDouble(secondObj.Mon.Text),
               Tue = ToDouble(firstObj.Tue.Text) + ToDouble(secondObj.Tue.Text),
               Wed = ToDouble(firstObj.Wed.Text) + ToDouble(secondObj.Wed.Text),
               Thu = ToDouble(firstObj.Thu.Text) + ToDouble(secondObj.Thu.Text),
               Fri = ToDouble(firstObj.Fri.Text) + ToDouble(secondObj.Fri.Text),
               Sat = ToDouble(firstObj.Sat.Text) + ToDouble(secondObj.Sat.Text)
            };

        }

        public static bool CompareFacilityStatsMappingObjects(FacilityStatsMappingObject Plan1, FacilityStatsMappingObject Plan2)
        {
            bool bMatched;
            bMatched = Plan1.DeptName == Plan2.DeptName &&
            Plan1.WFTDeptType == Plan2.WFTDeptType &&
            Plan1.DepartmentStat == Plan2.DepartmentStat &&
            Plan1.FacilityStat == Plan2.FacilityStat &&
            Plan1.CLPercentOrFTE == Plan2.CLPercentOrFTE &&
            Plan1.NPPercent == Plan2.NPPercent &&
            Plan1.IgnoredInWFT == Plan2.IgnoredInWFT &&
            Plan1.FreezeRatioVol == Plan2.FreezeRatioVol &&
            Plan1.FreezeStdTgt == Plan2.FreezeStdTgt &&
            Plan1.FreezeSVStepSel == Plan2.FreezeSVStepSel &&
            Plan1.FreezeCLPercent == Plan2.FreezeCLPercent &&
            Plan1.FreezeNPPercent == Plan2.FreezeNPPercent &&
            Plan1.FreezeOTPercent == Plan2.FreezeOTPercent;
            return bMatched;
        }

        public static Bitmap GetElementScreenShot(IWebElement element)
        {
            Screenshot sc = ((ITakesScreenshot)Driver.Instance).GetScreenshot();
            var img = System.Drawing.Image.FromStream(new MemoryStream(sc.AsByteArray)) as Bitmap;
            img.Save(@"C:\Screenshots\elementScreenshot.png", System.Drawing.Imaging.ImageFormat.Png);
            return img.Clone(new Rectangle(element.Location, element.Size), img.PixelFormat);
        }


        public static Bitmap GetElementScreenShot(IWebElement element, string fileData)
        {
            Screenshot sc = ((ITakesScreenshot)Driver.Instance).GetScreenshot();
            var img = System.Drawing.Image.FromStream(new MemoryStream(sc.AsByteArray)) as Bitmap;
            img.Save(@$"C:\Screenshots\{fileData}.png", System.Drawing.Imaging.ImageFormat.Png);
            return img.Clone(new Rectangle(element.Location, element.Size), img.PixelFormat);
        }

        public static void getScreenshot(string fileData)
        {
            scrollDown();
            ITakesScreenshot ts = (ITakesScreenshot)Driver.Instance;
            var screenshot = ts.GetScreenshot().AsBase64EncodedString;
            byte[] imageBytes = Convert.FromBase64String(screenshot);
            File.WriteAllBytes(@$"C:\Screenshots\{fileData}.png", imageBytes);
        }

        public static void GetScreenshot(string fileName)
        {
            Screenshot sc = ((ITakesScreenshot)Driver.Instance).GetScreenshot();
            var img = System.Drawing.Image.FromStream(new MemoryStream(sc.AsByteArray)) as Bitmap;
            img.Save(@$"C:\Screenshots\{fileName}.png", System.Drawing.Imaging.ImageFormat.Png);
        }

        //public static void getEelementScreenshot(IWebElement element)
        //{
        //    WaitUntilPageIsAcive();
        //    Thread.Sleep(2000);
        //    // Get location and size of the element
        //    Point location = element.Location;
        //    Size size = element.Size;

        //    // Take screenshot of the entire page
        //    ITakesScreenshot screenshotDriver = (ITakesScreenshot)Driver.Instance;
        //    Screenshot screenshot = screenshotDriver.GetScreenshot();

        //    // Convert base64 string to byte array
        //    byte[] byteArray = Convert.FromBase64String(screenshot.AsBase64EncodedString);

        //    // Convert byte array to MemoryStream
        //    using (MemoryStream stream = new MemoryStream(byteArray))
        //    {
        //        // Crop the screenshot to include only the desired element
        //        using (Bitmap bitmap = new Bitmap(stream))
        //        {
        //            Rectangle croppedRectangle = new Rectangle(location, size);
        //            Bitmap croppedImage = bitmap.Clone(croppedRectangle, bitmap.PixelFormat);

        //            // Save or do whatever you want with the cropped image
        //            croppedImage.Save(@"C:\Screenshots\elementScreenshot.png", System.Drawing.Imaging.ImageFormat.Png);
        //        }
        //    }

        //}

        public static double ToDouble(string value)
        {
            double result;
            double.TryParse(value, System.Globalization.NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"), out result);               
            return Math.Round(result,2,MidpointRounding.AwayFromZero);
        }

        public static double ToDouble(double value, int roundingDecimal)
        {
            return Math.Round(value, roundingDecimal, MidpointRounding.AwayFromZero);
        }

        public static double ToDouble(string value, int roundingDecimal)
        {
            double result;
            double.TryParse(value, System.Globalization.NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"), out result);
            return Math.Round(result, roundingDecimal, MidpointRounding.AwayFromZero);
        }

        
        public static bool CompareObjects(MonthlyForcastView WFTData, BudgetExportHost HostFileData)
        {
            bool ismatched;
            ismatched = WFTData.Jan == HostFileData.Jan &&
                WFTData.Feb == HostFileData.Feb &&
                WFTData.Mar == HostFileData.Mar &&
                WFTData.Apr == HostFileData.Apr &&
                WFTData.May == HostFileData.May &&
                WFTData.Jun == HostFileData.Jun &&
                WFTData.Jul == HostFileData.Jul &&
                WFTData.Aug == HostFileData.Aug &&
                WFTData.Sep == HostFileData.Sep &&
                WFTData.Oct == HostFileData.Oct &&
                WFTData.Nov == HostFileData.Nov &&
                WFTData.Dec == HostFileData.Dec;
            return ismatched ? true : false;
        }

        public static bool VerifySumOfMonthValuesEqualTotalValue(MonthlyForcastView WFTData)
        {
            double ExpectedTotalValue;
            ExpectedTotalValue = WFTData.Jan +
                WFTData.Feb +
                WFTData.Mar +
                WFTData.Apr +
                WFTData.May +
                WFTData.Jun +
                WFTData.Jul +
                WFTData.Aug +
                WFTData.Sep +
                WFTData.Oct +
                WFTData.Nov +
                WFTData.Dec;
            Console.WriteLine($"Expected total value: {ExpectedTotalValue} \n" +
                $"Actual total = {WFTData.Total}");
            return (ExpectedTotalValue == WFTData.Total) ? true : false;
        }

        public static bool CompareDataObjects(MonthlyForcastView firstDataSet, MonthlyForcastView SecondDataSet)
        {
            CommonFunctions.AddTestStep("Verify data Comparison", "Data verified ");
            bool ismatched;
            ismatched =
                firstDataSet.Jan == SecondDataSet.Jan &&
                firstDataSet.Feb == SecondDataSet.Feb &&
                firstDataSet.Mar == SecondDataSet.Mar &&
                firstDataSet.Apr == SecondDataSet.Apr &&
                firstDataSet.May == SecondDataSet.May &&
                firstDataSet.Jun == SecondDataSet.Jun &&
                firstDataSet.Jul == SecondDataSet.Jul &&
                firstDataSet.Aug == SecondDataSet.Aug &&
                firstDataSet.Sep == SecondDataSet.Sep &&
                firstDataSet.Oct == SecondDataSet.Oct &&
                firstDataSet.Nov == SecondDataSet.Nov &&
                firstDataSet.Dec == SecondDataSet.Dec;
                //firstDataSet.Total == SecondDataSet.Total;

            if (firstDataSet.Jan != SecondDataSet.Jan)
                Console.WriteLine($"Jan value was different = {firstDataSet.Jan}   {SecondDataSet.Jan}");
            if (firstDataSet.Feb != SecondDataSet.Feb)
                Console.WriteLine($"Feb value was different = {firstDataSet.Feb}   {SecondDataSet.Feb}");
            if (firstDataSet.Mar != SecondDataSet.Mar)
                Console.WriteLine($"Mar value was different = {firstDataSet.Mar}   {SecondDataSet.Mar}");
            if (firstDataSet.Apr != SecondDataSet.Apr)
                Console.WriteLine($"Apr value was different = {firstDataSet.Apr}   {SecondDataSet.Apr}");
            if (firstDataSet.May != SecondDataSet.May)
                Console.WriteLine($"May value was different = {firstDataSet.May}   {SecondDataSet.May}");
            if (firstDataSet.Jun != SecondDataSet.Jun)
                Console.WriteLine($"Jun value was different = {firstDataSet.Jun}   {SecondDataSet.Jun}");
            if (firstDataSet.Jul != SecondDataSet.Jul)
                Console.WriteLine($"Jul value was different = {firstDataSet.Jul}   {SecondDataSet.Jul}");
            if (firstDataSet.Aug != SecondDataSet.Aug)
                Console.WriteLine($"Aug value was different = {firstDataSet.Aug}   {SecondDataSet.Aug}");
            if (firstDataSet.Sep != SecondDataSet.Sep)
                Console.WriteLine($"Sep value was different = {firstDataSet.Sep}   {SecondDataSet.Sep}");
            if (firstDataSet.Oct != SecondDataSet.Oct)
                Console.WriteLine($"Oct value was different = {firstDataSet.Oct}   {SecondDataSet.Oct}");
            if (firstDataSet.Nov != SecondDataSet.Nov)
                Console.WriteLine($"Nov value was different = {firstDataSet.Nov}   {SecondDataSet.Nov}");
            if (firstDataSet.Dec != SecondDataSet.Dec)
                Console.WriteLine($"Dec value was different = {firstDataSet.Dec}   {SecondDataSet.Dec}");
            if (firstDataSet.Total != SecondDataSet.Total)
                Console.WriteLine($"Total value was different = {firstDataSet.Total}   {SecondDataSet.Total}");
            return ismatched ? true : false;
        }

        public static bool CompareDataObjects(MonthlyForcastView firstDataSet, MonthlyForcastView SecondDataSet, string rowName)
        {
            bool ismatched;
            CommonFunctions.AddTestStep($"Compare data {rowName}", $"Compare data {rowName}");
            string TestCasesFile = @$"{RunData.NewPlanDataComprisonBaseFolder}\{RunData.ComparisonFile}.txt";

            using (StreamWriter writer = (File.Exists(TestCasesFile)) ? File.AppendText(TestCasesFile) : File.CreateText(TestCasesFile))
            {
                ismatched =
                    firstDataSet.Jan == SecondDataSet.Jan &&
                    firstDataSet.Feb == SecondDataSet.Feb &&
                    firstDataSet.Mar == SecondDataSet.Mar &&
                    firstDataSet.Apr == SecondDataSet.Apr &&
                    firstDataSet.May == SecondDataSet.May &&
                    firstDataSet.Jun == SecondDataSet.Jun &&
                    firstDataSet.Jul == SecondDataSet.Jul &&
                    firstDataSet.Aug == SecondDataSet.Aug &&
                    firstDataSet.Sep == SecondDataSet.Sep &&
                    firstDataSet.Oct == SecondDataSet.Oct &&
                    firstDataSet.Nov == SecondDataSet.Nov &&
                    firstDataSet.Dec == SecondDataSet.Dec &&
                    firstDataSet.Total == SecondDataSet.Total;

                if (firstDataSet.Jan != SecondDataSet.Jan)
                {
                    Console.WriteLine($"{rowName} Jan value was different = {firstDataSet.Jan}   {SecondDataSet.Jan}");
                    writer.WriteLine($"{rowName} Jan value was different = {firstDataSet.Jan}   {SecondDataSet.Jan}");
                }
                if (firstDataSet.Feb != SecondDataSet.Feb)
                {
                    Console.WriteLine($"{rowName} Feb value was different = {firstDataSet.Feb}   {SecondDataSet.Feb}");
                    writer.WriteLine($"{rowName} Feb value was different = {firstDataSet.Feb}   {SecondDataSet.Feb}");
                }
                if (firstDataSet.Mar != SecondDataSet.Mar)
                {
                    Console.WriteLine($"{rowName} Mar value was different = {firstDataSet.Mar}   {SecondDataSet.Mar}");
                    writer.WriteLine($"{rowName} Mar value was different = {firstDataSet.Mar}   {SecondDataSet.Mar}");
                }
                if (firstDataSet.Apr != SecondDataSet.Apr)
                {
                    Console.WriteLine($"{rowName} Apr value was different = {firstDataSet.Apr}   {SecondDataSet.Apr}");
                    writer.WriteLine($"{rowName} Apr value was different = {firstDataSet.Apr}   {SecondDataSet.Apr}");
                }
                if (firstDataSet.May != SecondDataSet.May)
                {
                    Console.WriteLine($"{rowName} May value was different = {firstDataSet.May}   {SecondDataSet.May}");
                    writer.WriteLine($"{rowName} May value was different = {firstDataSet.May}   {SecondDataSet.May}");
                }
                if (firstDataSet.Jun != SecondDataSet.Jun)
                {
                    Console.WriteLine($"{rowName} Jun value was different = {firstDataSet.Jun}   {SecondDataSet.Jun}");
                    writer.WriteLine($"{rowName} Jun value was different = {firstDataSet.Jun}   {SecondDataSet.Jun}");
                }
                if (firstDataSet.Jul != SecondDataSet.Jul)
                {
                    Console.WriteLine($"{rowName} Jul value was different = {firstDataSet.Jul}   {SecondDataSet.Jul}");
                    writer.WriteLine($"{rowName} Jul value was different = {firstDataSet.Jul}   {SecondDataSet.Jul}");
                }
                if (firstDataSet.Aug != SecondDataSet.Aug)
                {
                    Console.WriteLine($"{rowName} Aug value was different = {firstDataSet.Aug}   {SecondDataSet.Aug}");
                    writer.WriteLine($"{rowName} Aug value was different = {firstDataSet.Aug}   {SecondDataSet.Aug}");
                }
                if (firstDataSet.Sep != SecondDataSet.Sep)
                {
                    Console.WriteLine($"{rowName} Sep value was different = {firstDataSet.Sep}   {SecondDataSet.Sep}");
                    writer.WriteLine($"{rowName} Sep value was different = {firstDataSet.Sep}   {SecondDataSet.Sep}");
                }
                if (firstDataSet.Oct != SecondDataSet.Oct)
                {
                    Console.WriteLine($"{rowName} Oct value was different = {firstDataSet.Oct}   {SecondDataSet.Oct}");
                    writer.WriteLine($"{rowName} Oct value was different = {firstDataSet.Oct}   {SecondDataSet.Oct}");
                }
                if (firstDataSet.Nov != SecondDataSet.Nov)
                {
                    Console.WriteLine($"{rowName} Nov value was different = {firstDataSet.Nov}   {SecondDataSet.Nov}");
                    writer.WriteLine($"{rowName} Nov value was different = {firstDataSet.Nov}   {SecondDataSet.Nov}");
                }
                if (firstDataSet.Dec != SecondDataSet.Dec)
                {
                    Console.WriteLine($"{rowName} Dec value was different = {firstDataSet.Dec}   {SecondDataSet.Dec}");
                    writer.WriteLine($"{rowName} Dec value was different = {firstDataSet.Dec}   {SecondDataSet.Dec}");
                }
                if (firstDataSet.Total != SecondDataSet.Total)
                {
                    Console.WriteLine($"{rowName} Total value was different = {firstDataSet.Total}   {SecondDataSet.Total}");
                    writer.WriteLine($"{rowName} Total value was different = {firstDataSet.Total}   {SecondDataSet.Total}");
                }
                //return ismatched ? true : false;
                return true;
            }
        }

        public static bool CompareObjectValuesWithSingleData(MonthlyForcastView firstDataSet, double value)
        {
            
            bool ismatched;
            ismatched = firstDataSet.Jan == value &&
                firstDataSet.Feb == value &&
                firstDataSet.Mar == value &&
                firstDataSet.Apr == value &&
                firstDataSet.May == value &&
                firstDataSet.Jun == value &&
                firstDataSet.Jul == value &&
                firstDataSet.Aug == value &&
                firstDataSet.Sep == value &&
                firstDataSet.Oct == value &&
                firstDataSet.Nov == value &&
                firstDataSet.Dec == value;
            return ismatched ? true : false;
        }
        /// <summary>
        /// This function starts from March - Dec.
        /// </summary>
        /// <param name="firstDataSet"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool CompareMontlyValuesForSpecificMonth(MonthlyForcastView firstDataSet, double value)
        {
            CommonFunctions.AddTestStep("Compare row's values to the Mar value", "Data are compared");
            bool ismatched;
            ismatched = 
                firstDataSet.Mar == value &&
                firstDataSet.Apr == value &&
                firstDataSet.May == value &&
                firstDataSet.Jun == value &&
                firstDataSet.Jul == value &&
                firstDataSet.Aug == value &&
                firstDataSet.Sep == value &&
                firstDataSet.Oct == value &&
                firstDataSet.Nov == value &&
                firstDataSet.Dec == value;
            return ismatched ? true : false;
        }

        public static bool CompareEntireRowValues(MonthlyForcastView firstDataSet, double value)
        {
            bool ismatched;
            ismatched =
                firstDataSet.Mar == value &&
                firstDataSet.Apr == value &&
                firstDataSet.May == value &&
                firstDataSet.Jun == value &&
                firstDataSet.Jul == value &&
                firstDataSet.Aug == value &&
                firstDataSet.Sep == value &&
                firstDataSet.Oct == value &&
                firstDataSet.Nov == value &&
                firstDataSet.Dec == value &&
                firstDataSet.Total == value;
            return ismatched ? true : false;
        }

        public static bool VerifyMonthValuesEqualTotal(MonthlyForcastView firstDataSet)
        {
            double Sum;
            Sum =
                firstDataSet.Jan +
                firstDataSet.Feb +
                firstDataSet.Mar +
                firstDataSet.Apr +
                firstDataSet.May +
                firstDataSet.Jun +
                firstDataSet.Jul +
                firstDataSet.Aug +
                firstDataSet.Sep +
                firstDataSet.Oct +
                firstDataSet.Nov +
                firstDataSet.Dec;
            return (firstDataSet.Total == Sum) ? true : false;
        }

        public static bool CompareMontlyValuesForSpecificMonth(MonthElements firstDataSet, string value)
        {
            bool ismatched;
            ismatched =
                CommonFunctions.ToDouble(firstDataSet.Mar.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.Apr.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.May.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.Jun.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.Jul.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.Aug.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.Sep.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.Oct.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.Nov.GetAttribute("value")) == CommonFunctions.ToDouble(value) &&
                CommonFunctions.ToDouble(firstDataSet.Dec.GetAttribute("value")) == CommonFunctions.ToDouble(value);
            return ismatched ? true : false;
        }

        public static MonthlyForcastView GetAverageOfTwoDataObjects(MonthlyForcastView firstDataSet, MonthlyForcastView SecondDataSet)
        {
            MonthlyForcastView monthlyForcastView = new MonthlyForcastView();
            monthlyForcastView.Jan = Math.Round((firstDataSet.Jan + SecondDataSet.Jan)/2, 2) ;
            monthlyForcastView.Feb = Math.Round((firstDataSet.Feb + SecondDataSet.Feb)/ 2, 2);
            monthlyForcastView.Mar = Math.Round((firstDataSet.Mar + SecondDataSet.Mar)/ 2, 2);
            monthlyForcastView.Apr = Math.Round((firstDataSet.Apr + SecondDataSet.Apr)/ 2, 2);
            monthlyForcastView.May = Math.Round((firstDataSet.May + SecondDataSet.May)/ 2, 2);
            monthlyForcastView.Jun = Math.Round((firstDataSet.Jun + SecondDataSet.Jun)/ 2, 2);
            monthlyForcastView.Jul = Math.Round((firstDataSet.Jul + SecondDataSet.Jul)/ 2, 2);
            monthlyForcastView.Aug = Math.Round((firstDataSet.Aug + SecondDataSet.Aug)/ 2, 2);
            monthlyForcastView.Sep = Math.Round((firstDataSet.Sep + SecondDataSet.Sep)/ 2, 2);
            monthlyForcastView.Oct = Math.Round((firstDataSet.Oct + SecondDataSet.Oct)/ 2, 2);
            monthlyForcastView.Nov = Math.Round((firstDataSet.Nov + SecondDataSet.Nov)/ 2, 2);
            monthlyForcastView.Dec = Math.Round((firstDataSet.Dec + SecondDataSet.Dec)/ 2, 2);
            monthlyForcastView.Total = Math.Round((firstDataSet.Total + SecondDataSet.Total)/ 2, 2);
            return monthlyForcastView;
        }
        public static MonthlyForcastView GetSumOfTwoDataObjects(MonthlyForcastView firstDataSet, MonthlyForcastView SecondDataSet)
        {
            MonthlyForcastView monthlyForcastView = new MonthlyForcastView();
            monthlyForcastView.Jan = firstDataSet.Jan + SecondDataSet.Jan;
            monthlyForcastView.Feb = firstDataSet.Feb + SecondDataSet.Feb;
            monthlyForcastView.Mar = firstDataSet.Mar + SecondDataSet.Mar;
            monthlyForcastView.Apr = firstDataSet.Apr + SecondDataSet.Apr;
            monthlyForcastView.May = firstDataSet.May + SecondDataSet.May;
            monthlyForcastView.Jun = firstDataSet.Jun + SecondDataSet.Jun;
            monthlyForcastView.Jul = firstDataSet.Jul + SecondDataSet.Jul;
            monthlyForcastView.Aug = firstDataSet.Aug + SecondDataSet.Aug;
            monthlyForcastView.Sep = firstDataSet.Sep + SecondDataSet.Sep;
            monthlyForcastView.Oct = firstDataSet.Oct + SecondDataSet.Oct;
            monthlyForcastView.Nov = firstDataSet.Nov + SecondDataSet.Nov;
            monthlyForcastView.Dec = firstDataSet.Dec + SecondDataSet.Dec;
            monthlyForcastView.Total = firstDataSet.Total + SecondDataSet.Total;
            return monthlyForcastView;
        }

        public static bool CompareColorInTwoObjects(MonthElements FirstList, MonthElements SecondList)
        {
            
            bool ismatched;
            ismatched = FirstList.Jan.GetCssValue("background-color") == SecondList.Jan.GetCssValue("background-color") &&
                FirstList.Feb.GetCssValue("background-color") == SecondList.Feb.GetCssValue("background-color") &&
                FirstList.Mar.GetCssValue("background-color") == SecondList.Mar.GetCssValue("background-color") &&
                FirstList.Apr.GetCssValue("background-color") == SecondList.Apr.GetCssValue("background-color") &&
                FirstList.May.GetCssValue("background-color") == SecondList.May.GetCssValue("background-color") &&
                FirstList.Jun.GetCssValue("background-color") == SecondList.Jun.GetCssValue("background-color") &&
                FirstList.Jul.GetCssValue("background-color") == SecondList.Jul.GetCssValue("background-color") &&
                FirstList.Aug.GetCssValue("background-color") == SecondList.Aug.GetCssValue("background-color") &&
                FirstList.Sep.GetCssValue("background-color") == SecondList.Sep.GetCssValue("background-color") &&
                FirstList.Oct.GetCssValue("background-color") == SecondList.Oct.GetCssValue("background-color") &&
                FirstList.Nov.GetCssValue("background-color") == SecondList.Nov.GetCssValue("background-color") &&
                FirstList.Dec.GetCssValue("background-color") == SecondList.Dec.GetCssValue("background-color");
            return ismatched ? true : false;
        }

        public static void GetColorInTwoObjects(MonthElements FirstList, MonthElements SecondList)
        {
            CommonFunctions.WaitUntilPageIsAcive();
            Console.WriteLine(" ******* First **************");
            Console.WriteLine(FirstList.Jan.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Feb.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Mar.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Apr.GetCssValue("background-color"));
            Console.WriteLine(FirstList.May.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Jun.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Jul.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Aug.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Sep.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Oct.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Nov.GetCssValue("background-color"));
            Console.WriteLine(FirstList.Dec.GetCssValue("background-color"));

            Console.WriteLine(" ******* Second **************");
            Console.WriteLine(SecondList.Jan.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Feb.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Mar.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Apr.GetCssValue("background-color"));
            Console.WriteLine(SecondList.May.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Jun.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Jul.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Aug.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Sep.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Oct.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Nov.GetCssValue("background-color"));
            Console.WriteLine(SecondList.Dec.GetCssValue("background-color"));


            
        }

        public static double getMonthValueFromMonthlyObject(MonthlyForcastView Data, string month)
        {
            double result;
            Dictionary<string, double> dicMonth = new Dictionary<string, double>();
            dicMonth.Add("January", Data.Jan);
            dicMonth.Add("February", Data.Feb);
            dicMonth.Add("March", Data.Mar);
            dicMonth.Add("April", Data.Apr);
            dicMonth.Add("May", Data.May);
            dicMonth.Add("June", Data.Jun);
            dicMonth.Add("July", Data.Jul);
            dicMonth.Add("August", Data.Aug);
            dicMonth.Add("September", Data.Sep);
            dicMonth.Add("October", Data.Oct);
            dicMonth.Add("November", Data.Nov);
            dicMonth.Add("December", Data.Dec);
            dicMonth.TryGetValue(month, out result);
            return result;
        }

        public static bool IsItemFoundinDropdownMenu(string ElementXpath, string searchedItem)
        {
            string optionValue;
            IList<IWebElement> lstElements = getElements(By.XPath(ElementXpath));
            foreach(var element in lstElements)
            {
                optionValue = element.Text;
                if(optionValue.Contains(searchedItem))
                {
                    return true;
                }
            }
            return false;
        }

        public static bool SearchItemByValue(string ElementXpath, string searchedItem)
        {
            string optionValue;
            IList<IWebElement> lstElements = getElements(By.XPath(ElementXpath));
            foreach (var element in lstElements)
            {
                optionValue = element.GetAttribute("value");
                if (optionValue.Contains(searchedItem))
                {
                    return true;
                }
            }
            return false;

        }


        public static void SetCheckbox(IWebElement element, bool toggle)
        {
            bool isChecked;
            switch (toggle)
            {
                case true: // check
                    isChecked = element.Selected;
                    if (!isChecked)
                    {
                        ClickByJE(element);
                    }
                    break;
                case false: //uncheck
                    isChecked = element.Selected;
                    if (isChecked)
                    {
                        ClickByJE(element);
                    }
                    break;
            }
        } 

        public static void WaitUntilPageIsAcive()
        {
            DateTime _desired = DateTime.Now.AddSeconds(900);
            while (DateTime.Now < _desired)
            {
                try
                {
                    //*/div[@class='blockUI blockOverlay']
                    IWebElement block = Driver.Instance.FindElement(By.XPath("//*/div[@class='blockUI']"));
                    IWebElement lblWorking = Driver.Instance.FindElement(By.XPath("//*/div[@class='blockUI blockMsg blockPage']"));                    
                }
                catch
                {
                    try
                    {                        
                        IWebElement block = Driver.Instance.FindElement(By.XPath("//*/div[@class='blockUI blockOverlay']"));
                    }
                    catch
                    {
                        try
                        {
                            IWebElement ApplicationInit = Driver.Instance.FindElement(By.XPath("//*/body/center[contains(text(),'initializing')]"));

                        }
                        catch
                        {
                            break;
                        }
                    }                   
                }               
            }
        }

        public static void WaitUntilPageIsAcive2()
        {
            //Thread.Sleep(3000);
            DateTime _desired = DateTime.Now.AddSeconds(900);
            while (DateTime.Now < _desired)
            {
                try
                {
                    //*/div[@class='blockUI blockOverlay']
                    IWebElement block = getElement(By.XPath("//*/div[@class='blockUI']"));
                    IWebElement lblWorking = getElement(By.XPath("//*/div[@class='blockUI blockMsg blockPage']"));
                }
                catch
                {
                    try
                    {
                        IWebElement block = getElement(By.XPath("//*/div[@class='blockUI blockOverlay']"));
                    }
                    catch
                    {
                        break;
                    }
                }

            }
        }

        public static void WaitSaveToastMsgDisappeared()
        {
            Thread.Sleep(3000);
            DateTime _desired = DateTime.Now.AddSeconds(20);
            while (DateTime.Now < _desired)
            {
                try
                {
                    IWebElement block = getElement(By.XPath("//div[@class='ui-pnotify-title']"));
                }
                catch
                {
                    break;
                }
            }
        }

        public static void WaitTillPageIsComplete()
        {
            Thread.Sleep(2000);
            new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10)).Until(
            d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));
        }
        //public static void TakeScreenshotwithScroll(string tcDescription, Exception exception = null)
        //{
        //    var basePath = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;
        //    var filePath = $@"\\aastsun6vfsweb1\Software\QA\Automation\Rekha\Screenshot\{tcDescription}.jpeg";
        //    VerticalCombineDecorator vcd = new VerticalCombineDecorator(new ScreenshotMaker());
        //    var value = Driver.Instance.TakeScreenshot(vcd).ToMagickImage().ToBitmap().Save(filePath, ImageFormat.Jpeg);

        //    // Creating an HTML file with image and necessary text including link.
        //    var html = $@"<html>
        //        <body>
        //        <p>{tcDescription}</p>" +

        //        (exception != null ?
        //        $@"<p>Exception: {exception.Message}</p>
        //        <p>StackTrace: {exception.StackTrace}</p>" : "") +

        //        $@"<p>{Driver.Instance.Url}</p>
        //        <img src=""{filePath}""/>
        //        <body>
        //        </html>";

        //    File.WriteAllText(filePath.Replace(".jpeg", ".html"), html);
        //}


        public static void DeleteCelll(string cellID)
        {
            // emailField.sendKeys(Keys.BACKSPACE);
        }

        //public static void SetEmailToUser(string userLogin)
        //{
        //    string staffQuery, staffUpdateQuery, userQuery, userUpdateQuery;
        //    string staffID, userID;
        //    staffQuery = $"SELECT sl.fsStaffID FROM dbo.fsStaffLogin sl WHERE sl.UserName = '{userLogin}'";
        //    staffID = GetQueryResult(staffQuery);
        //    Console.WriteLine($"staffID = {staffID}");
        //    staffUpdateQuery = $"UPDATE dbo.fsStaff SET Email = 'm@m.com' WHERE fsStaffID = {staffID} ";
        //    RunQuery(staffUpdateQuery);

        //    userQuery = $"SELECT sl.fsUserID FROM dbo.fsUserLogin sl WHERE sl.UserName = '{userLogin}'";
        //    userID = GetQueryResult(userQuery);
        //    Console.WriteLine($"userID = {userID}");
        //    userUpdateQuery = $"UPDATE dbo.fsUser SET Email = 'm@m.com' WHERE fsUserID = {userID} ";
        //    RunQuery(userUpdateQuery);


        //}

        //public static string GetQueryResult(string query)
        //{
        //    string DB = FacilityShift.GetDBName();
        //    string sDataSource = FacilityShift.getSource();
        //    Console.WriteLine($"DB = {DB}");
        //    try
        //    {


        //        string connString = $"Data Source={sDataSource};Initial Catalog={DB};Integrated Security=SSPI;";
        //        using (SqlConnection conn = new SqlConnection(connString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand(query, conn);
        //            string result = cmd.ExecuteScalar().ToString();
        //            conn.Close();
        //            return result;
        //        }
        //    }
        //    catch
        //    {
        //        string connString = $"Data Source=XRDCWQDBSAAS02.hcaqa.corpadqa.net;Initial Catalog={DB};Integrated Security=SSPI;";
        //        using (SqlConnection conn = new SqlConnection(connString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand(query, conn);
        //            string result = cmd.ExecuteScalar().ToString();
        //            conn.Close();
        //            return result;
        //        }

        //    }
        //}
        public static string GetQueryResult(string query)
        {
            string DB = RunData.DatabaseName.Trim();
            string sServerName = RunData.ServerName.Trim();
            try
            {
                string connString = $"Data Source={sServerName}; Initial Catalog={DB}; Integrated Security=SSPI;";
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    string result = cmd.ExecuteScalar().ToString();
                    conn.Close();
                    return result;
                }
            }
            catch 
            {
                throw;
              
            }
        }

        public static void RunQuery(string query)
        {
            try
            {
                string DB = RunData.DatabaseName;
                string sServerName = RunData.ServerName;
                string connString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch
            {
               
            }
        }

        public static void UnblockDB()
        {
            // Find blocked processes
            string query = @"
                SELECT blocking_session_id, session_id
                FROM sys.dm_exec_requests
                WHERE blocking_session_id <> 0";
            string DB = RunData.DatabaseName;
            string sServerName = RunData.ServerName;
            string connString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";

            using (SqlConnection conn = new SqlConnection(connString))
            {

                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int blockingSession = reader.GetInt32(0);
                            int blockedSession = reader.GetInt32(1);

                            Console.WriteLine($"Blocking Session: {blockingSession}, Blocked Session: {blockedSession}");

                            // Kill the blocking session
                            using (SqlCommand killCmd = new SqlCommand($"KILL {blockingSession}", conn))
                            {
                                killCmd.ExecuteNonQuery();
                                Console.WriteLine($"Killed session: {blockingSession}");
                            }
                        }
                    }
                }
                conn.Close();
            }
        }

        public static void RunQuery(string query, string DB)
        {
            try
            {
                string sServerName = RunData.ServerName;
                string connString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch
            {
                Console.WriteLine("ex");
            }
        }

        public static MonthlyForcastView FetchDataQuery(string query, string DB, string ID)
        {
            try
            {
                
                List<decimal> lstDecimal = new List<decimal>(); 
                string sServerName = RunData.ServerName;
                string connString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lstDecimal.Add(reader.GetDecimal(1));
                        }

                    }                    
                    conn.Close();

                    List<double> lstMonthly = lstDecimal.Select(d => (double)d).ToList();
                    MonthlyForcastView monthlyValue = new MonthlyForcastView()
                    {
                        Jan = lstMonthly[0],
                        Feb = lstMonthly[1],
                        Mar = lstMonthly[2],
                        Apr = lstMonthly[3],
                        May = lstMonthly[4],
                        Jun = lstMonthly[5],
                        Jul = lstMonthly[6],
                        Aug = lstMonthly[7],
                        Sep = lstMonthly[8],
                        Oct = lstMonthly[9],
                        Nov = lstMonthly[10],
                        Dec = lstMonthly[11],
                    };
                    return monthlyValue;
                }               
            }
            catch
            {
                Console.WriteLine("ex");
            }
            return null;
        }

       
        ///// <summary>
        ///// Run SQL query with DB name and query string 
        ///// </summary>
        ///// <param name="DataBaseName">DataBaseName</param>
        ///// <param name="query">query</param>
        //public static void ExcuteQuery(string query)
        //{
        //    string DB = FacilityShift.GetDBName();
        //    string sDataSource = FacilityShift.getSource();
        //    try
        //    {
        //        string connString = $"Data Source={sDataSource};Initial Catalog={DB};Integrated Security=SSPI;";
        //        using (SqlConnection conn = new SqlConnection(connString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand(query, conn);
        //            cmd.ExecuteNonQuery();
        //            conn.Close();
        //            // return result;
        //        }
        //    }
        //    catch
        //    {
        //        string connString = $"Data Source=XRDCWQDBSAAS02.hcaqa.corpadqa.net;Initial Catalog={DB};Integrated Security=SSPI;";
        //        using (SqlConnection conn = new SqlConnection(connString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand(query, conn);
        //            cmd.ExecuteNonQuery();
        //            conn.Close();
        //            // return result;
        //        }
        //    }
        //}

        //public static void RunSQLAgentJob(string DataBaseName, string jobName)
        //{
        //    string DB = FacilityShift.GetDBName();
        //    string sDataSource = FacilityShift.getSource();
        //    string connString = $"Data Source={sDataSource};Initial Catalog={DB};Integrated Security=SSPI;";
        //    using (SqlConnection conn = new SqlConnection(connString))
        //    {
        //        conn.Open();
        //        SqlCommand cmd = new SqlCommand("msdb.dbo.sp_start_job", conn);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@SchedulePhaseAutomation", $"{jobName}");
        //        cmd.ExecuteNonQuery();
        //        conn.Close();
        //    }
        //}

        public static string GenerateFSPasswordHash(string userName, string password)
        {
            userName = userName.Trim();
            return Convert.ToBase64String(new SHA384Managed()
                .ComputeHash(new UnicodeEncoding()
                    .GetBytes($"{password}.{userName}")));
        }

        public static string ToTitleCase(string str)
        {
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower());
        }

        public static string FirstCharToUpper(string input)
        {
            if (String.IsNullOrEmpty(input))
                throw new ArgumentException("Bad string!");
            return (System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(input.ToLower()).Trim().Replace(" ", string.Empty));
        }
        public static string FirstCharToUpperWithoutSpacing(string input)
        {
            if (String.IsNullOrEmpty(input))
                throw new ArgumentException("Bad string!");
            return (System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(input.ToLower()).Trim());
        }

        public static string FirstCharToLower(string input)
        {
            if (String.IsNullOrEmpty(input))
                throw new ArgumentException("Bad string!");
            string Prop = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(input).Trim().Replace(" ", string.Empty);
            return Prop.First().ToString().ToLower() + Prop.Substring(1);
        }

        public static string AddDaysToDate(string StartDate, int NumOfDays)
        {
            DateTime sDate = DateTime.Parse(StartDate).AddDays(NumOfDays);
            //Convert time to am/pm
            string Date = sDate.ToString("M/d/yyyy");
            return Date;
        }

        

        public static string AddDaysToDateWithDBFormat(string StartDate, int NumOfDays)
        {
            DateTime sDate = DateTime.Parse(StartDate).AddDays(NumOfDays);
            //Convert time to am/pm
            string Date = sDate.ToString("yyyy-MM-dd 00:00:00");
            return Date;
        }

        public static string DBLongFormat(string StartDate)
        {
            DateTime sDate = DateTime.Parse(StartDate);
            //Convert time to am/pm
            string Date = sDate.ToString("yyyy-MM-dd 00:00:00");
            return Date;
        }
        public static string AddDaysToDateAndReturnDayAndMonthOnly(string StartDate, int NumOfDays)
        {
            DateTime sDate = DateTime.Parse(StartDate).AddDays(NumOfDays);
            //Convert time to am/pm
            string Date = sDate.ToString("M/dd");
            return Date;
        }

        public static void CloseTextMsg()
        {
            string TxtMsgNotificationXpath = " //*/div[@class='k-widget k-window k-dialog user-notification']//button[contains(text(),'Don’t Show')]";
            string xpath = "//*/div[@class='toast toast-info']//button[@class='toast-close-button']";
            bool bExist = IsElementDisplayed(xpath, 1);
            if (bExist)
            {
                IWebElement cmdClose = getElement(By.XPath(xpath));
                CommonFunctions.ClickByJE(cmdClose);
                Thread.Sleep(1000);
            }
            bExist = CommonFunctions.IsElementDisplayed(TxtMsgNotificationXpath, 1);
            if (bExist)
            {
                IWebElement cmdDontShow = getElement(By.XPath(TxtMsgNotificationXpath));
                CommonFunctions.ClickByJE(cmdDontShow);
                Thread.Sleep(1000);
            }
        }
        public static void selectShiftDataCode(IWebElement dropdown, string shiftCode)
        {

            Thread.Sleep(1000);
            //Focus(dropdown);
            string xpath = $"option[@data-code='{shiftCode}']";
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            CommonFunctions.ClickByJE(dropdown);
            Thread.Sleep(1000);
            IWebElement option = dropdown.FindElement(By.XPath(xpath));
            CommonFunctions.ClickByJE(option);
            Thread.Sleep(1000);
        }

        public static void ClickBackButton()
        {
            Driver.Instance.Navigate().Back();
        }
        public static bool IsElementPresent(By by)
        {
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
                wait.Until(drv => drv.FindElement(by).Size.Height != 0);
                return true;
                //IWebElement ele = getElement(by);
                //bool stat = ele.Displayed;
                //return stat;
            }
            catch (NoSuchElementException e)
            {
                Console.Write(e.ToString());
                return false;
            }
        }
        public static void WaitForElementToStopLoading(IWebDriver driver, By element, int seconds = 40)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));
            if (IsElementPresent(element))
                wait.Until(x => !x.FindElement(element).Displayed);
        }
        public static void WaitForItemToStopLoading(IWebDriver driver, string element, int seconds = 40)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));
            By item = By.Id(element);
            if (IsElementPresent(item))
                wait.Until(x => !x.FindElement(item).Displayed);
        }
        public static string GetFirstDate(string period)
        {
            DateTime firstDate = DateTime.Today.AddDays(65);
            return firstDate.ToString("MM/dd/yyyy");
        }
        public static string GetFirstDate()
        {
            string Date;
            DateTime firstDate = DateTime.Today.AddDays(60);
            Date = firstDate.ToString("MM/dd/yyyy").Split('/').GetValue(0).ToString();
            return Date;
        }

        public static string GetTodaysDate()
        {
            string Date;
            DateTime firstDate = DateTime.Today;
            Date = firstDate.ToString("M/d/yyyy").ToString();
            return Date;
        }
        public static string FormatDateToMDYYYY()
        {
            string Date;
            DateTime firstDate = DateTime.Today;
            Date = firstDate.ToString("Mdyyyy").ToString();
            return Date;
        }
        public static string GetDateForEffectiveDate()
        {
            string Date;
            DateTime firstDate = DateTime.Today.AddYears(1);
            Date = firstDate.ToString("MM/dd/yyyy").Split('/').GetValue(2).ToString();
            return Date;
        }

        public static string AddDaysandTimetoCurrentDate(int days, int hours)
        {
            string startTime = "12:00 AM";
            DateTime duration = DateTime.Parse(startTime).AddDays(days).AddHours(hours);
            string displayTime = duration.ToString("MM/dd/yyyy hh:mm tt");
            Console.WriteLine(displayTime.ToString());
            return (displayTime);
        }
        public static string GetDateForEffectiveDateMnths()
        {
            string Date;
            DateTime firstDate = DateTime.Today.AddMonths(6);
            Date = firstDate.ToString("MM/dd/yyyy").Split('/').GetValue(2).ToString();
            return Date;
        }

        public static string GetNextYear()
        {
            DateTime dt = DateTime.Now;
            var nextyearDate = dt.AddYears(1);
            string year = nextyearDate.Year.ToString();
            return year;    
        }

        public static string GetPreviousYear(int lookbackYears)
        {
            DateTime dt = DateTime.Now;
            var nextyearDate = dt.AddYears((-1) *lookbackYears);
            string year = nextyearDate.Year.ToString();
            return year;
        }

        public static string GetNextMonth()
        {
            DateTime dt = DateTime.Now;
            var nextyearDate = dt.AddMonths(1);
            string month = nextyearDate.Month.ToString();
            return month;
        }

        public static string GetCurrentYear()
        {
            DateTime dt = DateTime.Now;
            string year = dt.Year.ToString();
            return year;
        }

        public static string GetDateWithFormateMddyyyy()
        {
            string Date;
            DateTime firstDate = DateTime.Today.AddDays(60);
            Date = firstDate.ToString("MM/dd/yyyy");
            return Date;
        }

        public static string GetTodaysDateWithFormateMddyyyy()
        {
            string Date;
            DateTime firstDate = DateTime.Now;
            Date = firstDate.ToString("MM/dd/yyyy");
            return Date;
        }

        public static bool ThisItemContainsThisText(By bythisItem, string thisText)
        {
            var element = getElements(bythisItem);
            if (element.Count > 0)
                return element[0].Text.Contains(thisText);
            return false;
        }
        public static bool ItemContainsThisText(IList<IWebElement> item, string thisText)
        {
            Thread.Sleep(1000);
            try
            {

                if (item.Count > 0)
                    return item[0].Text.Contains(thisText);
                return false;
            }
            catch (WebDriverException)
            {
                return false;
            }
        }
        public static bool ThisItemContainsThisValueText(IWebElement scheduleCell, string thisText)
        {
            try
            {
                string cellValue = scheduleCell.GetAttribute("value");
                var r = ((cellValue != null) && cellValue.Contains(thisText));
                return r;
            }
            catch (WebDriverException)
            {
                return false;
            }
        }
        public static DateTime FirstDateOfSchedule(string schedulePeriod)
        {
            string startPeriod = schedulePeriod.Substring(0, schedulePeriod.IndexOf("-") - 1);
            DateTime firstDate = DateTime.ParseExact(startPeriod, "MMM dd, yyyy",
                       System.Globalization.CultureInfo.InvariantCulture);
            return firstDate;
        }
        public static DateTime EndDateOfSchedule(string schedulePeriod)
        {
            string endPeriod = schedulePeriod.Substring(schedulePeriod.IndexOf("-") + 2, schedulePeriod.Length - (schedulePeriod.IndexOf("-") + 2));
            DateTime endDate = DateTime.ParseExact(endPeriod, "MMM dd, yyyy",
                       System.Globalization.CultureInfo.InvariantCulture);
            return endDate;
        }
        public static int GetSchedulePrintRowCount(IList<IWebElement> table)
        {
            string listofUsers = String.Empty;
            foreach (IWebElement row in table)
            {
                listofUsers = row.Text.ToString();
            }
            string[] lines = listofUsers.Split('\r');
            int count = lines.Length;
            return count;
        }
        public static string[] AddTableWebElementsToArray(IList<IWebElement> table)
        {
            int numberOfRows = table.Count;
            string[] listofUsers = new string[numberOfRows];
            int i = 0;
            foreach (IWebElement row in table)
            {
                listofUsers[i] = row.Text;
                i++;
            }
            return listofUsers;
        }
        /// <summary>
        /// Determines if string array is sorted from A -> Z
        /// </summary>
        public static bool IsSorted(string[] arr)
        {
            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i - 1].CompareTo(arr[i]) > 0) // If previous is bigger, return false
                {
                    return false;
                }
            }
            return true;
        }
        public static string[] AddRowWebElementsToArray(IList<IWebElement> row)
        {
            int i = 0;
            string[] listofElements = new string[row.Count];
            foreach (IWebElement cell in row)
            {
                if (string.IsNullOrEmpty(cell.Text.ToString()))
                {
                    listofElements[i] = "";
                }
                else
                    listofElements[i] = cell.Text;
                i++;
            }
            return listofElements;
        }
        //public void WaitForJQuery(double maxJQuerywaitTime)
        //{
        //    WebDriverWait waitForjQuery = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(maxJQuerywaitTime));
        //    waitForjQuery.Until(driver2 => ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("return jQuery.active==0"));
        //    waitForjQuery.Until(driver2 => ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("return typeof jQuery != 'undefined'"));
        //    waitForjQuery.Until(driver2 => ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("return document.readyState").Equals("complete"));
        //}
        /// <summary>
        /// Get page title
        /// </summary>
        /// <returns>Page title</returns>
        public static string GetPageTitle()
        {
            string title = null;
            // assume assigned elsewhere
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            title = (string)js.ExecuteScript("return document.title");
            return (title);
        }
        /// <summary>
        /// Set text in a textbox 
        /// </summary>
        /// <param name="textbox">Textbox object</param>
        /// <param name="value">value to input</param>
        /// <returns>True if the value is set correctly; otherwise, flase</returns>
        public static void EnterText(IWebElement textbox, string txtValue)
        {
            Focus(textbox);
            try
            {
                textbox.Click();
                textbox.SendKeys(txtValue);
            }
            catch
            {
                textbox.SendKeys(txtValue);
            }
        }
        public static void EnterTextBy(By textbox1, string txtValue)
        {
            //Focus(textbox1);
            try
            {
                IWebElement textbox = getElement((textbox1));
                textbox.Click();
                textbox.SendKeys(txtValue);
            }
            catch
            {
                IWebElement textbox = getElement((textbox1));
                textbox.SendKeys(txtValue);
            }
        }
        /// <summary>
        /// Click objects
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public static void Click(IWebElement element)
        {
            Focus(element);
            element.Click();
        }
        public static void ClickBy(By element)
        {
            try
            {
                IWebElement ele = getElement(element);
                ele.Click();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
        public static void SelectItemFromDropdownMenu(IWebElement dropdown, string value)
        {
            try
            {
                //Focus(dropdown);
                //Thread.Sleep(4000);
                IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
                CommonFunctions.ClickByJE(dropdown, js);
                //Thread.Sleep(1000);
                string xpath = $"option[contains(text(),'{value.Trim()}')]";
                var option = dropdown.FindElements(By.XPath(xpath));
                option.FirstOrDefault().Click();
                WaitTillPageIsComplete();
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

       

        public static void SelectOptionValue(IWebElement dropdown, string value)
        {
            string xpath = $"option[@value='{value.Trim()}']";
            Thread.Sleep(1000);
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            CommonFunctions.ClickByJE(dropdown, js);
            Thread.Sleep(2000);
            IWebElement option = dropdown.FindElement(By.XPath(xpath));
            option.Click();
            Thread.Sleep(2000);

        }

        /*public static void SelectOptionValueBy(By dropdown, string value)
        {
            string xpath = $"option[@value='{value}']";
            IWebElement ele = getElement(By.XPath(xpath));

            Thread.Sleep(4000);
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            CommonFunctions.ClickByJE(dropdown, js);
            Thread.Sleep(2000);
            IWebElement option = dropdown.FindElement(By.XPath(xpath));
            option.Click();
            Thread.Sleep(2000);

        }*/

        //ds
        public static void DSSelectItemFromDropdownMenu(IWebElement Element, string item)
        {

            CommonFunctions.ClickByJE(Element);
            Thread.Sleep(1000);
            string itemXpath = $"//*/ul[@aria-hidden='false']//li[contains(text(),'{item}')]";
            IWebElement itemDepartment = getElement(By.XPath(itemXpath));
            CommonFunctions.ClickByJE(itemDepartment);
            Thread.Sleep(1000);
        }

        public static void DSSelectIndexFromDropdownMenu(IWebElement Element, string index)
        {

            CommonFunctions.ClickByJE(Element);
            Thread.Sleep(2000);
            string itemXpath = $"//*/ul[@aria-hidden='false']//li[{index}]";
            IWebElement itemDepartment = getElement(By.XPath(itemXpath));
            CommonFunctions.ClickByJE(itemDepartment);
            Thread.Sleep(1000);
        }

      
        public static void SelectItemFromDropdownMenuByIndex(IWebElement dropdown, int index)
        {
            // string xpath = $"//descendant::option[{index}]";
            string xpath = $"option[{index}]";
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            CommonFunctions.ClickByJE(dropdown, js);
            Click(dropdown);
            IWebElement option = dropdown.FindElement(By.XPath(xpath));
            option.Click();
            Thread.Sleep(4000);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xpath">the element xpath</param>
        /// <param name="waitTime"> wait time is in seconds</param>
        /// <returns></returns>
        public static bool IsElementDisplayed(string xpath, int waitTime)
        {
            Thread.Sleep(5000);
            double dWait = waitTime;
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(dWait));
                wait.Until(drv => drv.FindElement(By.XPath(xpath)).Size.Height != 0);
                return true;
            }
            catch
            {
                return false;
            }

        }

        public static bool IsElementDisplayed(By Eelement, int waitTime)
        {
            double dWait = waitTime;
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(dWait));
                wait.Until(drv => drv.FindElement(Eelement).Size.Height != 0);
                return true;
            }
            catch
            {
                return false;
            }

        }
        public static bool IsNotDispalyed(string xpath, int waitTime)
        {
            double dWait = waitTime;
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
                wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath(xpath)));

                //var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(waitTime));
                //wait.Until(driver => !driver.FindElement(By.XPath(xpath)).Displayed);
                return true;
            }
            catch
            {
                return false;
            }

        }

        public static bool IsElementVisible(By Eelement, int waitTime)
        {
            double dWait = waitTime;
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(dWait));
                wait.Until(drv => drv.FindElement(Eelement).Size.Height != 0);
                return true;
            }
            catch
            {
                return false;
            }

        }
        public static bool IsNotVisible(string xpath, int waitTime)
        {
            double dWait = waitTime;
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
                wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath(xpath)));

                //var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(waitTime));
                //wait.Until(driver => !driver.FindElement(By.XPath(xpath)).Displayed);
                return true;
            }
            catch
            {
                return false;
            }

        }
        public static bool IsNotDispalyed(By element, int waitTime)
        {
            double dWait = waitTime;
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(waitTime));
                wait.Until(ExpectedConditions.InvisibilityOfElementLocated(element));
                return true;
            }
            catch
            {
                return false;
            }

        }
        /// <summary>
        /// retrun yyyy-MM-dd date
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static string ConvertDateToScheduleDate(string date)

        {
            DateTime duration = DateTime.Parse(date);
            string formatedDuration = duration.ToString("yyyy-MM-dd");
            return formatedDuration;

        }

        public static string ConverDateToFormatTo_MdYYYY(string date)
        {
            DateTime duration = DateTime.Parse(date);
            string formatedDuration = duration.ToString("M/d/yyyy");
            return formatedDuration;
        }

        public static string ConverDateToFormatTo_MMddYYYY(string date)
        {
            DateTime duration = DateTime.Parse(date);
            string formatedDuration = duration.ToString("MM/dd/yyyy");
            return formatedDuration;
        }


        public static List<string> GetUniqueShiftsFromTwoLists(List<string> FirstDeptShifts, List<string> SecondDeptShifts)
        {
            List<string> UniqueShifts = FirstDeptShifts.Except(SecondDeptShifts).ToList();
            return UniqueShifts;
        }

        public static bool IsTitleTextPresent(string Text)
        {
            string TitleText = Driver.Instance.Title.ToString();
            if (string.Equals(Text, TitleText, StringComparison.CurrentCultureIgnoreCase))
            {
                return true;
            }
            return true;
        }


        public static bool IsNewWindowTextPresent(string Text, string xpath)
        {
            IWebElement NewWindow = getElement(By.XPath(xpath));
            string windowText = NewWindow.Text;
            if (string.Equals(Text, windowText, StringComparison.CurrentCultureIgnoreCase))
            {
                return true;
            }
            return true;
        }

        public static bool IsElementClickable(string xpath, int waitTime)
        {
            double dWait = waitTime;
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(dWait));
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(By.XPath(xpath)));


                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool selectSpecificShift(string shift)
        {
            try
            {
                string shifstXpath = $"//*/div[@id='scheduleContainer']//table//tbody[contains(@style,'display:')]//tr//td/input[contains(@data-assignvalue,'{shift.ToUpper()}')]";
                IList<IWebElement> lsShifts = getElements(By.XPath(shifstXpath));
                Click(lsShifts[0]);
                return true;
            }
            catch
            {
                return false;

            }
        }
        public static bool CloseAlert()
        {
            try
            {
                Thread.Sleep(2000);
                Driver.Instance.SwitchTo().Alert().Accept();
                return true;
            }
            catch
            {
                return true;
            }
        }
        public static bool IsShiftExist(string shift)
        {
            try
            {
                string shifstXpath = $"//*/div[@id='scheduleContainer']//table//tbody[contains(@style,'display:')]//tr//td/input[contains(@data-assignvalue,'{shift.ToUpper().Trim()}')]";
                IList<IWebElement> lsShifts = getElements(By.XPath(shifstXpath));
                Click(lsShifts[0]);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static IWebElement GetCellLocation(string shift)
        {
            try
            {
                string shifstXpath = $"//*/div[@id='scheduleContainer']//table//tbody[contains(@style,'display:')]//tr//td/input[contains(@data-assignvalue,'{shift.ToUpper()}')]";
                IList<IWebElement> lsShifts = getElements(By.XPath(shifstXpath));
                Click(lsShifts[0]);
                return lsShifts[0];
            }
            catch
            {
                return null;
            }
        }
        public static bool RightClickOnShift(string shift)
        {
            try
            {
                string shifstXpath = $"//*/div[@id='scheduleContainer']//table//tbody[contains(@style,'display:')]//tr//td/input[contains(@data-assignvalue,'{shift.ToUpper()}')]";
                IList<IWebElement> lsShifts = getElements(By.XPath(shifstXpath));
                Click(lsShifts[0]);
                Actions action = new Actions(Driver.Instance);
                action.ContextClick(lsShifts[0]).Build().Perform();
                return true;
            }
            catch
            {
                return false;
            }
        }
        //ac
        public static void SetAutocompleteText(IWebElement Textbox, string option)
        {
            Textbox.Click();
            CommonFunctions.Sendkeys(option, Textbox);
            Thread.Sleep(1000);
            Textbox.SendKeys(Keys.Down);
            Textbox.SendKeys(Keys.Enter);
            Thread.Sleep(1000);
        }

        public static string SelectElementByValue(IWebElement dropdown, string item)
        {
            SelectElement mnuSelect = new SelectElement(dropdown);
            mnuSelect.SelectByText(item);
            return (mnuSelect.SelectedOption.Text.Trim());
        }

        public static List<string> getDropdownOptiontext(string dropdownXpath)
        {
            List<string> lstOptionText = new List<string>();
            IList<IWebElement> lstOptions = getElements(By.XPath($"{dropdownXpath}/option"));
            foreach(var opt in lstOptions)
            {
                lstOptionText.Add(opt.Text);
            }
            return lstOptionText;
        }

        public static List<int> getCOIDsFromUI(string dropdownXpath)
        {
            List<int> lstOptionText = new List<int>();
            IList<IWebElement> lstOptions = getElements(By.XPath($"{dropdownXpath}/option"));
            foreach (var opt in lstOptions)
            {
                lstOptionText.Add(Convert.ToInt32(opt.Text.Split('-').First()));
            }
            return lstOptionText;
        }

        public static string SelectedElementValue_DropDown(IWebElement dropdown)
        {
            SelectElement mnuSelect = new SelectElement(dropdown);

            return (mnuSelect.SelectedOption.Text.Trim());
        }

        public static string SelectElementByIndex(IWebElement dropdown, int index)
        {
            SelectElement mnuSelect = new SelectElement(dropdown);
            mnuSelect.SelectByIndex(index);
            return (mnuSelect.SelectedOption.Text.Trim());
        }

        public static bool SelectItemFromCollectionAndClickIt(string CollectionXpath, string valueToBeSelected)
        {
            try
            {
                string strCollectionItemText;
                IList<IWebElement> Collection = getElements(By.XPath(CollectionXpath));
                foreach (var item in Collection)
                {
                    strCollectionItemText = item.Text.ToString();
                    if (string.Equals(strCollectionItemText, valueToBeSelected, StringComparison.CurrentCultureIgnoreCase) ||
                        strCollectionItemText.Contains(valueToBeSelected))
                    {
                        item.Click();
                        break;
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool IsItemExistInCollection(string CollectionXpath, string valueToBeSearched)
        {
            bool isDisplayed = IsElementDisplayed(CollectionXpath, 10);
            if (isDisplayed)
            {
                try
                {
                    string strCollectionItemText;
                    IList<IWebElement> Collection = getElements(By.XPath(CollectionXpath));
                    foreach (var item in Collection)
                    {
                        strCollectionItemText = item.Text.ToString();
                        if (string.Equals(strCollectionItemText, valueToBeSearched, StringComparison.CurrentCultureIgnoreCase))
                        {
                            return true;
                        }
                    }
                    return false;
                }
                catch
                {
                    return false;
                }
            }
            return false;
        }
        /// <summary>
        /// Set shift on the first empty cell in schedule.
        /// </summary>
        /// <param name="shift"></param>
        public static void SetShift(string shift)
        {
            string shifstXpath = $"//*/div[@id='scheduleContainer']//table//tbody[contains(@style,'display:')]//tr//td/input[not(@data-assignvalue)]";
            IList<IWebElement> lsShifts = getElements(By.XPath(shifstXpath));
            Click(lsShifts[0]);
            EnterText(lsShifts[0], shift);
            IWebElement lblShift = getElement(By.XPath("//*/table[@id='tableNavBar']//tbody//tr//td[@id='ctl00_Body_tdShifts']"));
            Click(lblShift);
            Thread.Sleep(2000);
        }
        public static void ClearTextbox(IWebElement textbox)
        {
            textbox.SendKeys(Keys.Control + "a");
            textbox.SendKeys(Keys.Control + "a");
            textbox.Clear();
            textbox.SendKeys(Keys.Control + "a");
            textbox.SendKeys(Keys.Control + "a");
            textbox.SendKeys(Keys.Delete);

        }
        public static void ReplaceAndSetText(IWebElement textbox, string value)
        {
            //Focus(textbox);
            try
            {

                textbox.Click();
                //Thread.Sleep(1000);
                textbox.SendKeys(Keys.Control + "a");
                textbox.SendKeys(Keys.Control + "a");
                //Thread.Sleep(1000);
                textbox.SendKeys(value);
               // System.Threading.Thread.Sleep(1000);
            }
            catch
            {

                textbox.Clear();
                //Thread.Sleep(1000);
                textbox.SendKeys(value);
            }
        }

        public static void EnterValue(IWebElement textbox, string value)
        {
            textbox.Click();
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            js.ExecuteScript($"arguments[0].value='{value}';", textbox);

        }

        public static void AppendText(IWebElement textarea, string str)
        {
            var text = textarea.Text;
            StringBuilder sb = new StringBuilder(text);
            sb.Append(" ");
            sb.Append(str);
            SetText(textarea, sb.ToString());
        }

        public static string GetTextareaText(By ByTextarea)
        {
            return getElement(ByTextarea).Text;
        }
       

        public static void SetText(IWebElement textbox, string value)
        {
            //Focus(textbox);
            try
            {

                textbox.Click();
                textbox.Click();
                for (int i = 0; i < 20; i++)
                {
                    textbox.SendKeys(Keys.Control + "a");
                    textbox.SendKeys(Keys.Control + "a");
                    textbox.SendKeys(Keys.Delete);
                }
                textbox.SendKeys(value);
            }
            catch
            {

                textbox.Clear();
                textbox.SendKeys(value);
            }
        }


        public static void ReplaceAndSetTextBy(By textbox1, string value)
        {
            //Focus(textbox);
            try
            {
                IWebElement textbox = getElement((textbox1));
                textbox.Click();
                textbox.Clear();
                textbox.SendKeys(value);
            }
            catch
            {
                IWebElement textbox = getElement((textbox1));
                textbox.Clear();
                textbox.SendKeys(value);
            }
        }
        public static void Focus(IWebElement element)
        {
            try
            {
                Actions actions = new Actions(Driver.Instance);
                actions.MoveToElement(element).Build().Perform();
                //IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
                //js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                //Thread.Sleep(1000);
            }
            catch (Exception e)
            {
                Console.WriteLine("Focus function: " + e.Message.ToString());
            }
        }

        public static void Focus(By bySelector)
        {
            try
            {
                var element = getElement(bySelector);
                Actions actions = new Actions(Driver.Instance);
                actions.MoveToElement(element).Build().Perform();
                //IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
                //js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                //Thread.Sleep(1000);
            }
            catch (Exception e)
            {
                Console.WriteLine("Focus function: " + e.Message.ToString());
            }
        }

        public static void ClickWebElement(IWebElement webElement)
        {
            try
            {
                webElement.Click();
            }
            catch (Exception e)
            {
                
            }
        }
        public static void ClickByElement(By by)
        {
            try
            {
                IWebElement element = getElement(by);
                element.Click();
            }
            catch (Exception e)
            {
                
            }
        }
        public static bool colorchecktext(String excpected, IWebElement webelement)
        {
            string colorBlue = "rgba(60, 146, 239, 1)";
            string colorofText = webelement.GetCssValue("color");
            bool colorstatus = colorofText.Equals(excpected) || colorofText.Equals(colorBlue);
            return colorstatus;
        }
        public static bool colorCheckBackGround(String excpected, IWebElement webelement)
        {
            string colorofText = webelement.GetCssValue("background-color");
            bool colorstatus = colorofText.Equals(excpected);
            return colorstatus;
        }
        public static bool ColorchecktextBy(String excpected, By by)
        {
            string colorofText = getElement(by).GetCssValue("color");
            bool colorstatus = excpected.Equals(colorofText);
            return colorstatus;
        }
        public static bool Istextdecorated(String excpected, IWebElement webelement)
        {
            string decorrofText = webelement.GetCssValue("text-decoration-line");
            bool decorrstatus = excpected.Equals(decorrofText);
            return decorrstatus;
        }
        public static void Sendkeys(String input, IWebElement webElement)
        {
            try
            {
                webElement.SendKeys(input);
            }
            catch (Exception e)
            {
                
            }
        }
        public static void BrowserRefresh()
        {
            try
            {
                (Driver.Instance).Navigate().Refresh();
                WaitUntilPageIsAcive();
            }
            catch (Exception e)
            {
                //Driver.verificationErrors.Append(e.ToString());
                Console.WriteLine(e.ToString());
            }
        }
        public static string GetRandomString()
        {
            char partA;
            string partB, sShiftCode;
            partA = GetRandomCharacter();
            partB = getRandomNumber().ToString();
            sShiftCode = partA + partB;
            return sShiftCode;
        }
        public static string getRandomNumber()
        {
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                byte[] data = new byte[4];
                rng.GetBytes(data);
                int value = BitConverter.ToInt32(data, 0);
                return value.ToString().Replace("-", string.Empty);
            }
        }

        public static string GenerateRandonNumber()
        {
            int _min = 10000;
            int _max = 99999;
            Random _rdm = new Random();
            return _rdm.Next(_min, _max).ToString();
        }

        public static string GenerateSmallRandonNumber()
        {
            int _min = 1;
            int _max = 20;
            Random _rdm = new Random();
            return _rdm.Next(_min, _max).ToString();
        }
        public static char GetRandomCharacter()
        {
            string text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            Random rand = new Random();
            int index = rand.Next(text.Length);
            return text[index];
        }
        public static bool compareString(string expected, string actual)
        {
            bool status = expected.Equals(actual);
            return status;
        }
        public static bool IsIwebElementPresent(By ele)
        {
            try
            {
                bool stat = (Driver.Instance).FindElement(ele).Displayed;
                return stat;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public static bool IsIwebElementPresent(IWebElement ele)
        {
            try
            {
                bool stat = (ele).Displayed;
                return stat;
            }
            catch (Exception e)
            {
                Console.Write(e.ToString());
                return false;
            }
        }
        public static bool IsIwebElementPresentBy(By ele)
        {
            try
            {
                bool stat = ((Driver.Instance).FindElement(ele)).Displayed;
                return stat;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public static bool IsIwebElementsPresentBy(IList<IWebElement> ele)
        {
            try
            {
                bool stat = false;
                int j = ele.Count;
                for (int i = 0; i > j; i++)
                {
                    stat = ele[i].Displayed;
                }
                return stat;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public static bool IsIwebElementNotPresent(By ele)
        {
            try
            {
                bool stat = ((Driver.Instance).FindElement(ele)).Displayed;
                return false;
            }
            catch (Exception e)
            {
                return true;
            }
        }
        public static bool IsIwebElementNotPresent(IWebElement ele)
        {
            try
            {
                bool stat = ele.Displayed;
                return false;
            }
            catch (Exception e)
            {
                return true;
            }
        }

        public static bool IsIwebElementDisplayed(IWebElement ele)
        {
            bool condition = ele.Displayed;
            return condition;
        }

        public static void MouseHoverUsingLinkText(string linkText)
        {
            Actions action = new Actions(Driver.Instance);
            IWebElement element = getElement(By.LinkText(linkText));
            action.MoveToElement(element).Perform();
        }

        public static void MouseHoverUsingXpath(string xpath)
        {
            Actions action = new Actions(Driver.Instance);
            IWebElement element = getElement(By.XPath(xpath));
            action.MoveToElement(element).Perform();
        }

        public static void MouseHoverUsingWebElement(IWebElement element)
        {
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
        }

        public static void ClickUsingXpath(string xpath)
        {
            IWebElement webElement = getElement(By.XPath(xpath));
            ClickByJE(webElement);
            Thread.Sleep(7000);
        }

        public static void ClickUsingLinkText(string linkText)
        {
            IWebElement webElement = getElement(By.LinkText(linkText));
            Click(webElement);
            Thread.Sleep(6000);
        }

        public static bool IsElementDisplayedByLinkText(string linkText, int waitTime)
        {
            double dWait = waitTime;
            try
            {
                var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(dWait));
                wait.Until(drv => drv.FindElement(By.LinkText(linkText)).Size.Height != 0);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool IsIwebElementsPresent(By ele)
        {
            try
            {
                bool stat = false;
                IList<IWebElement> listofNeeds = (Driver.Instance).FindElements(ele);
                foreach (IWebElement need in listofNeeds)
                {
                    stat = need.Displayed;
                }
                return stat;
            }
            catch (Exception e)
            {
                //Console.WriteLine(e.ToString());
                return false;
            }
        }

        public static bool IsIwebElementsEnabled(By ele)
        {
            try
            {
                bool stat = false;
                IList<IWebElement> listofNeeds = (Driver.Instance).FindElements(ele);
                foreach (IWebElement need in listofNeeds)
                {
                    stat = need.Enabled;
                }
                return stat;
            }
            catch (Exception e)
            {
                //Console.WriteLine(e.ToString());
                return false;
            }
        }
        public static bool IsIwebElementsNotPresent(By ele)
        {
            try
            {
                bool stat = false;
                IList<IWebElement> listofNeeds = (Driver.Instance).FindElements(ele);
                foreach (IWebElement need in listofNeeds)
                {
                    stat = need.Displayed;
                }
                return false;
            }
            catch (Exception e)
            {

                return true;
            }
        }

        public static bool IsGreater(int expected, int actual)
        {
            try
            {
                bool stat = expected > actual;
                return true;
            }
            catch (Exception e)
            {
                return true;
            }
        }
        public static string ReturnSplitValeWithchar(IWebElement value, char splitchar, int index)
        {
            string[] splitval = value.Text.Split(splitchar);
            string valueneeded = splitval[index];
            return valueneeded;
        }
        public static List<string> GetListofLowerStringPlitFromIWebElementList(List<string> ele, char splitchar, int index)
        {
            List<string> listoftext = new List<string>();
            foreach (string element in ele)
            {
                string[] neww = element.Split(splitchar);
                listoftext.Add(neww[index].ToLower().Trim());
            }
            return listoftext;
        }
        public static bool GetElementEnabled(IList<IWebElement> ele)
        {
            bool stat = false;
            foreach (IWebElement element in ele)
            {
                stat = element.Enabled;
            }
            return stat;
        }

        public static int generateRandomNumberWithinRange(int min, int max)
        {
            Random r = new Random();
            int rInt = r.Next(min, max);
            return rInt;
        }

        public static string ConvertPeriodDate(string d)
        {
            int day, month, year;

            var MonthDic = new Dictionary<string, int>();
            MonthDic.Add("Jan", 1);
            MonthDic.Add("Feb", 2);
            MonthDic.Add("Mar", 3);
            MonthDic.Add("Apr", 4);
            MonthDic.Add("May", 5);
            MonthDic.Add("Jun", 6);
            MonthDic.Add("Jul", 7);
            MonthDic.Add("Aug", 8);
            MonthDic.Add("Sep", 9);
            MonthDic.Add("Oct", 10);
            MonthDic.Add("Nov", 11);
            MonthDic.Add("Dec", 12);



            string[] period = d.Split(',');
            string[] MMM = period[0].Split(' ');
            MonthDic.TryGetValue(MMM[0], out month);
            day = int.Parse(MMM[1]);
            year = int.Parse(period[1]);

            DateTime time = new DateTime(year, month, day);
            string DTime = time.ToString("D");
            string[] Date = DTime.Split(',');
            string[] monthDay = Date[1].Split(' ');

            string str = Date[0] + ", " + monthDay[2] + " " + monthDay[1].ToString() + "" + Date[2];
            return str;
        }

        public static int getMonthDigit(string month)
        {
            int digit;
            var MonthDic = new Dictionary<string, int>();
            MonthDic.Add("Jan", 1);
            MonthDic.Add("Feb", 2);
            MonthDic.Add("Mar", 3);
            MonthDic.Add("Apr", 4);
            MonthDic.Add("May", 5);
            MonthDic.Add("Jun", 6);
            MonthDic.Add("Jul", 7);
            MonthDic.Add("Aug", 8);
            MonthDic.Add("Sep", 9);
            MonthDic.Add("Oct", 10);
            MonthDic.Add("Nov", 11);
            MonthDic.Add("Dec", 12);
            MonthDic.Add("January", 1);
            MonthDic.Add("February ", 2);
            MonthDic.Add("March ", 3);
            MonthDic.Add("April", 4);
            MonthDic.Add("June", 6);
            MonthDic.Add("July", 7);
            MonthDic.Add("August", 8);
            MonthDic.Add("September", 9);
            MonthDic.Add("October", 10);
            MonthDic.Add("November", 11);
            MonthDic.Add("December", 12);
            digit = MonthDic[month.Trim()];
            return digit;

        }

        public static string ChangeDateFormat(string d)
        {
            int day, month, year;

            var MonthDic = new Dictionary<string, int>();
            MonthDic.Add("Jan", 1);
            MonthDic.Add("Feb", 2);
            MonthDic.Add("Mar", 3);
            MonthDic.Add("Apr", 4);
            MonthDic.Add("May", 5);
            MonthDic.Add("Jun", 6);
            MonthDic.Add("Jul", 7);
            MonthDic.Add("Aug", 8);
            MonthDic.Add("Sep", 9);
            MonthDic.Add("Oct", 10);
            MonthDic.Add("Nov", 11);
            MonthDic.Add("Dec", 12);
            MonthDic.Add("January", 1);
            MonthDic.Add("February ", 2);
            MonthDic.Add("March ", 3);
            MonthDic.Add("April", 4);
            MonthDic.Add("June", 6);
            MonthDic.Add("July", 7);
            MonthDic.Add("August", 8);
            MonthDic.Add("September", 9);
            MonthDic.Add("October", 10);
            MonthDic.Add("November", 11);
            MonthDic.Add("December", 12);



            string[] period = d.Split(',');
            string[] MMM = period[0].Split(' ');
            MonthDic.TryGetValue(MMM[0], out month);
            day = int.Parse(MMM[1]);
            year = int.Parse(period[1]);

            DateTime time = new DateTime(year, month, day);
            string Date = time.ToString("MM/dd/yyyy");
            return Date;

        }

        public static string ConvertPeriodDateG(string d)
        {
            int day, month, year;

            string[] period = d.Split('/');
            month = int.Parse(period[0]);
            day = int.Parse(period[1]);
            year = int.Parse(period[2]);
            DateTime time = new DateTime(year, month, day);

            string DTime = time.ToString("MM/dd/yyyy");
            return DTime;
        }
        public static string ConvertPeriodDateG(string d, string format)
        {
            int day, month, year;

            string[] period = d.Split('/');
            month = int.Parse(period[0]);
            day = int.Parse(period[1]);
            year = int.Parse(period[2]);
            DateTime time = new DateTime(year, month, day);
            string DTime = time.ToString(format);
            return DTime;
        }
        public static string ConvertPeriodDateD(string d, string format)
        {
            int day, month, year;

            string[] period = d.Split('/');
            year = int.Parse(period[0]);
            day = int.Parse(period[2]);
            month = int.Parse(period[1]);
            DateTime time = new DateTime(year, month, day);
            string DTime = time.ToString(format);
            return DTime;
        }

        public static List<string> GetListofStringFromIWebElementList(IList<IWebElement> ele)
        {
            List<string> listoftext = new List<string>();
            foreach (IWebElement element in ele)
            {
                listoftext.Add(element.Text.ToLower());
            }
            return listoftext;
        }
        public static List<string> GetListofTextFromBy(By eleBy)
        {
            IList<IWebElement> listofElements = new List<IWebElement>();
            listofElements = (Driver.Instance).FindElements(eleBy);
            List<string> listoftext = new List<string>();
            foreach (IWebElement element in listofElements)
            {
                listoftext.Add(element.Text.Trim());
            }
            return listoftext;
        }
        public static List<string> GetListofStringFromIWebElementListNew(IList<IWebElement>
            ele)
        {
            List<string> listoftext = new List<string>();
            foreach (IWebElement element in ele)
            {
                listoftext.Add(element.Text.Trim());
            }
            return listoftext;
        }



        public static string Value(this IWebElement element, IJavaScriptExecutor javaScriptExecutor)
        {
            try
            {
                string value = javaScriptExecutor.ExecuteScript("return arguments[0].value", element) as string;
                return value;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return null;
            }
        }


        public static void ClickByJE(this IWebElement element)
        {
            try
            {
                IJavaScriptExecutor js = (IJavaScriptExecutor)Driver.Instance;
                js.ExecuteScript("arguments[0].click();", element);
            }
            catch (Exception e)
            {                
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

        public static void ClickByJE(this IWebElement element, IJavaScriptExecutor javaScriptExecutor)
        {
            try
            {
                javaScriptExecutor.ExecuteScript("arguments[0].click();", element);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

        public static void SendKeysByJE(this string elementId, string value, IJavaScriptExecutor javaScriptExecutor)
        {
            try
            {
                //javaScriptExecutor.ExecuteScript("arguments[0].click();", element);
                javaScriptExecutor.ExecuteScript("document.getElementById('" + elementId + "').value='" + value + "';");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

        public static void scrollUp()
        {
            try
            {
                IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
                js.ExecuteScript("scroll(500, 0)");// if the element is on top
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

        public static void scrollUp(By ByElement)
        {
            IWebElement element = getElement(ByElement);
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView();", element);
        }

        public static void scrollUp(IWebElement Element)
        {
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView();", Element);
        }

        public static void scrollUpByJE()
        {
            try
            {
                IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
                js.ExecuteScript("scroll(500, 0)");// if the element is on top
                js.ExecuteScript("window.scrollBy(0,document.body.scrollHeight)", "");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

        public static void scrollToBottomOfPage()
        {
            try
            {
                IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
                //js.ExecuteScript("scroll(500, 0)");// if the element is on top
                js.ExecuteScript("window.scrollBy(0,document.body.scrollHeight)", "");
                Thread.Sleep(1000);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

        public static void scrollDownByJE()
        {
            try
            {
                IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
                js.ExecuteScript("scroll(0, 500)");// if the element is on bottom
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

        public static void scrollDown()
        {
            try
            {
                IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
                js.ExecuteScript("window.scrollTo(0, document.body.scrollHeight)");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                throw e;
            }
        }

        public static void scrollDownToElement(IWebElement element)
        {
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
            Thread.Sleep(1000);
        }


        //@author - Ashwini L J - common method to date format change
        public static string DateFormatSchedulerPage(string reqDate)
        {
            // string[] reqDateSplitHyphen = reqDate.Split('-');
            //string reqFinalDate = reqDateSplitHyphen[1] + "/" + reqDateSplitHyphen[2] + "/" + reqDateSplitHyphen[0];
            DateTime sDate = DateTime.Parse(reqDate);
            return sDate.ToString("M/d/yyyy");
        }

        public static string MonthAndDayDatefromFormatSchedulerPage(string reqDate)
        {
            string StartDate = $"{reqDate} 7:00 AM";
            DateTime sDate = DateTime.Parse(reqDate);
            //Convert time to am/pm
            //string Date = sDate.ToString("M/dd");
            //string Date = sDate.ToString("M/d");
            string Date = sDate.ToUniversalTime().ToString("MM/dd/yyyy");

            //string Date = sDate.ToString("M/d/yyyy hh:mm tt");
            Console.WriteLine(Date);
            return Date;
        }

        public static bool isSelectedCheckboxbyBy(By by)
        {
            bool selected = false;
            try
            {
                selected = getElement(by).Selected;
                return selected;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return selected;
            }
        }

        public static string GetTextOfIwebElementbyBy(By by)
        {
            try
            {
                string textofElem = getElement(by).Text.Trim();
                return textofElem;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return null;
            }
        }
        public static string GetTooltipOfIwebElementbyBy(By by)
        {
            try
            {
                string tooltipofElem = getElement(by).GetAttribute("title");
                return tooltipofElem;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return null;
            }
        }

        public static IList<string> GetListofColorOfIWebelement(IList<IWebElement> ele)
        {
            IList<string> listoftext = new List<string>();

            foreach (IWebElement element in ele)
            {
                string color = element.GetCssValue("background-color");
                listoftext.Add(color.Trim());
            }
            return listoftext;
        }


        /// <summary>
        /// Make Element Clickable If there is an Expection
        /// saying Element is 'Not Clickable at this moment'
        /// 'other element would receive the click'
        /// </summary>
        /// <param name="ByID"></param>

        public static void MakeElementClickable(string ByID)
        {
            IWebElement element = getElement(By.Id(ByID));
            Actions actions = new Actions(Driver.Instance);
            actions.MoveToElement(element).Click().Perform();
        }


        public static void MakeElementClickableXpath(string ByXpath)
        {
            IWebElement element = getElement(By.XPath(ByXpath));
            Actions actions = new Actions(Driver.Instance);
            actions.MoveToElement(element).Click().Perform();
        }


        public static void MakeElementClickableByWebElement(IWebElement element)
        {
            Actions actions = new Actions(Driver.Instance);
            actions.MoveToElement(element).Click().Perform();
        }

        public static bool IsMakeElementClickableByWebElementByAction(IWebElement element)
        {
            bool isAt = true;
            try
            {
                Actions actions = new Actions(Driver.Instance);
                actions.MoveToElement(element).Click().Perform();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                isAt = false;
            }
            return isAt;
        }

        public static void DoubleClickUsingWebElement(IWebElement element)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(element));
            Focus(element);
            Actions actions = new Actions(Driver.Instance);
            actions.MoveToElement(element).DoubleClick(element).Build().Perform();
            actions.DoubleClick(element).Perform();            
            actions.Click(element).Pause(TimeSpan.FromMilliseconds(100)).Click(element).Perform();
            //actions.DoubleClick(element).Build().Perform();
        }

        public static int IsLeapYear()
        {
            DateTime dateTime= DateTime.Now;
            if (DateTime.IsLeapYear(dateTime.Year))
            {
                return 366;
            }
            else
            {
                return 365;
            }
        }

        public static int GetDaysInMonth(string year, string month)
        {
            int iMonthDigit, iYear;
            iMonthDigit = getMonthDigit(month.Trim());
            iYear = Convert.ToInt32(year);
            int days = System.DateTime.DaysInMonth(iYear, iMonthDigit);
            return days;
        }

        /// <param name="ShiftCode"></param>
        /// <returns></returns>
        //// <summary>
        ///  Finds Empty Cell and Set shift ***
        ///  Enter shift in Schedule/Default Schedule Page ***
        //// </summary>
        //// <returns>
        ///  List of data Cell ID where the shift is Entered ***
        //// </returns>
        //// <Assertion>
        ///  Assert if the Shift is Entered ***
        //// </Assertion>
        public static List<string> EnterShiftInDefaultSchedule(string ShiftCode)
        {
            List<string> dataCellId = new List<string>();
            Thread.Sleep(500);
            string shifstXpath = "//*/table[@id='scheduleTable']/tbody/tr/td/input[not(contains(@data-isfloat,'false')) and not(@data-assignvalue)]";
            IList<IWebElement> lsShifts = getElements(By.XPath(shifstXpath));
            for (int i = 0; i < 3; i++)
            {
                Click(lsShifts[i]);
                string cellId = lsShifts[i].GetAttribute("data-cellid");
                dataCellId.Add(cellId);
                EnterText(lsShifts[i], ShiftCode);
                IWebElement lblShift = getElement(By.XPath("//*/table[@id='scheduleTable']/tbody/tr/td[5]"));
                Click(lblShift);
                Assert.IsTrue(IsElementDisplayed(
                    "//*/table[@id='scheduleTable']/tbody/tr/td/input[@data-assignvalue='" + ShiftCode + "'and @data-cellid='" + cellId + "']", 10));
            }
            return dataCellId;
        }

        static string linkXpath = "//*/div[@id='ctl00_upTableSchedule']/a[3]";
        static IWebElement Link => getElement(By.XPath(linkXpath));

        static bool Condition { get; set; }

        public static bool IsReportGeneratedAtTheRightPage(string ExpectedLinkText)
        {
            string linkText = Link.Text.Trim();
            string[] SplitLink = linkText.Split(' ');
            string newLink = SplitLink[1];
            string ExText = ExpectedLinkText;
            if (/*string.Equals(linkText, ExText, StringComparison.CurrentCultureIgnoreCase) ||*/ ExText.Contains(newLink))
            {
                Condition = true;
                Console.WriteLine("Expected Link Name at '" + ExpectedLinkText + "' generate landing page");
            }
            else
            {
                Condition = false;
                Console.WriteLine("'" + ExpectedLinkText + "' has been generated but\nDifferent Link Name Detected at Report generate landing page {potential Bug}");
            }
            return Condition;
        }

        public static bool IsElementExistAfterExplicitWait(string xpath, double waitTime)
        {
            bool isExist = true;
            try
            {
                WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(waitTime));
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath(xpath)));
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.ToString());
                isExist = false;
            }
            return isExist;
        }

        public static void selectCheckbox(By ele)
        {
            try
            {
                IList<IWebElement> ele1 = (Driver.Instance).FindElements(ele);

                foreach (IWebElement element1 in ele1)
                {
                    if (!element1.Selected)
                    {
                        element1.Click();
                    }
                }
            }
            catch (Exception e)
            {

            }

        }


        public static void UnselectCheckbox(By ele)
        {
            try
            {
                IList<IWebElement> ele1 = (Driver.Instance).FindElements(ele);

                foreach (IWebElement element1 in ele1)
                {
                    if (element1.Selected)
                    {
                        element1.Click();
                    }
                }
            }
            catch (Exception e)
            {

            }

        }

        //public static void TakeScreenShot(string tcDescription, Exception exception = null)
        //{
        //    string fp = @"\\aastsun6vfsweb1\Software\QA\ScreenShots\" + tcDescription + ".jpeg";
        //    VerticalCombineDecorator vcd = new VerticalCombineDecorator(new ScreenshotMaker());
        //    Driver.Instance.TakeScreenshot(vcd).ToMagickImage().ToBitmap().Save(fp, ImageFormat.Jpeg);

        //    // Creating an HTML file with image and necessary text including link.
        //    var html = $@"<html>
        //        <body>
        //        <p>{tcDescription}</p>" +

        //        (exception != null ?
        //        $@"<p>Exception: {exception.Message}</p>
        //        <p>StackTrace: {exception.StackTrace}</p>" : "") +

        //        $@"<p>{Driver.Instance.Url}</p>
        //        <img src=""{fp}""/>
        //        <body>
        //        </html>";

        //    File.WriteAllText(fp.Replace(".jpeg", ".html"), html);

        //    //ITakesScreenshot screenshotDriver = Driver.Instance as ITakesScreenshot;
        //    //try
        //    //{
        //    //    // local machine
        //    //    //string parent = Directory.GetParent(Environment.CurrentDirectory.ToString()).Parent.Parent.FullName;
        //    //    //ITakesScreenshot screenshotDriver = Driver.Instance as ITakesScreenshot;
        //    //    //Screenshot screenshot = screenshotDriver.GetScreenshot();
        //    //    //String fp = parent + @"\AAS.FacilityScheduler.UITest.Framework\ScreenShots\" + tcDescription + "_" + DateTime.Now.ToString("dd_MMMM_hh_mm_ss_tt") + ".png";
        //    //    //screenshot.SaveAsFile(fp);
        //    //    //var basePath = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;
        //    //    string fp = @"C:\Users\opt6590\OneDrive - HCA Healthcare\Desktop\Screenshot\" + tcDescription + "_" + DateTime.Now.ToShortDateString() + ".jpeg";
        //    //    VerticalCombineDecorator vcd = new VerticalCombineDecorator(new ScreenshotMaker());
        //    //    Driver.Instance.TakeScreenshot(vcd).ToMagickImage().ToBitmap().Save(fp, ImageFormat.Jpeg);
        //    //}
        //    //catch (Exception e)
        //    //{
        //    //    try
        //    //    {
        //    //        // VM location
        //    //        string ReleaseFolder;
        //    //        DateTime time = DateTime.Now;
        //    //        string format = "MMM ddd d yyyy";
        //    //        ReleaseFolder = @"C:\Dev\Screenshots\" + time.ToString(format);
        //    //        Directory.CreateDirectory(ReleaseFolder);
        //    //        Screenshot screenshot = screenshotDriver.GetScreenshot();
        //    //        string fp = ReleaseFolder + "\\" + tcDescription + "_" + DateTime.Now.ToString("hh_mm") + ".png";
        //    //        //String fp = parent + @"\AAS.FacilityScheduler.UITest.Framework\ScreenShots\" + tcDescription + "_" + DateTime.Now.ToString("dd_MMMM_hh_mm_ss_tt") + ".png";
        //    //        screenshot.SaveAsFile(fp);
        //    //    }
        //    //    catch
        //    //    {
        //    //        //Continue since there is nothing to report if the the folder is not there. 
        //    //    }

        //}

        public static IWebElement FindShadowRootElement(string[] Selectors)
        {
            IWebElement root = null;
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;

            //(IWebElement)js.ExecuteScript("document.querySelector("body > print - preview - app").shadowRoot.querySelector("#sidebar").shadowRoot.querySelector("print-preview-button-strip").shadowRoot.querySelector("div > cr-button.cancel-button")")

            foreach (var selector in Selectors)
            {
                root = (IWebElement)js.ExecuteScript("return arguments[0].querySelector(arguments[1]).shadowRoot", root, selector);
            }
            return root;
        }

        public static bool isSelectedCheckboxbyBy(IWebElement userFacilityCustomField)
        {
            throw new NotImplementedException();
        }
    }
}



