﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class Timer
    {
        private static Stopwatch stopwatch = new Stopwatch();

        public static void Start()
        {
            stopwatch.Reset();
            stopwatch.Start();
        }

        public static void Stop()
        {
            stopwatch.Stop();
        }

        public static string GetElapsedTime()
        {
            return $"{stopwatch.Elapsed.Minutes}:{stopwatch.Elapsed.Seconds}";
        }
        public static void Reset()
        {
            stopwatch.Reset();
        }
    }
}
