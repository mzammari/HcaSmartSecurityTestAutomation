﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using SharpCompress.Common;
using DocumentFormat.OpenXml;
using System.IO;
using System.Threading;
using RazorEngine.Compilation.ImpromptuInterface;

namespace ISAS_Regression_Automation
{
    public class ExcelTemplate
    {
        public static void CopyFile(string sourceFile, string destinationFile)
        {
            try
            {
                CommonFunctions.AddTestStep("Copy File", "Copy File");
                if (File.Exists(destinationFile))
                {
                    File.Delete(destinationFile);
                }
                File.Copy(sourceFile, destinationFile, true);
            }
            catch
            {
                throw;               
            }
        }





        public static void WriteToExcelFile(string filename, Dictionary<string, string> data)
        {   
            CommonFunctions.AddTestStep("Write to Excel File", "Write to Excel File");
            //byte[] byteArray = File.ReadAllBytes(fileLocation);
            using (MemoryStream stream = new MemoryStream())
            {
                // Open the workbook
                using (SpreadsheetDocument document = SpreadsheetDocument.Open(filename, true))
                {
                    try
                    {
                        // Get the first worksheet
                        Sheet sheet = document.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();
                        WorksheetPart worksheetPart = (WorksheetPart)document.WorkbookPart.GetPartById(sheet.Id);

                        // Update specific cells
                        var keys = new List<string>(data.Keys);
                        foreach (var key in keys)
                        {
                            UpdateCellValue(worksheetPart, key, data[key]);
                        }

                        // Save changes
                        worksheetPart.Worksheet.Save();
                        document.WorkbookPart.Workbook.Save();
                        document.Dispose();
                        Thread.Sleep(20000);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Saving exception");
                        document?.WorkbookPart?.Workbook.Save();
                        document?.Dispose();
                        Thread.Sleep(20000);
                    }                    
                }
            }        
        }

        // Method to update a cell value
        private static void UpdateCellValue(WorksheetPart worksheetPart, string cellReference, string newValue)
        {
            // Get the cell with the specified reference
            Cell cell = GetCell(worksheetPart, cellReference);

            // Update the cell's value
            cell.CellValue = new CellValue(newValue.ToString());

            // Set the data type to "String" to ensure text values are handled correctly
            cell.DataType = new EnumValue<CellValues>(CellValues.String);
        }

        private static Cell GetCell(WorksheetPart worksheetPart, string cellReference)
        {
            Worksheet worksheet = worksheetPart.Worksheet;
            SheetData sheetData = worksheet.GetFirstChild<SheetData>();

            // Extract row number from the cell reference (e.g., "E6" -> 6)
            uint rowIndex = uint.Parse(cellReference.Substring(1));

            // Find the row or create it if it doesn't exist
            Row row = sheetData.Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex) ??
                      sheetData.AppendChild(new Row { RowIndex = rowIndex });

            // Find the cell in the row or create it
            Cell cell = row.Elements<Cell>().FirstOrDefault(c => c.CellReference == cellReference) ??
                        row.AppendChild(new Cell { CellReference = cellReference });

            return cell;
        }
    }
}
