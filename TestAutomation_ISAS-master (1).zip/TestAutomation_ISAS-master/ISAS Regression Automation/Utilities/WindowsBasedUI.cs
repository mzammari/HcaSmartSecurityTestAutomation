﻿using AngleSharp.Dom;
using AventStack.ExtentReports.Gherkin.Model;
using DocumentFormat.OpenXml.Spreadsheet;
using SharpCompress.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation.Utilities
{
    public class WindowsBasedUI
    {
        

        [DllImport("user32.dll", EntryPoint = "FindWindow", CharSet = CharSet.Auto)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", EntryPoint = "FindWindowEx", CharSet = CharSet.Auto)]
        static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

        [DllImport("user32.dll", EntryPoint = "PostMessage", CharSet = CharSet.Auto)]
        static extern bool PostMessage1(IntPtr hWnd, uint Msg, int wParam, int lParam);

        [DllImport("user32.dll", EntryPoint = "SendMessage",CharSet = CharSet.Auto)]
        static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, string lParam);

        public static void ChooseFile(string filename)
        {
            uint WM_LBUTTONDOWN = 0x0201;
            uint WM_LBUTTONUP = 0x0202;
            uint WM_SETTEXT = 0x000C;

            IntPtr mwh = IntPtr.Zero; // main window handle
            bool formFound = false;
            int attempts = 0;
            while (!formFound && attempts < 25)
            {
                if (mwh == IntPtr.Zero)
                {
                    Thread.Sleep(100);
                    ++attempts;
                    //Find the main window handle
                    mwh = FindWindow(null, "Open");
                    IntPtr CB = FindWindowEx(mwh, IntPtr.Zero, "ComboBoxEx32", null);
                    IntPtr CCB = FindWindowEx(CB, IntPtr.Zero, "ComboBox", null);
                    IntPtr Edit = FindWindowEx(CCB, IntPtr.Zero, "Edit", null);
                    SendMessage(Edit, WM_SETTEXT, IntPtr.Zero, filename);
                    Thread.Sleep(1000);
                    //Click on the Open button
                    IntPtr butt = FindWindowEx(mwh, IntPtr.Zero, null, "&Open");
                    PostMessage1(butt, WM_LBUTTONDOWN, 0, 0);
                    PostMessage1(butt, WM_LBUTTONUP, 0, 0);
                    Thread.Sleep(3000);
                    CommonFunctions.AddTestStep("Select file", "the file was selected and opened");
                    CommonFunctions.WaitUntilPageIsAcive();
                }
                else
                {
                    Console.WriteLine("Form has been found");
                    formFound = true;
                }
            }
        }
    }
}
