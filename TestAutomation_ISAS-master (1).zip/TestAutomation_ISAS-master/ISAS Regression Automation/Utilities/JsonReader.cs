﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class JsonReader
    {
        public JsonReader() { }
        public String extractData(String fileName, String tokenName)
        {
            String dir = AppDomain.CurrentDomain.BaseDirectory;
            String TestDataPath = dir.Replace("bin\\Debug\\net6.0", "Test Data");
            String myJsonString = File.ReadAllText(TestDataPath + "/" + fileName + ".json");
            //Console.WriteLine(myJsonString);
            var jsonObject = JToken.Parse(myJsonString);
            return jsonObject.SelectToken(tokenName).Value<String>();
        }
        public String[] extractDataArray(String fileName, String tokenName)
        {
            String dir = AppDomain.CurrentDomain.BaseDirectory;
            String TestDataPath = dir.Replace("bin\\Debug\\net6.0", "Test Data");
            String myJsonString = File.ReadAllText(TestDataPath + "/" + fileName + ".json");
            var jsonObject = JToken.Parse(myJsonString);
            List<String> array = jsonObject.SelectTokens(tokenName).Values<String>().ToList();
            return array.ToArray();
        }
    }
}
