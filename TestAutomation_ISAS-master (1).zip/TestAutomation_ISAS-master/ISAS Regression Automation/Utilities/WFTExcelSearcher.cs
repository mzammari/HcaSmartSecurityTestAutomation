﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using ExcelDataReader;

namespace ISAS_Regression_Automation
{
    public class WFTExcelSearcher
    {
        /// <summary>
            /// Searches an Excel file for a specific value and returns the results as a list of dynamically generated objects.
            /// </summary>
            /// <param name="filePath">Path to the Excel file</param>
            /// <param name="searchValue">Value to search for</param>
            /// <param name="searchColumnIndex">Column index to search in (0-based)</param>
            /// <param name="useDynamicType">If true, returns compiled objects; if false, returns ExpandoObjects</param>
            /// <returns>A list of dynamic objects representing the matched rows</returns>
        public static List<object> SearchExcelAndCreateObjects(
        string filePath,
        object searchValue,
        int searchColumnIndex,
        bool useDynamicType = true)
        {
            // Try to register encoding provider - this requires the System.Text.Encoding.CodePages NuGet package
            try
            {
                // This is safer than checking if it's registered, as that could throw exceptions
                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Couldn't register encoding provider: {ex.Message}");
                Console.WriteLine("Please install the System.Text.Encoding.CodePages NuGet package");
            }

            // Search the Excel file
            var matches = SearchExcelFirstSheet(filePath, searchValue, searchColumnIndex);

            if (matches.Count == 0)
                return new List<object>();

            // Get the first match to use as a template for our dynamic type
            var firstMatch = matches[0].RowData;

            if (useDynamicType)
            {
                // Create a compiled type at runtime based on the dictionary keys
                Type generatedType = CreateDynamicType(firstMatch);

                // Convert all matches to this type
                return matches.Select(m =>
                {
                    var obj = Activator.CreateInstance(generatedType);
                    MapDictionaryToObject(m.RowData, obj);
                    return obj;
                }).ToList();
            }
            else
            {
                // Create ExpandoObjects instead
                return matches.Select(m => CreateDynamicObject(m.RowData)).Cast<object>().ToList();
            }
        }

        /// <summary>
            /// Gets the Type of the dynamically generated object based on sample data.
            /// Useful when you need to know the type before creating objects.
            /// </summary>
        public static Type GetDynamicObjectType(string filePath, object searchValue, int searchColumnIndex)
        {
            // Try to register encoding provider
            try
            {
                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Warning: Couldn't register encoding provider: {ex.Message}");
                Console.WriteLine("Please install the System.Text.Encoding.CodePages NuGet package");
            }

            // Get first match to determine structure
            var matches = SearchExcelFirstSheet(filePath, searchValue, searchColumnIndex);
            if (matches.Count == 0)
                throw new Exception("No matches found to determine object structure");

            return CreateDynamicType(matches[0].RowData);
        }

        /// <summary>
            /// Searches the first sheet of an Excel file for a specific value.
            /// </summary>
        private static List<(int SectionIndex, Dictionary<string, object> RowData)> SearchExcelFirstSheet(
        string filePath, object searchValue, int searchColumnIndex)
        {
            var matches = new List<(int SectionIndex, Dictionary<string, object> RowData)>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = (_) => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = false
                        }
                    });

                    if (result.Tables.Count > 0)
                    {
                        var worksheet = result.Tables[0];
                        var sections = FindSections(worksheet);

                        for (int sectionIndex = 0; sectionIndex < sections.Count; sectionIndex++)
                        {
                            var section = sections[sectionIndex];
                            var sectionMatches = SearchInSection(worksheet, section, searchValue, searchColumnIndex);

                            foreach (var rowData in sectionMatches)
                            {
                                matches.Add((sectionIndex, rowData));
                            }
                        }
                    }
                }
            }

            return matches;
        }

        /// <summary>
            /// Finds all sections (header + data blocks) in a worksheet.
            /// </summary>
        private static List<(int HeaderRowIndex, int DataStartRowIndex, int DataEndRowIndex)> FindSections(DataTable worksheet)
        {
            var sections = new List<(int, int, int)>();
            int rowCount = worksheet.Rows.Count;
            int currentRow = 0;

            while (currentRow < rowCount)
            {
                // Skip empty rows
                while (currentRow < rowCount && IsEmptyRow(worksheet.Rows[currentRow]))
                {
                    currentRow++;
                }

                if (currentRow >= rowCount) break;

                // This is a potential header row
                int headerRow = currentRow;
                currentRow++;

                // Skip empty rows after header
                while (currentRow < rowCount && IsEmptyRow(worksheet.Rows[currentRow]))
                {
                    currentRow++;
                }

                if (currentRow >= rowCount) break;

                // Data rows start here
                int dataStartRow = currentRow;

                // Find the end of this data section
                while (currentRow < rowCount && !IsEmptyRow(worksheet.Rows[currentRow]))
                {
                    currentRow++;
                }

                // Data rows end at the row before
                int dataEndRow = currentRow - 1;

                // Add this section
                sections.Add((headerRow, dataStartRow, dataEndRow));
            }

            return sections;
        }

        /// <summary>
            /// Determines if a row is empty.
            /// </summary>
        private static bool IsEmptyRow(DataRow row)
        {
            for (int i = 0; i < row.ItemArray.Length; i++)
            {
                if (row.ItemArray[i] != null && !string.IsNullOrWhiteSpace(row.ItemArray[i].ToString()))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
            /// Searches for a value in a specific section of the worksheet.
            /// </summary>
        private static List<Dictionary<string, object>> SearchInSection(
        DataTable worksheet,
        (int HeaderRowIndex, int DataStartRowIndex, int DataEndRowIndex) section,
        object searchValue,
        int searchColumnIndex)
        {
            var matches = new List<Dictionary<string, object>>();

            // Get the headers for this section
            var headers = new List<string>();
            var headerRow = worksheet.Rows[section.HeaderRowIndex];

            for (int col = 0; col < headerRow.ItemArray.Length; col++)
            {
                var headerValue = headerRow[col]?.ToString() ?? $"Column_{col}";
                headers.Add(headerValue);
            }

            // Search for the value in the data rows
            for (int rowIndex = section.DataStartRowIndex; rowIndex <= section.DataEndRowIndex; rowIndex++)
            {
                var row = worksheet.Rows[rowIndex];

                // Check if this row has our search value in the specified column
                if (row.ItemArray.Length > searchColumnIndex &&
                        row.ItemArray[searchColumnIndex] != null &&
                        row.ItemArray[searchColumnIndex].ToString() == searchValue.ToString())
                {
                    // Create a dictionary for this match
                    var matchData = new Dictionary<string, object>();

                    // Add all headers and values for this row
                    for (int col = 0; col < Math.Min(headers.Count, row.ItemArray.Length); col++)
                    {
                        // Use a unique key if there are duplicate header names
                        string key = headers[col];
                        if (matchData.ContainsKey(key))
                        {
                            key = $"{headers[col]}_{col}";
                        }

                        matchData[key] = row.ItemArray[col];
                    }

                    matches.Add(matchData);
                }
            }

            return matches;
        }

        /// <summary>
            /// Creates a dynamic ExpandoObject from a dictionary.
            /// </summary>
        private static dynamic CreateDynamicObject(Dictionary<string, object> dictionary)
        {
            dynamic obj = new ExpandoObject();
            var expandoDict = (IDictionary<string, object>)obj;

            foreach (var kvp in dictionary)
            {
                string propertyName = MakeValidPropertyName(kvp.Key);
                expandoDict[propertyName] = kvp.Value;
            }

            return obj;
        }

        /// <summary>
            /// Creates a compiled Type at runtime based on dictionary keys.
            /// </summary>
        private static Type CreateDynamicType(Dictionary<string, object> dictionary)
        {
            // Create a unique type name using a GUID to avoid conflicts
            string typeName = "ExcelRow_" + Guid.NewGuid().ToString("N");

            // Create a dynamic assembly and module
            AssemblyName assemblyName = new AssemblyName("DynamicExcelAssembly");
            AssemblyBuilder assemblyBuilder = AssemblyBuilder.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder = assemblyBuilder.DefineDynamicModule("DynamicExcelModule");

            // Create a new type
            TypeBuilder typeBuilder = moduleBuilder.DefineType(
          typeName,
          TypeAttributes.Public | TypeAttributes.Class | TypeAttributes.AutoClass |
          TypeAttributes.AnsiClass | TypeAttributes.BeforeFieldInit | TypeAttributes.AutoLayout,
          typeof(object));

            // Add properties for each dictionary key
            foreach (var key in dictionary.Keys)
            {
                string propertyName = MakeValidPropertyName(key);
                Type propertyType = GetAppropriateType(dictionary[key]);

                // Create a private field
                FieldBuilder fieldBuilder = typeBuilder.DefineField(
            "_" + propertyName,
            propertyType,
            FieldAttributes.Private);

                // Create property
                PropertyBuilder propertyBuilder = typeBuilder.DefineProperty(
            propertyName,
            PropertyAttributes.HasDefault,
            propertyType,
            null);

                // Define the getter method
                MethodBuilder getMethodBuilder = typeBuilder.DefineMethod(
            "get_" + propertyName,
            MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig,
            propertyType,
            Type.EmptyTypes);

                ILGenerator getIL = getMethodBuilder.GetILGenerator();
                getIL.Emit(OpCodes.Ldarg_0);
                getIL.Emit(OpCodes.Ldfld, fieldBuilder);
                getIL.Emit(OpCodes.Ret);

                // Define the setter method
                MethodBuilder setMethodBuilder = typeBuilder.DefineMethod(
            "set_" + propertyName,
            MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig,
            null,
            new[] { propertyType });

                ILGenerator setIL = setMethodBuilder.GetILGenerator();
                setIL.Emit(OpCodes.Ldarg_0);
                setIL.Emit(OpCodes.Ldarg_1);
                setIL.Emit(OpCodes.Stfld, fieldBuilder);
                setIL.Emit(OpCodes.Ret);

                // Set the accessor methods
                propertyBuilder.SetGetMethod(getMethodBuilder);
                propertyBuilder.SetSetMethod(setMethodBuilder);
            }

            // Create the type
            return typeBuilder.CreateType();
        }

        /// <summary>
            /// Maps dictionary values to an object's properties.
            /// </summary>
        private static void MapDictionaryToObject(Dictionary<string, object> dictionary, object obj)
        {
            Type type = obj.GetType();

            foreach (var kvp in dictionary)
            {
                string propertyName = MakeValidPropertyName(kvp.Key);
                PropertyInfo property = type.GetProperty(propertyName);

                if (property != null)
                {
                    try
                    {
                        // Convert the value to the property type
                        object convertedValue = ConvertToType(kvp.Value, property.PropertyType);
                        property.SetValue(obj, convertedValue);
                    }
                    catch
                    {
                        // If conversion fails, try to set a default value
                        try
                        {
                            property.SetValue(obj, property.PropertyType.IsValueType ?
                              Activator.CreateInstance(property.PropertyType) : null);
                        }
                        catch
                        {
                            // Ignore if we can't set a value
                        }
                    }
                }
            }
        }

        /// <summary>
            /// Converts a string into a valid C# property name.
            /// </summary>
        private static string MakeValidPropertyName(string input)
        {
            if (string.IsNullOrEmpty(input))
                return "EmptyProperty";

            // Remove invalid characters
            string valid = new string(input.Where(c => char.IsLetterOrDigit(c) || c == '_').ToArray());

            // Ensure it starts with a letter or underscore
            if (valid.Length == 0 || !char.IsLetter(valid[0]) && valid[0] != '_')
                valid = "_" + valid;

            return valid;
        }

        /// <summary>
            /// Determines the appropriate .NET type for a property based on its value.
            /// </summary>
        private static Type GetAppropriateType(object value)
        {
            if (value == null)
                return typeof(object);

            Type type = value.GetType();

            // For DB null or special types, use object
            if (type == typeof(DBNull) || type == typeof(DataColumn))
                return typeof(object);

            return type;
        }

        /// <summary>
            /// Converts a value to the specified type.
            /// </summary>
        private static object ConvertToType(object value, Type targetType)
        {
            if (value == null || value is DBNull)
                return null;

            if (targetType.IsAssignableFrom(value.GetType()))
                return value;

            try
            {
                return Convert.ChangeType(value, targetType);
            }
            catch
            {
                // If conversion fails, return null or default
                return targetType.IsValueType ? Activator.CreateInstance(targetType) : null;
            }
        }
    }
}
