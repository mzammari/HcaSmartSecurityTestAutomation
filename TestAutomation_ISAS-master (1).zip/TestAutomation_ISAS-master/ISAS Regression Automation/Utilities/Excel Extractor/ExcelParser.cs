﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Parses an Excel file (.xls or .xlsx) into a nested dictionary.
    /// 
    /// Usage:
    ///   var metrics = ExcelParser.ToList("Employed (Productive) FTEs:, Contract FTEs, Total Productive FTEs");
    ///   var columns = ExcelParser.ToList("Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, Total");
    ///   
    ///   var report = ExcelParser.ParseExcel("Report.xls", metrics, columns);
    ///   
    ///   double jan = report["Employed (Productive) FTEs:"]["Jan"];
    ///   double total = report["Contract FTEs"]["Total"];
    /// </summary>
    public class ExcelParser
    {
        /// <summary>
        /// Parse Excel (.xls or .xlsx) into Dictionary&lt;metricName, Dictionary&lt;columnName, value&gt;&gt;.
        /// </summary>
        public static Dictionary<string, Dictionary<string, double>> ParseExcel(
            string fileLocation,
            List<string> metrics,
            List<string> columns,
            string dataType = "double",
            string sheetName = null,
            int headerRow = 0)
        {
            // Read the sheet into a DataTable (works for .xls and .xlsx)
            var table = ExcelHeaderDiscovery.ReadSheet(fileLocation, sheetName);

            // Discover headers and their positions
            var headers = ExcelHeaderDiscovery.GetHeaders(table, headerRow);
            int detectedHeaderRow = headers.Values.FirstOrDefault()?.HeaderRow ?? 0;

            // Find the key column (where metric names live)
            int keyColIndex = FindKeyColumn(table, detectedHeaderRow, metrics);

            // Map requested columns to their DataTable positions
            var columnMap = new List<(string Name, int ColIndex)>();
            foreach (var col in columns)
            {
                var colInfo = headers.Values.FirstOrDefault(h =>
                    h.HeaderName.Equals(col, StringComparison.OrdinalIgnoreCase));

                if (colInfo != null)
                    columnMap.Add((col, colInfo.ColumnIndex));
                else
                    Console.WriteLine($"Warning: Column '{col}' not found in Excel.");
            }

            // Build the result
            var result = new Dictionary<string, Dictionary<string, double>>(StringComparer.OrdinalIgnoreCase);

            // Scan rows and match metrics
            var remaining = new HashSet<string>(metrics, StringComparer.OrdinalIgnoreCase);

            for (int row = detectedHeaderRow + 1; row < table.Rows.Count && remaining.Count > 0; row++)
            {
                string cellValue = table.Rows[row][keyColIndex]?.ToString()?.Trim();
                if (cellValue == null || !remaining.Contains(cellValue))
                    continue;

                var rowData = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

                foreach (var (name, colIndex) in columnMap)
                {
                    object cellObj = table.Rows[row][colIndex];
                    rowData[name] = ConvertToDouble(cellObj);
                }

                result[cellValue] = rowData;
                remaining.Remove(cellValue);
            }

            if (remaining.Count > 0)
                Console.WriteLine($"Warning: Metrics not found: {string.Join(", ", remaining)}");

            return result;
        }

        /// <summary>
        /// Compare Excel values against DB values.
        /// Returns a list of results with pass/fail.
        /// </summary>
        public static List<CompareResult> Compare(
            Dictionary<string, Dictionary<string, double>> excelData,
            Dictionary<string, Dictionary<string, double>> dbData,
            double tolerance = 0.01)
        {
            var results = new List<CompareResult>();

            foreach (var metric in excelData)
            {
                if (!dbData.TryGetValue(metric.Key, out var dbRow))
                {
                    results.Add(new CompareResult
                    {
                        Metric = metric.Key,
                        Column = "*",
                        ExcelValue = 0,
                        DbValue = 0,
                        Match = false,
                        Note = "Metric not found in DB"
                    });
                    continue;
                }

                foreach (var col in metric.Value)
                {
                    double dbVal = dbRow.TryGetValue(col.Key, out var v) ? v : 0;
                    bool match = Math.Abs(col.Value - dbVal) <= tolerance;

                    results.Add(new CompareResult
                    {
                        Metric = metric.Key,
                        Column = col.Key,
                        ExcelValue = col.Value,
                        DbValue = dbVal,
                        Match = match
                    });
                }
            }

            return results;
        }

        /// <summary>
        /// Print comparison results. Shows all or only mismatches.
        /// </summary>
        public static void PrintCompareResults(List<CompareResult> results, bool onlyMismatches = false)
        {
            var filtered = onlyMismatches ? results.Where(r => !r.Match).ToList() : results;

            //Console.WriteLine($"\n{"Metric",-40} {"Column",-8} {"Excel",> 12} {"DB",> 12} {"Match",> 8}");
            Console.WriteLine(new string('-', 82));

            foreach (var r in filtered)
            {
                Console.WriteLine($"{r.Metric,-40} {r.Column,-8} {r.ExcelValue,12:F4} {r.DbValue,12:F4} {(r.Match ? "PASS" : "FAIL"),8}");
            }

            int total = results.Count;
            int passed = results.Count(r => r.Match);
            Console.WriteLine(new string('-', 82));
            Console.WriteLine($"Total: {total} | Passed: {passed} | Failed: {total - passed}");
        }

        /// <summary>
        /// Convert comma-delimited string to List&lt;string&gt;.
        /// </summary>
        public static List<string> ToList(string commaDelimited)
        {
            return commaDelimited
                .Split(',')
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrEmpty(s))
                .ToList();
        }

        private static double ConvertToDouble(object cellObj)
        {
            if (cellObj == null || cellObj == DBNull.Value)
                return 0.0;

            // Already a number type
            if (cellObj is double d) return d;
            if (cellObj is decimal dec) return (double)dec;
            if (cellObj is int i) return i;
            if (cellObj is long l) return l;
            if (cellObj is float f) return f;

            // It's a string — parse it
            string text = cellObj.ToString()?.Trim();
            if (string.IsNullOrWhiteSpace(text)) return 0.0;

            // Percentage string: "52%", "4.21%"
            if (text.EndsWith("%"))
            {
                string numPart = text.TrimEnd('%').Trim();
                if (double.TryParse(numPart, out double pctValue))
                    return pctValue / 100.0;
            }

            // Currency/formatted: "$1,234.56"
            string cleaned = text.Replace("$", "").Replace(",", "").Trim();
            if (double.TryParse(cleaned, out double parsed))
                return parsed;

            return 0.0;
        }

        private static int FindKeyColumn(DataTable table, int headerRow, List<string> metrics)
        {
            var metricSet = new HashSet<string>(metrics, StringComparer.OrdinalIgnoreCase);
            int maxCol = Math.Min(table.Columns.Count, 5);

            for (int col = 0; col < maxCol; col++)
            {
                for (int row = headerRow + 1; row < table.Rows.Count; row++)
                {
                    string val = table.Rows[row][col]?.ToString()?.Trim();
                    if (val != null && metricSet.Contains(val))
                        return col;
                }
            }

            return 0;
        }

        /// <summary>
        /// Query an Excel file: find rows where searchColumn = searchValue,
        /// return all specified columns for each matching row.
        /// Uses decimal for exact precision — no rounding.
        /// 
        /// Usage:
        ///   var columns = ExcelParser.ToList("Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, Total");
        ///   var results = ExcelParser.QueryExcel(
        ///       "Report.xls",
        ///       columns,
        ///       searchColumn: "Department",
        ///       searchValue: "504"
        ///   );
        ///   
        ///   decimal jan = results["Employed (Productive) FTEs:"]["Jan"];
        ///   decimal total = results["Contract FTEs"]["Total"];
        /// </summary>
        public static Dictionary<string, Dictionary<string, decimal>> QueryExcel(
            string fileLocation,
            List<string> columns,
            string searchColumn,
            string searchValue,
            string sheetName = null,
            int headerRow = 0)
        {
            var table = ExcelHeaderDiscovery.ReadSheet(fileLocation, sheetName);
            var headers = ExcelHeaderDiscovery.GetHeaders(table, headerRow);
            int detectedHeaderRow = headers.Values.FirstOrDefault()?.HeaderRow ?? 0;

            // Find the search column
            var searchCol = headers.Values.FirstOrDefault(h =>
                h.HeaderName.Equals(searchColumn, StringComparison.OrdinalIgnoreCase));

            if (searchCol == null)
                throw new KeyNotFoundException($"Search column '{searchColumn}' not found. " +
                    $"Available: {string.Join(", ", headers.Values.Select(h => h.HeaderName))}");

            // Find the row key column (first column that isn't the search column and isn't in the columns list)
            int keyColIndex = -1;
            foreach (var h in headers.Values.OrderBy(h => h.ColumnIndex))
            {
                bool isSearchCol = h.ColumnIndex == searchCol.ColumnIndex;
                bool isDataCol = columns.Any(c => c.Equals(h.HeaderName, StringComparison.OrdinalIgnoreCase));
                if (!isSearchCol && !isDataCol)
                {
                    keyColIndex = h.ColumnIndex;
                    break;
                }
            }

            if (keyColIndex < 0) keyColIndex = 0;

            // Map requested columns to their positions
            var columnMap = new List<(string Name, int ColIndex)>();
            foreach (var col in columns)
            {
                var colInfo = headers.Values.FirstOrDefault(h =>
                    h.HeaderName.Equals(col, StringComparison.OrdinalIgnoreCase));

                if (colInfo != null)
                    columnMap.Add((col, colInfo.ColumnIndex));
                else
                    Console.WriteLine($"Warning: Column '{col}' not found in Excel.");
            }

            // Scan rows: find matching criteria, return entire row
            var result = new Dictionary<string, Dictionary<string, decimal>>(StringComparer.OrdinalIgnoreCase);

            for (int row = detectedHeaderRow + 1; row < table.Rows.Count; row++)
            {
                string cellValue = table.Rows[row][searchCol.ColumnIndex]?.ToString()?.Trim();
                if (!searchValue.Equals(cellValue, StringComparison.OrdinalIgnoreCase))
                    continue;

                string rowKey = table.Rows[row][keyColIndex]?.ToString()?.Trim();
                if (string.IsNullOrWhiteSpace(rowKey))
                    continue;

                var rowData = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
                foreach (var (name, colIndex) in columnMap)
                {
                    object cellObj = table.Rows[row][colIndex];
                    rowData[name] = ConvertToDecimal(cellObj);
                }

                // Handle duplicate row keys
                string uniqueKey = rowKey;
                if (result.ContainsKey(uniqueKey))
                {
                    int suffix = 2;
                    while (result.ContainsKey($"{rowKey}_{suffix}"))
                        suffix++;
                    uniqueKey = $"{rowKey}_{suffix}";
                }

                result[uniqueKey] = rowData;
            }

            if (result.Count == 0)
                Console.WriteLine($"Warning: No rows found where '{searchColumn}' = '{searchValue}'");
            else
                Console.WriteLine($"Found {result.Count} rows where '{searchColumn}' = '{searchValue}'");

            return result;
        }

        private static decimal ConvertToDecimal(object cellObj)
        {
            if (cellObj == null || cellObj == DBNull.Value)
                return 0m;

            if (cellObj is decimal dec) return dec;
            if (cellObj is double d) return (decimal)d;
            if (cellObj is int i) return i;
            if (cellObj is long l) return l;
            if (cellObj is float f) return (decimal)f;

            string text = cellObj.ToString()?.Trim();
            if (string.IsNullOrWhiteSpace(text)) return 0m;

            // Percentage: "52%" -> 0.52
            if (text.EndsWith("%"))
            {
                string numPart = text.TrimEnd('%').Trim();
                if (decimal.TryParse(numPart, out decimal pctValue))
                    return pctValue / 100m;
            }

            // Currency/formatted: "$1,234.56"
            string cleaned = text.Replace("$", "").Replace(",", "").Trim();
            if (decimal.TryParse(cleaned, out decimal parsed))
                return parsed;

            return 0m;
        }
    }

    public class CompareResult
    {
        public string Metric { get; set; }
        public string Column { get; set; }
        public double ExcelValue { get; set; }
        public double DbValue { get; set; }
        public bool Match { get; set; }
        public string Note { get; set; }

        public override string ToString()
            => $"{Metric} | {Column}: Excel={ExcelValue:F4}, DB={DbValue:F4} -> {(Match ? "PASS" : "FAIL")}";
    }
}
