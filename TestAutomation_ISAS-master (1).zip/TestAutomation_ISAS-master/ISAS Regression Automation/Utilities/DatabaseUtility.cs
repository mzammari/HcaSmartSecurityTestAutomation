﻿using ISAS_Regression_Automation.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DatabaseUtility
    {
        public static void ChangeWftRole(string role)
        {
            string DB = RunData.SecurityDB;
            string Query;
            //Delete current role 
            Query = "Delete   FROM [ISAS_Security].[dbo].[SecurityAssignment]  where UserIdentity like '%opt6590%' and role like '%WFT%'";
            CommonFunctions.RunQuery(Query, DB);

            switch (role.ToLower())
            {
                case "facility administrator":
                case "facility admin":
                    Query = "Insert into [ISAS_Security].[dbo].[SecurityAssignment] values ('opt6590@hca.corpad.net','WftFacilityAdministrator','Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',1,null)";
                    CommonFunctions.RunQuery(Query, DB);
                    break;
                case "approver":
                    Query = "Insert into [ISAS_Security].[dbo].[SecurityAssignment] values ('opt6590@hca.corpad.net','WftApprover','Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',1,null)";
                    CommonFunctions.RunQuery(Query, DB);
                    break;
                case "manager":
                    Query = "Insert into [ISAS_Security].[dbo].[SecurityAssignment] values ('opt6590@hca.corpad.net','WftManager','Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',1,null)";
                    CommonFunctions.RunQuery(Query, DB);
                    break;
                case "viewer":
                    Query = "Insert into [ISAS_Security].[dbo].[SecurityAssignment] values ('opt6590@hca.corpad.net','WftViewer','Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',1,null)";
                    CommonFunctions.RunQuery(Query, DB);
                    break;
                case "user administrator":
                case "user admin":
                    Query = "Insert into [ISAS_Security].[dbo].[SecurityAssignment] values ('opt6590@hca.corpad.net','WftUserAdministrator','Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',1,null)";
                    CommonFunctions.RunQuery(Query, DB);
                    break;
                case "administrator":
                case "admin":
                    Console.WriteLine("Admin role is in effect");
                    Query = "Insert into [ISAS_Security].[dbo].[SecurityAssignment] values ('opt6590@hca.corpad.net','WftFacilityAdministrator','Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',1,null)";
                    CommonFunctions.RunQuery(Query, DB);
                    Query = "Insert into [ISAS_Security].[dbo].[SecurityAssignment] values ('opt6590@hca.corpad.net','WftFreezeAdministrator','Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',1,null)";
                    CommonFunctions.RunQuery(Query, DB);
                    Query = "Insert into [ISAS_Security].[dbo].[SecurityAssignment] values ('opt6590@hca.corpad.net','WftManager','Hca.DevBlocks.S3.Framework.Jurisdiction.CorporateJurisdiction, Hca.DevBlocks.S3.Framework',1,null)";
                    CommonFunctions.RunQuery(Query, DB);
                    break;
            }
        }
    }
}
