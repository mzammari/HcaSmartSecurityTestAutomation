﻿using AventStack.ExtentReports.Reporter.Configuration;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ISAS_Regression_Automation
{
    public class ExtentReport
    {
        public static ExtentReports _extentReports;
        public static ExtentReports extent;
        public static ExtentTest _feature;
        public static ExtentTest _scenario;


        //public static String dir = AppDomain.CurrentDomain.BaseDirectory;
        //public static String testResultPath = dir.Replace("bin\\Debug\\net6.0", "TestResults");

        public static void ExtentReportInit()
        {
            String workingDirectory = Environment.CurrentDirectory;
            String projectDirectory = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
            //String reportPath = projectDirectory + "\\index.html";

            // Console.WriteLine("I am inside Extent Report" + reportPath);
            // Create a new report with timestamp for each run
            String timeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");
            //Console.WriteLine(timeStamp);

            // String reportPath = projectDirectory + "Extent_" + timeStamp + ".html";
            //// Console.WriteLine(reportPath);

            String reportPath = Path.Combine(projectDirectory, "Reports\\" + "Extent_" + timeStamp + "\\" + "report.html");
            Console.WriteLine("I am inside Extent Report" + reportPath);
            var htmlReporter = new ExtentHtmlReporter(reportPath);            
            //htmlReporter.Config.ReportName = "Automation Status Report";
            //htmlReporter.Config.DocumentTitle = "Automation Status Report";
            //htmlReporter.Config.Theme = Theme.Standard;
            htmlReporter.Start();

            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);
            extent.AddSystemInfo("Application", "ISAS QA Environment");
            extent.AddSystemInfo("Browser", "Chrome");
            extent.AddSystemInfo("OS", "Windows");


            //_extentReports = new ExtentReports();
            //_extentReports.AttachReporter(htmlReporter);
            //_extentReports.AddSystemInfo("Application", "ISAS QA Environment");
            //_extentReports.AddSystemInfo("Browser", "Chrome");
            //_extentReports.AddSystemInfo("OS", "Windows");

            String configPath = @"C:\Users\LPE4283\source\repos\ISAS NUnit Regression Automation\ISAS Regression Automation\Utilities\extent-config.xml";
            htmlReporter.LoadConfig(configPath);
        }

        public static void ExtentReportTearDown()
        {
            extent.Flush();
        }

        //public string addScreenshot(IWebDriver driver, ScenarioContext scenarioContext)
        //{
        //    ITakesScreenshot takesScreenshot = (ITakesScreenshot)driver;
        //    Screenshot screenshot = takesScreenshot.GetScreenshot();
        //    string screenshotLocation = Path.Combine(testResultPath, scenarioContext.ScenarioInfo.Title + ".png");
        //    screenshot.SaveAsFile(screenshotLocation, ScreenshotImageFormat.Png);
        //    return screenshotLocation;
        //}


    }
}
