﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation.Utilities
{
    class ExcelCreator
    {
        /// <summary>
        /// Creates an Excel workbook with one sheet containing headers and data
        /// </summary>
        /// <param name="filePath">Path where the Excel file will be saved</param>
        /// <param name="sheetName">Name of the worksheet</param>
        /// <param name="headers">List of column headers</param>
        /// <param name="data">List of rows, where each row is a list of values</param>
        public static void CreateExcelFile(string filePath, string sheetName, List<string> headers, List<List<object>> data)
        {
            using (var workbook = new XLWorkbook())
            {
                // Add a worksheet
                var worksheet = workbook.Worksheets.Add(sheetName);

                // Add headers
                for (int i = 0; i < headers.Count; i++)
                {
                    worksheet.Cell(1, i + 1).Value = headers[i];
                }

                // Add data rows
                for (int row = 0; row < data.Count; row++)
                {
                    for (int col = 0; col < data[row].Count && col < headers.Count; col++)
                    {
                       
                            worksheet.Cell(row + 2, col + 1).Value = data[row][col]?.ToString();
                    }
                }

                // Auto-fit columns
                worksheet.ColumnsUsed().AdjustToContents();

                // Save the workbook
                workbook.SaveAs(filePath);
            }
        }
    }
}
