﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

public class ExcelConverter
{
    /// <summary>
    /// Creates Excel by first generating CSV data, then converting to proper Excel format
    /// This approach often works when direct Excel creation fails in Office 365 web
    /// </summary>
    public static void CreateExcelFile(string filePath, string sheetName, List<string> headers, List<List<object>> data)
    {
        // Step 1: Create CSV content
        var csvContent = GenerateCsvContent(headers, data);

        // Step 2: Convert CSV to Excel format
        ConvertCsvToExcel(csvContent, filePath, sheetName);
    }

    /// <summary>
    /// Escapes CSV values properly - takes a string parameter and returns escaped string
    /// </summary>
    private static string EscapeCsvValue(string value)
    {
        if (string.IsNullOrEmpty(value))
            return "\"\"";

        if (value.Contains(",") || value.Contains("\"") || value.Contains("\n") || value.Contains("\r"))
        {
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }

        return "\"" + value + "\"";
    }

    /// <summary>
    /// Generates properly formatted CSV content
    /// </summary>
    private static string GenerateCsvContent(List<string> headers, List<List<object>> data)
    {
        var csvBuilder = new StringBuilder();

        // Add headers
        csvBuilder.AppendLine(string.Join(",", headers.Select(h => EscapeCsvValue(h))));

        // Add data rows
        foreach (var row in data)
        {
            var rowValues = new List<string>();
            for (int i = 0; i < headers.Count; i++)
            {
                string value = "";
                if (i < row.Count && row[i] != null)
                {
                    if (row[i] is DateTime dateValue)
                    {
                        value = dateValue.ToString("MM/dd/yyyy");
                    }
                    else if (row[i] is bool boolValue)
                    {
                        value = boolValue.ToString().ToUpper();
                    }
                    else
                    {
                        value = row[i].ToString();
                    }
                }
                rowValues.Add(EscapeCsvValue(value));
            }
            csvBuilder.AppendLine(string.Join(",", rowValues));
        }

        return csvBuilder.ToString();
    }

    /// <summary>
    /// Converts CSV content to Excel format with proper structure and date formatting
    /// </summary>
    private static void ConvertCsvToExcel(string csvContent, string filePath, string sheetName)
    {
        var lines = csvContent.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

        using (SpreadsheetDocument document = SpreadsheetDocument.Create(filePath, SpreadsheetDocumentType.Workbook))
        {
            WorkbookPart workbookPart = document.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();

            // Create stylesheet for date formatting
            WorkbookStylesPart stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
            stylesPart.Stylesheet = CreateStylesheet();

            // Create shared string table
            SharedStringTablePart sharedStringPart = workbookPart.AddNewPart<SharedStringTablePart>();
            sharedStringPart.SharedStringTable = new SharedStringTable();
            var sharedStrings = new List<string>();

            WorksheetPart worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            worksheetPart.Worksheet = new Worksheet(new SheetData());

            Sheets sheets = workbookPart.Workbook.AppendChild(new Sheets());
            Sheet sheet = new Sheet()
            {
                Id = workbookPart.GetIdOfPart(worksheetPart),
                SheetId = 1,
                Name = sheetName
            };
            sheets.Append(sheet);

            SheetData sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();

            // Process each line
            for (int lineIndex = 0; lineIndex < lines.Length; lineIndex++)
            {
                var values = ParseCsvLine(lines[lineIndex]);
                Row row = new Row() { RowIndex = (uint)(lineIndex + 1) };

                for (int colIndex = 0; colIndex < values.Count; colIndex++)
                {
                    string cellValue = values[colIndex];
                    Cell cell = new Cell() { CellReference = GetColumnName(colIndex) + (lineIndex + 1) };

                    // Try to determine data type
                    if (string.IsNullOrEmpty(cellValue))
                    {
                        cell.DataType = CellValues.String;
                        cell.CellValue = new CellValue("");
                    }
                    else if (double.TryParse(cellValue, out double numValue))
                    {
                        cell.DataType = CellValues.Number;
                        cell.CellValue = new CellValue(numValue.ToString("G17"));

                        // Apply number formatting based on whether it's a decimal
                        if (numValue % 1 != 0) // Has decimal places
                        {
                            cell.StyleIndex = 2; // Decimal format with leading zeros
                        }
                        else // Whole number
                        {
                            cell.StyleIndex = 3; // Integer format with leading zeros
                        }
                    }
                    else if (bool.TryParse(cellValue, out bool boolValue))
                    {
                        cell.DataType = CellValues.Boolean;
                        cell.CellValue = new CellValue(boolValue ? "1" : "0");
                    }
                    else if (DateTime.TryParse(cellValue, out DateTime dateValue))
                    {
                        // Store as Excel date number with proper formatting
                        cell.DataType = CellValues.Number;
                        cell.CellValue = new CellValue(dateValue.ToOADate().ToString("G17"));
                        cell.StyleIndex = 1; // Apply date format style
                    }
                    else
                    {
                        // Add to shared strings
                        if (!sharedStrings.Contains(cellValue))
                        {
                            sharedStrings.Add(cellValue);
                            sharedStringPart.SharedStringTable.AppendChild(new SharedStringItem(new Text(cellValue)));
                        }

                        int stringIndex = sharedStrings.IndexOf(cellValue);
                        cell.DataType = CellValues.SharedString;
                        cell.CellValue = new CellValue(stringIndex.ToString());
                    }

                    row.AppendChild(cell);
                }

                sheetData.AppendChild(row);
            }

            workbookPart.Workbook.Save();
        }
    }

    /// <summary>
    /// Creates stylesheet with proper date and number formatting (including leading zeros)
    /// </summary>
    private static Stylesheet CreateStylesheet()
    {
        Stylesheet stylesheet = new Stylesheet();

        // Number formats
        NumberingFormats numberingFormats = new NumberingFormats() { Count = 3 };

        // Date format
        NumberingFormat dateFormat = new NumberingFormat()
        {
            NumberFormatId = 164, // Custom format ID
            FormatCode = "mm/dd/yyyy" // This ensures MM/dd/yyyy display
        };
        numberingFormats.Append(dateFormat);

        // Decimal format with leading zeros (e.g., 01.50, 123.45)
        NumberingFormat decimalFormat = new NumberingFormat()
        {
            NumberFormatId = 165, // Custom format ID
            FormatCode = "00.00" // Two leading digits, two decimal places
        };
        numberingFormats.Append(decimalFormat);

        // Integer format with leading zeros (e.g., 01, 02, 123)
        NumberingFormat integerFormat = new NumberingFormat()
        {
            NumberFormatId = 166, // Custom format ID
            FormatCode = "00" // Two leading digits for integers
        };
        numberingFormats.Append(integerFormat);

        stylesheet.Append(numberingFormats);

        // Fonts
        Fonts fonts = new Fonts() { Count = 1 };
        Font font = new Font();
        font.Append(new FontSize() { Val = 11 });
        font.Append(new Color() { Rgb = "000000" });
        font.Append(new FontName() { Val = "Calibri" });
        fonts.Append(font);
        stylesheet.Append(fonts);

        // Fills
        Fills fills = new Fills() { Count = 1 };
        fills.Append(new Fill(new PatternFill() { PatternType = PatternValues.None }));
        stylesheet.Append(fills);

        // Borders
        Borders borders = new Borders() { Count = 1 };
        borders.Append(new Border());
        stylesheet.Append(borders);

        // Cell formats
        CellFormats cellFormats = new CellFormats() { Count = 4 };

        // Default format (index 0)
        cellFormats.Append(new CellFormat());

        // Date format (index 1)
        cellFormats.Append(new CellFormat()
        {
            NumberFormatId = 164,
            ApplyNumberFormat = true
        });

        // Decimal format with leading zeros (index 2)
        cellFormats.Append(new CellFormat()
        {
            NumberFormatId = 165,
            ApplyNumberFormat = true
        });

        // Integer format with leading zeros (index 3)
        cellFormats.Append(new CellFormat()
        {
            NumberFormatId = 166,
            ApplyNumberFormat = true
        });

        stylesheet.Append(cellFormats);

        return stylesheet;
    }

    /// <summary>
    /// Simple CSV line parser
    /// </summary>
    private static List<string> ParseCsvLine(string line)
    {
        var result = new List<string>();
        var current = new StringBuilder();
        bool inQuotes = false;

        for (int i = 0; i < line.Length; i++)
        {
            char c = line[i];

            if (c == '"')
            {
                if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                {
                    current.Append('"');
                    i++;
                }
                else
                {
                    inQuotes = !inQuotes;
                }
            }
            else if (c == ',' && !inQuotes)
            {
                result.Add(current.ToString());
                current.Clear();
            }
            else
            {
                current.Append(c);
            }
        }

        result.Add(current.ToString());
        return result;
    }

    /// <summary>
    /// Converts column index to Excel column name (A, B, C, ..., AA, AB, etc.)
    /// </summary>
    private static string GetColumnName(int columnIndex)
    {
        string columnName = "";
        while (columnIndex >= 0)
        {
            columnName = (char)('A' + columnIndex % 26) + columnName;
            columnIndex = columnIndex / 26 - 1;
        }
        return columnName;
    }
}

