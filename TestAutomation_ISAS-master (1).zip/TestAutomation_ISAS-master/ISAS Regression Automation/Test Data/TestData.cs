﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class AdoTestData
    {
        public static string Divison = "18";//North FL
        public static string Facility = "30201"; // Ocala
    }
}
