﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class ExtentReporting
    {
        private static ExtentReports extentReports;
        private static ExtentTest extentTest;

        private static ExtentReports startReporting()
        {
            var path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"..\..\..\..\Results\";
            if(extentReports== null)
            {
                Directory.GetCreationTime(path);
                extentReports = new ExtentReports();
                var htmlReporter = new ExtentHtmlReporter(path);
                extentReports.AttachReporter(htmlReporter);
                extentReports.AddSystemInfo("Application", "ISAS QA Environment");
                extentReports.AddSystemInfo("Browser", "Chrome");
                extentReports.AddSystemInfo("OS", "Windows");
                htmlReporter.Config.Theme = Theme.Dark;
            }
            return extentReports;
        }

        public static void CreateTest(string testName)
        {
            extentTest = startReporting().CreateTest(testName);
        }
        public static void EndReporting()
        {
            startReporting().Flush();
        }
        public static void LogInfo(string info)
        {
            extentTest.Info(info);
        }
        public static void LogPass(string info)
        {
            extentTest.Pass(info);
        }
        public static void LogFail(string info)
        {
            extentTest.Fail(info);
        }
        public static void LogScreenshot(string info, string image)
        {
            extentTest.Info(info, MediaEntityBuilder.CreateScreenCaptureFromBase64String(image).Build());   
        }
    }
}
