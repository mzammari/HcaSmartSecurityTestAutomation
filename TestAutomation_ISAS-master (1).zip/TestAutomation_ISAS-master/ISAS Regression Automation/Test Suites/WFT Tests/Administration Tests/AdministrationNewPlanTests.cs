﻿using AventStack.ExtentReports.Model;
using DocumentFormat.OpenXml.Wordprocessing;
using ISAS_Regression_Automation.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using static ISAS_Regression_Automation.EmployedAndContractFteCountsSP;
using static ISAS_Regression_Automation.ForecastView_ContractPercent;
using static ISAS_Regression_Automation.ForecastView_NonProductivePercent;
using static ISAS_Regression_Automation.ForecastView_OTPercent;
using static ISAS_Regression_Automation.ForecastView_Standards;
using static ISAS_Regression_Automation.ForecastView_Volume;
using System.Threading.Tasks;
using DocumentFormat.OpenXml.Bibliography;
using static ISAS_Regression_Automation.ForecastView_ProdHrsAndFTEs;
using static ISAS_Regression_Automation.AverageLaborRateCL;


namespace ISAS_Regression_Automation
{
    [TestFixture]
    
    public class AdministrationNewPlanTests : Driver
    {
        public static string VarAndSemiVarDept = SettingData.FacStatMappingSemiVariableDept;

        [Test]
        public async Task VerifyFacilityLaborSummaryYearlyReport()
        {

            string filePath;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string Year = CommonFunctions.GetCurrentYear();
            string fileName = "FacilityLaborReportExpToExl.XLS";

            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            var VarAndSemiVarDeptII = "675";
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();

            var DeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VarAndSemiVarDeptII);
            var planID = DeptDetails.PlanID;

            FacilityLaborSummaryYearly.GoTo();
            Assert.True(FacilityLaborSummaryYearly.IsAt, "Facility Labor Summary- Yearly report was not displayed.");
            FacilityLaborSummaryYearly.Report()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .SelectExcel();


            filePath = CommonFunctions.getDownloadedFile(fileName);

            // --- Expected: Excel "Facility Goal" column -------------------------
            var metrics = new List<string>
            {
                "Employed (Productive) FTEs",
                "Contract Labor %",
                "Contract FTEs",
                "Total Productive FTEs",
                "Employed Non-Productive %",
                "Non-Productive FTEs",
                "Employed (Paid) FTEs",
                "Total FTEs (Paid + Contract)",
                "Total Salaries & Wages ($000)",
                "Total Contract Labor  ($000)",   // double space before ($000)
                "Total Labor Expense  ($000)",    // double space before ($000)
                "Employed Labor Rate",
                "Contract Labor Rate",
                "Overtime Premium Dollars",
                "Overtime %",
                "Overtime FTEs",
                "Admissions",
                "Adjusted Admissions",
                "Patient Days",
                "APD",
                "ER Visits",
                "Outpatient Visits",
                "OP Factor",
                "ALOS",
                "EEOB",
                "MH/AA",
            };

            var columns = new List<string> { "Forecast", "Facility Goal", "Prior 12 Mon", "% Change" };
            var excelData = FacilityLaborSummaryYearlyExcel.getFacilityLaborSummaryYearlyExcelData(filePath, metrics, columns);
            

            // --- Actual (source of truth): DB row -> FacilityGoal object --------
            var runner = new StoredProcedureRunner();
            LaborMetricRow row = await runner.GetLaborMetricRowAsync(
                "rpt_GetLaborSumFacility",
                new Dictionary<string, object?> { ["PlanID"] = 235984780 });

            LaborSummaryYearlyFacilityGoal facilityGoal =
                LaborSummaryYearlyFacilityGoal.FromLaborMetricRow(row);

            var forecastMiss = LaborSummarySectionComparer.Compare(LaborSummaryYearlyForecast.FromLaborMetricRow(row).ToLabeledValues(), excelData, "Forecast", 5);
            var facilityGoalMiss = LaborSummarySectionComparer.Compare(LaborSummaryYearlyFacilityGoal.FromLaborMetricRow(row).ToLabeledValues(), excelData, "Facility Goal", 5);
            var prior12Miss = LaborSummarySectionComparer.Compare(LaborSummaryYearlyPrior12Month.FromLaborMetricRow(row).ToLabeledValues(), excelData, "Prior 12 Mon", 5);
            var pctChangeMiss = LaborSummarySectionComparer.Compare(LaborSummaryYearlyPercentChange.FromLaborMetricRow(row).ToLabeledValues(), excelData, "% Change", 5);

            Assert.Multiple(() =>
            {
                Assert.That(forecastMiss, Is.Empty, $"Forecast mismatches:{Environment.NewLine}{string.Join(Environment.NewLine, forecastMiss)}");
                Assert.That(facilityGoalMiss, Is.Empty, $"Facility Goal mismatches:{Environment.NewLine}{string.Join(Environment.NewLine, facilityGoalMiss)}");
                Assert.That(prior12Miss, Is.Empty, $"Prior 12 Mon mismatches:{Environment.NewLine}{string.Join(Environment.NewLine, prior12Miss)}");
                Assert.That(pctChangeMiss, Is.Empty, $"% Change mismatches:{Environment.NewLine}{string.Join(Environment.NewLine, pctChangeMiss)}");
            });
        }

        [Test]
        public void VerifyEmployedContractCountsReportData()
        {
            string filePath;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string Year = CommonFunctions.GetNextYear();
            string fileName = "EmployedContractCountsReportExpToExl.XLS";
            
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            var VarAndSemiVarDeptII = "675";
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            DepartmentForecastPlanFilter.GetCurrentPlanName();
            var bDeptInGroup = DepartmentForecastPlanFilter.IsDeptInGroup(VarAndSemiVarDeptII);

            //DB part
            var EmployedAndContractFTECountsDBData = LaborForecastRepository.GetLaborForecastData(0);

            EmployedAndContractFTECountsReport.GoTo();
            Assert.True(EmployedAndContractFTECountsReport.IsAt, "Employed And Contract FTE Counts Report was not displayed");
            EmployedAndContractFTECountsReport.Report()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(RunData.CurrentPlanName)
                .SelectExcel();
            Thread.Sleep(5000);
            //Take only Previous (0) values 
            var objPreviousDeptData = EmployedAndContractFTECountsDBData.Where(x => x.DeptNumber == VarAndSemiVarDeptII).ToList();
            filePath = CommonFunctions.getDownloadedFile(fileName);
            var EmployedAndContractFTECountsExcelReportData = EmployedAndContractFTECountsExcelReport.ParseEmployedAndContractFTECountsExcelReport(filePath);
            var DeptEmployedAndContractFTECountsExcelReportData = EmployedAndContractFTECountsExcelReportData.Where(x => x.Dept == VarAndSemiVarDeptII).ToList();
            var isMatched = EmployedAndContractFTECountsExcelReport.VerifyEmployedContractCountsReportDataAgainstDB(DeptEmployedAndContractFTECountsExcelReportData, objPreviousDeptData);
            Assert.True(isMatched, "Data in Employed And Contract FTE Counts Report does not match with DB data.");

        }

        [Test]
        public void VerifyEmployedContractCostReportData()
        {
            string filePath;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string Year = CommonFunctions.GetNextYear();
            string fileName = "EmployedContractCostsReportExpToExl.XLS";

            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            var VarAndSemiVarDeptII = "675";
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            DepartmentForecastPlanFilter.GetCurrentPlanName();
            var bDeptInGroup = DepartmentForecastPlanFilter.IsDeptInGroup(VarAndSemiVarDeptII);

            var EmployedAndContractFTECostDBData = LaborForecastRepository.GetLaborForecastData(0);

            EmployedAndContractFTECostReport.GoTo();
            Assert.True(EmployedAndContractFTECostReport.IsAt, "Employed And Contract FTE Cost Report was not displayed");
            EmployedAndContractFTECountsReport.Report()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(RunData.CurrentPlanName)
                .SelectExcel();
            Thread.Sleep(5000);
            //Take only Previous (0) values 
            var DBDeptData = EmployedAndContractFTECostDBData.Where(x => x.DeptNumber == VarAndSemiVarDeptII).ToList();
            filePath = CommonFunctions.getDownloadedFile(fileName);
            var EmployedAndContractFTECostExcelReportData = EmployedAndContractFteCostExcelReport.ParseEmployedAndContractFteCostExcelReport(filePath);
            var DeptEmployedAndContractFTECostExcelReportData = EmployedAndContractFTECostExcelReportData.Where(x => x.Dept == VarAndSemiVarDeptII).ToList();
            var isMatched = EmployedAndContractFteCostExcelReport.VerifyEmployedContractCostReportDataAgainstDB(DeptEmployedAndContractFTECostExcelReportData, DBDeptData);
            Assert.True(isMatched, "Data in Employed And Contract FTE Cost Report does not match with DB data.");

        }

        [Test]
        public void VerifyLaborSummaryMonthlyExcelReportData()
        {
            string filePath;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string Year = CommonFunctions.GetNextYear();
            string fileName = "MonthlyDeptLaborReportExpToExl.XLS";

            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            var VarAndSemiVarDeptII = "675";
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            DepartmentForecastPlanFilter.GetCurrentPlanName();
            var bDeptInGroup = DepartmentForecastPlanFilter.IsDeptInGroup(VarAndSemiVarDeptII);

            var EmployedAndContractFTECostDBData = LaborForecastRepository.GetLaborForecastData(0);

            LaborSummaryMonthlyReport.GoTo();
            Assert.True(LaborSummaryMonthlyReport.IsAt, "Labor Summary Monthly Report was not displayed");
            LaborSummaryMonthlyReport.Report()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(RunData.CurrentPlanName)
                .withDepartment(VarAndSemiVarDeptII)
                .SelectExcel();
            Thread.Sleep(15000);
            //Take only Previous (0) values 
            var DBDeptData = EmployedAndContractFTECostDBData.Where(x => x.DeptNumber == VarAndSemiVarDeptII).ToList();
            filePath = CommonFunctions.getDownloadedFile(fileName);
            LaborSummaryMonthlyExcelReport laborSummaryMonthlyReport = new LaborSummaryMonthlyExcelReport();
            var LaborSummaryMonthlyReportExcelData = laborSummaryMonthlyReport.GetDepartmentData(filePath, VarAndSemiVarDeptII);
            Console.WriteLine(  );
            var LaborSummaryMonthlyDBData = WftDepartmentLoader.GetLaborSummaryMonthlyDBData(VarAndSemiVarDeptII);
            Console.WriteLine(  );

            LaborSummaryValidator.Validate(LaborSummaryMonthlyReportExcelData, LaborSummaryMonthlyDBData);
           // var isMatched = EmployedAndContractFteCostExcelReport.VerifyEmployedContractCostReportDataAgainstDB(DeptEmployedAndContractFTECostExcelReportData, DBDeptData);
           // Assert.True(isMatched, "Data in Employed And Contract FTE Cost Report does not match with DB data.");

        }

        [Test]
        public void VerifyLaborSummaryTotalMonthlyComparisonReportData()
        {
            string filePath;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string Year = CommonFunctions.GetNextYear();
            string fileName = "CompareMonthlyDeptLaborReportExptoExl.XLS";

            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            var VarAndSemiVarDeptII = "675";
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            var lstWorkingPlans = DepartmentForecastPlanFilter.GetExistingPlanNames("W");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(lstWorkingPlans[0])
                .Select();
            //Get Plan 1 ID.
            RunData.PlanID = AdminPlanDetail.getPlanID();
            DepartmentForecastPlanFilter.GetCurrentPlanName();
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus("Working")
               .withPlan(lstWorkingPlans[1])
               .Select();
            // Get Plan 2 ID
            RunData.PlanTwoID = AdminPlanDetail.getPlanID();
            RunData.Deptartment = VarAndSemiVarDeptII;

            Console.WriteLine($"Plan1 ID = {RunData.PlanID}\n" +
                $"Plan2 ID = {RunData.PlanTwoID}");

            // We need Plan1, Plan2, and dept to get comparison data from DB.
            var MonthlyFacilityTotalComparisonDBData = MonthlyFacilityTotalSqlLoader.LoadFromSql();

            LaborSummaryMonthlyComparisonReport.GoTo();
            Assert.True(LaborSummaryMonthlyComparisonReport.IsAt, "Labor Summary Monthly Comparison Report Report was not displayed");
            LaborSummaryMonthlyComparisonReport.Report()
                .withPlan1Year(Year)
                .withPlan1Status("Working")
                .withPlan1Name(lstWorkingPlans[0])
                .withPlan1Dept(VarAndSemiVarDeptII)
                .withPlan2Year(Year)
                .withPlan2Status("Working")
                .withPlan2Name(lstWorkingPlans[1])
                .withPlan2Dept(VarAndSemiVarDeptII)
                .SelectExcelFormat();

            Thread.Sleep(15000);
            
            filePath = CommonFunctions.getDownloadedFile(fileName);
            //Get Excel data
            var MonthlyFacilityTotalComparisonExcelData = MonthlyFacilityTotalExcelParser.ParseExcelData(filePath);
            //Compare DB vs Excel
            // Assertion is already in included in the Validate method.
            //MonthlyFacilityTotalValidator.Validate(MonthlyFacilityTotalComparisonDBData, MonthlyFacilityTotalComparisonExcelData);
            MonthlyFacilityTotalValidator.Validate(MonthlyFacilityTotalComparisonDBData, MonthlyFacilityTotalComparisonDBData);
        }

        [Test]
        public void VerifyLaborSummaryMonthlyDetailComparisonReportData()
        {
            string filePath;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string Year = CommonFunctions.GetNextYear();
            string fileName = "CompareMonthlyDeptLaborReportExptoExl.XLS";

            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            var VarAndSemiVarDeptII = "675";
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            var lstWorkingPlans = DepartmentForecastPlanFilter.GetExistingPlanNames("W");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(lstWorkingPlans[0])
                .Select();
            //Get Plan 1 ID.
            RunData.PlanID = AdminPlanDetail.getPlanID();
            DepartmentForecastPlanFilter.GetCurrentPlanName();
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus("Working")
               .withPlan(lstWorkingPlans[1])
               .Select();
            // Get Plan 2 ID
            RunData.PlanTwoID = AdminPlanDetail.getPlanID();
            RunData.Deptartment = VarAndSemiVarDeptII;

            Console.WriteLine($"Plan1 ID = {RunData.PlanID}\n" +
                $"Plan2 ID = {RunData.PlanTwoID}");

            // We need Plan1, Plan2, and dept to get comparison data from DB.
            var MonthlyFacilityDetailComparisonDBData = MonthlyDepartmentDetailSqlLoader.LoadFromSql();

            LaborSummaryMonthlyComparisonReport.GoTo();
            Assert.True(LaborSummaryMonthlyComparisonReport.IsAt, "Labor Summary Monthly Comparison Report Report was not displayed");
            LaborSummaryMonthlyComparisonReport.Report()
                .withPlan1Year(Year)
                .withPlan1Status("Working")
                .withPlan1Name(lstWorkingPlans[0])
                .withPlan1Dept(VarAndSemiVarDeptII)
                .withPlan2Year(Year)
                .withPlan2Status("Working")
                .withPlan2Name(lstWorkingPlans[1])
                .withPlan2Dept(VarAndSemiVarDeptII)
                .SelectExcelFormat();

            Thread.Sleep(15000);

            filePath = CommonFunctions.getDownloadedFile(fileName);
            //Get Excel data
            var MonthlyFacilityDetailComparisonExcelData = MonthlyDeptDetailExcelParser.ParseAll(filePath);

            //Compare DB vs Excel
            // Assertion is already in included in the Validate method.            
            MonthlyDepartmentDetailValidator.Validate(MonthlyFacilityDetailComparisonDBData, MonthlyFacilityDetailComparisonDBData);
        }




        private LaborForecastCalculatedData GetLaborForecastCalculatedData(List<LaborForecastData> objPreviousDeptData, List<LaborForecastData> objCurrentDeptData)
        {
            // FTEs Paid
            var CalculatedFTEsPaidForecast = objPreviousDeptData.FirstOrDefault().FTEsProdForecast - objCurrentDeptData.FirstOrDefault().FTEsProdForecast;
            var CalculatedFTEsPaidPrior = objPreviousDeptData.FirstOrDefault().FTEsPaidPrior - objCurrentDeptData.FirstOrDefault().FTEsPaidPrior;
            var CalculatedFTEsPaidVar = objPreviousDeptData.FirstOrDefault().FTEsPaidVar - objCurrentDeptData.FirstOrDefault().FTEsPaidVar;


            // FTEs Prod
            var CalculatedFTEsProdForecast = objPreviousDeptData.FirstOrDefault().FTEsProdForecast - objCurrentDeptData.FirstOrDefault().FTEsProdForecast;
            var CalculatedFTEsProdPrior = objPreviousDeptData.FirstOrDefault().FTEsProdPrior - objCurrentDeptData.FirstOrDefault().FTEsProdPrior;
            var CalculatedFTEsProdVar = objPreviousDeptData.FirstOrDefault().FTEsProdVar - objCurrentDeptData.FirstOrDefault().FTEsProdVar;

            // FTEs Contract
            var CalculatedFTEsContractForecast = objPreviousDeptData.FirstOrDefault().FTEsContractForecast - objCurrentDeptData.FirstOrDefault().FTEsContractForecast;
            var CalculatedFTEsContractPrior = objPreviousDeptData.FirstOrDefault().FTEsContractPrior - objCurrentDeptData.FirstOrDefault().FTEsContractPrior;
            var CalculatedFTEsContractVar = objPreviousDeptData.FirstOrDefault().FTEsContractVar - objCurrentDeptData.FirstOrDefault().FTEsContractVar;

            // Salary
            var CalculatedSalaryForecast = objPreviousDeptData.FirstOrDefault().SalaryForecast - objCurrentDeptData.FirstOrDefault().SalaryForecast;
            var CalculatedSalaryPrior = objPreviousDeptData.FirstOrDefault().SalaryPrior - objCurrentDeptData.FirstOrDefault().SalaryPrior;
            var CalculatedSalaryVar = objPreviousDeptData.FirstOrDefault().SalaryVar - objCurrentDeptData.FirstOrDefault().SalaryVar;

            // Labor Salary
            var CalculatedLaborSalaryForecast = objPreviousDeptData.FirstOrDefault().LaborSalaryForecast - objCurrentDeptData.FirstOrDefault().LaborSalaryForecast;
            var CalculatedLaborSalaryPrior = objPreviousDeptData.FirstOrDefault().LaborSalaryPrior - objCurrentDeptData.FirstOrDefault().LaborSalaryPrior;
            var CalculatedLaborSalaryVar = objPreviousDeptData.FirstOrDefault().LaborSalaryVar - objCurrentDeptData.FirstOrDefault().LaborSalaryVar;

            // Total
            var CalculatedTotalSalaryVar = objPreviousDeptData.FirstOrDefault().TotalSalaryVar - objCurrentDeptData.FirstOrDefault().TotalSalaryVar;

            // Employed Labor Rate
            var CalculatedEmployedLaborRateForecast = objPreviousDeptData.FirstOrDefault().EmployedLaborRateForecast - objCurrentDeptData.FirstOrDefault().EmployedLaborRateForecast;
            var CalculatedEmployedLaborRatePrior = objPreviousDeptData.FirstOrDefault().EmployedLaborRatePrior - objCurrentDeptData.FirstOrDefault().EmployedLaborRatePrior;
            var CalculatedEmployedLaborRateVar = objPreviousDeptData.FirstOrDefault().EmployedLaborRateVar - objCurrentDeptData.FirstOrDefault().EmployedLaborRateVar;

            // Contract Labor Rate
            var CalculatedContractLaborRateForecast = objPreviousDeptData.FirstOrDefault().ContractLaborRateForecast - objCurrentDeptData.FirstOrDefault().ContractLaborRateForecast;
            var CalculatedContractLaborRatePrior = objPreviousDeptData.FirstOrDefault().ContractLaborRatePrior - objCurrentDeptData.FirstOrDefault().ContractLaborRatePrior;
            var CalculatedContractLaborRateVar = objPreviousDeptData.FirstOrDefault().ContractLaborRateVar - objCurrentDeptData.FirstOrDefault().ContractLaborRateVar;

            // OT Percent
            var CalculatedOTPercentForecast = objPreviousDeptData.FirstOrDefault().OTPercentForecast - objCurrentDeptData.FirstOrDefault().OTPercentForecast;
            var CalculatedOTPercentPrior = objPreviousDeptData.FirstOrDefault().OTPercentPrior - objCurrentDeptData.FirstOrDefault().OTPercentPrior;
            var CalculatedOTPercentVar = objPreviousDeptData.FirstOrDefault().OTPercentVar - objCurrentDeptData.FirstOrDefault().OTPercentVar;


            return new LaborForecastCalculatedData()
            {
                DeptNumber = objPreviousDeptData.FirstOrDefault().DeptNumber,
                DeptName = objPreviousDeptData.FirstOrDefault().DeptName,

                // FTEs Paid
                FTEsPaidForecast = CalculatedFTEsPaidForecast,
                FTEsPaidPrior = CalculatedFTEsPaidPrior,
                FTEsPaidVar = CalculatedFTEsPaidVar,
                FTEsPaidVarPercent = CalculateVariancePercent(CalculatedFTEsPaidPrior, CalculatedFTEsPaidVar),

                // FTEs Prod
                FTEsProdForecast = CalculatedFTEsProdForecast,
                FTEsProdPrior = CalculatedFTEsProdPrior,
                FTEsProdVar = CalculatedFTEsProdVar,
                FTEsProdVarPercent = CalculateVariancePercent(CalculatedFTEsProdPrior, CalculatedFTEsProdVar),

                // FTEs Contract
                FTEsContractForecast = CalculatedFTEsContractForecast,
                FTEsContractPrior = CalculatedFTEsContractPrior,
                FTEsContractVar = CalculatedFTEsContractVar,
                FTEsContractVarPercent = CalculateVariancePercent(CalculatedFTEsContractPrior, CalculatedFTEsContractVar),

                // Salary
                SalaryForecast = CalculatedSalaryForecast,
                SalaryPrior = CalculatedSalaryPrior,
                SalaryVar = CalculatedSalaryVar,
                SalaryVarPercent = CalculateVariancePercent(CalculatedSalaryPrior, CalculatedSalaryVar),

                // Labor Salary
                LaborSalaryForecast = CalculatedLaborSalaryForecast,
                LaborSalaryPrior = CalculatedLaborSalaryPrior,
                LaborSalaryVar = CalculatedLaborSalaryVar,
                LaborSalaryVarPercent = CalculateVariancePercent(CalculatedLaborSalaryPrior, CalculatedLaborSalaryVar),

                // Total
                TotalSalaryVar = CalculatedTotalSalaryVar,

                // Employed Labor Rate
                EmployedLaborRateForecast = CalculatedEmployedLaborRateForecast,
                EmployedLaborRatePrior = CalculatedEmployedLaborRatePrior,
                EmployedLaborRateVar = CalculatedEmployedLaborRateVar,
                EmployedLaborRateVarPercent = CalculateVariancePercent(CalculatedEmployedLaborRatePrior, CalculatedEmployedLaborRateVar),

                // Contract Labor Rate
                ContractLaborRateForecast = CalculatedContractLaborRateForecast,
                ContractLaborRatePrior = CalculatedContractLaborRatePrior,
                ContractLaborRateVar = CalculatedContractLaborRateVar,
                ContractLaborRateVarPercent = CalculateVariancePercent(CalculatedContractLaborRatePrior, CalculatedContractLaborRateVar),

                // OT Percent
                OTPercentForecast = CalculatedOTPercentForecast,
                OTPercentPrior = CalculatedOTPercentPrior,
                OTPercentVar = CalculatedOTPercentVar,
                OTPercentVarPercent = CalculateVariancePercent(CalculatedOTPercentPrior, CalculatedOTPercentVar)
            };
        }

        private double CalculateVariancePercent(double previousValue, double currentValue)
        {
            return (currentValue - previousValue)/(previousValue * 100);
        }


        [Test]
        [Category("WFT")]
        public void UserCanVerifyHistbuttonFunctionality()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Department Details Journey";

            bool bHistResult, bPlusResult, bHistDeptFacRatio, bAugValuesMatch;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            var VarAndSemiVarDeptII = "647"; 
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("1.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create(); 

            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
                .withIgnoredInWFT(false)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();

            AdminMenu.GoToForecast();
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VarAndSemiVarDept);
            CommonFunctions.WaitUntilPageIsAcive();
            ForecastView_Volume.DeptFacilityRatio.ClickHist();
            DeptForecastButtonPanel.clickSaveAndRecalc();
            var HistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var DeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            bHistResult = HistDeptFacilityRatioData.Jan == DeptFacilityRatioData.Jan;
            Assert.True(bHistResult, $"HistDeptFacilityRatioData.Jan: {HistDeptFacilityRatioData.Jan}\n" +
                $"DeptFacilityRatioData.Jan: {DeptFacilityRatioData.Jan}");

            //bHistResult = verifyPLUSandHistCalcInVolumeFcastStat6100();
            //Assert.True(bHistResult, "Hist functionality is not working");
            //ForecastView_Volume.PLUSVolume.ClickPLUS();
            //DeptForecastButtonPanel.clickSaveAndRecalc();
            //bPlusResult = verifyPLUSandHistCalcInVolumeFcastStat6100();
            //Assert.True(bPlusResult, "PLUS functionality is not working");


            var VolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var FacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            HistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var expectedHistDeptFacRatio = Math.Round(VolumefcastStat6100Data.Jan / FacilityStatsData.Jan, 3);
            bHistDeptFacRatio = expectedHistDeptFacRatio == HistDeptFacilityRatioData.Jan;
            Assert.True(bHistDeptFacRatio, $"expectedHistDeptFacRatio: {expectedHistDeptFacRatio}\n" +
                $"HistDeptFacilityRatioData.Jan: {HistDeptFacilityRatioData.Jan}");

            //Double click Hist cell
            IWebElement HistAug = CommonFunctions.getElement(By.XPath("//input[@id='txtHistDeptFacilityRatio-8']"));
            CommonFunctions.DoubleClickUsingWebElement(HistAug);
            DeptForecastButtonPanel.clickSaveAndRecalc();
            Thread.Sleep(2000);
            DeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            bAugValuesMatch = HistDeptFacilityRatioData.Aug == DeptFacilityRatioData.Dec &&
                HistDeptFacilityRatioData.Aug == DeptFacilityRatioData.Mar;
            Assert.True(bAugValuesMatch, $"Double-click functionality\n" +
                $"HistDeptFacilityRatioData.Aug: {HistDeptFacilityRatioData.Aug}\n" +
                $"DeptFacilityRatioData.Dec: {DeptFacilityRatioData.Dec}\n" +
                $"DeptFacilityRatioData.Mar: {DeptFacilityRatioData.Mar}");

            //Calc Daily Volume = volFcastStat6100.Jan/31 (31 days)
            VolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var VolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();
            var DailyVolumCalc = Math.Round(VolumefcastStat6100Data.Jan / 31, MidpointRounding.AwayFromZero);
            bool bDailyVolumCalcMatch = DailyVolumCalc == VolumeDailyAverageVolumeData.Jan;
            Assert.True(bDailyVolumCalcMatch, $"bDailyVolumCalcMatch: DailyVolumCalc:{DailyVolumCalc}\n" +
                $"VolumeDailyAverageVolumeData.Jan: {VolumeDailyAverageVolumeData.Jan}");

            //Calc Total Daily Volume
            var numberOfDaysInCurrentYear = CommonFunctions.IsLeapYear();
            var TotalDailyVolCalc = Math.Round(VolumefcastStat6100Data.Total / numberOfDaysInCurrentYear, MidpointRounding.AwayFromZero);
            VolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();
            bool bTotalDailyVolCalcMatch = VolumeDailyAverageVolumeData.Total == TotalDailyVolCalc;
            Assert.True(bTotalDailyVolCalcMatch, $"bTotalDailyVolCalcMatch\n" +
                $"VolumeDailyAverageVolumeData.Total: {VolumeDailyAverageVolumeData.Total}\n" +
                $"TotalDailyVolCalc: {TotalDailyVolCalc}");

            //Verify colors
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
                .withIgnoredInWFT(false)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(true)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            AdminMenu.GoToForecast();
            var deptDetail = DeptForecastDepartmentDetails.GetDeptDetails(VarAndSemiVarDept);
            CommonFunctions.WaitUntilPageIsAcive();
            var VolumefcastStat6100Elements = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Elements();
            CommonFunctions.DoubleClickUsingWebElement(VolumefcastStat6100Elements.Jan);
            CommonFunctions.WaitUntilPageIsAcive();
            var VolumeDailyAverageVolumeElements = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeElements();
            CommonFunctions.GetColorInTwoObjects(VolumefcastStat6100Elements, VolumeDailyAverageVolumeElements);
            bool IsColorMatch = CommonFunctions.CompareColorInTwoObjects(VolumefcastStat6100Elements, VolumeDailyAverageVolumeElements);
            Assert.True(IsColorMatch, "Colors in 2 objects did not match");

            //next and previous button
            IWebElement cmdNext = CommonFunctions.getElement(By.Id("btnNextDept"));
            CommonFunctions.ClickByJE(cmdNext);
            string NavigateAwayXpath = "//*/div[@aria-labelledby='ui-dialog-title-dirtypage-nav-with-save-confirm']//button/span[text()='Yes']";
            bool bExist = CommonFunctions.IsElementDisplayed(NavigateAwayXpath, 2);
            Assert.True(bExist, "Clicking next button did not trigger the navigate-away popup");
            //IWebElement cmdYes = CommonFunctions.getElement(By.XPath(NavigateAwayXpath));
            //CommonFunctions.ClickByJE(cmdYes);
            //CommonFunctions.WaitUntilPageIsAcive();
        }

        private bool verifyPLUSandHistCalcInVolumeFcastStat6100()
        {
            bool Result;
            var FacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var DeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var VolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var ExpectedResult = Math.Ceiling(FacilityStatsData.Jan * DeptFacilityRatioData.Jan);
            Console.WriteLine($"ExpectedResult: {ExpectedResult}");
            Result = ExpectedResult == VolumefcastStat6100Data.Jan ? true : false;
            return Result;
        }

        [Test]
        [Category("WFT")]
        public void VerifySvStepTargetCopyFunctionality()
        {
            string SemiVariableDept = "600";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("30201");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");

            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(CommonFunctions.GetNextYear())
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();

            var SemiVariableDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SemiVariableDept);
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();

            var originalSource = SVFTEStepTargets.GetAllMonthlyStepTargetsValues();
            originalSource["Jan"][0].Copy.Click();
            var CopyTargetRowToOtherMonths = SVFTEStepTargets.GetCopyTargetRowToOtherMonths();
            SVFTEStepTargets.UncheckAllMonths(CopyTargetRowToOtherMonths);
            //Copy Jan to Nov and Dec
            SVFTEStepTargets.ClickMonths(CopyTargetRowToOtherMonths, "Nov", "Dec");
            SVFTEStepTargets.SaveStepTargets();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastButtonPanel.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
            //Open the dialaog again to verify the values are copied to Nov and Dec.
            PLUSStdSV_FTEs.Edit();
            Thread.Sleep(2000);
            var newSource = SVFTEStepTargets.GetAllMonthlyStepTargetsValues();
            SVFTEStepTargets.CancelStepTargets();


            //Verify that Nov and Dec are match with Jan
            var diffNov = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Jan"][0], newSource["Nov"][0]);
            var diffDec = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Jan"][0], newSource["Dec"][0]);
            Assert.IsTrue(diffNov.Count == 0, "Nov values are not the same as Jan");
            Assert.IsTrue(diffDec.Count == 0, "Dec values are not the same as Jan");

            //newSourceerify other months are still the same and didn't change. 
            var diffFeb = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Feb"][0], newSource["Feb"][0]);
            var diffMar = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Mar"][0], newSource["Mar"][0]);
            var diffApr = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Apr"][0], newSource["Apr"][0]);
            var diffMay = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["May"][0], newSource["May"][0]);
            var diffJun = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Jun"][0], newSource["Jun"][0]);
            var diffJul = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Jul"][0], newSource["Jul"][0]);
            var diffAug = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Aug"][0], newSource["Aug"][0]);
            var diffSep = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Sep"][0], newSource["Sep"][0]);
            var diffOct = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSource["Oct"][0], newSource["Oct"][0]);

            Assert.IsTrue(diffFeb.Count == 0, "Feb values are not the same as before");
            Assert.IsTrue(diffMar.Count == 0, "Mar values are not the same as before");
            Assert.IsTrue(diffApr.Count == 0, "Apr values are not the same as before");
            Assert.IsTrue(diffMay.Count == 0, "May values are not the same as before");
            Assert.IsTrue(diffJun.Count == 0, "Jun values are not the same as before");
            Assert.IsTrue(diffJul.Count == 0, "Jul values are not the same as before");
            Assert.IsTrue(diffAug.Count == 0, "Aug values are not the same as before");
            Assert.IsTrue(diffSep.Count == 0, "Sep values are not the same as before");
            Assert.IsTrue(diffOct.Count == 0, "Oct values are not the same as before");


            //Add rows to Jan and then copy the third row to Dec.
            DeptForecastDepartmentDetails.GetDeptDetails("603");
            PLUSStdSV_FTEs.Edit();
            var originalSource1 = SVFTEStepTargets.GetAllMonthlyStepTargetsValues();             
            if(originalSource1["Jan"].Count > 1)
            {
                Console.WriteLine("3 rows are added to Jan");
            }
            else
            {
                originalSource1["Jan"][0].Add.Click();
                originalSource1["Jan"][0].Add.Click();
                var originalSourceElementsAfterAddingRows = SVFTEStepTargets.GetAllMonthlyStepTargetsElements();
                SVFTEStepTargets.AddStepTargetRows(originalSourceElementsAfterAddingRows["Jan"]);
                SVFTEStepTargets.SaveStepTargets();
                CommonFunctions.WaitUntilPageIsAcive();
                PLUSStdSV_FTEs.Edit();
            }

            var originalSourceElements = SVFTEStepTargets.GetAllMonthlyStepTargetsElements();
            //Get all rows with the new added rows. This is to verify that the new added rows are copied to Dec.
            var originalSourceWithAddedRows = SVFTEStepTargets.GetAllMonthlyStepTargetsValues();
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(2000);
            originalSourceElements["Jan"][2].Copy.Click();
            CopyTargetRowToOtherMonths = SVFTEStepTargets.GetCopyTargetRowToOtherMonths();
            SVFTEStepTargets.UncheckAllMonths(CopyTargetRowToOtherMonths);
            //Copy Jan[2] to  Dec
            SVFTEStepTargets.ClickMonths(CopyTargetRowToOtherMonths, "Dec");
            Thread.Sleep(2000);
            CommonFunctions.WaitUntilPageIsAcive();
            var newSourceWithAddedRows = SVFTEStepTargets.GetAllMonthlyStepTargetsValues();

            var diffDecThirdRow = SVFTEStepTargets.GetMonthlyStepTargetsDifferences(originalSourceWithAddedRows["Jan"][2], newSourceWithAddedRows["Dec"][2]);
            Assert.IsTrue(diffDecThirdRow.Count == 0, "Dec[2] values don't match Jan[2]");
            SVFTEStepTargets.ClickRestPlusData();
            SVFTEStepTargets.SaveStepTargets();
            DeptForecastButtonPanel.clickSaveAndRecalc();
        }


        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifytheJourneyOfVolumeSectionInDepartmentForecastpage()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Volume section in Department Forecast page";
            string VariableAndSemiVariableDept;
            bool isMatched;
            VariableAndSemiVariableDept = "604";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("34222");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string Year = CommonFunctions.GetNextYear();
            string PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("1.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            AdminMenu.GoToForecast();

            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);

            //Testing Double-click Average Labor Rate - Empl
            DeptForecastButtonPanel.GoToAdmin();
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "Average Labor Rate Empl page was displayed.");

            var QMIRSEmplLbrRateData = AverageLaborRateEmpl.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            double QMIRSEmplLbrRateMar = QMIRSEmplLbrRateData.Mar;
            AverageLaborRateEmpl.QMIRSEmplLbrRate.DoubleClickMonth();
            QMIRSEmplLbrRateData = AverageLaborRateEmpl.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var EmployedLaborRateData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();
            isMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(EmployedLaborRateData, QMIRSEmplLbrRateMar);
            Assert.True(isMatched, $"{QMIRSEmplLbrRateMar.ToString()} , was not filled in the Employed Labor Rate row’s January – December + Total cells");

            var LastSavedEmployedLaborRateData = AverageLaborRateEmpl.LastSavedEmployedLaborRate.getLastSavedEmployedLaborRateData();
            double LastSavedEmployedLaborRateMar = LastSavedEmployedLaborRateData.Mar;
            AverageLaborRateEmpl.LastSavedEmployedLaborRate.DoubleClickMonth();
            EmployedLaborRateData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();
            isMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(EmployedLaborRateData, LastSavedEmployedLaborRateMar);
            Assert.True(isMatched, $"{LastSavedEmployedLaborRateMar.ToString()} , was not filled in the Employed Labor Rate row’s January – December + Total cells");



            AdminMenu.GoToForecast();
            //PLUS Std (SV FTEs) edit button >> 
            string SunInput = "4.00";
            string MonInput = "7.00";
            string SatInput = "11.00";
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            Assert.True(SVFTEStepTargets.IsAt, "SV FTE Step Targets dialog wasn't displayed");
            var SVFTEStepTargetsData = SVFTEStepTargets.GetMonthlyStepTargets();
            CommonFunctions.SetText(SVFTEStepTargetsData[3].Sun, SunInput);
            CommonFunctions.DoubleClickUsingWebElement(SVFTEStepTargetsData[3].Sun);
            SVFTEStepTargets.SaveStepTargets();
            //Verify double-click values. 
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            Assert.True(SVFTEStepTargets.IsAt, "SV FTE Step Targets dialog wasn't displayed");
            SVFTEStepTargetsData = SVFTEStepTargets.GetMonthlyStepTargets();            
            isMatched = SVFTEStepTargets.CompareMonthlyStepTargetsWithSpecificInput(SVFTEStepTargetsData[3], SunInput);
            SVFTEStepTargets.CancelStepTargets();
            Assert.True(isMatched, "SV FTE Step Targets Sun double-click functionality didn't work > Sun - Sat");

            //Verify Mon-Fri double-click
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            Assert.True(SVFTEStepTargets.IsAt, "SV FTE Step Targets dialog wasn't displayed");
            SVFTEStepTargetsData = SVFTEStepTargets.GetMonthlyStepTargets();
            CommonFunctions.SetText(SVFTEStepTargetsData[4].Mon, MonInput);
            CommonFunctions.DoubleClickUsingWebElement(SVFTEStepTargetsData[4].Mon);
            SVFTEStepTargets.SaveStepTargets();
            //Verify 
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            Assert.True(SVFTEStepTargets.IsAt, "SV FTE Step Targets dialog wasn't displayed");
            SVFTEStepTargetsData = SVFTEStepTargets.GetMonthlyStepTargets();
            isMatched = SVFTEStepTargets.CompareStepTargetsMondayToFridayWithSpecificInput(SVFTEStepTargetsData[4], MonInput);
            SVFTEStepTargets.CancelStepTargets();
            Assert.True(isMatched, "SV FTE Step Targets >> Mon-Fri double-click funtionality didn't work");


            //Verify Sat double-click
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            Assert.True(SVFTEStepTargets.IsAt, "SV FTE Step Targets dialog wasn't displayed");
            SVFTEStepTargetsData = SVFTEStepTargets.GetMonthlyStepTargets();
            CommonFunctions.SetText(SVFTEStepTargetsData[6].Sat, SatInput);
            CommonFunctions.DoubleClickUsingWebElement(SVFTEStepTargetsData[6].Sat);
            SVFTEStepTargets.SaveStepTargets();
            //Verify 
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            Assert.True(SVFTEStepTargets.IsAt, "SV FTE Step Targets dialog wasn't displayed");
            Thread.Sleep(2000);
            SVFTEStepTargetsData = SVFTEStepTargets.GetMonthlyStepTargets();           
            isMatched = SVFTEStepTargets.CompareStepTargetsWeekendWithSpecificInput(SVFTEStepTargetsData[6], SatInput);
            SVFTEStepTargets.CancelStepTargets();
            Assert.True(isMatched, "SV FTE Step Targets >> Sat double-click funtionality didn't work");

            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            ProductiveMinFTEs.SelectTimeInterval("By Day of Week per Month");
            //get all week days. 
            var DefaultToBeSet = ProductiveMinFTEs.getByDayOfWeekPerMonth_DefaultToBeSet();
            //Set Monday value
            ProductiveMinFTEs.SetDayInDayofWeekPerMonth(DefaultToBeSet.Mon, "4");
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastMenu.clickSaveAndRecalc();

            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            ProductiveMinFTEs.SelectTimeInterval("By Day of Week per Month");
            var ByDayOfWeekPerMonth = ProductiveMinFTEs.getByDayOfWeekPerMonth_Months();
            ////Double-click
            Thread.Sleep(5000);
            CommonFunctions.DoubleClickUsingWebElement(ByDayOfWeekPerMonth[3].Mon);
            //Thread.Sleep(1000);
            ProductiveMinFTEs.saveByDay();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastMenu.clickSaveAndRecalc();
            //Verify the double-click values
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            ProductiveMinFTEs.SelectTimeInterval("By Day of Week per Month");
            var AfterDoubleClickByDayOfWeekPerMonth = ProductiveMinFTEs.getByDayOfWeekPerMonth_Months();
            ProductiveMinFTEs.CancelByDay();
            isMatched = ProductiveMinFTEs.CompareMonToFriObjectsAgainstValue(AfterDoubleClickByDayOfWeekPerMonth[3], "4");
            Assert.True(isMatched, "Mon-Fri values weren't copied correctly");

            //Test Weekend entries
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            ProductiveMinFTEs.SelectTimeInterval("By Day of Week per Month");
            ByDayOfWeekPerMonth = ProductiveMinFTEs.getByDayOfWeekPerMonth_Months();
            CommonFunctions.SetText(ByDayOfWeekPerMonth[5].Sat, "8");
            CommonFunctions.ClickByJE(ByDayOfWeekPerMonth[3].Mon);
            Thread.Sleep(5000);
            CommonFunctions.DoubleClickUsingWebElement(ByDayOfWeekPerMonth[5].Sat);
            ProductiveMinFTEs.saveByDay();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastMenu.clickSaveAndRecalc();

            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            ProductiveMinFTEs.SelectTimeInterval("By Day of Week per Month");
            var AfterByDayOfWeekPerMonth = ProductiveMinFTEs.getByDayOfWeekPerMonth_Months();
            isMatched = string.Equals(ByDayOfWeekPerMonth[5].Sat.GetAttribute("value"),
                ByDayOfWeekPerMonth[5].Sun.GetAttribute("value"), StringComparison.CurrentCultureIgnoreCase);            
            Console.WriteLine($"Sat = {ByDayOfWeekPerMonth[5].Sat.GetAttribute("value")}");
            Console.WriteLine($"Sun = {ByDayOfWeekPerMonth[5].Sun.GetAttribute("value")}");
            ProductiveMinFTEs.CancelByDay();
            Assert.True(isMatched, "Sun and Sat value did not match with double-click functionality");

            //Enter a value in Sun and double-click it. It should copied thru Mon - Sat
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            ProductiveMinFTEs.SelectTimeInterval("By Day of Week per Month");
            ByDayOfWeekPerMonth = ProductiveMinFTEs.getByDayOfWeekPerMonth_Months();
            CommonFunctions.SetText(ByDayOfWeekPerMonth[7].Sun, "8");
            CommonFunctions.ClickByJE(ByDayOfWeekPerMonth[3].Mon);
            Thread.Sleep(2000);
            CommonFunctions.DoubleClickUsingWebElement(ByDayOfWeekPerMonth[7].Sun);
            ProductiveMinFTEs.saveByDay();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastMenu.clickSaveAndRecalc();
            //Reopen Edit dialog to verify values
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            ProductiveMinFTEs.SelectTimeInterval("By Day of Week per Month");
            ByDayOfWeekPerMonth = ProductiveMinFTEs.getByDayOfWeekPerMonth_Months();
            isMatched = ProductiveMinFTEs.CompareWeeklyObjectAgainstInput(ByDayOfWeekPerMonth[7], "8");
            Assert.True(isMatched, "Sun - Sat double-click did not work");
            ProductiveMinFTEs.CancelByDay();
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();

            //Testing By Day
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            var ByDayMinHrs = ProductiveMinFTEs.getByDayMinHrs();
            CommonFunctions.SetText(ByDayMinHrs.Mar, "8");
            CommonFunctions.ClickByJE(ByDayMinHrs.Jan);
            CommonFunctions.DoubleClickUsingWebElement(ByDayMinHrs.Mar);            
            //get new values
            ByDayMinHrs = ProductiveMinFTEs.getByDayMinHrs();
            isMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(ByDayMinHrs, "8");
            Assert.True(isMatched, "By Day double-click did not work correctly");
            ProductiveMinFTEs.saveByDay();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastMenu.clickSaveAndRecalc();

            //Testing double-click in Dept Facility Ratio
            var DeptFacilityRatioData = DeptFacilityRatio.getDeptFacilityRatioData();
            var DeptFacilityRatioMar = DeptFacilityRatioData.Mar;
            DeptFacilityRatio.DoubleClickMar();            
            DeptFacilityRatioData = DeptFacilityRatio.getDeptFacilityRatioData();
            isMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(DeptFacilityRatioData, DeptFacilityRatioMar);
            Assert.True(isMatched, "The double-click in Dept Facility Ratio did not work correctly.");

            //Testing double-click in Hist Dept Facility Ratio
            CommonFunctions.WaitUntilPageIsAcive();
            var HistDeptFacilityRatioData = HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var histDeptFacilityRatioRow = HistDeptFacilityRatio.HistDeptFacilityRatioRow();
            CommonFunctions.DoubleClickUsingWebElement(histDeptFacilityRatioRow.May);
            DeptForecastMenu.clickSaveAndRecalc();
            DeptFacilityRatioData = DeptFacilityRatio.getDeptFacilityRatioData();
            isMatched = CommonFunctions.CompareEntireRowValues(DeptFacilityRatioData, HistDeptFacilityRatioData.May);
            Assert.True(isMatched, $"The double-click in Hist Dept Facility Ratio (May cell) did not work correctly.\n" +
                $"May value didn't get copied over the entire Dept Facility Ratio row\n" +
                $"May = {HistDeptFacilityRatioData.May}\n" +
                $"May = {DeptFacilityRatioData.May}");
            DeptForecastMenu.clickSaveAndRecalc();

            //verify click on Hist. Dept/Facility Ratio Total cell, Dept/Facility Ratio
            //row should be updated
            HistDeptFacilityRatioData = HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            histDeptFacilityRatioRow = HistDeptFacilityRatio.HistDeptFacilityRatioRow();
            CommonFunctions.DoubleClickUsingWebElement(histDeptFacilityRatioRow.Total);
            DeptForecastMenu.clickSaveAndRecalc();
            DeptFacilityRatioData = DeptFacilityRatio.getDeptFacilityRatioData();
            isMatched = CommonFunctions.CompareEntireRowValues(DeptFacilityRatioData, HistDeptFacilityRatioData.Total);
            Assert.True(isMatched, $"The double-click in Hist Dept Facility Ratio (Total cell) did not work correctly.\n" +
                $"Total = {HistDeptFacilityRatioData.Total}\n" +
                $"May = {DeptFacilityRatioData.May}");


            //Testing Volume fcast Stat 6100
            CommonFunctions.WaitUntilPageIsAcive();
            var VolumefcastStat6100Data = VolumefcastStat6100.getVolumefcastStat6100Data();
            var VolumefcastStat6100Mar = VolumefcastStat6100Data.Mar;
            VolumefcastStat6100.DoubleClickMar();
            VolumefcastStat6100Data = VolumefcastStat6100.getVolumefcastStat6100Data();
            isMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(VolumefcastStat6100Data, VolumefcastStat6100Mar);
            Assert.True(isMatched, "The double-click in Volume fcast Stat 6100 did not work correctly.");

        }

        [Test]
        public void VerifyLoadTargetsJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Load Targets Journey";
            bool isMatched;
            string VariableAndSemiVariableDept;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            homePage.SwitchToWindow("Workload Forecast");
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetCurrentYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("3.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            homePage.SwitchToWindow("PLUS");
            Division.SetPLUSDivisionAndFacility();
            TargetDetail.GoTo();
            Assert.True(TargetDetail.IsAt, "Productivity Targets page was not displayed.");
            VariableAndSemiVariableDept = SettingData.LoadNPDept;
            TargetDetail.selectDept(VariableAndSemiVariableDept);
            var PlusProdMinFTEsData = DefineMinHours.getPlusProdMinFTEsData();
            var PlusHrsPerUOSMontlyDetails = TargetDetail.VariableDeptartment.getHrsPerUOS(VariableAndSemiVariableDept);

            //switch to WFT
            homePage.SwitchToWindow("Workload Forecast");
            //Go to dept forecast page
            AdminMenu.GoToForecast();
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);

            //PLUS
            LoadTargets.GoTo();
            Assert.True(LoadTargets.IsAt, "Load target popup was not dispalyed.");
            LoadTargets.LoadTarget()
                .withLoadProductivityTargets("PLUS")
                .withPLUSTargetMonthFrom("January to All")
                .withStepTargets(true)
                .withProductiveMinFtes(true)
                .OK();

            var WftProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            isMatched = CommonFunctions.CompareDataObjects(WftProductiveMinFTEsData, PlusProdMinFTEsData);
            Assert.True(isMatched, $"Productive Min FTEs data did not match between PLUS and WFT\n" +
                $"WFT: {WftProductiveMinFTEsData.Jan}    {PlusProdMinFTEsData.Jan}\n" +
                 $"WFT: {WftProductiveMinFTEsData.Feb}    {PlusProdMinFTEsData.Feb}\n" +
                  $"WFT: {WftProductiveMinFTEsData.Mar}    {PlusProdMinFTEsData.Mar}\n" +
                   $"WFT: {WftProductiveMinFTEsData.Apr}    {PlusProdMinFTEsData.Apr}\n" +
                    $"WFT: {WftProductiveMinFTEsData.May}    {PlusProdMinFTEsData.May}\n" +
                     $"WFT: {WftProductiveMinFTEsData.Jun}    {PlusProdMinFTEsData.Jun}\n" +
                      $"WFT: {WftProductiveMinFTEsData.Jul}    {PlusProdMinFTEsData.Jul}\n" +
                       $"WFT: {WftProductiveMinFTEsData.Aug}    {PlusProdMinFTEsData.Aug}\n" +
                        $"WFT: {WftProductiveMinFTEsData.Sep}    {PlusProdMinFTEsData.Sep}\n" +
                         $"WFT: {WftProductiveMinFTEsData.Oct}    {PlusProdMinFTEsData.Oct}\n" +
                          $"WFT: {WftProductiveMinFTEsData.Nov}    {PlusProdMinFTEsData.Nov}\n" +
                           $"WFT: {WftProductiveMinFTEsData.Dec}    {PlusProdMinFTEsData.Dec}\n" +
                           $"WFT: {WftProductiveMinFTEsData.Total}    {PlusProdMinFTEsData.Total}");

            var WftfcastStdSvFtesData = ForecastView_Standards.FcastVarStd.getFcastVarStdData();
            isMatched = CommonFunctions.CompareObjectValuesWithSingleData(WftfcastStdSvFtesData, PlusHrsPerUOSMontlyDetails.Jan);
            Assert.True(isMatched, $"fcast Std Sv Ftes row data did match PLUS Hrs Per UOS value\n" +
                $"{WftfcastStdSvFtesData.Jan}   {PlusHrsPerUOSMontlyDetails.Jan}");

        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void ForecastStandardsModificationsJourney()
        {
            
                RunData.AdoTestPlan = "WFT Journeys";
                RunData.AdoTestCaseName = "Verify the Journey of Forecast Standards Modifications";
                UserCanModifyTheDeptForecast();
        }

        [Test]
        //[Category("WFT")]
        public void UserCanCreateMultipleWftPlan()
        {
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string Year = CommonFunctions.GetNextYear();
            homePage.NavigateToWorkloadForecaster();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            List<string> lstYear = new List<string>() {  "2026" }; //"2025",    fac "34222" , "39385", "30916" , "25016", "34407", "37355", "27202"
            List<string> lstCoid = new List<string>() { "34222" , "39385", "30916" , "34407"}; //, "30913" //"34222", "39385", "30916"
            DeletePlansInFacilities(lstYear, lstCoid);
            foreach (var fac in lstCoid)
            {
                
                //CreateWftPlan(fac, Year);
                //homePage.SwitchToWindow("Workload Forecast");
                //DeptForecastButtonPanel.GoToAdmin();
                //AdminMenu.DeleteDefaultPlan();
            }

            //foreach (var fac in lstCoid)
            //{
            //    UserCanCreateSgPlan(fac);
            //}
        }

        private void DeletePlansInFacilities(List<string> lstYears, List<string> lstCoid)
        {
            foreach (var year in lstYears)
            {
                foreach (var fac in lstCoid)
                {
                    try
                    {
                        Division.SetWFTDivisionAndFacility(fac);
                        ExistingPlanFilter.GoTo();
                        Assert.True(ExistingPlanFilter.IsAt, "The plan filter is not displayed.");
                        var ExistingWorkingPlans = ExistingPlanFilter.getExistingPlanCount(year, "Working");
                        var iWorkingPlanCount = ExistingWorkingPlans.Count;
                        Console.WriteLine($"ExistingWorkingPlans - {fac} = {ExistingWorkingPlans.Count.ToString()}");
                        if (iWorkingPlanCount > 0)
                        {
                            foreach (var workingPlan in ExistingWorkingPlans)
                            {
                                try
                                {
                                    ExistingPlanFilter.GoTo();
                                    Assert.True(ExistingPlanFilter.IsAt, "The plan filter is not displayed.");
                                    ExistingPlanFilter.ExistingPlan()
                                    .withYear(year)
                                    .withPlanStatus("Working")
                                    .withPlan(workingPlan)
                                    .Select();
                                    AdminMenu.DeleteDefaultPlan();
                                }
                                catch
                                {
                                    continue;
                                }
                            }
                        }
                        var ExistingWorkingPlansAfter = ExistingPlanFilter.getExistingPlanCount(year, "Working");
                        var iWorkingPlanCountAfter = ExistingWorkingPlans.Count;
                        Console.WriteLine($"ExistingWorkingPlans after deleting - {fac} = {ExistingWorkingPlansAfter.Count.ToString()}");
                    }
                    catch
                    {
                        continue;
                    }
                }
            }
        }

        private void CreateWftPlan(string fac, string Year)
        {
            RunData.Facility = fac;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            Division.SetWFTDivisionAndFacility(fac);
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"DeveloperPlan_PleaseIgnore{CommonFunctions.GenerateRandonNumber()}";
            //string Year = CommonFunctions.GetCurrentYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("3.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
                CommonFunctions.WaitUntilPageIsAcive();
        }


        private void UserCanCreateSgPlan(string facility)
        {
            RunData.Facility = facility;
            string currentYear = CommonFunctions.GetCurrentYear();
            string startDate = $"12/01/{currentYear}";
            string TodaysDate = CommonFunctions.GetTodaysDateWithFormateMddyyyy();
            double VarProdHrsVolTotal;
            bool bDispayed, bMatched;
            string interfaceMsg;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToWorkloadForecaster();
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToStaffingGrid();
            Division.SetStaffingGridDivisionAndFacility(facility);
            SgMainMenu.SelectGrid();
            StaffingGridFliterPage.SgFilter()
                .withDepartment("610")
                .withStatus("New - Blank")
                .withStaffingGrid(string.Empty)
                .Create();
            string SgDescription = $"SG_{CommonFunctions.GenerateRandonNumber()}";
            CommonFunctions.AddTestStep($"Verfiy a user can set SG detail with {SgDescription} and {startDate}", "The SG were created with specific name and date.");
            StaffingGridMainPage.SetStaffingGridDetails(startDate, SgDescription);
            CommonFunctions.WaitUntilPageIsAcive();

            var SumOfSubTotals = StaffingGridMainPage.SetOrientationAndEducation();
            Console.WriteLine($"Sun = {SumOfSubTotals.Sun.ToString()}");
            var StaffingGridMainDetails = StaffingGridMainPage.GetStaffingGridDetails();
            SgMainMenu.clickNextStep();
            var StaffingGridDetailTotals = StaffingGridDetails.getStaffingGridDetailTotals();
            //SG target
            VarProdHrsVolTotal = StaffingGridDetailTotals.VarProdHrsVolTotal;
            Console.WriteLine(StaffingGridDetailTotals.VarProdHrsVolTotal);
            SgMainMenu.clickSubmitForApproval();
            //Navigate to ISAS home page.
            homePage.SwitchToWindow("Workload Forecast");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            Division.SetWFTDivisionAndFacility(facility);
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");

            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("1.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMRIS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
        }

         
        private void UserCanModifyTheDeptForecast()
        {            
            bool isMatched, bExists;
            string VariableDept, VariableAndSemiVariableDept, SemiVariableDept;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS(); 
            homePage.SwitchToWindow("Workload Forecast");
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("3.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");

            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("All")
                .withPlan(PlanDescription)
                .Select();

            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");

            VariableDept = SettingData.VariableDept;
            SemiVariableDept = SettingData.SemiVariableDept;
            VariableAndSemiVariableDept = SettingData.VariableAndSemiVariableDept;
            //Get PLUS data
            homePage.SwitchToWindow("PLUS");
            Division.SetPLUSDivisionAndFacility();
            TargetDetail.GoTo();
            Assert.True(TargetDetail.IsAt, "Productivity Targets page was not displayed.");
            TargetDetail.selectDept(VariableDept);
            CommonFunctions.WaitUntilPageIsAcive();
            var PLUSTargetMonthFromDeptData = TargetDetail.VariableDeptartment.getHrsPerUOS(SettingData.LoadTargetVariableDept);
            var HrsPerUOSMontlyDetails = TargetDetail.VariableDeptartment.getHrsPerUOS(VariableDept);
            var TargetNPPercentDetails = TargetDetail.VariableDeptartment.getTargetNPPercent(VariableDept);
            //Console.WriteLine($"TargetNPPercentDetails.Jul = {TargetNPPercentDetails.Jul}");
            //Console.WriteLine($"TargetOTPercent.Jul = {TargetDetail.VariableDeptartment.getTargetOTPercent(VariableDept).Jul}");
            //Console.WriteLine($"TargetContractPercent.Jul = {TargetDetail.VariableDeptartment.getTargetContractPercent(VariableDept).Jul}");
            //Console.WriteLine($"TargetAvgRate.Jul = {TargetDetail.VariableDeptartment.getTargetAvgRate(VariableDept).Jul}");
            //Console.WriteLine($"SemiVariableDepartment > from > Jul = {TargetDetail.SemiVariableDepartment.getFromData(SemiVariableDept).Jul}");
            //Console.WriteLine($"SemiVariableDepartment > Sun > Jul = {TargetDetail.SemiVariableDepartment.getSunData(SemiVariableDept).Jul}");
            //Console.WriteLine($"SemiVariableDepartment > Total > Jul = {TargetDetail.SemiVariableDepartment.getTotalData(SemiVariableDept).Jul}");


            //Switch to WFT
            homePage.SwitchToWindow("Workload Forecast");
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");

            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("All")
                .withPlan(PlanDescription)
                .Select();

            //verify gray color in Nov and Dec cell. 
            var color = ForecastView_Volume.HistDeptFacilityRatio.GetColor();
            Console.WriteLine(color);
            Assert.IsTrue(string.Equals(color, "rgba(164, 164, 164, 1)", StringComparison.InvariantCultureIgnoreCase),
                "Color didn't match.");
            //Varialbe dept
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableDept);
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");

            var ByDayofWeekPerMonthValues = ProductiveMinFTEs.getByDayofWeekPerMonth("10.00");
            CommonFunctions.IsElementDisplayed("//*/a[@id='prodMinFtesEditBtn']", 5);
            var StandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            Console.WriteLine($"StandardsProductiveMinFTEsValues.Jan = {StandardsProductiveMinFTEsValues.Jan}");
            isMatched = ByDayofWeekPerMonthValues.Jan == StandardsProductiveMinFTEsValues.Jan;
            Assert.True(isMatched, "Edit did not work properly");

            //Verify monthly min hrs
            isMatched = false;
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            var MonthlyMinHrs = ProductiveMinFTEs.getMonthlyMinHrs("4.00");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//*/a[@id='prodMinFtesEditBtn']", 5);
            StandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            isMatched = CommonFunctions.ToDouble(MonthlyMinHrs.Jan.ToString()) == StandardsProductiveMinFTEsValues.Jan;
            Assert.True(isMatched, $"Min hrs did not work properly\n" +
                $"MonthlyMinHrs.Jan: {MonthlyMinHrs.Jan}\n" +
                $"StandardsProductiveMinFTEsValues.Jan: {StandardsProductiveMinFTEsValues.Jan}");

            //ByDay
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            isMatched = false;
            double byDayDoubleValue = 12.00;
            var ByDay = ProductiveMinFTEs.getByDay(byDayDoubleValue);
            CommonFunctions.WaitUntilPageIsAcive();
            StandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            Console.WriteLine($"ByDay.Jan = {ByDay.Jan}");
            isMatched = CommonFunctions.CompareDataObjects(StandardsProductiveMinFTEsValues, ByDay);
            Assert.True(isMatched, $"By day > edit did not work properly\n" +
                $"ByDay.Jan: {ByDay.Jan}\n" +
                $"StandardsProductiveMinFTEsValues.Jan: {StandardsProductiveMinFTEsValues.Jan}");

            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");

            var ByDayOfWeek = ProductiveMinFTEs.getByDayOfWeek("42.00");
            CommonFunctions.WaitUntilPageIsAcive();
            StandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            Console.WriteLine($"ByDay.Jan = {ByDay.Jan}");
            isMatched = ByDayOfWeek == StandardsProductiveMinFTEsValues.Jan;
            Assert.True(isMatched, $"By Day Of Week > edit did not work properly\n" +
                $"ByDayOfWeek {ByDayOfWeek}\n" +
                $"StandardsProductiveMinFTEsValues.Jan {StandardsProductiveMinFTEsValues.Jan}");

            //Testing F,P,Q buttons
            ForecastView_Standards.FcastVarStd.EnterFirstMonth("6.00");
           // ForecastView_Standards.FcastVarStd.ClickFill();
            var FcastVarStdData =  ForecastView_Standards.FcastVarStd.getFcastVarStdData();
            //Assert.True(FcastVarStdData.Jan == FcastVarStdData.Sep, $"Values don't match\n" +
            //    $"FcastVarStdData.Jan \n" +
            //    $"FcastVarStdData.Sep");
            //DeptForecastMenu.clickSaveAndRecalc();
            //CommonFunctions.WaitUntilPageIsAcive();
            //Thread.Sleep(15000);
            //Thread.Sleep(2000);
            // Variable And Semi Variable Dept
            var VariableAndSemiVariableDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "Productive Min FTEs dialog was not open");
            CommonFunctions.WaitUntilPageIsAcive();
            var VariableAndSemiVariableByDayofWeekPerMonthValues = ProductiveMinFTEs.getByDayofWeekPerMonth("7.00");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//*/a[@id='prodMinFtesEditBtn']", 5);
            Console.WriteLine($"VariableAndSemiVariableByDayofWeekPerMonthValues.Jan = {VariableAndSemiVariableByDayofWeekPerMonthValues.Jan}");
            var VariableAndSemiVariableStandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            Console.WriteLine($"VariableAndSemiVariableStandardsProductiveMinFTEsValues.Jan = {VariableAndSemiVariableStandardsProductiveMinFTEsValues.Jan}");
            isMatched = CommonFunctions.ToDouble(VariableAndSemiVariableByDayofWeekPerMonthValues.Jan.ToString()) ==
                VariableAndSemiVariableStandardsProductiveMinFTEsValues.Jan;
            Assert.True(isMatched, "Edit did not work properly");

            Thread.Sleep(2000);
            //Semi Variable Dept
            var SemiVariableDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SemiVariableDept);
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            Assert.True(SVFTEStepTargets.IsAt, "SV FTE Step Targets dialog wasn't displayed");
            // data from dialog
            var SVFTEStepTargetsMonthlyValues = SVFTEStepTargets.getSVFTEStepTargetsData("35.00");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//*/a[@name='Step Targets']", 5);
            CommonFunctions.WaitUntilPageIsAcive();
            var PLUSStdSV_FTEsMontlyValues = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            Console.WriteLine($"SVFTEStepTargetsMonthlyValues.Jan = {SVFTEStepTargetsMonthlyValues.Jan}\n" +
                $"PLUSStdSV_FTEsMontlyValues.Jan = {PLUSStdSV_FTEsMontlyValues.Jan}");

            isMatched = CommonFunctions.ToDouble(SVFTEStepTargetsMonthlyValues.Jan.ToString()) == PLUSStdSV_FTEsMontlyValues.Jan;
            Assert.True(isMatched, "Standards > PLUSStdSV_FTEs Edit did not work properly");

            //Select variable dept to test data from Sep to all months.
            DeptForecastMenu.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(15000);
            var LoadTargetVariableDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SettingData.LoadTargetVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();
            bExists = CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 30);
            Assert.True(bExists, "Forecast view was not loaded.");
            FcastVarStdData = FcastVarStd.getFcastVarStdData();
            isMatched = CommonFunctions.ToDouble(PLUSTargetMonthFromDeptData.Sep.ToString()) == FcastVarStdData.Jan;
            Console.WriteLine($"PLUSTargetMonthFromDeptData.Sep = {PLUSTargetMonthFromDeptData.Sep}\n" +
                $"FcastVarStdData.Jan = {FcastVarStdData.Jan}");
            //Assert.True(isMatched, "Sep data wasn't displayed correctly in Jan cell.");
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyDepartmentDetailsJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Department Details Journey";
            bool isMatched, bExists;
            string firstFacDept, secondFacDept;
            string deptNumber = SettingData.deptDetail;
            string SecondFacility = SettingData.FpcFacility;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("30927");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetCurrentYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");            
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus(string.Empty)
               .withPlan(string.Empty)
               .Select();
            //Varialbe dept
            var FirstDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails("610");
            firstFacDept = FirstDeptDetails.DeptName;

            //Navigate to another facility
            Division.SetWFTDivisionAndFacility("30201");
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus(string.Empty)
               .withPlan(string.Empty)
               .Select();
            // We need to have a Working plan
            var SecondDeptDetails = DeptForecastDepartmentDetails.GetDeptDetailsForDefaultDept();
            secondFacDept = SecondDeptDetails.DeptName;
            isMatched = firstFacDept.Contains("610") && secondFacDept.Contains("610");
            CommonFunctions.AddTestStep("Verify the same dept is persistent", "The same dept is persistent");
            Assert.True(isMatched, $"Dept 610 was not displayed in facility 30201");
        }

        
        [Test]
        [Category("WFT"), Description("Journey")]
        public void UserCanNavigateToHelpPage()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Help-Contents";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            CommonFunctions.LoginToHelpServerAsync();
            HelpPage.GoTo();
            Assert.True(HelpPage.IsAt, "Help page was not displayed");
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyCreateNewPlanJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Save and Recalculate button functionality Journey";
            UserCanCreateWFT_AdminNewPlan();
        }

        [Test]
        public void verifyConractPercentCalculationJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Contract Percent Calculation Journey";
            string COID = "06676";
            string Dept = "830";
            double FortyDividedBySeven = 5.7142857;
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility(COID);
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();           

            //CL Hrs Fcast = Fcast Total Prod Hrs * (CL % fcast / 100.00)
            //CL FTEs fcast = CL Hrs Fcast / (40 / 7) / number of days in that month
            var x = CLHrsFcast.VerifyCLHrsFcastCalculation();
            Console.WriteLine(x.ToString());

            var y = ClFtesFcast.VerifyClFtesFcastCalculation();
            Console.WriteLine(y.ToString());




        }

        

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifySaveAndRecalcButtonFunctionalityJouney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Save and Recalculate button functionality Journey";
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Approving {PlanDescription}")
                .Approve();
            DeptForecastButtonPanel.ReleasePlan();
            Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
                $"{PlanDescription} was not released correctly.");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            bool bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnSaveBugdegetForecast']", 3);
            Assert.True(bExist, "Save & Calculate button is not displayed with Working option");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Historical")
                .withPlan(string.Empty)
                .Select();
            bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnSaveBugdegetForecast']", 3);
            Assert.True(bExist, "Save & Calculate button is not displayed with Historical option");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus("Rejected")
               .withPlan(string.Empty)
               .Select();
            bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnSaveBugdegetForecast']", 3);
            Assert.True(bExist, "Save & Calculate button is not displayed with Rejected option");
        }


        //[Test] // Test completed
        //[Category("WFT"), Description("Journey")]
        public void LoadTargetJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Load Targets Journey";
            bool isMatched, bExists;
            string VariableDept, VariableAndSemiVariableDept, SemiVariableDept;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Navigate to ISAS home page. 
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            homePage.SwitchToWindow("Workload Forecast");
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");

            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("All")
                .withPlan(PlanDescription)
                .Select();

            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");

            var FacStatMappingData = FacilityStatsMapping.GetFacilityStatsMappingData();
            var wft_V = from type in FacStatMappingData
                        where string.Equals(type.WFTDeptType, "Variable")
                        select type;
            VariableDept = wft_V.ToList().First().DeptName.Trim();
            Console.WriteLine($"dept name - V {wft_V.ToList().First().DeptName}");

            var wft_SV = from type in FacStatMappingData
                         where string.Equals(type.WFTDeptType, "SemiVariable")
                         select type;
            SemiVariableDept = wft_SV.ToList().First().DeptName.Trim();
            Console.WriteLine($"dept name - SV {SemiVariableDept}");

            var wft_B = from type in FacStatMappingData
                        where string.Equals(type.WFTDeptType, "Variable/SemiVariable")
                        select type;
            VariableAndSemiVariableDept = wft_B.ToList().First().DeptName;
            Console.WriteLine($"dept name - Both {wft_B.ToList().First().DeptName}");


            //Get PLUS data
            homePage.SwitchToWindow("PLUS");
            Division.SetPLUSDivisionAndFacility();
            TargetDetail.GoTo();
            Assert.True(TargetDetail.IsAt, "Productivity Targets page was not displayed.");
            //We need this to test target months
            var PLUSTargetMonthFromDeptData = TargetDetail.VariableDeptartment.getHrsPerUOS(SettingData.LoadTargetVariableDept);
            var HrsPerUOSMontlyDetails = TargetDetail.VariableDeptartment.getHrsPerUOS(VariableDept);
            var PLUSDataForSemiVariableDept = TargetDetail.SemiVariableDepartment.getProdFTEsData(SemiVariableDept);


            //Switch to WFT
            homePage.SwitchToWindow("Workload Forecast");
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");

            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("All")
                .withPlan(PlanDescription)
                .Select();

            //Varialbe dept
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableDept);
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, " 529 Productive Min FTEs dialog was not open");

            var ByDayofWeekPerMonthValues = ProductiveMinFTEs.getByDayofWeekPerMonth("10.00");
            CommonFunctions.IsElementDisplayed("//*/a[@id='prodMinFtesEditBtn']", 5);
            Console.WriteLine($"ByDayofWeekPerMonthValues.Jan = {ByDayofWeekPerMonthValues.Jan}");
            var StandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            Console.WriteLine($"StandardsProductiveMinFTEsValues.Jan = {StandardsProductiveMinFTEsValues.Jan}");
            isMatched = ByDayofWeekPerMonthValues.Jan == StandardsProductiveMinFTEsValues.Jan;
            Assert.True(isMatched, "Edit did not work properly");

            //load target
            LoadTargets.GoTo();
            Assert.True(LoadTargets.IsAt, "Load target dialog is not displayed");
            LoadTargets.LoadTarget()
                .withLoadProductivityTargets("PLUS: Hrs/UOS to WFT: Fcast Var. Std")
                .withPLUSTargetMonthFrom("Jan: Dec to Jan:Dec")
                .withProductiveMinFtes(true)
                .withStepTargets(false)
                .OK();
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(15000);
            bExists = CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 30);
            Assert.True(bExists, "Forcat view was not loaded.");
            // Thread.Sleep(2000);
            DeptForecastMenu.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(15000);
            var StandardsProductiveMinFTEsValuesAfterLoadingTarget = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            isMatched = StandardsProductiveMinFTEsValuesAfterLoadingTarget.Jan ==
                HrsPerUOSMontlyDetails.Jan;

            Assert.True(isMatched, $"Load target from PLUS did not work\n" +
                $"StandardsProductiveMinFTEsValuesAfterLoadingTarget.Jan = {StandardsProductiveMinFTEsValuesAfterLoadingTarget.Jan}\n" +
                $"PLUS > HrsPerUOSMontlyDetails.Jan {HrsPerUOSMontlyDetails.Jan}\n" +
                $"{deptDetails.DeptTypeToUse}\n" +
                $"{VariableDept}");

            // By Day option
            DeptForecastMenu.clickSaveAndRecalc();
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, " 570 Productive Min FTEs dialog was not open");
            var byDayValue = CommonFunctions.GetDoubleRandomNumber();
            var ByDay = ProductiveMinFTEs.getByDay(12.00);
            StandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            Console.WriteLine($"ByDay.Jan = {ByDay.Jan}");
            isMatched = CommonFunctions.CompareDataObjects(ByDay,StandardsProductiveMinFTEsValues);
            Assert.True(isMatched, $"By day > edit did not work properly\n" +
                $"ByDay.Jan {ByDay.Jan}\n" +
                $"StandardsProductiveMinFTEsValues.Jan {StandardsProductiveMinFTEsValues.Jan}");

            DeptForecastMenu.clickSaveAndRecalc();
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "582 Productive Min FTEs dialog was not open");
            var ByDayOfWeek = ProductiveMinFTEs.getByDayOfWeek("42.00");
            StandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            Console.WriteLine($"ByDay.Jan = {ByDay.Jan}");
            isMatched = ByDayOfWeek == StandardsProductiveMinFTEsValues.Jan;
            Assert.True(isMatched, $"By Day Of Week > edit did not work properly\n" +
                $"ByDayOfWeek {ByDayOfWeek}\n" +
                $"StandardsProductiveMinFTEsValues.Jan {StandardsProductiveMinFTEsValues.Jan}");


            Thread.Sleep(2000);
            DeptForecastMenu.clickSaveAndRecalc();
            // Variable And Semi Variable Dept
            var VariableAndSemiVariableDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            Assert.True(ProductiveMinFTEs.IsAt, "597 Productive Min FTEs dialog was not open");
            var VariableAndSemiVariableByDayofWeekPerMonthValues = ProductiveMinFTEs.getByDayofWeekPerMonth("7.00");
            CommonFunctions.IsElementDisplayed("//*/a[@id='prodMinFtesEditBtn']", 5);
            Console.WriteLine($"VariableAndSemiVariableByDayofWeekPerMonthValues.Jan = {VariableAndSemiVariableByDayofWeekPerMonthValues.Jan}");
            CommonFunctions.WaitUntilPageIsAcive();
            var VariableAndSemiVariableStandardsProductiveMinFTEsValues = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            CommonFunctions.WaitUntilPageIsAcive();
            Console.WriteLine($"VariableAndSemiVariableStandardsProductiveMinFTEsValues.Jan = {VariableAndSemiVariableStandardsProductiveMinFTEsValues.Jan}");
            isMatched = VariableAndSemiVariableByDayofWeekPerMonthValues.Jan ==
                VariableAndSemiVariableStandardsProductiveMinFTEsValues.Jan;
            Assert.True(isMatched, "Variable And Semi Variable Dept > Edit did not work properly");
            //Semi Variable Dept
            Console.WriteLine("*** Semi-Variable dept ****");
            var SemiVariableDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SemiVariableDept);
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            Assert.True(SVFTEStepTargets.IsAt, "SV FTE Step Targets dialog wasn't displayed");
            // data from dialog
            var SVFTEStepTargetsMonthlyValues = SVFTEStepTargets.getSVFTEStepTargetsData("42.00");
            CommonFunctions.IsElementDisplayed("//*/a[@name='Step Targets']", 20);
            CommonFunctions.WaitUntilPageIsAcive();
            Console.WriteLine("*** After modifying the step target dialog ****");
            var PLUSStdSV_FTEsMontlyValues = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            Console.WriteLine($"SVFTEStepTargetsMonthlyValues.Jan = {SVFTEStepTargetsMonthlyValues.Jan}\n" +
                $"PLUSStdSV_FTEsMontlyValues.Jan = {PLUSStdSV_FTEsMontlyValues.Jan}");
            isMatched = SVFTEStepTargetsMonthlyValues.Jan == PLUSStdSV_FTEsMontlyValues.Jan;
            // Assert.True(isMatched, "Standards > PLUSStdSV_FTEs Edit did not work properly");
            Console.WriteLine("*** Load target - semi-var ****");
            //load target
            LoadTargets.GoTo();
            Assert.True(LoadTargets.IsAt, "Load target dialog is not displayed");
            LoadTargets.LoadTarget()
                .withLoadProductivityTargets("PLUS: Hrs/UOS to WFT: Fcast Var. Std")
                .withPLUSTargetMonthFrom("September to All")
                .withProductiveMinFtes(true)
                .withStepTargets(true)
                .OK();
            Thread.Sleep(2000);
            CommonFunctions.WaitUntilPageIsAcive();
            bExists = CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 30);
            Assert.True(bExists, "Forcat view was not loaded.");
            DeptForecastMenu.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
            //Thread.Sleep(15000);
            var PLUSStdSV_FTEsMontlyValuesAfterLoadingTarget = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            string semiVariableAfterLoadingTarget = $"PLUSDataForSemiVariableDept.Jan = {PLUSDataForSemiVariableDept.Jan}\n" +
                 $"PLUSStdSV_FTEsMontlyValuesAfterLoadingTarget.Jan = {PLUSStdSV_FTEsMontlyValuesAfterLoadingTarget.Jan}\n" +
                 $"{deptDetails.Description}";
            isMatched = PLUSDataForSemiVariableDept.Jan == Math.Round(PLUSStdSV_FTEsMontlyValuesAfterLoadingTarget.Jan, 1);
            Assert.True(isMatched, semiVariableAfterLoadingTarget);
            isMatched = false;

            //Select variable dept to test data from Sep to all months.
            var LoadTargetVariableDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SettingData.LoadTargetVariableDept.Trim());
            CommonFunctions.WaitUntilPageIsAcive();
            bExists = CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 30);
            Assert.True(bExists, "Forcat view was not loaded.");
            var FcastVarStdData = FcastVarStd.getFcastVarStdData();
            //isMatched = PLUSTargetMonthFromDeptData.Sep == FcastVarStdData.Jan;
            //Assert.True(isMatched, "Sep data wasn't displayed correctly in Jan cell.");
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifySelfApprovalJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify self-Approval journey";
            UserCanApproveAndReleasePlan();
        }

       // [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyOfFacilityStatMapping()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Facility Stat Mapping";
            string DeptNum, VariableDept, SemiVariableDept, VarAndSemiVarDept;
            bool bExist, bEnabled;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Navigate to ISAS home page. 
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            homePage.SwitchToWindow("Workload Forecast");
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            VariableDept = SettingData.FacStatMappingVariableDept;
            SemiVariableDept = SettingData.FacStatMappingSemiVariableDept;
            VarAndSemiVarDept = SettingData.VarSemiVarDept;

            //Verify new dept persistent
            By byLstNewDept = By.XPath("//*/div[contains(@class,'facstat-mapping')]//table/tbody//td/input[contains(@id,'isInactiveWft') and not (@checked)]//following-sibling::select[contains(@id,'facDeptNPfcast') and @title='Needs Verification']/ancestor::div[@deptid]");
            var lstNewDept = CommonFunctions.getElements(byLstNewDept);
            string newDeptNum = lstNewDept[0].GetDomAttribute("deptnum");
            Console.WriteLine($"NewDeptNum = {newDeptNum}");
            //DeptForecastButtonPanel.GoToAdmin();
            //FacilityStatsMapping.GoTo();
           // Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(newDeptNum)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("FTE") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();
            var FacilityStatsMappingDataBefore = FacilityStatsMapping.GetFacilityStatsMappingData(newDeptNum);
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "Average Labor Rate Empl page was not displayed.");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            var FacilityStatsMappingDataAfter = FacilityStatsMapping.GetFacilityStatsMappingData(newDeptNum);
            bool isMatched = FacilityStatsMappingDataAfter.NPPercent.Contains(FacilityStatsMappingDataAfter.NPPercent);
            Assert.True(isMatched, $"The dept {newDeptNum} did not diplayed PLUS in NP %");



            Console.WriteLine("First test");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
                .withIgnoredInWFT(true)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("FTE")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            // Get fac stat mapping data for dept
            var FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "not found");
            string wftDepartmentsXpath = "//select[@id='ddlwftDepartments']/option";
            bExist = CommonFunctions.IsItemFoundinDropdownMenu(wftDepartmentsXpath, VarAndSemiVarDept);
            Assert.False(bExist, "Dept was found");

            Console.WriteLine("Second test");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
                .withIgnoredInWFT(false) // uncheck Ignore in WFT 
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            Console.WriteLine("Third test");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(true)
               .withFreezeStdTgt(true)
               .withFreezeSVStepSel(true)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(true)
               .withFreezeOTPercent(true)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            Console.WriteLine("Fourth test");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("NP-0%")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            //Testing Red color in NP - 0%
            Console.WriteLine("NP - 0% red color test");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("NP-0%")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();
            string Dept = SettingData.VarSemiVarDept.ToString();
            bExist = VerifyNpPercentColor(Dept);
            Assert.True(bExist, "NP - 0% - NP Percent select did not turn to red color");

            //Verify NP % dropdown is disabled when ticking Freeze NP Percent
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(true)
               .withFreezeOTPercent(false)
               .Save();
            bEnabled = FacilityStatsMapping.IsNpPercentDropdownDisabled(VarAndSemiVarDept);
            //Assert.True(bEnabled, $"{VarAndSemiVarDept} was not disabled after checking the freeze NP % checkbox.");

            

            // Verify NP - 7%
            Console.WriteLine("7% red color part");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
             .withIgnoredInWFT(false) // uncheck Ignore in WFT 
             .withFacilityStat(string.Empty)
             .withCLPercentOrFTE("%") // keep using %
             .withNPPercent("NP-7%")
             .withFreezeRatioVol(false)
             .withFreezeStdTgt(false)
             .withFreezeSVStepSel(false)
             .withFreezeCLPercent(false)
             .withFreezeNPPercent(false)
             .withFreezeOTPercent(false)
             .Save();

            //verify red color if in NP-7%
            bExist = VerifyNpPercentColor(Dept);
            Assert.True(bExist, "NP - 7% - NP Percent select did not turn to red color");
            //Select override to get rid of the red color. 
            Console.WriteLine("7% part");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
             .withIgnoredInWFT(false) // uncheck Ignore in WFT 
             .withFacilityStat(string.Empty)
             .withCLPercentOrFTE("%") // keep using %
             .withNPPercent("OVERRIDE")
             .withFreezeRatioVol(false)
             .withFreezeStdTgt(false)
             .withFreezeSVStepSel(false)
             .withFreezeCLPercent(false)
             .withFreezeNPPercent(false)
             .withFreezeOTPercent(false)
             .Save();

            // Verify NP - 7%
            Console.WriteLine("7% part");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
             .withIgnoredInWFT(false) // uncheck Ignore in WFT 
             .withFacilityStat(string.Empty)
             .withCLPercentOrFTE("%") // keep using %
             .withNPPercent("NP-7%")
             .withFreezeRatioVol(false)
             .withFreezeStdTgt(false)
             .withFreezeSVStepSel(false)
             .withFreezeCLPercent(false)
             .withFreezeNPPercent(false)
             .withFreezeOTPercent(false)
             .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            // Verify NP - 0%
            Console.WriteLine("0% part");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("FTE") // keep using %
               .withNPPercent("NP-0%")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            
            //Testing Override option in NP %
            Console.WriteLine("Override part");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("FTE") // keep using %
               .withNPPercent("OVERRIDE")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();

            bExist = VerifyNpPercentColor(Dept);
            Assert.False(bExist, "Override - NP Percent select turned to red color");

            

            //Forecast: Contract %, Non-Productive %, OT % Double Click Enhancements 
            VerifyContractPercentNonProductivePercentOtPercentDoublClickFunctionality(VarAndSemiVarDept);
        }

        private bool VerifyNpPercentColor(string Dept)
        {
            bool bExist;
            CommonFunctions.WaitUntilPageIsAcive();
            AdminMenu.GoToForecast();
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();
            ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.ModifyNPPercentFcastExcludesCLData("3.00");
            DeptForecastButtonPanel.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastButtonPanel.GoToAdmin();
            //FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            string NPPercentWithRedColorXpath = $"//*/table[@class='tblFacStat']//tr//td/input[contains(@value,'{Dept.Trim()}')]/ancestor::tr//select[@style='background-color:red']";
            bExist = CommonFunctions.IsElementDisplayed(NPPercentWithRedColorXpath, 2);
            return bExist;
        }

        private void VerifyContractPercentNonProductivePercentOtPercentDoublClickFunctionality(string Dept)
        {
            bool bMatched;
            AdminMenu.GoToForecast();
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();

            // Testing double-clicking in QMIRS row
            var QMIRSNPPercentData = QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            double QMIRS_Mar = QMIRSNPPercentData.Mar;
            QMIRS_NP_Percent.DoubleClickMar();
            var NPPercentFcastExcludesCLData = NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(NPPercentFcastExcludesCLData, QMIRS_Mar);
            Assert.True(bMatched, $"Doubl-clicking QMIRS Mar value did not get copied to all months of NP Percent Fcast Excludes CL rows");

            //Testing double-clicking in PLUS Avg NP % row
            var PLUSAvgNPPercentData = PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            double PLUSAvgNPPercentMar = PLUSAvgNPPercentData.Mar;
            PLUSAvgNP_Percent.DoubleClickMar();
            NPPercentFcastExcludesCLData = NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(NPPercentFcastExcludesCLData, PLUSAvgNPPercentMar);
            Assert.True(bMatched, $"Doubl-clicking PLUS Avg. NP % Mar value did not get copied to all months of NP Percent Fcast Excludes CL rows");

            //Testing double-clicking in NP Percent Fcast Excludes CL row
            string newValue = "1.00";
            NPPercentFcastExcludesCL.ModifyNPPercentFcastExcludesCLData(newValue);
            NPPercentFcastExcludesCLData = NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            double MarValue = NPPercentFcastExcludesCLData.Mar;
            NPPercentFcastExcludesCL.DoubleClickMar();
            NPPercentFcastExcludesCLData = NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(NPPercentFcastExcludesCLData, MarValue);
            Assert.True(bMatched, $"{MarValue.ToString()} , was not filled in the NP % (excludes CL) fcast row’s January – December + Total cells\n" +
                $" May = {NPPercentFcastExcludesCLData.May}");

            //Testing double-click in OT % 
            var OTPercentQMIRSData = OTPercentQMIRS.getOTPercentQMIRSData();
            double OTPercentQMIRS_Mar = OTPercentQMIRSData.Mar;
            OTPercentQMIRS.DoubleClickMar();
            var OTPercentFcastData = OTPercentFcast.getOTPercentFcastData();
            bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(OTPercentFcastData, OTPercentQMIRS_Mar);
            Assert.True(bMatched, $"{OTPercentFcastData.ToString()} , was not filled in the OT % Fcast row’s January – December + Total cells");
        }

        private void VerifyFacilityStatsMappingData(FacilityStatsMappingObject FacilityStatsMappingData, string Dept)
        {
            bool bMatched, bView, bEdit, bExist;

            AdminMenu.GoToForecast();
            //Set Dept
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();

            //Freeze Std Tgt
            switch (FacilityStatsMappingData.FreezeStdTgt)
            {
                case true:
                    bView = CommonFunctions.IsElementDisplayed("//a[@id='prodMinFtesViewBtn']", 2);
                    // Assert.True(bView, "View button button wasn't displayed.");
                    break;
                case false:
                    bEdit = CommonFunctions.IsElementDisplayed("//a[@id='prodMinFtesEditBtn']", 2);
                    Assert.True(bEdit, "Edit button button wasn't displayed.");
                    break;
            }

            //FreezeRatioVol
            IWebElement DeptFacilityRatio = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptFacilityRatio-1']"));
            switch (FacilityStatsMappingData.FreezeRatioVol)
            {
                case true:
                    //bEnabled = DeptFacilityRatio.Enabled;
                    //Assert.False(bEnabled, "Dept Facility Ratio row is enabled");
                    ////verify PLUS button is invisible
                    //bPlusButtonExist = CommonFunctions.IsElementDisplayed("//a[@id='resetDFRationtoPlusFillBtn']", 2);
                    //Assert.False(bPlusButtonExist, "Plus button was visible.");
                    //bFillButtonExist = CommonFunctions.IsElementDisplayed("//a[@id='deptVolumeFillBtn']", 2);
                    //Assert.False(bFillButtonExist, "Fill button was visible.");
                    break;
                case false:
                    //bEnabled = DeptFacilityRatio.Enabled;
                    //Assert.True(bEnabled, "Dept Facility Ratio row is disabled");
                    ////verify PLUS button is visible
                    //bPlusButtonExist = CommonFunctions.IsElementDisplayed("//a[@id='resetDFRationtoPlusFillBtn']", 2);
                    //Assert.True(bPlusButtonExist, "Plus button was invisible.");
                    //bFillButtonExist = CommonFunctions.IsElementDisplayed("//a[@id='deptVolumeFillBtn']", 2);
                    //Assert.True(bFillButtonExist, "Fill button was invisible.");
                    break;
            }

            //FreezeCLPercent            
            //switch (FacilityStatsMappingData.FreezeCLPercent)
            //{
            //    case true:
            //        bExist = CommonFunctions.IsElementDisplayed("//input[@id='clPct-1' and @readonly]", 1);
            //        Assert.True(bExist, "Cl % fcast field is enabled after selecting the freeze option");
            //        break;
            //    case false:
            //        bExist = CommonFunctions.IsElementDisplayed("//input[@id='txtContractLaborPercent-1' and not(@readonly)]", 1);
            //        Assert.True(bExist, "Cl % fcast field is disabled after unticking the freeze option");
            //        break;
            //}

            //FreezeNPPercent
            IWebElement NonProductivePercent = CommonFunctions.getElement(By.XPath("//input[@id='txtNonProductivePercent-1']"));
            switch (FacilityStatsMappingData.FreezeNPPercent)
            {
                // We use super admin to run the script.
                case true:
                    Assert.True(NonProductivePercent.Enabled, "Non-Productive Percent field is enabled after selecting the freeze option");
                    break;
                case false:
                    Assert.True(NonProductivePercent.Enabled, "Non-Productive Percent field is disabled after unticking the freeze option");
                    break;
            }

            //FreezeOTPercent
            IWebElement OTPercent = CommonFunctions.getElement(By.XPath("//input[@id='txtOTPercent-1']"));
            switch (FacilityStatsMappingData.FreezeOTPercent)
            {
                // We use super admin to run the script.
                case true:
                    Assert.True(OTPercent.Enabled, "OT Percent field is enabled after selecting the freeze option");
                    break;
                case false:
                    Assert.True(OTPercent.Enabled, "OT Percent field is disabled after unticking the freeze option");
                    break;
            }

            //Verify NP %
            switch (FacilityStatsMappingData.NPPercent.Trim())
            {
                //case "PLUS":
                //    Console.WriteLine("PLUS block");
                //    var PLUSAvgNPPercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
                //    var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                //    bMatched = PLUSAvgNPPercentData.Jan == NPPercentFcastExcludesCLData.Jan;
                //    Assert.True(bMatched, $"No match:\nPLUSAvgNPPercentData.Jan = {PLUSAvgNPPercentData.Jan}\n" +
                //        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                //    break;
                case "QMIRS":
                    Console.WriteLine("QMIRS block");
                    var QMIRSNPPercentData = QMIRS_NP_Percent.getQMIRS_NP_PercentData();
                    var NPPercentFcastExcludesCLData = NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    bMatched = CommonFunctions.CompareDataObjects(QMIRSNPPercentData, NPPercentFcastExcludesCLData);
                    Assert.True(bMatched, $"No match:\n QMIRSNPPercentData.Jan = {QMIRSNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    CommonFunctions.AddTestStep("Verify QMRIS data ", "Data is verified");
                    break;
                case "NP-7%":
                    Console.WriteLine("NP-7%");
                    QMIRSNPPercentData = QMIRS_NP_Percent.getQMIRS_NP_PercentData();
                    NPPercentFcastExcludesCLData = NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    bMatched = CommonFunctions.CompareObjectValuesWithSingleData(NPPercentFcastExcludesCLData, 7);
                    Assert.True(bMatched, $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan} does not equal 7.00");
                    CommonFunctions.AddTestStep("Verify NP % should show 7 ", " 7 is displayed.");
                    break;
                case "NP-0%":
                    Console.WriteLine($"NP-0% {Dept}");
                    QMIRSNPPercentData = QMIRS_NP_Percent.getQMIRS_NP_PercentData();
                    NPPercentFcastExcludesCLData = NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    bMatched = CommonFunctions.CompareObjectValuesWithSingleData(NPPercentFcastExcludesCLData, 0);
                    CommonFunctions.AddTestStep("Verify NP % should show 0 ", " 0 is displayed.");
                    Assert.True(bMatched, $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan} does not equal 0");
                    
                    break;
                default:
                    Console.WriteLine("Nothing to compare");
                    break;
            }

            //Verify CL % / FTEs
            switch (FacilityStatsMappingData.CLPercentOrFTE)
            {
                //FTEs
                case "Fixed":
                    Console.WriteLine("CL FTEs -- Fixed");
                    var ClFtesFcastData = ClFtesFcast.getClFtesFcastData();
                    bExist = CommonFunctions.IsElementDisplayed("//input[@id='txtclFtesFixed-1' and not(@readonly)]", 5);
                    Assert.True(bExist, "CL FTEs row is disabled");

                    //Doubl-click Mar
                    ClFtesFcast.DoubleClickMar();
                    ClFtesFcastData = ClFtesFcast.getClFtesFcastData();
                    bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(ClFtesFcastData, ClFtesFcastData.Mar);
                    Assert.True(bMatched, $"Cl Ftes Fcast Mar value didn't get copied to the remaining months of the year");
                    break;

                case "Percent":
                    Console.WriteLine("CL % -- percent");
                    var CLPercentFcastData = CLPercentFcast.getCLPercentFcastData();
                    IWebElement JanCLPercent = CommonFunctions.getElement(By.XPath("//input[@id='txtContractLaborPercent-1' and not(@readonly)]"));
                    Assert.True(JanCLPercent.Enabled, "CL % row is not enabled");

                    //Testing CL %  doubl-click
                    double CLPercentFcastMar = 8;
                    CLPercentFcast.SetMar(CLPercentFcastMar.ToString());
                    CLPercentFcast.DoubleClickMar();
                    CLPercentFcastData = CLPercentFcast.getCLPercentFcastData();
                    bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(CLPercentFcastData, CLPercentFcastMar);
                    Assert.True(bMatched, $"{CLPercentFcastMar} was not filled in the CL % Fcast row’s January – December");

                    //Testing QMRIS double-click
                    var QMIRSData = QMIRS.getQMIRSData();
                    QMIRS.DoubleClickMar();
                    //verify QMIRS Mar value got copied across CL % Fcast
                    CLPercentFcastData = CLPercentFcast.getCLPercentFcastData();
                    bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(CLPercentFcastData, QMIRSData.Mar);
                    Assert.True(bMatched, $"QMIRS Mar value didn't get copied across  CL % Fcast months");
                    break;
            }

            ForecastView_NonProductivePercent.ClickPLUS();
            DeptForecastButtonPanel.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
        }


        [Test]
        [Category("WFT"), Description("Journey")]
        public void BudgetExportFromWFTtoHostJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Budget export from WFT to Host journey";
            VerifyHostFileData();
        }



        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyofPLUSInterface()
        {
            UserCanSendApprovedPlanToPLUSwithDeptartmentData();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyDeleteFunctionality()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Delete Functionality Journey";
            UserCanDeletePlan();
        }

        //[Test]
       // [Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyOfFacilityGoals()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Facility Goals";
            VerifyFacilityGoals();
        }
        
        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifytheJourneyofAverageLaborRateEmpl()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Average Labor rate Empl";
            bool bMathched;
            double monthValue;
            string ApplyToAllDeptOption = string.Empty;
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("3.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            CommonFunctions.WaitUntilPageIsAcive();

            VerifyLatestQMIRS_MonthValueReceivedFromNewPlan();
            VerifyAHRRate();
            VerifyLatest_or_QMRIS_Options();
            UserCanVerifyLatestQMRISMonthInAverageLaborRateEmployee();
            // Testing double-click functionalities 
        }

        public void VerifyLatest_or_QMRIS_Options()
        {
            bool bExists;
            //Verify latest or QMRIS options
            var ApplyToAllDeptOption = "Latest QMIRS Month";
            var QMIRSEmplLbrRateData = AverageLaborRateEmpl.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            AverageLaborRateEmpl.ApplyHistoricalOrLatestQMIRStoAllDepts(ApplyToAllDeptOption);
            //Latest QMIRS Month value from the new plan (e.g., Aug)
            var latestQMIRSMonth = NewPlanLatestQMIRSMonth.LatestQMIRSMonth;
            Console.WriteLine($"latestQMIRSMonth = {latestQMIRSMonth}");
            var monthValue = CommonFunctions.getMonthValueFromMonthlyObject(QMIRSEmplLbrRateData, latestQMIRSMonth);
            Console.WriteLine($"monthValue = {monthValue}");
            var EmployedLaborRateData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();
            var bMathched = CommonFunctions.CompareEntireRowValues(EmployedLaborRateData,  monthValue);
            Assert.True(bMathched,
                $"Latest QMIRS Month value was not applied correctly -- {monthValue}\n{EmployedLaborRateData.Jan}");
        }

        public void VerifyAHRRate()
        {
            bool bMathched;
            //Verify AHR Rate
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "Average Labor Rate - Empl tab was not selected");

            // use this part as a method 11
            AHRRate.GoTo();
            Assert.True(AHRRate.IsAt, "AHR Rate dialog was not displayed");
            AHRRate.QMIRSHistoricalMonth()
                .withMonth("Jul")
                .ApplyToAllDept();
            CommonFunctions.WaitUntilPageIsAcive();
            var QMIRSEmplLbrRateData = AverageLaborRateEmpl.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var EmployedLaborRateData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();
            bMathched = CommonFunctions.CompareObjectValuesWithSingleData(EmployedLaborRateData, QMIRSEmplLbrRateData.Jul);
            Assert.True(bMathched,
                $"AHR Rate was not applied correctly -- {QMIRSEmplLbrRateData.Jul}\n{EmployedLaborRateData.Jul}");
        }

        public void VerifyLatestQMIRS_MonthValueReceivedFromNewPlan()
        {
            //Verify latest QMIRS month value received from the new plan. 
            bool bMathched;
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "Average Labor Rate - Empl tab was not selected");
            var QMIRSEmplLbrRateData = AverageLaborRateEmpl.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            //Latest QMIRS Month value from the new plan (e.g., Aug)
            var latestQMIRSMonth = NewPlanLatestQMIRSMonth.LatestQMIRSMonth;
            var monthValue = CommonFunctions.getMonthValueFromMonthlyObject(QMIRSEmplLbrRateData, latestQMIRSMonth);
            Console.WriteLine($"Latest month: {latestQMIRSMonth} -- {monthValue}");
            var EmployedLaborRateData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();
            bMathched = monthValue == EmployedLaborRateData.Jan;
            Assert.True(bMathched,
                $"Latest QMIRS Month value was not applied correctly -- {monthValue}\n{EmployedLaborRateData.Jan}");
        }

        //[Test]
        //[Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyOfLoadNpPercent()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Load NP %";
            UserCanLoadNPPercent();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyOfSmoothDeptRatio()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Smooth Dept Ratio";
            UserCanSmoothDeptRatio();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifySubmitForApprovalFunctionality()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Submit for Approval functionality";
            UserCanApproveAndReleasePlan();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyApproveFunctionality()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Approve Functionality";
            UserCanApproveRejectedPlan();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyRejectFunctionality()
        {
            //UserCanCreateWFT_AdminNewPlan();
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Reject Functionality";
            UserCanRejectPlan();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyReleaseFunctionality()
        {
            //UserCanCreateWFT_AdminNewPlan();
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Release Functionality";
            UserCanApproveAndReleasePlan();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyDownloadButtonFunctionality()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Download button Functionality";
            UserCanDownloadPlan();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyGoToForecastButtonFunctionality()
        {
            //UserCanCreateWFT_AdminNewPlan();
            UserCanNavigateToDeptForecast();
        }
        
        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyGoToAdminButtonFunctionality()
        {
            //UserCanCreateWFT_AdminNewPlan();
            UserCanNavigateToAdminPage();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyOfComments()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the journey of Comments";
            UserCanAddComments();
        }
        
        

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyDepatmentForecastVolume()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify The Journey Of Volume Section In Department Forecast";
            string VariableAndSemiVariableDept = SettingData.VarSemiVarDept;
            bool bAfterUpdatingMatch;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string StatDescription = $"Stat{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            // Variable And Semi Variable Dept
            var VariableAndSemiVariableDeptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);
            
            //Dept Facility Ratio
            var BeforeDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var DeptFacilityRatioMarValue = BeforeDeptFacilityRatioData.Mar;
            ForecastView_Volume.DeptFacilityRatio.DoubleClickMar();
            var AfterDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            bAfterUpdatingMatch = CommonFunctions.CompareMontlyValuesForSpecificMonth(AfterDeptFacilityRatioData, DeptFacilityRatioMarValue);
            Assert.True(bAfterUpdatingMatch, "Dept Facility Ratio double-click did not work correctly");

            //HistDeptFacilityRatio
            var BeforeHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var HistDeptFacilityRatioMarValue = BeforeHistDeptFacilityRatioData.Mar;
            ForecastView_Volume.HistDeptFacilityRatio.DoubleClickMar();
            var AfterHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            bAfterUpdatingMatch = CommonFunctions.CompareMontlyValuesForSpecificMonth(AfterHistDeptFacilityRatioData, HistDeptFacilityRatioMarValue);
            Assert.True(bAfterUpdatingMatch, "Hist Dept Facility Ratio double-click did not work correctly");

            //Volume fcast Stat 6100 
            var BeforeVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var VolumefcastStat6100MarValue = BeforeVolumefcastStat6100Data.Mar;
            ForecastView_Volume.VolumefcastStat6100.DoubleClickMar();
            var AfterVolumefcastStat6100Dat = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            bAfterUpdatingMatch = CommonFunctions.CompareMontlyValuesForSpecificMonth(AfterVolumefcastStat6100Dat, VolumefcastStat6100MarValue);
            Assert.True(bAfterUpdatingMatch, "Volume fcast Stat 6100 double-click did not work correctly");
        }       

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyOfNonProdPercent()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the journey of Non-Productive %";
            string DeptNum, VariableDept, SemiVariableDept, VarAndSemiVarDept, bDept;
            bool bExists, bEnabled;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Navigate to ISAS home page. 
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            homePage.SwitchToWindow("Workload Forecast");
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            VariableDept = "647";//SettingData.FacStatMappingVariableDept;
            SemiVariableDept = "647";
            VarAndSemiVarDept = "647";
            bDept = "652";
            string Dept = "655";

            Console.WriteLine("First test");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
                .withIgnoredInWFT(true)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            // Get fac stat mapping data for dept
            var FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "not found");
            string wftDepartmentsXpath = "//select[@id='ddlwftDepartments']/option";
            bool bExist = CommonFunctions.IsItemFoundinDropdownMenu(wftDepartmentsXpath, VarAndSemiVarDept);
            Assert.False(bExist, "Dept was found");

            Console.WriteLine("Second test");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
                .withIgnoredInWFT(false) // uncheck Ignore in WFT 
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            Console.WriteLine("Third test");
            DeptForecastButtonPanel.GoToAdmin();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(true)
               .withFreezeStdTgt(true)
               .withFreezeSVStepSel(true)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(true)
               .withFreezeOTPercent(true)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            Console.WriteLine("Fourth test");
            DeptForecastButtonPanel.GoToAdmin();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            //Testing Red color in NP Percent 
            string forecastViewXpath = "//*/label[normalize-space()='Facility Stat']";
            bExist = CommonFunctions.IsElementDisplayed(forecastViewXpath, 2);
            if (!bExist)
            {
                AdminMenu.GoToForecast();
            }
            //string Dept = SettingData.VarSemiVarDept.ToString();
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();
            ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.ModifyNPPercentFcastExcludesCLData("7.50");
            DeptForecastButtonPanel.clickSaveAndRecalc();
            DeptForecastButtonPanel.GoToAdmin();
           // FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            string NPPercentWithRedColorXpath = $"//*/table[@class='tblFacStat']//tr//td/input[contains(@value,'{Dept.Trim()}')]/ancestor::tr//select[@style='background-color:red']";
            bExist = CommonFunctions.IsElementDisplayed(NPPercentWithRedColorXpath, 2);
            Assert.True(bExist, "NP Percent select did not turn to red color");

            //Verify NP % dropdown is disabled when ticking Freeze NP Percent
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(true)
               .withFreezeOTPercent(false)
               .Save();
            bEnabled = FacilityStatsMapping.IsNpPercentDropdownDisabled(VarAndSemiVarDept);
           //Assert.True(bEnabled, $"{VarAndSemiVarDept} was not disabled after checking the freeze NP % checkbox.");

            ////Reset Freeze NP % to false -- uncheck
            //FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
            //  .withIgnoredInWFT(false) // uncheck Ignore in WFT 
            //  .withFacilityStat(string.Empty)
            //  .withCLPercentOrFTE("%") // keep using %
            //  .withNPPercent("PLUS")
            //  .withFreezeRatioVol(false)
            //  .withFreezeStdTgt(false)
            //  .withFreezeSVStepSel(false)
            //  .withFreezeCLPercent(false)
            //  .withFreezeNPPercent(false)
            //  .withFreezeOTPercent(false)
            //  .Save();

            // Verify NP - 7%
            Console.WriteLine("7% part");
            FacilityStatsMapping.ModifyFacilityStatsMapping(bDept)
             .withIgnoredInWFT(false) // uncheck Ignore in WFT 
             .withFacilityStat(string.Empty)
             .withCLPercentOrFTE("%") // keep using %
             .withNPPercent("NP-7%")
             .withFreezeRatioVol(false)
             .withFreezeStdTgt(false)
             .withFreezeSVStepSel(false)
             .withFreezeCLPercent(false)
             .withFreezeNPPercent(false)
             .withFreezeOTPercent(false)
             .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(bDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, bDept);

            // Verify NP - 0%
            Console.WriteLine("0% part");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(bDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("NP-0%")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(bDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, bDept);

            //Testing Override option in NP %
            Console.WriteLine("Override part");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("OVERRIDE")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();

            //Go to dept forecast
            bExist = CommonFunctions.IsElementDisplayed(forecastViewXpath, 2);
            if (!bExist)
            {
                AdminMenu.GoToForecast();
            }
            deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VarAndSemiVarDept.Trim());
            CommonFunctions.WaitUntilPageIsAcive();
            ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.ModifyNPPercentFcastExcludesCLData("9.50");
            DeptForecastButtonPanel.clickSaveAndRecalc();
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            //Verify data            
            NPPercentWithRedColorXpath = $"(//*/table[@class='tblFacStat']//tr[contains(@class,'facilitymapping-row')]//td/input[contains(@value,'{VarAndSemiVarDept.Trim()}')]/../..//select)[4]";
            var redColorNpPercent = CommonFunctions.getElement(By.XPath(NPPercentWithRedColorXpath)).GetCssValue("background-color");
            bool isRed = redColorNpPercent.Equals("rgba(255, 0, 0, 1)", StringComparison.OrdinalIgnoreCase)
                        || redColorNpPercent.Equals("rgb(255, 0, 0)", StringComparison.OrdinalIgnoreCase);            
            Assert.False(isRed, "NP Percent select turned to red color");
        }

        //[Test]
        [Category("WFT"), Description("Journey")]       
        public void VerifyTheJourneyOfOtPercent()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the journey of OT Percent";
            string DeptNum, VariableDept, SemiVariableDept, VarAndSemiVarDept;
            bool bExists, bEnabled;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Navigate to ISAS home page. 
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            homePage.SwitchToWindow("Workload Forecast");
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            VariableDept = SettingData.FacStatMappingVariableDept;
            SemiVariableDept = SettingData.FacStatMappingSemiVariableDept;
            VarAndSemiVarDept = SettingData.VarSemiVarDept;

            Console.WriteLine("First test");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
                .withIgnoredInWFT(true)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            // Get fac stat mapping data for dept
            var FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "not found");
            string wftDepartmentsXpath = "//select[@id='ddlwftDepartments']/option";
            bool bExist = CommonFunctions.IsItemFoundinDropdownMenu(wftDepartmentsXpath, VarAndSemiVarDept);
            Assert.False(bExist, "Dept was found");

            Console.WriteLine("Second test");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
                .withIgnoredInWFT(false) // uncheck Ignore in WFT 
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            Console.WriteLine("Third test");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(true)
               .withFreezeStdTgt(true)
               .withFreezeSVStepSel(true)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(true)
               .withFreezeOTPercent(true)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            Console.WriteLine("Fourth test");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            //Testing Red color in NP Percent 
            string forecastViewXpath = "//*/label[normalize-space()='Facility Stat']";
            bExist = CommonFunctions.IsElementDisplayed(forecastViewXpath, 2);
            if (!bExist)
            {
                AdminMenu.GoToForecast();
            }
            string Dept = SettingData.VarSemiVarDept.ToString();
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();
            ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.ModifyNPPercentFcastExcludesCLData("7.50");
            DeptForecastButtonPanel.clickSaveAndRecalc();
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            string NPPercentWithRedColorXpath = $"//*/table[@class='tblFacStat']//tr//td/input[contains(@value,'{Dept.Trim()}')]/ancestor::tr//select[@style='background-color:red']";
            bExist = CommonFunctions.IsElementDisplayed(NPPercentWithRedColorXpath, 2);
            Assert.True(bExist, "NP Percent select did not turn to red color");

            //Verify NP % dropdown is disabled when ticking Freeze NP Percent
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("PLUS")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(true)
               .withFreezeOTPercent(false)
               .Save();
            bEnabled = FacilityStatsMapping.IsNpPercentDropdownDisabled(VarAndSemiVarDept);
            Assert.True(bEnabled, $"{VarAndSemiVarDept} was not disabled after checking the freeze NP % checkbox.");

            //Reset Freeze NP % to false -- uncheck
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
              .withIgnoredInWFT(false) // uncheck Ignore in WFT 
              .withFacilityStat(string.Empty)
              .withCLPercentOrFTE("%") // keep using %
              .withNPPercent("PLUS")
              .withFreezeRatioVol(false)
              .withFreezeStdTgt(false)
              .withFreezeSVStepSel(false)
              .withFreezeCLPercent(false)
              .withFreezeNPPercent(false)
              .withFreezeOTPercent(false)
              .Save();

            // Verify NP - 6%
            Console.WriteLine("6% part");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
             .withIgnoredInWFT(false) // uncheck Ignore in WFT 
             .withFacilityStat(string.Empty)
             .withCLPercentOrFTE("%") // keep using %
             .withNPPercent("NP-6%")
             .withFreezeRatioVol(false)
             .withFreezeStdTgt(false)
             .withFreezeSVStepSel(false)
             .withFreezeCLPercent(false)
             .withFreezeNPPercent(false)
             .withFreezeOTPercent(false)
             .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            // Verify NP - 0%
            Console.WriteLine("0% part");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("NP-0%")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VarAndSemiVarDept);
            VerifyFacilityStatsMappingData(FacilityStatsMappingData, VarAndSemiVarDept);

            //Testing Override option in NP %
            Console.WriteLine("Override part");
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VarAndSemiVarDept)
               .withIgnoredInWFT(false) // uncheck Ignore in WFT 
               .withFacilityStat(string.Empty)
               .withCLPercentOrFTE("%") // keep using %
               .withNPPercent("OVERRIDE")
               .withFreezeRatioVol(false)
               .withFreezeStdTgt(false)
               .withFreezeSVStepSel(false)
               .withFreezeCLPercent(false)
               .withFreezeNPPercent(false)
               .withFreezeOTPercent(false)
               .Save();

            //Go to dept forecast
            bExist = CommonFunctions.IsElementDisplayed(forecastViewXpath, 2);
            if (!bExist)
            {
                AdminMenu.GoToForecast();
            }
            deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VarAndSemiVarDept.Trim());
            CommonFunctions.WaitUntilPageIsAcive();
            ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.ModifyNPPercentFcastExcludesCLData("9.50");
            DeptForecastButtonPanel.clickSaveAndRecalc();
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            //Verify data
            NPPercentWithRedColorXpath = $"//*/table[@class='tblFacStat']//tr//td/input[contains(@value,'{Dept.Trim()}')]/ancestor::tr//select[@style='background-color:red']";
            bExist = CommonFunctions.IsElementDisplayed(NPPercentWithRedColorXpath, 2);
            Assert.False(bExist, "NP Percent select turned to red color");
        } 
        
        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyOfStatusDropdown()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Status drop down";
            string SemiVariableDept, currentStatus;
            bool bMatched;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            SemiVariableDept = SettingData.FacStatMappingSemiVariableDept;
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            ExistingPlanFilter.GoTo();
            currentStatus = ExistingPlanFilter.getPlanStatus();
            Console.WriteLine($"currentStatus {currentStatus}");
            bMatched = string.Equals(currentStatus.Trim(), "Working", StringComparison.InvariantCultureIgnoreCase);
            Assert.True(bMatched, $"Working was not displayed");

            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus("Released")
                .withPlan(string.Empty)
                .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            ExistingPlanFilter.GoTo();
            currentStatus = ExistingPlanFilter.getPlanStatus();
            bMatched = currentStatus.Trim().Contains("Released");
            Assert.True(bMatched, $"Approved & Released was not displayed");

            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus("Historical")
                .withPlan(string.Empty)
                .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            ExistingPlanFilter.GoTo();
            currentStatus = ExistingPlanFilter.getPlanStatus();
            bMatched = currentStatus.Trim().Contains("Historical");
            Assert.True(bMatched, $"Approved Historical was not displayed");
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyPaidHrsAndFTEsJourney()
        {
            UserCanVerifyPaidHrsAndFTEsJourney();
        }

        [Test]
        [Category("WFT"), Description("Journey")]
        public void VerifyTheJourneyOfDepartmentForecastSummary()
        {
            VerifyDepartmentForecastSummary();
        }


        [Test]
        [Category("WFT")]
        public void StaffingGridAndWftInterface()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of SG - WFT Interface";

            string facility = "30997";
            string currentYear = CommonFunctions.GetCurrentYear();
            string startDate = $"12/01/{currentYear}";
            string TodaysDate = CommonFunctions.GetTodaysDateWithFormateMddyyyy();            
            double VarProdHrsVolTotal;
            bool bDispayed, bMatched;
            string interfaceMsg;
            string SgDept = SettingData.SgDeptII;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            
            homePage.NavigateToWorkloadForecaster();
           
            Division.SetWFTDivisionAndFacility(facility);
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToStaffingGrid();
            Division.SetStaffingGridDivisionAndFacility(facility);
            SgMainMenu.SelectGrid();
            StaffingGridFliterPage.SgFilter()
                .withDepartment(SgDept)
                .withStatus("New - Blank")
                .withStaffingGrid(string.Empty)
                .Create();
            string SgDescription = $"SG_{CommonFunctions.GenerateRandonNumber()}";
            CommonFunctions.AddTestStep($"Verfiy a user can set SG detail with {SgDescription} and {startDate}", "The SG were created with specific name and date.");
            StaffingGridMainPage.SetStaffingGridDetails(startDate, SgDescription);
            CommonFunctions.WaitUntilPageIsAcive();
           
            var SumOfSubTotals = StaffingGridMainPage.SetOrientationAndEducation();
            Console.WriteLine($"Sun = {SumOfSubTotals.Sun.ToString()}");
            var StaffingGridMainDetails = StaffingGridMainPage.GetStaffingGridDetails();
            SgMainMenu.clickNextStep();
            var StaffingGridDetailTotals = StaffingGridDetails.getStaffingGridDetailTotals();
            //SG target
            VarProdHrsVolTotal = StaffingGridDetailTotals.VarProdHrsVolTotal;
            Console.WriteLine(StaffingGridDetailTotals.VarProdHrsVolTotal);           
            SgMainMenu.clickSubmitForApproval();
            //Navigate to ISAS home page.
            homePage.SwitchToWindow("Workload Forecast");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");

            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("1.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMRIS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            AdminMenu.GoToForecast();
            CommonFunctions.WaitUntilPageIsAcive();
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SgDept);
            CommonFunctions.WaitUntilPageIsAcive();
            //verify message
            interfaceMsg = "//*/label[contains(text(),'NOTE: The interfaced')]";
            bDispayed = CommonFunctions.IsElementDisplayed(interfaceMsg, 5);
            Console.WriteLine($"The msg was displayed = {bDispayed.ToString()}");
           // Assert.True(bDispayed, "WFT-SG interface mssage was not displayed.");
            //DeptForecastButtonPanel.clickSaveAndRecalc();           
            var FcastVarStdData = FcastVarStd.getFcastVarStdData();
            bMatched = CommonFunctions.CompareEntireRowValues(FcastVarStdData, VarProdHrsVolTotal);
            Assert.True(bMatched, $"{VarProdHrsVolTotal} was not copied correctly from SG to WFT\n" +
                $"It's {FcastVarStdData.Jan}");
            //Verify S button is selected and is in bold. 
            string SgButtonInBold = "//a[@id='staffingGridVarStdFillBtn' and contains(@style,'bold')]";
            bDispayed = CommonFunctions.IsElementDisplayed(SgButtonInBold, 5);
            Assert.True(bDispayed, "the S button is not in bold");
            var lstStepTargetsWeekDaysForAllMonths =  SVFTEStepTargets.GetStepTargetsWeekDays();
            bMatched = CommonFunctions.CompareWeekDaysValues(lstStepTargetsWeekDaysForAllMonths[1], SumOfSubTotals);
            SVFTEStepTargets.CancelStepTargets();
            Assert.True(bMatched, "Sub-Totals are not copied correctly to the step target dialog");

            //Verify buttons are bold when selected
            FcastVarStd.ClickPlus();
            bDispayed = FcastVarStd.isPlusBold();
            Assert.True(bDispayed, "the P button is not in bold");

            FcastVarStd.ClickQUMRIS();
            bDispayed = FcastVarStd.isQumrisBold();
            Assert.True(bDispayed, "the Q button is not in bold");

            FcastVarStd.ClickSG();
            bDispayed = FcastVarStd.isSgBold();
            Assert.True(bDispayed, "the S button is not in bold");
            DeptForecastButtonPanel.clickSaveAndRecalc();




            //Add another target
            homePage.SwitchToWindow("ISAS Portal");
            homePage.SwitchToWindow("Staffing Grid");
            Division.SetStaffingGridDivisionAndFacility(facility);
            SgMainMenu.SelectGrid();
            StaffingGridFliterPage.SgFilter()
                .withDepartment(SgDept)
                .withStatus("New - Blank")
                .withStaffingGrid(string.Empty)
                .Create();
            SgDescription = $"SG_{CommonFunctions.GenerateRandonNumber()}";
            CommonFunctions.AddTestStep($"Verfiy a user can set SG detail with {SgDescription} and {startDate}", "The SG were created with specific name and date.");
            StaffingGridMainPage.SetStaffingGridDetails(startDate, SgDescription);
            CommonFunctions.WaitUntilPageIsAcive();

            SumOfSubTotals = StaffingGridMainPage.SetOrientationAndEducation();
            Console.WriteLine($"Sun = {SumOfSubTotals.Sun.ToString()}");
            StaffingGridMainDetails = StaffingGridMainPage.GetStaffingGridDetails();
            SgMainMenu.clickNextStep();
            StaffingGridDetailTotals = StaffingGridDetails.getStaffingGridDetailTotals();
            //SG target
            VarProdHrsVolTotal = StaffingGridDetailTotals.VarProdHrsVolTotal;
            Console.WriteLine(StaffingGridDetailTotals.VarProdHrsVolTotal);
            SgMainMenu.clickSubmitForApproval();
            //Navigate to ISAS home page.
            homePage.SwitchToWindow("Workload Forecast");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus(string.Empty)
               .withPlan(string.Empty)
               .Select();
            //Varialbe dept
            deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SgDept);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //verify message
            interfaceMsg = "//*/label[contains(text(),'NOTE: The interfaced')]";
            bDispayed = CommonFunctions.IsElementDisplayed(interfaceMsg, 12);
            Console.WriteLine($"The msg was displayed = {bDispayed.ToString()}");
            Assert.True(bDispayed, "WFT-SG interface mssage was not displayed.");
            DeptForecastButtonPanel.clickSaveAndRecalc();
            //DeptForecastButtonPanel.clickDeptSaveAndRecalc();
            CommonFunctions.WaitSaveToastMsgDisappeared();
            //verify the message is invisible.
            bDispayed = CommonFunctions.IsElementDisplayed(interfaceMsg, 5);
            Assert.False(bDispayed, "WFT-SG interface mssage was still displayed after saving");


            FcastVarStdData = FcastVarStd.getFcastVarStdData();
            bMatched = CommonFunctions.CompareEntireRowValues(FcastVarStdData, VarProdHrsVolTotal);
            Assert.True(bMatched, $"{VarProdHrsVolTotal} was not copied correctly from SG to WFT\n" +
                $"It's {FcastVarStdData.Jan}");
            //Verify S button is selected and is in bold. 
            SgButtonInBold = "//a[@id='staffingGridVarStdFillBtn' and contains(@style,'bold')]";
            bDispayed = CommonFunctions.IsElementDisplayed(SgButtonInBold, 5);
            Assert.True(bDispayed, "the S button is not in bold");
            lstStepTargetsWeekDaysForAllMonths = SVFTEStepTargets.GetStepTargetsWeekDays();
            bMatched = CommonFunctions.CompareWeekDaysValues(lstStepTargetsWeekDaysForAllMonths[1], SumOfSubTotals);
            SVFTEStepTargets.CancelStepTargets();
            Assert.True(bMatched, "Sub-Totals are not copied correctly to the step target dialog");

            //Verify buttons are bold when selected
            FcastVarStd.ClickPlus();
            bDispayed = FcastVarStd.isPlusBold();
            Assert.True(bDispayed, "the P button is not in bold");

            FcastVarStd.ClickQUMRIS();
            bDispayed = FcastVarStd.isQumrisBold();
            Assert.True(bDispayed, "the Q button is not in bold");

            FcastVarStd.ClickSG();
            bDispayed = FcastVarStd.isSgBold();
            Assert.True(bDispayed, "the S button is not in bold");
            DeptForecastButtonPanel.clickDeptSaveAndRecalc();
            CommonFunctions.WaitSaveToastMsgDisappeared();
        }       

        #region: Journeys functions

        // [Test] [Category("WFT")]
        public void UserCanCreateWFT_AdminNewPlan()
        {

            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine("environment" + Environment.GetEnvironmentVariable("ISASQA"));
            //homePage.LaunchISASApplication("QA");
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
           
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("10.00")
                    .withFreezeFacilityRatiosAndVolumes(true)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

        }  

        
        

        [Test] [Category("WFT")]
        public void VerifyDepartmentDetails()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Department Details Journey";
            string SemiVariableDept;
            bool bDeptStat, bFacilityStatToUse, bPLUSDeptType, bDeptTypeToUse;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            SemiVariableDept = SettingData.FacStatMappingSemiVariableDept;
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();

            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page was not displayed.");
            // Get fac stat mapping data for dept
            var FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept);
            AdminMenu.GoToForecast();
            CommonFunctions.WaitUntilPageIsAcive();
            //Set Dept
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SemiVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();
            bDeptStat = string.Equals(FacilityStatsMappingData.DepartmentStat, deptDetails.DeptStat, StringComparison.InvariantCultureIgnoreCase);
            Console.WriteLine($"bDeptStat = {bDeptStat}");
            bFacilityStatToUse = string.Equals(FacilityStatsMappingData.FacilityStat, deptDetails.FacilityStatToUse, StringComparison.InvariantCultureIgnoreCase);
            Console.WriteLine($"bFacilityStatToUse = {bFacilityStatToUse}");
            bPLUSDeptType = string.Equals(FacilityStatsMappingData.WFTDeptType, deptDetails.PLUSDeptType, StringComparison.InvariantCultureIgnoreCase);
            Console.WriteLine($"bPLUSDeptType = {bPLUSDeptType}");
            bPLUSDeptType = string.Equals(FacilityStatsMappingData.WFTDeptType, deptDetails.PLUSDeptType, StringComparison.InvariantCultureIgnoreCase);
            Console.WriteLine($"bPLUSDeptType = {bPLUSDeptType}");
            bDeptTypeToUse = string.Equals(deptDetails.DeptTypeToUse, deptDetails.PLUSDeptType, StringComparison.InvariantCultureIgnoreCase);
            Console.WriteLine($"bDeptTypeToUse = {bDeptTypeToUse}");
            Assert.True(bDeptStat && bFacilityStatToUse && bPLUSDeptType && bDeptTypeToUse,
                "No macth");

        }

        
        private void UserCanVerifyLatestQMRISMonthInAverageLaborRateEmployee()
        {
            bool bMathched;
            double monthValue;             
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "Average Labor Rate - Empl tab was not selected");
            var QMIRSEmplLbrRateData = AverageLaborRateEmpl.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();           
            //Latest QMIRS Month value from the new plan (e.g., Aug)
            var latestQMIRSMonth = NewPlanLatestQMIRSMonth.LatestQMIRSMonth;
            monthValue = CommonFunctions.getMonthValueFromMonthlyObject(QMIRSEmplLbrRateData, latestQMIRSMonth);
            var EmployedLaborRateData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();
            bMathched = monthValue == EmployedLaborRateData.Jan;
            Assert.True(bMathched,
                $"Latest QMIRS Month value was not applied correctly -- {monthValue}\n{EmployedLaborRateData.Jan}");
        }

        //Verify that Forecast row highlights if the forecast row data is not matching with Host budget data
        [Test] [Category("WFT")]
        public void VerifyThatForecastRowIsHighlightedIfForecastRowDataDoesnotMatchwithHostBudgetData()
        {
            bool bHostBudgetWarning, bForecastWarning;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(false)
                    .Create();
            FacilityStats.GoTo();
            Assert.True(FacilityStats.IsAt, "Facility Stats page was not displayed.");
            Assert.True(FacilityStats.IsHostBudgetWarningDispayed(), "Host budget warning was not displayed.");
            Assert.True(FacilityStats.IsForecastWarningDispayed(), "Forecast warning was not displayed.");
        }        

        [Test] 
        [Category("WFT")]
        public void VerifyTheJourneyofFacilityStats()
        {
            bool bTotalEqualsSumOfMonth;   
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Facility Stats";
            bool bFound, bAfterUpdatingMatch, bQMIRSMatch, bMatched, bFacStat17, bFacStat4138, bFacStat4142;
            double BudgetVolumePercent = 2;
            string lstElementsXpath, FacStatID;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
             Division.SetWFTDivisionAndFacility("30928");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string StatDescription = $"Stat{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage(BudgetVolumePercent.ToString())
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(false)
                    .Create();
            FacilityStats.GoTo();
            Assert.True(FacilityStats.IsAt, "Facility Stats wasn't displayed");
            Assert.True(FacilityStats.IsHostBudgetWarningDispayed(), "Host budget warning was not displayed.");
            Assert.True(FacilityStats.IsForecastWarningDispayed(), "Forecast warning was not displayed.");
            var ForecastBeforeUpdatingVolume = FacilityStats.getFacilityStatForecastsDataWithWarning();            
            FacStatID = ForecastBeforeUpdatingVolume.FacilityStatID;
            Console.WriteLine($"FacStatID = {FacStatID}");


            //Double-click testing
            //FacilityStats.GoTo();
            var FacilityStatQMIRS_HistAndProjectionData = FacilityStats.getFacilityStatQMIRS_HistAndProjectionWithStatID(FacStatID);

            //Verify the sum of all months value is equal to the total value
            var isMatched = CommonFunctions.VerifySumOfMonthValuesEqualTotalValue(FacilityStatQMIRS_HistAndProjectionData);
            Assert.True(isMatched, "The sum of all months value deosn't equal to the total value");

            var QMIRS_HistAndProjectionMar = FacilityStatQMIRS_HistAndProjectionData.Mar;
            FacilityStats.DoubClickQMIRS_HistCell(FacStatID);            

            var FacilityStatForecastData = FacilityStats.getFacilityStatForecastDataWithStatID(FacStatID);
            isMatched = CommonFunctions.VerifySumOfMonthValuesEqualTotalValue(FacilityStatForecastData);
            Assert.True(isMatched, "The sum of all months value deosn't equal to the total value");

            bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(FacilityStatForecastData, QMIRS_HistAndProjectionMar);
            Assert.True(bMatched, "Forecast months did not match QMIRSy_Hist Mar value");
            bTotalEqualsSumOfMonth = CommonFunctions.VerifyMonthValuesEqualTotal(FacilityStatForecastData);
            Assert.True(bTotalEqualsSumOfMonth, $"The total value did not match the sum of all months of FacilityStatForecastData");

            //FacilityStats.GoTo();
            var FacilityStatHostBudgetData = FacilityStats.getFacilityStatHostBudget(FacStatID);
            var HostBudgetMar = FacilityStatHostBudgetData.Mar;
            FacilityStats.DoubClickHostBudgetCell(FacStatID);
            FacilityStatForecastData = FacilityStats.getFacilityStatForecastDataWithStatID(FacStatID);
            bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(FacilityStatForecastData, HostBudgetMar);
            Assert.True(bMatched, "Forecast months did not match Host Budget Mar value");
            bTotalEqualsSumOfMonth = CommonFunctions.VerifyMonthValuesEqualTotal(FacilityStatForecastData);
            Assert.True(bTotalEqualsSumOfMonth, $"The total value did not match the sum of all months of FacilityStatForecastData");



            //Insert a value in Forecast row and double-click Mar cell
            // FacilityStats.GoTo();
            double sForecastValue = 542.00;
            FacilityStats.InsertAndDoubClickInForecastCell(FacStatID, sForecastValue.ToString());
            FacilityStatForecastData = FacilityStats.getFacilityStatForecastDataWithStatID(FacStatID);
            bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(FacilityStatForecastData, sForecastValue);
            Assert.True(bMatched, $"Forecast months Mar-Dec did not match {sForecastValue}");
            bTotalEqualsSumOfMonth = CommonFunctions.VerifyMonthValuesEqualTotal(FacilityStatForecastData);
            Assert.True(bTotalEqualsSumOfMonth, $"The total value did not match the sum of all months of FacilityStatForecastData");

            // Double - click percent change row.
            ////Get all stat names in the facility stats page
            var lstStatNames = FacilityStats.getStatNames();
            string StatName = lstStatNames[3];
            Console.WriteLine($"lstStatNames count = {lstStatNames.Count.ToString()}");
            Console.WriteLine($"StatName = {lstStatNames[3]}");
            var PercentChangeMonthData = FacilityStats.GetPercentChange(StatName);
            var PercentChangeMar = PercentChangeMonthData.Mar;
            Console.WriteLine($"PercentChangeMar = {PercentChangeMar}");
            var PercentChangeMonths = FacilityStats.GetPercentChangeRow(StatName);
            CommonFunctions.DoubleClickUsingWebElement(PercentChangeMonths.Mar);
            AdminMenu.Save();
            FacilityStats.CancelUpdatePlan();
            var afterPercentChangeMonthData = FacilityStats.GetPercentChange(StatName);
            // bMatched = CommonFunctions.CompareMontlyValuesForSpecificMonth(afterPercentChangeMonthData, PercentChangeMar);
            // Assert.True(bMatched, $"Percent change months Mar-Dec did not match {PercentChangeMar}");
            //bTotalEqualsSumOfMonth = CommonFunctions.VerifyMonthValuesEqualTotal(PercentChangeMonthData);
            //Assert.True(bTotalEqualsSumOfMonth, $"The total value did not match the sum of all months of PercentChangeData");
            VerifyCalculationForFacilityStats(FacStatID);

            //Update budget volume
            FacilityStats.GoTo();
            Console.WriteLine(" -- Load Budget Volume --");
            FacilityStats.LoadVolume("Budget Volume");
            var ForecastAfterUpdatingVolume = FacilityStats.getFacilityStatForecastsDataAfterUpdaingVolume(FacStatID);
            var HostBudgetNextYear = FacilityStats.getFacilityStatHostBudget(FacStatID);
            bAfterUpdatingMatch = ForecastAfterUpdatingVolume.Jan == HostBudgetNextYear.Jan;
            Assert.True(bAfterUpdatingMatch, $"No match:\n" +
                $"HostBudgetNextYear.Jan: {HostBudgetNextYear.Jan} and\n" +
                $"ForecastAfterUpdatingVolume.Jan: {ForecastAfterUpdatingVolume.Jan}");
            bTotalEqualsSumOfMonth = CommonFunctions.VerifyMonthValuesEqualTotal(HostBudgetNextYear);
            Assert.True(bTotalEqualsSumOfMonth, $"The total value did not match the sum of all months of HostBudgetNextYear");



            //Load QMIRS
            Console.WriteLine(" -- Load QMIRS Volume --");
            FacilityStats.CancelUpdatePlan();
            FacilityStats.LoadVolume("QMIRS Volume");
            FacilityStats.CancelUpdatePlan();
            ForecastBeforeUpdatingVolume = FacilityStats.getFacilityStatForecastsDataWithWarning();
            var QMIRS_Hist = FacilityStats.getFacilityStatQMIRS_HistAndProjectionWithStatID(ForecastBeforeUpdatingVolume.FacilityStatID);
            bQMIRSMatch = ForecastBeforeUpdatingVolume.Jan == QMIRS_Hist.Jan;
            Assert.True(bQMIRSMatch, $"ForecastBeforeUpdatingVolume.Jan: {ForecastBeforeUpdatingVolume.Jan}\n" +
                $"QMIRS_Hist.Jan: {QMIRS_Hist.Jan}");
            bTotalEqualsSumOfMonth = CommonFunctions.VerifyMonthValuesEqualTotal(QMIRS_Hist);
            Assert.True(bTotalEqualsSumOfMonth, $"The total value did not match the sum of all months of QMIRS_Hist");
            VerifyCalculationForFacilityStats(FacStatID);

            //verify Q and H 
            //click H
            FacilityStats.ClickHostBudget(FacStatID);
            Console.WriteLine(" -- Testing H button --");
            ForecastAfterUpdatingVolume = FacilityStats.getFacilityStatForecastsDataAfterUpdaingVolume(FacStatID);
            HostBudgetNextYear = FacilityStats.getFacilityStatHostBudget(FacStatID);
            bAfterUpdatingMatch = ForecastAfterUpdatingVolume.Jan == HostBudgetNextYear.Jan;
            Assert.True(bAfterUpdatingMatch, $"No match:\n" +
                $"HostBudgetNextYear.Jan: {HostBudgetNextYear.Jan} and\n" +
                $"ForecastAfterUpdatingVolume.Jan: {ForecastAfterUpdatingVolume.Jan}");
            AdminMenu.Save();
            bTotalEqualsSumOfMonth = CommonFunctions.VerifyMonthValuesEqualTotal(HostBudgetNextYear);
            Assert.True(bTotalEqualsSumOfMonth, $"The total value did not match the sum of all months of HostBudgetNextYear");
            VerifyCalculationForFacilityStats(FacStatID);

            //Click Q
            Console.WriteLine(" -- Testing Q button --");
            FacilityStats.ClickQMIRS(FacStatID);
            var QMIRSData = FacilityStats.getFacilityStatForecastsDataAfterUpdaingVolume(FacStatID);
            QMIRS_Hist = FacilityStats.getFacilityStatQMIRS_HistAndProjectionWithStatID(ForecastBeforeUpdatingVolume.FacilityStatID);
            bQMIRSMatch = ForecastBeforeUpdatingVolume.Jan == QMIRS_Hist.Jan;
            Assert.True(bQMIRSMatch, $"ForecastBeforeUpdatingVolume.Jan: {ForecastBeforeUpdatingVolume.Jan}\n" +
                $"QMIRS_Hist.Jan: {QMIRS_Hist.Jan}");
            AdminMenu.Save();
            bTotalEqualsSumOfMonth = CommonFunctions.VerifyMonthValuesEqualTotal(QMIRS_Hist);
            Assert.True(bTotalEqualsSumOfMonth, $"The total value did not match the sum of all months of QMIRS_Hist");
            VerifyCalculationForFacilityStats(FacStatID);
            ////Click Fill
            //FacilityStats.ClickFill(FacStatID);
            //var ForecastData = FacilityStats.getFacilityStatForecastsDataAfterUpdaingVolume(FacStatID);
            //bMatched = ForecastData.Jan == ForecastData.Sep;
            //Assert.True(bMatched, $"ForecastData.Jan: {ForecastData.Jan}\n" +
            //    $"ForecastData.Sep: {ForecastData.Sep}");

            //Add a facility stat
            FacilityStats.AddFacilityStat()
                .withStatDescription(StatDescription)
                .withStatJanuary("0")
                .withForecastJanuary("0")
                .withPercentChange("0")
                .Save();
            FacilityStats.CancelUpdatePlan();
            lstStatNames = FacilityStats.getNewAddedStatNames();
            bFound = lstStatNames.Exists(x =>string.Equals(x,StatDescription,StringComparison.InvariantCultureIgnoreCase));
            //lstElementsXpath = "//*/input[@class='fac-stat-name' and @title]";
            //bFound = CommonFunctions.SearchItemByValue(lstElementsXpath, StatDescription);
            Assert.True(bFound, $"{StatDescription} was not added or not found");

            //Delete fac stat
            Assert.False(FacilityStats.DeleteFacStat(),
                $"{StatDescription} was not deleted.");
           
            //Verify Fac Stat 17 is disabled
            bFacStat17 = CommonFunctions.IsElementDisplayed("(//*/div//input[@value='17']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[@readonly])[1]", 2);
            Assert.True(bFacStat17, "Fac Stat 17 is enabled");
            //Verify Fac Stat 4138 is disabled
            bFacStat4138 = CommonFunctions.IsElementDisplayed("(//*/div//input[@value='4138']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[@readonly])[1]", 2);
            Assert.True(bFacStat4138, "Fac Stat 4138 is enabled");
            //Verify Fac Stat 4142 is disabled
            bFacStat4142 = CommonFunctions.IsElementDisplayed("(//*/div//input[@value='4142']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[@readonly])[1]", 2);
            Assert.True(bFacStat4138, "Fac Stat 4142 is enabled");

            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage(BudgetVolumePercent.ToString())
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(false)
                    .Create();

            verifySumOfAllRowsInFacilityStat();
            //Submit a plan and verify data
            PlanWorkflow.SubmitPlan();
            verifySumOfAllRowsInFacilityStat();
            //Approved a plan and verify data
            PlanWorkflow.ApprovedPlan();
            verifySumOfAllRowsInFacilityStat();
            //Relase a plan and verify data
            PlanWorkflow.ReleasePlan();
            verifySumOfAllRowsInFacilityStat();
        }

        private void verifySumOfAllRowsInFacilityStat()
        {
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStats.GoTo();
            Assert.True(FacilityStats.IsAt, "Facility Stats wasn't displayed");

            var FacilityStatsCodsAndStatIds = FacilityStats.getAllStatIdAndCodes();
            foreach (KeyValuePair<string, string> pair in FacilityStatsCodsAndStatIds)
            {
                Console.WriteLine("Current stat Id and code: {0}, {1}", pair.Key, pair.Value);
                VerifyCalculationForFacilityStats(pair.Key);
            }
        }


        private void VerifyCalculationForFacilityStats(string FacStatID)
        {
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStats.GoTo();
            Assert.True(FacilityStats.IsAt, "Facility Stats wasn't displayed");
            Thread.Sleep(3000);
            bool bMatched, bQmirsHistTotal, bHostBudgetTotal, bForecastsTotal;
            var FacilityStatQmirsHistAndProjectionData = FacilityStats.getFacilityStatQMIRS_HistAndProjectionWithStatID(FacStatID);
            var FacilityStatHostBudgetData = FacilityStats.getFacilityStatHostBudget(FacStatID);
            var FacilityStatForecastsData = FacilityStats.getFacilityStatForecastDataWithStatID(FacStatID);
            var FacilityStatPercentChangeData = FacilityStats.getFacilityStatPercentChange(FacStatID);

            var PercentChangeCalculated = FacilityStats.CalculatePercentChange(FacilityStatForecastsData, FacilityStatQmirsHistAndProjectionData);
            bMatched = CommonFunctions.CompareDataObjects(PercentChangeCalculated, FacilityStatPercentChangeData);
            Assert.True(bMatched, $"% Change didn't match");

            bQmirsHistTotal = CommonFunctions.VerifySumOfMonthValuesEqualTotalValue(FacilityStatQmirsHistAndProjectionData);
            Assert.True(bQmirsHistTotal, $"The sum of QMRIS months did not equal the total value");
            bHostBudgetTotal = CommonFunctions.VerifySumOfMonthValuesEqualTotalValue(FacilityStatHostBudgetData);
            Assert.True(bHostBudgetTotal, $"The sum of Host Budget months did not equal the total value");
            bForecastsTotal = CommonFunctions.VerifySumOfMonthValuesEqualTotalValue(FacilityStatForecastsData);
            Assert.True(bForecastsTotal, $"The sum of Forecasts months did not equal the total value");

        }

        //[Test] [Category("WFT")]
        public void VerifyFacilityMaintenanceJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Facility Maintenance Journey";
            string Year = CommonFunctions.GetNextYear();
            string SemiVariableDept = SettingData.deptDetail;
            // Test color for excluded months (Dec)
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFTFacilty.GoTo();
            Assert.True(WFTFacilty.IsAt, "Facility page was not displayed.");
            WFTFacilty.SetFacility()
                .withNumberOfRequiredApprovers("1 - One")
                .withNewPlanNonProductivePercent("Use Most Recent Approved Plan")
                .withNewPlanStatisticMapping("Use Most Recent Approved Plan")
                .withNewPlanVclPercentOrFixedFtes("Use Percent")
                .withCopyingPlanNonProductivePercent("Use Copied Plan")
                .withCopyingPlanStatisticMapping("Use Copied Plan")
                .withCopyingPlanEE_AHR_Months("Use Copied Plan")
                .withCopyingPlanCL_AHR_Months("Use Copied Plan")
                .withCopyingPlanCLPercentOrFixedFtes("Use Fixed")
                .withNewDeptartment(false) // if true, dept will be added. 
                .withNumber("601")
                .withDescription("text")
                .withDepartmentType("Semi-Variable")
                .withDefaultFacilityStat("BIRTHS - 5815")
                .withDepartmentStat("text")
                .Save();
            //It takes a bit of time for new chages to sync
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();

            //intialize FacilityOptions class with data
            WFTFacilty.SetFacility()
                .getFacilityOptions();

            //verify new plan setting
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            //Get a new plan default set up.
            AdministrationNewPlan.NewPlan()
                .getNewPlanDefaultSetup();

            //verify option selected in the facility options are reflected in the new plan. 
            verifyNewPlanDefaultSetup();
            CommonFunctions.AddTestStep("Verify that the new plan created has the options selected in the faility page.", "The new plan has all options selected");

            WFTMainMenu.WorkloadForecast.DepartmentForecast.SelectDepartmentForecast();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .Select();
            var color = HistDeptFacilityRatio.GetColor();
            Console.WriteLine(color);
            Assert.IsTrue(string.Equals(color, "rgba(164, 164, 164, 1)", StringComparison.InvariantCultureIgnoreCase),
                "Color didn't match.");
            //verify other option in Dept fcast page.
            verifyFacilityOptionsInDeptFcastPageForNewPlan();

            //Navigate to Admin plan
            DeptForecastButtonPanel.GoToAdmin();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Existing plan filter was displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("All")
                .withPlan(string.Empty)
                .Select();

            // copy a plan
            CopyPlan.GoTo();
            string CopiedPlanDescription = $"Copied_{PlanDescription}";
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");
            verifyFacilityStatMappingOptionsForCopiedPlan(SemiVariableDept);
            AdminMenu.GoToForecast();
            verifyFacilityOptionsInDeptFcastPageForCopiedPlan();
            //Go to dept Fcast page
            //AdminMenu.GoToForecast();
            WFTMainMenu.WorkloadForecast.DepartmentForecast.SelectDepartmentForecast();
            verifyFacilityOptionsInDeptFcastPageForCopiedPlan();
        } 

        private void verifyFacilityStatMappingOptionsForCopiedPlan(string SemiVariableDept)
        {
            var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept);
            switch (FacilityMenuOptions.CopyingPlanNonProductivePercent)
            {
                case "Use QMIRS NP %":
                    Assert.True(CopiedPlanFacilityStatsMapping.NPPercent.Contains("QMIRS"), "QMIRS was not selected in the facility stat mapping page");
                    break;
                case "Use PLUS Avg. NP %":
                    Assert.True(CopiedPlanFacilityStatsMapping.NPPercent.Contains("PLUS"), "PLUS was not selected in the facility stat mapping page");
                    break;
                default:
                    break;
            }

            switch (FacilityMenuOptions.CopyingPlanCLPercentOrFixedFtes)
            {
                case "Use Percent":
                    Assert.True(CopiedPlanFacilityStatsMapping.CLPercentOrFTE.Contains("%"), "% was not selected the facility stat mapping page");
                    break;
                case "Use Fixed":
                    Assert.True(CopiedPlanFacilityStatsMapping.CLPercentOrFTE.Contains("FTE"), "FTE was not selected the facility stat mapping page");
                    break;
                default:
                    break;
            }


        }
        
        private void verifyNewPlanDefaultSetup()
        {
            bool isMatched;
            isMatched = FacilityMenuOptions.NumberOfRequiredApprovers.Contains(NewPlanElements.Approvers);
            Assert.True(isMatched, $"Number of required approvers did not match\n" +
                $"Facility options: {FacilityMenuOptions.NumberOfRequiredApprovers}\n" +
                $"New plan: {NewPlanElements.Approvers}");

            switch (FacilityMenuOptions.NewPlanNonProductivePercent)
            {
                case "Use QMIRS NP %":
                    Assert.True(NewPlanElements.NonProductiveQMIRSAvgNpPercent, "Non Productive QMIRS Avg Np % was not selected");
                    break;
                case "Use PLUS Avg. NP %":
                    Assert.True(NewPlanElements.NonProductivePLUSAvgNpPercent, "Non Productive PLUS Avg Np % was not selected");
                    break;
                case "Use Most Recent Approved Plan":
                    Assert.True(NewPlanElements.NonProductiveMostRecentApprovedPlan, "Non Productive MostRecentApproved was not selected");
                    break;
                case "Use Most Recent Approved & Released Plan":
                    Assert.True(NewPlanElements.NonProductiveMostRecentApprovedAndReleasedPlan, "Non Productive Most Recent Approved & released was not selected");
                    break;
                default:
                    break;
            }

            switch(FacilityMenuOptions.NewPlanStatisticMapping)
            {
                case "Use System Default":
                    Assert.True(NewPlanElements.StatisticMappingSystemDefault, "Use System Default was not selected");
                    break;
                case "Use Most Recent Approved Plan":
                    Assert.True(NewPlanElements.StatisticMappingMostRecentApprovedPlan, "StatisticMapping -- MostRecentApproved was not selected");
                    break;
                case "Use Most Recent Approved & Released Plan":
                    Assert.True(NewPlanElements.StatisticMappingMostRecentApprovedAndReleasedPlan, "StatisticMapping -- Most Recent Approved & released was not selected");
                    break;
                default:
                    break;
            }

            switch(FacilityMenuOptions.NewPlanClPercentOrFixedFtes)
            {
                case "Use Percent":
                    Assert.True(NewPlanElements.ClPercent, "Use Percent was not selected");
                    break;
                case "Use Fixed":
                    Assert.True(NewPlanElements.FixedFTEs, "Use Fixed was not selected");
                    break;
                default:
                    break;
            }
        }

        private void verifyFacilityOptionsInDeptFcastPageForNewPlan()
        {
            bool isMatched;
            //Verify NP %
            switch (FacilityMenuOptions.NewPlanNonProductivePercent)
            {
                case "Use PLUS Avg. NP %":
                    Console.WriteLine("PLUS block");
                    var PLUSAvgNPPercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
                    var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    isMatched = CommonFunctions.CompareDataObjects(PLUSAvgNPPercentData, NPPercentFcastExcludesCLData);
                    Assert.True(isMatched, $"No match:\nPLUSAvgNPPercentData.Jan = {PLUSAvgNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    CommonFunctions.AddTestStep("Verify Use PLUS Avg. NP %", "Use PLUS Avg. NP % options was verified");
                    break;
                case "Use QMIRS NP %":
                    Console.WriteLine("QMIRS block");
                    var QMIRSNPPercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
                    NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    isMatched = CommonFunctions.CompareDataObjects(QMIRSNPPercentData, NPPercentFcastExcludesCLData);
                    Assert.True(isMatched, $"No match:\n QMIRSNPPercentData.Jan = {QMIRSNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    CommonFunctions.AddTestStep("Verify Use QMIRS NP % option", "Data was verified correctly");
                    break;
                default:
                    Console.WriteLine("Nothing to compare");
                    break;
            }

            //Verify CL % / FTEs
            switch (FacilityMenuOptions.NewPlanClPercentOrFixedFtes)
            {
                //FTEs
                case "Use Fixed":
                    Console.WriteLine("CL FTEs -- Fixed");
                    var ClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();
                    IWebElement JanCLFTEs = CommonFunctions.getElement(By.XPath("//input[@id='clFtes-1' and not(@readonly)]"));
                    Assert.True(JanCLFTEs.Enabled, "CL FTEs row is not enabled");
                    CommonFunctions.AddTestStep("Verify the Use Fixed option", "CL FTEs row is enabled");
                    break;

                case "Use Percent":
                    Console.WriteLine("CL % -- percent");
                    var CLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
                    IWebElement JanCLPercent = CommonFunctions.getElement(By.XPath("//input[@id='txtContractLaborPercent-1' and not(@readonly)]"));
                    Assert.True(JanCLPercent.Enabled, "CL % row is not enabled");
                    CommonFunctions.AddTestStep("Verify the Use Percent option", "CL Percent row is enabled");
                    break;
            }
        }

        private void verifyFacilityOptionsInDeptFcastPageForCopiedPlan()
        {
            bool isMatched;
            //Verify NP %
            switch (FacilityMenuOptions.CopyingPlanNonProductivePercent)
            {
                case "Use PLUS Avg. NP %":
                    Console.WriteLine("PLUS block");
                    var PLUSAvgNPPercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
                    var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    isMatched = CommonFunctions.CompareDataObjects(PLUSAvgNPPercentData, NPPercentFcastExcludesCLData);
                    Assert.True(isMatched, $"No match:\nPLUSAvgNPPercentData.Jan = {PLUSAvgNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    break;
                case "Use QMIRS NP %":
                    Console.WriteLine("QMIRS block");
                    var QMIRSNPPercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
                    NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    isMatched = CommonFunctions.CompareDataObjects(QMIRSNPPercentData, NPPercentFcastExcludesCLData);
                    Assert.True(isMatched, $"No match:\n QMIRSNPPercentData.Jan = {QMIRSNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    break;
                default:
                    Console.WriteLine("Nothing to compare");
                    break;
            }

            //Verify CL % / FTEs
            switch (FacilityMenuOptions.CopyingPlanCLPercentOrFixedFtes)
            {
                //FTEs
                case "Use Fixed":
                    Console.WriteLine("CL FTEs -- Fixed");
                    var ClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();
                    IWebElement JanCLFTEs = CommonFunctions.getElement(By.XPath("//input[@id='clFtes-1' and not(@readonly)]"));
                    Assert.True(JanCLFTEs.Enabled, "CL FTEs row is not enabled");
                    break;

                case "Use Percent":
                    Console.WriteLine("CL % -- percent");
                    var CLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
                    IWebElement JanCLPercent = CommonFunctions.getElement(By.XPath("//input[@id='txtContractLaborPercent-1' and not(@readonly)]"));
                    Assert.True(JanCLPercent.Enabled, "CL % row is not enabled");
                    break;
            }
        }

        private void UserCanNavigateToDeptForecast()
        {
            bool isMatched, bExists;
            string VariableDept, VariableAndSemiVariableDept, SemiVariableDept, MaximumReachedForMonthValue;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string Year = CommonFunctions.GetNextYear();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");



        }

        private void UserCanNavigateToAdminPage()
        {
            bool isMatched, bExists;
            string VariableDept, VariableAndSemiVariableDept, SemiVariableDept, MaximumReachedForMonthValue;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string Year = CommonFunctions.GetNextYear();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");



        }

        [Test] [Category("WFT")]
        public void TestSVFTEStepTargetsDialog()
        {
            // This is related to Verify Facility Maintenance Journey
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Facility Maintenance Journey";
            bool isMatched, bExists;
            string VariableDept, VariableAndSemiVariableDept, SemiVariableDept, MaximumReachedForMonthValue;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);

            homePage.NavigateToWorkloadForecaster();            
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string Year = CommonFunctions.GetNextYear();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year) 
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 20);
            ////testing SV FTE Step Targets dialog
            bool bAddRow = SVFTEStepTargets.VerifyAddRow();
            Assert.True(bAddRow, "Adding row functionality did not work correctly.");
            bool bDeleteRow = SVFTEStepTargets.VerifyDeleteRow();
            Assert.True(bDeleteRow, "Deleting row functionality did not work correctly.");
            bool bCopyRow = SVFTEStepTargets.VerifyCopyFunctionality();
            Assert.True(bCopyRow, "Copying row functionality did not work correctly.");
            DeptForecastMenu.clickSaveAndRecalc();
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");

            //Set filter to select S dept
            FacilityStatsMapping.Filters()
               .withDept("ALL")
               .withIgnoredInPlus("N")
               .withIgnoredInWFT("N")
               .withPLUSDeptType("S")
               .withWFTDeptType("S")
               .withDepartmentStat("ALL")
               .withFacilityStat("ALL")
               .withCLPercentOrFTE("ALL")
               .withNPPercent("ALL")
               .withFreezeVolumes("ALL")
               .withFreezeMinHours("ALL")
               .withFreezeStdTgt("ALL")
               .withFreezeSVStepSel("ALL")
               .withFreezeCLPercent("ALL")
               .withFreezeNPPercent("ALL")
               .withFreezeOTPercent("ALL")
               .Set();
            Thread.Sleep(2000);
            var lstDeptElements = FacilityStatsMapping.GetFacilityStatsMappingVisibleRowsElementsForWorkingPlans();
            Console.WriteLine(lstDeptElements.Count.ToString());
             SemiVariableDept = lstDeptElements[0].DeptName.GetAttribute("value");
            Console.WriteLine($"SV dept = {SemiVariableDept}");
            //Uncheck Freeze SV Step Sel checkbox
            CommonFunctions.SetCheckbox(lstDeptElements[0].FreezeSVStepSel, false);
            AdminMenu.Save();
            AdminMenu.GoToForecast();
            //Set dept
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SemiVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();
            MaximumReachedForMonthValue = SVFTEStepTargets.VerifyMaximumReachedForMonth();
            CommonFunctions.WaitUntilPageIsAcive();
            var PLUSStdSV_FTEsMontlyValues = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            isMatched = Convert.ToDouble(PLUSStdSV_FTEsMontlyValues.Jan) == Convert.ToDouble(MaximumReachedForMonthValue);
            Console.WriteLine($"MaximumReachedForMonthValue = {MaximumReachedForMonthValue}\n" +
                $"PLUSStdSV_FTEsMontlyValues.Jan = {PLUSStdSV_FTEsMontlyValues.Jan}");
            Assert.True(isMatched, "Standards > PLUSStdSV_FTEs Maximum - Reached for month Value did not match");

            var DayMixMonths = SVFTEStepTargets.getDayMix();
            var FcastStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            // We have a problem with rounding decimal values in PLUSStdSV_FTEs, so we cannot compare them.
            // In day mix, it shows 8.39, but in PLUSStdSV_FTEs it shows 8.4
            //isMatched = CommonFunctions.CompareDataObjects(DayMixMonths, FcastStdSV_FTEsData);
            // Assert.True(isMatched, "Day mix data are not copied correctly");

            var ProdFtesMonths = SVFTEStepTargets.getProdFtes();
            FcastStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            isMatched = CommonFunctions.CompareDataObjects(ProdFtesMonths, FcastStdSV_FTEsData);
            Assert.True(isMatched, "Prod Ftes data are not copied correctly");
        }

        [Test] [Category("WFT")]
        public void UserCanVerifyFreezeOptionsInNewPlan()
        {
            //comment here.
            bool bEnabled, bPlusButtonExist, bFillButtonExist;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            CommonFunctions.WaitUntilPageIsAcive();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(true)
                    .withFreezeCL(true)
                    .withFreezeNPRatiosAndVolumes(true)
                    .withFreezeOT(true)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement ClFtesFixed = CommonFunctions.getElement(By.XPath("//input[@id='txtclFtesFixed-1']"));
            Assert.True(ClFtesFixed.Enabled, "Cl Ftes Fixed field is enabled after selecting the freezing option");
            IWebElement NonProductivePercent = CommonFunctions.getElement(By.XPath("//input[@id='txtNonProductivePercent-1']"));
            Assert.True(NonProductivePercent.Enabled, "Non-Productive Percent field is enabled after selecting the freezing option");
            IWebElement OTPercent = CommonFunctions.getElement(By.XPath("//input[@id='txtOTPercent-1']"));
            Assert.True(OTPercent.Enabled, "OT Percent field is enabled after selecting the freezing option");
            IWebElement DeptFacilityRatio = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptFacilityRatio-1']"));
            Assert.True(DeptFacilityRatio.Enabled, "Dept Facility Ratio field is enabled after selecting the freezing option");            
            bEnabled = DeptFacilityRatio.Enabled;
            Assert.True(bEnabled, "Dept Facility Ratio row is enabled");
            //verify PLUS button is invisible
            bPlusButtonExist = CommonFunctions.IsElementDisplayed("//a[@id='resetDFRationtoPlusFillBtn']", 2);
            Assert.False (bPlusButtonExist, "Plus button was visible.");
            //verify Fill button is invisible
           // bFillButtonExist = CommonFunctions.IsElementDisplayed("//a[@id='deptVolumeFillBtn']", 2);
           // Assert.False(bFillButtonExist, "Fill button was visible.");
                    
        }

       //[Test] [Category("WFT")]
        public void UserCanDeletePlan()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Delete Functionality Journey";
            bool bDeleted, bExist;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//div[@id='facStatContent']//div[@id='monthly-header']", 30);

            
            bDeleted = AdminMenu.DeletePlan(PlanDescription);
            CommonFunctions.WaitUntilPageIsAcive();
            Assert.False(bDeleted, $"{PlanDescription} was not deleted");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus("Approved")
                .withPlan(string.Empty)
                .Select();
            bExist = CommonFunctions.IsElementDisplayed("//button[@id='deletePlanBtn' and @disabled]", 3);
            Assert.True(bExist, "Delete button is enabled");

            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus("Released")
                .withPlan(string.Empty)
                .Select();
            bExist = CommonFunctions.IsElementDisplayed("//button[@id='deletePlanBtn' and @disabled]", 3);
            Assert.True(bExist, "Delete button is enabled");

            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus("Historical")
                .withPlan(string.Empty)
                .Select();
            bExist = CommonFunctions.IsElementDisplayed("//button[@id='deletePlanBtn' and @disabled]", 3);
            Assert.True(bExist, "Delete button is enabled");
        }

        [Test] [Category("WFT")]
        public void UserCanSmoothDeptRatio()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Smooth Dept Ratio";
            bool bMatched;
            string smoothDepRatioOption = "Current";
            string smoothDepRatioHistoricalOption = "Historical";
            string VariableAndSemiVariableDept;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("PLUS Avg. NP %")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios(smoothDepRatioOption)
                    .withUpdateForecast(true)
                    .Create();
            VariableAndSemiVariableDept = SettingData.LoadNPDept;

            //Make sure NP Percent checkbox is disabled. 
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VariableAndSemiVariableDept)
                .withIgnoredInWFT(false)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)//make sure this is disabled.
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            // Get fac stat mapping data for dept
            var FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VariableAndSemiVariableDept);
            AdminMenu.GoToForecast();
            //Set Dept
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();
            SmoothDeptRatio.GoTo();
            Assert.True(SmoothDeptRatio.IsAt, "Smooth dept ratio pop-up was not displayed.");
            //Verify "Current" the default section from new plan
            SmoothDeptRatio.SelectSmoothDeptRatio(smoothDepRatioOption);
            verifySmoothRatio(smoothDepRatioOption);
            CommonFunctions.WaitUntilPageIsAcive();
            //Verify "Historical"
            SmoothDeptRatio.GoTo();
            Assert.True(SmoothDeptRatio.IsAt, "Smooth dept ratio pop-up was not displayed.");
            SmoothDeptRatio.SelectSmoothDeptRatio(smoothDepRatioHistoricalOption);
            CommonFunctions.WaitUntilPageIsAcive();
            verifySmoothRatio(smoothDepRatioHistoricalOption);

            void verifySmoothRatio(string Option)
            {
                //Save & Recalculate
                DeptForecastMenu.clickSaveAndRecalc();
                CommonFunctions.WaitUntilPageIsAcive();
                Thread.Sleep(15000);

                switch (Option)
                {
                    case "Current":
                        bool bJanCurrent = CommonFunctions.IsElementDisplayed("//*/input[@id='txtDeptFacilityRatio-1' and not(@readonly)]", 3);
                        Assert.True(bJanCurrent, "Dept Facility Ratio row is disabled.");
                        break;
                    case "Historical":
                        Console.WriteLine("hist");
                        bool bJanHist = CommonFunctions.IsElementDisplayed("//*/div[@id='divHistDeptFacilityRatio']//input[@month='1' and not(@readonly)]", 3);
                        //Assert.True(bJanHist, "Hist Dept Facility Ratio row is disabled.");
                        break;
                }
            }
        }

       [Test] [Category("WFT")]
        public void UserCanLoadNPPercent()
        {
            string Option;
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Load NP %";
            bool bMatched;
            string VariableAndSemiVariableDept;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("PLUS Avg. NP %")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            //VariableAndSemiVariableDept = SettingData.LoadNPDept;
            VariableAndSemiVariableDept = "647";

            //Make sure NP Percent checkbox is disabled. 
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page was not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VariableAndSemiVariableDept)
                .withIgnoredInWFT(false)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("PLUS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            // Get fac stat mapping data for dept
            var FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VariableAndSemiVariableDept);
            AdminMenu.GoToForecast();
            //Set Dept
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();            
            //Verify NP % with new plan data
            switch (FacilityStatsMappingData.NPPercent.Trim())
            {
                case "PLUS":
                    Console.WriteLine("PLUS block");
                    var PLUSAvgNPPercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
                    var NPPercentFcastExcludesCLDataPlus = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    bMatched = CommonFunctions.CompareDataObjects(PLUSAvgNPPercentData, NPPercentFcastExcludesCLDataPlus);
                   /// bMatched = PLUSAvgNPPercentData.Jan == NPPercentFcastExcludesCLDataPlus.Jan;
                    Assert.True(bMatched, $"No match:\nPLUSAvgNPPercentData.Jan = {PLUSAvgNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLDataPlus.Jan}");
                    break;
                case "QMIRS":
                    Console.WriteLine("QMIRS block");
                    var QMIRSNPPercent = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
                    var NPPercentFcastExcludesCLDataList = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    bMatched = CommonFunctions.CompareDataObjects(QMIRSNPPercent, NPPercentFcastExcludesCLDataList);
                    Assert.True(bMatched, $"No match: take a look at the log for mismatched values");
                    break;
                default:
                    Console.WriteLine("Nothing to compare");
                    break;
            }

            //Load NP
            LoadNPPercent.GoTo();
            Assert.True(LoadNPPercent.IsAt, "Load NP % dialoag was not open");
            LoadNPPercent.LoadNP("QMIRS");
            //Save & Recalculate
            DeptForecastMenu.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(15000);
            //Verify QMIRS row.
            var QMIRSNPPercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            bMatched = QMIRSNPPercentData.Jan == NPPercentFcastExcludesCLData.Jan;
            Assert.True(bMatched, $"No match:\n QMIRSNPPercentData.Jan = {QMIRSNPPercentData.Jan}\n" +
                $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
            

            //Go to Admin again to make sure the NP freeze checkbox is disabled
            DeptForecastButtonPanel.GoToAdmin();
            //Make sure NP Percent checkbox is disabled. 
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(VariableAndSemiVariableDept)
                .withIgnoredInWFT(false)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("QMIRS")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(false)
                .withFreezeSVStepSel(false)
                .withFreezeCLPercent(false)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(false)
                .Save();
            // Get fac stat mapping data for dept
            FacilityStatsMappingData = FacilityStatsMapping.GetFacilityStatsMappingData(VariableAndSemiVariableDept);
            AdminMenu.GoToForecast();
            //Set Dept
            deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();
            //Test PLUS again
            //Load NP
            LoadNPPercent.GoTo();
            Assert.True(LoadNPPercent.IsAt, "Load NP % dialoag was not open");
            LoadNPPercent.LoadNP("PLUS");
            //Save & Recalculate
            DeptForecastMenu.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(15000);
            var PLUSData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var NPPercentFcastExcludesCL = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            bMatched = PLUSData.Jan == NPPercentFcastExcludesCL.Jan;
            Assert.True(bMatched, $"No match:\nPLUSAvgNPPercentData.Jan = {PLUSData.Jan}\n" +
                $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCL.Jan}");
            
        }

        [Test]
        [Category("WFT")]
        public void TestNewPlanElements()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                .getNewPlanDefaultSetup();
            var apr = NewPlanElements.LatestQMIRSMonth;
            var ap = NewPlanElements.Apr;
            Console.WriteLine("");
        }
        
        [Test] [Category("WFT")]
        public void UserCanApproveAndReleasePlan()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");            
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Approving {PlanDescription}")
                .Approve();
            DeptForecastButtonPanel.ReleasePlan();
            Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
                $"{PlanDescription} was not released correctly.");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            bool bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnRelease' and contains(@style, 'display: none')]", 3);
            Assert.False(bExist, "Release button is displayed with Working option");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Historical")
                .withPlan(string.Empty)
                .Select();
            bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnRelease' and contains(@style, 'display: none')]", 3);
            Assert.False(bExist, "Release button is displayed with Historical option");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus("Rejected")
               .withPlan(string.Empty)
               .Select();
            bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnRelease' and contains(@style, 'display: none')]", 3);
            Assert.False(bExist, "Release button is displayed with Rejected option");
        }

        
        public void UserCanDownloadPlan()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Approving {PlanDescription}")
                .Approve();
            DeptForecastButtonPanel.ReleasePlan();
            Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
                $"{PlanDescription} was not released correctly.");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            bool bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnDownload' and contains(@style, 'display: none')]", 3);
            Assert.False(bExist, "Release button is displayed with Working option");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Historical")
                .withPlan(string.Empty)
                .Select();
            bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnDownload' and contains(@style, 'display: none')]", 3);
            Assert.False(bExist, "Release button is displayed with Historical option");

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus("Rejected")
               .withPlan(string.Empty)
               .Select();
            bExist = CommonFunctions.IsElementDisplayed("//a[@id='btnDownload' and contains(@style, 'display: none')]", 3);
            Assert.False(bExist, "Release button is displayed with Rejected option");


        }

        private void UserCanAddComments()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Approving {PlanDescription}")
                .Approve();
        }

        [Test] [Category("WFT")]
        public void UserCanSendApprovedAndReleasedPlanToPLUSwithDeptartmentData()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");

            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Pending Approval {PlanDescription}")
                .Approve();
            Assert.True(DeptForecastButtonPanel.IsPlanApproved(),
                $"{PlanDescription} was not approved correctly.");

            DeptForecastButtonPanel.ReleasePlan();
            Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
                $"{PlanDescription} was not released correctly.");

            PlusInterface.GoTo();
            Assert.True(PlusInterface.IsAt, "Plus interface page was not dispalyed");
            PlusInterface.SelectBy("Department")
                .withInterfaceTargetsFROM_Year(Year)
                .withInterfaceTargetsFROM_PlanStatus("Approved & Released")
                .withDeptOrGroup(SettingData.FacStatMappingSemiVariableDept)
                //.withInterfaceTargetsFROM_Plan(PlanDescription)
                .withInterfaceTargetsTo_Year(Year)
                .SendToPLUS();
        }   
        
        private void CreateNewPlanAndApproveIt()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Approving {PlanDescription}")
                .Approve();
            DeptForecastButtonPanel.ReleasePlan();
            Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
                $"{PlanDescription} was not released correctly.");
        }

        private void CreateNewPlanAndReleaseIt()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Approving {PlanDescription}")
                .Approve();
            DeptForecastButtonPanel.ReleasePlan();
            Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
                $"{PlanDescription} was not released correctly.");
        }

        [Test] [Category("WFT")]
        public void UserCanSendApprovedPlanToPLUSwithDeptartmentData()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of PLUS Interface";            
            bool bPlanTypeExists, bMatched;
            string PlanStatus = "Approved & Released";
            string planType = "(X)";
            var facility = "32801"; //32801
            var VariableAndSemiVariableDept = "647";// 647 SettingData.FacStatMappingSemiVariableDept;
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();            

            //Set Division and facility.
            Division.SetWFTDivisionAndFacility(facility);
            WFTMainMenu.WorkloadForecast.DepartmentForecast.SelectDepartmentForecast();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department Forecast Plan Filter was not displayed.");

            
            bPlanTypeExists = DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus(PlanStatus)
                .withPlan(planType)
                .IsPlanExist();

            if (!bPlanTypeExists)
            {
                CreateNewPlanAndApproveIt();
            }
            else
            {
                DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus(PlanStatus)
                .withPlan(planType)
                .Select();
            }

            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(VariableAndSemiVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();

            var WftFcastVarStdData = ForecastView_Standards.FcastVarStd.getFcastVarStdData();
            var WftNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var WftOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var WftCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var WftAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();

            PlusInterface.GoTo();
            Assert.True(PlusInterface.IsAt, "Plus interface page was not dispalyed");
            PlusInterface.SelectBy("Department")
                .withInterfaceTargetsFROM_Year(Year)
                .withInterfaceTargetsFROM_PlanStatus(PlanStatus)
                .withDeptOrGroup(VariableAndSemiVariableDept)
                .withInterfaceTargetsFROM_BeginningMonth("January")
                .withInterfaceTargetsFROM_EndMonth("December")
                .withInterfaceTargetsTo_Year(Year)
                .withInterfaceTargetsTo_BeginningMonth("January")
                .withInterfaceTargetsTo_EndMonth("December")
                .SendToPLUS();
            //Wait 1.5 min to make sure the email was sent
            Thread.Sleep(90000);
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            Division.SetPLUSDivisionAndFacility(facility);
            TargetDetail.GoTo();
            Assert.True(TargetDetail.IsAt, "Productivity Targets page was not displayed.");
            TargetDetail.TargetDetailMenu.SetTargetByAndYear()
                .withSelectby("Department")
                .withYear(Year)
                .Select();

            TargetDetail.selectDept(VariableAndSemiVariableDept);
            var PlusProdMinFTEsData = DefineMinHours.getPlusProdMinFTEsData();
            var PlusHrsPerUOSMontlyDetails = TargetDetail.VariableDeptartment.getHrsPerUOS(VariableAndSemiVariableDept);
            var PlusTargetNPPercent = TargetDetail.VariableDeptartment.getTargetNPPercent(VariableAndSemiVariableDept);
            var PlusTargetOTPercent = TargetDetail.VariableDeptartment.getTargetOTPercent(VariableAndSemiVariableDept);
            var PlusTargetContractPercent = TargetDetail.VariableDeptartment.getTargetContractPercent(VariableAndSemiVariableDept);
            var PlusTargetAvgRate = TargetDetail.VariableDeptartment.getTargetAvgRate(VariableAndSemiVariableDept);

            bMatched = CommonFunctions.CompareDataObjects(WftFcastVarStdData, PlusHrsPerUOSMontlyDetails);
            Assert.True(bMatched, "Hrs Per UOS data didn't match");
            bMatched = CommonFunctions.CompareDataObjects(PlusTargetNPPercent, WftNPPercentFcastExcludesCLData);
            Assert.True(bMatched, "NP% data didn't match");
            bMatched = CommonFunctions.CompareDataObjects(PlusTargetOTPercent, WftOTPercentFcastData);
            Assert.True(bMatched, "OT% data didn't match");
            bMatched = CommonFunctions.CompareDataObjects(PlusTargetContractPercent, WftCLPercentFcastData);
            Assert.True(bMatched, "CL% data didn't match");
            bMatched = CommonFunctions.CompareDataObjects(PlusTargetAvgRate, WftAvgEE_ClRateFcastData);
            Assert.True(bMatched, "Avg EE Cl Rate Fcast data didn't match");
        }

        [Test] 
        [Category("WFT")]
        public void UserCanRejectPlan()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create(); 
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.RejectPlan();
            Comments.UserComment()
                .withDescription($"Rejecting {PlanDescription}")
                .Reject();                
            Assert.True(DeptForecastButtonPanel.IsPlanRejected(),
                $"{PlanDescription} was not rejected correctly.");
        }

        [Test] [Category("WFT")]
        public void UserCanApproveRejectedPlan()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.RejectPlan();
            Comments.UserComment()
                .withDescription($"Rejecting {PlanDescription}")
                .Reject();
            Assert.True(DeptForecastButtonPanel.IsPlanRejected(),
                $"{PlanDescription} was not rejected correctly.");

            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");

            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Pending Approval {PlanDescription}")
                .Approve();
            Assert.True(DeptForecastButtonPanel.IsPlanApproved(),
                $"{PlanDescription} was not approved correctly.");
        }

        [Test] [Category("WFT")]
        public void VerifyHostFileData()
        {
            AdministrationNewPlanTests adminTests = new AdministrationNewPlanTests();
            adminTests.UserCanApproveAndReleasePlan();
            bool bVolumefcastStat6100Matched, bVolumefcastStat6150Matched, bVolumefcastStat6160Matched, bFcastEmplPaidHrsMatched;
            bool bCLHrsFcastMatched, bFcastEmplProdHrsMatched, bOTHrsFcastMatched, bTotalOTHrsFcast, bTotalPaidHoursofAllDepts;
            string Year = CommonFunctions.GetNextYear();
            //var homePage = new HomePage(Driver.Instance);
            //var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            //homePage.NavigateToWorkloadForecaster();
            ////Set Division and facility.
            //Division.SetWFTDivisionAndFacility();
            //WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Approved & Released")
                .withPlan(string.Empty)
                .Select();
            //Download file and get its data. 
            DeptForecastButtonPanel.DownloadPlan();
            var HostVolumefcastStat6100 = BudgetExportFromWFTtoHost.GetHostFileData("VolumefcastStat6100");
            var HostVolumefcastStat6150 = BudgetExportFromWFTtoHost.GetHostFileData("VolumefcastStat6150");
            var HostVolumefcastStat6160 = BudgetExportFromWFTtoHost.GetHostFileData("VolumefcastStat6160");
            var HostFcastEmplPaidHrs = BudgetExportFromWFTtoHost.GetHostFileData("FcastEmplPaidHrs");
            var HostCLHrsFcast = BudgetExportFromWFTtoHost.GetHostFileData("CLHrsFcast");
            var HostFcastEmplProdHrs = BudgetExportFromWFTtoHost.GetHostFileData("FcastEmplProdHrs");
            var HostOTHrsFcast = BudgetExportFromWFTtoHost.GetHostFileData("OTHrsFcast");
            //Code 50 total emp paid hours
            //double JanuaryTotalFcastEmplPaidHrs = HostFcastEmplPaidHrs.Sum(item => item.Jan);
            double JanuaryTotalFcastEmplPaidHrs = 0;
            int count = 0;
            foreach(var item in HostFcastEmplPaidHrs)
            {
                if(!string.IsNullOrEmpty(item.DeptCode))
                {
                    JanuaryTotalFcastEmplPaidHrs += item.Jan;
                    count++;
                }
            }
            var HostTotalPaidHoursofAllDepts = BudgetExportFromWFTtoHost.GetHostFileData("TotalPaidHoursofAllDepts");
            bTotalPaidHoursofAllDepts = JanuaryTotalFcastEmplPaidHrs == HostTotalPaidHoursofAllDepts.FirstOrDefault().Jan;            
            Assert.True(bTotalPaidHoursofAllDepts, $"JanuaryTotalFcastEmplPaidHrs: {JanuaryTotalFcastEmplPaidHrs}\n" +
                $"HostTotalPaidHoursofAllDepts.FirstOrDefault().Jan: {HostTotalPaidHoursofAllDepts.FirstOrDefault().Jan}");

            //code 12
            double JanuaryTotalOTHrsForAllDepts = 0;
            int OTCount = 0;
            foreach (var item in HostOTHrsFcast)
            {
                if (!string.IsNullOrEmpty(item.DeptCode))
                {
                    JanuaryTotalOTHrsForAllDepts += item.Jan;
                    OTCount++;
                }
            }
            var HostTotalOTHrsFcast = BudgetExportFromWFTtoHost.GetHostFileData("TotalOTHrsFcast");
            bTotalOTHrsFcast = JanuaryTotalOTHrsForAllDepts == HostTotalOTHrsFcast[1].Jan;
            Assert.True(bTotalOTHrsFcast, $"JanuaryTotalOTHrsForAllDepts: {JanuaryTotalOTHrsForAllDepts}\n" +
                $"HostTotalOTHrsFcast > Jan: {HostTotalOTHrsFcast.FirstOrDefault().Jan}");

            foreach (var dept in HostVolumefcastStat6100)
            {
                bVolumefcastStat6100Matched = false;
                bVolumefcastStat6150Matched = false;
                bVolumefcastStat6160Matched = false;
                bFcastEmplPaidHrsMatched = false;
                bCLHrsFcastMatched = false;
                bFcastEmplProdHrsMatched = false;
                bOTHrsFcastMatched = false;

                DeptForecastDepartmentDetails.SelectDept(dept.DeptCode);
                //parse file data based on dept
                CommonFunctions.AddTestStep($"Parse file data based on dept code {dept.DeptCode}", "Data is parsed");
                var VolumefcastStat6100Results = HostVolumefcastStat6100.Where(o => o.DeptCode == dept.DeptCode);
                var HostVolumefcastStat6150Result = HostVolumefcastStat6150.Where(o => o.DeptCode == dept.DeptCode);
                var HostVolumefcastStat6160Result = HostVolumefcastStat6160.Where(o => o.DeptCode == dept.DeptCode);
                var HostFcastEmplPaidHrsResult = HostFcastEmplPaidHrs.Where(o => o.DeptCode == dept.DeptCode);
                var HostCLHrsFcastResult = HostCLHrsFcast.Where(o => o.DeptCode == dept.DeptCode);
                var HostFcastEmplProdHrsResult = HostFcastEmplProdHrs.Where(o => o.DeptCode == dept.DeptCode);
                var HostOTHrsFcastResult = HostOTHrsFcast.Where(o => o.DeptCode == dept.DeptCode);

                var VolumefcastStat6100 =  ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();                

                bVolumefcastStat6100Matched = CommonFunctions.CompareObjects(VolumefcastStat6100, VolumefcastStat6100Results.FirstOrDefault());                
                Assert.True(bVolumefcastStat6100Matched, $"No match: fcast Stat 6100 -- {dept.DeptCode}");

                var VolumefcastStat6150 = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
                bVolumefcastStat6150Matched = CommonFunctions.CompareObjects(VolumefcastStat6150, HostVolumefcastStat6150Result.FirstOrDefault());
                Assert.True(bVolumefcastStat6150Matched, $"No match: fcast Stat 6150 -- {dept.DeptCode}");

                var VolumefcastStat6160 = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
                bVolumefcastStat6160Matched = CommonFunctions.CompareObjects(VolumefcastStat6160, HostVolumefcastStat6160Result.FirstOrDefault());
                Assert.True(bVolumefcastStat6160Matched, $"No match: fcast Stat 6160 -- {dept.DeptCode}");

                var FcastEmplPaidHrs = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
                bFcastEmplPaidHrsMatched = CommonFunctions.CompareObjects(FcastEmplPaidHrs, HostFcastEmplPaidHrsResult.FirstOrDefault());
                Assert.True(bFcastEmplPaidHrsMatched, $"No match: Fcast Empl Paid Hrs -- {dept.DeptCode}  -- {FcastEmplPaidHrs.Jan} -- {HostFcastEmplPaidHrsResult.FirstOrDefault()}");

                var CLHrsFcast = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
                bCLHrsFcastMatched = CommonFunctions.CompareObjects(CLHrsFcast, HostCLHrsFcastResult.FirstOrDefault());
                Assert.True(bCLHrsFcastMatched, $"No match: CL Hrs Fcast -- {dept.DeptCode} --  {CLHrsFcast.Jan} ");

                var FcastEmplProdHrs = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();
                bFcastEmplProdHrsMatched = CommonFunctions.CompareObjects(FcastEmplProdHrs, HostFcastEmplProdHrsResult.FirstOrDefault());
                Assert.True(bFcastEmplProdHrsMatched, $"No match: Fcast Empl Prod Hrs -- {dept.DeptCode}");

                var OTHrsFcast = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
                bOTHrsFcastMatched = CommonFunctions.CompareObjects(OTHrsFcast, HostOTHrsFcastResult.FirstOrDefault());
                Assert.True(bOTHrsFcastMatched, $"No match: OT Hrs Fcast -- {dept.DeptCode}");                
                break;
            }
        }

        [Test] [Category("WFT")]
        public void VerifyProdHrsAndFtesourney()
        {

            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Prod Hrs and FTEs journey";
            int daysInMonth = 0;
            string Year = CommonFunctions.GetNextYear();
            bool isMatched, bExists;
            string VariableDept, VariableAndSemiVariableDept, SemiVariableDept;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();           
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            //Navigate to ISAS home page. 
           //homePage.SwitchToWindow("ISAS Portal");
           // homePage.NavigateToPLUS();
            homePage.SwitchToWindow("Workload Forecast");
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            var FcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var FcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            daysInMonth = CommonFunctions.GetDaysInMonth(Year, "Jan");            
            var dExpectedResultValue = Math.Round(FcastTotalProdHrsData.Jan / (5.714 * daysInMonth),2);
            Assert.True(dExpectedResultValue == FcastTotalProdFtesData.Jan,
                $"dExpectedResultValue = {dExpectedResultValue}\n" +
                $"FcastTotalProdFtesData.Jan = {FcastTotalProdFtesData.Jan}");
            CommonFunctions.AddTestStep("Department forecast page is disaplayed.", "Department forecast page is disaplayed.");
            
        }

        [Test]
        [Category("WFT")]
        public void VerifyNotesInDepartmentDetails()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            DateTime.Now.ToString("M/d/yyyy hh:mm:ss tt");
        }

        
        private void VerifyDepartmentForecastSummary()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            var FcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();
            var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var FcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var expectedFcastEmplPaidHrs = CommonFunctions.ToDouble(FcastEmplProdHrsData.Jan, 2) / (1 - (NPPercentFcastExcludesCLData.Jan / 100));
            
            Assert.True(CommonFunctions.ToDouble(FcastEmplPaidHrsData.Jan,2) == CommonFunctions.ToDouble(expectedFcastEmplPaidHrs, 2),
                $"expectedFcastEmplPaidHrs {expectedFcastEmplPaidHrs}\n" +
                $"FcastEmplPaidHrsData.Jan {FcastEmplPaidHrsData.Jan}");
        }

        [Test]
        [Category("WFT")]
        public void UserCanVerifyPaidHrsAndFTEsJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Paid Hrs and FTEs journey";
            string Year =  CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(string.Empty)
                .Select();
            var FcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();
            var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var FcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var expectedFcastEmplPaidHrs = FcastEmplProdHrsData.Jan / (1 - (NPPercentFcastExcludesCLData.Jan / 100));
            Assert.True(FcastEmplPaidHrsData.Jan == Math.Round(expectedFcastEmplPaidHrs,0),
                $"expectedFcastEmplPaidHrs {expectedFcastEmplPaidHrs}\n" +
                $"FcastEmplPaidHrsData.Jan {FcastEmplPaidHrsData.Jan}");
        }

       [Test] [Category("WFT")]
        public void VerifyFacilityGoals()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Facility Goals";
            string query, planID;
            int DaysInYear = CommonFunctions.IsLeapYear();
            Console.WriteLine($"DaysInYear = {DaysInYear}");
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            FacilityGoals.GoTo();
            Assert.True(FacilityGoals.IsAt, "Facility goals page was not displayed");
            var FacilityBudgetGoals = FacilityGoals.GetFacilityBudgetGoals();
            CommonFunctions.WaitUntilPageIsAcive();
            FacilityStats.GoTo();
            Assert.True(FacilityStats.IsAt, "Facility Stats page was not displayed");
            FacilityStats.GoTo();
            var FacStatAdjAdmission = FacilityStats.getFacilityStatQMIRS_HistAndProjection("ADJUSTED ADMISSIONS");
            var FacStatAdmission = FacilityStats.getFacilityStatQMIRS_HistAndProjection("ADMISSIONS");
            var FacStatADP = FacilityStats.getFacilityStatQMIRS_HistAndProjection("ADJUSTED PATIENT DAYS");
            var FacStatPatientDays = FacilityStats.getFacilityStatQMIRS_HistAndProjection("PATIENT DAYS");
            var FacStatTotalERVisits = FacilityStats.getFacilityStatQMIRS_HistAndProjection("TOTAL ER VISITS");
            var FacStatOutpatientVisits = FacilityStats.getFacilityStatQMIRS_HistAndProjection("OUTPATIENT VISITS");
            var FacStatAcutePatientDays = FacilityStats.getFacilityStatQMIRS_HistAndProjection("ACUTE PATIENT DAYS");
            var FacStatAdjustedAcutePatientDays = FacilityStats.getFacilityStatQMIRS_HistAndProjection("ADJUSTED ACUTE PATIENT DAYS");

            //Employed Productive FTEs
            string EmployedProductiveFTEsQuery = $"select (sum(HistoricalProductiveHours)/5.7142857142857142857142857143)*1/366" +
                $" from ReferenceMonthlyValue " +
                $"where Department_ID  " +
                $"in " +
                $"(select id  " +
                $"from Department dd " +
                $"where Facility_ID = 1463471 " +
                $"and dd.IsInactive = 0)";
            double EmployedProductiveFTEsQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(EmployedProductiveFTEsQuery));
            Console.WriteLine($"EmployedProductiveFTEsQueryResult = {EmployedProductiveFTEsQueryResult}\n" +
                $"EmployedProductiveFTEs = {FacilityBudgetGoals.EmployedProductiveFTEs}\n");

            //Contract FTEs
            string ContractFTEsQuery = $"select (sum(HistoricalContractHours)/5.7142857142857142857142857143)*1/{DaysInYear}" +
                $" from ReferenceMonthlyValue " +
                $"where Department_ID  " +
                $"in " +
                $"(select id  " +
                $"from Department dd " +
                $"where Facility_ID = 1463471 " +
                $"and dd.IsInactive = 0)";
            double ContractFTEsQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(ContractFTEsQuery));
            Console.WriteLine($"ContractFTEsQueryResult = {ContractFTEsQueryResult}\n" +
                $"ContractFTEs = {FacilityBudgetGoals.ContractFTEs}\n");

            //Non Prod %
            string NonProdPercentQuery = $"select (1-(sum(HistoricalProductiveHours)/sum(HistoricalPaidHours)))*100 " +
                $"from ReferenceMonthlyValue " +
                $"where Department_ID " +
                $"in " +
                $"(select id " +
                $"from Department dd " +
                $"where Facility_ID = 1463471 " +
                $"and dd.IsInactive = 0)";           
            double NonProdPercentQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(NonProdPercentQuery));
            Console.WriteLine($"NonProdPercentQueryResult = {NonProdPercentQueryResult}\n" +
                $"NonProdPercent = {FacilityBudgetGoals.NonProdPercent}\n");

            //OT %
            string OTPercentQuery = $"select ((sum(HistoricalOtHours)/sum(HistoricalProductiveHours)))*100 " +
               $"from ReferenceMonthlyValue " +
               $"where Department_ID " +
               $"in " +
               $"(select id " +
               $"from Department dd " +
               $"where Facility_ID = 1463471 " +
               $"and dd.IsInactive = 0)";
            double OTPercentQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(OTPercentQuery));
            Console.WriteLine($"OTPercentQueryResult = {OTPercentQueryResult}\n" +
                $"OTPercent = {FacilityBudgetGoals.OTPercent}\n");

            //Admission
            Console.WriteLine($"FacStatAdmission = {FacStatAdmission.Total}\n" +
                $"FacilityBudgetGoals.Admissions = {FacilityBudgetGoals.Admissions}\n");

            //Adj Admissions
            var opfactor = $"select HistoricalOpFactor from Facility where CoId = 30927";
            var AdjAdmissions = (FacStatAdmission.Total * ((CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(opfactor))) + 1));
            Console.WriteLine($"Adj Admissions = {AdjAdmissions}\n" +
                $"FacilityBudgetGoals.AdjAdmissions = {FacilityBudgetGoals.AdjAdmissions}\n");

            //EEOB
            var eEOBCalc = FacilityBudgetGoals.TotalFTEsPaidAndContract / (FacilityBudgetGoals.APD / CommonFunctions.IsLeapYear());
            Console.WriteLine($"EEOB Calc = {eEOBCalc}\n" +
                $"FacilityBudgetGoals.EEOB = {FacilityBudgetGoals.EEOB}\n");

            //MH/AA
            var mHAACalc = FacilityBudgetGoals.TotalFTEsPaidAndContract * (5.7142857142857142857142857143) * CommonFunctions.IsLeapYear() / FacilityBudgetGoals.AdjAdmissions;
            Console.WriteLine($"MH/AA Calc = {mHAACalc}\n" +
                $"FacilityBudgetGoals.MHAA = {FacilityBudgetGoals.MHAA}\n");

            //Patient Days
            Console.WriteLine($"Fac stats Patient Days total = {FacStatPatientDays.Total}\n" +
                $"FacilityBudgetGoals.PatientDays = {FacilityBudgetGoals.PatientDays}\n");

            //ER Visits
            Console.WriteLine($"Fac stats total ER visits = {FacStatTotalERVisits.Total}\n" +
                $"FacilityBudgetGoals.ERVisits = {FacilityBudgetGoals.ERVisits}\n");

            //Outpatient visits
            Console.WriteLine($"Fac stats outpatient visits = {FacStatOutpatientVisits.Total}\n" +
               $"FacilityBudgetGoals.OutPatientVisits = {FacilityBudgetGoals.OutPatientVisits}\n");

            //Employed Labor Rate(Excl CL)           
            string TotalSalAndWagesQuery = $"select sum(HistoricalHospitalDollarsFromGl)" +
                $" from ReferenceMonthlyValue " +
                $"where Department_ID" +
                $" in " +
                $"(select id " +
                $"from Department dd " +
                $"where Facility_ID = 1463471 " +
                $"and dd.IsInactive = 0) ";
            string PaidFtesQuery = $"select sum(HistoricalPaidHours)/ 5.7142857142857142857142857143/{DaysInYear}" +
                $"from ReferenceMonthlyValue " +
                $"where Department_ID " +
                $"in " +
                $"(select id " +
                $"from Department dd " +
                $"where Facility_ID = 1463471 " +
                $"and dd.IsInactive = 0) ";
            double TotalSalAndWagesQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(TotalSalAndWagesQuery));
            double PaidFtesQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(PaidFtesQuery));
            var EmployedLaborRateExclCLCalculation = TotalSalAndWagesQueryResult / (PaidFtesQueryResult * 5.7142857142857142857142857143 * DaysInYear);
            Console.WriteLine($"EmployedLaborRateExclCLCalculation = {EmployedLaborRateExclCLCalculation}\n" +
              $"FacilityBudgetGoals.EmployedLaborRateExclCL = {FacilityBudgetGoals.EmployedLaborRateExclCL}\n");

            //Contract $ Per Hour
            string ContractDollarsPerHourQuery = $"select sum(HistoricalContractDollarsFromGl)/sum(HistoricalContractHours) " +
                $"from ReferenceMonthlyValue " +
                $"where Department_ID " +
                $"in " +
                $"(select id " +
                $"from Department dd  " +
                $"where Facility_ID = 1463471 " +
                $"and dd.IsInactive = 0)";            
            double ContractDollarsPerHourQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(ContractDollarsPerHourQuery));
            Console.WriteLine($"ContractDollarsPerHourQueryResult = {ContractDollarsPerHourQueryResult}\n" +
              $"FacilityBudgetGoals.ContractDollarPerHour = {FacilityBudgetGoals.ContractDollarPerHour}\n");

            //OP Factor
            string OPFactorQuery = $"Select HistoricalOpFactor from Facility where CoId = 30927";
            double OPFactorQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(OPFactorQuery));
            Console.WriteLine($"OPFactorQueryResult = {OPFactorQueryResult}\n" +
              $"FacilityBudgetGoals.OPFactor = {FacilityBudgetGoals.OPFactor}\n");

            //APD
            var APDCalc = FacilityBudgetGoals.PatientDays * (1 + FacilityBudgetGoals.OPFactor);
            Console.WriteLine($"APD Calc = {APDCalc}\n" +
              $"FacilityBudgetGoals.APD = {FacilityBudgetGoals.APD}\n");

            //ALOS
            var AlosCalc =  FacStatPatientDays.Total / FacStatAdmission.Total;
            Console.WriteLine($"ALOS Calc = {AlosCalc}\n" +
              $"FacilityBudgetGoals.ALOS = {FacilityBudgetGoals.ALOS}\n");

            //Employed Paid FTEs
            var EmployedPaidFTEsQuery = $"select sum(HistoricalPaidHours)/ 5.7142857142857142857142857143/{DaysInYear} " +
                $"from ReferenceMonthlyValue " +
                $"where Department_ID  " +
                $"in " +
                $"(select id " +
                $"from Department dd " +
                $"where Facility_ID = 1463471 " +
                $"and dd.IsInactive = 0) ";
            double EmployedPaidFTEsQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(EmployedPaidFTEsQuery));
            Console.WriteLine($"EmployedPaidFTEsQueryResult = {EmployedPaidFTEsQueryResult}\n" +
              $"FacilityBudgetGoals.EmployedPaidFTEs = {FacilityBudgetGoals.EmployedPaidFTEs}\n");

            //Total FTEs (Paid + Contract)
            var TotalFTEsPaidContractQuery = $"select (sum(HistoricalPaidHours)/ 5.7142857142857142857142857143/{DaysInYear})+ (sum(HistoricalContractHours)/ 5.7142857142857142857142857143/{DaysInYear}) " +
                $"from ReferenceMonthlyValue " +
                $"where Department_ID " +
                $"in " +
                $"(select id " +
                $"from Department dd " +
                $"where Facility_ID = 1463471 " +
                $"and dd.IsInactive = 0) ";
            double TotalFTEsPaidContractQueryResult = CommonFunctions.ToDouble(CommonFunctions.GetQueryResult(TotalFTEsPaidContractQuery));
            Console.WriteLine($"TotalFTEsPaidContractQueryResult = {TotalFTEsPaidContractQueryResult}\n" +
              $"FacilityBudgetGoals.TotalFTEsPaidAndContract = {FacilityBudgetGoals.TotalFTEsPaidAndContract}\n");

            //Acute Patient days 
            Console.WriteLine($"FacStatAcutePatientDays = {FacStatAcutePatientDays.Total}\n" +
              $"FacilityBudgetGoals.AcutePatientDays = {FacilityBudgetGoals.AcutePatientDays}\n");

            //Adjusted Acute Patient Days 
            Console.WriteLine($"FacStatAdjustedAcutePatientDays = {FacStatAdjustedAcutePatientDays.Total}\n" +
              $"FacilityBudgetGoals.AdjustedAcutePatientDays = {FacilityBudgetGoals.AdjustedAcutePatientDays}\n");
        }

        [Test]
        [Category("SmokeTest")]
        public void Test()
        {
            RunData.AdoTestPlan = "PLUS Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Contract Rates";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
           // homePage.NavigateToWorkloadForecaster();
            string ID = "215076870"; // get wft dept ID from the URL
            string DB = RunData.DatabaseName;
            string query = $"select Month, rmv.PlusVolumeHistory AS [PLUSVolume] " +
                $" from ReferenceMonthlyValue(nolock) rmv " +
                $" join WftDepartment(nolock) wd " +
                $" on rmv.Department_ID=wd.Department_ID " +
                $" where wd.id=215076870 " +
                $" order by Month";
            var values = CommonFunctions.FetchDataQuery(query, DB, ID);
            Console.WriteLine("Test done");


        }

        

        [Test] [Category("WFT")]
        public void VerifytheJourneyOfFacilityFteSummary()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Facility FTE summary";
            string query, planID;
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            //DeptForecastMenu.clickSaveAndRecalc();
            //CommonFunctions.WaitUntilPageIsAcive();

            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(string.Empty);
            planID = deptDetails.PlanID;
            Console.WriteLine($"PlanID: {planID}");
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //Employed(Productive)FTEs
            query = $"Select sum(ROUND(EmployeeProductiveHours,0)) /5.714/31" +
                $" from WftMonthlyValue" +
                $" where WftDepartment_ID" +
                $"  in (select Id" +
                $"  from WftDepartment d " +
                $"where WftPlan_ID = {planID} " +
                $"and d.Department_ID" +
                $" in " +
                $"( select id " +
                $"from Department dd " +
                $"where Facility_ID = 1463471" +
                $" and dd.IsInactiveInWFT = 0 ))" +
                $" and month = 1";
            string result = CommonFunctions.GetQueryResult(query);
            Console.WriteLine($"Result: {CommonFunctions.ToDouble(result)}");
            var EmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            Console.WriteLine(EmployedProductiveFTEsData.Jan);

            //Contract FTEs
            string ContractFTEsQuery = $"select sum(ROUND(ContractLaborFtes,0)) " +
                $"from WftMonthlyValue" +
                $" where WftDepartment_ID " +
                $"in " +
                $" (select Id" +
                $" from WftDepartment d " +
                $" where WftPlan_ID = {planID} " +
                $" and d.Department_ID" +
                $" in " +
                $" (select id " +
                $" from Department dd " +
                $" where Facility_ID = 1463471 " +
                $" and dd.IsInactiveInWFT = 0))" +
                $" and month = 1";
            string ContractFTEResult = CommonFunctions.GetQueryResult(ContractFTEsQuery);
            var ContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            //Assert.True(Convert.ToDouble(ContractFTEResult) == ContractFTEsData.Jan,
            Console.WriteLine($"ContractFTEResult = {CommonFunctions.ToDouble(ContractFTEResult)}\n" +
                $"ContractFTEsData.Jan: {ContractFTEsData.Jan} \n");

            //Total Productive FTEs
            string TotalProductiveFtesQuery = $"select sum(ROUND(TotalProductiveFtes,2)) " +
                $"from WftMonthlyValue" +
                $" where WftDepartment_ID " +
                $"in " +
                $" (select Id" +
                $" from WftDepartment d " +
                $" where WftPlan_ID = {planID} " +
                $" and d.Department_ID" +
                $" in " +
                $" (select id " +
                $" from Department dd " +
                $" where Facility_ID = 1463471 " +
                $" and dd.IsInactiveInWFT = 0))" +
                $" and month = 1";
            string TotalProductiveFtesQueryResult = CommonFunctions.GetQueryResult(TotalProductiveFtesQuery);
            var TotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            Console.WriteLine($"TotalProductiveFtesQueryResult: {CommonFunctions.ToDouble(TotalProductiveFtesQueryResult)}\n" +
                $"TotalProductiveFTEsData.Jan: {TotalProductiveFTEsData.Jan} \n");

            //Contract Labor %
            double ContractLaborPercent = (CommonFunctions.ToDouble(ContractFTEResult) / CommonFunctions.ToDouble(TotalProductiveFtesQueryResult)) * 100;
            var ContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            Console.WriteLine($"ContractLaborPercent= {ContractLaborPercent.ToString()}\n" +
                $"ContractLaborPercentData.Jan = {ContractLaborPercentData.Jan} \n");

            //Non - Productive FTEs
            string NonProductiveHoursQuery = $"Select sum(ROUND(NonProductiveHours,0)) /5.714/31" +
                $" from WftMonthlyValue" +
                $" where WftDepartment_ID" +
                $"  in (select Id" +
                $"  from WftDepartment d " +
                $"where WftPlan_ID = {planID} " +
                $"and d.Department_ID" +
                $" in " +
                $"( select id " +
                $"from Department dd " +
                $"where Facility_ID = 1463471" +
                $" and dd.IsInactiveInWFT = 0 ))" +
                $" and month = 1";
            string NonProductiveHoursQueryResult = CommonFunctions.GetQueryResult(NonProductiveHoursQuery);
            var NonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            Console.WriteLine($"NonProductiveHoursQueryResult = {CommonFunctions.ToDouble(NonProductiveHoursQueryResult)}\n" +
                $"NonProductiveFTEsData.Jan = {Math.Round(NonProductiveFTEsData.Jan,1)} \n");

            //Employed (Paid) FTEs 
            string EmployeePaidManHoursQuery = $"Select sum(ROUND(EmployeePaidManHours,0)) /5.714/31" +
                $" from WftMonthlyValue" +
                $" where WftDepartment_ID" +
                $"  in (select Id" +
                $"  from WftDepartment d " +
                $"where WftPlan_ID = {planID} " +
                $"and d.Department_ID" +
                $" in " +
                $"( select id " +
                $"from Department dd " +
                $"where Facility_ID = 1463471" +
                $" and dd.IsInactiveInWFT = 0 ))" +
                $" and month = 1";
            string EmployeePaidManHoursQueryResult = CommonFunctions.GetQueryResult(EmployeePaidManHoursQuery);
            var EmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            Console.WriteLine($"EmployeePaidManHoursQueryResult = {CommonFunctions.ToDouble(EmployeePaidManHoursQueryResult)}\n" +
                $"EmployedPaidFTEsData.Jan = {EmployedPaidFTEsData.Jan} \n");

            //Non-Productive % 
            var NonProductivePercent = (NonProductiveFTEsData.Jan / TotalProductiveFTEsData.Jan) * 100;
            var NonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            Console.WriteLine($"NonProductivePercent = {Math.Round(NonProductivePercent,MidpointRounding.AwayFromZero)}\n" +
                $"NonProductivePercentData.Jan = {Math.Round(NonProductivePercentData.Jan,0)} \n");

            //Total FTEs(Paid+Contract)            
            EmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var TotalFTEsPaidAndContract = EmployedPaidFTEsData.Jan + ContractFTEsData.Jan;
            var TotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();
            Console.WriteLine($"TotalFTEsPaidAndContract = {TotalFTEsPaidAndContract}\n" +
                $"TotalFTEsPaidPlusContractData.Jan = {TotalFTEsPaidPlusContractData.Jan}\n");

            //Tot Sal & Wages($000)
            string TotalSalariesAndWagesQuery = $"select sum(ROUND(EmployedSalaries/1000,2)) " +
               $"from WftMonthlyValue" +
               $" where WftDepartment_ID " +
               $"in " +
               $" (select Id" +
               $" from WftDepartment d " +
               $" where WftPlan_ID = {planID} " +
               $" and d.Department_ID" +
               $" in " +
               $" (select id " +
               $" from Department dd " +
               $" where Facility_ID = 1463471 " +
               $" and dd.IsInactiveInWFT = 0))" +
               $" and month = 1";

            string TotalSalariesAndWagesQueryResult = CommonFunctions.GetQueryResult(TotalSalariesAndWagesQuery);
            var TotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            Console.WriteLine($"TotalSalariesAndWagesQueryResult = {CommonFunctions.ToDouble(TotalSalariesAndWagesQueryResult)}\n" +
               $"TotSalAndWagesData.Jan = {TotSalAndWagesData.Jan}\n");
            Console.WriteLine(" ");

            //Tot Contract Labor($000)
            string TotalContractLaborQuery = $"select sum(ROUND(ContractAmount/1000,2)) " +
               $"from WftMonthlyValue" +
               $" where WftDepartment_ID " +
               $"in " +
               $" (select Id" +
               $" from WftDepartment d " +
               $" where WftPlan_ID = {planID} " +
               $" and d.Department_ID" +
               $" in " +
               $" (select id " +
               $" from Department dd " +
               $" where Facility_ID = 1463471 " +
               $" and dd.IsInactiveInWFT = 0))" +
               $" and month = 1";
            string TotalContractLaborQueryResult = CommonFunctions.GetQueryResult(TotalContractLaborQuery);
            var TotContractLaborData = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            Console.WriteLine($"TotalContractLaborQueryResult = {CommonFunctions.ToDouble(TotalContractLaborQueryResult)}\n" +
                $"TotContractLaborData.Jan = {TotContractLaborData.Jan}\n");

            //Tot Labor Expense($000) 
            string TotalContracExpenseQuery = $"select sum(ROUND(TotalLaborDollars/1000,2)) " +
               $"from WftMonthlyValue" +
               $" where WftDepartment_ID " +
               $" in " +
               $" (select Id" +
               $" from WftDepartment d " +
               $" where WftPlan_ID = {planID} " +
               $" and d.Department_ID" +
               $" in " +
               $" (select id " +
               $" from Department dd " +
               $" where Facility_ID = 1463471 " +
               $" and dd.IsInactiveInWFT = 0)) " +
               $" and month = 1";

            string TotalContracExpenseQueryResult = CommonFunctions.GetQueryResult(TotalContracExpenseQuery);
            var TotLaborExpenseData = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            Console.WriteLine($"TotalContracExpenseQueryResult = {CommonFunctions.ToDouble(TotalContracExpenseQueryResult)}\n" +
                $"TotLaborExpenseData.Jan = {TotLaborExpenseData.Jan}\n");

            //Employed Labor Rate 
            var EmployedLaborRate = (CommonFunctions.ToDouble(TotalSalariesAndWagesQueryResult) * 1000) / (EmployedPaidFTEsData.Jan * 5.714 * 31);
            var EmployedLaborRateData = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            Console.WriteLine($"EmployedLaborRate = {Math.Round(EmployedLaborRate, MidpointRounding.AwayFromZero)}\n" +
                $"EmployedLaborRateData.Jan = {EmployedLaborRateData.Jan}\n");

            //Contract Labor Rate 
            TotContractLaborData = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            ContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var ContractLaborRateData = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var ExpectedContractLaborRate = (TotContractLaborData.Jan * 1000) / (ContractFTEsData.Jan * 5.714 * 31);
            Console.WriteLine($"ExpectedContractLaborRate = {ExpectedContractLaborRate}\n" +
                $"ContractLaborRateData.Jan = {ContractLaborRateData.Jan}\n");


            //OT FTE 
            string OTFTEQuery = $"select sum(ROUND(OtHours),0) " +
               $" from WftMonthlyValue" +
               $" where WftDepartment_ID " +
               $" in " +
               $" (select Id" +
               $" from WftDepartment d " +
               $" where WftPlan_ID = {planID} " +
               $" and d.Department_ID " +
               $" in " +
               $" (select id " +
               $" from Department dd " +
               $" where Facility_ID = 1463471 " +
               $" and dd.IsInactiveInWFT = 0)) " +
               $" and month = 1";

            //string OTFTEQueryResult = CommonFunctions.GetQueryResult(OTFTEQuery);
            //var OTFTEExpectedResult =  Math.Round(CommonFunctions.ToDouble(OTFTEQueryResult) / (5.714 * 31));
            var OvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();
            //Console.WriteLine($"OTFTEExpectedResult = {OTFTEExpectedResult}\n" +
            //    $"OvertimeFTEsData.Jan = {OvertimeFTEsData.Jan}\n");

            //OT %
            TotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            OvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();
            var OvertimePercentData = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var OTExpectedResult = (OvertimeFTEsData.Jan / TotalProductiveFTEsData.Jan) * 100;
            Console.WriteLine($"OTExpectedResult = {Math.Round(OTExpectedResult,2)}\n" +
                $"OvertimePercentData.Jan = {OvertimePercentData.Jan}\n");

            //Facility Volume Summary section
            //ADJUSTED ADMISSIONS
            //PATIENT DAYS
            //ADJUSTED PATIENT DAYS
            //TOTAL ER VISITS
            //OUTPATIENT VISITS
            bool bAdmissions, bAdjustedAdmissions, bPatientDays, bAPD, bERVisits, bOutPatientVisits;
            var AdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var AdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var PatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var APDData = FacilityVolumeSummary.APD.getAPDData();
            var ERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var OutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();

            DeptForecastButtonPanel.GoToAdmin();
            FacilityStats.GoTo();
            Assert.True(FacilityStats.IsAt, "Facility Stat page was not displayed.");
            var facAdmissions = FacilityStats.getFacilityStatForecastsData("ADMISSIONS");
            var facAdjustedAdmissions = FacilityStats.getFacilityStatForecastsData("ADJUSTED ADMISSIONS");
            var facPatientDays = FacilityStats.getFacilityStatForecastsData("PATIENT DAYS");
            var facAdujustedPatientDays = FacilityStats.getFacilityStatForecastsData("ADJUSTED PATIENT DAYS");
            var facERVisits = FacilityStats.getFacilityStatForecastsData("TOTAL ER VISITS");
            var facOutpatientVisits = FacilityStats.getFacilityStatForecastsData("OUTPATIENT VISITS");

            bAdmissions = CommonFunctions.CompareDataObjects(AdmissionsData, facAdmissions);
            bAdjustedAdmissions = CommonFunctions.CompareDataObjects(AdjustedAdmissionsData, facAdjustedAdmissions);
            bPatientDays = CommonFunctions.CompareDataObjects(PatientDaysData, facPatientDays);
            bAPD = CommonFunctions.CompareDataObjects(APDData, facAdujustedPatientDays);
            bERVisits = CommonFunctions.CompareDataObjects(facERVisits, ERVisitsData);
            bOutPatientVisits = CommonFunctions.CompareDataObjects(OutPatientVisitsData, facOutpatientVisits);

            Console.WriteLine($"bAdmissions = {bAdmissions}\n" +
                $"bAdjustedAdmissions = {bAdjustedAdmissions.ToString()}\n" +
                $"bPatientDays = {bPatientDays}\n" +
                $"bAPD = {bAPD}\n" +
                $"bERVisits = {bERVisits}\n" +
                $"bOutPatientVisits = {bOutPatientVisits}\n");
           CommonFunctions.AddTestStep(
           "Test 'GET' request for /applications/<Application ID>/roles endpoint with bad or null values.",
           "Systems should respond accordingly.");
        }

        [Test]
        [Category("WFT")]
        public void LaborRatesJourney()
        {
            bool isMatched;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("32801");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetCurrentYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            //ExistingPlanFilter.GoTo();
            //Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");

            //ExistingPlanFilter.ExistingPlan()
            //    .withYear(string.Empty)
            //    .withPlanStatus("Working")
            //    .withPlan(string.Empty)
            //    .Select();
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "Average Labor Rate Empl page was not displayed");
            var QMIRSEmplLbrRateData = AverageLaborRateEmpl.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var EmployedLaborRateData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();
            var EmployeeSalariesData = AverageLaborRateEmpl.EmployeeSalaries.getEmployeeSalariesData();

            AverageLaborRateCL.GoTo();
            Assert.True(AverageLaborRateCL.IsAt, "Average Labor Rate CL page was not displayed");
            var QMIRSContractRateData = AverageLaborRateCL.QMIRSContractRate.getQMIRSContractRateData();
            var ContractRateData = AverageLaborRateCL.ContractRate.getContractRateData();
            var CLData = AverageLaborRateCL.CL.getCLData();

            AdminMenu.GoToForecast();
            var ForecastView_QMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var ForecastView_EmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var ForecastView_EmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var ForecastView_QMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var ForecastView_ContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var ForecastView_CLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var ForecastView_QMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var ForecastView_AvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var ForecastView_TotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();

            isMatched = CommonFunctions.CompareDataObjects(QMIRSEmplLbrRateData, ForecastView_QMIRSEmplLbrRateData);
            Assert.True(isMatched, "QMIRS Empl Lbr Rate Data didn't match");
            isMatched = CommonFunctions.CompareDataObjects(EmployedLaborRateData, ForecastView_EmplLaborRateFcastData);
            Assert.True(isMatched, "Employed Labor Rate Data didn't match");
            isMatched = CommonFunctions.CompareDataObjects(EmployeeSalariesData, ForecastView_EmplSalariesFcastData);
            Assert.True(isMatched, "Employee Salaries Data didn't match");
            isMatched = CommonFunctions.CompareDataObjects(QMIRSContractRateData, ForecastView_QMIRSContractRateData);
            Assert.True(isMatched, "QMIRS Contract Rate Data didn't match");
            isMatched = CommonFunctions.CompareDataObjects(ContractRateData, ForecastView_ContractRateFcastData);
            Assert.True(isMatched, "Contract Rate Data didn't match");
            isMatched = CommonFunctions.CompareDataObjects(CLData, ForecastView_CLDollarsFcastData);
            Assert.True(isMatched, "CL Dollars Data didn't match");
            isMatched = CommonFunctions.CompareDataObjects(EmployeeSalariesData, ForecastView_TotalLaborDollarsFcastData);
            Assert.True(isMatched, "Employee Salaries Data didn't match");
            var expectedAvgEE_ClRateFcastData = CommonFunctions.GetSumOfTwoDataObjects(ForecastView_EmplLaborRateFcastData, ForecastView_ContractRateFcastData);
            isMatched = CommonFunctions.CompareDataObjects(ForecastView_AvgEE_ClRateFcastData, expectedAvgEE_ClRateFcastData);               
            Assert.True(isMatched, "expected Avg EE_Cl Rate Fcast data didn't match");

            DeptForecastButtonPanel.GoToAdmin();
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "Average Labor Rate Empl page was not displayed");
            AverageLaborRateEmpl.EmployedLaborRate.SetEmployedLaborRateData("45");
            AdminMenu.Save();
            var EmployedLaborRateModifiedData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();

            AverageLaborRateCL.GoTo();
            Assert.True(AverageLaborRateCL.IsAt, "Average Labor Rate CL page was not displayed");
            AverageLaborRateCL.ContractRate.SetContractRateData("55");
            AdminMenu.Save();
            var ContractRateModifiedData = AverageLaborRateCL.ContractRate.getContractRateData();
            AdminMenu.GoToForecast();
            //verify emp labor rate
            var ForecastView_EmplLaborRateFcastModifiedData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            isMatched = CommonFunctions.CompareDataObjects(EmployedLaborRateModifiedData, ForecastView_EmplLaborRateFcastModifiedData);
            Assert.True(isMatched, "Employed Labor Rate modified data didn't match");
            //Verify CL rate
            var ForecastView_ContractRateFcastModifiedData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            isMatched = CommonFunctions.CompareDataObjects(ContractRateModifiedData, ForecastView_ContractRateFcastModifiedData);
            Assert.True(isMatched, "Contract Rate modified data didn't match");
        }
        #endregion
    }
}
