﻿using AdoTestCasePlugin.Dtos;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class PlanWorkflow
    {
        public static void SubmitPlan()
        {
            bool bDisplayed;
            bDisplayed = ForecastView.IsAt;
            if (!bDisplayed)
            {
                DeptForecastButtonPanel.GoToAdmin();
                AdminMenu.GoToForecast();
                Assert.True(ForecastView.IsAt, "Forecast view page was not displayed.");
            }

            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
        }

        public static void ApprovedPlan()
        {
            bool bDisplayed;
            bDisplayed = ForecastView.IsAt;
            if (!bDisplayed)
            { 
                DeptForecastButtonPanel.GoToAdmin();
                AdminMenu.GoToForecast();
                Assert.True(ForecastView.IsAt, "Forecast view page was not displayed.");
            }

            var bSubmitted = SubmitForApproval.SubmitPlanForApproval();
            if (bSubmitted)
            {
                Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
                Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                    "User name was not displayed in the submission detail");
            }

            var bPlanApproved = DeptForecastButtonPanel.IsPlanApproved();
            if (!bPlanApproved)
            {
                DeptForecastButtonPanel.ApprovePlan();
                Comments.UserComment()
                    .withDescription($"Approving plan")
                    .Approve();
                Assert.True(DeptForecastButtonPanel.IsPlanApproved(), "Plan was not approved");

            }
        }

        public static void RejectPlan()
        {
            bool bDisplayed;
            bDisplayed = ForecastView.IsAt;
            if (!bDisplayed)
            {
                DeptForecastButtonPanel.GoToAdmin();
                AdminMenu.GoToForecast();
                Assert.True(ForecastView.IsAt, "Forecast view page was not displayed.");
            }

            var bPlanRejected = DeptForecastButtonPanel.IsPlanRejected();
            if (!bPlanRejected)
            {
                DeptForecastButtonPanel.RejectPlan();
                Comments.UserComment()
                    .withDescription($"Rejecting plan")
                    .Approve();
                Assert.True(DeptForecastButtonPanel.IsPlanRejected(), "Plan was not rejected");
            }
        }

        public static void ReleasePlan()
        {
            bool bDisplayed;
            bDisplayed = ForecastView.IsAt;
            if (!bDisplayed)
            {
                DeptForecastButtonPanel.GoToAdmin();
                AdminMenu.GoToForecast();
                Assert.True(ForecastView.IsAt, "Forecast view page was not displayed.");
            }

            var bSubmitted = SubmitForApproval.SubmitPlanForApproval();
            if (bSubmitted)
            {
                Assert.True(SubmitForApproval.IsAt, "Plan was not submitted for approval");
                Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                    "User name was not displayed in the submission detail");
            }

           var bPlanApproved = DeptForecastButtonPanel.IsPlanApproved();
            if (!bPlanApproved)
            {
                DeptForecastButtonPanel.ApprovePlan();
                Comments.UserComment()
                    .withDescription($"Approving plan ")
                    .Approve();
                Assert.True(DeptForecastButtonPanel.IsPlanApproved(), "Plan was not approved");
            }

            DeptForecastButtonPanel.ReleasePlan();
            Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
                $"The source plan was not released correctly.");
            CommonFunctions.WaitUntilPageIsAcive();

        }
    }
}
