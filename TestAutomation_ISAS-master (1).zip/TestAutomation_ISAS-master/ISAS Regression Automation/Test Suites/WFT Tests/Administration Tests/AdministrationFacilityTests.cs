﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Model;
using ISAS_Regression_Automation.Utilities;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using NuGet.Frameworks;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;


namespace ISAS_Regression_Automation
{
    [TestFixture]
    //[Parallelizable(ParallelScope.All)]
    public class AdministrationFacilityTests : Driver
    {

        [Test]
        public void VerifyFacilityLaborSummaryMonthlyReport()
        {
            RunData.PlanID = "253173932";
            string fileName = "MonthlyFacilityLaborReportExpToExl.XLS";
            string filePath = CommonFunctions.getDownloadedFile(fileName);
            var reportMetrics = CommonFunctions.ToList("Employed (Productive) FTEs, Contract Labor %, Contract FTEs, Total Productive FTEs, Non-Productive %, Non-Productive FTEs, Employed (Paid) FTEs, Total FTEs (Paid + Contract), Total Salaries & Wages ($000), Total Contract Labor ($000), Total Labor Expense ($000), Employed Labor Rate, Contract Labor Rate, Overtime Premium Dollars, Overtime %, Overtime FTEs, Admissions, Adjusted Admissions, Patient Days, APD, ER Visits, Outpatient Visits, EEOB, MH/AA");            
            var reportColumns = CommonFunctions.ToList("Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, Total");
            var DbColumns = CommonFunctions.ToList("MonthNum, MonthName, DaysInMonth, EmployedProductiveFtes, ContractPercent, ContractFTEs, TotalProductiveFtes, NonProductivePercent, NonProductiveFtes, EmployedPaidFtes, TotalFtes, TotalSalariesAndWages, TotalContractLaborDollars, TotalLaborExpense, EmployedLaborRate, ContractLaborRate, OverTimePremiumDollars, OtPercent, OTFTEs, Eeob, MhAa, Admissions, AAdmissions, PatientDays, APatientDays, ERVisits, Outpatient, Max_EmployedProductiveFtes, Max_ContractLaborPercent, Max_ContractFtes, Max_TotalProductiveFtes, Max_NonProductivePercent, Max_NonProductiveFtes, Max_EmployedPaidFtes, Max_TotalFtes, Max_TotalSalariesAndWages, Max_TotalContractLaborDollars, Max_TotalLaborExpense, Max_EmployedLaborRate, Max_ContractLaborRate, Max_OverTimePremiumDollars, Max_OtPercent, Max_OtFte, Max_Eeob, Max_MhAa, Min_EmployedProductiveFtes, Min_ContractLaborPercent, Min_ContractFtes, Min_TotalProductiveFtes, Min_NonProductivePercent, Min_NonProductiveFtes, Min_EmployedPaidFtes, Min_TotalFtes, Min_TotalSalariesAndWages, Min_TotalContractLaborDollars, Min_TotalLaborExpense, Min_EmployedLaborRate, Min_ContractLaborRate, Min_OverTimePremiumDollars, Min_OtPercent, Min_OtFte, Max_Admissions, Max_AAdmissions, Max_PatientDays, Max_APatientDays, Max_ERVisits, Max_Outpatient, Min_Admissions, Min_AAdmissions, Min_PatientDays, Min_APatientDays, Min_ERVisits, Min_Outpatient, Min_Eeob, Min_MhAa, EmployedProductiveFtesTotal, ContractPercentTotal, ContractFtesTotal, TotalProductiveFtesTotal, NonProductivePercentTotal, NonProductiveFtesTotal, EmployedPaidFtesTotal, TotalFtesTotal, TotalSalariesAndWagesTotal, TotalContractLaborDollarsTotal, TotalLaborExpenseTotal, EmployedLaborRateTotal, ContractLaborRateTotal, OverTimePremiumDollarsTotal, OtPercentTotal, OTFTEsTotal, EeobTotal, MhAaTotal");
            var FacilityLaborSummaryMonthlyExcelData = FacilityLaborSummaryMonthlyExcel.getFacilityLaborSummaryMonthlyExcelData(filePath, reportMetrics, reportColumns);           
            string query = FacilityLaborSummaryMonthlySP.getFacilityLaborSummaryMonthlySP();
            var result = FacilityLaborSummaryMonthlyDB.ExecuteAndPivot(query, DbColumns);

            Console.WriteLine();

        }



        //[Test]
        //[Category("WftCopyPlan"), Description("Journey")]
        public void VerifyCopyFunctionality()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Copy Functionality";
            //UserCanCopyWorkingRejectedPlan();
            UserCanCopyApprovedHistoricalPlan();
            UserCanCopyApprovedAndReleasedPlan();
            UserCanCopyPlanWithChangesMadeToFacilityStatsMappingPage();
        }

        [Test]
        public void UpdateTascData()
        {
            var parent = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;
            int counter = 1;
            string filePath = $@"{parent}\Utilities\TascData.txt";
            bool bCore, bAvg, bPeak, bResult;
            string line, TC, subFun, PrnValues;
            int TimeSaved;
            List<bool> blist = new List<bool>();
            var homePage = new HomePage(Driver.Instance);

            using (StreamReader reader = new StreamReader(filePath))
            {
                while ((line = reader.ReadLine()) != null)
                {
                    var arrData = line.Split('\t');
                    TC = arrData[0];
                    TimeSaved = int.Parse(arrData[1]);
                    Console.WriteLine();
                    var _tascBaseUrl = SettingData.TascUrl;
                    var _applicationId = int.Parse(arrData[2]);

                    if (string.IsNullOrEmpty(_tascBaseUrl) || TimeSaved == null) return;

                    var tm = new TascUpdater(_tascBaseUrl);
                    var result = tm.SendTestMetricsResult(_applicationId, TC, "Local Machine", TimeSaved);
                    Thread.Sleep(1000);
                    //Console.WriteLine($"TASC Updater Result: {result}");
                }
            }
        }

        [Test]
        public void UpdateExcel()
        {
           
            string filename = @"C:\Project\Selenium\DailyStatImportTemplate.xlsx";
            
            List<string> list = new List<string>() { "One", "Two", "Test3" };
            string inputDate = "Monday, June 9, 2025";
            string date = CommonFunctions.FormatDate(inputDate);
            Console.WriteLine(date);

            Dictionary<string, string> dic = new Dictionary<string, string>
            {
                {"C3", date },
                {"E3", date },
                {"B3", date },
                {"B8", date },
                {"F8", date }
            };

            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            //ExcelTemplate.WriteToExcelFile(filename, dic);
          // WindowsBasedUI.ChooseFile(filename);


            // Create test data with various number formats to show leading zero formatting
            var headers = new List<string> { "Coid", "Department#", "Date", "Adj Value" };
            var data = new List<List<object>>
            {
                new List<object> { "32801", "613", date, 9.75 }
                
            };

            CsvToExcelConverter.CreateExcelFile(filename, "Employees", headers, data);
            WindowsBasedUI.ChooseFile(filename);
            Console.WriteLine();
        }

        [Test]
        public async Task TestFacilityLaborYearlyAsync()
        {
            long planId = 243174933;   

            var runner = new StoredProcedureRunner();
            LaborMetricRow row = await runner.GetLaborMetricRowAsync(
                "dbo.rpt_getLaborSumFacility",
                new Dictionary<string, object?> { ["PlanID"] = planId });

            IReadOnlyList<MetricResult> outcomes = MetricEvaluator.EvaluateAll(row.ToMetricMap());
            foreach (var m in outcomes)
                Console.WriteLine($"{m.DisplayName,-28} {m.CurrentValue,12:N5}");
            
        }

        //[Test]
        public void Example()
        {

            string filePath = @"C:\Users\opt6590\Downloads\MonthlyDeptFTECountsReportExpToExl.XLS";

            // Read all rows as dynamic objects
            var rows = ExcelRowReader.ReadExcelAsObjects(filePath, useDynamicType: true);

            // Each object in the list has properties matching the column headers
            foreach (var row in rows)
            {
                // You can access properties dynamically
                var properties = row.GetType().GetProperties();
                foreach (var prop in properties)
                {
                    var value = prop.GetValue(row);
                    Console.WriteLine($"{prop.Name}: {value}");
                }
                Console.WriteLine("---");
            }

            // Or if you know the structure, you can cast to dynamic and access properties directly
            dynamic firstRow = rows.FirstOrDefault();
            if (firstRow != null)
            {
                // Access properties by name (this will work if the headers match)
                // Console.WriteLine($"Some Property: {firstRow.SomePropertyName}");
            }
        }


        //[Test]
        // [Category("WftCopyPlan"), Description("Journey")]
        public void VerifyFacilityMaintenanceJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Facility Maintenance Journey";
            UserCanCreateNewPlanBasedOnFacilityOption();
        }
        //[Test] [Category("WftCopyPlan")]
        public void UserCanVerifyFacilityNewPlanSettings()
        {
            bool IsNewDeptAdded;
            string deptNum = CommonFunctions.GenerateRandonNumber();
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            //mainly using system default option
            WFTFacilty.GoTo();
            Assert.True(WFTFacilty.IsAt, "Facility page was not displayed.");
            WFTFacilty.SetFacility()
                .withNumberOfRequiredApprovers("1 - One")
                .withNewPlanNonProductivePercent("Use PLUS Avg. NP %")
                .withNewPlanStatisticMapping("Use Most Recent Approved Plan")
                .withNewPlanVclPercentOrFixedFtes("Use Percent")
                .withCopyingPlanNonProductivePercent("Use PLUS Avg. NP %")
                .withCopyingPlanStatisticMapping("Use System Default")
                .withCopyingPlanEE_AHR_Months("Use System Default")
                .withCopyingPlanCL_AHR_Months("Use System Default")
                .withCopyingPlanCLPercentOrFixedFtes("Use Fixed")
                .withNewDeptartment(false) // if true, dept will be added. 
                .withNumber(deptNum)
                .withDescription($"New Dept {deptNum}")
                .withDepartmentType("Semi-Variable")
                .withDefaultFacilityStat("BIRTHS - 5815")
                .withDepartmentStat($"NewDept_{deptNum}")
                .Save();

            WFT_Admin_Plan.NavigateToAdminPlanPage();
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            var newPlanSettings = WFTNewPlan.GetNewPlanSettings();
            //verify Use PLUS Avg. NP % is selected in the new plan
            Assert.True(newPlanSettings.NonProductive_PLUS, "PLUS was selected in the new plan");
            Assert.True(newPlanSettings.StatisticMapping_Approved, "Satic mapping > Approved option was not selected in the new plan");
            Assert.True(newPlanSettings.Percent, "Percent was not selected in the new plan");

            //AdminMenu.GoToForecast();
            //IsNewDeptAdded = CommonFunctions.IsItemFoundinDropdownMenu("//select[@id='ddlwftDepartments']", deptNum);
            //Assert.True(IsNewDeptAdded, $"{deptNum} was not found");
        }

        //[Test] [Category("WftCopyPlan")]
        public void VerifyUserCanSelectPLUSforNonProductivePercentInFacilityPage()
        {
            bool isMatched;
            string Year = CommonFunctions.GetNextYear();
            string PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFTFacilty.GoTo();
            Assert.True(WFTFacilty.IsAt, "Facility page was not displayed.");
            WFTFacilty.SetFacility()
                .withNumberOfRequiredApprovers("1 - One")
                .withNewPlanNonProductivePercent("Use PLUS Avg. NP %")
                .withNewPlanStatisticMapping("Use Most Recent Approved Plan")
                .withNewPlanVclPercentOrFixedFtes("Use Percent")
                .withCopyingPlanNonProductivePercent("Use Copied Plan")
                .withCopyingPlanStatisticMapping("Use Copied Plan")
                .withCopyingPlanEE_AHR_Months("Use Copied Plan")
                .withCopyingPlanCL_AHR_Months("Use Copied Plan")
                .withCopyingPlanCLPercentOrFixedFtes("Use Copied Plan")
                .withNewDeptartment(false) // if true, dept will be added. 
                .withNumber("601")
                .withDescription("text")
                .withDepartmentType("Semi-Variable")
                .withDefaultFacilityStat("BIRTHS - 5815")
                .withDepartmentStat("text")
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse(string.Empty)
                    .withStatisticMapping(string.Empty)
                    .withForCLPercentOrFixedFtesUse(string.Empty)
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(false) // no data update.
                    .Create();

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(PlanDescription)
                .Select();
            CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 20);
            var PLUSAvgNPPercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            isMatched = PLUSAvgNPPercentData.Jan == NPPercentFcastExcludesCLData.Jan;
            Assert.True(isMatched, $"No match:\nPLUSAvgNPPercentData.Jan = {PLUSAvgNPPercentData.Jan}\n" +
                $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");

        }

        //[Test] [Category("WftCopyPlan")]
        //public void UserCanCopyWorkingRejectedPlan()
        //{
        //    RunData.AdoTestPlan = "WFT Journeys";
        //    RunData.AdoTestCaseName = "Verify Copy Functionality";
        //    bool bBothObjMatched, bCopiedAndNewPlansMatched;
        //    string CopiedPlanDescription, PlanDescription, SemiVariableDept;
        //    string Year = CommonFunctions.GetNextYear();
        //    PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
        //    Console.WriteLine($"PlanDescription: {PlanDescription}");
        //    CopiedPlanDescription = $"CopiedRejected_{PlanDescription}";
        //    Console.WriteLine($"CopiedPlanDescription: CopiedRejected_{PlanDescription}");
        //    SemiVariableDept = SettingData.CopyingDept;
        //    var homePage = new HomePage(Driver.Instance);
        //    var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
        //    homePage.NavigateToWorkloadForecaster();
        //    //Set Division and facility.
        //    Division.SetWFTDivisionAndFacility("32801");
        //    WFT_Admin_Plan.NavigateToAdminPlanPage();
        //    ExistingPlanFilter.ExistingPlan()
        //        .withYear(Year)
        //        .withPlanStatus("Released")
        //        .withPlan("(X)")
        //        .Select();
        //    //FacilityStatsMapping.GoTo();
        //   // Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");            
        //    // Get fac stat mapping data for dept
        //    var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingForReleasedAndAppprovedPlanData();
        //    AdminMenu.GoToForecast();
        //    DeptForecastMenu.clickSaveAndRecalc();
        //    var originalNPPercentFcastExcludesCLData =  ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
        //    var originalCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
        //    var originalCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();

        //    DeptForecastButtonPanel.GoToAdmin();
        //    CommonFunctions.WaitUntilPageIsAcive();

        //    // copy the plan
        //    CopyPlan.GoTo();            
        //    CopyPlan.Copy()
        //        .withPlanYear(Year)
        //        .withDescription(CopiedPlanDescription)
        //        .withUpdateForecast(false)
        //        .Save();
        //    CommonFunctions.WaitUntilPageIsAcive();
        //    FacilityStatsMapping.GoTo();
        //    Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");
        //    var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept); ;
        //    bool bMatched = CommonFunctions.CompareFacilityStatsMappingObjects(CopiedPlanFacilityStatsMapping, NewPlanFacilityStatsMapping);
        //    Assert.True(bMatched, "Copied plan did not work!");

        //    AdminMenu.GoToForecast();
        //    DeptForecastMenu.clickSaveAndRecalc();
        //    var CopiedNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
        //    var CopiedCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
        //    var CopiedCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();

        //    var bNPPercentMatched =  CommonFunctions.CompareDataObjects(originalNPPercentFcastExcludesCLData, CopiedNPPercentFcastExcludesCLData);
        //    Assert.True(bNPPercentMatched, "NP Percent Fcast Excludes CL data didn't match");
        //    var bCLHrsMatched = CommonFunctions.CompareDataObjects(originalCLHrsFcastData, CopiedCLHrsFcastData);
        //    Assert.True(bCLHrsMatched, "CLHrsFcast data didn't match. ");
        //    var bCLPercentMatched = CommonFunctions.CompareDataObjects(originalCLPercentFcastData, CopiedCLPercentFcastData);
        //    Assert.True(bCLPercentMatched, "CL Percent data didn't match.");

        //}        

        [Test]
        [Category("WftCopyPlan")]
        public void UserCanCopyPlan() 
        { 
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify source plan and new plan when copying";
            RunData.TimeSaved = 10800;

            string TestCasesFile = @"C:\Project\TestAutomation_ISAS\CopyPlanComparison\DataComparison.txt";
            if (File.Exists(TestCasesFile))
            {
                File.Delete(TestCasesFile);
            }

            bool bBothObjMatched, bCopiedAndNewPlansMatched;
            string CopiedPlanDescription, PlanDescription, SemiVariableDept;
            string Year = CommonFunctions.GetNextYear();
            PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"Plan's name: {PlanDescription}");
            // SemiVariableDept = SettingData.CopyingDept;
            SemiVariableDept = "687";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("27625");
            WFT_Admin_Plan.NavigateToAdminPlanPage();            
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");

            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            var SourceAdminPlanDetailData = AdminPlanDetail.getAdminPlanDetailData();
            // Get fac stat mapping data for dept
            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept);
            AdminMenu.GoToForecast();
            DeptForecastButtonPanel.clickSaveAndRecalc();
            DeptForecastMenu.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastButtonPanel.GoToAdmin();
            CommonFunctions.WaitUntilPageIsAcive();
            // copy the plan
            CopyPlan.GoTo();
            CopiedPlanDescription = $"Copied{PlanDescription}";
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");
            var CopiedAdminPlanDetailData = AdminPlanDetail.getAdminPlanDetailData();
            var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept); ;
            bool bMatched = CommonFunctions.CompareFacilityStatsMappingObjects(CopiedPlanFacilityStatsMapping, NewPlanFacilityStatsMapping);
            Assert.True(bMatched, "Copied plan did not work!");

            //Pass the plan ID instead of plan description
            string sourcePlanID = SourceAdminPlanDetailData.PlanID;
            string newPlanID = CopiedAdminPlanDetailData.PlanID;

            CompareOriginalPlanDataToCopiedPlanData(Year, "Working", sourcePlanID, newPlanID, SemiVariableDept);
            //Approve the plan and compare date
            CompareSoucelPlanDataToApprovedPlanData(Year, "All", sourcePlanID, SemiVariableDept);
        }

        [Test]
        [Category("WftCopyPlan")]
        public void UserCanCopyOldPlans()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify source plan and new plan when copying";
            RunData.TimeSaved = 10800;

            string TestCasesFile = @"C:\Project\TestAutomation_ISAS\CopyPlanComparison\OldPlanDataComparison.txt";
            if (File.Exists(TestCasesFile))
            {
                File.Delete(TestCasesFile);
            }

            bool bBothObjMatched, bCopiedAndNewPlansMatched;
            string CopiedPlanDescription, PlanDescription, SemiVariableDept;
            string Year = CommonFunctions.GetPreviousYear(2);
            PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"Plan's name: {PlanDescription}");
            // SemiVariableDept = SettingData.CopyingDept;
            SemiVariableDept = "687";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("27625");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            //AdministrationNewPlan.GoTo();
            //Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");

            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Existing Plan Filter wasn't displayed");
            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("All")
                .withPlan(string.Empty)
                .Select();

            var SourceAdminPlanDetailData = AdminPlanDetail.getAdminPlanDetailData();
            // Get fac stat mapping data for dept
//            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept);
           // AdminMenu.GoToForecast();
            //DeptForecastButtonPanel.clickSaveAndRecalc();
            //DeptForecastMenu.clickSaveAndRecalc();
            //CommonFunctions.WaitUntilPageIsAcive();
            //DeptForecastButtonPanel.GoToAdmin();
            //CommonFunctions.WaitUntilPageIsAcive();
            // copy the plan
            CopyPlan.GoTo();
            CopiedPlanDescription = $"Copied{PlanDescription}";
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");
            var CopiedAdminPlanDetailData = AdminPlanDetail.getAdminPlanDetailData();
          //  var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept); ;
           // bool bMatched = CommonFunctions.CompareFacilityStatsMappingObjects(CopiedPlanFacilityStatsMapping, NewPlanFacilityStatsMapping);
           // Assert.True(bMatched, "Copied plan did not work!");

            //Pass the plan ID instead of plan description
            string sourcePlanID = SourceAdminPlanDetailData.PlanID;
            string newPlanID = CopiedAdminPlanDetailData.PlanID;

            CompareOriginalPlanDataToCopiedPlanData(Year, "All", sourcePlanID, newPlanID, SemiVariableDept);
            //Approve the plan and compare date
            //CompareSoucelPlanDataToApprovedPlanData(Year, "All", sourcePlanID, SemiVariableDept);
        }

        [Test]
        [Category("WftCopyPlan")]
        public void UserCanComparePlanDataInDiffernetStatusesUsingWftFreezeAdministrator()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "UserCanComparePlanDataInDiffernetStatusesUsingWftFreezeAdministratorJouney";
            RunData.TimeSaved = 10800;

            bool createWithWftFreezeAdmin;
            bool submitWithWftFreezeAdmin;
            bool approveWithWftFreezeAdmin;
            bool releaseWithWftFreezeAdmin;

            RunData.ComparisonFile = "DataComparison1";
            UserCanComparePlanDataInDiffernetStatuses(false, false, false, false);
            RunData.ComparisonFile = "DataComparison2";
            UserCanComparePlanDataInDiffernetStatuses(false, false, false, true);
            RunData.ComparisonFile = "DataComparison3";
            UserCanComparePlanDataInDiffernetStatuses(false, false, true, false);
            RunData.ComparisonFile = "DataComparison4";
            UserCanComparePlanDataInDiffernetStatuses(false, false, true, true);
            RunData.ComparisonFile = "DataComparison5";
            UserCanComparePlanDataInDiffernetStatuses(false, true, false, false);
            RunData.ComparisonFile = "DataComparison6";
            UserCanComparePlanDataInDiffernetStatuses(false, true, false, true);
            RunData.ComparisonFile = "DataComparison7";
            UserCanComparePlanDataInDiffernetStatuses(false, true, true, false);
            RunData.ComparisonFile = "DataComparison8";
            UserCanComparePlanDataInDiffernetStatuses(false, true, true, true);
            RunData.ComparisonFile = "DataComparison9";
            UserCanComparePlanDataInDiffernetStatuses(true, false, false, false);
            RunData.ComparisonFile = "DataComparison10";
            UserCanComparePlanDataInDiffernetStatuses(true, false, false, true);
            RunData.ComparisonFile = "DataComparison11";
            UserCanComparePlanDataInDiffernetStatuses(true, false, true, false);
            RunData.ComparisonFile = "DataComparison12";
            UserCanComparePlanDataInDiffernetStatuses(true, false, true, true);
            RunData.ComparisonFile = "DataComparison13";
            UserCanComparePlanDataInDiffernetStatuses(true, true, false, false);
            RunData.ComparisonFile = "DataComparison14";
            UserCanComparePlanDataInDiffernetStatuses(true, true, false, true);
            RunData.ComparisonFile = "DataComparison15";
            UserCanComparePlanDataInDiffernetStatuses(true, true, true, false);
            RunData.ComparisonFile = "DataComparison16";
            UserCanComparePlanDataInDiffernetStatuses(true, true, true, true);

            //Insert Wft Freeze Administrator.
            CommonFunctions.InsertWftFreezeAdministrator();

            var lstEmptyTextFiles = CommonFunctions.GetNonEmptyTextFiles(RunData.NewPlanDataComprisonBaseFolder);
            bool bAllFilesEmpty = lstEmptyTextFiles.Count > 0 ? false : true;
            if(!bAllFilesEmpty)
            {
                foreach (var file in lstEmptyTextFiles)
                {
                    Console.WriteLine($"File: {file}");
                }
            }
            Assert.True(bAllFilesEmpty, "Data was inaccurate in new plan. Please check files");            
        }

        
        public void UserCanComparePlanDataInDiffernetStatuses()
        {

            bool createWithWftFreezeAdmin;
            bool submitWithWftFreezeAdmin;
            bool approveWithWftFreezeAdmin;
            bool releaseWithWftFreezeAdmin;

            RunData.ComparisonFile = "DataComparison1";
            UserCanComparePlanDataInDiffernetStatuses(false, false, false, false);
            RunData.ComparisonFile = "DataComparison2";
            UserCanComparePlanDataInDiffernetStatuses(false, false, false, true);
            RunData.ComparisonFile = "DataComparison3";
            UserCanComparePlanDataInDiffernetStatuses(false, false, true, false);
            RunData.ComparisonFile = "DataComparison4";
            UserCanComparePlanDataInDiffernetStatuses(false, false, true, true);
            RunData.ComparisonFile = "DataComparison5";
            UserCanComparePlanDataInDiffernetStatuses(false, true, false, false);
            RunData.ComparisonFile = "DataComparison6";
            UserCanComparePlanDataInDiffernetStatuses(false, true, false, true);
            RunData.ComparisonFile = "DataComparison7";
            UserCanComparePlanDataInDiffernetStatuses(false, true, true, false);
            RunData.ComparisonFile = "DataComparison8";
            UserCanComparePlanDataInDiffernetStatuses(false, true, true, true);
            RunData.ComparisonFile = "DataComparison9";
            UserCanComparePlanDataInDiffernetStatuses(true, false, false, false);
            RunData.ComparisonFile = "DataComparison10";
            UserCanComparePlanDataInDiffernetStatuses(true, false, false, true);
            RunData.ComparisonFile = "DataComparison11";
            UserCanComparePlanDataInDiffernetStatuses(true, false, true, false);
            RunData.ComparisonFile = "DataComparison12";
            UserCanComparePlanDataInDiffernetStatuses(true, false, true, true);
            RunData.ComparisonFile = "DataComparison13";
            UserCanComparePlanDataInDiffernetStatuses(true, true, false, false);
            RunData.ComparisonFile = "DataComparison14";
            UserCanComparePlanDataInDiffernetStatuses(true, true, false, true);
            RunData.ComparisonFile = "DataComparison15";
            UserCanComparePlanDataInDiffernetStatuses(true, true, true, false);
            RunData.ComparisonFile = "DataComparison16";
            UserCanComparePlanDataInDiffernetStatuses(true, true, true, true);

            string[] animals2 = new string[] { "deer", "moose", "boars" };
            var lstEmptyTextFiles = CommonFunctions.GetNonEmptyTextFiles(RunData.NewPlanDataComprisonBaseFolder);
            bool bAllFilesEmpty = lstEmptyTextFiles.Count > 0 ? false : true;
            if (!bAllFilesEmpty)
            {
                foreach (var file in lstEmptyTextFiles)
                {
                    Console.WriteLine($"File: {file}");
                }
            }
            Assert.True(bAllFilesEmpty, "Data was inaccurate in new plan. Please check files");
        }

        private void InsertDeleteWftFreezeAdmin(bool bflag)
        {
            if(bflag)
            {
                CommonFunctions.InsertWftFreezeAdministrator();
            }
            else
            {
                CommonFunctions.DeleteWftFreezeAdministrator();
            }
        }

        public void UserCanComparePlanDataInDiffernetStatuses(bool createWithWftFreezeAdmin, 
            bool submitWithWftFreezeAdmin,
            bool approveWithWftFreezeAdmin, 
            bool releaseWithWftFreezeAdmin)
        {
            string TestCasesFile = @$"{RunData.NewPlanDataComprisonBaseFolder}\{RunData.ComparisonFile}.txt";
            if (File.Exists(TestCasesFile))
            {
                File.Delete(TestCasesFile);
            }


            bool bBothObjMatched, bCopiedAndNewPlansMatched;
            string CopiedPlanDescription, PlanDescription, SemiVariableDept;
            string Year = CommonFunctions.GetNextYear();
            PlanDescription = $"TestingPlan{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"Plan's name: {PlanDescription}");
            // SemiVariableDept = SettingData.CopyingDept;
            SemiVariableDept = "610";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility("27625");
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            Console.WriteLine($"PlanDescription = {PlanDescription}");

            InsertDeleteWftFreezeAdmin(createWithWftFreezeAdmin);

            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("PLUS")
                    .withPLUSTargetMonth("September to All")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();

            var SourceAdminPlanDetailData = AdminPlanDetail.getAdminPlanDetailData();
            // Get fac stat mapping data for dept
            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept);
            AdminMenu.GoToForecast();
            DeptForecastButtonPanel.clickSaveAndRecalc();
            DeptForecastMenu.clickSaveAndRecalc();
            CommonFunctions.WaitUntilPageIsAcive();

            InsertDeleteWftFreezeAdmin(submitWithWftFreezeAdmin);
            CompareSoucelPlanDataToSubmittedPlanData(Year, "All", PlanDescription, SemiVariableDept);

            InsertDeleteWftFreezeAdmin(approveWithWftFreezeAdmin);
            CompareSoucelPlanDataToApprovedPlanData(Year, "All", PlanDescription, SemiVariableDept);

            InsertDeleteWftFreezeAdmin(releaseWithWftFreezeAdmin);
            CompareApprovedPlanDataToReleasedPlanData(Year, "All", PlanDescription, SemiVariableDept);



        }

        public void CompareOriginalPlanDataToCopiedPlanData(string Year, string Status,  string PlanDescription, string CopiedPlan, string Dept)
        {
            bool bMathced;
           //AdminMenu.GoToForecast();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "DepartmentForecastPlanFilter wasn't visible");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus(Status)
                .withPlan(PlanDescription)
                .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();

            var OriginalFacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var OriginalDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var OriginalHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var OriginalQMIRSStat6100Data = ForecastView_Volume.QMIRS_Stat6100.getQMIRSStat6100Data();
            var OriginalPLUSVolumeData = ForecastView_Volume.PLUSVolume.getPLUSVolumeData();
            var OriginalHostBudgetData = ForecastView_Volume.HostBudget.getHostBudgetData();
            var OriginalVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var OriginalVolumefcastStat6150Data = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
            var OriginalVolumefcastStat6160Data = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
            var OriginalVolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();            


            var OriginalProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            var OriginalFcastProdHrsUOSData = ForecastView_Standards.FcastProdHrsUOS.getFcastProdHrsUOSData();
            var OriginalPLUSStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            var OriginalQMIRSProdHrsUOSData = ForecastView_Standards.QMIRSProdHrsUOS.getQMIRSProdHrsUOSData();
            //one extra for B dept

            //Prod Hrs And FTEs
            var OriginalFcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var OriginalFcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            var OriginalQMIRSTotalProdFTEsData = ForecastView_ProdHrsAndFTEs.QMIRSTotalProdFTEs.getQMIRSTotalProdFTEsData();
            var OriginalFcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();

            //Contract %
            var OriginalQMIRSData = ForecastView_ContractPercent.QMIRS.getQMIRSData();
            var OriginalCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var OriginalCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
            var OriginalClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();

            //Non-Productive %
            var OriginalQMIRS_NP_PercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var OriginalPLUSAvgNP_PercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var OriginalNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var OriginalNPHrsFcastData = ForecastView_NonProductivePercent.NPHrsFcast.getNPHrsFcastData();

            //Paid Hrs and FTEs
            var OriginalFcastTotalPaidHrsDataa = ForecastView_PaidHrsAndFTEs.FcastTotalPaidHrs.getFcastTotalPaidHrsData();
            var OriginalFcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var OriginalFcastTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.FcastTotalPaidFTEs.getFcastTotalPaidFTEsData();
            var OriginalQMIRSTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.QMIRSTotalPaidFTEs.getQMIRSTotalPaidFTEsData();         

            //OT %
            var OriginalOTPercentQMIRSData = ForecastView_OTPercent.OTPercentQMIRS.getOTPercentQMIRSData();
            var OriginalOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var OriginalOTHrsFcastData = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
            var OriginalOTFTEsFcastData = ForecastView_OTPercent.OTFTEsFcast.getOTFTEsFcastData();

            //Labor Rates
            var OriginalQMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var OriginalEmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var OriginalEmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var OriginalQMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var OriginalContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var OriginalCLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var OriginalQMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var OriginalAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var OriginalTotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();


            //Summary View
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //Source Plan Facility FTE Summary
            var SourcePlanEmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            var SourcePlanContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            var SourcePlanContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var SourcePlanTotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            var SourcePlanNonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            var SourcePlanNonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            var SourcePlanEmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var SourcePlanTotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();

            //Source PlanFacility Labor Expense Summary
            var SourcePlanTotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            var SourcePlanTotContractLabor = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            var SourcePlanTotLaborExpense = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            var SourcePlanEmployedLaborRate = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            var SourcePlanContractLaborRate = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var SourcePlanOTPremiumDollars = FacilityLaborExpenseSummary.OTPremiumDollars.getOTPremiumDollarsData();
            var SourcePlanOvertimePercent = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var SourcePlanOvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();

            //Source PlanFacility Volume Summary
            var SourcePlanAdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var SourcePlanAdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var SourcePlanPatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var SourcePlanApdData = FacilityVolumeSummary.APD.getAPDData();
            var SourcePlanERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var SourcePlanOutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();
            var SourcePlanEeobData = FacilityVolumeSummary.EEOB.getEEOBData();
            var SourcePlanMhaaData = FacilityVolumeSummary.MHAA.getMHAA_Data();

            ForecastView.GoTo();
            Assert.True(ForecastView.IsAt, "Forecast view page was not displayed.");

            //Copied plan
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "DepartmentForecastPlanFilter wasn't visible");
            DepartmentForecastPlanFilter.ExistingPlan()
               .withYear(Year)
               .withPlanStatus(Status)
               .withPlan(CopiedPlan)
               .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();

            DeptForecastMenu.clickSaveAndRecalc();

            var CopiedFacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var CopiedDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var CopiedHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var CopiedQMIRSStat6100Data = ForecastView_Volume.QMIRS_Stat6100.getQMIRSStat6100Data();
            var CopiedPLUSVolumeData = ForecastView_Volume.PLUSVolume.getPLUSVolumeData();
            var CopiedHostBudgetData = ForecastView_Volume.HostBudget.getHostBudgetData();
            var CopiedVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var CopiedVolumefcastStat6150Data = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
            var CopiedVolumefcastStat6160Data = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
            var CopiedVolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();

            var CopiedlProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            var CopiedFcastProdHrsUOSData = ForecastView_Standards.FcastProdHrsUOS.getFcastProdHrsUOSData();
            var CopiedPLUSStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            var CopiedQMIRSProdHrsUOSData = ForecastView_Standards.QMIRSProdHrsUOS.getQMIRSProdHrsUOSData();
            //one extra for B dept

            //Prod Hrs And FTEs
            var CopiedFcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var CopiedFcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            var CopiedQMIRSTotalProdFTEsData = ForecastView_ProdHrsAndFTEs.QMIRSTotalProdFTEs.getQMIRSTotalProdFTEsData();
            var CopiedFcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();

            //Contract %
            var CopiedQMIRSData = ForecastView_ContractPercent.QMIRS.getQMIRSData();
            var CopiedCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var CopiedCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
            var CopiedClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();

            //Non-Productive %
            var CopiedQMIRS_NP_PercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var CopiedPLUSAvgNP_PercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var CopiedNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var CopiedNPHrsFcastData = ForecastView_NonProductivePercent.NPHrsFcast.getNPHrsFcastData();

            //Paid Hrs and FTEs
            var CopiedFcastTotalPaidHrsDataa = ForecastView_PaidHrsAndFTEs.FcastTotalPaidHrs.getFcastTotalPaidHrsData();
            var CopiedFcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var CopiedFcastTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.FcastTotalPaidFTEs.getFcastTotalPaidFTEsData();
            var CopiedQMIRSTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.QMIRSTotalPaidFTEs.getQMIRSTotalPaidFTEsData();

            //OT %
            var CopiedOTPercentQMIRSData = ForecastView_OTPercent.OTPercentQMIRS.getOTPercentQMIRSData();
            var CopiedOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var CopiedOTHrsFcastData = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
            var CopiedOTFTEsFcastData = ForecastView_OTPercent.OTFTEsFcast.getOTFTEsFcastData();

            //Labor Rates
            var CopiedQMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var CopiedEmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var CopiedEmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var CopiedQMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var CopiedContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var CopiedCLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var CopiedQMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var CopiedAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var CopiedTotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();


            //Summary View
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //New Plan Facility FTE Summary
            var NewPlanEmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            var NewPlanContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            var NewPlanContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var NewPlanTotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            var NewPlanNonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            var NewPlanNonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            var NewPlanEmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var NewPlanTotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();

            //New PlanFacility Labor Expense Summary
            var NewPlanTotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            var NewPlanTotContractLabor = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            var NewPlanTotLaborExpense = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            var NewPlanEmployedLaborRate = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            var NewPlanContractLaborRate = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var NewPlanOTPremiumDollars = FacilityLaborExpenseSummary.OTPremiumDollars.getOTPremiumDollarsData();
            var NewPlanOvertimePercent = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var NewPlanOvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();

            //New PlanFacility Volume Summary
            var NewPlanAdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var NewPlanAdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var NewPlanPatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var NewPlanApdData = FacilityVolumeSummary.APD.getAPDData();
            var NewPlanERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var NewPlanOutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();
            var NewPlanEeobData = FacilityVolumeSummary.EEOB.getEEOBData();
            var NewPlanMhaaData = FacilityVolumeSummary.MHAA.getMHAA_Data();

            #region: Forecast View assertions
            //Forecast View
            //Volume
            bMathced = CommonFunctions.CompareDataObjects(OriginalFacilityStatsData, CopiedFacilityStatsData, "OriginalFacilityStatsData");
            Assert.True(bMathced, "Facility Stats Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalDeptFacilityRatioData, CopiedDeptFacilityRatioData, "OriginalDeptFacilityRatioData");
            Assert.True(bMathced, "Dept Facility Ratio Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalHistDeptFacilityRatioData, CopiedHistDeptFacilityRatioData, "OriginalHistDeptFacilityRatioData");
            Assert.True(bMathced, "HistDeptFacilityRatio Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSStat6100Data, CopiedQMIRSStat6100Data, "CopiedQMIRSStat6100Data");
            Assert.True(bMathced, "QMIRSStat6100 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSVolumeData, CopiedPLUSVolumeData, "CopiedPLUSVolumeData");
            Assert.True(bMathced, "PLUSVolume Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalHostBudgetData, CopiedHostBudgetData, "CopiedHostBudgetData");
            Assert.True(bMathced, "HostBudget Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6100Data, CopiedVolumefcastStat6100Data, "CopiedVolumefcastStat6100Data");
            Assert.True(bMathced, "VolumefcastStat6100 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6150Data, CopiedVolumefcastStat6150Data, "CopiedVolumefcastStat6150Data");
            Assert.True(bMathced, "VolumefcastStat6150 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6160Data, CopiedVolumefcastStat6160Data, "CopiedVolumefcastStat6160Data");
            Assert.True(bMathced, "VolumefcastStat616 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumeDailyAverageVolumeData, CopiedVolumeDailyAverageVolumeData, "CopiedVolumeDailyAverageVolumeData");
            Assert.True(bMathced, "VolumeDailyAverageVolume Data didn't match");

            //Standards
            bMathced = CommonFunctions.CompareDataObjects(OriginalProductiveMinFTEsData, CopiedlProductiveMinFTEsData, "CopiedlProductiveMinFTEsData");
            Assert.True(bMathced, "ProductiveMinFTEs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastProdHrsUOSData, CopiedFcastProdHrsUOSData, "CopiedFcastProdHrsUOSData");
            Assert.True(bMathced, "FcastProdHrsUO Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSStdSV_FTEsData, CopiedPLUSStdSV_FTEsData, "CopiedPLUSStdSV_FTEsData");
            Assert.True(bMathced, "PLUSStdSV_FTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSProdHrsUOSData, CopiedQMIRSProdHrsUOSData, "CopiedQMIRSProdHrsUOSData");
            Assert.True(bMathced, "QMIRSProdHrsUOS Data didn't match");

            //Prod Hrs And FTEs
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalProdHrsData, CopiedFcastTotalProdHrsData, "CopiedFcastTotalProdHrsData");
            Assert.True(bMathced, "FcastTotalProdHrs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalProdFtesData, CopiedFcastTotalProdFtesData, "CopiedFcastTotalProdFtesData");
            Assert.True(bMathced, "FcastTotalProdFtes Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSTotalProdFTEsData, CopiedQMIRSTotalProdFTEsData, "CopiedQMIRSTotalProdFTEsData");
            //Assert.True(bMathced, "QMIRSTotalProdFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastEmplProdHrsData, CopiedFcastEmplProdHrsData, "CopiedFcastEmplProdHrsData");
            Assert.True(bMathced, "FcastEmplProdHrs Data didn't match");

            //Contract %
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSData, CopiedQMIRSData, "CopiedQMIRSData");
            Assert.True(bMathced, "QMIRS didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLPercentFcastData, CopiedCLPercentFcastData, "CopiedCLPercentFcastData");
            Assert.True(bMathced, "CLPercentFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLHrsFcastData, CopiedCLHrsFcastData, "CopiedCLHrsFcastData");
            Assert.True(bMathced, "CLHrsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalClFtesFcastData, CopiedClFtesFcastData, "CopiedClFtesFcastData");
            Assert.True(bMathced, "ClFtesFcas Data didn't match");

            //Non - Productive %
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRS_NP_PercentData, CopiedQMIRS_NP_PercentData, "CopiedQMIRS_NP_PercentData");
            Assert.True(bMathced, "QMIRS_NP_Percent didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSAvgNP_PercentData, CopiedPLUSAvgNP_PercentData, "CopiedPLUSAvgNP_PercentData");
            Assert.True(bMathced, "FcastProdHrsUO Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalNPPercentFcastExcludesCLData, CopiedNPPercentFcastExcludesCLData, "OriginalNPPercentFcastExcludesCLData");
            Assert.True(bMathced, "NPPercentFcastExcludesCL Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalNPHrsFcastData, CopiedNPHrsFcastData, "CopiedNPHrsFcastData");
            Assert.True(bMathced, "NPHrsFcast Data didn't match");

            //Paid Hrs and FTEs
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalPaidHrsDataa, CopiedFcastTotalPaidHrsDataa, "CopiedFcastTotalPaidHrsDataa");
            Assert.True(bMathced, "FcastTotalPaidHrs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastEmplPaidHrsData, CopiedFcastEmplPaidHrsData, "CopiedFcastEmplPaidHrsData");
            //Assert.True(bMathced, "FcastEmplPaidHrs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalPaidFTEsData, CopiedFcastTotalPaidFTEsData, "CopiedFcastTotalPaidFTEsData");
            Assert.True(bMathced, "FcastTotalPaidFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSTotalPaidFTEsData, CopiedQMIRSTotalPaidFTEsData, "CopiedQMIRSTotalPaidFTEsData");
            Assert.True(bMathced, "QMIRSTotalPaidFTEs Data didn't match");

            //OT %
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTPercentQMIRSData, CopiedOTPercentQMIRSData, "CopiedOTPercentQMIRSData");
            Assert.True(bMathced, "OTPercentQMIRS didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTPercentFcastData, CopiedOTPercentFcastData, "CopiedOTPercentFcastData");
            Assert.True(bMathced, "OTPercentFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTHrsFcastData, CopiedOTHrsFcastData, "CopiedOTHrsFcastData");
            Assert.True(bMathced, "OTHrsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTFTEsFcastData, CopiedOTFTEsFcastData, "CopiedOTFTEsFcastData");
            Assert.True(bMathced, "OTFTEsFcast Data didn't match");

            //Labor Rates
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSEmplLbrRateData, CopiedQMIRSEmplLbrRateData, "OriginalQMIRSEmplLbrRateData");
            Assert.True(bMathced, "QMIRSEmplLbrRate didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalEmplLaborRateFcastData, CopiedEmplLaborRateFcastData, "CopiedEmplLaborRateFcastData");
            Assert.True(bMathced, "EmplLaborRateFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalEmplSalariesFcastData, CopiedEmplSalariesFcastData, "CopiedEmplSalariesFcastData");
            Assert.True(bMathced, "EmplSalariesFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSContractRateData, CopiedQMIRSContractRateData, "CopiedQMIRSContractRateData");
            Assert.True(bMathced, "QMIRSContractRate Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalContractRateFcastData, CopiedContractRateFcastData, "CopiedContractRateFcastData");
            Assert.True(bMathced, "ContractRateFcast didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLDollarsFcastData, CopiedCLDollarsFcastData, "CopiedCLDollarsFcastData");
            Assert.True(bMathced, "CLDollarsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSAvgRateData, CopiedQMIRSAvgRateData, "CopiedQMIRSAvgRateData");
            Assert.True(bMathced, "PLUSStdSV_FTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalAvgEE_ClRateFcastData, CopiedAvgEE_ClRateFcastData, "CopiedAvgEE_ClRateFcastData");
            Assert.True(bMathced, "AvgEE_ClRateFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalTotalLaborDollarsFcastData, CopiedTotalLaborDollarsFcastData, "CopiedTotalLaborDollarsFcastData");
            Assert.True(bMathced, "TotalLaborDollarsFcast Data didn't match");
            #endregion

            #region: Summary View Assertions
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedProductiveFTEsData, NewPlanEmployedProductiveFTEsData, "SourcePlanEmployedProductiveFTEsData");
            Assert.True(bMathced, "EmployedProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractLaborPercentData, NewPlanContractLaborPercentData, "NewPlanContractLaborPercentData");
            Assert.True(bMathced, "ContractLaborPercent Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractFTEsData, NewPlanContractFTEsData, "NewPlanContractFTEsData");
            Assert.True(bMathced, "ContractFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotalProductiveFTEsData, NewPlanTotalProductiveFTEsData, "NewPlanTotalProductiveFTEsData");
            Assert.True(bMathced, "ProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanNonProductivePercentData, NewPlanNonProductivePercentData, "NewPlanNonProductivePercentData");
            Assert.True(bMathced, "ProductivePercentData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanNonProductiveFTEsData, NewPlanNonProductiveFTEsData, "NewPlanNonProductiveFTEsData");
            Assert.True(bMathced, "NonProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedPaidFTEsData, NewPlanEmployedPaidFTEsData, "NewPlanEmployedPaidFTEsData");
            Assert.True(bMathced, "EmployedPaidFTEsData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotalFTEsPaidPlusContractData, NewPlanTotalFTEsPaidPlusContractData, "NewPlanTotalFTEsPaidPlusContractData");
            Assert.True(bMathced, "TotalFTEsPaidPlusContractData didn't match");


            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotSalAndWagesData, NewPlanTotSalAndWagesData, "NewPlanTotSalAndWagesData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotContractLabor, NewPlanTotContractLabor, "NewPlanTotContractLabor");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotLaborExpense, NewPlanTotLaborExpense, "NewPlanTotLaborExpense");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedLaborRate, NewPlanEmployedLaborRate, "NewPlanEmployedLaborRate");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractLaborRate, NewPlanContractLaborRate, "NewPlanContractLaborRate");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOTPremiumDollars, NewPlanOTPremiumDollars, "NewPlanOTPremiumDollars");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOvertimePercent, NewPlanOvertimePercent, "NewPlanOvertimePercent");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOvertimeFTEsData, NewPlanOvertimeFTEsData, "NewPlanOvertimeFTEsData");
            Assert.True(bMathced, "Data didn't match");

            bMathced = CommonFunctions.CompareDataObjects(SourcePlanAdmissionsData, NewPlanAdmissionsData, "NewPlanAdmissionsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanAdjustedAdmissionsData, NewPlanAdjustedAdmissionsData, "NewPlanAdjustedAdmissionsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanPatientDaysData, NewPlanPatientDaysData, "NewPlanPatientDaysData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanApdData, NewPlanApdData, "NewPlanApdData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanERVisitsData, NewPlanERVisitsData, "NewPlanERVisitsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOutPatientVisitsData, NewPlanOutPatientVisitsData, "NewPlanOutPatientVisitsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEeobData, NewPlanEeobData, "NewPlanEeobData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanMhaaData, NewPlanMhaaData, "NewPlanMhaaData");
            Assert.True(bMathced, "Data didn't match");
            #endregion
        }

        public void CompareSoucelPlanDataToSubmittedPlanData(string Year, string Status, string OriginalPlan, string Dept)
        {
            bool bMathced;
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "DepartmentForecastPlanFilter wasn't visible");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus(Status)
                .withPlan(OriginalPlan)
                .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();

            var OriginalFacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var OriginalDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var OriginalHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var OriginalQMIRSStat6100Data = ForecastView_Volume.QMIRS_Stat6100.getQMIRSStat6100Data();
            var OriginalPLUSVolumeData = ForecastView_Volume.PLUSVolume.getPLUSVolumeData();
            var OriginalHostBudgetData = ForecastView_Volume.HostBudget.getHostBudgetData();
            var OriginalVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var OriginalVolumefcastStat6150Data = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
            var OriginalVolumefcastStat6160Data = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
            var OriginalVolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();


            var OriginalProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            var OriginalFcastProdHrsUOSData = ForecastView_Standards.FcastProdHrsUOS.getFcastProdHrsUOSData();
            var OriginalPLUSStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            var OriginalQMIRSProdHrsUOSData = ForecastView_Standards.QMIRSProdHrsUOS.getQMIRSProdHrsUOSData();
            //one extra for B dept

            //Prod Hrs And FTEs
            var OriginalFcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var OriginalFcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            var OriginalQMIRSTotalProdFTEsData = ForecastView_ProdHrsAndFTEs.QMIRSTotalProdFTEs.getQMIRSTotalProdFTEsData();
            var OriginalFcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();

            //Contract %
            var OriginalQMIRSData = ForecastView_ContractPercent.QMIRS.getQMIRSData();
            var OriginalCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var OriginalCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
            var OriginalClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();

            //Non-Productive %
            var OriginalQMIRS_NP_PercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var OriginalPLUSAvgNP_PercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var OriginalNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var OriginalNPHrsFcastData = ForecastView_NonProductivePercent.NPHrsFcast.getNPHrsFcastData();

            //Paid Hrs and FTEs
            var OriginalFcastTotalPaidHrsDataa = ForecastView_PaidHrsAndFTEs.FcastTotalPaidHrs.getFcastTotalPaidHrsData();
            var OriginalFcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var OriginalFcastTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.FcastTotalPaidFTEs.getFcastTotalPaidFTEsData();
            var OriginalQMIRSTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.QMIRSTotalPaidFTEs.getQMIRSTotalPaidFTEsData();

            //OT %
            var OriginalOTPercentQMIRSData = ForecastView_OTPercent.OTPercentQMIRS.getOTPercentQMIRSData();
            var OriginalOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var OriginalOTHrsFcastData = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
            var OriginalOTFTEsFcastData = ForecastView_OTPercent.OTFTEsFcast.getOTFTEsFcastData();

            //Labor Rates
            var OriginalQMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var OriginalEmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var OriginalEmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var OriginalQMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var OriginalContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var OriginalCLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var OriginalQMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var OriginalAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var OriginalTotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();


            //Summary View
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //Source Plan Facility FTE Summary
            var SourcePlanEmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            var SourcePlanContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            var SourcePlanContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var SourcePlanTotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            var SourcePlanNonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            var SourcePlanNonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            var SourcePlanEmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var SourcePlanTotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();

            //Source PlanFacility Labor Expense Summary
            var SourcePlanTotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            var SourcePlanTotContractLabor = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            var SourcePlanTotLaborExpense = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            var SourcePlanEmployedLaborRate = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            var SourcePlanContractLaborRate = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var SourcePlanOTPremiumDollars = FacilityLaborExpenseSummary.OTPremiumDollars.getOTPremiumDollarsData();
            var SourcePlanOvertimePercent = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var SourcePlanOvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();

            //Source PlanFacility Volume Summary
            var SourcePlanAdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var SourcePlanAdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var SourcePlanPatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var SourcePlanApdData = FacilityVolumeSummary.APD.getAPDData();
            var SourcePlanERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var SourcePlanOutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();
            var SourcePlanEeobData = FacilityVolumeSummary.EEOB.getEEOBData();
            var SourcePlanMhaaData = FacilityVolumeSummary.MHAA.getMHAA_Data();

            ForecastView.GoTo();
            Assert.True(ForecastView.IsAt, "Forecast view page was not displayed.");

            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            //DeptForecastButtonPanel.ApprovePlan();
            //Comments.UserComment()
            //    .withDescription($"Approving {OriginalPlan}")
            //    .Approve();
            //Assert.True(DeptForecastButtonPanel.IsPlanApproved(), "Plan was not approved");
            //DeptForecastButtonPanel.ReleasePlan();
            //Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
            //    $"{OriginalPlan} was not released correctly.");
            //Assert.True(DeptForecastButtonPanel.IsPlanReleased(), "Plan was not released");
            CommonFunctions.WaitUntilPageIsAcive();
            var deptDetail = DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();
            var approvedPlanID = deptDetail.PlanID;

            var CopiedFacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var CopiedDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var CopiedHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var CopiedQMIRSStat6100Data = ForecastView_Volume.QMIRS_Stat6100.getQMIRSStat6100Data();
            var CopiedPLUSVolumeData = ForecastView_Volume.PLUSVolume.getPLUSVolumeData();
            var CopiedHostBudgetData = ForecastView_Volume.HostBudget.getHostBudgetData();
            var CopiedVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var CopiedVolumefcastStat6150Data = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
            var CopiedVolumefcastStat6160Data = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
            var CopiedVolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();

            var CopiedlProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            var CopiedFcastProdHrsUOSData = ForecastView_Standards.FcastProdHrsUOS.getFcastProdHrsUOSData();
            var CopiedPLUSStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            var CopiedQMIRSProdHrsUOSData = ForecastView_Standards.QMIRSProdHrsUOS.getQMIRSProdHrsUOSData();
            //one extra for B dept

            //Prod Hrs And FTEs
            var CopiedFcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var CopiedFcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            var CopiedQMIRSTotalProdFTEsData = ForecastView_ProdHrsAndFTEs.QMIRSTotalProdFTEs.getQMIRSTotalProdFTEsData();
            var CopiedFcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();

            //Contract %
            var CopiedQMIRSData = ForecastView_ContractPercent.QMIRS.getQMIRSData();
            var CopiedCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var CopiedCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
            var CopiedClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();

            //Non-Productive %
            var CopiedQMIRS_NP_PercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var CopiedPLUSAvgNP_PercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var CopiedNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var CopiedNPHrsFcastData = ForecastView_NonProductivePercent.NPHrsFcast.getNPHrsFcastData();

            //Paid Hrs and FTEs
            var CopiedFcastTotalPaidHrsDataa = ForecastView_PaidHrsAndFTEs.FcastTotalPaidHrs.getFcastTotalPaidHrsData();
            var CopiedFcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var CopiedFcastTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.FcastTotalPaidFTEs.getFcastTotalPaidFTEsData();
            var CopiedQMIRSTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.QMIRSTotalPaidFTEs.getQMIRSTotalPaidFTEsData();

            //OT %
            var CopiedOTPercentQMIRSData = ForecastView_OTPercent.OTPercentQMIRS.getOTPercentQMIRSData();
            var CopiedOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var CopiedOTHrsFcastData = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
            var CopiedOTFTEsFcastData = ForecastView_OTPercent.OTFTEsFcast.getOTFTEsFcastData();

            //Labor Rates
            var CopiedQMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var CopiedEmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var CopiedEmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var CopiedQMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var CopiedContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var CopiedCLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var CopiedQMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var CopiedAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var CopiedTotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();


            //Summary View
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //New Plan Facility FTE Summary
            var NewPlanEmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            var NewPlanContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            var NewPlanContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var NewPlanTotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            var NewPlanNonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            var NewPlanNonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            var NewPlanEmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var NewPlanTotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();

            //New PlanFacility Labor Expense Summary
            var NewPlanTotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            var NewPlanTotContractLabor = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            var NewPlanTotLaborExpense = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            var NewPlanEmployedLaborRate = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            var NewPlanContractLaborRate = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var NewPlanOTPremiumDollars = FacilityLaborExpenseSummary.OTPremiumDollars.getOTPremiumDollarsData();
            var NewPlanOvertimePercent = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var NewPlanOvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();

            //New PlanFacility Volume Summary
            var NewPlanAdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var NewPlanAdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var NewPlanPatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var NewPlanApdData = FacilityVolumeSummary.APD.getAPDData();
            var NewPlanERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var NewPlanOutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();
            var NewPlanEeobData = FacilityVolumeSummary.EEOB.getEEOBData();
            var NewPlanMhaaData = FacilityVolumeSummary.MHAA.getMHAA_Data();

            #region: Forecast View assertions
            //Forecast View
            //Volume
            bMathced = CommonFunctions.CompareDataObjects(OriginalFacilityStatsData, CopiedFacilityStatsData, "OriginalFacilityStatsData");
            Assert.True(bMathced, "Facility Stats Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalDeptFacilityRatioData, CopiedDeptFacilityRatioData, "OriginalDeptFacilityRatioData");
            Assert.True(bMathced, "Dept Facility Ratio Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalHistDeptFacilityRatioData, CopiedHistDeptFacilityRatioData, "OriginalHistDeptFacilityRatioData");
            Assert.True(bMathced, "HistDeptFacilityRatio Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSStat6100Data, CopiedQMIRSStat6100Data, "CopiedQMIRSStat6100Data");
            Assert.True(bMathced, "QMIRSStat6100 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSVolumeData, CopiedPLUSVolumeData, "CopiedPLUSVolumeData");
            Assert.True(bMathced, "PLUSVolume Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalHostBudgetData, CopiedHostBudgetData, "CopiedHostBudgetData");
            Assert.True(bMathced, "HostBudget Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6100Data, CopiedVolumefcastStat6100Data, "CopiedVolumefcastStat6100Data");
            Assert.True(bMathced, "VolumefcastStat6100 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6150Data, CopiedVolumefcastStat6150Data, "CopiedVolumefcastStat6150Data");
            Assert.True(bMathced, "VolumefcastStat6150 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6160Data, CopiedVolumefcastStat6160Data, "CopiedVolumefcastStat6160Data");
            Assert.True(bMathced, "VolumefcastStat616 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumeDailyAverageVolumeData, CopiedVolumeDailyAverageVolumeData, "CopiedVolumeDailyAverageVolumeData");
            Assert.True(bMathced, "VolumeDailyAverageVolume Data didn't match");

            //Standards
            bMathced = CommonFunctions.CompareDataObjects(OriginalProductiveMinFTEsData, CopiedlProductiveMinFTEsData, "CopiedlProductiveMinFTEsData");
            Assert.True(bMathced, "ProductiveMinFTEs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastProdHrsUOSData, CopiedFcastProdHrsUOSData, "CopiedFcastProdHrsUOSData");
            Assert.True(bMathced, "FcastProdHrsUO Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSStdSV_FTEsData, CopiedPLUSStdSV_FTEsData, "CopiedPLUSStdSV_FTEsData");
            Assert.True(bMathced, "PLUSStdSV_FTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSProdHrsUOSData, CopiedQMIRSProdHrsUOSData, "CopiedQMIRSProdHrsUOSData");
            Assert.True(bMathced, "QMIRSProdHrsUOS Data didn't match");

            //Prod Hrs And FTEs
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalProdHrsData, CopiedFcastTotalProdHrsData, "CopiedFcastTotalProdHrsData");
            Assert.True(bMathced, "FcastTotalProdHrs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalProdFtesData, CopiedFcastTotalProdFtesData, "CopiedFcastTotalProdFtesData");
            Assert.True(bMathced, "FcastTotalProdFtes Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSTotalProdFTEsData, CopiedQMIRSTotalProdFTEsData, "CopiedQMIRSTotalProdFTEsData");
            //Assert.True(bMathced, "QMIRSTotalProdFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastEmplProdHrsData, CopiedFcastEmplProdHrsData, "CopiedFcastEmplProdHrsData");
            Assert.True(bMathced, "FcastEmplProdHrs Data didn't match");

            //Contract %
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSData, CopiedQMIRSData, "CopiedQMIRSData");
            Assert.True(bMathced, "QMIRS didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLPercentFcastData, CopiedCLPercentFcastData, "CopiedCLPercentFcastData");
            Assert.True(bMathced, "CLPercentFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLHrsFcastData, CopiedCLHrsFcastData, "CopiedCLHrsFcastData");
            Assert.True(bMathced, "CLHrsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalClFtesFcastData, CopiedClFtesFcastData, "CopiedClFtesFcastData");
            Assert.True(bMathced, "ClFtesFcas Data didn't match");

            // Non - Productive %
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRS_NP_PercentData, CopiedQMIRS_NP_PercentData, "CopiedQMIRS_NP_PercentData");
            Assert.True(bMathced, "QMIRS_NP_Percent didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSAvgNP_PercentData, CopiedPLUSAvgNP_PercentData, "CopiedPLUSAvgNP_PercentData");
            Assert.True(bMathced, "FcastProdHrsUO Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalNPPercentFcastExcludesCLData, CopiedNPPercentFcastExcludesCLData, "OriginalNPPercentFcastExcludesCLData");
            //Assert.True(bMathced, "NPPercentFcastExcludesCL Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalNPHrsFcastData, CopiedNPHrsFcastData, "CopiedNPHrsFcastData");
            //Assert.True(bMathced, "NPHrsFcast Data didn't match");

            //Paid Hrs and FTEs
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalPaidHrsDataa, CopiedFcastTotalPaidHrsDataa, "CopiedFcastTotalPaidHrsDataa");
            //Assert.True(bMathced, "FcastTotalPaidHrs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastEmplPaidHrsData, CopiedFcastEmplPaidHrsData, "CopiedFcastEmplPaidHrsData");
            //Assert.True(bMathced, "FcastEmplPaidHrs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalPaidFTEsData, CopiedFcastTotalPaidFTEsData, "CopiedFcastTotalPaidFTEsData");
            //Assert.True(bMathced, "FcastTotalPaidFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSTotalPaidFTEsData, CopiedQMIRSTotalPaidFTEsData, "CopiedQMIRSTotalPaidFTEsData");
            Assert.True(bMathced, "QMIRSTotalPaidFTEs Data didn't match");

            //OT %
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTPercentQMIRSData, CopiedOTPercentQMIRSData, "CopiedOTPercentQMIRSData");
            Assert.True(bMathced, "OTPercentQMIRS didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTPercentFcastData, CopiedOTPercentFcastData, "CopiedOTPercentFcastData");
            Assert.True(bMathced, "OTPercentFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTHrsFcastData, CopiedOTHrsFcastData, "CopiedOTHrsFcastData");
            Assert.True(bMathced, "OTHrsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTFTEsFcastData, CopiedOTFTEsFcastData, "CopiedOTFTEsFcastData");
            Assert.True(bMathced, "OTFTEsFcast Data didn't match");

            // Rates
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSEmplLbrRateData, CopiedQMIRSEmplLbrRateData, "OriginalQMIRSEmplLbrRateData");
            Assert.True(bMathced, "QMIRSEmplLbrRate didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalEmplLaborRateFcastData, CopiedEmplLaborRateFcastData, "CopiedEmplLaborRateFcastData");
            Assert.True(bMathced, "EmplLaborRateFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalEmplSalariesFcastData, CopiedEmplSalariesFcastData, "CopiedEmplSalariesFcastData");
            Assert.True(bMathced, "EmplSalariesFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSContractRateData, CopiedQMIRSContractRateData, "CopiedQMIRSContractRateData");
            Assert.True(bMathced, "QMIRSContractRate Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalContractRateFcastData, CopiedContractRateFcastData, "CopiedContractRateFcastData");
            Assert.True(bMathced, "ContractRateFcast didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLDollarsFcastData, CopiedCLDollarsFcastData, "CopiedCLDollarsFcastData");
            Assert.True(bMathced, "CLDollarsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSAvgRateData, CopiedQMIRSAvgRateData, "CopiedQMIRSAvgRateData");
            Assert.True(bMathced, "PLUSStdSV_FTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalAvgEE_ClRateFcastData, CopiedAvgEE_ClRateFcastData, "CopiedAvgEE_ClRateFcastData");
            Assert.True(bMathced, "AvgEE_ClRateFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalTotalLaborDollarsFcastData, CopiedTotalLaborDollarsFcastData, "CopiedTotalLaborDollarsFcastData");
            Assert.True(bMathced, "TotalLaborDollarsFcast Data didn't match");
            #endregion

            #region: Summary View Assertions
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedProductiveFTEsData, NewPlanEmployedProductiveFTEsData, "SourcePlanEmployedProductiveFTEsData");
            Assert.True(bMathced, "EmployedProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractLaborPercentData, NewPlanContractLaborPercentData, "NewPlanContractLaborPercentData");
            Assert.True(bMathced, "ContractLaborPercent Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractFTEsData, NewPlanContractFTEsData, "NewPlanContractFTEsData");
            Assert.True(bMathced, "ContractFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotalProductiveFTEsData, NewPlanTotalProductiveFTEsData, "NewPlanTotalProductiveFTEsData");
            Assert.True(bMathced, "ProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanNonProductivePercentData, NewPlanNonProductivePercentData, "NewPlanNonProductivePercentData");
            Assert.True(bMathced, "ProductivePercentData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanNonProductiveFTEsData, NewPlanNonProductiveFTEsData, "NewPlanNonProductiveFTEsData");
            Assert.True(bMathced, "NonProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedPaidFTEsData, NewPlanEmployedPaidFTEsData, "NewPlanEmployedPaidFTEsData");
            Assert.True(bMathced, "EmployedPaidFTEsData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotalFTEsPaidPlusContractData, NewPlanTotalFTEsPaidPlusContractData, "NewPlanTotalFTEsPaidPlusContractData");
            Assert.True(bMathced, "TotalFTEsPaidPlusContractData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotSalAndWagesData, NewPlanTotSalAndWagesData, "NewPlanTotSalAndWagesData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotContractLabor, NewPlanTotContractLabor, "NewPlanTotContractLabor");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotLaborExpense, NewPlanTotLaborExpense, "NewPlanTotLaborExpense");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedLaborRate, NewPlanEmployedLaborRate, "NewPlanEmployedLaborRate");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractLaborRate, NewPlanContractLaborRate, "NewPlanContractLaborRate");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOTPremiumDollars, NewPlanOTPremiumDollars, "NewPlanOTPremiumDollars");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOvertimePercent, NewPlanOvertimePercent, "NewPlanOvertimePercent");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOvertimeFTEsData, NewPlanOvertimeFTEsData, "NewPlanOvertimeFTEsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanAdmissionsData, NewPlanAdmissionsData, "NewPlanAdmissionsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanAdjustedAdmissionsData, NewPlanAdjustedAdmissionsData, "NewPlanAdjustedAdmissionsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanPatientDaysData, NewPlanPatientDaysData, "NewPlanPatientDaysData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanApdData, NewPlanApdData, "NewPlanApdData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanERVisitsData, NewPlanERVisitsData, "NewPlanERVisitsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOutPatientVisitsData, NewPlanOutPatientVisitsData, "NewPlanOutPatientVisitsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEeobData, NewPlanEeobData, "NewPlanEeobData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanMhaaData, NewPlanMhaaData, "NewPlanMhaaData");
            Assert.True(bMathced, "Data didn't match");
            #endregion
        }

        public void CompareSoucelPlanDataToApprovedPlanData(string Year, string Status, string OriginalPlan, string Dept)
        {
            bool bMathced, bSubmitted, bPlanApproved;
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "DepartmentForecastPlanFilter wasn't visible");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus(Status)
                .withPlan(OriginalPlan)
                .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();

            var OriginalFacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var OriginalDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var OriginalHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var OriginalQMIRSStat6100Data = ForecastView_Volume.QMIRS_Stat6100.getQMIRSStat6100Data();
            var OriginalPLUSVolumeData = ForecastView_Volume.PLUSVolume.getPLUSVolumeData();
            var OriginalHostBudgetData = ForecastView_Volume.HostBudget.getHostBudgetData();
            var OriginalVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var OriginalVolumefcastStat6150Data = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
            var OriginalVolumefcastStat6160Data = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
            var OriginalVolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();


            var OriginalProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            var OriginalFcastProdHrsUOSData = ForecastView_Standards.FcastProdHrsUOS.getFcastProdHrsUOSData();
            var OriginalPLUSStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            var OriginalQMIRSProdHrsUOSData = ForecastView_Standards.QMIRSProdHrsUOS.getQMIRSProdHrsUOSData();
            //one extra for B dept

            //Prod Hrs And FTEs
            var OriginalFcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var OriginalFcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            var OriginalQMIRSTotalProdFTEsData = ForecastView_ProdHrsAndFTEs.QMIRSTotalProdFTEs.getQMIRSTotalProdFTEsData();
            var OriginalFcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();

            //Contract %
            var OriginalQMIRSData = ForecastView_ContractPercent.QMIRS.getQMIRSData();
            var OriginalCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var OriginalCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
            var OriginalClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();

            //Non-Productive %
            var OriginalQMIRS_NP_PercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var OriginalPLUSAvgNP_PercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var OriginalNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var OriginalNPHrsFcastData = ForecastView_NonProductivePercent.NPHrsFcast.getNPHrsFcastData();

            //Paid Hrs and FTEs
            var OriginalFcastTotalPaidHrsDataa = ForecastView_PaidHrsAndFTEs.FcastTotalPaidHrs.getFcastTotalPaidHrsData();
            var OriginalFcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var OriginalFcastTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.FcastTotalPaidFTEs.getFcastTotalPaidFTEsData();
            var OriginalQMIRSTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.QMIRSTotalPaidFTEs.getQMIRSTotalPaidFTEsData();

            //OT %
            var OriginalOTPercentQMIRSData = ForecastView_OTPercent.OTPercentQMIRS.getOTPercentQMIRSData();
            var OriginalOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var OriginalOTHrsFcastData = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
            var OriginalOTFTEsFcastData = ForecastView_OTPercent.OTFTEsFcast.getOTFTEsFcastData();

            //Labor Rates
            var OriginalQMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var OriginalEmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var OriginalEmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var OriginalQMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var OriginalContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var OriginalCLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var OriginalQMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var OriginalAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var OriginalTotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();


            //Summary View
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //Source Plan Facility FTE Summary
            var SourcePlanEmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            var SourcePlanContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            var SourcePlanContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var SourcePlanTotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            var SourcePlanNonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            var SourcePlanNonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            var SourcePlanEmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var SourcePlanTotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();

            //Source PlanFacility Labor Expense Summary
            var SourcePlanTotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            var SourcePlanTotContractLabor = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            var SourcePlanTotLaborExpense = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            var SourcePlanEmployedLaborRate = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            var SourcePlanContractLaborRate = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var SourcePlanOTPremiumDollars = FacilityLaborExpenseSummary.OTPremiumDollars.getOTPremiumDollarsData();
            var SourcePlanOvertimePercent = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var SourcePlanOvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();

            //Source PlanFacility Volume Summary
            var SourcePlanAdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var SourcePlanAdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var SourcePlanPatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var SourcePlanApdData = FacilityVolumeSummary.APD.getAPDData();
            var SourcePlanERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var SourcePlanOutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();
            var SourcePlanEeobData = FacilityVolumeSummary.EEOB.getEEOBData();
            var SourcePlanMhaaData = FacilityVolumeSummary.MHAA.getMHAA_Data();

            ForecastView.GoTo();
            Assert.True(ForecastView.IsAt, "Forecast view page was not displayed.");

            bSubmitted = SubmitForApproval.SubmitPlanForApproval();
            if(bSubmitted)
            {
                Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
                Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                    "User name was not displayed in the submission detail");
            }

            bPlanApproved = DeptForecastButtonPanel.IsPlanApproved();
            if (!bPlanApproved)
            {
                DeptForecastButtonPanel.ApprovePlan();
                Comments.UserComment()
                    .withDescription($"Approving {OriginalPlan}")
                    .Approve();
                Assert.True(DeptForecastButtonPanel.IsPlanApproved(), "Plan was not approved");
            }
            //DeptForecastButtonPanel.ReleasePlan();
            //Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
            //    $"{OriginalPlan} was not released correctly.");
            //Assert.True(DeptForecastButtonPanel.IsPlanReleased(), "Plan was not released");
            CommonFunctions.WaitUntilPageIsAcive();
            var deptDetail = DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();
            var approvedPlanID = deptDetail.PlanID;

            var CopiedFacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var CopiedDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var CopiedHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var CopiedQMIRSStat6100Data = ForecastView_Volume.QMIRS_Stat6100.getQMIRSStat6100Data();
            var CopiedPLUSVolumeData = ForecastView_Volume.PLUSVolume.getPLUSVolumeData();
            var CopiedHostBudgetData = ForecastView_Volume.HostBudget.getHostBudgetData();
            var CopiedVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var CopiedVolumefcastStat6150Data = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
            var CopiedVolumefcastStat6160Data = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
            var CopiedVolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();

            var CopiedlProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            var CopiedFcastProdHrsUOSData = ForecastView_Standards.FcastProdHrsUOS.getFcastProdHrsUOSData();
            var CopiedPLUSStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            var CopiedQMIRSProdHrsUOSData = ForecastView_Standards.QMIRSProdHrsUOS.getQMIRSProdHrsUOSData();
            //one extra for B dept

            //Prod Hrs And FTEs
            var CopiedFcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var CopiedFcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            var CopiedQMIRSTotalProdFTEsData = ForecastView_ProdHrsAndFTEs.QMIRSTotalProdFTEs.getQMIRSTotalProdFTEsData();
            var CopiedFcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();

            //Contract %
            var CopiedQMIRSData = ForecastView_ContractPercent.QMIRS.getQMIRSData();
            var CopiedCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var CopiedCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
            var CopiedClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();

            //Non-Productive %
            var CopiedQMIRS_NP_PercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var CopiedPLUSAvgNP_PercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var CopiedNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var CopiedNPHrsFcastData = ForecastView_NonProductivePercent.NPHrsFcast.getNPHrsFcastData();

            //Paid Hrs and FTEs
            var CopiedFcastTotalPaidHrsDataa = ForecastView_PaidHrsAndFTEs.FcastTotalPaidHrs.getFcastTotalPaidHrsData();
            var CopiedFcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var CopiedFcastTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.FcastTotalPaidFTEs.getFcastTotalPaidFTEsData();
            var CopiedQMIRSTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.QMIRSTotalPaidFTEs.getQMIRSTotalPaidFTEsData();

            //OT %
            var CopiedOTPercentQMIRSData = ForecastView_OTPercent.OTPercentQMIRS.getOTPercentQMIRSData();
            var CopiedOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var CopiedOTHrsFcastData = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
            var CopiedOTFTEsFcastData = ForecastView_OTPercent.OTFTEsFcast.getOTFTEsFcastData();

            //Labor Rates
            var CopiedQMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var CopiedEmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var CopiedEmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var CopiedQMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var CopiedContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var CopiedCLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var CopiedQMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var CopiedAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var CopiedTotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();


            //Summary View
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //New Plan Facility FTE Summary
            var NewPlanEmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            var NewPlanContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            var NewPlanContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var NewPlanTotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            var NewPlanNonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            var NewPlanNonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            var NewPlanEmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var NewPlanTotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();

            //New PlanFacility Labor Expense Summary
            var NewPlanTotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            var NewPlanTotContractLabor = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            var NewPlanTotLaborExpense = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            var NewPlanEmployedLaborRate = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            var NewPlanContractLaborRate = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var NewPlanOTPremiumDollars = FacilityLaborExpenseSummary.OTPremiumDollars.getOTPremiumDollarsData();
            var NewPlanOvertimePercent = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var NewPlanOvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();

            //New PlanFacility Volume Summary
            var NewPlanAdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var NewPlanAdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var NewPlanPatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var NewPlanApdData = FacilityVolumeSummary.APD.getAPDData();
            var NewPlanERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var NewPlanOutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();
            var NewPlanEeobData = FacilityVolumeSummary.EEOB.getEEOBData();
            var NewPlanMhaaData = FacilityVolumeSummary.MHAA.getMHAA_Data();

            #region: Forecast View assertions
            //Forecast View
            //Volume
            bMathced = CommonFunctions.CompareDataObjects(OriginalFacilityStatsData, CopiedFacilityStatsData, "OriginalFacilityStatsData");
            Assert.True(bMathced, "Facility Stats Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalDeptFacilityRatioData, CopiedDeptFacilityRatioData, "OriginalDeptFacilityRatioData");
            Assert.True(bMathced, "Dept Facility Ratio Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalHistDeptFacilityRatioData, CopiedHistDeptFacilityRatioData, "OriginalHistDeptFacilityRatioData");
            Assert.True(bMathced, "HistDeptFacilityRatio Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSStat6100Data, CopiedQMIRSStat6100Data, "CopiedQMIRSStat6100Data");
            Assert.True(bMathced, "QMIRSStat6100 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSVolumeData, CopiedPLUSVolumeData, "CopiedPLUSVolumeData");
            Assert.True(bMathced, "PLUSVolume Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalHostBudgetData, CopiedHostBudgetData, "CopiedHostBudgetData");
            Assert.True(bMathced, "HostBudget Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6100Data, CopiedVolumefcastStat6100Data, "CopiedVolumefcastStat6100Data");
            Assert.True(bMathced, "VolumefcastStat6100 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6150Data, CopiedVolumefcastStat6150Data, "CopiedVolumefcastStat6150Data");
            Assert.True(bMathced, "VolumefcastStat6150 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6160Data, CopiedVolumefcastStat6160Data, "CopiedVolumefcastStat6160Data");
            Assert.True(bMathced, "VolumefcastStat616 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumeDailyAverageVolumeData, CopiedVolumeDailyAverageVolumeData, "CopiedVolumeDailyAverageVolumeData");
            Assert.True(bMathced, "VolumeDailyAverageVolume Data didn't match");

            //Standards
            bMathced = CommonFunctions.CompareDataObjects(OriginalProductiveMinFTEsData, CopiedlProductiveMinFTEsData, "CopiedlProductiveMinFTEsData");
            Assert.True(bMathced, "ProductiveMinFTEs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastProdHrsUOSData, CopiedFcastProdHrsUOSData, "CopiedFcastProdHrsUOSData");
            Assert.True(bMathced, "FcastProdHrsUO Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSStdSV_FTEsData, CopiedPLUSStdSV_FTEsData, "CopiedPLUSStdSV_FTEsData");
            Assert.True(bMathced, "PLUSStdSV_FTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSProdHrsUOSData, CopiedQMIRSProdHrsUOSData, "CopiedQMIRSProdHrsUOSData");
            Assert.True(bMathced, "QMIRSProdHrsUOS Data didn't match");

            //Prod Hrs And FTEs
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalProdHrsData, CopiedFcastTotalProdHrsData, "CopiedFcastTotalProdHrsData");
            Assert.True(bMathced, "FcastTotalProdHrs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalProdFtesData, CopiedFcastTotalProdFtesData, "CopiedFcastTotalProdFtesData");
            Assert.True(bMathced, "FcastTotalProdFtes Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSTotalProdFTEsData, CopiedQMIRSTotalProdFTEsData, "CopiedQMIRSTotalProdFTEsData");
            //Assert.True(bMathced, "QMIRSTotalProdFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastEmplProdHrsData, CopiedFcastEmplProdHrsData, "CopiedFcastEmplProdHrsData");
            Assert.True(bMathced, "FcastEmplProdHrs Data didn't match");

            //Contract %
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSData, CopiedQMIRSData, "CopiedQMIRSData");
            Assert.True(bMathced, "QMIRS didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLPercentFcastData, CopiedCLPercentFcastData, "CopiedCLPercentFcastData");
            Assert.True(bMathced, "CLPercentFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLHrsFcastData, CopiedCLHrsFcastData, "CopiedCLHrsFcastData");
            Assert.True(bMathced, "CLHrsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalClFtesFcastData, CopiedClFtesFcastData, "CopiedClFtesFcastData");
            Assert.True(bMathced, "ClFtesFcas Data didn't match");

           // Non - Productive %
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRS_NP_PercentData, CopiedQMIRS_NP_PercentData, "CopiedQMIRS_NP_PercentData");
            Assert.True(bMathced, "QMIRS_NP_Percent didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSAvgNP_PercentData, CopiedPLUSAvgNP_PercentData, "CopiedPLUSAvgNP_PercentData");
            Assert.True(bMathced, "FcastProdHrsUO Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalNPPercentFcastExcludesCLData, CopiedNPPercentFcastExcludesCLData, "OriginalNPPercentFcastExcludesCLData");
            //Assert.True(bMathced, "NPPercentFcastExcludesCL Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalNPHrsFcastData, CopiedNPHrsFcastData, "CopiedNPHrsFcastData");
            //Assert.True(bMathced, "NPHrsFcast Data didn't match");

            //Paid Hrs and FTEs
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalPaidHrsDataa, CopiedFcastTotalPaidHrsDataa, "CopiedFcastTotalPaidHrsDataa");
            //Assert.True(bMathced, "FcastTotalPaidHrs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastEmplPaidHrsData, CopiedFcastEmplPaidHrsData, "CopiedFcastEmplPaidHrsData");
            //Assert.True(bMathced, "FcastEmplPaidHrs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalPaidFTEsData, CopiedFcastTotalPaidFTEsData, "CopiedFcastTotalPaidFTEsData");
            //Assert.True(bMathced, "FcastTotalPaidFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSTotalPaidFTEsData, CopiedQMIRSTotalPaidFTEsData, "CopiedQMIRSTotalPaidFTEsData");
            Assert.True(bMathced, "QMIRSTotalPaidFTEs Data didn't match");

            //OT %
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTPercentQMIRSData, CopiedOTPercentQMIRSData, "CopiedOTPercentQMIRSData");
            Assert.True(bMathced, "OTPercentQMIRS didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTPercentFcastData, CopiedOTPercentFcastData, "CopiedOTPercentFcastData");
            Assert.True(bMathced, "OTPercentFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTHrsFcastData, CopiedOTHrsFcastData, "CopiedOTHrsFcastData");
            Assert.True(bMathced, "OTHrsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTFTEsFcastData, CopiedOTFTEsFcastData, "CopiedOTFTEsFcastData");
            Assert.True(bMathced, "OTFTEsFcast Data didn't match");

            // Rates
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSEmplLbrRateData, CopiedQMIRSEmplLbrRateData, "OriginalQMIRSEmplLbrRateData");
            Assert.True(bMathced, "QMIRSEmplLbrRate didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalEmplLaborRateFcastData, CopiedEmplLaborRateFcastData, "CopiedEmplLaborRateFcastData");
            Assert.True(bMathced, "EmplLaborRateFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalEmplSalariesFcastData, CopiedEmplSalariesFcastData, "CopiedEmplSalariesFcastData");
            Assert.True(bMathced, "EmplSalariesFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSContractRateData, CopiedQMIRSContractRateData, "CopiedQMIRSContractRateData");
            Assert.True(bMathced, "QMIRSContractRate Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalContractRateFcastData, CopiedContractRateFcastData, "CopiedContractRateFcastData");
            Assert.True(bMathced, "ContractRateFcast didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLDollarsFcastData, CopiedCLDollarsFcastData, "CopiedCLDollarsFcastData");
            Assert.True(bMathced, "CLDollarsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSAvgRateData, CopiedQMIRSAvgRateData, "CopiedQMIRSAvgRateData");
            Assert.True(bMathced, "PLUSStdSV_FTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalAvgEE_ClRateFcastData, CopiedAvgEE_ClRateFcastData, "CopiedAvgEE_ClRateFcastData");
            Assert.True(bMathced, "AvgEE_ClRateFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalTotalLaborDollarsFcastData, CopiedTotalLaborDollarsFcastData, "CopiedTotalLaborDollarsFcastData");
            Assert.True(bMathced, "TotalLaborDollarsFcast Data didn't match");
            #endregion

            #region: Summary View Assertions
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedProductiveFTEsData, NewPlanEmployedProductiveFTEsData, "SourcePlanEmployedProductiveFTEsData");
            Assert.True(bMathced, "EmployedProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractLaborPercentData, NewPlanContractLaborPercentData, "NewPlanContractLaborPercentData");
            Assert.True(bMathced, "ContractLaborPercent Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractFTEsData, NewPlanContractFTEsData, "NewPlanContractFTEsData");
            Assert.True(bMathced, "ContractFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotalProductiveFTEsData, NewPlanTotalProductiveFTEsData, "NewPlanTotalProductiveFTEsData");
            Assert.True(bMathced, "ProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanNonProductivePercentData, NewPlanNonProductivePercentData, "NewPlanNonProductivePercentData");
            Assert.True(bMathced, "ProductivePercentData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanNonProductiveFTEsData, NewPlanNonProductiveFTEsData, "NewPlanNonProductiveFTEsData");
            Assert.True(bMathced, "NonProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedPaidFTEsData, NewPlanEmployedPaidFTEsData, "NewPlanEmployedPaidFTEsData");
            Assert.True(bMathced, "EmployedPaidFTEsData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotalFTEsPaidPlusContractData, NewPlanTotalFTEsPaidPlusContractData, "NewPlanTotalFTEsPaidPlusContractData");
            Assert.True(bMathced, "TotalFTEsPaidPlusContractData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotSalAndWagesData, NewPlanTotSalAndWagesData, "NewPlanTotSalAndWagesData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotContractLabor, NewPlanTotContractLabor, "NewPlanTotContractLabor");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotLaborExpense, NewPlanTotLaborExpense, "NewPlanTotLaborExpense");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedLaborRate, NewPlanEmployedLaborRate, "NewPlanEmployedLaborRate");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractLaborRate, NewPlanContractLaborRate, "NewPlanContractLaborRate");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOTPremiumDollars, NewPlanOTPremiumDollars, "NewPlanOTPremiumDollars");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOvertimePercent, NewPlanOvertimePercent, "NewPlanOvertimePercent");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOvertimeFTEsData, NewPlanOvertimeFTEsData, "NewPlanOvertimeFTEsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanAdmissionsData, NewPlanAdmissionsData, "NewPlanAdmissionsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanAdjustedAdmissionsData, NewPlanAdjustedAdmissionsData, "NewPlanAdjustedAdmissionsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanPatientDaysData, NewPlanPatientDaysData, "NewPlanPatientDaysData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanApdData, NewPlanApdData, "NewPlanApdData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanERVisitsData, NewPlanERVisitsData, "NewPlanERVisitsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOutPatientVisitsData, NewPlanOutPatientVisitsData, "NewPlanOutPatientVisitsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEeobData, NewPlanEeobData, "NewPlanEeobData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanMhaaData, NewPlanMhaaData, "NewPlanMhaaData");
            Assert.True(bMathced, "Data didn't match");
            #endregion
        }

        public void CompareApprovedPlanDataToReleasedPlanData(string Year, string Status, string OriginalPlan, string Dept)
        {
            bool bMathced;
            bool bSubmitted, bPlanApproved;
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "DepartmentForecastPlanFilter wasn't visible");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus(Status)
                .withPlan(OriginalPlan)
                .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();

            var OriginalFacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var OriginalDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var OriginalHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var OriginalQMIRSStat6100Data = ForecastView_Volume.QMIRS_Stat6100.getQMIRSStat6100Data();
            var OriginalPLUSVolumeData = ForecastView_Volume.PLUSVolume.getPLUSVolumeData();
            var OriginalHostBudgetData = ForecastView_Volume.HostBudget.getHostBudgetData();
            var OriginalVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var OriginalVolumefcastStat6150Data = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
            var OriginalVolumefcastStat6160Data = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
            var OriginalVolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();


            var OriginalProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            var OriginalFcastProdHrsUOSData = ForecastView_Standards.FcastProdHrsUOS.getFcastProdHrsUOSData();
            var OriginalPLUSStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            var OriginalQMIRSProdHrsUOSData = ForecastView_Standards.QMIRSProdHrsUOS.getQMIRSProdHrsUOSData();
            //one extra for B dept

            //Prod Hrs And FTEs
            var OriginalFcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var OriginalFcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            var OriginalQMIRSTotalProdFTEsData = ForecastView_ProdHrsAndFTEs.QMIRSTotalProdFTEs.getQMIRSTotalProdFTEsData();
            var OriginalFcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();

            //Contract %
            var OriginalQMIRSData = ForecastView_ContractPercent.QMIRS.getQMIRSData();
            var OriginalCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var OriginalCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
            var OriginalClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();

            //Non-Productive %
            var OriginalQMIRS_NP_PercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var OriginalPLUSAvgNP_PercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var OriginalNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var OriginalNPHrsFcastData = ForecastView_NonProductivePercent.NPHrsFcast.getNPHrsFcastData();

            //Paid Hrs and FTEs
            var OriginalFcastTotalPaidHrsDataa = ForecastView_PaidHrsAndFTEs.FcastTotalPaidHrs.getFcastTotalPaidHrsData();
            var OriginalFcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var OriginalFcastTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.FcastTotalPaidFTEs.getFcastTotalPaidFTEsData();
            var OriginalQMIRSTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.QMIRSTotalPaidFTEs.getQMIRSTotalPaidFTEsData();

            //OT %
            var OriginalOTPercentQMIRSData = ForecastView_OTPercent.OTPercentQMIRS.getOTPercentQMIRSData();
            var OriginalOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var OriginalOTHrsFcastData = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
            var OriginalOTFTEsFcastData = ForecastView_OTPercent.OTFTEsFcast.getOTFTEsFcastData();

            //Labor Rates
            var OriginalQMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var OriginalEmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var OriginalEmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var OriginalQMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var OriginalContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var OriginalCLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var OriginalQMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var OriginalAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var OriginalTotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();


            //Summary View
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //Source Plan Facility FTE Summary
            var SourcePlanEmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            var SourcePlanContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            var SourcePlanContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var SourcePlanTotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            var SourcePlanNonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            var SourcePlanNonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            var SourcePlanEmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var SourcePlanTotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();

            //Source PlanFacility Labor Expense Summary
            var SourcePlanTotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            var SourcePlanTotContractLabor = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            var SourcePlanTotLaborExpense = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            var SourcePlanEmployedLaborRate = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            var SourcePlanContractLaborRate = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var SourcePlanOTPremiumDollars = FacilityLaborExpenseSummary.OTPremiumDollars.getOTPremiumDollarsData();
            var SourcePlanOvertimePercent = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var SourcePlanOvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();

            //Source PlanFacility Volume Summary
            var SourcePlanAdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var SourcePlanAdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var SourcePlanPatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var SourcePlanApdData = FacilityVolumeSummary.APD.getAPDData();
            var SourcePlanERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var SourcePlanOutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();
            var SourcePlanEeobData = FacilityVolumeSummary.EEOB.getEEOBData();
            var SourcePlanMhaaData = FacilityVolumeSummary.MHAA.getMHAA_Data();

            ForecastView.GoTo();
            Assert.True(ForecastView.IsAt, "Forecast view page was not displayed.");

            
            bSubmitted = SubmitForApproval.SubmitPlanForApproval();
            if (bSubmitted)
            {
                Assert.True(SubmitForApproval.IsAt, "Plan was not submitted for approval");
                Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                    "User name was not displayed in the submission detail");
            }

            bPlanApproved = DeptForecastButtonPanel.IsPlanApproved();
            if (!bPlanApproved)
            {
                DeptForecastButtonPanel.ApprovePlan();
                Comments.UserComment()
                    .withDescription($"Approving {OriginalPlan}")
                    .Approve();
                Assert.True(DeptForecastButtonPanel.IsPlanApproved(), "Plan was not approved");
            }

            DeptForecastButtonPanel.ReleasePlan();
            Assert.True(DeptForecastButtonPanel.IsPlanReleased(),
                $"{OriginalPlan} was not released correctly.");
            CommonFunctions.WaitUntilPageIsAcive();
            var deptDetail = DeptForecastDepartmentDetails.GetDeptDetails(Dept);
            CommonFunctions.WaitUntilPageIsAcive();
            var approvedPlanID = deptDetail.PlanID;

            var CopiedFacilityStatsData = ForecastView_Volume.FacilityStat.getFacilityStatsData();
            var CopiedDeptFacilityRatioData = ForecastView_Volume.DeptFacilityRatio.getDeptFacilityRatioData();
            var CopiedHistDeptFacilityRatioData = ForecastView_Volume.HistDeptFacilityRatio.getHistDeptFacilityRatioData();
            var CopiedQMIRSStat6100Data = ForecastView_Volume.QMIRS_Stat6100.getQMIRSStat6100Data();
            var CopiedPLUSVolumeData = ForecastView_Volume.PLUSVolume.getPLUSVolumeData();
            var CopiedHostBudgetData = ForecastView_Volume.HostBudget.getHostBudgetData();
            var CopiedVolumefcastStat6100Data = ForecastView_Volume.VolumefcastStat6100.getVolumefcastStat6100Data();
            var CopiedVolumefcastStat6150Data = ForecastView_Volume.VolumefcastStat6150.getVolumefcastStat6150Data();
            var CopiedVolumefcastStat6160Data = ForecastView_Volume.VolumefcastStat6160.getVolumefcastStat6160Data();
            var CopiedVolumeDailyAverageVolumeData = ForecastView_Volume.VolumeDailyAverageVolume.getVolumeDailyAverageVolumeData();

            var CopiedlProductiveMinFTEsData = ForecastView_Standards.ProductiveMinFTEs.getProductiveMinFTEsData();
            var CopiedFcastProdHrsUOSData = ForecastView_Standards.FcastProdHrsUOS.getFcastProdHrsUOSData();
            var CopiedPLUSStdSV_FTEsData = ForecastView_Standards.PLUSStdSV_FTEs.getPLUSStdSV_FTEsData();
            var CopiedQMIRSProdHrsUOSData = ForecastView_Standards.QMIRSProdHrsUOS.getQMIRSProdHrsUOSData();
            //one extra for B dept

            //Prod Hrs And FTEs
            var CopiedFcastTotalProdHrsData = ForecastView_ProdHrsAndFTEs.FcastTotalProdHrs.getFcastTotalProdHrsData();
            var CopiedFcastTotalProdFtesData = ForecastView_ProdHrsAndFTEs.FcastTotalProdFtes.getFcastTotalProdFtesData();
            var CopiedQMIRSTotalProdFTEsData = ForecastView_ProdHrsAndFTEs.QMIRSTotalProdFTEs.getQMIRSTotalProdFTEsData();
            var CopiedFcastEmplProdHrsData = ForecastView_ProdHrsAndFTEs.FcastEmplProdHrs.getFcastEmplProdHrsData();

            //Contract %
            var CopiedQMIRSData = ForecastView_ContractPercent.QMIRS.getQMIRSData();
            var CopiedCLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
            var CopiedCLHrsFcastData = ForecastView_ContractPercent.CLHrsFcast.getCLHrsFcastData();
            var CopiedClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();

            //Non-Productive %
            var CopiedQMIRS_NP_PercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var CopiedPLUSAvgNP_PercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
            var CopiedNPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            var CopiedNPHrsFcastData = ForecastView_NonProductivePercent.NPHrsFcast.getNPHrsFcastData();

            //Paid Hrs and FTEs
            var CopiedFcastTotalPaidHrsDataa = ForecastView_PaidHrsAndFTEs.FcastTotalPaidHrs.getFcastTotalPaidHrsData();
            var CopiedFcastEmplPaidHrsData = ForecastView_PaidHrsAndFTEs.FcastEmplPaidHrs.getFcastEmplPaidHrsData();
            var CopiedFcastTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.FcastTotalPaidFTEs.getFcastTotalPaidFTEsData();
            var CopiedQMIRSTotalPaidFTEsData = ForecastView_PaidHrsAndFTEs.QMIRSTotalPaidFTEs.getQMIRSTotalPaidFTEsData();

            //OT %
            var CopiedOTPercentQMIRSData = ForecastView_OTPercent.OTPercentQMIRS.getOTPercentQMIRSData();
            var CopiedOTPercentFcastData = ForecastView_OTPercent.OTPercentFcast.getOTPercentFcastData();
            var CopiedOTHrsFcastData = ForecastView_OTPercent.OTHrsFcast.getOTHrsFcastData();
            var CopiedOTFTEsFcastData = ForecastView_OTPercent.OTFTEsFcast.getOTFTEsFcastData();

            //Labor Rates
            var CopiedQMIRSEmplLbrRateData = ForecastView_LaborRates.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var CopiedEmplLaborRateFcastData = ForecastView_LaborRates.EmplLaborRateFcast.getEmplLaborRateFcastData();
            var CopiedEmplSalariesFcastData = ForecastView_LaborRates.EmplSalariesFcast.getEmplSalariesFcastData();
            var CopiedQMIRSContractRateData = ForecastView_LaborRates.QMIRSContractRate.getQMIRSContractRateData();
            var CopiedContractRateFcastData = ForecastView_LaborRates.ContractRateFcast.getContractRateFcastData();
            var CopiedCLDollarsFcastData = ForecastView_LaborRates.CLDollarsFcast.getCLDollarsFcastData();
            var CopiedQMIRSAvgRateData = ForecastView_LaborRates.QMIRSAvgRate.getQMIRSAvgRateData();
            var CopiedAvgEE_ClRateFcastData = ForecastView_LaborRates.AvgEE_ClRateFcast.getAvgEE_ClRateFcastData();
            var CopiedTotalLaborDollarsFcastData = ForecastView_LaborRates.TotalLaborDollarsFcast.getTotalLaborDollarsFcastData();


            //Summary View
            SummaryView.GoTo();
            Assert.True(SummaryView.IsAt, "Summary view page was not displayed");

            //New Plan Facility FTE Summary
            var NewPlanEmployedProductiveFTEsData = FacilityFTESummary.EmployedProductiveFTEs.getEmployedProductiveFTEsData();
            var NewPlanContractLaborPercentData = FacilityFTESummary.ContractLaborPercent.getContractLaborPercentData();
            var NewPlanContractFTEsData = FacilityFTESummary.ContractFTEs.getContractFTEsData();
            var NewPlanTotalProductiveFTEsData = FacilityFTESummary.TotalProductiveFTEs.getTotalProductiveFTEsData();
            var NewPlanNonProductivePercentData = FacilityFTESummary.NonProductivePercent.getNonProductivePercentData();
            var NewPlanNonProductiveFTEsData = FacilityFTESummary.NonProductiveFTEs.getNonProductiveFTEsData();
            var NewPlanEmployedPaidFTEsData = FacilityFTESummary.EmployedPaidFTEs.getEmployedPaidFTEsData();
            var NewPlanTotalFTEsPaidPlusContractData = FacilityFTESummary.TotalFTEsPaidPlusContract.getTotalFTEsPaidPlusContractData();

            //New PlanFacility Labor Expense Summary
            var NewPlanTotSalAndWagesData = FacilityLaborExpenseSummary.TotSalAndWages.getTotSalAndWagesData();
            var NewPlanTotContractLabor = FacilityLaborExpenseSummary.TotContractLabor.getTotContractLaborData();
            var NewPlanTotLaborExpense = FacilityLaborExpenseSummary.TotLaborExpense.getTotLaborExpenseData();
            var NewPlanEmployedLaborRate = FacilityLaborExpenseSummary.EmployedLaborRate.getEmployedLaborRateData();
            var NewPlanContractLaborRate = FacilityLaborExpenseSummary.ContractLaborRate.getContractLaborRateData();
            var NewPlanOTPremiumDollars = FacilityLaborExpenseSummary.OTPremiumDollars.getOTPremiumDollarsData();
            var NewPlanOvertimePercent = FacilityLaborExpenseSummary.OvertimePercent.getOvertimePercentData();
            var NewPlanOvertimeFTEsData = FacilityLaborExpenseSummary.OvertimeFTEs.getOvertimeFTEsData();

            //New PlanFacility Volume Summary
            var NewPlanAdmissionsData = FacilityVolumeSummary.Admissions.getAdmissionsData();
            var NewPlanAdjustedAdmissionsData = FacilityVolumeSummary.AdjustedAdmissions.getAdjustedAdmissionsData();
            var NewPlanPatientDaysData = FacilityVolumeSummary.PatientDays.getPatientDaysData();
            var NewPlanApdData = FacilityVolumeSummary.APD.getAPDData();
            var NewPlanERVisitsData = FacilityVolumeSummary.ERVisits.getERVisitsData();
            var NewPlanOutPatientVisitsData = FacilityVolumeSummary.OutPatientVisits.getOutPatientVisitsData();
            var NewPlanEeobData = FacilityVolumeSummary.EEOB.getEEOBData();
            var NewPlanMhaaData = FacilityVolumeSummary.MHAA.getMHAA_Data();

            #region: Forecast View assertions
            //Forecast View
            //Volume
            bMathced = CommonFunctions.CompareDataObjects(OriginalFacilityStatsData, CopiedFacilityStatsData, "OriginalFacilityStatsData");
            Assert.True(bMathced, "Facility Stats Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalDeptFacilityRatioData, CopiedDeptFacilityRatioData, "OriginalDeptFacilityRatioData");
            Assert.True(bMathced, "Dept Facility Ratio Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalHistDeptFacilityRatioData, CopiedHistDeptFacilityRatioData, "OriginalHistDeptFacilityRatioData");
            Assert.True(bMathced, "HistDeptFacilityRatio Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSStat6100Data, CopiedQMIRSStat6100Data, "CopiedQMIRSStat6100Data");
            Assert.True(bMathced, "QMIRSStat6100 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSVolumeData, CopiedPLUSVolumeData, "CopiedPLUSVolumeData");
            Assert.True(bMathced, "PLUSVolume Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalHostBudgetData, CopiedHostBudgetData, "CopiedHostBudgetData");
            Assert.True(bMathced, "HostBudget Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6100Data, CopiedVolumefcastStat6100Data, "CopiedVolumefcastStat6100Data");
            Assert.True(bMathced, "VolumefcastStat6100 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6150Data, CopiedVolumefcastStat6150Data, "CopiedVolumefcastStat6150Data");
            Assert.True(bMathced, "VolumefcastStat6150 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumefcastStat6160Data, CopiedVolumefcastStat6160Data, "CopiedVolumefcastStat6160Data");
            Assert.True(bMathced, "VolumefcastStat616 Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalVolumeDailyAverageVolumeData, CopiedVolumeDailyAverageVolumeData, "CopiedVolumeDailyAverageVolumeData");
            Assert.True(bMathced, "VolumeDailyAverageVolume Data didn't match");

            //Standards
            bMathced = CommonFunctions.CompareDataObjects(OriginalProductiveMinFTEsData, CopiedlProductiveMinFTEsData, "CopiedlProductiveMinFTEsData");
            Assert.True(bMathced, "ProductiveMinFTEs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastProdHrsUOSData, CopiedFcastProdHrsUOSData, "CopiedFcastProdHrsUOSData");
            Assert.True(bMathced, "FcastProdHrsUO Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSStdSV_FTEsData, CopiedPLUSStdSV_FTEsData, "CopiedPLUSStdSV_FTEsData");
            Assert.True(bMathced, "PLUSStdSV_FTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSProdHrsUOSData, CopiedQMIRSProdHrsUOSData, "CopiedQMIRSProdHrsUOSData");
            Assert.True(bMathced, "QMIRSProdHrsUOS Data didn't match");

            //Prod Hrs And FTEs
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalProdHrsData, CopiedFcastTotalProdHrsData, "CopiedFcastTotalProdHrsData");
            Assert.True(bMathced, "FcastTotalProdHrs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalProdFtesData, CopiedFcastTotalProdFtesData, "CopiedFcastTotalProdFtesData");
            Assert.True(bMathced, "FcastTotalProdFtes Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSTotalProdFTEsData, CopiedQMIRSTotalProdFTEsData, "CopiedQMIRSTotalProdFTEsData");
            //Assert.True(bMathced, "QMIRSTotalProdFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastEmplProdHrsData, CopiedFcastEmplProdHrsData, "CopiedFcastEmplProdHrsData");
            Assert.True(bMathced, "FcastEmplProdHrs Data didn't match");

            //Contract %
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSData, CopiedQMIRSData, "CopiedQMIRSData");
            Assert.True(bMathced, "QMIRS didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLPercentFcastData, CopiedCLPercentFcastData, "CopiedCLPercentFcastData");
            Assert.True(bMathced, "CLPercentFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLHrsFcastData, CopiedCLHrsFcastData, "CopiedCLHrsFcastData");
            Assert.True(bMathced, "CLHrsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalClFtesFcastData, CopiedClFtesFcastData, "CopiedClFtesFcastData");
            Assert.True(bMathced, "ClFtesFcas Data didn't match");

            // Non - Productive %
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRS_NP_PercentData, CopiedQMIRS_NP_PercentData, "CopiedQMIRS_NP_PercentData");
            Assert.True(bMathced, "QMIRS_NP_Percent didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalPLUSAvgNP_PercentData, CopiedPLUSAvgNP_PercentData, "CopiedPLUSAvgNP_PercentData");
            Assert.True(bMathced, "FcastProdHrsUO Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalNPPercentFcastExcludesCLData, CopiedNPPercentFcastExcludesCLData, "OriginalNPPercentFcastExcludesCLData");
            //Assert.True(bMathced, "NPPercentFcastExcludesCL Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalNPHrsFcastData, CopiedNPHrsFcastData, "CopiedNPHrsFcastData");
            //Assert.True(bMathced, "NPHrsFcast Data didn't match");

            //Paid Hrs and FTEs
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalPaidHrsDataa, CopiedFcastTotalPaidHrsDataa, "CopiedFcastTotalPaidHrsDataa");
            //Assert.True(bMathced, "FcastTotalPaidHrs didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastEmplPaidHrsData, CopiedFcastEmplPaidHrsData, "CopiedFcastEmplPaidHrsData");
            //Assert.True(bMathced, "FcastEmplPaidHrs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalFcastTotalPaidFTEsData, CopiedFcastTotalPaidFTEsData, "CopiedFcastTotalPaidFTEsData");
            //Assert.True(bMathced, "FcastTotalPaidFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSTotalPaidFTEsData, CopiedQMIRSTotalPaidFTEsData, "CopiedQMIRSTotalPaidFTEsData");
            Assert.True(bMathced, "QMIRSTotalPaidFTEs Data didn't match");

            //OT %
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTPercentQMIRSData, CopiedOTPercentQMIRSData, "CopiedOTPercentQMIRSData");
            Assert.True(bMathced, "OTPercentQMIRS didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTPercentFcastData, CopiedOTPercentFcastData, "CopiedOTPercentFcastData");
            Assert.True(bMathced, "OTPercentFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTHrsFcastData, CopiedOTHrsFcastData, "CopiedOTHrsFcastData");
            Assert.True(bMathced, "OTHrsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalOTFTEsFcastData, CopiedOTFTEsFcastData, "CopiedOTFTEsFcastData");
            Assert.True(bMathced, "OTFTEsFcast Data didn't match");

            // Rates
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSEmplLbrRateData, CopiedQMIRSEmplLbrRateData, "OriginalQMIRSEmplLbrRateData");
            Assert.True(bMathced, "QMIRSEmplLbrRate didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalEmplLaborRateFcastData, CopiedEmplLaborRateFcastData, "CopiedEmplLaborRateFcastData");
            Assert.True(bMathced, "EmplLaborRateFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalEmplSalariesFcastData, CopiedEmplSalariesFcastData, "CopiedEmplSalariesFcastData");
            Assert.True(bMathced, "EmplSalariesFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSContractRateData, CopiedQMIRSContractRateData, "CopiedQMIRSContractRateData");
            Assert.True(bMathced, "QMIRSContractRate Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalContractRateFcastData, CopiedContractRateFcastData, "CopiedContractRateFcastData");
            Assert.True(bMathced, "ContractRateFcast didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalCLDollarsFcastData, CopiedCLDollarsFcastData, "CopiedCLDollarsFcastData");
            Assert.True(bMathced, "CLDollarsFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalQMIRSAvgRateData, CopiedQMIRSAvgRateData, "CopiedQMIRSAvgRateData");
            Assert.True(bMathced, "PLUSStdSV_FTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalAvgEE_ClRateFcastData, CopiedAvgEE_ClRateFcastData, "CopiedAvgEE_ClRateFcastData");
            Assert.True(bMathced, "AvgEE_ClRateFcast Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(OriginalTotalLaborDollarsFcastData, CopiedTotalLaborDollarsFcastData, "CopiedTotalLaborDollarsFcastData");
            Assert.True(bMathced, "TotalLaborDollarsFcast Data didn't match");
            #endregion

            #region: Summary View Assertions
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedProductiveFTEsData, NewPlanEmployedProductiveFTEsData, "SourcePlanEmployedProductiveFTEsData");
            Assert.True(bMathced, "EmployedProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractLaborPercentData, NewPlanContractLaborPercentData, "NewPlanContractLaborPercentData");
            Assert.True(bMathced, "ContractLaborPercent Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractFTEsData, NewPlanContractFTEsData, "NewPlanContractFTEsData");
            Assert.True(bMathced, "ContractFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotalProductiveFTEsData, NewPlanTotalProductiveFTEsData, "NewPlanTotalProductiveFTEsData");
            Assert.True(bMathced, "ProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanNonProductivePercentData, NewPlanNonProductivePercentData, "NewPlanNonProductivePercentData");
            Assert.True(bMathced, "ProductivePercentData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanNonProductiveFTEsData, NewPlanNonProductiveFTEsData, "NewPlanNonProductiveFTEsData");
            Assert.True(bMathced, "NonProductiveFTEs Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedPaidFTEsData, NewPlanEmployedPaidFTEsData, "NewPlanEmployedPaidFTEsData");
            Assert.True(bMathced, "EmployedPaidFTEsData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotalFTEsPaidPlusContractData, NewPlanTotalFTEsPaidPlusContractData, "NewPlanTotalFTEsPaidPlusContractData");
            Assert.True(bMathced, "TotalFTEsPaidPlusContractData didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotSalAndWagesData, NewPlanTotSalAndWagesData, "NewPlanTotSalAndWagesData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotContractLabor, NewPlanTotContractLabor, "NewPlanTotContractLabor");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanTotLaborExpense, NewPlanTotLaborExpense, "NewPlanTotLaborExpense");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEmployedLaborRate, NewPlanEmployedLaborRate, "NewPlanEmployedLaborRate");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanContractLaborRate, NewPlanContractLaborRate, "NewPlanContractLaborRate");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOTPremiumDollars, NewPlanOTPremiumDollars, "NewPlanOTPremiumDollars");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOvertimePercent, NewPlanOvertimePercent, "NewPlanOvertimePercent");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOvertimeFTEsData, NewPlanOvertimeFTEsData, "NewPlanOvertimeFTEsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanAdmissionsData, NewPlanAdmissionsData, "NewPlanAdmissionsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanAdjustedAdmissionsData, NewPlanAdjustedAdmissionsData, "NewPlanAdjustedAdmissionsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanPatientDaysData, NewPlanPatientDaysData, "NewPlanPatientDaysData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanApdData, NewPlanApdData, "NewPlanApdData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanERVisitsData, NewPlanERVisitsData, "NewPlanERVisitsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanOutPatientVisitsData, NewPlanOutPatientVisitsData, "NewPlanOutPatientVisitsData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanEeobData, NewPlanEeobData, "NewPlanEeobData");
            Assert.True(bMathced, "Data didn't match");
            bMathced = CommonFunctions.CompareDataObjects(SourcePlanMhaaData, NewPlanMhaaData, "NewPlanMhaaData");
            Assert.True(bMathced, "Data didn't match");
            #endregion
        }


        [Test]
        [Category("WftCopyPlan")]
        public void VerifyLOBforPlus()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of WFT - LOB filter";

            By byLOB = By.XPath("//select[@id='lobSelectionList']");
            string byFac = "//select[@id='facilitySelectionList']";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToPLUS();
            //string query = $"SELECT o.LOB, o.Description, s.Coid, s.FacilityName   FROM [ISAS_Security].[dbo].[Facility] s  join [dbo].[Facility_LOB_Order] o  on  s.LOB_ID = o.LOB_ID  where  o.LOB_ID = {lobID}";
            verifyLOB(byLOB, byFac);
        }        

        private void verifyLOB(By byLOB, string byFac)
        {
            bool bContained;
            var lstLOB = Division.getLineOfBusiness();
            int lobID;
            foreach (var LOB in lstLOB)
            {
                var mLob = CommonFunctions.getElement(byLOB);
                CommonFunctions.SelectItemFromDropdownMenu(mLob, LOB);
                CommonFunctions.WaitUntilPageIsAcive();
                lobID = Division.getLobID(LOB);
                // Retrun coid from DB
                var lstDbCoid = Division.getFacilityCOIDs(lobID.ToString());
                Thread.Sleep(5000);
                // return coids from UI
                var lstCOIDs = CommonFunctions.getCOIDsFromUI(byFac);
                var lstMissingItems = lstCOIDs.Where(item => !lstDbCoid.Contains(item)).ToList();
                bContained = lstMissingItems.Count == 0 ? true : false;
                Console.WriteLine($"{LOB}\n" +
                    $"{lstMissingItems.Count.ToString()}\n" +
                    $"{string.Join(", ", lstMissingItems)}\n");
            }
        }

        //[Test] [Category("WftCopyPlan")]
        public void UserCanCopyApprovedPlan()
        {
            UserCanApprovePlan();
            DeptForecastButtonPanel.GoToAdmin();
            bool bBothObjMatched, bCopiedAndNewPlansMatched;
            string CopiedPlanDescription, PlanDescription, SemiVariableDept;
            string Year = CommonFunctions.GetNextYear();
            PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            SemiVariableDept = SettingData.CopyingDept;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
           // homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
           // Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Approved")
                .withPlan(string.Empty)
                .Select();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");

            // Get fac stat mapping data for dept
            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingDataForNonWorkingPlan(SemiVariableDept);
            // copy the plan
            CopyPlan.GoTo();
            CopiedPlanDescription = $"Copied_{PlanDescription}";
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");
            var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingDataForNonWorkingPlan(SemiVariableDept);
            //bool bMatched = CommonFunctions.CompareFacilityStatsMappingObjects(CopiedPlanFacilityStatsMapping, NewPlanFacilityStatsMapping);
            //Assert.True(bMatched, "Copied plan did not work!");

            // verify both copied and new plan are matched
            bCopiedAndNewPlansMatched = string.Equals(NewPlanFacilityStatsMapping.NPPercent,
                CopiedPlanFacilityStatsMapping.NPPercent, StringComparison.OrdinalIgnoreCase);
            Assert.True(bCopiedAndNewPlansMatched, $"Copied and new plan are different.\n" +
                $"new plan: {NewPlanFacilityStatsMapping.NPPercent}\n" +
                $"Copied plan: {CopiedPlanFacilityStatsMapping.NPPercent}");
            bBothObjMatched = NewPlanFacilityStatsMapping.FreezeCLPercent == CopiedPlanFacilityStatsMapping.FreezeCLPercent;
            Assert.True(bBothObjMatched, "NewPlanFacilityStatsMapping and CopiedPlanFacilityStatsMapping are not the same");
        }
        
        public void UserCanApprovePlan()
        {
            string Year = CommonFunctions.GetNextYear();
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Approving {PlanDescription}")
                .Approve();
            
        }

        //[Test] [Category("WftCopyPlan")]
        public void UserCanCopyApprovedHistoricalPlan()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Copy Functionality";
            bool bBothObjMatched, bCopiedAndNewPlansMatched;
            string CopiedPlanDescription, PlanDescription, Dept;
            string Year = CommonFunctions.GetNextYear();
            Dept = "630";
            PlanDescription = "Lake Monroe V8";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFTFacilty.GoTo();
            Assert.True(WFTFacilty.IsAt, "Facility page was not displayed.");
            WFTFacilty.SetFacility()
                .withNumberOfRequiredApprovers("1 - One")
                .withNewPlanNonProductivePercent("Use Most Recent Approved & Released Plan")
                .withNewPlanStatisticMapping("Use Most Recent Approved & Released Plan")
                .withNewPlanVclPercentOrFixedFtes("Use Percent")
                .withCopyingPlanNonProductivePercent("Use Copied Plan")
                .withCopyingPlanStatisticMapping("Use Copied Plan")
                .withCopyingPlanEE_AHR_Months("Use Copied Plan")
                .withCopyingPlanCL_AHR_Months("Use Copied Plan")
                .withCopyingPlanCLPercentOrFixedFtes("Use Copied Plan")
                .withNewDeptartment(false) // if true, dept will be added. 
                .withNumber("601")
                .withDescription("text")
                .withDepartmentType("Semi-Variable")
                .withDefaultFacilityStat("BIRTHS - 5815")
                .withDepartmentStat("text")
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Approved Historical")
                .withPlan(string.Empty)
                .Select();

            //// Get fac stat mapping data for dept
            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingDataForNonWorkingPlan(Dept);
            By byPlanDescription = By.XPath("//*/input[@id='selectedPlanDescription']");


            // copy the plan
            CopyPlan.GoTo();
            CopiedPlanDescription = $"NewPlan{PlanDescription.Replace(" ", "")}_{CommonFunctions.GenerateRandonNumber()}";
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");
            var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(Dept); ;

            // verify both copied and new plan are matched
            bCopiedAndNewPlansMatched = NewPlanFacilityStatsMapping.NPPercent.Contains(CopiedPlanFacilityStatsMapping.NPPercent);
            Assert.True(bCopiedAndNewPlansMatched, $"Copied and new plan are different.\n" +
                $"new plan: {NewPlanFacilityStatsMapping.NPPercent}\n" +
                $"Copied plan: {CopiedPlanFacilityStatsMapping.NPPercent}");
            bBothObjMatched = NewPlanFacilityStatsMapping.FreezeCLPercent == CopiedPlanFacilityStatsMapping.FreezeCLPercent;
            Assert.True(bBothObjMatched, "NewPlanFacilityStatsMapping and CopiedPlanFacilityStatsMapping are not the same");
            CompareOriginalPlanDataToCopiedPlanData(Year, "All", PlanDescription, CopiedPlanDescription, Dept);
        }

        //[Test]
        [Category("WftCopyPlan")]
        public void VerifyCopyPlanJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Copy Functionality";
            UserCanCopyApprovedAndReleasedPlan();
            UserCanCopyApprovedHistoricalPlan();
            UserCanCopyPlan();
            UserCanCopyPlanWithChangesMadeToFacilityStatsMappingPage();
            //UserCanCopyWorkingRejectedPlan();
        }

        //[Test] 
        //[Category("WftCopyPlan")]
        public void UserCanCopyApprovedAndReleasedPlan()
        {
            AdministrationNewPlanTests administrationNewPlanTests = new AdministrationNewPlanTests();
            administrationNewPlanTests.UserCanApproveAndReleasePlan();
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Copy Functionality";
            bool bBothObjMatched, bCopiedAndNewPlansMatched;
            string CopiedPlanDescription, PlanDescription, SemiVariableDept;
            string Year = CommonFunctions.GetNextYear();
            PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";            
            SemiVariableDept = SettingData.CopyingDept;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Released")
                .withPlan(string.Empty)
                .Select();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");

            // Get fac stat mapping data for dept
            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingDataForNonWorkingPlan(SemiVariableDept);
            // copy the plan
            CopyPlan.GoTo();
            CopiedPlanDescription = $"Copied_{PlanDescription}";
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");
            var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept);

            // verify both copied and new plan are matched
            bCopiedAndNewPlansMatched = NewPlanFacilityStatsMapping.NPPercent.Contains(CopiedPlanFacilityStatsMapping.NPPercent);
            //bCopiedAndNewPlansMatched = string.Equals(NewPlanFacilityStatsMapping.NPPercent,
            //    CopiedPlanFacilityStatsMapping.NPPercent, StringComparison.CurrentCultureIgnoreCase);
            Assert.True(bCopiedAndNewPlansMatched, $"Copied and new plan are different.\n" +
                $"new plan: {NewPlanFacilityStatsMapping.NPPercent}\n" +
                $"Copied plan: {CopiedPlanFacilityStatsMapping.NPPercent}");
            bBothObjMatched = NewPlanFacilityStatsMapping.FreezeCLPercent == CopiedPlanFacilityStatsMapping.FreezeCLPercent;
            Assert.True(bBothObjMatched, "NewPlanFacilityStatsMapping and CopiedPlanFacilityStatsMapping are not the same");
        }

        [Test] [Category("WftCopyPlan")]
        public void UserCanCopyPlanWithChangesMadeToFacilityStatsMappingPage()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify Copy Functionality";
            bool bBothObjMatched, bCopiedAndNewPlansMatched, isMatched;
            string CopiedPlanDescription, PlanDescription, SemiVariableDept;
            string Year = CommonFunctions.GetNextYear();
            PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            Console.WriteLine($"PlanDescription: {PlanDescription}");
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();

            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("1.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse(string.Empty)
                    .withStatisticMapping(string.Empty)
                    .withForCLPercentOrFixedFtesUse(string.Empty)
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(false) // no data update.
                    .Create();
            CommonFunctions.WaitUntilPageIsAcive();
            SemiVariableDept = SettingData.CopyingDept;
            
            //FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            FacilityStatsMapping.ModifyFacilityStatsMapping(SemiVariableDept)
                .withIgnoredInWFT(false)
                .withFacilityStat(string.Empty)
                .withCLPercentOrFTE("%")
                .withNPPercent("NP-7%")
                .withFreezeRatioVol(false)
                .withFreezeStdTgt(true)
                .withFreezeSVStepSel(true)
                .withFreezeCLPercent(true)
                .withFreezeNPPercent(false)
                .withFreezeOTPercent(true)
                .Save();
            AdminMenu.GoToForecast();
            var deptDetails = DeptForecastDepartmentDetails.GetDeptDetails(SemiVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();
            ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.ModifyNPPercentFcastExcludesCLData("7.50");
            DeptForecastButtonPanel.clickSaveAndRecalc();
            DeptForecastButtonPanel.GoToAdmin();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats Mapping page is not displayed.");
            // Get fac stat mapping data for dept
            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept);
            // copy the plan
            CopyPlan.GoTo();
            CopiedPlanDescription = $"Copied{PlanDescription}";
            Console.WriteLine($"CopiedPlanDescription: {CopiedPlanDescription}");
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");
            Thread.Sleep(5000);
            var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData(SemiVariableDept); ;

            // verify both copied and new plan are matched
            bCopiedAndNewPlansMatched = string.Equals(NewPlanFacilityStatsMapping.NPPercent,
                CopiedPlanFacilityStatsMapping.NPPercent, StringComparison.OrdinalIgnoreCase);
            Assert.True(bCopiedAndNewPlansMatched, $"Copied and new plan are different.\n" +
                $"new plan: {NewPlanFacilityStatsMapping.NPPercent}\n" +
                $"Copied plan: {CopiedPlanFacilityStatsMapping.NPPercent}");
            bBothObjMatched = JsonConvert.SerializeObject(NewPlanFacilityStatsMapping) == JsonConvert.SerializeObject(CopiedPlanFacilityStatsMapping);
            Assert.True(bBothObjMatched, "NewPlanFacilityStatsMapping and CopiedPlanFacilityStatsMapping are not the same");

            DeptForecastButtonPanel.GoToAdmin();
            Assert.True(FacilityStatsMapping.IsAt, "Facility stat mapping page wasn't displayed.");
            //Verify facililty stat mapping filters
            FacilityStatsMapping.Filters()
                .withDept("OR")
                .withIgnoredInPlus("ALL")
                .withIgnoredInWFT("ALL")
                .withPLUSDeptType("ALL")
                .withWFTDeptType("ALL")
                .withDepartmentStat("ALL")
                .withFacilityStat("ALL")
                .withCLPercentOrFTE("ALL")
                .withNPPercent("ALL")
                .withFreezeVolumes("Y")
                .withFreezeMinHours("ALL")
                .withFreezeStdTgt("ALL")
                .withFreezeSVStepSel("ALL")
                .withFreezeCLPercent("ALL")
                .withFreezeNPPercent("ALL")
                .withFreezeOTPercent("ALL")
                .Set();
            var lstDepts = FacilityStatsMapping.GetFacilityStatsMappingVisibleRowsForWorkingPlans();
            Console.WriteLine(lstDepts.Count.ToString());
            var bAllFreezeVolumeSelected = lstDepts.All(x => x.FreezeRatioVol);
            Assert.True(bAllFreezeVolumeSelected, "Some of Freeze volume items were unchecked and included in the 'Y' filter");
        }

        //[Test] [Category("WftCopyPlan")]
        public void UserCanUseAdminFacilityToCopyPlanTest()
        {
            bool bDisplayed, bCopiedAndNewPlansMatched, bAvgEmpLbrRateMatched, bContractRate, isMatched;
            string CopiedPlanDescription, PlanDescription;
            string Year = CommonFunctions.GetNextYear();
            PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            //mainly using system default option
            WFTFacilty.GoTo();
            Assert.True(WFTFacilty.IsAt, "Facility page was not displayed.");
            WFTFacilty.SetFacility()
                .withNumberOfRequiredApprovers("1 - One")
                .withNewPlanNonProductivePercent("Use PLUS Avg. NP %")
                .withNewPlanStatisticMapping("Use Most Recent Approved Plan")
                .withNewPlanVclPercentOrFixedFtes("Use Percent")
                .withCopyingPlanNonProductivePercent("Use PLUS Avg. NP %")
                .withCopyingPlanStatisticMapping("Use System Default")
                .withCopyingPlanEE_AHR_Months("Use System Default")
                .withCopyingPlanCL_AHR_Months("Use System Default")
                .withCopyingPlanCLPercentOrFixedFtes("Use Fixed")
                .withNewDeptartment(false) // if true, dept will be added. 
                .withNumber("601")
                .withDescription("text")
                .withDepartmentType("Semi-Variable")
                .withDefaultFacilityStat("BIRTHS - 5815")
                .withDepartmentStat("text")
                .Save();

            WFT_Admin_Plan.NavigateToAdminPlanPage();
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse(string.Empty)
                    .withStatisticMapping(string.Empty)
                    .withForCLPercentOrFixedFtesUse(string.Empty)
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(false) // no data update.
                    .Create();
            CommonFunctions.WaitUntilPageIsAcive();
            Console.WriteLine($"*** New Plan == {PlanDescription}    ****");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");            
            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData();           

            // copy the plan
            CopyPlan.GoTo();
            Assert.True(CopyPlan.IsAt, "Copy plan pop-up was not displayed.");
            CopiedPlanDescription = $"Copied{PlanDescription}";
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            Console.WriteLine($"*** Copied plan: {CopiedPlanDescription}    ****");
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Facility Stats mapping page is not displayed.");           
            var CopiedPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData();

            // verify both copied and new plan are matched
            bCopiedAndNewPlansMatched = string.Equals(NewPlanFacilityStatsMapping[0].NPPercent,
                CopiedPlanFacilityStatsMapping[0].NPPercent, StringComparison.OrdinalIgnoreCase);
            Assert.True(bCopiedAndNewPlansMatched, $"Copied and new plan are different.\n" +
                $"new plan: {NewPlanFacilityStatsMapping[0].NPPercent}\n" +
                $"Copied plan: {CopiedPlanFacilityStatsMapping[0].NPPercent}");

            //Verify Average Labor Rate - Empl
            AverageLaborRateEmpl.GoTo();
            Assert.True(AverageLaborRateEmpl.IsAt, "Average Labor Rate - Empl table was not displayed.");
            //Verify total value equals emp lbr rate.
            var QMIRSEmplLbrRateData = AverageLaborRateEmpl.QMIRSEmplLbrRate.getQMIRSEmplLbrRateData();
            var EmployedLaborRateData = AverageLaborRateEmpl.EmployedLaborRate.getEmployedLaborRateData();
            bAvgEmpLbrRateMatched = QMIRSEmplLbrRateData.Total == EmployedLaborRateData.Jan;
            Assert.True(bAvgEmpLbrRateMatched, $"Values don't match:\n" +
                $"QMIRSEmplLbrRateData.Total = {QMIRSEmplLbrRateData.Total}\n" +
                $"EmployedLaborRateData.Jan = {EmployedLaborRateData.Jan}");

            //Verify Average Labor Rate - CL
            AverageLaborRateCL.GoTo();
            Assert.True(AverageLaborRateCL.IsAt, "Average Labor Rate - CL page was not displayed.");
            var QMIRSContractRateData = AverageLaborRateCL.QMIRSContractRate.getQMIRSContractRateData();
            var ContractRateData = AverageLaborRateCL.ContractRate.getContractRateData();
            bContractRate = QMIRSContractRateData.Total == ContractRateData.Jan;
            Assert.True(bContractRate, $"CL values don't match:\n" +
                $"QMIRSContractRateData.Total = {QMIRSContractRateData.Total}\n" +
                $"ContractRateData.Jan = {ContractRateData.Jan}");
            
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(CopiedPlanDescription)
                .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            bDisplayed = CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 20);
            Assert.True(bDisplayed, "Dept forecast - Facility Stat page is not displayed.");

            //Verify NP %
            switch (CopiedPlanFacilityStatsMapping[0].NPPercent.Trim())
            {
                case "PLUS":
                    Console.WriteLine("PLUS block");
                    var PLUSAvgNPPercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
                    var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    isMatched = PLUSAvgNPPercentData.Jan ==
                        NPPercentFcastExcludesCLData.Jan;
                    Assert.True(isMatched, $"No match:\nPLUSAvgNPPercentData.Jan = {PLUSAvgNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    break;
                case "QMIRS":
                    Console.WriteLine("QMIRS block");
                    var QMIRSNPPercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
                    NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    isMatched = QMIRSNPPercentData.Jan ==
                        NPPercentFcastExcludesCLData.Jan;
                    Assert.True(isMatched, $"No match:\n QMIRSNPPercentData.Jan = {QMIRSNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    break;
                default:
                    Console.WriteLine("Nothing to compare");
                    break;
            }

            //Verify CL % / FTEs
            switch (CopiedPlanFacilityStatsMapping[0].CLPercentOrFTE)
            {
                //FTEs
                case "Fixed":
                    Console.WriteLine("CL FTEs -- Fixed");
                    var ClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();
                    IWebElement JanCLFTEs = CommonFunctions.getElement(By.XPath("//input[@id='txtclFtesFixed-1' and not(@readonly)]"));
                    Assert.IsTrue(JanCLFTEs.Enabled, "CL FTEs row is not enabled");
                    break;

                case "Percent":
                    Console.WriteLine("CL % -- percent");
                    var CLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
                    IWebElement JanCLPercent = CommonFunctions.getElement(By.XPath("//input[@id='clPct-1' and not(@readonly)]"));
                    Assert.IsTrue(JanCLPercent.Enabled, "CL % row is not enabled");
                    break;
            }
        }

       // [Test] [Category("WftCopyPlan")]
        public void VerifyUserCanSelectQMIRSforNonProductivePercentInFacilityPage()
        {
            bool isMatched;
            string Year = CommonFunctions.GetNextYear();
            string PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFTFacilty.GoTo();
            Assert.True(WFTFacilty.IsAt, "Facility page was not displayed.");
            WFTFacilty.SetFacility()
                .withNumberOfRequiredApprovers("1 - One")
                .withNewPlanNonProductivePercent("Use QMIRS NP %")
                .withNewPlanStatisticMapping("Use Most Recent Approved Plan")
                .withNewPlanVclPercentOrFixedFtes("Use Percent")
                .withCopyingPlanNonProductivePercent("Use Copied Plan")
                .withCopyingPlanStatisticMapping("Use Copied Plan")
                .withCopyingPlanEE_AHR_Months("Use Copied Plan")
                .withCopyingPlanCL_AHR_Months("Use Copied Plan")
                .withCopyingPlanCLPercentOrFixedFtes("Use Copied Plan")
                .withNewDeptartment(false) // if true, dept will be added. 
                .withNumber("601")
                .withDescription("text")
                .withDepartmentType("Semi-Variable")
                .withDefaultFacilityStat("BIRTHS - 5815")
                .withDepartmentStat("text")
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse(string.Empty)
                    .withStatisticMapping(string.Empty)
                    .withForCLPercentOrFixedFtesUse(string.Empty)
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(false) // no data update.
                    .Create();

            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(PlanDescription)
                .Select();
            CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 20);
            var QMIRSNPPercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
            var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
            isMatched = QMIRSNPPercentData.Jan == NPPercentFcastExcludesCLData.Jan;
            Assert.True(isMatched, $"No match:\n QMIRSNPPercentData.Jan = {QMIRSNPPercentData.Jan}\n" +
                $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");

        }       

        //[Test] [Category("WftCopyPlan")]
        public void UserCanCreateNewPlanBasedOnFacilityOption()
        {
            bool isMatched, isNPMatched, isCLMatched;
            string Year = CommonFunctions.GetNextYear();
            string PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFTFacilty.GoTo();
            Assert.True(WFTFacilty.IsAt, "Facility page was not displayed.");
            WFTFacilty.SetFacility()
                .withNumberOfRequiredApprovers("1 - One")
                .withNewPlanNonProductivePercent("Use Most Recent Approved & Released Plan")
                .withNewPlanStatisticMapping("Use Most Recent Approved & Released Plan")
                .withNewPlanVclPercentOrFixedFtes("Use Percent")
                .withCopyingPlanNonProductivePercent("Use Copied Plan")
                .withCopyingPlanStatisticMapping("Use Copied Plan")
                .withCopyingPlanEE_AHR_Months("Use Copied Plan")
                .withCopyingPlanCL_AHR_Months("Use Copied Plan")
                .withCopyingPlanCLPercentOrFixedFtes("Use Copied Plan")
                .withNewDeptartment(false) // if true, dept will be added. 
                .withNumber("601")
                .withDescription("text")
                .withDepartmentType("Semi-Variable")
                .withDefaultFacilityStat("BIRTHS - 5815")
                .withDepartmentStat("text")
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("15.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse(string.Empty)
                    .withStatisticMapping(string.Empty)
                    .withForCLPercentOrFixedFtesUse(string.Empty)
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(false) // no data update.
                    .Create();

            WFT_Admin_Plan.NavigateToAdminPlanPage();
            // Get Fac mapping for an existing released & approved plan
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Approved & Released")
                .withPlan("(X)")
                .Select();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");

            var ReleasedAndApprovedFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingForReleasedAndAppprovedPlanData();
            Console.WriteLine($"*** Released & Approved data ****");
            Console.WriteLine(ReleasedAndApprovedFacilityStatsMapping[0].DepartmentStat);
            Console.WriteLine(ReleasedAndApprovedFacilityStatsMapping[0].CLPercentOrFTE);
            Console.WriteLine(ReleasedAndApprovedFacilityStatsMapping[0].NPPercent);

            WFT_Admin_Plan.NavigateToAdminPlanPage();
            ExistingPlanFilter.GoTo();
            Assert.True(ExistingPlanFilter.IsAt, "Administration Existing Plan Filter is not displayed.");
            ExistingPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("All")
                .withPlan(PlanDescription)
                .Select();
            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");
            Console.WriteLine($"*** New Plan == {PlanDescription}    ****");
            var NewPlanFacilityStatsMapping = FacilityStatsMapping.GetFacilityStatsMappingData();
            Console.WriteLine(NewPlanFacilityStatsMapping[0].DepartmentStat);
            Console.WriteLine(NewPlanFacilityStatsMapping[0].CLPercentOrFTE);
            Console.WriteLine(NewPlanFacilityStatsMapping[0].NPPercent);

            isNPMatched = string.Equals(NewPlanFacilityStatsMapping[0].NPPercent.Trim(),
                ReleasedAndApprovedFacilityStatsMapping[0].NPPercent.Trim(),
                StringComparison.InvariantCultureIgnoreCase);
            Assert.True(isNPMatched, $"NP percent does not match between released & approved plan and the new plan\n" +
                $"NewPlanFacilityStatsMapping[0].NPPercent = {NewPlanFacilityStatsMapping[0].NPPercent}\n" +
                $"ReleasedAndApprovedFacilityStatsMapping[0].NPPercent = {ReleasedAndApprovedFacilityStatsMapping[0].NPPercent}");
            
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(Year)
                .withPlanStatus("Working")
                .withPlan(PlanDescription)
                .Select();
            CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 20);

            //Verify NP %
            switch (NewPlanFacilityStatsMapping[0].NPPercent.Trim())
            {
                case "PLUS":
                    Console.WriteLine("PLUS block");
                    var PLUSAvgNPPercentData = ForecastView_NonProductivePercent.PLUSAvgNP_Percent.getPLUSAvgNP_PercentData();
                    var NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    isMatched = PLUSAvgNPPercentData.Jan == NPPercentFcastExcludesCLData.Jan;
                    Assert.True(isMatched, $"No match:\nPLUSAvgNPPercentData.Jan = {PLUSAvgNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    break;
                case "QMIRS":
                    Console.WriteLine("QMIRS block");
                    var QMIRSNPPercentData = ForecastView_NonProductivePercent.QMIRS_NP_Percent.getQMIRS_NP_PercentData();
                    NPPercentFcastExcludesCLData = ForecastView_NonProductivePercent.NPPercentFcastExcludesCL.getNPPercentFcastExcludesCLData();
                    isMatched = QMIRSNPPercentData.Jan == NPPercentFcastExcludesCLData.Jan;
                    Assert.True(isMatched, $"No match:\n QMIRSNPPercentData.Jan = {QMIRSNPPercentData.Jan}\n" +
                        $"NPPercentFcastExcludesCLData.Jan = {NPPercentFcastExcludesCLData.Jan}");
                    break;
                default:
                    Console.WriteLine("Nothing to compare");
                    break;
            }

            //Verify CL % / FTEs
            switch (NewPlanFacilityStatsMapping[0].CLPercentOrFTE)
            {
                //FTEs
                case "Fixed":
                    Console.WriteLine("CL FTEs -- Fixed");
                    var ClFtesFcastData = ForecastView_ContractPercent.ClFtesFcast.getClFtesFcastData();
                    IWebElement JanCLFTEs = CommonFunctions.getElement(By.XPath("//input[@id='clFtes-1' and not(@readonly)]"));
                    Assert.True(JanCLFTEs.Enabled, "CL FTEs row is not enabled");
                    break;

                case "Percent":
                    Console.WriteLine("CL % -- percent");
                    var CLPercentFcastData = ForecastView_ContractPercent.CLPercentFcast.getCLPercentFcastData();
                    IWebElement JanCLPercent = CommonFunctions.getElement(By.XPath("//input[@id='txtContractLaborPercent-1' and not(@readonly)]"));
                    Assert.True(JanCLPercent.Enabled, "CL % row is not enabled");
                    break;
            }
        }
    }
}
