﻿using ISAS_Regression_Automation.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    [TestFixture]
    //[Parallelizable(scope: ParallelScope.Children)]
    public class HelpTest : Driver
    {
        
    }
}
