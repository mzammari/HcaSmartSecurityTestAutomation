﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Linq;

namespace ISAS_Regression_Automation
{
    [TestFixture]
    public class DepartmentForecastPlanFilterTests : Driver
    {        
        //[Test] [Category("WFT")]
        public void UserCanLoadPlUSTargets()
        {
            string VariableDept, VariableAndSemiVariableDept, SemiVariableDept;
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            homePage.SwitchToWindow("Workload Forecast");
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            DepartmentForecastPlanFilter.GoTo();
            Assert.True(DepartmentForecastPlanFilter.IsAt, "Department forecast page is not disaplayed.");

            //if we pass null or string.empty, it select the first existing plan. 
            DepartmentForecastPlanFilter.ExistingPlan()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .Select();

            FacilityStatsMapping.GoTo();
            Assert.True(FacilityStatsMapping.IsAt, "Existing Facility Stats is not displayed.");

            var FacStatMappingData = FacilityStatsMapping.GetFacilityStatsMappingData();
            var wft_V = from type in FacStatMappingData
                        where string.Equals(type.WFTDeptType, "Variable")
                        select type;
            VariableDept = wft_V.ToList().First().DeptName.Trim();
            Console.WriteLine($"dept name - V {wft_V.ToList().First().DeptName}");

            var wft_SV = from type in FacStatMappingData
                         where string.Equals(type.WFTDeptType, "SemiVariable")
                         select type;
            SemiVariableDept = wft_SV.ToList().First().DeptName.Trim();
            Console.WriteLine($"dept name - SV {SemiVariableDept}");

            var wft_B = from type in FacStatMappingData
                        where string.Equals(type.WFTDeptType, "Variable/SemiVariable")
                        select type;
            VariableAndSemiVariableDept = wft_B.ToList().First().DeptName;
            Console.WriteLine($"dept name - Both {wft_B.ToList().First().DeptName}");
            //Get PLUS data
            homePage.SwitchToWindow("PLUS");
            Division.SetPLUSDivisionAndFacility();
            TargetDetail.GoTo();
            Assert.True(TargetDetail.IsAt, "Productivity Targets page was not displayed.");
            var HrsPerUOSMontlyDetails = TargetDetail.VariableDeptartment.getHrsPerUOS(VariableDept);
            Console.WriteLine($"HrsPerUOSMontlyDetails.Jul = {HrsPerUOSMontlyDetails.Jul}");
            var TargetNPPercentDetails = TargetDetail.VariableDeptartment.getTargetNPPercent(VariableDept);
            Console.WriteLine($"TargetNPPercentDetails.Jul = {TargetNPPercentDetails.Jul}");
            Console.WriteLine($"TargetOTPercent.Jul = {TargetDetail.VariableDeptartment.getTargetOTPercent(VariableDept).Jul}");
            Console.WriteLine($"TargetContractPercent.Jul = {TargetDetail.VariableDeptartment.getTargetContractPercent(VariableDept).Jul}");
            Console.WriteLine($"TargetAvgRate.Jul = {TargetDetail.VariableDeptartment.getTargetAvgRate(VariableDept).Jul}");
            Console.WriteLine($"SemiVariableDepartment > from > Jul = {TargetDetail.SemiVariableDepartment.getFromData(SemiVariableDept).Jul}");
            Console.WriteLine($"SemiVariableDepartment > Sun > Jul = {TargetDetail.SemiVariableDepartment.getSunData(SemiVariableDept).Jul}");
            Console.WriteLine($"SemiVariableDepartment > Total > Jul = {TargetDetail.SemiVariableDepartment.getTotalData(SemiVariableDept).Jul}");







            LoadTargets.GoTo();
            Assert.True(LoadTargets.IsAt, "Load target dialog is not displayed");

            LoadTargets.LoadTarget()
                .withLoadProductivityTargets("PLUS: Hrs/UOS to WFT: Fcast Var. Std")
                .withPLUSTargetMonthFrom("Jan: Dec to Jan:Dec")
                .withProductiveMinFtes(false)
                .withStepTargets(false)
                .OK();
            CommonFunctions.WaitUntilPageIsAcive();
            bool bExists = CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 30);
            if(bExists)
            {
                Console.WriteLine("stats exists");
            }



        }



    }
}
