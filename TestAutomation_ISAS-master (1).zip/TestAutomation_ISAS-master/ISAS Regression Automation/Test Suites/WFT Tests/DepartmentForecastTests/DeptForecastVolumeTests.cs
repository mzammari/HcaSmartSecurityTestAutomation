﻿using ISAS_Regression_Automation.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SharpCompress.Common;
using System;
using System.Threading;
using static ISAS_Regression_Automation.PLUSMainMenu;

namespace ISAS_Regression_Automation
{    
    public class DeptForecastVolumeTests : Driver
    {
        
    }
}
