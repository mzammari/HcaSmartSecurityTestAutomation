﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    [TestFixture]
    //[Parallelizable(ParallelScope.Self)]
    public class WFTReportTests : Driver
    {
        [SetUp]
        public void Init()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify the WFT Reports";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
        }


        [Test] [Category("WftReports")]
        public void PaidFTESummaryReportInExcelFormat()
        {
            //This will select the default values in the report. 
            PaidFTESummaryReport.GoTo();
            Assert.True(PaidFTESummaryReport.IsAt, "Paid FTE Summary Report was not displayed.");
            PaidFTESummaryReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void PaidFTESummaryReportInPDFFormat()
        {
            //This will select the default values in the report. 
            PaidFTESummaryReport.GoTo();
            Assert.True(PaidFTESummaryReport.IsAt, "Paid FTE Summary Report was not displayed.");
            PaidFTESummaryReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void ProductiveFTESummaryReportInExcelFormat()
        {
            //This will select the default values in the report. 
            ProductiveFTESummaryReport.GoTo();
            Assert.True(ProductiveFTESummaryReport.IsAt, "Productive FTE Summary report was not displayed.");
            ProductiveFTESummaryReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void ProductiveFTESummaryReportInPDFFormat()
        {
            //This will select the default values in the report. 
            ProductiveFTESummaryReport.GoTo();
            Assert.True(ProductiveFTESummaryReport.IsAt, "Productive FTE Summary report was not displayed.");
            ProductiveFTESummaryReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void ContractFTESummaryReportInExcelFormat()
        {
            //This will select the default values in the report. 
            ContractFTESummaryReport.GoTo();
            Assert.True(ContractFTESummaryReport.IsAt, "Productive FTE Summary report was not displayed.");
            ContractFTESummaryReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void ContractFTESummaryReportInPDFFormat()
        {
            //This will select the default values in the report. 
            ContractFTESummaryReport.GoTo();
            Assert.True(ContractFTESummaryReport.IsAt, "Productive FTE Summary report was not displayed.");
            ContractFTESummaryReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }
        [Test] [Category("WftReports")]
        public void AnnualBudgetSummaryReportInExcelFormat()
        {
            //This will select the default values in the report. 
            AnnualBudgetSummaryReport.GoTo();
            Assert.True(AnnualBudgetSummaryReport.IsAt, "Annual Budget Summary report was not displayed.");
            AnnualBudgetSummaryReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void AnnualBudgetSummaryReportInPDFFormat()
        {
            //This will select the default values in the report. 
            AnnualBudgetSummaryReport.GoTo();
            Assert.True(AnnualBudgetSummaryReport.IsAt, "Annual Budget Summary report was not displayed.");
            AnnualBudgetSummaryReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void EmployedAndContractFTECountsReportInExcelFormat()
        {
            //This will select the default values in the report. 
            EmployedAndContractFTECountsReport.GoTo();
            Assert.True(EmployedAndContractFTECountsReport.IsAt, "Employed and Contract FTE Counts report was not displayed.");
            EmployedAndContractFTECountsReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void EmployedAndContractFTECountsReportInPDFFormat()
        {
            //This will select the default values in the report. 
            EmployedAndContractFTECountsReport.GoTo();
            Assert.True(EmployedAndContractFTECountsReport.IsAt, "Employed and Contract FTE Counts report was not displayed.");
            EmployedAndContractFTECountsReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void EmployedAndContractFTECostReportInExcelFormat()
        {
            //This will select the default values in the report. 
            EmployedAndContractFTECostReport.GoTo();
            Assert.True(EmployedAndContractFTECostReport.IsAt, "Employed and Contract FTE Cost report was not displayed.");
            EmployedAndContractFTECostReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void EmployedAndContractFTECostReportInPDFFormat()
        {
            //This will select the default values in the report. 
            EmployedAndContractFTECostReport.GoTo();
            Assert.True(EmployedAndContractFTECostReport.IsAt, "Employed and Contract FTE Cost report was not displayed.");
            EmployedAndContractFTECostReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void LaborSummaryMonthlyReportInExcelFormat()
        {
            //This will select the default values in the report. 
            LaborSummaryMonthlyReport.GoTo();
            Assert.True(LaborSummaryMonthlyReport.IsAt, "Dept > Labor Summary - Monthly report was not displayed.");
            LaborSummaryMonthlyReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void LaborSummaryMonthlyReportInPDFFormat()
        {
            //This will select the default values in the report. 
            LaborSummaryMonthlyReport.GoTo();
            Assert.True(LaborSummaryMonthlyReport.IsAt, "Dept > Labor Summary - Monthly report was not displayed.");
            LaborSummaryMonthlyReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void LaborSummaryYearlyReportInExcelFormat()
        {
            //This will select the default values in the report. 
            LaborSummaryYearlyReport.GoTo();
            Assert.True(LaborSummaryYearlyReport.IsAt, "Dept > Labor Summary - Yearly report was not displayed.");
            LaborSummaryYearlyReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void LaborSummaryYearlyReportInPDFFormat()
        {
            //This will select the default values in the report. 
            LaborSummaryYearlyReport.GoTo();
            Assert.True(LaborSummaryYearlyReport.IsAt, "Dept > Labor Summary - Yearly report was not displayed.");
            LaborSummaryYearlyReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void DepartmentGroupLaborSummaryMonthlyReportInExcelFormat()
        {
            //This will select the default values in the report. 
            DepartmentGroupLaborSummaryMonthlyReport.GoTo();
            Assert.True(DepartmentGroupLaborSummaryMonthlyReport.IsAt, "Department Group > Labor Summary - Monthly report was not displayed.");
            DepartmentGroupLaborSummaryMonthlyReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void DepartmentGroupLaborSummaryMonthlyReportInPDFFormat()
        {
            //This will select the default values in the report. 
            DepartmentGroupLaborSummaryMonthlyReport.GoTo();
            Assert.True(DepartmentGroupLaborSummaryMonthlyReport.IsAt, "Department Group > Labor Summary - Monthly report was not displayed.");
            DepartmentGroupLaborSummaryMonthlyReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void DepartmentGroupLaborSummaryYearlyReportInExcelFormat()
        {
            //This will select the default values in the report. 
            DepartmentGroupLaborSummaryMonthlyReport.GoTo();
            Assert.True(DepartmentGroupLaborSummaryMonthlyReport.IsAt, "Department Group > Labor Summary - Yearly report was not displayed.");
            DepartmentGroupLaborSummaryMonthlyReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void DepartmentGroupLaborSummaryYearlyReportInPDFFormat()
        {
            //This will select the default values in the report. 
            DepartmentGroupLaborSummaryMonthlyReport.GoTo();
            Assert.True(DepartmentGroupLaborSummaryMonthlyReport.IsAt, "Department Group > Labor Summary - Yearly report was not displayed.");
            DepartmentGroupLaborSummaryMonthlyReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void DeptFacilityRatioImpactAnalysisReportInExcelFormat()
        {
            //This will select the default values in the report. 
            DeptFacilityRatioImpactAnalysisReport.GoTo();
            Assert.True(DeptFacilityRatioImpactAnalysisReport.IsAt, "Dept Facility Ratio Impact Analysis report was not displayed.");
            DeptFacilityRatioImpactAnalysisReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withSmoothingnVariancePercent(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void DeptFacilityRatioImpactAnalysisReportInPDFFormat()
        {
            //This will select the default values in the report. 
            DeptFacilityRatioImpactAnalysisReport.GoTo();
            Assert.True(DeptFacilityRatioImpactAnalysisReport.IsAt, "Dept Facility Ratio Impact Analysis report was not displayed.");
            DeptFacilityRatioImpactAnalysisReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withSmoothingnVariancePercent(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void FacilityStatMappingReportInExcelFormat()
        {
            //This will select the default values in the report. 
            FacilityStatMappingReport.GoTo();
            Assert.True(FacilityStatMappingReport.IsAt, "Facility Stat Mapping report was not displayed.");
            FacilityStatMappingReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void FacilityStatMappingReportInPDFFormat()
        {
            //This will select the default values in the report. 
            FacilityStatMappingReport.GoTo();
            Assert.True(FacilityStatMappingReport.IsAt, "Facility Stat Mapping report was not displayed.");
            FacilityStatMappingReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }
        [Test] [Category("WftReports")]
        public void FacilityLaborSummaryMonthlyInExcelFormat()
        {
            //This will select the default values in the report. 
            FacilityLaborSummaryMonthly.GoTo();
            Assert.True(FacilityLaborSummaryMonthly.IsAt, "Facility Labor Summary- Monthly report was not displayed.");
            FacilityLaborSummaryMonthly.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void FacilityLaborSummaryMonthlyInPDFFormat()
        {
            //This will select the default values in the report. 
            FacilityLaborSummaryMonthly.GoTo();
            Assert.True(FacilityLaborSummaryMonthly.IsAt, "Facility Labor Summary- Monthly report was not displayed.");
            FacilityLaborSummaryMonthly.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void FacilityLaborSummaryYearlyInExcelFormat()
        {
            //This will select the default values in the report. 
            FacilityLaborSummaryYearly.GoTo();
            Assert.True(FacilityLaborSummaryYearly.IsAt, "Facility Labor Summary- Yearly report was not displayed.");
            FacilityLaborSummaryYearly.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void FacilityLaborSummaryYearlyInPDFFormat()
        {
            //This will select the default values in the report. 
            FacilityLaborSummaryYearly.GoTo();
            Assert.True(FacilityLaborSummaryYearly.IsAt, "Facility Labor Summary- Yearly report was not displayed.");
            FacilityLaborSummaryYearly.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void NonProdPercentImpactAnalysisReportInExcelFormat()
        {
            //This will select the default values in the report. 
            NonProdPercentImpactAnalysisReport.GoTo();
            Assert.True(NonProdPercentImpactAnalysisReport.IsAt, "Non-Prod % Impact Analysis report was not displayed.");
            NonProdPercentImpactAnalysisReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void NonProdPercentImpactAnalysisReportInPDFFormat()
        {
            //This will select the default values in the report. 
            NonProdPercentImpactAnalysisReport.GoTo();
            Assert.True(NonProdPercentImpactAnalysisReport.IsAt, "Non-Prod % Impact Analysis report was not displayed.");
            NonProdPercentImpactAnalysisReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void ApprovedAndReleasedReportInExcelFormat()
        {
            //This will select the default values in the report. 
            ApprovedAndReleasedReport.GoTo();
            Assert.True(ApprovedAndReleasedReport.IsAt, "Non-Prod % Impact Analysis report was not displayed.");
            ApprovedAndReleasedReport.Report()
                .withYear(string.Empty)
                .withDivision(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void ApprovedAndReleasedReportInPDFFormat()
        {
            //This will select the default values in the report. 
            ApprovedAndReleasedReport.GoTo();
            Assert.True(ApprovedAndReleasedReport.IsAt, "Non-Prod % Impact Analysis report was not displayed.");
            ApprovedAndReleasedReport.Report()
                .withYear(string.Empty)
                .withDivision(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void PLUSSystemTargetsReportInExcelFormat()
        {
            //This will select the default values in the report. 
            PLUSSystemTargetsReport.GoTo();
            Assert.True(PLUSSystemTargetsReport.IsAt, "PLUS System Targets report was not displayed.");
            PLUSSystemTargetsReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void PLUSSystemTargetsReportInPDFFormat()
        {
            //This will select the default values in the report. 
            PLUSSystemTargetsReport.GoTo();
            Assert.True(PLUSSystemTargetsReport.IsAt, "PLUS System Targets report was not displayed.");
            PLUSSystemTargetsReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void SVComparisonReportInExcelFormat()
        {
            //This will select the default values in the report. 
            SVComparisonReport.GoTo();
            Assert.True(SVComparisonReport.IsAt, "SV Comparison report was not displayed.");
            SVComparisonReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectExcel();
        }

        [Test] [Category("WftReports")]
        public void SVComparisonReportInPDFFormat()
        {
            //This will select the default values in the report. 
            SVComparisonReport.GoTo();
            Assert.True(SVComparisonReport.IsAt, "SV Comparison report was not displayed.");
            SVComparisonReport.Report()
                .withYear(string.Empty)
                .withPlanStatus(string.Empty)
                .withPlan(string.Empty)
                .withDepartment(string.Empty)
                .SelectPDF();
        }

        [Test] [Category("WftReports")]
        public void ExportsReportInExcelFormat()
        {
            //This will select the default values in the report. 
            ExportsReport.GoTo();
            Assert.True(ExportsReport.IsAt, "Exports report was not displayed.");
            ExportsReport.Report()
                .withYear(string.Empty)
                .withPlan(string.Empty)
                .withExportType(string.Empty)
                .SelectExcel();
            
        }
    }
}
