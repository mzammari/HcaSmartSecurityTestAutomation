﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    [TestFixture, Ignore("reason")]
    public class ViewerRole : Driver
    {
        AdministrationNewPlanTests administrationNewPlanTests = new AdministrationNewPlanTests();
        WFTReportTests wFTReportTests = new WFTReportTests();

        [Test]
        public void ViewerCanCreateNewPlanAndAddComment()
        {
            Driver.Instance.Close();
            Driver.Instance.Quit();
            DatabaseUtility.ChangeWftRole("Viewer");
            Driver.Method();

            bool bDeleted;
            string CopiedPlanDescription;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();
            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFT_Admin_Plan.NavigateToAdminPlanPage();
            string PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            string Year = CommonFunctions.GetNextYear();
            Console.WriteLine($"PlanDescription = {PlanDescription}");
            AdministrationNewPlan.GoTo();
            Assert.True(AdministrationNewPlan.IsAt, "Create a new plan page is not displayed");
            AdministrationNewPlan.NewPlan()
                    .withYear(Year)
                    .withPlanDescription(PlanDescription)
                    .withApprovers("1 - One")
                    .withBudgetedvolumepercentage("2.00")
                    .withFreezeFacilityRatiosAndVolumes(false)
                    .withFreezeCL(false)
                    .withFreezeNPRatiosAndVolumes(false)
                    .withFreezeOT(false)
                    .withForNonProductiveUse("Most Recent Approved Plan")
                    .withStatisticMapping("Most Recent Approved Plan")
                    .withForCLPercentOrFixedFtesUse("Fixed FTEs")
                    .withApplyLatestQMIRSMonthRatetoAllMonths(true)
                    .withLoadProductivityTargets("QMIRS")
                    .withPLUSTargetMonth("Jan: Dec to Jan:Dec")
                    .withSmoothRatios("Current")
                    .withUpdateForecast(true)
                    .Create();
            CommonFunctions.WaitUntilPageIsAcive();
            //Add a comment
            AdminMenu.Comments();
            Assert.True(Comments.IsAt, "Comments popup was not displayed.");
            Comments.UserComment()
                .withDescription("Viewer comment")
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approve a plan
            AdminMenu.GoToForecast();
            SubmitForApproval.SubmitPlanForApproval();
            Assert.True(SubmitForApproval.IsAt, "Plan was not approved");
            Assert.True(SubmitForApproval.bLastNameDisplayedInSubmissionDetails(),
                "User name was not displayed in the submission detail");
            DeptForecastButtonPanel.ApprovePlan();
            Comments.UserComment()
                .withDescription($"Approving {PlanDescription}")
                .Approve();
            // copy the plan
            DeptForecastButtonPanel.GoToAdmin();
            CopyPlan.GoTo();
            CopiedPlanDescription = $"Copied_{PlanDescription}";
            CopyPlan.Copy()
                .withPlanYear(Year)
                .withDescription(CopiedPlanDescription)
                .withUpdateForecast(false)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            //Delet a plan
            bDeleted = AdminMenu.DeletePlan(PlanDescription);
            Assert.False(bDeleted, $"{PlanDescription} was not deleted");
        }

        [Test]
        public void ViewerCanVerifyFacilityGoals()
        {
            Driver.Instance.Close();
            Driver.Instance.Quit();
            DatabaseUtility.ChangeWftRole("Viewer");
            Driver.Method();
            administrationNewPlanTests.VerifyFacilityGoals();
        }

        [Test]
        public void ViewerCanModifyFacilityStatsMapping()
        {
            Driver.Instance.Close();
            Driver.Instance.Quit();
            DatabaseUtility.ChangeWftRole("Viewer");
            Driver.Method();
            //administrationNewPlanTests.UserCanModifyFacilityStatsMapping();
        }

        [Test]
        public void ViewerCanRejectPlan()
        {
            Driver.Instance.Close();
            Driver.Instance.Quit();
            DatabaseUtility.ChangeWftRole("Viewer");
            Driver.Method();
            administrationNewPlanTests.UserCanRejectPlan();
        }

        [Test]
        public void ViewerCanGenerateReports()
        {
            Driver.Instance.Close();
            Driver.Instance.Quit();
            DatabaseUtility.ChangeWftRole("Viewer");
            Driver.Method();
            wFTReportTests.AnnualBudgetSummaryReportInExcelFormat();
            wFTReportTests.ApprovedAndReleasedReportInExcelFormat();
            wFTReportTests.ContractFTESummaryReportInExcelFormat();
            wFTReportTests.DepartmentGroupLaborSummaryMonthlyReportInExcelFormat();
            wFTReportTests.DeptFacilityRatioImpactAnalysisReportInExcelFormat();

        }

    }
}
