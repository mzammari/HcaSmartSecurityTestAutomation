﻿using ISAS_Regression_Automation.Utilities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace ISAS_Regression_Automation
{
    [TestFixture]
    public class DailyTest : Driver
    {        
        [Test]
        [Category("Plus")]
        public void UserCanFilterContractHoursDeptView()
        {
            double dInterfacedHours, dDayAdjHrs,dNightAdjHrs, dTotalHrs, dTotal, dCalculatedTotalDollars, dTotalDollars;
            string FpcDept = SettingData.FpcDept;
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility("34222");
            ContractHours.GoTo();
            Assert.True(ContractHours.IsAt, "Contract hours page was not displayed.");
            ContractHours.DeptView()
                .withDepartment("610")
                .withSkillMix("163")
                .getData();
            CommonFunctions.WaitUntilPageIsAcive();
            ContarctHoursData.SetDepartmentAdjHours("8");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractHours.DeptView()
                .withDepartment("610")
                .withSkillMix("163")
                .getData();
            CommonFunctions.WaitUntilPageIsAcive();
            var DeptViewDataResult = ContarctHoursData.GetDeptarmentViewData();
            dInterfacedHours = CommonFunctions.ToDouble(DeptViewDataResult[0].InterfacedHours);
            dDayAdjHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].DayAdjHours);
            dNightAdjHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].NightAdjHours);
            dTotalHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].TotalHours);
            dTotalDollars = CommonFunctions.ToDouble(DeptViewDataResult[0].TotalDollars);
            dTotal = dInterfacedHours + dDayAdjHrs;
            Assert.True(dTotal == dTotalHrs, $"Dept veiew: Total {dTotal} doesn't match total hours {dTotalHrs}");


            //Days View
            ContractHours.DaysView()
                .withPayPeriod("Current")
                .withDate("current data")
                .withSkillMix("161")
                .GetData();
            CommonFunctions.WaitUntilPageIsAcive();            
            //Adj hours
            ContarctHoursData.SetDaysAdjHours("4");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractHours.DaysView()
                .withPayPeriod("Current")
                .withDate("current data")
                .withSkillMix("161")
                .GetData();
            CommonFunctions.WaitUntilPageIsAcive();
            var DaysViewDataResult = ContarctHoursData.GetDaysViewData();
            dInterfacedHours = CommonFunctions.ToDouble(DaysViewDataResult[0].InterfacedHours);
            dDayAdjHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].DayAdjHours);
            dNightAdjHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].NightAdjHours);
            dTotalHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].TotalHours);
            dTotalDollars = CommonFunctions.ToDouble(DaysViewDataResult[0].TotalDollars);
            dTotal = dInterfacedHours + dDayAdjHrs;
            Assert.True(dTotal == dTotalHrs, $"Days view: Total {dTotal} doesn't match total hours {dTotalHrs}");
            //verify total dollars
            dCalculatedTotalDollars = CommonFunctions.ToDouble(DaysViewDataResult[0].Rate) * dTotalHrs;
            Assert.True(dTotalDollars == dCalculatedTotalDollars, $"dTotalDollars {dTotalDollars} doesn't match Calculated Total Dollars {dCalculatedTotalDollars}");
        }

        [Test]
        [Category("Plus")]
        public void VerifySharedHours()
        {
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility();
            SharedHours.GoTo();
            Assert.True(SharedHours.IsAt, "Shared hours page was not displayed.");
            SharedHours.DeptView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDepartment("600")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDeptViewData(40.00);
            var SharedHoursDeptViewDataResults = SharedHoursData.GetSharedHoursDeptViewData();
            Console.WriteLine(SharedHoursDeptViewDataResults[0].DayOtHours);

            SharedHours.DaysView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDate("Current date")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDaysViewData(40);
            var SharedHoursDaysViewDataResults = SharedHoursData.GetSharedHoursDaysViewData();
            Console.WriteLine(SharedHoursDaysViewDataResults[0].DayOtHours);

            //add the calc
        }

        [Test]
        [Category("Plus")]
        public void StatisticVolumesJourney()
        {
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");

            DepartmentOptions.GoTo();
            Assert.True(DepartmentOptions.IsAt, "DepartmentOptions page was not displayed.");
            DepartmentOptions.DeptOptions()
                .withDepartment("610")
                .withDepartmentCategory("Variable")
                .withIgnoreDepartment(false)
                .withAllowStatisticVolumeAdjustment(true)
                .withAllowPLUSSharedOutHourEntry(true)
                .withFreezeDepartmentPAVolumes(false)
                .withContractLaborPercentage("0.0")
                .withFixedNoOfFtes("0.0")
                .Save();

            StatisticVolumes.GoTo();
            Assert.True(StatisticVolumes.IsAt, "Statistic Volumes page was not displayed.");
            StatisticVolumes.DeptView()
                .withDepartment("610")
                .withPayPeriod("Current")
                .GetType();
            StatisticVolumesData.SetStatisticVolumesDeptViewData(3.00);
            var StatisticVolumesDeptViewDataResult = StatisticVolumesData.GetStatisticVolumesDeptViewData();

            StatisticVolumes.DaysView()
                .withDate("Current date")
                .withPayPeriod("Current")
                .withStatisticDescription("ALL")
                .GetData();
            StatisticVolumesData.SetStatisticVolumesDaysViewData(5.00);
            var StatisticVolumesDaysViewDataResults = StatisticVolumesData.GetStatisticVolumesDaysViewData();

            StatisticVolumes.FacilityLevelStatisticsView()
                .withPayPeriod("Current")
                .withDate("Current date")
                .GetData();
            StatisticVolumesData.SetStatisticVolumesFacilityLevelStatisticsViewData(6.00);
            var StatisticVolumesFacilityLevelStatisticsViewDataResults = StatisticVolumesData.GetStatisticVolumesFacilityLevelStatisticsViewData();

        }
    }
}
