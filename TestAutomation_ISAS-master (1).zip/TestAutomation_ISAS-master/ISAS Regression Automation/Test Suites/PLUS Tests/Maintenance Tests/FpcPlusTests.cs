﻿using AngleSharp.Text;
using DocumentFormat.OpenXml.Bibliography;
using ISAS_Regression_Automation.Utilities;
using Microsoft.VisualBasic;
using NuGet.Frameworks;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.WFTMainMenu.WFTReports;

namespace ISAS_Regression_Automation
{
    [TestFixture]
    public class FpcPlusTests : Driver
    {
        [Test]
        [Category("Plus")]
        public void ProcedureMultiplierJourney()
        {
            double dMultiplierForAll = 3.00;
            bool isMatched;
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            ProcedureMultiplier.GoTo();
            Assert.True(ProcedureMultiplier.IsAt, "Procedure multiplier page was not displayed.");
            ProcedureMultiplier.ProcedureProductivityMultipliers()
                .withDepartment("610")
                .withStatus("Active")
                .ApplyFilter();            
            ProcedureMultiplierData.SetMultiplier("0.02");
            var lstProcedureMultiplierData = ProcedureMultiplierData.GetProcedureMultiplierData();
            Console.WriteLine($"{lstProcedureMultiplierData[0].Status}\n" +
                $"{lstProcedureMultiplierData[0].Multiplier}");
            //Enter Multiplier For All button and dialog
            ProcedureMultiplier.EnterMultiplierForAll(dMultiplierForAll.ToString());
            lstProcedureMultiplierData = ProcedureMultiplierData.GetProcedureMultiplierData();
            isMatched = CommonFunctions.ToDouble(lstProcedureMultiplierData[0].Multiplier) == dMultiplierForAll;
            Assert.True(isMatched, $"lstProcedureMultiplierData[0].Multiplier = {lstProcedureMultiplierData[0].Multiplier} " +
                $"does not equal {dMultiplierForAll}");
        }        

       //[Test]
        public void ATestVolumeForecastingExtendSession()
        {
            bool bDisplayed, bBeforeTimeout;
            int counter = 1;
            string SgDept = SettingData.SgDept;
            var homePage = new HomePage(Driver.Instance);

            //Plus
            //homePage.NavigateToFPC();
            //Division.SetPLUSDivisionAndFacility("34222");
            //ContractRates.GoTo();
            //Assert.True(ContractRates.IsAt, "Contract Rates page was not displayed.");

            //Staffing Grid 
            //homePage.NavigateToStaffingGrid();
            //Division.SetStaffingGridDivisionAndFacility();
            //SgMainMenu.SelectGrid();
            //StaffingGridFliterPage.SgFilter()
            //    .withDepartment(string.Empty)
            //    .withStatus("New - Blank")
            //    .withStaffingGrid(string.Empty)
            //    .Create();

            //VF
            homePage.NavigateToVolumeForecasting();
            Thread.Sleep(5000);

            By byAdd = By.XPath("//a[@id='addSkillMixBtn']");
            By bySgCreate = By.XPath("//input[@id='btnView']");
            By byVolumeForecasting = By.XPath("//input[@onclick='AutoGenerateMethodClick()']");

            //DateTime _desired = DateTime.Now.AddHours(3);
            By byExtendSession = By.XPath("//*/div[@aria-describedby=\"session-timeout-headsup\"]//button[contains(text(),'Extend the Session')]");
            By bySessionTimeout = By.XPath("/*/div[@aria-describedby=\"session-timeout\"]//div[@class=\"ui-dialog-buttonset\"]//button[contains(text(),'OK')]");
            DateTime startTime = DateTime.Now;
            TimeSpan maxDuration = TimeSpan.FromHours(4);
            DateTime lastStartTime = DateTime.Now; // Start the first check time
            while (DateTime.Now - startTime < maxDuration)
            { 
                bDisplayed = CommonFunctions.IsElementDisplayed(byExtendSession,1);
                if(bDisplayed)
                {
                    TimeSpan elapsed = DateTime.Now - lastStartTime;
                    Console.WriteLine($"Extend session button was displayed for {counter++} time after {elapsed.TotalMinutes:F2} minutes.");
                    //Console.WriteLine($"Time: {DateTime.Now}");
                    bBeforeTimeout = getTimeout();
                    if (bBeforeTimeout)
                    {
                        CommonFunctions.getElement(byExtendSession).Click();                        
                        Console.WriteLine($" Page reload: {TimeItTakesToReloadPage(byVolumeForecasting)}");
                        Console.WriteLine();
                        // Reset the start time for the next loop
                        lastStartTime = DateTime.Now;


                        bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                        if (bDisplayed)
                        {
                            break;
                            CommonFunctions.getElement(bySessionTimeout).Click();
                            elapsed = DateTime.Now - lastStartTime;
                            Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.");

                            // Reset the start time for the next loop
                            lastStartTime = DateTime.Now;
                        }
                    }
                }

                //bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                //if (bDisplayed)
                //{
                //    CommonFunctions.getElement(bySessionTimeout).Click();
                //    TimeSpan elapsed = DateTime.Now - lastStartTime;
                //    Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.");

                //    // Reset the start time for the next loop
                //    lastStartTime = DateTime.Now;
                //}
            }           
        }

       //[Test]
        public void TestPlusExtendSession()
        {
            bool bDisplayed, bBeforeTimeout;
            int counter = 1;
            string SgDept = SettingData.SgDept;
            var homePage = new HomePage(Driver.Instance);

            //Plus
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            ContractRates.GoTo();
            Assert.True(ContractRates.IsAt, "Contract Rates page was not displayed.");

            //Staffing Grid 
            //homePage.NavigateToStaffingGrid();
            //Division.SetStaffingGridDivisionAndFacility();
            //SgMainMenu.SelectGrid();
            //StaffingGridFliterPage.SgFilter()
            //    .withDepartment(string.Empty)
            //    .withStatus("New - Blank")
            //    .withStaffingGrid(string.Empty)
            //    .Create();

            //VF
            //homePage.NavigateToVolumeForecasting();

            By byAdd = By.XPath("//a[@id='addSkillMixBtn']");
            By bySgCreate = By.XPath("//input[@id='btnView']");
            By byVolumeForecasting = By.XPath("//input[@onclick='AutoGenerateMethodClick()']");

            // DateTime _desired = DateTime.Now.AddHours(3);
            By byExtendSession = By.XPath("//*/div[@aria-describedby=\"session-timeout-headsup\"]//button[contains(text(),'Extend the Session')]");
            By bySessionTimeout = By.XPath("/*/div[@aria-describedby=\"session-timeout\"]//div[@class=\"ui-dialog-buttonset\"]//button[contains(text(),'OK')]");
            DateTime startTime = DateTime.Now;
            TimeSpan maxDuration = TimeSpan.FromHours(4);
            DateTime lastStartTime = DateTime.Now; // Start the first check time
            while (DateTime.Now - startTime < maxDuration)
            {
                bDisplayed = CommonFunctions.IsElementDisplayed(byExtendSession, 1);
                if (bDisplayed)
                {
                    TimeSpan elapsed = DateTime.Now - lastStartTime;
                    Console.WriteLine($"Extend session button was displayed for {counter++} time after {elapsed.TotalMinutes:F2} minutes.");
                    //Console.WriteLine($"Time: {DateTime.Now}");
                    bBeforeTimeout = getTimeout();
                    if (bBeforeTimeout)
                    {
                        CommonFunctions.getElement(byExtendSession).Click();
                        Console.WriteLine($" Page reload: {TimeItTakesToReloadPage(byAdd)}");
                        
                        // Reset the start time for the next loop
                        lastStartTime = DateTime.Now;
                        DateTime now = DateTime.Now; // Local time
                        string timestamp = now.ToString("yyyy-MM-dd HH:mm:ss"); // Format: 2026-01-13 14:25:00
                        Console.WriteLine($"Time: {timestamp} ");

                        bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                        if (bDisplayed)
                        {
                            
                            CommonFunctions.getElement(bySessionTimeout).Click();
                            elapsed = DateTime.Now - lastStartTime;
                            DateTime ExpiredTime = DateTime.Now; // Local time
                            string ExpiredTimestamp = now.ToString("yyyy-MM-dd HH:mm:ss"); // Format: 2026-01-13 14:25:00                            
                            Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.\n" +
                                $"Current time: {DateTime.Now}");
                            Console.WriteLine($"Session expired time: {ExpiredTimestamp} ");
                            break;
                            // Reset the start time for the next loop
                            //lastStartTime = DateTime.Now;
                        }
                    }
                }

                //bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                //if (bDisplayed)
                //{
                //    CommonFunctions.getElement(bySessionTimeout).Click();
                //    TimeSpan elapsed = DateTime.Now - lastStartTime;
                //    Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.");

                //    // Reset the start time for the next loop
                //    lastStartTime = DateTime.Now;
                //}
            }
        }

        //[Test]
        public void TestStaffingGridExtendSession()
        {
            bool bDisplayed, bBeforeTimeout;
            int counter = 1;
            string SgDept = SettingData.SgDept;
            var homePage = new HomePage(Driver.Instance);

            //Plus
            //homePage.NavigateToFPC();
            //Division.SetPLUSDivisionAndFacility("34222");
            //ContractRates.GoTo();
            //Assert.True(ContractRates.IsAt, "Contract Rates page was not displayed.");

            //Staffing Grid 
            homePage.NavigateToStaffingGrid();
            Division.SetStaffingGridDivisionAndFacility();
            SgMainMenu.SelectGrid();
            //StaffingGridFliterPage.SgFilter()
            //    .withDepartment(string.Empty)
            //    .withStatus("New - Blank")
            //    .withStaffingGrid(string.Empty)
            //    .Create();

            //VF
            //homePage.NavigateToVolumeForecasting();

            By byAdd = By.XPath("//a[@id='addSkillMixBtn']");
            By bySgCreate = By.XPath("//input[@id='btnView']");
            By byVolumeForecasting = By.XPath("//input[@onclick='AutoGenerateMethodClick()']");

            DateTime _desired = DateTime.Now.AddHours(2);
            By byExtendSession = By.XPath("//*/div[@aria-describedby=\"session-timeout-headsup\"]//button[contains(text(),'Extend the Session')]");
            By bySessionTimeout = By.XPath("/*/div[@aria-describedby=\"session-timeout\"]//div[@class=\"ui-dialog-buttonset\"]//button[contains(text(),'OK')]");
            DateTime startTime = DateTime.Now;
            TimeSpan maxDuration = TimeSpan.FromHours(4);
            DateTime lastStartTime = DateTime.Now; // Start the first check time
            while (DateTime.Now - startTime < maxDuration)
            {
                bDisplayed = CommonFunctions.IsElementDisplayed(byExtendSession, 1);
                if (bDisplayed)
                {
                    TimeSpan elapsed = DateTime.Now - lastStartTime;
                    Console.WriteLine($"Extend session button was displayed for {counter++} time after {elapsed.TotalMinutes:F2} minutes.");
                    //Console.WriteLine($"Time: {DateTime.Now}");
                    bBeforeTimeout = getTimeout();
                    if (bBeforeTimeout)
                    {
                        CommonFunctions.getElement(byExtendSession).Click();
                        Console.WriteLine($" Page reload: {TimeItTakesToReloadPage(byAdd)}");

                        // Reset the start time for the next loop
                        lastStartTime = DateTime.Now;
                        DateTime now = DateTime.Now; // Local time
                        string timestamp = now.ToString("yyyy-MM-dd HH:mm:ss"); // Format: 2026-01-13 14:25:00
                        Console.WriteLine($"Time: {timestamp} ");

                        bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                        if (bDisplayed)
                        {

                            CommonFunctions.getElement(bySessionTimeout).Click();
                            elapsed = DateTime.Now - lastStartTime;
                            DateTime ExpiredTime = DateTime.Now; // Local time
                            string ExpiredTimestamp = now.ToString("yyyy-MM-dd HH:mm:ss"); // Format: 2026-01-13 14:25:00                            
                            Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.\n" +
                                $"Current time: {DateTime.Now}");
                            Console.WriteLine($"Session expired time: {ExpiredTimestamp} ");
                            break;
                            // Reset the start time for the next loop
                            //lastStartTime = DateTime.Now;
                        }
                    }
                }

                //bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                //if (bDisplayed)
                //{
                //    CommonFunctions.getElement(bySessionTimeout).Click();
                //    TimeSpan elapsed = DateTime.Now - lastStartTime;
                //    Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.");

                //    // Reset the start time for the next loop
                //    lastStartTime = DateTime.Now;
                //}
            }
        }

        //[Test]
        public void TestWftExtendSession()
        {
            bool bDisplayed, bBeforeTimeout;
            int counter = 1;
            string SgDept = SettingData.SgDept;
            //var homePage = new HomePage(Driver.Instance);

            //Plus
            //homePage.NavigateToFPC();
            //Division.SetPLUSDivisionAndFacility("34222");
            //ContractRates.GoTo();
            //Assert.True(ContractRates.IsAt, "Contract Rates page was not displayed.");

            //Staffing Grid 
            //homePage.NavigateToStaffingGrid();
            //Division.SetStaffingGridDivisionAndFacility();
            //SgMainMenu.SelectGrid();
            //StaffingGridFliterPage.SgFilter()
            //    .withDepartment(string.Empty)
            //    .withStatus("New - Blank")
            //    .withStaffingGrid(string.Empty)
            //    .Create();

            //VF
            //homePage.NavigateToVolumeForecasting();

            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToWorkloadForecaster();

            //Set Division and facility.
            Division.SetWFTDivisionAndFacility();
            WFTMainMenu.WorkloadForecast.DepartmentForecast.SelectDepartmentForecast();

           
            By bySgCreate = By.XPath("//select[@id='ddlwftDepartments']");
            DateTime _desired = DateTime.Now.AddHours(4);
            By byExtendSession = By.XPath("//*/div[@aria-describedby=\"session-timeout-headsup\"]//button[contains(text(),'Extend the Session')]");
            By bySessionTimeout = By.XPath("/*/div[@aria-describedby=\"session-timeout\"]//div[@class=\"ui-dialog-buttonset\"]//button[contains(text(),'OK')]");
            DateTime startTime = DateTime.Now;
            TimeSpan maxDuration = TimeSpan.FromHours(6);
            DateTime lastStartTime = DateTime.Now; // Start the first check time
            while (DateTime.Now - startTime < maxDuration)
            {
                bDisplayed = CommonFunctions.IsElementDisplayed(byExtendSession, 1);
                if (bDisplayed)
                {
                    TimeSpan elapsed = DateTime.Now - lastStartTime;
                    Console.WriteLine($"Extend session button was displayed for {counter++} time after {elapsed.TotalMinutes:F2} minutes.");
                    //Console.WriteLine($"Time: {DateTime.Now}");
                    bBeforeTimeout = getTimeout();
                    if (bBeforeTimeout)
                    {
                        CommonFunctions.getElement(byExtendSession).Click();
                        Console.WriteLine($" Page reload: {TimeItTakesToReloadPage(bySgCreate)}");
                        Console.WriteLine();
                        // Reset the start time for the next loop
                        lastStartTime = DateTime.Now;


                        bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                        if (bDisplayed)
                        {
                            break;
                            CommonFunctions.getElement(bySessionTimeout).Click();
                            elapsed = DateTime.Now - lastStartTime;
                            Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.");

                            // Reset the start time for the next loop
                            lastStartTime = DateTime.Now;
                        }
                    }
                }

                //bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                //if (bDisplayed)
                //{
                //    CommonFunctions.getElement(bySessionTimeout).Click();
                //    TimeSpan elapsed = DateTime.Now - lastStartTime;
                //    Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.");

                //    // Reset the start time for the next loop
                //    lastStartTime = DateTime.Now;
                //}
            }
        }

        private void TestExtendSession(double NumOfHrs)
        {
            bool bDisplayed, bBeforeTimeout;
            int counter = 0;
            By bySgCreate = By.XPath("//select[@id='ddlwftDepartments']");
            DateTime _desired = DateTime.Now.AddHours(4);
            By byExtendSession = By.XPath("//*/div[@aria-describedby=\"session-timeout-headsup\"]//button[contains(text(),'Extend the Session')]");
            By bySessionTimeout = By.XPath("/*/div[@aria-describedby=\"session-timeout\"]//div[@class=\"ui-dialog-buttonset\"]//button[contains(text(),'OK')]");
            DateTime startTime = DateTime.Now;
            TimeSpan maxDuration = TimeSpan.FromHours(NumOfHrs);
            DateTime lastStartTime = DateTime.Now; // Start the first check time
            while (DateTime.Now - startTime < maxDuration)
            {
                bDisplayed = CommonFunctions.IsElementDisplayed(byExtendSession, 1);
                if (bDisplayed)
                {
                    TimeSpan elapsed = DateTime.Now - lastStartTime;
                    Console.WriteLine($"Extend session button was displayed for {counter++} time after {elapsed.TotalMinutes:F2} minutes.");
                    //Console.WriteLine($"Time: {DateTime.Now}");
                    bBeforeTimeout = getTimeout();
                    if (bBeforeTimeout)
                    {
                        CommonFunctions.getElement(byExtendSession).Click();
                        Console.WriteLine($" Page reload: {TimeItTakesToReloadPage(bySgCreate)}");
                        Console.WriteLine();
                        // Reset the start time for the next loop
                        lastStartTime = DateTime.Now;


                        bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                        if (bDisplayed)
                        {
                            break;
                            CommonFunctions.getElement(bySessionTimeout).Click();
                            elapsed = DateTime.Now - lastStartTime;
                            Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.");

                            // Reset the start time for the next loop
                            lastStartTime = DateTime.Now;
                        }
                    }
                }

                //bDisplayed = CommonFunctions.IsElementDisplayed(bySessionTimeout, 1);
                //if (bDisplayed)
                //{
                //    CommonFunctions.getElement(bySessionTimeout).Click();
                //    TimeSpan elapsed = DateTime.Now - lastStartTime;
                //    Console.WriteLine($" Session timeout was displayed after {elapsed.TotalMinutes:F2} minutes.");

                //    // Reset the start time for the next loop
                //    lastStartTime = DateTime.Now;
                //}
            }
        }

        private string TimeItTakesToReloadPage(By byVariable)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            DateTime timeout = DateTime.Now.AddMinutes(15);
            bool isElementEnabled;

            while (DateTime.Now < timeout)
            {
                CommonFunctions.WaitUntilPageIsAcive();
                
                isElementEnabled = CommonFunctions.IsElementDisplayed(byVariable, 1);
                if (isElementEnabled) 
                {
                    stopwatch.Stop();

                    // Get the elapsed time
                    TimeSpan elapsedTime = stopwatch.Elapsed;

                    // Convert the elapsed time to minutes and seconds
                    int minutes = elapsedTime.Minutes;
                    int seconds = elapsedTime.Seconds;

                    return $"The page was reloaded in {minutes} minute(s) and {seconds} second(s)";
                }                
            }
            return null;
        }

        private bool getTimeout()
        {
            Thread.Sleep(2000);
            By byTimeout = By.XPath("//div[@aria-labelledby='ui-dialog-title-session-timeout-headsup' and contains(@style,'block')]//div[@id='session-timeout-headsup']//span[@id='time-left-for-timeout']");
            var iwTimeout = CommonFunctions.getElement(byTimeout);
            string timeText = iwTimeout.Text;

            TimeSpan timeSpan = ConvertToTimeSpan(timeText);
            DateTime timeoutTime = DateTime.Now.Add(timeSpan);
            // Calculate the time that is 20 seconds before the timeout
            DateTime targetTime = timeoutTime.AddMinutes(-6);
            // Loop until the current time is 20 seconds before the timeout
            while (DateTime.Now < targetTime)
            {                
                System.Threading.Thread.Sleep(1000);
                //return true;                
            }
            return true;
        }

        public TimeSpan ConvertToTimeSpan(string timeText)
        {
            string[] timeParts = timeText.Split(':');

            // Parse minutes and seconds
            int minutes = int.Parse(timeParts[0]);
            int seconds = int.Parse(timeParts[1]);

            // Create and return the TimeSpan
            return new TimeSpan(0, minutes, seconds);
        }


        //[Test]
        public void TestReportData()
        {
            string filePath = @"C:\Users\opt6590\Downloads\BiWeeklyStaffingSummary_32801_071525_133750.xls";
            var homePage = new HomePage(Driver.Instance);
            //homePage.NavigateToFPC();
            //var SummaryReportData = BiWeeklyStaffingSummary.ParseStaffingSummaryReport(filePath);
            Console.WriteLine();
        }

        [Test]
        [Category("Plus")]
        public void PlusAndSgInterface()
        {
            bool isMatched, bExists;
            string VariableAndSemiVariableDept = "610";
            string Facility = "34222";
            string currentYear = CommonFunctions.GetCurrentYear();
            string startDate = $"12/01/{currentYear}";
            string newHrsPerUOS; 
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToStaffingGrid();
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();           
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(Facility);
            TargetDetail.GoTo();
            Assert.True(TargetDetail.IsAt, "Productivity Targets page was not displayed.");
            TargetDetail.selectDept(VariableAndSemiVariableDept);
            CommonFunctions.WaitUntilPageIsAcive();
            newHrsPerUOS = TargetDetail.VariableDeptartment.SetHrsPerUosMonth(VariableAndSemiVariableDept);
            Console.WriteLine($"newHrsPerUOS = {newHrsPerUOS}");
            var PLUSTargetMonthFromDeptData = TargetDetail.VariableDeptartment.getHrsPerUOS(VariableAndSemiVariableDept);
            isMatched = string.Equals(newHrsPerUOS, 
                PLUSTargetMonthFromDeptData.Nov.ToString(), 
                StringComparison.InvariantCultureIgnoreCase);
            Assert.True(isMatched, $"newHrsPerUOS = {newHrsPerUOS} \n" +
                $"PLUSTargetMonthFromDeptData.Nov = {PLUSTargetMonthFromDeptData.Nov.ToString()}\n" +
                $"Hrs per UOS for November is not updated in PLus");

            homePage.SwitchToWindow("Staffing Grid");
            Division.SetStaffingGridDivisionAndFacility(Facility);
            SgMainMenu.SelectGrid();
            StaffingGridFliterPage.SgFilter()
                .withDepartment(VariableAndSemiVariableDept)
                .withStatus("New - Blank")
                .withStaffingGrid(string.Empty)
                .Create();
            string SgDescription = $"SG_{CommonFunctions.GenerateRandonNumber()}";
            CommonFunctions.AddTestStep($"Verfiy a user can set SG detail with {SgDescription} and {startDate}", "The SG were created with specific name and date.");
            StaffingGridMainPage.SetStaffingGridDetails(startDate, SgDescription);
            CommonFunctions.WaitUntilPageIsAcive();
            var SumOfSubTotals = StaffingGridMainPage.SetOrientationAndEducation();
            StaffingGridMainPage.SetPLUSTargetMonth("November");
            var StaffingGridMainDetails = StaffingGridMainPage.GetStaffingGridDetails();
            isMatched = string.Equals(StaffingGridMainDetails.VarProdHoursUOS, 
                newHrsPerUOS, 
                StringComparison.InvariantCultureIgnoreCase);
            Assert.True(isMatched, $"StaffingGridMainDetails.VarProdHoursUOS = {StaffingGridMainDetails.VarProdHoursUOS}\n" +
                $"newHrsPerUOS {newHrsPerUOS}\n" +
                $"VarProdHoursUOS in Staffing Grid does not match with the value set in Plus");

        }

        [Test]
        [Category("Plus")]
        public void ContractRatesJourney()
        {
            RunData.AdoTestPlan = "PLUS Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Contract Rates";
            bool isMatched;
            double dOverrideRate = 8.00;
            string RateToUse = "Override";
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            ContractRates.GoTo();
            Assert.True(ContractRates.IsAt, "Contract Rates page was not displayed.");
            ContractRates.ContractRate()
                .withDepartment("601")
                .withSkillMix("161")
                .Add();
            ContractRates.SetContractRatesData(dOverrideRate, RateToUse);
            var ContractRatesData = ContractRates.GetContractRatesData();
            isMatched = string.Equals(ContractRatesData[0].RateToUse, RateToUse, StringComparison.InvariantCultureIgnoreCase);
            Assert.True(isMatched, $"ContractRatesData[0].RateToUse = {ContractRatesData[0].RateToUse}\n" +
                $"RateToUse = {RateToUse}");
            CommonFunctions.AddTestStep("Verify rate to use values", "the rate to use values are correct.");
        }
        
        [Test]
        [Category("Plus")]
        public void SharedRatesJourney()
        {
            bool isMatched;
            double dOverrideRate = 8.00;
            string RateToUse = "Override";
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            SharedRates.GoTo();
            Assert.True(SharedRates.IsAt, "Shared Rates page was not displayed.");
            SharedRates.SharedRate()
                .withDirection("In")
                .withDepartment("601")
                .withSkillMix("10")
                .Add(); 
            SharedRates.SetSharedRatesData(dOverrideRate, RateToUse);
            var SharedRatesData = SharedRates.GetSharedRatesData();
            isMatched = string.Equals(SharedRatesData[0].RateToUse, RateToUse, StringComparison.InvariantCultureIgnoreCase);
            Assert.True(isMatched, $"SharedRatesData[0].RateToUse = {SharedRatesData[0].RateToUse}\n" +
                $"RateToUse = {RateToUse}");
        }

        [Test]
        [Category("Plus")]
        public void DepartmentGroupsJourney()
        {
            RunData.AdoTestPlan = "PLUS Journeys";
            RunData.AdoTestCaseName = "Department Groups Journey";
            string PlanDescription = $"TestingPlan_{CommonFunctions.GenerateRandonNumber()}";
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            DepartmentGroups.GoTo();
            Assert.True(DepartmentGroups.IsAt, "Department Groups page was not displayed.");
            DepartmentGroups.NewGroup()
                .withGroupName(PlanDescription)
                .withKronosSharedOut(false)
                .withDepartmentNumber("610")
                .Save();
            DepartmentGroups.ExistingGroup()
                .withGroupName(PlanDescription)
                .withKronosSharedOut(false)
                .withDepartmentNumber("610")
                .Save();
            //Delete group
            DepartmentGroupsMenu.Delete();
        }


        [Test]
        [Category("Plus")]
        public void StatisticAssignmentDepartmentViewJourney()
        {
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            StatisticAssignment.GoTo();
            Assert.True(StatisticAssignment.IsAt, "Statistic Assignment page was not displayed.");
            StatisticAssignment.DeptartmentView()
                .withDepartment("610")
                .View();
            var StatisticAssignmentForDepartmentData = StatisticAssignment.getStatisticAssignmentForDepartment();
            Console.WriteLine(StatisticAssignmentForDepartmentData.StatisticDescription);

            StatisticAssignment.GroupView()
                .withGroupName("11")
                .withStatisticVolumeBasedOn("One Or More Departments")
                .withStatisticToUse("HOSPITAL APD")
                .View();
            var ExistingDepartmentsInThisGroupData = StatisticAssignment.getExistingDepartmentsInThisGroup();
            Console.WriteLine(ExistingDepartmentsInThisGroupData[0].AssignStatisticVolume);
            Console.WriteLine(ExistingDepartmentsInThisGroupData[0].Department);
        }

        [Test]
        [Category("Plus")]
        public void StatisticDescriptionsJourney()
        {
            bool bExist;
            string NewStatsDescription = $"Testing_{CommonFunctions.GenerateRandonNumber()}".ToUpper();
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            StatisticDescriptions.GoTo();
            Assert.True(StatisticDescriptions.IsAt, "Statistic Descriptions page was not displayed.");
            StatisticDescriptions.SetStatisticDescriptions(NewStatsDescription);
            var StatisticDescriptionsData = StatisticDescriptions.getStatisticDescriptionsData();
            bExist = StatisticDescriptionsData.Exists(x => x.Description.Contains(NewStatsDescription));
            Assert.True(bExist, $"{NewStatsDescription} wasn't found");
        }

        [Test]
        [Category("Plus")]
        public void FacilityOptionsJourney()
        {
            bool bMatched;
            string factorToUse = "Override";
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            FacilityOptions.GoTo();
            Assert.True(FacilityOptions.IsAt, "Facility Options page was not displayed.");
            FacilityOptions.SetOutpatientFactorDataData(factorToUse);
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            var OutpatientFactorDataData = FacilityOptions.GetOutpatientFactorDataData();
            bMatched = string.Equals(OutpatientFactorDataData[1].FactorToUse, factorToUse, StringComparison.InvariantCultureIgnoreCase);
            Assert.True(bMatched, $"OutpatientFactorDataData[1].FactorToUse = {OutpatientFactorDataData[1].FactorToUse}\n" +
                $"factorToUse = {factorToUse}");

            FacilityOptions.StatisticAndTargetAdministration()
                .withTotalOperatingRoomMinutes(true)
                .withTotalAnesthesiaMinutes(true)
                .withTotalFirstAssistMinutes(true)
                .Save();
        }

        [Test]
        [Category("Plus")]
        public void DepartmentOptionsJourney()
        {
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            DepartmentOptions.GoTo();
            Assert.True(DepartmentOptions.IsAt, "Department Options page was not displayed.");
            DepartmentOptions.DeptOptions()
                .withDepartment("610")
                .withDepartmentCategory("Variable")
                .withIgnoreDepartment(false)
                .withAllowStatisticVolumeAdjustment(true)
                .withAllowPLUSSharedOutHourEntry(true)
                .withFreezeDepartmentPAVolumes(false)
                .withContractLaborPercentage("0.0")
                .withFixedNoOfFtes("0.0")
                .Save();
            var DepartmentInformationData = DepartmentOptions.getDepartmentInformationData();
            Console.WriteLine(DepartmentInformationData.UpdatedBy);
        }

        //[Test]
        //[Category("Plus")]
        public void PlusToolsAdministrationJourney()
        {
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");
            PlusToolsAdministration.GoTo();
            Assert.True(PlusToolsAdministration.IsAt, "Plus Tools Administration page was not displayed.");
            PlusToolsAdministration.Task()
                .withAction("Budget Refresh")
                .withJobStatus("Completed")
                .withTask("(C)")
                .ViewTask();
            var TaskSummaryData = PlusToolsAdministration.getTaskSummaryData();
            Console.WriteLine(TaskSummaryData.RequestedBy);

        }

        //[Test]
        //[Category("Plus")]
        public void ImportFileToDailyStatisticVolume()
        {
            string DateToUpdate, newAdjValue;

            string filename = SettingData.StatVolumeFile;
            string NewFileName = SettingData.CopiedStatVolFile;
            string dept = SettingData.StatisticVolDept;
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility();
            StatisticVolumes.GoTo();
            Assert.True(StatisticVolumes.IsAt, "Statistic Volumes page was not displayed.");
            StatisticVolumes.DeptView()
                .withPayPeriod("Current")
                .withDepartment(dept)
                .GetData();
            var StatisticVolumesDeptViewData = StatisticVolumesData.GetStatisticVolumesDeptViewData();
            DateToUpdate = StatisticVolumesDeptViewData[1].Date;
            UpdateToExcel(filename, DateToUpdate);
            ExcelTemplate.CopyFile(filename, NewFileName);
            StatisticVolumes.ClickChooseFile();
            WindowsBasedUI.ChooseFile(NewFileName);
            StatisticVolumes.ClickImportFile();
            CommonFunctions.WaitUntilPageIsAcive();
            StatisticVolumesDeptViewData = StatisticVolumesData.GetStatisticVolumesDeptViewData();
            newAdjValue = StatisticVolumesDeptViewData[1].AdjValue;
            Console.WriteLine(newAdjValue);







        }

        private bool UpdateToExcel(string filename, string inputDate)
        {
            try
            {
                string date = CommonFunctions.FormatDate(inputDate);
                Dictionary<string, string> dic = new Dictionary<string, string>
                {
                    {"C3", date }
                };
                ExcelTemplate.WriteToExcelFile(filename, dic);                
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
