﻿using AdoTestCasePlugin.Dtos;
using AutomationCoreLite.Reporting;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using DocumentFormat.OpenXml.Office2019.Drawing.Diagram12;
using DocumentFormat.OpenXml.Office2019.Excel.RichData2;
using DocumentFormat.OpenXml.Vml;
using DocumentFormat.OpenXml.Wordprocessing;
using IBM.Data.Db2;
using ISAS_Regression_Automation.Utilities;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.CodeAnalysis;
using Microsoft.Office.Interop.Excel;
using Microsoft.VisualBasic;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.AverageLaborRateCL;
using static ISAS_Regression_Automation.FacilityLaborExpenseSummary;
using static ISAS_Regression_Automation.FpcPlan;
using static ISAS_Regression_Automation.FpcPlan.FTEsSummary;
using static ISAS_Regression_Automation.FpcPlan.NonProductivePercentage;
using static ISAS_Regression_Automation.FpcPlan.PlanDetail;
using static ISAS_Regression_Automation.WFTMainMenu.WFTReports;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Path = System.IO.Path;

//[assembly: Parallelizable(ParallelScope.All)]

namespace ISAS_Regression_Automation
{
    [TestFixture]
    public class FpcAdministrationTests: Driver
    {

        [Test]
        public void TestFpcAutoResher()
        {
            bool bDisplayed;
            int counter = 0;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            string filePath = @"C:\Users\opt6590\OneDrive - HCA Healthcare\Desktop\WF SPs\FPC_AUTO_Refresh_Batch_Calculated_Plan_0505.xlsx";
            string resultFilePath = @"C:\Users\opt6590\OneDrive - HCA Healthcare\Desktop\WF SPs\FpcOutput\FpcAutoRefreshResult.txt";
            var lstFpcExcelRecords = FpcAutoFreshParser.Parse(filePath);

            By byExtendSession = By.XPath("//*/div[@class='ui-dialog-buttonset']//span[contains(text(),'Extend the Session')]");
            By bySessionTimeout = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-session-timeout' and contains(@style,'display: block')]//span[contains(text(),'OK')]");



            //Delete an existing result text file
            CommonFunctions.DeleteFile(resultFilePath);
            
            homePage.NavigateToFPC();

            foreach (var record in lstFpcExcelRecords)
            {
                try
                {
                    counter++;
                    //Set Division and facility.
                    Division.SetPLUSDivisionAndFacility(record.FacilityName);

                    //Create a new FPC Plan
                    FPCMainMenu.FPC.SelectPlan();
                    Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");

                    FpcPlanFilter.PlanFilter()
                          .withDepartment(record.DeptNum.Trim())
                          .withPlanStatus("Approved")
                          .withPlan(string.Empty)
                          .ViewPlan();
                    CommonFunctions.WaitUntilPageIsAcive();

                    var PlanViewSummary = FpcPlan.GetPlanViewSummary();
                    if (string.Equals(record.PlanId, PlanViewSummary.PlanID, StringComparison.InvariantCultureIgnoreCase))
                    {

                        var FteSummary = FTEsSummary.GetFTEsSummary();
                        var OverrideMinFTEsAndHoursUOS = FpcPlan.getOverrideMinFTEsAndHoursUOS();
                        verifyFpcData(record, OverrideMinFTEsAndHoursUOS, FteSummary, resultFilePath);
                    }
                    //Extend session if session timeout dialog displayed.
                    bDisplayed = CommonFunctions.IsElementDisplayed(byExtendSession, 1);
                    if (bDisplayed)
                    {
                        CommonFunctions.getElement(byExtendSession).Click();

                    }
                }
                catch
                {
                    Console.WriteLine($"last row number was tested : {counter.ToString()}");
                }
            }
        }

        private void verifyFpcData(FpcAutoFreshRecord record, OverrideMinFTEsAndHoursUOS overridFte, clFTEsSummary fteSummary, string resultFilePath)
        {
            if(record.ProductiveMinFtesTarget_MinFtes != CommonFunctions.ToDouble(overridFte.ProductiveMinFTEsTarget,3))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.ProductiveMinFtesTarget_MinFtes}, {overridFte.ProductiveMinFTEsTarget}");
            }
            if (record.ProductiveMinFtesOverride_OvrMinFtes != CommonFunctions.ToDouble(overridFte.ProductiveMinFTEsOverride, 3))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.ProductiveMinFtesOverride_OvrMinFtes},  {overridFte.ProductiveMinFTEsOverride}");
            }
            if (record.ProductiveHoursUosTarget_HrsUos != CommonFunctions.ToDouble(overridFte.ProductiveHoursUOSTarget, 3))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.ProductiveHoursUosTarget_HrsUos}, {overridFte.ProductiveHoursUOSTarget}");
            }
            if (record.ProductiveHoursUosOverride_OvrHrsUos != CommonFunctions.ToDouble(overridFte.ProductiveHoursUOSOverride, 3))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.ProductiveHoursUosOverride_OvrHrsUos} , {overridFte.ProductiveHoursUOSOverride}");
            }

            if (record.TotalTargetPaidFtesCore_CorePaidFtes != CommonFunctions.ToDouble(fteSummary.TotalTargetPaidFTEsCore))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.TotalTargetPaidFtesCore_CorePaidFtes} , {fteSummary.TotalTargetPaidFTEsCore}");

            }

            if (record.TotalTargetPaidFtesAverage_AvgPaidFtes != CommonFunctions.ToDouble(fteSummary.TotalTargetPaidFTEsAverage))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.TotalTargetPaidFtesAverage_AvgPaidFtes} , {fteSummary.TotalTargetPaidFTEsAverage}");

            }
            if (record.TotalTargetPaidFtesPeak_PeakPaidFtes != CommonFunctions.ToDouble(fteSummary.TotalTargetPaidFTEsPeak))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.TotalTargetPaidFtesPeak_PeakPaidFtes} , {fteSummary.TotalTargetPaidFTEsPeak}");

            }
            if (record.TotalTargetProductiveFtesCore_CoreProdFtes != CommonFunctions.ToDouble(fteSummary.TotalTargetProductiveFTEsCore))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.TotalTargetProductiveFtesCore_CoreProdFtes} , {fteSummary.TotalTargetProductiveFTEsCore}");
            }
            if (record.TotalTargetProductiveFtesAverage_AvgProdFtes != CommonFunctions.ToDouble(fteSummary.TotalTargetProductiveFTEsAverage))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.TotalTargetProductiveFtesAverage_AvgProdFtes} , {fteSummary.TotalTargetProductiveFTEsAverage}");
            }
            if (record.TotalTargetProductiveFtesPeak_PeakProdFtes != CommonFunctions.ToDouble(fteSummary.TotalTargetProductiveFTEsPeak))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.TotalTargetProductiveFtesPeak_PeakProdFtes} , {fteSummary.TotalTargetProductiveFTEsPeak}");

            }
            if (record.CalendarBusinessDayAverageVolumeCore_CoreVol != CommonFunctions.ToDouble(fteSummary.AverageDailyVolumeCore))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.CalendarBusinessDayAverageVolumeCore_CoreVol} , {fteSummary.AverageDailyVolumeCore}");
            }
            if (record.CalendarBusinessDayAverageVolumeAverage_AvgVol != CommonFunctions.ToDouble(fteSummary.AverageDailyVolumeAverage))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.CalendarBusinessDayAverageVolumeAverage_AvgVol} , {fteSummary.AverageDailyVolumeAverage}");
            }
            if (record.CalendarBusinessDayAverageVolumePeak_PeakVol != CommonFunctions.ToDouble(fteSummary.AverageDailyVolumePeak))
            {
                CommonFunctions.WriteToFile(resultFilePath, $"{record.CoId}, {record.DeptNum} , {record.CalendarBusinessDayAverageVolumePeak_PeakVol} , {fteSummary.AverageDailyVolumePeak}");

            }
        }

        [Test]
        [Category("FPC")]
        public void VerifyStepSelectedNotAllowedDialog()
        {            
            string FpcDept = "600";
            bool bErrDisplayed, bRecordResoted, bNewEmpAdded;
            //string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility("34222");
            FpcAdministration.GoTo();
            Assert.True(FpcAdministration.IsAt, "FPC Administration page was not displayed");
            AdminFacilityOptions.FacilityOptions()
                .withFreezeFPCAdministration("No")
                .Save();
            AdminDepartmentOptions.DepartmentFilter()
                .withFrom(FpcDept)
                .withTo(FpcDept)
                .View();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed(deptOptionXpath, 15);
            AdminDepartmentOptions.DepartmentOption(FpcDept)
                .withVariance("0.50")
                .withSetDepartmentLevelCoreAndPeakRules(true)
                .withCoreRulesByDailyAverage("Lowest UOS Month")
                .withPeakRulesByDailyAverage("Highest UOS Month")
                .withCalculateDailyAverageVolumesBasedOn("Calendar Days")
                .withAllowSelectableTargetMonth(false)
                .withDefaultTargetMonth("Current Month")
                .withOverrideHrsuos(false)
                .withOverrideProductiveMinimumHours(false)
                .withOverrideMonthlyTargetedSemiVariableProductiveFtes(true)
                //.withIncludeAllInactiveEmployeesInFtesCalculation(true)
                .withUseCurrentActualVolumesForCalculatingFtesInApprovedPlans(false)
                .withAllowSavingIfCoreFtesAreOverAllowableFTEVariance("Yes")
                .withVolumeBudget(true)
                .withVolumeHistorical(true)
                .withVolumeOverride(true)
                .withNonproductiveTarget(true)
                .withNonproductiveHistorical(true)
                .withNonproductiveOverride(true)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("All")
                .withPlan(string.Empty)
                .ViewPlan();
            var SemiVariableSteps = FpcPlan.getSemiVariableSteps();
            if (SemiVariableSteps.Count > 1)
            {
                CommonFunctions.SetCheckbox(SemiVariableSteps[2].Average, true);
                CommonFunctions.SetCheckbox(SemiVariableSteps[1].Peak, true);
                var bAllowed = FpcPlan.IsStepSelectedNotAllowed();
                Assert.True(bAllowed, "Step Selected Not Allowed dialog was not displayed.");
            }
        }

        [Test]
        [Category("FPC")]
        public void VerifyOverrideMinFTEsAndHoursUOSJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Override Min FTEs and Hours UOS Journey";
            FpcAdministationOption();

        }

        //[Test]
        //[Category("FPC")]
        //public void VerifyFPCSemiVariableStepsJourney()
        //{
        //    RunData.AdoTestPlan = "FPC Journeys";
        //    RunData.AdoTestCaseName = "Verify FPC SemiVariable Steps Journey";
        //    FpcAdministationOption();

        //}


        public void FpcAdministationOption()
        {
            string TargetMonth;
            bool bErrMsg;
            By byTargetMonth = By.XPath("//select[@class='setTargetMonthId' and not (@disabled)]");
            bool bMatched, bRecordResoted, bNewEmpAdded;
            string FpcDept = "712";
            string FpcFacility = "34222";
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            FpcAdministration.GoTo();
            Assert.True(FpcAdministration.IsAt, "FPC Administration page was not displayed");
            AdminFacilityOptions.FacilityOptions()
                .withFreezeFPCAdministration("No")
                .Save();
            AdminDepartmentOptions.DepartmentFilter()
                .withFrom(FpcDept)
                .withTo(FpcDept)
                .View();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed(deptOptionXpath, 15);
            string CoreRule = "Lowest UOS Month";
            string PeakRule = "Highest UOS Month";
            string CalendarBusinessDaysSelected = "Calendar";
            AdminDepartmentOptions.DepartmentOption(FpcDept)
                .withVariance("0.50")
                .withSetDepartmentLevelCoreAndPeakRules(true)
                .withCoreRulesByDailyAverage(CoreRule)
                .withPeakRulesByDailyAverage(PeakRule)
                .withCalculateDailyAverageVolumesBasedOn(CalendarBusinessDaysSelected)
                .withAllowSelectableTargetMonth(true)
                .withDefaultTargetMonth("Current Month")
                .withOverrideHrsuos(true)
                .withOverrideProductiveMinimumHours(true)
                .withOverrideMonthlyTargetedSemiVariableProductiveFtes(true)
                //.withIncludeAllInactiveEmployeesInFtesCalculation(true)
                .withUseCurrentActualVolumesForCalculatingFtesInApprovedPlans(true)
                .withAllowSavingIfCoreFtesAreOverAllowableFTEVariance("Yes")
                .withVolumeBudget(true)
                .withVolumeHistorical(true)
                .withVolumeOverride(true)
                .withNonproductiveTarget(true)
                .withNonproductiveHistorical(true)
                .withNonproductiveOverride(true)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanMenu.Save();
            //Wait 5 sec to make sure the numbers loaded correctly. 
            Thread.Sleep(5000);
            CommonFunctions.WaitUntilPageIsAcive();
            var ProductiveMinFTEsOverride = CommonFunctions.IsElementDisplayed("//*/input[@id='overrideMinFtes' and not (@readonly)]", 2);
            CommonFunctions.AddTestStep("Verify Productive Min FTEs Override is enabled ", "Productive Min FTEs Override is enabled");
            Assert.True(ProductiveMinFTEsOverride, "ProductiveMinFTEsOverride ");
            var ProductiveHoursUOSOverride = CommonFunctions.IsElementDisplayed("//*/input[@id='overrideHoursPerUos' and not (@readonly)]", 2);
            CommonFunctions.AddTestStep("Verify Productive Hours UOS Override is enabled ", "Productive Hours UOS Override is enabled");
            Assert.True(ProductiveHoursUOSOverride, "ProductiveHoursUOSOverride ");
            var OverrideMonthlyTargetProductiveFtes = CommonFunctions.IsElementDisplayed("//*/div[@id='semiVariableStepsSummary']//table/tbody//tr/td[4]/input[not (readonly)]", 5);
            Assert.True(OverrideMonthlyTargetProductiveFtes, "OverrideMonthlyTargetProductiveFtes ");
            CommonFunctions.AddTestStep("Verify Override Monthly Target Productive Ftes is enabled ", "Override Monthly Target Productive Ftes is enabled");
            var bTargetMonthEnabled = CommonFunctions.IsElementDisplayed(byTargetMonth, 2);
            CommonFunctions.AddTestStep("Verify Target Month is enabled ", "Target Month is enabled");
            Assert.True(bTargetMonthEnabled, "TargetMonth is disabled.");

            var PlanSummary = FpcPlan.GetPlanViewSummary();
            bMatched = PlanSummary.CoreBusinessRule.Contains(CoreRule);
            CommonFunctions.AddTestStep($"Verfiy that core rule {CoreRule} is displayed", $"The core role: {CoreRule} exists");
            Assert.True(bMatched, "CoreBusinessRule ");
            bMatched = PlanSummary.PeakBusinessRule.Contains(PeakRule);
            CommonFunctions.AddTestStep($"Verfiy that peak rule {PeakRule} is displayed", $"The peak rule: {PeakRule} exists");
            Assert.True(bMatched, "PeakBusinessRule ");
            //verify lbl contains either calendar or business day text. 
            By lblCalendarBusiness = By.XPath("//input[@title='Average of Month’s Volume / Number of Calendar Days in Month']");
            var lblCalendarBusinessText = CommonFunctions.getElement(lblCalendarBusiness).GetAttribute("value");
            bMatched = lblCalendarBusinessText.Contains(CalendarBusinessDaysSelected);
            CommonFunctions.AddTestStep("Verify that calendar/business text exists", "The calendar/business text exists.");
            Assert.True(bMatched, $"{CalendarBusinessDaysSelected} was not found in the FTEs summary");

            var UsedVolumeData = FpcPlan.Volume.UsedVolume.getUsedVolumeData();
            // get month's names for core and peak
            var CoreMonth = CommonFunctions.GetItemRankInList(UsedVolumeData,CoreRule );           
            var PeakMonth = CommonFunctions.GetItemRankInList(UsedVolumeData, PeakRule);            
            var CoreUsedVolume = CommonFunctions.getMonthValueFromMonthlyObject(UsedVolumeData, CoreMonth);
            var PeakUsedVolume = CommonFunctions.getMonthValueFromMonthlyObject(UsedVolumeData, PeakMonth);
            Console.WriteLine($"The core rule: {CoreRule} = {CoreMonth} == {CoreUsedVolume}");
            Console.WriteLine($"The peak rule: {PeakRule} = {PeakMonth} == {PeakUsedVolume}");
            var BusinessCalendarDaysData = FpcPlan.Volume.AvgDailyVolume.getBusinessCalendarDaysData();
            var CoreDailyAvgDays = CommonFunctions.getMonthValueFromMonthlyObject(BusinessCalendarDaysData, CoreMonth);
            var PeakDailyAvgDays = CommonFunctions.getMonthValueFromMonthlyObject(BusinessCalendarDaysData, PeakMonth);
            Console.WriteLine($"The Daily average: Core days, Peak days = {CoreDailyAvgDays} , {PeakDailyAvgDays}");
            var Core = Math.Round(CoreUsedVolume / CoreDailyAvgDays, 2);
            Console.WriteLine($"Core: {Core}");
            var Peak = Math.Round(PeakUsedVolume / PeakDailyAvgDays, 2);
            Console.WriteLine($"Peak: {Peak}");

            //Verify with Peak and core value in UI
            var FTEsSummaryData = FpcPlan.FTEsSummary.GetFTEsSummary();
            bMatched = Core == CommonFunctions.ToDouble(FTEsSummaryData.AverageDailyVolumeCore);
            Assert.That( bMatched, $"Core values didn't match\n" +
                $"{Core} -- {FTEsSummaryData.AverageDailyVolumeCore}" );
            bMatched = Peak == CommonFunctions.ToDouble(FTEsSummaryData.AverageDailyVolumePeak);
            Assert.That(bMatched, $"Peak values didn't match\n" +
                $"{Peak} -- {FTEsSummaryData.AverageDailyVolumePeak}");

            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.AddTestStep("Click the next step button", "The plan detail page is loaded");
            CommonFunctions.WaitUntilPageIsAcive();
            //In case there is any previous errors
            FpcPlanMenu.UpdateReqInfo();
            //Submit a plan
            FpcPlanMenu.Submit();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Submit the current plan", "The plan is submitted");
            //Approve a plan
            string ApprovedComment = "Approving paln";
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
            CommonFunctions.AddTestStep("Approve the plan", "The plan is approved");
        }

        [Test]
        public void TestDb2Connection()
        {
            try
            {
                Console.WriteLine($"DLL: {typeof(DB2Connection).Assembly.Location}");
                Console.WriteLine($"Runtime: {System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture}");

                var conn = new DB2Connection(
                    $"Server=dsnt.es.medcity.net:446;Database=DSNT;Uid={RunData.UserName};Pwd={RunData.Password};");
                conn.Open();
                Console.WriteLine("Connected!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        [Test]
        [Category("FPC")]
        public void VerifyFpcContractLaborJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Contract Labor tab";
            bool bMatched;
            string expectedBackgroundColor = "rgba(147, 252, 110, 1)";
            var Db2Data = Db2DataService.GetFacilityAndDeptList();

            string FpcDept = Db2Data[0].DeptNum;
            string FpcFacility = Db2Data[0].CoId;
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("Approved")
                .withPlan(string.Empty)
                .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcContractLabor.GoTo();
            Assert.True(FpcContractLabor.IsAt, "Contract labor page was not loaded");
            var ContractLaborData = FpcContractLabor.GetContractLaborData();
            if (ContractLaborData != null)
            {
                var lstPositionType = ContractLaborData.Where(x => x.PositionType.Contains("International")).ToList();
                if(lstPositionType.Count() > 0)
                {
                    CommonFunctions.AddTestStep("Verify the green color for 'international' text", "The green color was displayed");
                    bMatched= string.Equals(lstPositionType[0].PositionTypeBackgroundColor, expectedBackgroundColor, StringComparison.OrdinalIgnoreCase);
                    Assert.True(bMatched, "The position type background color was not green");
                }
            }
        }

        [Test]
        [Category("FPC")]
        public void ReaddedBlueLineUsesOpenedDateForHiredInDate()
        {
            bool bMatched;
            string FpcDept = "604";
            string FpcFacility = "30930";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("Approved")
                .withPlan(string.Empty)
                .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            var PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabElementsBlueLinesWithRequisitionStatus("Approved"); 
            if(PlanDetailTabData.Count > 0)
            {
                CommonFunctions.AddTestStep("Verify the requisition status for blue line", "The requisition status is approved");
                var HiredInDateBeforeDeleting = PlanDetailTabData[0].HiredInDate.GetAttribute("value");
                var RequistionNumber = PlanDetailTabData[0].ReqNumber.GetAttribute("value");
                PlanDetailTab.DeleteExistingRequisition(RequistionNumber);

                RequisitionsTab.GoTo();
                Assert.True(RequisitionsTab.IsAt, "Requistion tab was not displayed");
                var RequisitionTabData = RequisitionsTab.getRequistionTabData(RequistionNumber);
                CommonFunctions.AddTestStep($"Get data from the Requisition tab for {RequistionNumber}", "data is captured");
                var OpenDate = RequisitionTabData[0].Opened;

                PlanDetailTab.GoTo();
                Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
                PlanDetailTab.AddMissingReqisition();
                var UserAddedRowAfterAddingMissingRequisition = PlanDetailTab.GetPlanDetailTabElementsBlueLinesWithRequisitionNumber(RequistionNumber);
                var UserAddedRowAfterAddingMissingRequisitionHiredInDate = UserAddedRowAfterAddingMissingRequisition[0].HiredInDate.GetAttribute("value");
                Console.WriteLine($"x = {UserAddedRowAfterAddingMissingRequisitionHiredInDate}");
                var RequisitionTabDataOpenedDate= RequisitionTabData[0].Opened;
                Console.WriteLine($"y = {RequisitionTabDataOpenedDate}");
                bMatched = string.Equals(UserAddedRowAfterAddingMissingRequisitionHiredInDate, 
                    RequisitionTabDataOpenedDate, 
                    StringComparison.OrdinalIgnoreCase);
                Assert.That(bMatched, "The hired in date after adding missing requisition is not same as open date in requisition tab\n" +
                    $"RequisitionTabData[0].Opened = {RequisitionTabDataOpenedDate}\n" +
                    $"UserAddedRowAfterAddingMissingRequisition[0].HiredInDate = {UserAddedRowAfterAddingMissingRequisitionHiredInDate}");


            }
            

        }

        [Test]
        [Category("FPC")]
        public void Verify​​AddingPendingHireName​()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "​Add Pending Hire Name Journey";
            bool bMatched;
            string FpcDept = "613";
            string FpcFacility = "34222";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("Approved")
                .withPlan(string.Empty)
                .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            var PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabElementsBlueLines();
            RequisitionsTab.GoTo();
            Assert.True(RequisitionsTab.IsAt, "Requistion tab was not displayed");
            var RequisitionTabData = RequisitionsTab.getRequistionTabData();
            CommonFunctions.AddTestStep("Get all Pending Hire data from the Requisition tab", "All Pending Hire data are captured");

            // Replacing name doesn't exist
            var PendingHireReqsWithoutReplacingName = RequisitionTabData
                .Where(row => string.Equals(row.ReqStatus, "Pending Hire", StringComparison.OrdinalIgnoreCase) &&
                        string.IsNullOrEmpty(row.ReplacingName))
                .ToList();

            Console.WriteLine($"PendingHireReqsWithoutReplacingName = {PendingHireReqsWithoutReplacingName.Count.ToString()}");

            // Replacing name exists 
            var PendingHireReqsWithReplacingName = RequisitionTabData
                .Where(row => string.Equals(row.ReqStatus, "Pending Hire", StringComparison.OrdinalIgnoreCase) &&
                        !string.IsNullOrWhiteSpace(row.ReplacingName))
                .ToList();

            Console.WriteLine($"PendingHireReqsWithReplacingName {PendingHireReqsWithReplacingName.Count.ToString()}");

            //Get rows where Pending Hire doesn't exist and Replacing name exists
            var ReplacingNameWithoutPendingName = RequisitionTabData
               .Where(row => !string.IsNullOrWhiteSpace(row.ReplacingName) &&
                        string.IsNullOrWhiteSpace(row.PendingName))
               .ToList();
            Console.WriteLine($"ReplacingNameWithoutPendingName = {ReplacingNameWithoutPendingName.Count.ToString()}");

            //Pending Hire without Replacing name
            if (PendingHireReqsWithoutReplacingName.Count > 0)
            {
                
                PlanDetailTab.GoTo();
                Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
                PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabElementsBlueLinesIncludingActiveAndInactive();
                CommonFunctions.AddTestStep("Verify the pending hire name", "The pending hire name was displayed correctly");
                var PendingHirePlanDetail = PlanDetailTabData
                    .Where(row => string.Equals(row.ReqNumber.GetAttribute("value"), PendingHireReqsWithoutReplacingName[0].GHRReqs, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                var PendingNameExistInNotes = PendingHirePlanDetail[0].Notes.GetAttribute("value")
                    .Contains(PendingHireReqsWithoutReplacingName[0].PendingName, StringComparison.OrdinalIgnoreCase) &&
                    PendingHirePlanDetail[0].Notes.GetAttribute("value").Contains("PENDING:");
                Assert.True(PendingNameExistInNotes, "The pending hire name was not displayed correctly");

                CommonFunctions.AddTestStep("Verify First and Last names are empty", "First and last name were populated");
                var bFirstNameAndLastNameNotEmpty = PendingHirePlanDetail[0].LastName.GetAttribute("value") == string.Empty &&
                    PendingHirePlanDetail[0].FirstName.GetAttribute("value") == string.Empty;
                Assert.True(bFirstNameAndLastNameNotEmpty, "The first name and last name were not empty");                               
            }

            //Pending Hire with Replacing name             
            if (PendingHireReqsWithReplacingName.Count > 0)
            {                
                PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabElementsBlueLinesIncludingActiveAndInactive();
                CommonFunctions.AddTestStep("Verify the pending hire name with replacing name", "The pending hire name was displayed correctly");
                var PendingHirePlanDetail2 = PlanDetailTabData
                    .Where(row => string.Equals(row.ReqNumber.GetAttribute("value"), PendingHireReqsWithReplacingName[0].GHRReqs, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                var PendingNameExistInNotes = PendingHirePlanDetail2[0].Notes.GetAttribute("value")
                    .Contains(PendingHireReqsWithReplacingName[0].PendingName, StringComparison.OrdinalIgnoreCase) &&
                    PendingHirePlanDetail2[0].Notes.GetAttribute("value").Contains("PENDING:");
                Assert.True(PendingNameExistInNotes, "The pending hire name was not displayed correctly");

                var arrReplacingName = PendingHireReqsWithReplacingName[0].ReplacingName.Split(',');
                string LastName = arrReplacingName[0].Trim();
                var arrFirstName = arrReplacingName[1].Trim().Split(' ');
                string FirstName = arrFirstName[0].Trim();

                CommonFunctions.AddTestStep("Verify First and Last names are populated", "First and last name were empty");
                string x = PendingHirePlanDetail2[0].LastName.GetAttribute("value");

                var bFirstNameAndLastNameEmpty = string.Equals(PendingHirePlanDetail2[0].LastName.GetAttribute("value"), LastName, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(PendingHirePlanDetail2[0].FirstName.GetAttribute("value"), FirstName, StringComparison.OrdinalIgnoreCase);
                Assert.True(bFirstNameAndLastNameEmpty, "The first name and last name were not empty");

                //verify the tooltip
                var bReplacingEinInTooltip = PendingHirePlanDetail2[0].Notes.GetAttribute("title")
                    .Contains(PendingHireReqsWithReplacingName[0].ReplacingNameEIN, StringComparison.OrdinalIgnoreCase) &&
                    PendingHirePlanDetail2[0].Notes.GetAttribute("title").Contains("Replacing EIN:", StringComparison.OrdinalIgnoreCase);
                Assert.True(bReplacingEinInTooltip, $"The tooltip didn't include replacing name EIN");



            }

            //Verify Replacing name  exist, but Pending Hire name doesn't exist           
            if (ReplacingNameWithoutPendingName.Count > 0)
            {
                PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabElementsBlueLinesIncludingActiveAndInactive();
                CommonFunctions.AddTestStep("Verify replacing name", "The replacing name wasn't displayed correctly");
                var ReplacingNamePlanDetail = PlanDetailTabData
                    .Where(row => string.Equals(row.ReqNumber.GetAttribute("value"), ReplacingNameWithoutPendingName[0].GHRReqs, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                var ReplacingNameExistInNotes = ReplacingNamePlanDetail[0].Notes.GetAttribute("value")
                    .Contains(ReplacingNameWithoutPendingName[0].ReplacingName, StringComparison.OrdinalIgnoreCase) &&
                    ReplacingNamePlanDetail[0].Notes.GetAttribute("value").Contains("REPLACING:");
                Assert.True(ReplacingNameExistInNotes, "The replacing name was not displayed correctly");

                CommonFunctions.AddTestStep("Verify First and Last names are populated", "First and last name were empty");
                var arrReplacingName = ReplacingNameWithoutPendingName[0].ReplacingName.Split(',');
                string LastName = arrReplacingName[0].Trim();
                var arrFirstName = arrReplacingName[1].Trim().Split(' ');
                string FirstName = arrFirstName[0].Trim();
                var bFirstNameAndLastNameEmpty = string.Equals(ReplacingNamePlanDetail[0].LastName.GetAttribute("value"), LastName, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(ReplacingNamePlanDetail[0].FirstName.GetAttribute("value"), FirstName, StringComparison.OrdinalIgnoreCase);
                Assert.True(bFirstNameAndLastNameEmpty, "The first name and last name were empty");
            }
        }

        [Test]
        [Category("FPC")]
        public static void VerifyFpcSemiVariableStepsJourney()
        {
            RunData.AdoTestPlan = "WFT Journeys";
            RunData.AdoTestCaseName = "Verify FPC SemiVariable Steps Journey";
            bool bErrMsg, bMatched;
            string FpcDept = SettingData.FacStatMappingSemiVariableDept;// "610";
            string FpcFacility = AdoTestData.Facility;// "30927";
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();            
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);

            FpcAdministration.GoTo();
            Assert.True(FpcAdministration.IsAt, "FPC Administration page was not displayed");
            AdminFacilityOptions.FacilityOptions()
                .withFreezeFPCAdministration("No")
                .Save();
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");

            var tblSemiVariableSteps = FpcPlan.getSemiVariableSteps();
            if (tblSemiVariableSteps.Count <= 1)
            {
                CommonFunctions.AddTestStep("Add target steps to dept in Plus", "Target steps are added.");
                string monthDigit = CommonFunctions.GetNextMonth();
                Console.WriteLine($"Next month digit = {monthDigit}");
                AddStepsToPlusProductivityTargets(FpcFacility, FpcDept, monthDigit);
                CommonFunctions.AddTestStep("Navigate to FPC", "FPC page is loaded");
                homePage.SwitchToWindow("ISAS Portal");
                homePage.SwitchToWindow("FPC");
                FPCMainMenu.FPC.SelectPlan();
                Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
               if(!FpcPlanFilter.PlanFilter()
                    .withDepartment(FpcDept)
                    .withPlanStatus("Working")
                    .withPlan(string.Empty)
                    .IsPlanTypeExist())                
                {
                    FpcPlanFilter.PlanFilter()
                        .withDepartment(FpcDept)
                        .withPlanStatus("New")
                        .withPlan(string.Empty)
                        .EditPlan();
                }
                CommonFunctions.WaitUntilPageIsAcive();
            }
            CommonFunctions.AddTestStep("Get all steps in the semi-variable table", "All steps are noted.");
            tblSemiVariableSteps = FpcPlan.getSemiVariableSteps();
            Console.WriteLine($"tblSemiVariableSteps count = {tblSemiVariableSteps.Count.ToString()}");
            if (tblSemiVariableSteps.Count > 1)
            {
                CommonFunctions.AddTestStep("Verify error message", "Error msg was displayed correctly.");
                tblSemiVariableSteps[0].Core.Click();
                tblSemiVariableSteps[0].Average.Click();
                tblSemiVariableSteps[0].Peak.Click();


                tblSemiVariableSteps[2].Core.Click();
                bErrMsg = FpcPlan.IsStepSelectedNotAllowed();
                Assert.True(bErrMsg, "Error message wasn't dispayed");
                tblSemiVariableSteps[0].Core.Click();
            }
            FpcPlanMenu.Save();
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            TargetDetail.GoTo();
            Assert.True(TargetDetail.IsAt, "Productivity Targets page was not displayed.");            
            TargetDetail.VariableDeptartment.SetNpPercentData();
            var TargetNPPercentDetails = TargetDetail.VariableDeptartment.getTargetNPPercent(FpcDept);
            homePage.SwitchToWindow("FPC");
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            var NpPercentTargetData = Target.getTragetData();
            bMatched = CommonFunctions.CompareDataObjects(NpPercentTargetData, TargetNPPercentDetails);
            Assert.True(bMatched, "NP perent target did not interface correctly between FPC and PLUS");
        }


        private static void AddStepsToPlusProductivityTargets(string Fac, string Dept, string Month)
        {
            
            var homePage = new HomePage(Driver.Instance);
            homePage.SwitchToWindow("ISAS Portal");
            homePage.NavigateToPLUS();
            homePage.SwitchToWindow("PLUS");
            Division.SetPLUSDivisionAndFacility(Fac);
            TargetDetail.GoTo();
            Assert.True(TargetDetail.IsAt, "Productivity Targets page was not displayed.");
            TargetDetail.selectDept(Dept);
            var steps = TargetDetail.SemiVariableDepartment.AddSteps(Month);
            
        }
        public void TestReq()
        {
            string FpcDept = "780";
            string FpcFacility = "34222";
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);

            string fpcDept = "780";
            FpcPlanFilter.PlanFilter()
                  .withDepartment(fpcDept)
                  .withPlanStatus(string.Empty)
                  .withPlan(string.Empty)
                  .ViewPlan();
            CommonFunctions.WaitUntilPageIsAcive();

            var lstFpcDepts = FpcPlanFilter.GetAllDepts();
            var (Previous, Next) = CommonFunctions.GetPreviousAndNextItemsInList<string>(lstFpcDepts, fpcDept);
            FpcPlanFilter.ClickNext();
            var currentDept = FpcPlanFilter.getCurrentDeptValue();
            Assert.True(string.Equals(currentDept,Next, StringComparison.OrdinalIgnoreCase),
                $"Next button is not working. Next {Next}, Current dept {currentDept}");

            FpcPlanFilter.PlanFilter()
                  .withDepartment(fpcDept)
                  .withPlanStatus(string.Empty)
                  .withPlan(string.Empty)
                  .ViewPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.ClickPrevious();
            currentDept = FpcPlanFilter.getCurrentDeptValue();
            Assert.True(string.Equals(currentDept, Previous, StringComparison.OrdinalIgnoreCase),
                $"Previous button is not working. Previou {Previous}, Current dept {currentDept}");





            //Get all requistions            
            RequisitionsTab.GoTo();
            Assert.True(RequisitionsTab.IsAt, "Requistion tab was not displayed");
            var RequistionTabData = RequisitionsTab.getRequistionTabData();
            var requisitionNumbers = RequistionTabData
                .Where(row => row.OpenFTE <=0.01m || row.OpenFTE > 0.30m)
                .Select(row => row.GHRReqs)
                .ToList();
            var reqNum = requisitionNumbers[0];
            Console.WriteLine($"reqNum {reqNum}"); 

            //Navigate to view plan detail page
            // FpcPlanFilter.ViewPlanDetail();
            //CommonFunctions.WaitUntilPageIsAcive();
            PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            //Modify existing record and verify erros in the req tab. 
            PlanDetailTab.ModifyExistingDeptPlanDetail(reqNum);

            CommonFunctions.WaitUntilPageIsAcive();
            RequisitionsTab.GoTo();
            Assert.True(PlanDetail.RequisitionsTab.IsAt, "Requisition table was not displayed.");
            var bErrDisplayed = PlanDetail.RequisitionsTab.VerifyShiftErrorInRequistion(reqNum);
            Assert.True(bErrDisplayed, "Shift error was not displayed");
            PlanDetail.PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            FpcPlanMenu.UpdateReqInfo();
            var isInactiveEmpBlueLines = PlanDetail.PlanDetailTab.IncludeInactiveEmpInDeptPlanDetailBlueLines();
            Assert.True(isInactiveEmpBlueLines, "Include inactive values didn't match with subtotals");

            //delete a record
            reqNum = PlanDetail.PlanDetailTab.DeleteExistingDeptPlanDetail();
            PlanDetail.RequisitionsTab.GoTo();
            Assert.True(PlanDetail.RequisitionsTab.IsAt, "Requisition table was not displayed.");
            Assert.True(PlanDetail.RequisitionsTab.VerifyDeletionErrorInRequistion(reqNum),
                "Deleting error was not displayed in the req tab");
            PlanDetailTab.GoTo();
            Assert.True(PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            FpcPlanMenu.AddMissingReqs();
            var PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabElementsBlueLines();
            var  bRecordResoted = PlanDetailTabData.Exists(x => string.Equals(x.ReqNumber.GetAttribute("value"), reqNum, StringComparison.InvariantCultureIgnoreCase));


            Assert.True(bRecordResoted, $"Record with req number {reqNum} was not added back");
        }


        [Test]
        [Category("FPC"), Category("SmokeTest")]
        public void VerifyDepartmentOptionsInFpcAdministrationJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Department options in FPC Administration Journey";
            bool bPRN;
            string reqNum;
            string fName = "Sam";
            string lName = "Smith";
            bool bErrDisplayed, bRecordResoted, bNewEmpAdded, bPlanExist, bExist;
            string ApprovedComment = "Approving the submitted plan";
            //string FpcDept = SettingData.SemiVariableDept;
            //string FpcFacility = SettingData.secondUserFacility;
            string FpcDept = "780";
            string FpcFacility = "27610";
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);

            //ContractLaborTab.verifyContrcatLaborTableInSummaryView();

            FpcAdministration.GoTo();
            Assert.True(FpcAdministration.IsAt, "FPC Administration page was not displayed");
            AdminFacilityOptions.FacilityOptions()
                .withFreezeFPCAdministration("No")
                .Save();
            AdminDepartmentOptions.DepartmentFilter()
                .withFrom(FpcDept)
                .withTo(FpcDept)
                .View();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed(deptOptionXpath, 15);
            AdminDepartmentOptions.DepartmentOption(FpcDept)
                .withVariance("0.50")
                .withSetDepartmentLevelCoreAndPeakRules(true)
                .withCoreRulesByDailyAverage("Lowest UOS Month")
                .withPeakRulesByDailyAverage("Highest UOS Month")
                .withCalculateDailyAverageVolumesBasedOn("Calendar Days")
                .withAllowSelectableTargetMonth(false)
                .withDefaultTargetMonth("Current Month")
                .withOverrideHrsuos(false)
                .withOverrideProductiveMinimumHours(false)
                .withOverrideMonthlyTargetedSemiVariableProductiveFtes(true)
                .withIncludeAllInactiveEmployeesInFtesCalculation(true)
                .withUseCurrentActualVolumesForCalculatingFtesInApprovedPlans(false)
                .withAllowSavingIfCoreFtesAreOverAllowableFTEVariance("Yes")
                .withVolumeBudget(true)
                .withVolumeHistorical(true)
                .withVolumeOverride(true)
                .withNonproductiveTarget(true)
                .withNonproductiveHistorical(true)
                .withNonproductiveOverride(true)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            
            bPlanExist = FpcPlanFilter.PlanFilter()
              .withDepartment(FpcDept)
              .withPlanStatus("Working")
              .withPlan("(W)")
              .IsPlanTypeExist();
            //Delete any existing working plan
            if (bPlanExist)
            {
                FpcPlanFilter.PlanFilter()
                  .withDepartment(FpcDept)
                  .withPlanStatus("Working")
                  .withPlan("(W)")
                  .DeletePlan();
            }

            //Delete any pending plan
            FPCMainMenu.FPC.SelectPlan();
            bPlanExist = FpcPlanFilter.PlanFilter()
              .withDepartment(FpcDept)
              .withPlanStatus("Pending")
              .withPlan("(P)")
              .IsPlanTypeExist();
            if(bPlanExist)
            {               
                FpcPlanFilter.PlanFilter()
                  .withDepartment(FpcDept)
                  .withPlanStatus("Pending")
                  .withPlan("(P)")
                  .ViewPlanDetail();
                FpcPlanMenu.Approve(ApprovedComment);
                CommonFunctions.AddTestStep("Approving current pending plan", "The paln is approved.");
            }
            
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            CommonFunctions.WaitUntilPageIsAcive();


            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //In case there is any previous errors
            FpcPlanMenu.UpdateReqInfo();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
            // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.PlanFilter()
                  .withDepartment(FpcDept)
                  .withPlanStatus("Approved")
                  .withPlan("(A)")
                  .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanMenu.Save();

            //Get all requistions            
            RequisitionsTab.GoTo();
            Assert.True(RequisitionsTab.IsAt, "Requistion tab was not displayed");
            var RequistionTabData = RequisitionsTab.getRequistionTabData();
            var requisitionNumbers = RequistionTabData
                .Where(row => row.OpenFTE <= 0.01m || row.OpenFTE > 0.30m)
                .Select(row => row.GHRReqs)
                .ToList();
            reqNum = requisitionNumbers[0];
            Console.WriteLine($"reqNum {reqNum}");

            //Navigate to view plan detail page
            // FpcPlanFilter.ViewPlanDetail();
            //CommonFunctions.WaitUntilPageIsAcive();
            PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            //Modify existing record and verify erros in the req tab. 
            PlanDetailTab.ModifyExistingDeptPlanDetail(reqNum);
            
            CommonFunctions.WaitUntilPageIsAcive();
            RequisitionsTab.GoTo();
            Assert.True(PlanDetail.RequisitionsTab.IsAt, "Requisition table was not displayed.");
            bErrDisplayed = PlanDetail.RequisitionsTab.VerifyShiftErrorInRequistion(reqNum);
            Assert.True(bErrDisplayed, "Shift error was not displayed"); 
            PlanDetail.PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            FpcPlanMenu.UpdateReqInfo();
            var isInactiveEmpBlueLines = PlanDetail.PlanDetailTab.IncludeInactiveEmpInDeptPlanDetailBlueLines();            
            Assert.True(isInactiveEmpBlueLines, "Include inactive values didn't match with subtotals");

            //delete a record
            PlanDetail.PlanDetailTab.DeleteExistingDeptPlanDetail(reqNum);
            PlanDetail.RequisitionsTab.GoTo();
            Assert.True(PlanDetail.RequisitionsTab.IsAt, "Requisition table was not displayed.");
            Assert.True(PlanDetail.RequisitionsTab.VerifyDeletionErrorInRequistion(reqNum),
                "Deleting error was not displayed in the req tab");
            PlanDetailTab.GoTo();
            Assert.True(PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            FpcPlanMenu.AddMissingReqs();
            Thread.Sleep(5000);
            var PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabElementsBlueLines();
            bRecordResoted = PlanDetailTabData.Exists(x => string.Equals(x.ReqNumber.GetAttribute("value"), reqNum, StringComparison.InvariantCultureIgnoreCase));
            Assert.True(bRecordResoted, $"Record with req number {reqNum} was not added back");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Add a new employee
            PlanDetailTab.AddNewEmployee(fName, lName);
            PlanDetailTabData = PlanDetailTab.GetPlanDetailTabElementsBlueLines();
            bNewEmpAdded = PlanDetailTabData.Exists(x => string.Equals(x.LastName.GetAttribute("value"), lName, StringComparison.InvariantCultureIgnoreCase));
            Assert.True(bNewEmpAdded, $"{lName} was not found");

            //Verify all Requisition filter
            VerifyAllRequistionsFilter();
            //Contract labor tab
            PlanDetail.ContractLaborTab.GoTo();
            //Check if there is data in the contract labor tab
            bExist = PlanDetail.ContractLaborTab.IsAt;
            if (bExist)
            {
                var ContractLaborData = PlanDetail.ContractLaborTab.getContractLaborData();
                var lstWorking = ContractLaborData.Where(x => string.Equals(x.MatchStatus, "Embedded", StringComparison.InvariantCultureIgnoreCase));
                Console.WriteLine(lstWorking.Count().ToString());
                var planFteSummary = PlanDetailTab.GetPlanDetailFTESummaryDepartment();
                var PlanDetailFteSummary = PlanDetail.PlanDetailFteSummary.getPlanDetailFteSummary();
                bool bMatched = string.Equals(PlanDetailFteSummary.Working_Total,
                    lstWorking.Count().ToString(), StringComparison.InvariantCultureIgnoreCase);
                Assert.True(bMatched, $"PlanDetailFteSummary.Working_Total = {PlanDetailFteSummary.Working_Total}\n" +
                    $"lstWorking.Count = {lstWorking.Count().ToString()} ");
            }

            FpcPlanMenu.Save();
            FpcPlanFilter.PlanFilter()
                  .withDepartment(FpcDept)
                  .withPlanStatus(string.Empty)
                  .withPlan(string.Empty)
                  .ViewPlan();
            CommonFunctions.WaitUntilPageIsAcive();

            //PRN part
            //VerifyPRN_Functionality();


            //Test employee-result filters

            FpcPlanFilter.PlanFilter()
                  .withDepartment(FpcDept)
                  .withPlanStatus(string.Empty)
                  .withPlan(string.Empty)
                  .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            PlanDetailTab.EmployeeResultFilters()
                .withShiftFilter("All")
                .withSkillMixFilter("All")
                .withTypeFilter("R")
                .withLastNameFilter("All")
                .withFirstNameFilter("All")
                .withPositionDescriptionFilter("All")
                .withHiredInDateFilter("All")
                .withStatusFilter("All")
                .withIncludeInactiveFilter("All")
                .withHiredInFTEFilter("All")
                .withCoreFilter("All")
                .withAvgFilter("All")
                .withPeakFilter("All")
                .withReqNumberFilter("All")
                .withNotesFilter("All")
                .Set();
            var employeeResults = PlanDetailTab.GetPlanDetailTabData();
            //verify the rows. 


            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            CommonFunctions.WaitUntilPageIsAcive();

            //Verify user info and date in the note area
            FpcPlan.AddFpcNotes();           
            ////Click on the view plan button.
            //FpcPlanFilter.ViewPlan();
            var FpcPlanSummaryData = FpcPlan.GetPlanViewSummary();
            Console.WriteLine($"FpcPlanSummaryData.LastUpdated = {FpcPlanSummaryData.LastUpdate}");
            Console.WriteLine($"FpcPlanSummaryData.UpdatedBy = {FpcPlanSummaryData.UpdatedBy}");
            bExist = FpcPlanSummaryData.UpdatedBy.Contains("System");
            Assert.True(bExist, $"Updated by info is not displayed in the note last updated row.");

            // Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovedComment);
            //Go to view plan page
            FpcPlanFilter.ViewPlan();
            //append a new note
            var newNote = FpcPlan.AppendTextToFpcNote();
            Console.WriteLine($"New note: {newNote}");
            //Get last update value
            var UpdatedFpcPlanSummaryData = FpcPlan.GetPlanViewSummary();

            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            CommonFunctions.WaitUntilPageIsAcive();

            var newAddedNote = FpcPlan.GetFpcNoteText();
            Console.WriteLine($"newAddedNote: {newAddedNote}");
            Console.WriteLine($"UpdatedFpcPlanSummaryData.LastUpdate = {UpdatedFpcPlanSummaryData.LastUpdate}");
            var lastUpdateTime = getDatePartFromLastUpdate(UpdatedFpcPlanSummaryData.LastUpdate);
            Console.WriteLine($"lastUpdateTime = { lastUpdateTime}");
            bExist = newAddedNote.Contains(lastUpdateTime);
            Assert.True(bExist, $"New plan doesn't contain the last update value.");

            // Verify FTEs and count
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractLaborTab.GoTo();
            Assert.True(ContractLaborTab.IsAt, "Contract labor tab was not displayed");
            //var bMatch = ContractLaborTab.verifyContrcatLaborTableInSummaryView();
            //Assert.False(bMatch, "Contract Labor FTEs and count didn't matched");


            //Verify next and previous button
            FpcPlanFilter.PlanFilter()
                 .withDepartment(FpcDept)
                 .withPlanStatus(string.Empty)
                 .withPlan(string.Empty)
                 .ViewPlan();
            CommonFunctions.WaitUntilPageIsAcive();

            var lstFpcDepts = FpcPlanFilter.GetAllDepts();
            var (Previous, Next) = CommonFunctions.GetPreviousAndNextItemsInList<string>(lstFpcDepts, FpcDept);
            FpcPlanFilter.ClickNext();
            var currentDept = FpcPlanFilter.getCurrentDeptValue();
            Assert.True(string.Equals(currentDept, Next, StringComparison.OrdinalIgnoreCase),
                $"Next button is not working. Next {Next}, Current dept {currentDept}");

            FpcPlanFilter.PlanFilter()
                  .withDepartment(FpcDept)
                  .withPlanStatus(string.Empty)
                  .withPlan(string.Empty)
                  .ViewPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.ClickPrevious();
            currentDept = FpcPlanFilter.getCurrentDeptValue();
            Assert.True(string.Equals(currentDept, Previous, StringComparison.OrdinalIgnoreCase),
                $"Previous button is not working. Previou {Previous}, Current dept {currentDept}");

        }

        private static string getDatePartFromLastUpdate(string lastUpdate)
        {
            var x = lastUpdate.Replace("Last Update :", " ");
            string[] parts = x.Split(new[] { ' ' }, StringSplitOptions.None);
            DateTime dt = DateTime.Parse($"{parts[2]} {parts[3]} {parts[4]}");
            string time = dt.ToString("h:mm:ss tt");
            return time;
        }

        private void VerifyAllRequistionsFilter()
        {
            bool bReqNumNotNull, bFound, bMatched;
            PlanDetailTab.Filters()
                .withSubtotalBy("Department")
                .withFilterBy("All")
                .withFilterByStatus("All")
                .withFilterByType("All Requisitions")
                .SetFilterBy();

            CommonFunctions.AddTestStep("Verify when selecting All-Requistion filter, there are no gray lines are displyed",
                "There are no gray lines are displyed");
            var lstGrayLines = PlanDetailTab.GetPlanDetailTabElementsGrayLines();
            bFound = lstGrayLines.Count == 0 ? true : false;
            Assert.True(bFound, "Gray lines were displayed when selecting All-Requistion filter");

            CommonFunctions.AddTestStep("All-Requistion filter", "Verify all requistion cells are populated.");            
            var lstBlueLines = PlanDetailTab.GetPlanDetailTabElementsBlueLinesActiveAndInactive();

            bReqNumNotNull = lstBlueLines.Exists(x => !string.IsNullOrEmpty(x.ReqNumber.GetAttribute("value")));
            Assert.True(bReqNumNotNull, "Req number is empty");

            var ActiveBlueLines_SubtotalCore = lstBlueLines.Where(x => x.Status.FindElement(By.XPath("option[@selected]")).GetAttribute("value").Contains("A"))
                .Select(x => CommonFunctions.GetDecimalValue(x.Core)).Sum();

            var ActiveBlueLines_SubtotalAvg = lstBlueLines.Where(x => x.Status.FindElement(By.XPath("option[@selected]")).GetAttribute("value").Contains("A"))
                .Select(x => CommonFunctions.GetDecimalValue(x.Avg)).Sum();

            var ActiveBlueLines_SubtotalPeak = lstBlueLines.Where(x => x.Status.FindElement(By.XPath("option[@selected]")).GetAttribute("value").Contains("A"))
                .Select(x => CommonFunctions.GetDecimalValue(x.Peak)).Sum();

            bMatched = ActiveBlueLines_SubtotalCore == CommonFunctions.GetDecimalValue(lstBlueLines[0].FTEs_Core) &&
                ActiveBlueLines_SubtotalAvg == CommonFunctions.GetDecimalValue(lstBlueLines[0].FTEs_Avg) &&
                ActiveBlueLines_SubtotalPeak == CommonFunctions.GetDecimalValue((lstBlueLines[0].FTEs_Peak));
            Assert.True(bMatched, "Subtotal didn't matched.");

            //Reset the filter
            PlanDetailTab.Filters()
                .withSubtotalBy("Department")
                .withFilterBy("All")
                .withFilterByStatus("All")
                .withFilterByType("All Types")
                .SetFilterBy();
        }

        private void VerifyPRN_Functionality()
        {
            bool bPRN;
            PlanDetailTab.Filters()
                .withSubtotalBy("Department")
                .withFilterBy("All")
                .withFilterByStatus("All")
                .withFilterByType("R - PRN")
                .SetFilterBy();

            var lstGrayLines = PlanDetailTab.GetPlanDetailTabElementsGrayLines();
            foreach (var line in lstGrayLines)
            {
                var sType = line.Type.GetAttribute("value");
                var dhiredInFTE = CommonFunctions.GetDecimalValue(line.HiredInFTE);
                var dCore = CommonFunctions.GetDecimalValue(line.Core);
                var dAvg = CommonFunctions.GetDecimalValue(line.Avg);
                var dPeak = CommonFunctions.GetDecimalValue(line.Peak);
                //If Hired In FTE <=0.1, Set Core/Avg/Peak FTE = 0.15 
                //This is mainly for R-Type
                bPRN = (string.Equals(sType, "R") && dhiredInFTE <= (decimal)0.1 && dCore >= (decimal)0.15 && dAvg >= (decimal)0.15 && dPeak >= (decimal)0.15) ? true : false;
                Assert.True(bPRN, $"Type = {sType}, HiredInFTE = {dhiredInFTE.ToString()}, Core = {dCore}, Avg = {dAvg}, Peak = {dPeak}");
            }


            //Set Core to 0.30
            CommonFunctions.SetText(lstGrayLines[0].Core, "0.30");
            FpcPlanMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();

            PlanDetailTab.Filters()
                .withSubtotalBy("Department")
                .withFilterBy("All")
                .withFilterByStatus("All")
                .withFilterByType("R - PRN")
                .SetFilterBy();

            lstGrayLines = PlanDetailTab.GetPlanDetailTabElementsGrayLines();
            CommonFunctions.SetText(lstGrayLines[0].Core, "0.50");
            FpcPlanMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();

            PlanDetailTab.Filters()
                .withSubtotalBy("Department")
                .withFilterBy("All")
                .withFilterByStatus("All")
                .withFilterByType("R - PRN")
                .SetFilterBy();
            lstGrayLines = PlanDetailTab.GetPlanDetailTabElementsGrayLines();
            var dCoreValue = CommonFunctions.GetDecimalValue(lstGrayLines[0].Core);
            bPRN = dCoreValue == (decimal)0.30;
            Assert.That(bPRN, $"Core value != 0.30 after replacing. It's {dCoreValue.ToString()}");
        }

        [Test]
        public void TestingGrayLinePRN()
        {
            //*/div[@id="employeeResults"]//tbody/tr/td[7]/input[contains(@title,'03049')]
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Plan PRN Core Greater Than Hired In for PI Labor Only";
            var parent = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;
            string filePath = $@"{parent}\Utilities\PrnData.txt";
            bool bCore, bAvg, bPeak, bResult;
            string line, fac, dept, subFun, PrnValues;
            List<bool> blist = new List<bool>();
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            CommonFunctions.WriteToFile("\n\nGray Line PRN Results\n");

            using (StreamReader reader = new StreamReader(filePath))
            {
                while ((line = reader.ReadLine()) !=null)
                {
                    var arrData = line.Split('\t');
                    fac = arrData[0];
                    dept = arrData[1];

                    PrnValues = $"{fac.Trim()}_{dept.Trim()}";

                    //Set Division and facility.
                    Division.SetPLUSDivisionAndFacility(fac);
                    Thread.Sleep(5000);
                    CommonFunctions.WaitUntilPageIsAcive();

                    //FPCMainMenu.FPC.SelectPlan();
                    Thread.Sleep(10000);
                    CommonFunctions.WaitUntilPageIsAcive();
                    Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
                    FpcPlanFilter.PlanFilter()
                       .withDepartment(dept)
                       .withPlanStatus(string.Empty)
                       .withPlan(string.Empty)
                       .ViewPlanDetail();
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitUntilPageIsAcive();

                    PlanDetailTab.GoTo();
                    Assert.True(PlanDetailTab.IsAt, "Plan detail tab was not displayed");

                    //Select R-PRN -- Type R -- Gray lines
                    PlanDetailTab.Filters()
                       .withSubtotalBy("Department")
                       .withFilterBy("All")
                       .withFilterByStatus("All")
                       .withFilterByType("R - PRN")
                       .SetFilterBy();
                    CommonFunctions.WaitUntilPageIsAcive();
                    
                    //PlanDetailTab.EmployeeResultFilters()
                    //    .withShiftFilter("All")
                    //    .withSkillMixFilter("All")
                    //    .withTypeFilter("R")
                    //    .withLastNameFilter("All")
                    //    .withFirstNameFilter("All")
                    //    .withPositionDescriptionFilter("All")
                    //    .withHiredInDateFilter("All")
                    //    .withStatusFilter("All")
                    //    .withIncludeInactiveFilter("All")
                    //    .withHiredInFTEFilter("All")
                    //    .withCoreFilter("All")
                    //    .withAvgFilter("All")
                    //    .withPeakFilter("All")
                    //    .withReqNumberFilter("All")
                    //    .withNotesFilter("All")
                    //    .Set();


                    var empResults = PlanDetailTab.GetGrayLinesValues();
                    bool bFlag = true;
                    blist.Clear();
                    foreach ( var emp in empResults)
                    {

                        if (string.Equals(emp.JobCode, "05056", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(emp.JobCode, "05057", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(emp.JobCode, "05142", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(emp.JobCode, "05153", StringComparison.OrdinalIgnoreCase))
                        {
                            if (string.Equals(emp.HiredInFTE, "0.00", StringComparison.OrdinalIgnoreCase) ||
                                string.Equals(emp.HiredInFTE, "0.01", StringComparison.OrdinalIgnoreCase))
                            {
                                bCore = string.Equals(emp.Core, "0.01", StringComparison.OrdinalIgnoreCase);
                                bAvg = string.Equals(emp.Avg, "0.01", StringComparison.OrdinalIgnoreCase);
                                bPeak = string.Equals(emp.Peak, "0.01", StringComparison.OrdinalIgnoreCase);
                                bResult = bCore && bAvg && bPeak;
                                blist.Add(bResult);

                            }
                        }
                        else
                        {
                            if (string.Equals(emp.HiredInFTE, "0.00", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(emp.HiredInFTE, "0.01", StringComparison.OrdinalIgnoreCase))
                            {
                                bCore = string.Equals(emp.Core, "0.15", StringComparison.OrdinalIgnoreCase);
                                bAvg = string.Equals(emp.Avg, "0.15", StringComparison.OrdinalIgnoreCase);
                                bPeak = string.Equals(emp.Peak, "0.15", StringComparison.OrdinalIgnoreCase);
                                bResult = bCore && bAvg && bPeak;
                                blist.Add(bResult);

                            }
                        }
                    }
                    bFlag = blist.All(x => x == true) ? true : false;
                    if (bFlag)
                    {    
                        
                        CommonFunctions.AddTestStep($"Passed:{fac} - {dept}", $"Passed: {fac} - {dept}");                        
                        CommonFunctions.getScreenshot(PrnValues);
                    }
                    else
                    {
                        CommonFunctions.AddTestStep($"Failed {fac} - {dept}", $"Failed {fac} - {dept}");
                        CommonFunctions.WriteToFile($"{fac} - {dept}");
                        CommonFunctions.getScreenshot(PrnValues);
                    }
                    Console.WriteLine($"FAC/Dept: {fac} - {dept}");
                }
            }
            bool bPrnError = CommonFunctions.GetFileContentLength();
            Assert.True(bPrnError, "PRN data didn't matach. Review result file");
        }

        [Test]
        public void TestingBlueLinePRN()
        {
            //*/div[@id="employeeResults"]//tbody/tr/td[7]/input[contains(@title,'03049')]
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Plan PRN Core Greater Than Hired In for PI Labor Only";
            var parent = Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.Parent;
            int counter = 1;
            string filePath = $@"{parent}\Utilities\BlueLineRRN.txt";
            bool bCore, bAvg, bPeak, bResult;
            string line, fac, dept, subFun, PrnValues;
            List<bool> blist = new List<bool>();
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            CommonFunctions.WriteToFile("\n\nBlue Line PRN Results\n");

            using (StreamReader reader = new StreamReader(filePath))
            {
                while ((line = reader.ReadLine()) != null)
                {
                    var arrData = line.Split('\t');
                    fac = arrData[0];
                    dept = arrData[1];
                    //subFun = arrData[2];

                    PrnValues = $"{fac.Trim()}_{dept.Trim()}";

                    //Set Division and facility.
                    Division.SetPLUSDivisionAndFacility(fac);
                    By byNo = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-dirtypage-nav-with-save-confirm']//button/span[text()='No']");
                    By byNavigateAway = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-dirtypage-nav-confirm']//button/span[contains(text(), 'Yes,')]");
                    if(CommonFunctions.IsElementDisplayed(byNo, 1))
                    {
                        CommonFunctions.ClickByJE(CommonFunctions.getElement(byNo));
                        CommonFunctions.WaitUntilPageIsAcive();
                    }
                    if (CommonFunctions.IsElementDisplayed(byNavigateAway, 1))
                    {
                        CommonFunctions.ClickByJE(CommonFunctions.getElement(byNavigateAway));
                        CommonFunctions.WaitUntilPageIsAcive();
                    }
                    Thread.Sleep(5000);
                    CommonFunctions.WaitUntilPageIsAcive();

                    //FPCMainMenu.FPC.SelectPlan();
                    Thread.Sleep(10000);
                    CommonFunctions.WaitUntilPageIsAcive();
                    Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
                    FpcPlanFilter.PlanFilter()
                       .withDepartment(dept)
                       .withPlanStatus(string.Empty)
                       .withPlan(string.Empty)
                       .ViewPlanDetail();
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitUntilPageIsAcive();

                    PlanDetailTab.GoTo();
                    CommonFunctions.WaitUntilPageIsAcive();
                    Assert.True(PlanDetailTab.IsAt, "Plan detail tab was not displayed");

                    //Select R-PRN -- Type R -- Gray lines
                    PlanDetailTab.Filters()
                       .withSubtotalBy("Department")
                       .withFilterBy("All")
                       .withFilterByStatus("All")
                       .withFilterByType("3 - PRN to Hire")
                       .SetFilterBy();
                    CommonFunctions.WaitUntilPageIsAcive();

                    //PlanDetailTab.EmployeeResultFilters()
                    //    .withShiftFilter("All")
                    //    .withSkillMixFilter("All")
                    //    .withTypeFilter("R")
                    //    .withLastNameFilter("All")
                    //    .withFirstNameFilter("All")
                    //    .withPositionDescriptionFilter("All")
                    //    .withHiredInDateFilter("All")
                    //    .withStatusFilter("All")
                    //    .withIncludeInactiveFilter("All")
                    //    .withHiredInFTEFilter("All")
                    //    .withCoreFilter("All")
                    //    .withAvgFilter("All")
                    //    .withPeakFilter("All")
                    //    .withReqNumberFilter("All")
                    //    .withNotesFilter("All")
                    //    .Set();


                    var empResults = PlanDetailTab.GetPlanDetailTabElementsBlueLines();
                    bool bFlag = true;
                    blist.Clear();
                    foreach (var emp in empResults)
                    {
                        var JobCode = emp.PositionDescription.GetAttribute("title").Split(':').ElementAt(1).Trim();
                        if (string.Equals(JobCode, "05056", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(JobCode, "05057", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(JobCode, "05142", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(JobCode, "05153", StringComparison.OrdinalIgnoreCase))
                        {
                            if (string.Equals(emp.HiredInFTE.GetAttribute("value"), "0.00", StringComparison.OrdinalIgnoreCase) ||
                                string.Equals(emp.HiredInFTE.GetAttribute("value"), "0.01", StringComparison.OrdinalIgnoreCase))
                            {
                                bCore = string.Equals(emp.Core.GetAttribute("value"), "0.01", StringComparison.OrdinalIgnoreCase);
                                bAvg = string.Equals(emp.Avg.GetAttribute("value"), "0.01", StringComparison.OrdinalIgnoreCase);
                                bPeak = string.Equals(emp.Peak.GetAttribute("value"), "0.01", StringComparison.OrdinalIgnoreCase);
                                bResult = bCore && bAvg && bPeak;
                                blist.Add(bResult);

                            }
                        }
                        else
                        {
                            if (string.Equals(emp.HiredInFTE.GetAttribute("value"), "0.00", StringComparison.OrdinalIgnoreCase) ||
                                string.Equals(emp.HiredInFTE.GetAttribute("value"), "0.01", StringComparison.OrdinalIgnoreCase))
                            {
                                bCore = string.Equals(emp.Core.GetAttribute("value"), "0.15", StringComparison.OrdinalIgnoreCase);
                                bAvg = string.Equals(emp.Avg.GetAttribute("value"), "0.15", StringComparison.OrdinalIgnoreCase);
                                bPeak = string.Equals(emp.Peak.GetAttribute("value"), "0.15", StringComparison.OrdinalIgnoreCase);
                                bResult = bCore && bAvg && bPeak;
                                blist.Add(bResult);
                            }
                        }
                    }
                    bFlag = blist.All(x => x == true) ? true : false;
                    if (bFlag)
                    {
                        CommonFunctions.AddTestStep($"Passed: {fac} - {dept}", $"Passed: {fac} - {dept}");
                        CommonFunctions.getScreenshot(PrnValues);
                    }
                    else
                    {
                        CommonFunctions.AddTestStep($"Failed: {dept}", $"Failed {fac} - {dept}");
                        CommonFunctions.WriteToFile($"{fac} - {dept}");
                        //CommonFunctions.getScreenshot(PrnValues);
                    }
                    Console.WriteLine($"Line = {counter++} --- {fac} - {dept}");
                }
            }
            bool bPrnError = CommonFunctions.GetFileContentLength();
            Assert.True(bPrnError, "PRN data didn't matach. Review result file");
        }

        [Test]
        [Category("FPC")]
        public void VerifyFpcSummaryAndApprovalApproveRejectAndCancelJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Fpc Summary And Approval approve, reject, and cancel journey";
            
            string ApprovedComment = "Approving submitted plan";
            string RejectedComment = "Rejecting the submitted plan";
            string ApprovingRejectedPlanComment = "Approving the rejected plan";
            string FpcDept = SettingData.FpcDeptII;
            string FpcFacility = SettingData.secondUserFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();
            Assert.True(FpcPlanFilter.IsPlanDeleted(), "Working plan wasn't deleted");
            FpcPlanMenu.Save();

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
          //  Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Reject a plan
            FpcComment = FpcPlanMenu.Reject(RejectedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approving a rejected plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working - Rejected")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovingRejectedPlanComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            //verify comments in summary and approval page.
            SummaryAndApproval.GoTo();
            Assert.True(SummaryAndApproval.IsAt, "Summary And Approval page was not found");
            SummaryAndApprovalFilter.Filter()
                .withPlanStatus("All")
                .withDepartment(FpcDept)
                .withPlan(string.Empty)
                .ViewPlan();
            var SummaryAndApprovalComments = SummaryAndApproval.GetSummaryAndApprovalComments();
            foreach(var comment in SummaryAndApprovalComments.CommentsAndApprovers)
            {
                bool isFound = comment.Text.Contains(ApprovingRejectedPlanComment);
                if(isFound) 
                {
                    Console.WriteLine(isFound);
                }
            }
            
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                     .withDepartment(FpcDept)
                     .withPlanStatus("New")
                     .withPlan(string.Empty)
                     .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();
            Assert.True(FpcPlanFilter.IsPlanDeleted(), "Plan was not deleted");
        }
        
        [Test]
        [Category("FPC")]
        public void VerifyPlanDetailsjourney()
        {
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility();
            SharedHours.GoTo();
            Assert.True(SharedHours.IsAt, "Shared hours page was not displayed.");
            SharedHours.DeptView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDepartment("600")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDeptViewData(40.00);
            var SharedHoursDeptViewDataResults = SharedHoursData.GetSharedHoursDeptViewData();
            Console.WriteLine(SharedHoursDeptViewDataResults[0].DayOtHours);

            SharedHours.DaysView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDate("Current date")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDaysViewData(40.00);
            var SharedHoursDaysViewDataResults = SharedHoursData.GetSharedHoursDaysViewData();
            Console.WriteLine(SharedHoursDaysViewDataResults[0].DayOtHours);

            //add the calc
        }


       
        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifytheJourneyofContractLabortab()
        {
            string ApprovedComment = "Approving submitted plan";
            string RejectedComment = "Rejecting the submitted plan";
            string ApprovingRejectedPlanComment = "Approving the rejected plan";
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Reject a plan
            FpcComment = FpcPlanMenu.Reject(RejectedComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approving a rejected plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working - Rejected")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovingRejectedPlanComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            //verify comments in summary and approval page.
            SummaryAndApproval.GoTo();
            Assert.True(SummaryAndApproval.IsAt, "Summary And Approval page was not found");
            SummaryAndApprovalFilter.Filter()
                .withPlanStatus("All")
                .withDepartment(FpcDept)
                .withPlan(string.Empty)
                .ViewPlan();
            var SummaryAndApprovalComments = SummaryAndApproval.GetSummaryAndApprovalComments();
            foreach (var comment in SummaryAndApprovalComments.CommentsAndApprovers)
            {
                bool isFound = comment.Text.Contains(ApprovingRejectedPlanComment);
                if (isFound)
                {
                    Console.WriteLine(isFound);
                }
            }

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                     .withDepartment(FpcDept)
                     .withPlanStatus("New")
                     .withPlan(string.Empty)
                     .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();
            Assert.True(FpcPlanFilter.IsPlanDeleted(), "Plan was not deleted");
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifytheJourneyofFacilityoptionsinFpcAdministration()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Facility options in FPC Administration";

            string ApprovedComment = "Approving submitted plan";
            string RejectedComment = "Rejecting the submitted plan";

            string ApprovingRejectedPlanComment = "Approving the rejected plan";
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Reject a plan
            FpcComment = FpcPlanMenu.Reject(RejectedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approving a rejected plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working - Rejected")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovingRejectedPlanComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            //verify comments in summary and approval page.
            SummaryAndApproval.GoTo();
            Assert.True(SummaryAndApproval.IsAt, "Summary And Approval page was not found");
            SummaryAndApprovalFilter.Filter()
                .withPlanStatus("All")
                .withDepartment(FpcDept)
                .withPlan(string.Empty)
                .ViewPlan();
            var SummaryAndApprovalComments = SummaryAndApproval.GetSummaryAndApprovalComments();
            foreach (var comment in SummaryAndApprovalComments.CommentsAndApprovers)
            {
                bool isFound = comment.Text.Contains(ApprovingRejectedPlanComment);
                if (isFound)
                {
                    Console.WriteLine(isFound);
                }
            }

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                     .withDepartment(FpcDept)
                     .withPlanStatus("New")
                     .withPlan(string.Empty)
                     .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();
            Assert.True(FpcPlanFilter.IsPlanDeleted(), "Plan was not deleted");
        }        

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyOverrideMinFTEsandHoursUOSJourney()
        {
            string ApprovedComment = "Approving submitted plan";
            string RejectedComment = "Rejecting the submitted plan";
            string ApprovingRejectedPlanComment = "Approving the rejected plan";
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Reject a plan
            FpcComment = FpcPlanMenu.Reject(RejectedComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approving a rejected plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working - Rejected")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovingRejectedPlanComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            //verify comments in summary and approval page.
            SummaryAndApproval.GoTo();
            Assert.True(SummaryAndApproval.IsAt, "Summary And Approval page was not found");
            SummaryAndApprovalFilter.Filter()
                .withPlanStatus("All")
                .withDepartment(FpcDept)
                .withPlan(string.Empty)
                .ViewPlan();
            var SummaryAndApprovalComments = SummaryAndApproval.GetSummaryAndApprovalComments();
            foreach (var comment in SummaryAndApprovalComments.CommentsAndApprovers)
            {
                bool isFound = comment.Text.Contains(ApprovingRejectedPlanComment);
                if (isFound)
                {
                    Console.WriteLine(isFound);
                }
            }

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                     .withDepartment(FpcDept)
                     .withPlanStatus("New")
                     .withPlan(string.Empty)
                     .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();
            Assert.True(FpcPlanFilter.IsPlanDeleted(), "Plan was not deleted");
        }        

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifytheJourneyofPlanStatusdropdown()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of Department and Plan Status drop down";

            string ApprovedComment = "Approving submitted plan";
            string RejectedComment = "Rejecting the submitted plan";
            string ApprovingRejectedPlanComment = "Approving the rejected plan";
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Reject a plan
            FpcComment = FpcPlanMenu.Reject(RejectedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approving a rejected plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working - Rejected")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovingRejectedPlanComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            //verify comments in summary and approval page.
            SummaryAndApproval.GoTo();
            Assert.True(SummaryAndApproval.IsAt, "Summary And Approval page was not found");
            SummaryAndApprovalFilter.Filter()
                .withPlanStatus("All")
                .withDepartment(FpcDept)
                .withPlan(string.Empty)
                .ViewPlan();
            var SummaryAndApprovalComments = SummaryAndApproval.GetSummaryAndApprovalComments();
            foreach (var comment in SummaryAndApprovalComments.CommentsAndApprovers)
            {
                bool isFound = comment.Text.Contains(ApprovingRejectedPlanComment);
                if (isFound)
                {
                    Console.WriteLine(isFound);
                }
            }

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                     .withDepartment(FpcDept)
                     .withPlanStatus("New")
                     .withPlan(string.Empty)
                     .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();
            Assert.True(FpcPlanFilter.IsPlanDeleted(), "Plan was not deleted");
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifySemiVariableStepsJourney()
        {
            string reqNum;
            string fName = "Sam";
            string lName = "Smith";
            bool bErrDisplayed, bRecordResoted, bNewEmpAdded;
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            FpcAdministration.GoTo();
            Assert.True(FpcAdministration.IsAt, "FPC Administration page was not displayed");
            AdminFacilityOptions.FacilityOptions()
                .withFreezeFPCAdministration("No")
                .Save();
            AdminDepartmentOptions.DepartmentFilter()
                .withFrom(FpcDept)
                .withTo(FpcDept)
                .View();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed(deptOptionXpath, 15);
            AdminDepartmentOptions.DepartmentOption(FpcDept)
                .withVariance("0.50")
                .withSetDepartmentLevelCoreAndPeakRules(true)
                .withCoreRulesByDailyAverage("Lowest UOS Month")
                .withPeakRulesByDailyAverage("Highest UOS Month")
                .withCalculateDailyAverageVolumesBasedOn("Calendar Days")
                .withAllowSelectableTargetMonth(false)
                .withDefaultTargetMonth("Current Month")
                .withOverrideHrsuos(false)
                .withOverrideProductiveMinimumHours(false)
                .withOverrideMonthlyTargetedSemiVariableProductiveFtes(false)
                //.withIncludeAllInactiveEmployeesInFtesCalculation(true)
                .withUseCurrentActualVolumesForCalculatingFtesInApprovedPlans(false)
                .withAllowSavingIfCoreFtesAreOverAllowableFTEVariance("Yes")
                .withVolumeBudget(true)
                .withVolumeHistorical(true)
                .withVolumeOverride(true)
                .withNonproductiveTarget(true)
                .withNonproductiveHistorical(true)
                .withNonproductiveOverride(true)
                .Save();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            PlanDetail.PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            //Modify existing record and verify erros in the req tab. 
            reqNum = PlanDetail.PlanDetailTab.ModifyExistingDeptPlanDetail();
            PlanDetail.RequisitionsTab.GoTo();
            Assert.True(PlanDetail.RequisitionsTab.IsAt, "Requisition table was not displayed.");
            bErrDisplayed = PlanDetail.RequisitionsTab.VerifyShiftErrorInRequistion(reqNum);
            Assert.True(bErrDisplayed, "Shift error was not displayed");
            PlanDetail.PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            FpcPlanMenu.UpdateReqInfo();
            PlanDetail.PlanDetailTab.IncludeInactiveEmpInDeptPlanDetail();
            var PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabData();
            var selected = PlanDetailTabData.Exists(x => x.IncludeInactive.Selected);
            Assert.True(selected, "Include inactive checkbox was not checked");
            //delete a record
            reqNum = PlanDetail.PlanDetailTab.DeleteExistingDeptPlanDetail();
            PlanDetail.RequisitionsTab.GoTo();
            Assert.True(PlanDetail.RequisitionsTab.IsAt, "Requisition table was not displayed.");
            Assert.True(PlanDetail.RequisitionsTab.VerifyDeletionErrorInRequistion(reqNum),
                "Deleting error was not displayed in the req tab");
            PlanDetail.PlanDetailTab.GoTo();
            Assert.True(PlanDetail.PlanDetailTab.IsAt, "Plan detail tab was not displayed");
            FpcPlanMenu.AddMissingReqs();
            PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabData();
            bRecordResoted = PlanDetailTabData.Exists(x => string.Equals(x.ReqNumber, reqNum, StringComparison.InvariantCultureIgnoreCase));
            Assert.True(bRecordResoted, $"Record with req number {reqNum} was not added back");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Add a new employee
            PlanDetail.PlanDetailTab.AddNewEmployee(fName, lName);
            PlanDetailTabData = PlanDetail.PlanDetailTab.GetPlanDetailTabData();
            bNewEmpAdded = PlanDetailTabData.Exists(x => string.Equals(x.LastName, lName, StringComparison.InvariantCultureIgnoreCase));
            Assert.True(bNewEmpAdded, $"{lName} was not found");

            //Contract labor tab
            PlanDetail.ContractLaborTab.GoTo();
            Assert.True(PlanDetail.ContractLaborTab.IsAt, "Contract Labor Tab wasn't displayed.");
            var ContractLaborData = PlanDetail.ContractLaborTab.getContractLaborData();
            var lstWorking = ContractLaborData.Where(x => string.Equals(x.MatchStatus, "Working", StringComparison.InvariantCultureIgnoreCase));
            Console.WriteLine(lstWorking.Count().ToString());
            var PlanDetailFteSummary = PlanDetail.PlanDetailFteSummary.getPlanDetailFteSummary();
            bool bMatched = string.Equals(PlanDetailFteSummary.Working_Total,
                lstWorking.Count().ToString(), StringComparison.InvariantCultureIgnoreCase);
            Assert.True(bMatched, $"PlanDetailFteSummary.Working_Total = {PlanDetailFteSummary.Working_Total}\n" +
                $"lstWorking.Count = {lstWorking.Count().ToString()} ");

            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve("Approving submitted plan");
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();



        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyVolumeJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Volume Journey";

            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility();
            SharedHours.GoTo();
            Assert.True(SharedHours.IsAt, "Shared hours page was not displayed.");
            SharedHours.DeptView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDepartment("600")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDeptViewData(40.00);
            var SharedHoursDeptViewDataResults = SharedHoursData.GetSharedHoursDeptViewData();
            Console.WriteLine(SharedHoursDeptViewDataResults[0].DayOtHours);

            SharedHours.DaysView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDate("Current date")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDaysViewData(40.00);
            var SharedHoursDaysViewDataResults = SharedHoursData.GetSharedHoursDaysViewData();
            Console.WriteLine(SharedHoursDaysViewDataResults[0].DayOtHours);

            //add the calc
        }
        //Verify Non-Productive Percentage journey

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyNonProductivePercentageJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify NonProductive Percentage Journey";

            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility();
            SharedHours.GoTo();
            Assert.True(SharedHours.IsAt, "Shared hours page was not displayed.");
            SharedHours.DeptView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDepartment("600")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDeptViewData(40.00);
            var SharedHoursDeptViewDataResults = SharedHoursData.GetSharedHoursDeptViewData();
            Console.WriteLine(SharedHoursDeptViewDataResults[0].DayOtHours);

            SharedHours.DaysView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDate("Current date")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDaysViewData(40.00);
            var SharedHoursDaysViewDataResults = SharedHoursData.GetSharedHoursDaysViewData();
            Console.WriteLine(SharedHoursDaysViewDataResults[0].DayOtHours);

            //add the calc
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyOtClFTEsInformativeUseOnlyJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify OT & CL FTEs (Informative Use Only) Journey"; 

            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility();
            SharedHours.GoTo();
            Assert.True(SharedHours.IsAt, "Shared hours page was not displayed.");
            SharedHours.DeptView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDepartment("600")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDeptViewData(40.00);
            var SharedHoursDeptViewDataResults = SharedHoursData.GetSharedHoursDeptViewData();
            Console.WriteLine(SharedHoursDeptViewDataResults[0].DayOtHours);

            SharedHours.DaysView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDate("Current date")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDaysViewData(40.00);
            var SharedHoursDaysViewDataResults = SharedHoursData.GetSharedHoursDaysViewData();
            Console.WriteLine(SharedHoursDaysViewDataResults[0].DayOtHours);

            //add the calc
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyPlanSummaryJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Plan Summary Journey";

            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility();
            SharedHours.GoTo();
            Assert.True(SharedHours.IsAt, "Shared hours page was not displayed.");
            SharedHours.DeptView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDepartment("600")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDeptViewData(40.00);
            var SharedHoursDeptViewDataResults = SharedHoursData.GetSharedHoursDeptViewData();
            Console.WriteLine(SharedHoursDeptViewDataResults[0].DayOtHours);

            SharedHours.DaysView()
                .withDirection("In")
                .withPayPeriod("Current")
                .withDate("Current date")
                .withSkillMix("010")
                .GetData();
            SharedHoursData.SetSharedHoursDaysViewData(40.00);
            var SharedHoursDaysViewDataResults = SharedHoursData.GetSharedHoursDaysViewData();
            Console.WriteLine(SharedHoursDaysViewDataResults[0].DayOtHours);

            //add the calc
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyFTEsSummaryJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify FTEs Summary Journey";

            string ApprovedComment = "Approving submitted plan";
            string RejectedComment = "Rejecting the submitted plan";
            string ApprovingRejectedPlanComment = "Approving the rejected plan";
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Reject a plan
            FpcComment = FpcPlanMenu.Reject(RejectedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approving a rejected plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working - Rejected")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovingRejectedPlanComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            //verify comments in summary and approval page.
            SummaryAndApproval.GoTo();
            Assert.True(SummaryAndApproval.IsAt, "Summary And Approval page was not found");
            SummaryAndApprovalFilter.Filter()
                .withPlanStatus("All")
                .withDepartment(FpcDept)
                .withPlan(string.Empty)
                .ViewPlan();
            var SummaryAndApprovalComments = SummaryAndApproval.GetSummaryAndApprovalComments();
            foreach (var comment in SummaryAndApprovalComments.CommentsAndApprovers)
            {
                bool isFound = comment.Text.Contains(ApprovingRejectedPlanComment);
                if (isFound)
                {
                    Console.WriteLine(isFound);
                }
            }

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                     .withDepartment(FpcDept)
                     .withPlanStatus("New")
                     .withPlan(string.Empty)
                     .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();
            Assert.True(FpcPlanFilter.IsPlanDeleted(), "Plan was not deleted");
        }

        [Test]
        public void VerifySkillMixJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Skill Mix Summary Journey";

            string FpcDept = "600"; 
            string FpcFacility = "34222";
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Approved")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            FpcSkillMixSummary.GoTo();
            Assert.True(FpcSkillMixSummary.IsAt, "Skill mix summary page was not loaded correctly");
            bool bMatch = FpcSkillMixSummary.VerifyTotalSkillMixBreakdown();
            Assert.True(bMatch, "Skill mix breakdown calculation is not correct");
            CommonFunctions.AddTestStep("Verify Skill mix breakdown calculation", "Calculation was correct");
        }

        [Test]
        public void UserCanCreateMulipleFpcPlans()
        {
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            List<string> lstCoid = new List<string>() { "34222", "39385", "30916", "34407" };//, "39385", "30916", "34407"
            foreach (var fac in lstCoid)
            {
                CreateFpcPlan(fac);
            }
        }

        private void CreateFpcPlan(string coid)
        {
            CommonFunctions.WriteToFile(coid);
            //string FpcDept = SettingData.FpcDept;
            //string FpcFacility = SettingData.FpcFacility;
            
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(coid);
            CommonFunctions.WaitUntilPageIsAcive();
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            CommonFunctions.WriteToFile($"Create a new plan in dept 610");
            FpcPlanFilter.PlanFilter()
                .withDepartment("610")
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.PlanFilter().clickViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanMenu.Submit();

            FpcPlanFilter.PlanFilter()
                .withDepartment("608")
                .withPlanStatus("Approved")
                .withPlan(string.Empty)
                .ViewPlan();
            CommonFunctions.WriteToFile($"Select an existing approved plan in dept 608 -> Plan detail page");
            FpcPlanFilter.PlanFilter().clickViewPlanDetail();

            CommonFunctions.WriteToFile($"Select Approved plan in dept 600 -> Click directly on the plan detail button");
            FpcPlanFilter.PlanFilter()
                .withDepartment("600")
                .withPlanStatus("Approved")
                .withPlan(string.Empty)
                .ViewPlanDetail();
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyCommentSumbitApproveAndRejectPlanJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Comment, Submit, Approve and reject plan Journey"; 
            string ApprovedComment = "Approving submitted plan";
            string RejectedComment = "Rejecting the submitted plan";
            string ApprovingRejectedPlanComment = "Approving the rejected plan";
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();


            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);

            //FpcSkillMixSummary.GoTo();
            //Assert.True(FpcSkillMixSummary.IsAt, "Skill mix summary page was not loaded correctly");
            //bool bMatch = FpcSkillMixSummary.VerifyTotalSkillMixBreakdown();
           //Assert.True(bMatch, "Skill mix breakdown calculation is not correct");

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Reject a plan
            FpcComment = FpcPlanMenu.Reject(RejectedComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approving a rejected plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working - Rejected")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovingRejectedPlanComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            //verify comments in summary and approval page.
            SummaryAndApproval.GoTo();
            Assert.True(SummaryAndApproval.IsAt, "Summary And Approval page was not found");
            SummaryAndApprovalFilter.Filter()
                .withPlanStatus("All")
                .withDepartment(FpcDept)
                .withPlan(string.Empty)
                .ViewPlan();
            var SummaryAndApprovalComments = SummaryAndApproval.GetSummaryAndApprovalComments();
            foreach (var comment in SummaryAndApprovalComments.CommentsAndApprovers)
            {
                bool isFound = comment.Text.Contains(ApprovingRejectedPlanComment);
                if (isFound)
                {
                    Console.WriteLine(isFound);
                }
            }

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                     .withDepartment(FpcDept)
                     .withPlanStatus("New")
                     .withPlan(string.Empty)
                     .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();
            Assert.True(FpcPlanFilter.IsPlanDeleted(), "Plan was not deleted");
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyTheJourneyofPlanDetailExportToExcelTab()
        {
            By byExcelTab = By.XPath("//a[normalize-space()='Export to Excel']");
            By byPlanDetailTab = By.XPath("//a[normalize-space()='Plan Detail']");
            By bySkillMixSummary = By.XPath("//a[normalize-space()='Skill Mix Summary']");
            bool bDisplayed;
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                    .withDepartment(FpcDept)
                    .withPlanStatus("Approved")
                    .withPlan(string.Empty)
                    .ViewPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //CommonFunctions.getElement(byPlanDetailTab).Click();
            //bDisplayed = CommonFunctions.IsElementDisplayed(byExcelTab, 5);
            //Assert.True(bDisplayed, "Excel tab wasn't visible");
            //CommonFunctions.AddTestStep("Verify that the Excel tab is invisible", "The Excel tab is invisible");
            CommonFunctions.getElement(bySkillMixSummary).Click();
            bDisplayed = CommonFunctions.IsElementDisplayed(byExcelTab, 5);
            Assert.False(bDisplayed, "Excel tab was visible");
            CommonFunctions.AddTestStep("Verify that the Excel tab is visible", "The Excel tab is visible");


        }

        //Verify Plan detail FTEs Summary journey
        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyPlanDetailFTEsSummaryJourney()
        {
            
            string ApprovedComment = "Approving submitted plan";
            string RejectedComment = "Rejecting the submitted plan";
            string ApprovingRejectedPlanComment = "Approving the rejected plan";
            string FpcDept = SettingData.FpcDept;
            string FpcFacility = SettingData.FpcFacility;
            string deptOptionXpath = $"//*/div[@deptnumber='{FpcDept}']//select[@deptnumber='{FpcDept}' and contains(@id,'selectMonthPayPeriod')]";
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility(FpcFacility);
            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //Delete current working plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working")
               .withPlan(string.Empty)
               .DeletePlan();

            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            //create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            var FpcComment = FpcPlanMenu.Approve(ApprovedComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Create a new plan
            FpcPlanFilter.PlanFilter()
                .withDepartment(FpcDept)
                .withPlanStatus("New")
                .withPlan(string.Empty)
                .EditPlan();
            //Navigate to view plan detail page
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Reject a plan
            FpcComment = FpcPlanMenu.Reject(RejectedComment);
           // Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            //Approving a rejected plan
            FpcPlanFilter.PlanFilter()
               .withDepartment(FpcDept)
               .withPlanStatus("Working - Rejected")
               .withPlan(string.Empty)
               .ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();
            //Submit a plan
            FpcPlanMenu.Submit();
            //Approve a plan
            FpcComment = FpcPlanMenu.Approve(ApprovingRejectedPlanComment);
            //Console.WriteLine(FpcComment.PlanID);
            FpcPlanFilter.ViewPlanDetail();
            CommonFunctions.WaitUntilPageIsAcive();

            //verify comments in summary and approval page.
            SummaryAndApproval.GoTo();
            Assert.True(SummaryAndApproval.IsAt, "Summary And Approval page was not found");
            SummaryAndApprovalFilter.Filter()
                .withPlanStatus("All")
                .withDepartment(FpcDept)
                .withPlan(string.Empty)
                .ViewPlan();
            var SummaryAndApprovalComments = SummaryAndApproval.GetSummaryAndApprovalComments();
            foreach (var comment in SummaryAndApprovalComments.CommentsAndApprovers)
            {
                bool isFound = comment.Text.Contains(ApprovingRejectedPlanComment);
                if (isFound)
                {
                    Console.WriteLine(isFound);
                }
            }

            //Create a new FPC Plan
            FPCMainMenu.FPC.SelectPlan();
            Assert.True(FpcPlanFilter.IsAt, "FPC plan page was not displayed");
            FpcPlanFilter.PlanFilter()
                     .withDepartment(FpcDept)
                     .withPlanStatus("New")
                     .withPlan(string.Empty)
                     .EditPlan();
            
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyPlanDetailTabJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify FPC Plan detail Tab Journey";

            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");

            DepartmentOptions.GoTo();
            Assert.True(DepartmentOptions.IsAt, "DepartmentOptions page was not displayed.");
            DepartmentOptions.DeptOptions()
                .withDepartment("610")
                .withDepartmentCategory("Variable")
                .withIgnoreDepartment(false)
                .withAllowStatisticVolumeAdjustment(true)
                .withAllowPLUSSharedOutHourEntry(true)
                .withFreezeDepartmentPAVolumes(false)
                .withContractLaborPercentage("0.0")
                .withFixedNoOfFtes("0.0")
                .Save();

            StatisticVolumes.GoTo();
            Assert.True(StatisticVolumes.IsAt, "Statistic Volumes page was not displayed.");
            StatisticVolumes.DeptView()
                .withDepartment("610")
                .withPayPeriod("Current")
                .GetType();
            StatisticVolumesData.SetStatisticVolumesDeptViewData(3.00);
            var StatisticVolumesDeptViewDataResult = StatisticVolumesData.GetStatisticVolumesDeptViewData();

            StatisticVolumes.DaysView()
                .withDate("Current date")
                .withPayPeriod("Current")
                .withStatisticDescription("ALL")
                .GetData();
            StatisticVolumesData.SetStatisticVolumesDaysViewData(5.00);
            var StatisticVolumesDaysViewDataResults = StatisticVolumesData.GetStatisticVolumesDaysViewData();

            StatisticVolumes.FacilityLevelStatisticsView()
                .withPayPeriod("Current")
                .withDate("Current date")
                .GetData();
            StatisticVolumesData.SetStatisticVolumesFacilityLevelStatisticsViewData(6.00);
            var StatisticVolumesFacilityLevelStatisticsViewDataResults = StatisticVolumesData.GetStatisticVolumesFacilityLevelStatisticsViewData();

        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifySkillMixSummaryJourney()
        {
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");

            DepartmentOptions.GoTo();
            Assert.True(DepartmentOptions.IsAt, "DepartmentOptions page was not displayed.");
            DepartmentOptions.DeptOptions()
                .withDepartment("610")
                .withDepartmentCategory("Variable")
                .withIgnoreDepartment(false)
                .withAllowStatisticVolumeAdjustment(true)
                .withAllowPLUSSharedOutHourEntry(true)
                .withFreezeDepartmentPAVolumes(false)
                .withContractLaborPercentage("0.0")
                .withFixedNoOfFtes("0.0")
                .Save();

            StatisticVolumes.GoTo();
            Assert.True(StatisticVolumes.IsAt, "Statistic Volumes page was not displayed.");
            StatisticVolumes.DeptView()
                .withDepartment("610")
                .withPayPeriod("Current")
                .GetType();
            StatisticVolumesData.SetStatisticVolumesDeptViewData(3.00);
            var StatisticVolumesDeptViewDataResult = StatisticVolumesData.GetStatisticVolumesDeptViewData();

            StatisticVolumes.DaysView()
                .withDate("Current date")
                .withPayPeriod("Current")
                .withStatisticDescription("ALL")
                .GetData();
            StatisticVolumesData.SetStatisticVolumesDaysViewData(5.00);
            var StatisticVolumesDaysViewDataResults = StatisticVolumesData.GetStatisticVolumesDaysViewData();

            StatisticVolumes.FacilityLevelStatisticsView()
                .withPayPeriod("Current")
                .withDate("Current date")
                .GetData();
            StatisticVolumesData.SetStatisticVolumesFacilityLevelStatisticsViewData(6.00);
            var StatisticVolumesFacilityLevelStatisticsViewDataResults = StatisticVolumesData.GetStatisticVolumesFacilityLevelStatisticsViewData();

        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyRequisitionsJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Requisitions Journey";

            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            Division.SetPLUSDivisionAndFacility("34222");

            DepartmentOptions.GoTo();
            Assert.True(DepartmentOptions.IsAt, "DepartmentOptions page was not displayed.");
            DepartmentOptions.DeptOptions()
                .withDepartment("610")
                .withDepartmentCategory("Variable")
                .withIgnoreDepartment(false)
                .withAllowStatisticVolumeAdjustment(true)
                .withAllowPLUSSharedOutHourEntry(true)
                .withFreezeDepartmentPAVolumes(false)
                .withContractLaborPercentage("0.0")
                .withFixedNoOfFtes("0.0")
                .Save();

            StatisticVolumes.GoTo();
            Assert.True(StatisticVolumes.IsAt, "Statistic Volumes page was not displayed.");
            StatisticVolumes.DeptView()
                .withDepartment("610")
                .withPayPeriod("Current")
                .GetType();
            StatisticVolumesData.SetStatisticVolumesDeptViewData(3.00);
            var StatisticVolumesDeptViewDataResult = StatisticVolumesData.GetStatisticVolumesDeptViewData();

            StatisticVolumes.DaysView()
                .withDate("Current date")
                .withPayPeriod("Current")
                .withStatisticDescription("ALL")
                .GetData();
            StatisticVolumesData.SetStatisticVolumesDaysViewData(5.00);
            var StatisticVolumesDaysViewDataResults = StatisticVolumesData.GetStatisticVolumesDaysViewData();

            StatisticVolumes.FacilityLevelStatisticsView()
                .withPayPeriod("Current")
                .withDate("Current date")
                .GetData();
            StatisticVolumesData.SetStatisticVolumesFacilityLevelStatisticsViewData(6.00);
            var StatisticVolumesFacilityLevelStatisticsViewDataResults = StatisticVolumesData.GetStatisticVolumesFacilityLevelStatisticsViewData();

        }
        
       // [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyDeletePlanJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Delete plan journey";

            double dInterfacedHours, dDayAdjHrs, dNightAdjHrs, dTotalHrs, dTotal, dCalculatedTotalDollars, dTotalDollars;
            string FpcDept = SettingData.FpcDept;
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility("34222");
            ContractHours.GoTo();
            Assert.True(ContractHours.IsAt, "Contract hours page was not displayed.");
            ContractHours.DeptView()
                .withDepartment("610")
                .withSkillMix("163")
                .getData();
            CommonFunctions.WaitUntilPageIsAcive();
            ContarctHoursData.SetDepartmentAdjHours("6.00");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractHours.DeptView()
                .withDepartment("610")
                .withSkillMix("163")
                .getData();
            CommonFunctions.WaitUntilPageIsAcive();
            var DeptViewDataResult = ContarctHoursData.GetDeptarmentViewData();
            dInterfacedHours = CommonFunctions.ToDouble(DeptViewDataResult[0].InterfacedHours);
            dDayAdjHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].DayAdjHours);
            dNightAdjHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].NightAdjHours);
            dTotalHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].TotalHours);
            dTotalDollars = CommonFunctions.ToDouble(DeptViewDataResult[0].TotalDollars);
            dTotal = dInterfacedHours + dDayAdjHrs;
            Assert.True(dTotal == dTotalHrs, $"Dept veiew: Total {dTotal} doesn't match total hours {dTotalHrs}");


            //Days View
            ContractHours.DaysView()
                .withPayPeriod("Current")
                .withDate("current data")
                .withSkillMix("161")
                .GetData();
            CommonFunctions.WaitUntilPageIsAcive();
            //Adj hours
            ContarctHoursData.SetDaysAdjHours("4.00");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractHours.DaysView()
                .withPayPeriod("Current")
                .withDate("current data")
                .withSkillMix("161")
                .GetData();
            CommonFunctions.WaitUntilPageIsAcive();
            var DaysViewDataResult = ContarctHoursData.GetDaysViewData();
            dInterfacedHours = CommonFunctions.ToDouble(DaysViewDataResult[0].InterfacedHours);
            dDayAdjHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].DayAdjHours);
            dNightAdjHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].NightAdjHours);
            dTotalHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].TotalHours);
            dTotalDollars = CommonFunctions.ToDouble(DaysViewDataResult[0].TotalDollars);
            dTotal = dInterfacedHours + dDayAdjHrs;
            Assert.True(dTotal == dTotalHrs, $"Days view: Total {dTotal} doesn't match total hours {dTotalHrs}");
            //verify total dollars
            dCalculatedTotalDollars = CommonFunctions.ToDouble(DaysViewDataResult[0].Rate) * dTotalHrs;
            Assert.True(dTotalDollars == dCalculatedTotalDollars, $"dTotalDollars {dTotalDollars} doesn't match Calculated Total Dollars {dCalculatedTotalDollars}");
        }

        [Test]
        [Category("FPC"), Description("Journey")]
        public void VerifyFpcSummaryAndApprovalPlanSummaryJourney()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Fpc Summary And Approval Plan Summary Journey";

            double dInterfacedHours, dDayAdjHrs, dNightAdjHrs, dTotalHrs, dTotal, dCalculatedTotalDollars, dTotalDollars;
            string FpcDept = SettingData.FpcDept;
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility("34222");
            CommonFunctions.AddTestStep(FpcDept, "Set Division and facility.");
            ContractHours.GoTo();
            Assert.True(ContractHours.IsAt, "Contract hours page was not displayed.");
            ContractHours.DeptView()
                .withDepartment("610")
                .withSkillMix("163")
                .getData();
            CommonFunctions.WaitUntilPageIsAcive();
            ContarctHoursData.SetDepartmentAdjHours("6.00");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractHours.DeptView()
                .withDepartment("610")
                .withSkillMix("163")
                .getData();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep(FpcDept, "Set Department Adj hours to 6.00");
            var DeptViewDataResult = ContarctHoursData.GetDeptarmentViewData();
            dInterfacedHours = CommonFunctions.ToDouble(DeptViewDataResult[0].InterfacedHours);
            dDayAdjHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].DayAdjHours);
            dNightAdjHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].NightAdjHours);
            dTotalHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].TotalHours);
            dTotalDollars = CommonFunctions.ToDouble(DeptViewDataResult[0].TotalDollars);
            dTotal = dInterfacedHours + dDayAdjHrs;
            Assert.True(dTotal == dTotalHrs, $"Dept veiew: Total {dTotal} doesn't match total hours {dTotalHrs}");


            //Days View
            ContractHours.DaysView()
                .withPayPeriod("Current")
                .withDate("current data")
                .withSkillMix("161")
                .GetData();
            CommonFunctions.AddTestStep(FpcDept, "Get Days view data");
            CommonFunctions.WaitUntilPageIsAcive();
            //Adj hours
            ContarctHoursData.SetDaysAdjHours("4.00");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractHours.DaysView()
                .withPayPeriod("Current")
                .withDate("current data")
                .withSkillMix("161")
                .GetData();
            CommonFunctions.AddTestStep(FpcDept, "Set Days Adj hours to 4.00");
            CommonFunctions.WaitUntilPageIsAcive();
            var DaysViewDataResult = ContarctHoursData.GetDaysViewData();
            dInterfacedHours = CommonFunctions.ToDouble(DaysViewDataResult[0].InterfacedHours);
            dDayAdjHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].DayAdjHours);
            dNightAdjHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].NightAdjHours);
            dTotalHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].TotalHours);
            dTotalDollars = CommonFunctions.ToDouble(DaysViewDataResult[0].TotalDollars);
            dTotal = dInterfacedHours + dDayAdjHrs;
            Assert.True(dTotal == dTotalHrs, $"Days view: Total {dTotal} doesn't match total hours {dTotalHrs}");
            //verify total dollars
            dCalculatedTotalDollars = CommonFunctions.ToDouble(DaysViewDataResult[0].Rate) * dTotalHrs;
            Assert.True(dTotalDollars == dCalculatedTotalDollars, $"dTotalDollars {dTotalDollars} doesn't match Calculated Total Dollars {dCalculatedTotalDollars}");
        }

        
        private void TestingFpcPlan()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify Fpc Summary And Approval Plan Summary Journey";

            double dInterfacedHours, dDayAdjHrs, dNightAdjHrs, dTotalHrs, dTotal, dCalculatedTotalDollars, dTotalDollars;
            string FpcDept = SettingData.FpcDept;
            var homePage = new HomePage(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility("34222");
            ContractHours.GoTo();
            Assert.True(ContractHours.IsAt, "Contract hours page was not displayed.");
            ContractHours.DeptView()
                .withDepartment("610")
                .withSkillMix("163")
                .getData();
            CommonFunctions.WaitUntilPageIsAcive();
            ContarctHoursData.SetDepartmentAdjHours("6.00");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractHours.DeptView()
                .withDepartment("610")
                .withSkillMix("163")
                .getData();
            CommonFunctions.WaitUntilPageIsAcive();
            var DeptViewDataResult = ContarctHoursData.GetDeptarmentViewData();
            dInterfacedHours = CommonFunctions.ToDouble(DeptViewDataResult[0].InterfacedHours);
            dDayAdjHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].DayAdjHours);
            dNightAdjHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].NightAdjHours);
            dTotalHrs = CommonFunctions.ToDouble(DeptViewDataResult[0].TotalHours);
            dTotalDollars = CommonFunctions.ToDouble(DeptViewDataResult[0].TotalDollars);
            dTotal = dInterfacedHours + dDayAdjHrs;
            Assert.True(dTotal == dTotalHrs, $"Dept veiew: Total {dTotal} doesn't match total hours {dTotalHrs}");


            //Days View
            ContractHours.DaysView()
                .withPayPeriod("Current")
                .withDate("current data")
                .withSkillMix("161")
                .GetData();
            CommonFunctions.WaitUntilPageIsAcive();
            //Adj hours
            ContarctHoursData.SetDaysAdjHours("4.00");
            CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            ContractHours.DaysView()
                .withPayPeriod("Current")
                .withDate("current data")
                .withSkillMix("161")
                .GetData();
            CommonFunctions.WaitUntilPageIsAcive();
            var DaysViewDataResult = ContarctHoursData.GetDaysViewData();
            dInterfacedHours = CommonFunctions.ToDouble(DaysViewDataResult[0].InterfacedHours);
            dDayAdjHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].DayAdjHours);
            dNightAdjHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].NightAdjHours);
            dTotalHrs = CommonFunctions.ToDouble(DaysViewDataResult[0].TotalHours);
            dTotalDollars = CommonFunctions.ToDouble(DaysViewDataResult[0].TotalDollars);
            dTotal = dInterfacedHours + dDayAdjHrs;
            Assert.True(dTotal == dTotalHrs, $"Days view: Total {dTotal} doesn't match total hours {dTotalHrs}");
            //verify total dollars
            dCalculatedTotalDollars = CommonFunctions.ToDouble(DaysViewDataResult[0].Rate) * dTotalHrs;
            Assert.True(dTotalDollars == dCalculatedTotalDollars, $"dTotalDollars {dTotalDollars} doesn't match Calculated Total Dollars {dCalculatedTotalDollars}");
        }

    }
}
