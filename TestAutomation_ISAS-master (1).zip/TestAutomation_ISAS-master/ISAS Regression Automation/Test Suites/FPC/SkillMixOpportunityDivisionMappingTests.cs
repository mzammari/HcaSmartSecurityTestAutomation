using ClosedXML.Excel;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ISAS_Regression_Automation
{
    [TestFixture]
    [Category("FpcReportMapping")]
    public class SkillMixOpportunityDivisionMappingTests
    {
        private static readonly string[] Headers =
        {
            "Div", "COID/dept", "unit number", "dep", "GL Dept Desc", "Sun fun", "Mapping",
            "PLUS 14 Day FTE Paid Actual", "PLUS 14 Day FTE Paid Var", "PLUS 14 Day FTE Prod Actual",
            "PLUS 14 Day FTE Prod var", "PLUS 14 Day FTE CL FTEs", "Grid Status",
            "Approved/Approved Historical Staffing Grid RN", "Approved/Approved Historical Staffing Grid PCT",
            "Approved/Approved Historical Staffing Grid LPN", "Approved/Approved Historical Staffing Grid Clerical",
            "Approved/Approved Historical Staffing Grid Specialist",
            "Kronos/PLUS Keyed in CL 14 Day Skill Mix RN", "Kronos/PLUS Keyed in CL 14 Day Skill Mix PCT",
            "Kronos/PLUS Keyed in CL 14 Day Skill Mix LPN", "Kronos/PLUS Keyed in CL 14 Day Skill Mix Clerical",
            "Kronos/PLUS Keyed in CL 14 Day Skill Mix Specialist",
            "RN Target", "PCT Target", "LPN Target", "Clerical Target", "Specialist Target",
            "RN Actual", "PCT Actual", "LPN Actual", "Clerical Actual", "Specialist Actual",
            "Prod FTE Variance by Skill Mix RN Var", "Prod FTE Variance by Skill Mix PCT Var",
            "Prod FTE Variance by Skill Mix LPN Var", "Prod FTE Variance by Skill Mix Clerical Var",
            "Specialist Var", "Prod Index% RN", "Prod Index% PCT", "Prod Index% LPN", "Prod Index% Clerical",
            "RN+LPN", "PCT + Clerical", "Total(RN+LPN+PCT+Clerical)",
            "Missed Target RN Missed FTEs", "Missed Target LPN Missed FTEs",
            "Missed Target PCT Missed FTEs", "Missed Target ClericalMissed FTEs",
            "Missed Target RN+LPN Missed FTEs", "Missed Target RN+LPN Missed %"
        };

        [TestCase(false, "Approved/Approved Historical Staffing Grid", false)]
        [TestCase(true, "Approved/Approved Historical Staffing Grid", false)]
        [TestCase(true, "Approved Historical Staffing Grid", true)]
        [TestCase(true, "Approved Staffing Grid", true)]
        public void ParserRecognizesSuppliedMappings(bool grouped, string approvedHeading, bool metricFirst)
        {
            WithReport(grouped, approvedHeading, metricFirst, rows =>
            {
                Assert.That(rows, Has.Count.EqualTo(1));
                var row = rows.Single();
                var fields = SkillMixOpportunityReportDivisionExcelReport.RequiredValidationFields.ToArray();
                Assert.That(fields, Has.Length.EqualTo(Headers.Length));
                Assert.That(row.AvailableFields, Is.EquivalentTo(fields));
                for (int i = 0; i < fields.Length; i++)
                {
                    var property = typeof(SkillMixOpportunityReportDivisionData).GetProperty(fields[i]);
                    object expected = property.PropertyType == typeof(decimal) ? (object)(1000m + i) : TextValue(i);
                    Assert.That(property.GetValue(row), Is.EqualTo(expected), fields[i]);
                }
                Assert.That(row.AvailableFields, Does.Not.Contain(nameof(SkillMixOpportunityReportDivisionData.FacilityName)));
                Assert.That(row.AvailableFields, Does.Not.Contain(nameof(SkillMixOpportunityReportDivisionData.GroupName)));
                var dbRow = CreateDatabaseRow();
                Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { dbRow }));
            });
        }

        [Test]
        public void ValidatorIgnoresFieldsWithoutExcelMappings()
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var row = rows.Single();
                row.AvailableFields.Remove(nameof(SkillMixOpportunityReportDivisionData.AhsgRn));
                row.AvailableFields.Remove(nameof(SkillMixOpportunityReportDivisionData.DeptDescription));
                row.AhsgRn = -999m;
                row.DeptDescription = "Unmapped value must not be compared";
                Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { CreateDatabaseRow() }));
            });
        }

        [Test]
        public void ValidatorRejectsMappedValueMismatch()
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var dbRow = CreateDatabaseRow();
                dbRow.TargetPct += 10m;
                Assert.Throws<AssertionException>(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { dbRow }));
            });
        }

        [TestCase(nameof(SkillMixOpportunityReportDivisionData.UnitNumber))]
        [TestCase(nameof(SkillMixOpportunityReportDivisionData.SubFunctionNumber))]
        public void ValidatorComparesSecondaryIdentifierMismatchForUniqueDepartment(string fieldName)
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var dbRow = CreateDatabaseRow();
                typeof(SkillMixOpportunityReportDivisionData).GetProperty(fieldName).SetValue(dbRow, "999");
                var error = Assert.Throws<AssertionException>(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { dbRow }));
                Assert.That(error.Message, Does.Contain("0 unmatched or ambiguous Excel rows"));
                Assert.That(error.Message, Does.Contain($"1 mapped value mismatches out of {Headers.Length} comparisons"));
            });
        }

        [Test]
        public void ValidatorMatchesCompositeCoidAndPaddedDepartmentIdentifiers()
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var row = rows.Single();
                row.Coid = "0012345 / 00600";
                row.DeptNumber = "00600.0";
                row.UnitNumber = "0010.0";
                row.SubFunctionNumber = "0020";
                Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { CreateDatabaseRow() }));
            });
        }

        [Test]
        public void ValidatorUsesSecondaryIdentifiersForDuplicateDepartments()
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var otherUnit = CreateDatabaseRow();
                otherUnit.UnitNumber = "999";
                otherUnit.PaidActual = -999m;
                Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { otherUnit, CreateDatabaseRow() }));
            });
        }

        [Test]
        public void ValidatorRejectsAmbiguousDepartmentMatch()
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var first = CreateDatabaseRow();
                var second = CreateDatabaseRow();
                first.UnitNumber = "998";
                second.UnitNumber = "999";
                var error = Assert.Throws<AssertionException>(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { first, second }));
                Assert.That(error.Message, Does.Contain("1 unmatched or ambiguous Excel rows"));
                Assert.That(error.Message, Does.Contain("DB2 key samples"));
            });
        }

        [Test]
        public void ValidatorReportsMissingDepartmentWithKeySamples()
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var dbRow = CreateDatabaseRow();
                dbRow.Coid = "99999";
                var error = Assert.Throws<AssertionException>(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { dbRow }));
                Assert.That(error.Message, Does.Contain("1 unmatched or ambiguous Excel rows"));
                Assert.That(error.Message, Does.Contain("Excel key samples"));
                Assert.That(error.Message, Does.Contain("99999"));
            });
        }

        [TestCase("7 - TRISTAR DIVISION")]
        [TestCase("Tristar")]
        [TestCase(" TRISTAR DIVISION ")]
        public void ValidatorScopesDatabaseRowsByExcelDivisionName(string divisionName)
        {
            WithReport(false, string.Empty, false, rows =>
            {
                rows.Single().DivisionName = divisionName;
                var otherDivision = CreateDatabaseRow();
                otherDivision.DivisionName = "OTHER DIVISION";
                otherDivision.PaidActual = -999m;
                Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { otherDivision, CreateDatabaseRow() }));
            });
        }

        [Test]
        public void ValidatorDoesNotUseDepartmentFromAnotherDivision()
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var otherDivision = CreateDatabaseRow();
                otherDivision.DivisionName = "OTHER DIVISION";
                var error = Assert.Throws<AssertionException>(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { otherDivision }));
                Assert.That(error.Message, Does.Contain("1 unmatched or ambiguous Excel rows"));
                Assert.That(error.Message, Does.Contain("TRISTAR DIVISION"));
                Assert.That(error.Message, Does.Contain("OTHER DIVISION"));
            });
        }

        [TestCase(false)]
        [TestCase(true)]
        public void ValidatorHandlesSecondDetailSheetFacilityNamesAndFormattedPercentages(bool percentageText)
        {
            WithScreenshotLayout(rows =>
            {
                Assert.That(rows, Has.Count.EqualTo(1));
                var row = rows.Single();
                Assert.That(row.DivisionName, Is.EqualTo("TRISTAR"));
                Assert.That(row.FacilityName, Is.EqualTo("STONECREST MEDICAL CENTER"));
                Assert.That(row.DeptNumber, Is.EqualTo("604"));
                Assert.That(row.AvailableFields, Does.Not.Contain(nameof(SkillMixOpportunityReportDivisionData.Coid)));
                Assert.That(row.ProdIdxRn, Is.EqualTo(151.75m));
                Assert.That(row.MissingTargetPercent, Is.EqualTo(0.0018m));
                Assert.That(row.ProdRn, Is.EqualTo(3.93m));
                var expected = CreateScreenshotDatabaseRow();
                var otherFacility = CreateScreenshotDatabaseRow();
                otherFacility.FacilityName = "OTHER FACILITY";
                otherFacility.ProdIdxRn = -999m;
                Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { otherFacility, expected }));
            }, percentageText);
        }

        [TestCase(nameof(SkillMixOpportunityReportDivisionData.ProdIdxRn), 151.74)]
        [TestCase(nameof(SkillMixOpportunityReportDivisionData.MissingTargetPercent), 0.0031)]
        public void ValidatorRejectsDifferenceAtDisplayedPercentagePrecision(string fieldName, double value)
        {
            WithScreenshotLayout(rows =>
            {
                var expected = CreateScreenshotDatabaseRow();
                typeof(SkillMixOpportunityReportDivisionData).GetProperty(fieldName).SetValue(expected, (decimal)value);
                Assert.Throws<AssertionException>(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { expected }));
            });
        }

        [Test]
        public void ParserDoesNotFallBackToHospitalLevelWhenDetailIsMissing()
        {
            string path = Path.Combine(TestContext.CurrentContext.WorkDirectory, Guid.NewGuid() + ".xlsx");
            try
            {
                using (var workbook = new XLWorkbook())
                {
                    workbook.AddWorksheet("Hospital Level").Cell(1, 1).Value = "Summary only";
                    workbook.SaveAs(path);
                }
                var error = Assert.Throws<InvalidOperationException>(() =>
                    SkillMixOpportunityReportDivisionExcelReport.ParseSkillMixOpportunityReportDivisionExcel(path));
                Assert.That(error.Message, Does.Contain("required Detail sheet"));
            }
            finally
            {
                if (File.Exists(path))
                    File.Delete(path);
            }
        }

        [TestCase("Rolling 14 Day Dept Level FTE and Job Class Staffing Detail 8/10/2026 - 8/23/2026", "Rolling 14 Day", 10, 23)]
        [TestCase("Report Type: Month 2026-08-01 to 2026-08-31", "Month", 1, 31)]
        public void CriteriaAndQueryUseDatesFromDownloadedReport(string header, string reportType, int startDay, int endDay)
        {
            WithScreenshotLayout(rows => Assert.That(rows, Is.Not.Empty), validateCriteria: criteria =>
            {
                Assert.That(criteria.DivisionName, Is.EqualTo("TRISTAR"));
                Assert.That(criteria.DivisionNumber, Is.EqualTo(7));
                Assert.That(criteria.ReportType, Is.EqualTo(reportType));
                Assert.That(criteria.StartDate, Is.EqualTo(new DateTime(2026, 8, startDay)));
                Assert.That(criteria.EndDate, Is.EqualTo(new DateTime(2026, 8, endDay)));
                string query = SkillMixOpportunityReportDivisionSP.GetSkillMixOpportunityReportDivisionQuery(
                    criteria.DivisionNumber, criteria.StartDate, criteria.EndDate);
                Assert.That(query, Does.Contain($"DATE('2026-08-{startDay:00}'), DATE('2026-08-{endDay:00}')"));
                Assert.That(query, Does.Not.Contain("DATE(MAX(ACTIVITY_DATE))"));
            }, reportHeader: header);
        }

        [Test]
        public void CriteriaCanResolveDivisionNumberFromUiSelection()
        {
            string path = Path.Combine(TestContext.CurrentContext.WorkDirectory, Guid.NewGuid() + ".xlsx");
            try
            {
                using (var workbook = new XLWorkbook())
                {
                    workbook.AddWorksheet("Hospital Level");
                    var sheet = workbook.AddWorksheet("DETAIL");
                    sheet.Cell(1, 1).Value = "Div";
                    sheet.Cell(1, 2).Value = "COID/dept";
                    sheet.Cell(1, 3).Value = "dep";
                    sheet.Cell(2, 1).Value = "EXAMPLE";
                    sheet.Cell(2, 2).Value = "12345";
                    sheet.Cell(2, 3).Value = "604";
                    workbook.SaveAs(path);
                }
                var criteria = SkillMixOpportunityReportDivisionExcelReport.GetReportCriteria(path, "9 - EXAMPLE DIVISION");
                Assert.That(criteria.DivisionName, Is.EqualTo("EXAMPLE"));
                Assert.That(criteria.DivisionNumber, Is.EqualTo(9));
                Assert.That(criteria.StartDate, Is.Null);
                Assert.That(criteria.EndDate, Is.Null);
            }
            finally
            {
                if (File.Exists(path))
                    File.Delete(path);
            }
        }

        [Test]
        public void QueryRetainsLatestActivityFallbackAndRejectsInvalidDateRanges()
        {
            Assert.That(SkillMixOpportunityReportDivisionSP.GetSkillMixOpportunityReportDivisionQuery(7),
                Does.Contain("DATE(MAX(ACTIVITY_DATE)) - 13 DAYS"));
            Assert.Throws<ArgumentException>(() => SkillMixOpportunityReportDivisionSP.GetSkillMixOpportunityReportDivisionQuery(
                7, new DateTime(2026, 8, 10), null));
            Assert.Throws<ArgumentException>(() => SkillMixOpportunityReportDivisionSP.GetSkillMixOpportunityReportDivisionQuery(
                7, new DateTime(2026, 8, 23), new DateTime(2026, 8, 10)));
        }

        [Test]
        public void EmptyDetailDataDoesNotFailValidation()
        {
            string path = Path.Combine(TestContext.CurrentContext.WorkDirectory, Guid.NewGuid() + ".xlsx");
            try
            {
                using (var workbook = new XLWorkbook())
                {
                    workbook.AddWorksheet("Hospital Level").Cell(1, 1).Value = "Summary only";
                    workbook.AddWorksheet("DETAIL").Cell(1, 1).Value = "Report is downloaded with no data";
                    workbook.SaveAs(path);
                }
                Assert.That(SkillMixOpportunityReportDivisionExcelReport.HasValidationColumns(path), Is.False);
                var rows = SkillMixOpportunityReportDivisionExcelReport.ParseSkillMixOpportunityReportDivisionExcel(path);
                Assert.That(rows, Is.Empty);
                Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { CreateDatabaseRow() }));
            }
            finally
            {
                if (File.Exists(path))
                    File.Delete(path);
            }
        }

        [TestCase(0.04, true)]
        [TestCase(0.06, false)]
        public void ValidatorUsesOneDecimalPlaceForNumericValues(double difference, bool shouldMatch)
        {
            WithReport(false, string.Empty, false, rows =>
            {
                var expected = CreateDatabaseRow();
                expected.PaidActual = rows.Single().PaidActual + (decimal)difference;
                var databaseRows = new List<SkillMixOpportunityReportDivisionData> { expected };
                if (shouldMatch)
                    Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows, databaseRows));
                else
                    Assert.Throws<AssertionException>(() => SkillMixOpportunityReportDivisionValidator.Validate(rows, databaseRows));
            });
        }

        [Test]
        public void ValidatorRoundsPercentagesInDisplayedUnitsToOneDecimal()
        {
            WithScreenshotLayout(rows =>
            {
                var expected = CreateScreenshotDatabaseRow();
                expected.ProdIdxRn = 151.76m;
                expected.MissingTargetPercent = 0.0019m;
                Assert.DoesNotThrow(() => SkillMixOpportunityReportDivisionValidator.Validate(rows,
                    new List<SkillMixOpportunityReportDivisionData> { expected }));
            });
        }

        private static SkillMixOpportunityReportDivisionData CreateScreenshotDatabaseRow()
        {
            return new SkillMixOpportunityReportDivisionData
            {
                DivisionName = "TRISTAR DIVISION", FacilityName = "STONECREST MEDICAL CENTER",
                Coid = "12345", DeptNumber = "604", DeptDescription = "SPINE NURS",
                RnLpn = 130.47m, PctCle = 81.99m, ProdIdxRn = 151.75m,
                ProdIdxLpn = 0m, ProdIdxPct = 81.99m, ProdIdxClerical = 0m, TotalSkm = 113.72m,
                MissedTargetRnLpn = 0.52m, MissingTargetPercent = 0.0018m,
                MtfRn = 0.44m, MtfLpn = 0.08m, MtfPct = 0.26m, MtfClerical = 0m,
                ProdRn = 3.93m, ProdLpn = -1.24m, ProdPct = -0.84m,
                ProdClerical = 0m, ProdSpecialist = 0m
            };
        }

        private static void WithScreenshotLayout(Action<List<SkillMixOpportunityReportDivisionData>> validate, bool percentageText = false,
            Action<SkillMixOpportunityReportDivisionCriteria> validateCriteria = null, string reportHeader = null)
        {
            string path = Path.Combine(TestContext.CurrentContext.WorkDirectory, Guid.NewGuid() + ".xlsx");
            try
            {
                using (var workbook = new XLWorkbook())
                {
                    var summary = workbook.AddWorksheet("Hospital Level");
                    summary.Cell(1, 1).Value = "Div";
                    summary.Cell(1, 2).Value = "COID/dept";
                    summary.Cell(1, 3).Value = "dep";
                    summary.Cell(2, 1).Value = "WRONG DIVISION";
                    summary.Cell(2, 2).Value = "99999";
                    summary.Cell(2, 3).Value = "999";
                    var detail = workbook.AddWorksheet("DETAIL");
                    detail.Cell(1, 1).Value = "PLUS - SKILL MIX OPPORTUNITY REPORT - Department Detail";
                    detail.Cell(2, 1).Value = reportHeader ?? "Rolling 14 Day Dept Level FTE and Job Class Staffing Detail 8/10/2026 - 8/23/2026";
                    detail.Cell(3, 1).Value = "v_Div_Num = 7";
                    var headers = new[]
                    {
                        "Div", "COID Name", "Dep", "GL Dept Desc", "RN + LPN", "PCT + Clerical",
                        "RN", "LPN", "PCT", "Clerical", "Total(RN+LPN+PCT+Clerical)",
                        "RN+LPN Missed FTEs", "RN+LPN Missed %", "PCT + Clerical Missed FTEs",
                        "RN Missed FTEs", "LPN Missed FTEs", "PCT Missed FTEs", "Clerical Missed FTEs",
                        "Total Missed FTEs", "RN+LPN", "PCT+Clerical", "RN Var", "LPN Var", "PCT Var",
                        "Clerical Var", "Specialist Var"
                    };
                    for (int i = 0; i < headers.Length; i++)
                        detail.Cell(8, i + 1).Value = headers[i];
                    for (int column = 1; column <= 4; column++)
                    {
                        detail.Range(7, column, 8, column).Merge();
                        detail.Cell(7, column).Value = headers[column - 1];
                    }
                    detail.Range(7, 5, 7, 11).Merge();
                    detail.Cell(7, 5).Value = "Prod Index %";
                    detail.Range(7, 12, 7, 19).Merge();
                    detail.Cell(7, 12).Value = "Missed Targets";
                    detail.Range(7, 20, 7, 26).Merge();
                    detail.Cell(7, 20).Value = "Prod FTE Variance";
                    detail.Cell(9, 1).Value = "TRISTAR";
                    detail.Cell(9, 2).Value = "STONECREST MEDICAL CENTER";
                    detail.Cell(9, 3).Value = 604;
                    detail.Cell(9, 4).Value = "SPINE NURS";
                    var indexes = new[] { 1.3047m, 0.8199m, 1.5175m, 0m, 0.8199m, 0m, 1.1372m };
                    for (int i = 0; i < indexes.Length; i++)
                    {
                        detail.Cell(9, 5 + i).Value = indexes[i];
                        detail.Cell(9, 5 + i).Style.NumberFormat.Format = "0.00%";
                        if (percentageText)
                            detail.Cell(9, 5 + i).Value = (indexes[i] * 100m).ToString(System.Globalization.CultureInfo.InvariantCulture) + "%";
                    }
                    detail.Cell(9, 12).Value = 0.52m;
                    detail.Cell(9, 13).Value = 0.0018m;
                    detail.Cell(9, 13).Style.NumberFormat.Format = "0.00%";
                    if (percentageText)
                        detail.Cell(9, 13).Value = "0.18%";
                    detail.Cell(9, 14).Value = 999m;
                    detail.Cell(9, 15).Value = 0.44m;
                    detail.Cell(9, 16).Value = 0.08m;
                    detail.Cell(9, 17).Value = 0.26m;
                    detail.Cell(9, 18).Value = 0m;
                    detail.Cell(9, 19).Value = 999m;
                    detail.Cell(9, 20).Value = 999m;
                    detail.Cell(9, 21).Value = 999m;
                    detail.Cell(9, 22).Value = 3.93m;
                    detail.Cell(9, 23).Value = -1.24m;
                    detail.Cell(9, 24).Value = -0.84m;
                    detail.Cell(9, 25).Value = 0m;
                    detail.Cell(9, 26).Value = 0m;
                    workbook.SaveAs(path);
                }
                Assert.That(SkillMixOpportunityReportDivisionExcelReport.HasValidationColumns(path), Is.True);
                validate(SkillMixOpportunityReportDivisionExcelReport.ParseSkillMixOpportunityReportDivisionExcel(path));
                validateCriteria?.Invoke(SkillMixOpportunityReportDivisionExcelReport.GetReportCriteria(path, "7 - TRISTAR DIVISION"));
            }
            finally
            {
                if (File.Exists(path))
                    File.Delete(path);
            }
        }

        private static SkillMixOpportunityReportDivisionData CreateDatabaseRow()
        {
            var row = new SkillMixOpportunityReportDivisionData { FacilityName = "Ignored facility", GroupName = "Ignored group" };
            var fields = SkillMixOpportunityReportDivisionExcelReport.RequiredValidationFields.ToArray();
            for (int i = 0; i < fields.Length; i++)
            {
                var property = typeof(SkillMixOpportunityReportDivisionData).GetProperty(fields[i]);
                property.SetValue(row, property.PropertyType == typeof(decimal) ? (object)(1000m + i) : TextValue(i));
            }
            return row;
        }

        private static string TextValue(int index)
        {
            switch (index)
            {
                case 0: return "TRISTAR DIVISION";
                case 1: return "12345";
                case 2: return "10";
                case 3: return "600";
                case 5: return "20";
                default: return "Text " + index;
            }
        }

        private static void WithReport(bool grouped, string approvedHeading, bool metricFirst,
            Action<List<SkillMixOpportunityReportDivisionData>> validate)
        {
            string path = Path.Combine(TestContext.CurrentContext.WorkDirectory, Guid.NewGuid() + ".xlsx");
            try
            {
                using (var workbook = new XLWorkbook())
                {
                    workbook.AddWorksheet("Hospital Level").Cell(1, 1).Value = "Summary must not be validated";
                    var sheet = workbook.AddWorksheet("Detail");
                    int headerRow = grouped ? 8 : 1;
                    var fields = SkillMixOpportunityReportDivisionExcelReport.RequiredValidationFields.ToArray();
                    for (int i = 0; i < Headers.Length; i++)
                    {
                        sheet.Cell(headerRow, i + 1).Value = Headers[i];
                        var property = typeof(SkillMixOpportunityReportDivisionData).GetProperty(fields[i]);
                        if (property.PropertyType == typeof(decimal))
                            sheet.Cell(headerRow + 1, i + 1).Value = 1000m + i;
                        else
                            sheet.Cell(headerRow + 1, i + 1).Value = TextValue(i);
                    }
                    if (grouped)
                    {
                        sheet.Range(3, 14, 5, 18).Merge();
                        sheet.Cell(3, 14).Value = approvedHeading;
                        var skills = new[] { "RN", "PCT", "LPN", "Clerical", "Specialist" };
                        for (int i = 0; i < skills.Length; i++)
                            sheet.Cell(headerRow, 14 + i).Value = skills[i];
                        sheet.Range(6, 19, 7, 23).Merge();
                        sheet.Cell(6, 19).Value = "Kronos/PLUS Keyed in CL 14 Day Skill Mix";
                        for (int i = 0; i < skills.Length; i++)
                            sheet.Cell(headerRow, 19 + i).Value = skills[i];
                        sheet.Range(6, 24, 7, 28).Merge();
                        sheet.Cell(6, 24).Value = "Target";
                        for (int i = 0; i < skills.Length; i++)
                            sheet.Cell(headerRow, 24 + i).Value = skills[i];
                        sheet.Range(3, 46, 5, 51).Merge();
                        sheet.Cell(3, 46).Value = "Missed Target";
                        var missedSkills = new[] { "RN", "LPN", "PCT", "Clerical", "RN+LPN", "RN+LPN" };
                        for (int i = 0; i < missedSkills.Length; i++)
                        {
                            string metric = i == 5 ? "Missed %" : "Missed FTEs";
                            sheet.Cell(7, 46 + i).Value = metricFirst ? metric : missedSkills[i];
                            sheet.Cell(headerRow, 46 + i).Value = metricFirst ? missedSkills[i] : metric;
                        }
                    }
                    sheet.Cell(headerRow, Headers.Length + 1).Value = "FACILITY_NAME";
                    sheet.Cell(headerRow + 1, Headers.Length + 1).Value = "Different ignored facility";
                    sheet.Cell(headerRow, Headers.Length + 2).Value = "GROUP_NAME";
                    sheet.Cell(headerRow + 1, Headers.Length + 2).Value = "Different ignored group";
                    workbook.SaveAs(path);
                }
                Assert.That(SkillMixOpportunityReportDivisionExcelReport.HasValidationColumns(path), Is.True);
                validate(SkillMixOpportunityReportDivisionExcelReport.ParseSkillMixOpportunityReportDivisionExcel(path));
            }
            finally
            {
                if (File.Exists(path))
                    File.Delete(path);
            }
        }
    }
}
