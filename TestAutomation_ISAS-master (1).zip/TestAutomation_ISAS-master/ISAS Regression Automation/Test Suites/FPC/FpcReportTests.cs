﻿using ISAS_Regression_Automation.PageObjects.FPC.FPC_Reports;
using ISAS_Regression_Automation.PageObjects.FPC.FPC_Reports.Daily_Reports;
using IBM.Data.Db2;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    //[TestFixture]
    //[Parallelizable(ParallelScope.Self)]
    public class FpcReportTests : Driver
    {
        [SetUp]
        public void Init()
        {
            var homePage = new HomePage(Driver.Instance);
            var WFT_Admin_Plan = new WFT_Admin_Plan(Driver.Instance);
            homePage.NavigateToFPC();
            //Set Division and facility.
            Division.SetPLUSDivisionAndFacility();
        }


        [Test]
        [Category("FpcReports")]
        public void UerCanselectDailyTrendReportInExcelFormat()
        {
            RunData.AdoTestPlan = "FPC Reports Integration";
            RunData.AdoTestCaseName = "UerCanselectDailyTrendReportInExcelFormat";
            string reportType = "Month";
            string reportPeriod = "Current";
            string deptGroupSelection = "Department";
            string department = "the first department in the menu";
            DateTime downloadStartTime = DateTime.Now;

            DailyTrendReport.GoTo();
            Assert.True(DailyTrendReport.IsAt, "Daily Trend Report was not displayed.");
            DailyTrendReport.dailyTrendReport()
                .withReportType(reportType)
                .withReportPeriod(reportPeriod)
                .withDeptgroupSelection(deptGroupSelection)
                .withDepartment(department)
                .Excel();

            Thread.Sleep(5000);

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            CommonFunctions.AddTestStep("Wait for Skill Mix Opportunity Division Excel download", "This report can take longer than other FPC reports to download.");
            DateTime timeout = DateTime.Now.AddMinutes(3);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = downloadDirectory
                    .GetFiles("DailyTrend_*.xls*")
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Daily Trend Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            var excelData = DailyTrendReportExcelReport.ParseDailyTrendReportExcel(filePath);
            Assert.IsNotEmpty(excelData, "The parsed Daily Trend Report Excel data is empty.");
            CommonFunctions.AddTestStep("Parse the Daily Trend Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            var excelDates = excelData
                .Where(r => DateTime.TryParse(r.Key, out _))
                .Select(r => DateTime.Parse(r.Key))
                .OrderBy(d => d)
                .ToList();

            Assert.IsNotEmpty(excelDates, "No date rows were parsed from the Daily Trend Excel report.");
            DateTime startDate = excelDates.First();
            DateTime endDate = excelDates.Last();

            var dbData = DailyTrendReportDBLoader.LoadFromDatabase(reportType, reportPeriod, deptGroupSelection, department, startDate, endDate);
            Assert.IsNotEmpty(dbData, "The DB query returned no data for Daily Trend Report.");
            CommonFunctions.AddTestStep("Load Daily Trend Report from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            DailyTrendReportValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Daily Trend Excel vs DB2", "Daily Trend Report data validation passed.");
        }

        [Test]
        [Category("FpcReports")]
        public void UserCanselectDailyStaffingDivisionSummaryReportInExcelFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            string division = "7 - TRISTAR DIVISION";
            string reportType = "Month";
            string reportPeriod = "Current";
            DateTime downloadStartTime = DateTime.Now;

            DailyStaffingSummaryDivisionReport.GoTo();
            Assert.True(DailyStaffingSummaryDivisionReport.IsAt, "The Daily Staffing Summary Division Report was not displayed.");
            DailyStaffingSummaryDivisionReport.dailyStaffingSummaryDivisionReport()
                .withDivision(division)
                .withReportType(reportType)
                .withReportPeriod(reportPeriod)
                .Excel();

            Thread.Sleep(5000);

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            CommonFunctions.AddTestStep("Wait for Skill Mix Opportunity Division Excel download", "This report can take longer than other FPC reports to download.");
            DateTime timeout = DateTime.Now.AddMinutes(3);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = new[] { "DailyStaffingSummaryDivision_*.xls*", "*Daily*Staffing*Summary*Division*.xls*", "*Division*Staffing*Summary*.xls*" }
                    .SelectMany(pattern => downloadDirectory.GetFiles(pattern))
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Daily Staffing Summary Division Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            var excelData = DailyStaffingSummaryExcelReport.ParseDailyStaffingSummaryExcel(filePath);
            CommonFunctions.AddTestStep("Parse the Daily Staffing Summary Division Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                CommonFunctions.AddTestStep("Validate Daily Staffing Summary Division no-data report", "Report is downloaded but there is no data to validate.");
                return;
            }

            var reportCriteria = DailyStaffingSummaryExcelReport.GetReportCriteria(filePath, reportType, reportPeriod, division);
            CommonFunctions.AddTestStep("Read Daily Staffing Summary Division report criteria from Excel", $"Division: {reportCriteria.Division}, Report Type: {reportCriteria.ReportType}, Report Period: {reportCriteria.ReportPeriod}, Start Date: {reportCriteria.StartDate:yyyy-MM-dd}, End Date: {reportCriteria.EndDate:yyyy-MM-dd}");

            var dbData = DailyStaffingSummaryDBLoader.LoadFromDatabase(reportCriteria.Division, reportCriteria.ReportType, reportCriteria.ReportPeriod, reportCriteria.StartDate, reportCriteria.EndDate);
            CommonFunctions.AddTestStep("Load Daily Staffing Summary Division from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            if (!excelData.Any() && !dbData.Any())
            {
                Console.WriteLine("There were No records found");
                CommonFunctions.AddTestStep("Validate Daily Staffing Summary Division no-records result", "There were No records found");
                return;
            }

            Assert.IsNotEmpty(excelData, "The parsed Daily Staffing Summary Division report data is empty, but DB2 returned records.");
            Assert.IsNotEmpty(dbData, "The DB query returned no data for Daily Staffing Summary Division, but Excel returned records.");

            DailyStaffingSummaryValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Daily Staffing Summary Division Excel vs DB2", "Daily Staffing Summary Division data validation passed.");

        }

        [Test]
        [Category("FpcReports")]
        public void UserCanselectDailyStaffingSummaryIgnoreDeptReportInExcelFormat()
        { 
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            string reportType = "Month";
            string reportPeriod = "Current";
            DateTime downloadStartTime = DateTime.Now;

            DailyStaffingSummaryIgnoreDeptReport.GoTo();
            Assert.True(DailyStaffingSummaryIgnoreDeptReport.IsAt, "The Daily Staffing Summary Ignore Department Report was not displayed.");
            DailyStaffingSummaryIgnoreDeptReport.dailyStaffingSummaryIgnoreDeptReport()        
                .withReportType(reportType)
                .withReportPeriod(reportPeriod)
                .Excel();

            Thread.Sleep(5000);

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            DateTime timeout = DateTime.Now.AddSeconds(30);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = new[] { "DailyStaffingSummaryIgnoreDept_*.xls*", "*Daily*Staffing*Summary*Ignore*Dept*.xls*", "*Ignore*Dept*.xls*" }
                    .SelectMany(pattern => downloadDirectory.GetFiles(pattern))
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Daily Staffing Summary Ignore Dept Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            var excelData = DailyStaffingSummaryIgnoreDeptExcelReport.ParseDailyStaffingSummaryIgnoreDeptExcel(filePath);
            CommonFunctions.AddTestStep("Parse the Daily Staffing Summary Ignore Dept Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                CommonFunctions.AddTestStep("Validate Daily Staffing Summary Ignore Dept no-data report", "Report is downloaded but there is no data to validate.");
                return;
            }

            var reportCriteria = DailyStaffingSummaryIgnoreDeptExcelReport.GetReportCriteria(filePath, reportType, reportPeriod);
            CommonFunctions.AddTestStep("Read Daily Staffing Summary Ignore Dept report criteria from Excel", $"Report Type: {reportCriteria.ReportType}, Report Period: {reportCriteria.ReportPeriod}, Start Date: {reportCriteria.StartDate:yyyy-MM-dd}, End Date: {reportCriteria.EndDate:yyyy-MM-dd}");

            var dbData = DailyStaffingSummaryIgnoreDeptDBLoader.LoadFromDatabase(reportCriteria.ReportType, reportCriteria.ReportPeriod, reportCriteria.StartDate, reportCriteria.EndDate);
            CommonFunctions.AddTestStep("Load Daily Staffing Summary Ignore Dept from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            if (!excelData.Any() && !dbData.Any())
            {
                Console.WriteLine("There were No records found");
                CommonFunctions.AddTestStep("Validate Daily Staffing Summary Ignore Dept no-records result", "There were No records found");
                return;
            }

            Assert.IsNotEmpty(dbData, "The DB query returned no data for Daily Staffing Summary Ignore Dept, but Excel returned records.");

            DailyStaffingSummaryIgnoreDeptValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Daily Staffing Summary Ignore Dept Excel vs DB2", "Daily Staffing Summary Ignore Dept data validation passed.");
        }
        [Test]
        [Category("FpcReports")]
        public void UserCanselectDailyStaffingSummaryIgnoreDeptReportInPDFFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            DailyStaffingSummaryIgnoreDeptReport.GoTo();
            Assert.True(DailyStaffingSummaryIgnoreDeptReport.IsAt, "The Daily Staffing Summary Ignore Department Report was not displayed.");
            DailyStaffingSummaryIgnoreDeptReport.dailyStaffingSummaryIgnoreDeptReport()
                .withReportType("Month")
                .withReportPeriod("Current")
                .PDF();
        }

        [Test]
        [Category("FpcReports")]
        public void UserCanselectDailyStaffingPaidHoursSummaryReportInExcel()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            string reportType = "Month";
            string reportPeriod = "Current";
            DateTime downloadStartTime = DateTime.Now;

            DailyStaffingPaidHoursSummaryReport.GoTo();
            Assert.True(DailyStaffingPaidHoursSummaryReport.IsAt, "The Daily Staffing Paid Hours Summary Report was not displayed.");
            DailyStaffingPaidHoursSummaryReport.dailyStaffingPaidHoursSummaryReport()
                .withReportType(reportType)
                .withReportPeriod(reportPeriod)
                .Excel();

            Thread.Sleep(5000);

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            DateTime timeout = DateTime.Now.AddSeconds(30);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = new[] { "DailyStaffingPaidHoursSummary_*.xls*", "*Daily*Staffing*Paid*Hours*Summary*.xls*", "*Paid*Hours*Summary*.xls*" }
                    .SelectMany(pattern => downloadDirectory.GetFiles(pattern))
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Daily Staffing Paid Hours Summary Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            if (!DailyStaffingPaidHoursSummaryExcelReport.HasValidationColumns(filePath))
            {
                Console.WriteLine("Report is downloaded but required Excel column names are not available. Validation skipped.");
                CommonFunctions.AddTestStep("Validate Daily Staffing Paid Hours Summary missing-column report", "Report is downloaded but required Excel column names are not available. Validation skipped.");
                return;
            }

            var excelData = DailyStaffingPaidHoursSummaryExcelReport.ParseDailyStaffingPaidHoursSummaryExcel(filePath);
            CommonFunctions.AddTestStep("Parse the Daily Staffing Paid Hours Summary Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                CommonFunctions.AddTestStep("Validate Daily Staffing Paid Hours Summary no-data report", "Report is downloaded but there is no data to validate.");
                return;
            }

            var reportCriteria = DailyStaffingPaidHoursSummaryExcelReport.GetReportCriteria(filePath, reportType, reportPeriod);
            CommonFunctions.AddTestStep("Read Daily Staffing Paid Hours Summary report criteria from Excel", $"Report Type: {reportCriteria.ReportType}, Report Period: {reportCriteria.ReportPeriod}, Start Date: {reportCriteria.StartDate:yyyy-MM-dd}, End Date: {reportCriteria.EndDate:yyyy-MM-dd}");

            var dbData = DailyStaffingPaidHoursSummaryDBLoader.LoadFromDatabase(reportCriteria.ReportType, reportCriteria.ReportPeriod, reportCriteria.StartDate, reportCriteria.EndDate);
            CommonFunctions.AddTestStep("Load Daily Staffing Paid Hours Summary from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            Assert.IsNotEmpty(dbData, "The DB query returned no data for Daily Staffing Paid Hours Summary, but Excel returned records.");

            DailyStaffingPaidHoursSummaryValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Daily Staffing Paid Hours Summary Excel vs DB2", "Daily Staffing Paid Hours Summary data validation passed.");
        }

        [Test]
        [Category("FpcReports")]
        public void UserCanselectDailyUosErVisitsHoldsReportInExcel()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            string reportType = "Month";
            string reportPeriod = "Current";
            DateTime downloadStartTime = DateTime.Now;

            DailyUosErVisitsHoldsReport.GoTo();
            Assert.True(DailyUosErVisitsHoldsReport.IsAt, "The Daily Uos Er Visits Holds Report was not displayed.");
            DailyUosErVisitsHoldsReport.dailyUosErVisitsHoldsReport()
                .withReportType(reportType)
                .withReportPeriod(reportPeriod)
                .Excel();

            Thread.Sleep(5000);

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            DateTime timeout = DateTime.Now.AddSeconds(30);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = new[] { "DailyUosErVisitsHolds_*.xls*", "DailyUosErHold_*.xls*", "*Daily*Uos*Er*Visits*Holds*.xls*", "*Daily*Uos*Er*Hold*.xls*", "*UOS*ER*Visits*Holds*.xls*", "*UOS*ER*Hold*.xls*" }
                    .SelectMany(pattern => downloadDirectory.GetFiles(pattern))
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5) || f.LastWriteTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Daily UOS ER Visits Holds Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            if (!DailyUosErVisitsHoldsExcelReport.HasValidationColumns(filePath))
            {
                Console.WriteLine("Report is downloaded but required Excel column names are not available. Validation skipped.");
                CommonFunctions.AddTestStep("Validate Daily UOS ER Visits Holds missing-column report", "Report is downloaded but required Excel column names are not available. Validation skipped.");
                return;
            }

            var excelData = DailyUosErVisitsHoldsExcelReport.ParseDailyUosErVisitsHoldsExcel(filePath);
            CommonFunctions.AddTestStep("Parse the Daily UOS ER Visits Holds Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                CommonFunctions.AddTestStep("Validate Daily UOS ER Visits Holds no-data report", "Report is downloaded but there is no data to validate.");
                return;
            }

            var reportCriteria = DailyUosErVisitsHoldsExcelReport.GetReportCriteria(filePath, reportType, reportPeriod);
            CommonFunctions.AddTestStep("Read Daily UOS ER Visits Holds report criteria from Excel", $"Report Type: {reportCriteria.ReportType}, Report Period: {reportCriteria.ReportPeriod}, Department: {reportCriteria.DepartmentNumber}, Start Date: {reportCriteria.StartDate:yyyy-MM-dd}, End Date: {reportCriteria.EndDate:yyyy-MM-dd}");

            var dbData = DailyUosErVisitsHoldsDBLoader.LoadFromDatabase(reportCriteria.ReportType, reportCriteria.ReportPeriod, reportCriteria.DepartmentNumber, reportCriteria.StartDate, reportCriteria.EndDate);
            CommonFunctions.AddTestStep("Load Daily UOS ER Visits Holds from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            Assert.IsNotEmpty(dbData, "The DB query returned no data for Daily UOS ER Visits Holds, but Excel returned records.");

            DailyUosErVisitsHoldsValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Daily UOS ER Visits Holds Excel vs DB2", "Daily UOS ER Visits Holds data validation passed.");
        }


        [Test]
        [Category("FpcReports")]
        public void UerCanselectDailyTrendReportInPdfFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            DailyTrendReport.GoTo();
            Assert.True(DailyTrendReport.IsAt, "Daily Trend Report was not displayed.");
            DailyTrendReport.dailyTrendReport()
                .withReportType("Month")
                .withReportPeriod("Current")
                .withDeptgroupSelection("Department")
                .PDF();
        }

        [Test]
        [Category("FpcReports")]
        public void UerCanselectDailyStaffingSummaryReportInExcelFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            string reportType = "Month";
            string reportPeriod = "Current";
            DateTime downloadStartTime = DateTime.Now;

            DailyStaffingSummaryReport.GoTo();
            Assert.True(DailyStaffingSummaryReport.IsAt, "The Daily Staffing Summary Report was not displayed.");
            DailyStaffingSummaryReport.dailyStaffingSummaryReport()
                .withReportType(reportType)
                .withReportPeriod(reportPeriod)
                .Excel();

            Thread.Sleep(5000);

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            DateTime timeout = DateTime.Now.AddSeconds(30);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = new[] { "DailyStaffingSummary_*.xls*", "*Daily*Staffing*Summary*.xls*" }
                    .SelectMany(pattern => downloadDirectory.GetFiles(pattern))
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Daily Staffing Summary Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            var excelData = DailyStaffingSummaryExcelReport.ParseDailyStaffingSummaryExcel(filePath);
            CommonFunctions.AddTestStep("Parse the Daily Staffing Summary Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            var reportCriteria = DailyStaffingSummaryExcelReport.GetReportCriteria(filePath, reportType, reportPeriod);
            CommonFunctions.AddTestStep("Read Daily Staffing Summary report criteria from Excel", $"Report Type: {reportCriteria.ReportType}, Report Period: {reportCriteria.ReportPeriod}, Start Date: {reportCriteria.StartDate:yyyy-MM-dd}, End Date: {reportCriteria.EndDate:yyyy-MM-dd}");

            var dbData = DailyStaffingSummaryDBLoader.LoadFromDatabase(reportCriteria.ReportType, reportCriteria.ReportPeriod, reportCriteria.StartDate, reportCriteria.EndDate);
            CommonFunctions.AddTestStep("Load Daily Staffing Summary from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            if (!excelData.Any() && !dbData.Any())
            {
                Console.WriteLine("There were No records found");
                CommonFunctions.AddTestStep("Validate Daily Staffing Summary no-records result", "There were No records found");
                return;
            }

            Assert.IsNotEmpty(excelData, "The parsed Daily Staffing Summary report data is empty, but DB2 returned records.");
            Assert.IsNotEmpty(dbData, "The DB query returned no data for Daily Staffing Summary, but Excel returned records.");

            DailyStaffingSummaryValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Daily Staffing Summary Excel vs DB2", "Daily Staffing Summary data validation passed.");

        }

        [Test]
        [Category("FpcReports")]
        public void UerCanselectDailyStaffingSummaryReportInPdfFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            DailyStaffingSummaryReport.GoTo();
            Assert.True(DailyStaffingSummaryReport.IsAt, "The Daily Staffing Summary Report was not displayed.");
            DailyStaffingSummaryReport.dailyStaffingSummaryReport()
                .withReportType("Month")
                .withReportPeriod("Current")
                .withDateInMonth("the first day in the menu")
                .PDF();
                   }

        [Test]
        [Category("FpcReports")]
        public void UserCanSelectBiWeeklyDeptLaborUtilizTrendReportInExcelFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            string year = "current";
            string deptGroupSelection = "deptGroupSelection";
            string deptSelection = "deptSelection";
            string department = "the first department in the menu";
            DateTime downloadStartTime = DateTime.Now;

            BiWeeklyDeptLaborUtilizReport.GoTo();
            Assert.True(BiWeeklyDeptLaborUtilizReport.IsAt, "The Bi-Weekly Department Labor Utilization Report was not displayed");
            BiWeeklyDeptLaborUtilizReport.BiWeeklyDeptLaborUtiliz()
                .withYear(year)
                .withDeptGroupSelection(deptGroupSelection)
                .withDeptSelection(deptSelection)
                .withDepartment(department)
                .Excel();

            Thread.Sleep(5000);

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            DateTime timeout = DateTime.Now.AddSeconds(30);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = new[] { "BiWeeklyDeptLaborUtilizTrend_*.xls*", "BiWeeklyDepartmentalLaborUtilizationTrend_*.xls*", "*Bi*Weekly*Dept*Labor*Utiliz*Trend*.xls*", "*Bi*Weekly*Departmental*Labor*Utilization*Trend*.xls*", "*Dept*Labor*Util*.xls*", "*Departmental*Labor*Utilization*.xls*" }
                    .SelectMany(pattern => downloadDirectory.GetFiles(pattern))
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5) || f.LastWriteTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Bi-Weekly Dept Labor Utilization Trend Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            if (!BiWeeklyDeptLaborUtilizTrendExcelReport.HasValidationColumns(filePath))
            {
                Console.WriteLine("Report is downloaded but required Excel column names are not available. Validation skipped.");
                CommonFunctions.AddTestStep("Validate Bi-Weekly Dept Labor Utilization Trend missing-column report", "Report is downloaded but required Excel column names are not available. Validation skipped.");
                return;
            }

            var excelData = BiWeeklyDeptLaborUtilizTrendExcelReport.ParseBiWeeklyDeptLaborUtilizTrendExcel(filePath);
            CommonFunctions.AddTestStep("Parse the Bi-Weekly Dept Labor Utilization Trend Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                CommonFunctions.AddTestStep("Validate Bi-Weekly Dept Labor Utilization Trend no-data report", "Report is downloaded but there is no data to validate.");
                return;
            }

            var reportCriteria = BiWeeklyDeptLaborUtilizTrendExcelReport.GetReportCriteria(filePath);
            CommonFunctions.AddTestStep("Read Bi-Weekly Dept Labor Utilization Trend report criteria from Excel", $"COID: {reportCriteria.Coid}, Departments: {string.Join(", ", reportCriteria.DeptOrGroupNumbers)}, Start Date: {reportCriteria.StartDate:yyyy-MM-dd}, End Date: {reportCriteria.EndDate:yyyy-MM-dd}");

            var dbData = BiWeeklyDeptLaborUtilizTrendDBLoader.LoadFromDatabase(reportCriteria.Coid, reportCriteria.DeptOrGroupNumbers, reportCriteria.StartDate, reportCriteria.EndDate);
            CommonFunctions.AddTestStep("Load Bi-Weekly Dept Labor Utilization Trend from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            Assert.IsNotEmpty(dbData, "The DB query returned no data for Bi-Weekly Dept Labor Utilization Trend, but Excel returned records.");

            BiWeeklyDeptLaborUtilizTrendValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Bi-Weekly Dept Labor Utilization Trend Excel vs DB2", "Bi-Weekly Dept Labor Utilization Trend data validation passed.");
        }

        [Test]
        [Category("FpcReports")]
        public void UserCanSelectSkillMixOpportunityReportDivisionInExcelFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            string division = "7 - TRISTAR DIVISION";
            DateTime downloadStartTime = DateTime.Now;

            SkillMixOpportunityReportDivision.GoTo();
            Assert.True(SkillMixOpportunityReportDivision.IsAt, "The Skill Mix Opportunity Division Report was not displayed.");
            SkillMixOpportunityReportDivision.SkillMixOpportunityDivisionReport()
                .withDivision(division)
                .Excel();

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            CommonFunctions.AddTestStep("Wait for Skill Mix Opportunity Division Excel download", "This report can take longer than other FPC reports to download.");
            DateTime timeout = DateTime.Now.AddMinutes(3);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = new[] { "SkillMixOpportunityDivision_*.xls*", "*Skill*Mix*Opportunity*Division*.xls*", "*SkillMix*Opportunity*.xls*" }
                    .SelectMany(pattern => downloadDirectory.GetFiles(pattern))
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5) || f.LastWriteTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Skill Mix Opportunity Division Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            if (!SkillMixOpportunityReportDivisionExcelReport.HasValidationColumns(filePath))
            {
                Console.WriteLine("Report is downloaded but required Excel column names are not available. Validation skipped.");
                CommonFunctions.AddTestStep("Validate Skill Mix Opportunity Division missing-column report", "Report is downloaded but required Excel column names are not available. Validation skipped.");
                return;
            }

            var excelData = SkillMixOpportunityReportDivisionExcelReport.ParseSkillMixOpportunityReportDivisionExcel(filePath);
            CommonFunctions.AddTestStep("Parse the Skill Mix Opportunity Division Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                CommonFunctions.AddTestStep("Validate Skill Mix Opportunity Division no-data report", "Report is downloaded but there is no data to validate.");
                return;
            }

            var reportCriteria = SkillMixOpportunityReportDivisionExcelReport.GetReportCriteria(filePath, division);
            CommonFunctions.AddTestStep("Read Skill Mix Opportunity Division report criteria from Excel", $"Division: {reportCriteria.DivisionName}, Division Number: {reportCriteria.DivisionNumber}, Report Type: {reportCriteria.ReportType ?? "Not specified"}, Date Range: {(reportCriteria.StartDate.HasValue ? $"{reportCriteria.StartDate:yyyy-MM-dd} to {reportCriteria.EndDate:yyyy-MM-dd}" : "Latest 14-day activity window (no dates in Excel)")}");

            var dbData = SkillMixOpportunityReportDivisionDBLoader.LoadFromDatabase(reportCriteria.DivisionNumber, reportCriteria.StartDate, reportCriteria.EndDate);
            CommonFunctions.AddTestStep("Load Skill Mix Opportunity Division from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            Assert.IsNotEmpty(dbData, "The DB query returned no data for Skill Mix Opportunity Division, but Excel returned records.");

            SkillMixOpportunityReportDivisionValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Skill Mix Opportunity Division Excel vs DB2", "Skill Mix Opportunity Division data validation passed.");
        }

        [Test]
        [Category("FpcReports")]
        public void UserCanSelectBiWeeklyFpcStaffingSummaryReportInExcelFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            BiWeeklyFpcStaffingSummary.GoTo();
            Assert.True(BiWeeklyFpcStaffingSummary.IsAt, "The Bi-Weekly FPC Staffing Summary Report was not displayed");
            BiWeeklyFpcStaffingSummary.BiWeeklyFpcStaffingSummaryReport()
                .withPayPeriod("current")
                .Excel();

            // Wait for the file to download
            Thread.Sleep(5000);

            // Get the latest downloaded file matching the pattern BiWeeklyStaffingSummary_*.xls or .xlsx
            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            DateTime timeout = DateTime.Now.AddSeconds(30);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = downloadDirectory
                    .GetFiles("BiWeeklyStaffingSummary_*.xls*")
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }
            Assert.IsNotNull(filePath, "The downloaded BiWeeklyStaffingSummary Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            // Parse the downloaded Excel report
            var reportData = BiWeeklyFpcStaffingSummaryExcelReport.ParseBiWeeklyFpcStaffingSummaryExcel(filePath);
            Assert.IsNotEmpty(reportData, "The parsed Bi-Weekly FPC Staffing Summary report data is empty.");
            CommonFunctions.AddTestStep("Parse the Bi-Weekly FPC Staffing Summary Excel report", $"Successfully parsed {reportData.Count} rows from the report.");

            // Load data from DB and validate against Excel
            string payPeriod = "current"; // TODO: set actual pay period date used in the report
            var dbData = BiWeeklyFpcStaffingSummaryDBLoader.LoadFromDatabase(payPeriod);
            Assert.IsNotEmpty(dbData, "The DB query returned no data for BiWeekly FPC Staffing Summary.");
            CommonFunctions.AddTestStep("Load BiWeekly FPC Staffing Summary from DB", $"Successfully loaded {dbData.Count} rows from the database.");

            // Validate Excel vs DB
            BiWeeklyFpcStaffingSummaryValidator.Validate(reportData, dbData);
            CommonFunctions.AddTestStep("Validate Excel vs DB", "BiWeekly FPC Staffing Summary data validation passed.");
        }


        [Test]
        [Category("FpcReports")]
        public void UserCanSelectBiWeeklyFpcFacilityLaborUtilizTrendReportInExcelFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            BiWeeklyFacilityLaborUtilizTrendReport.GoTo();
            Assert.True(BiWeeklyFacilityLaborUtilizTrendReport.IsAt, "The Bi-Weekly FPC Facility Labor Utiliz Trend Report was not displayed");
            BiWeeklyFacilityLaborUtilizTrendReport.BiWeeklyFacilityLaborUtilizTrend()
                .withYear("current")
                .Excel();

        }

        [Test]
        [Category("FpcReports")]
        public void UserCanSelectBiWeeklyDivisionStaffingSummaryReportInExcelFormat()
        {
            RunData.AdoTestPlan = "FPC Journeys";
            RunData.AdoTestCaseName = "Verify the Journey of FPC Reports";
            DateTime downloadStartTime = DateTime.Now;

            BiWeeklyDivisionStaffingSummaryReport.GoTo();
            Assert.True(BiWeeklyDivisionStaffingSummaryReport.IsAt, "The Bi-Weekly Division Staffing Summary Report was not displayed");
            BiWeeklyDivisionStaffingSummaryReport.BiWeeklyDivisionStaffingSummary()
                .Excel();

            Thread.Sleep(5000);

            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            var downloadDirectory = new DirectoryInfo(downloadsPath);
            string filePath = null;
            DateTime timeout = DateTime.Now.AddSeconds(30);

            while (DateTime.Now < timeout && filePath == null)
            {
                filePath = new[] { "BiWeeklyDivisionStaffingSummary_*.xls*", "*Bi*Weekly*Division*Staffing*Summary*.xls*", "*Division*Staffing*Summary*.xls*" }
                    .SelectMany(pattern => downloadDirectory.GetFiles(pattern))
                    .Where(f => !f.Name.EndsWith(".crdownload", StringComparison.OrdinalIgnoreCase))
                    .Where(f => f.CreationTime >= downloadStartTime.AddSeconds(-5) || f.LastWriteTime >= downloadStartTime.AddSeconds(-5))
                    .OrderByDescending(f => f.CreationTime)
                    .FirstOrDefault()?.FullName;

                if (filePath == null)
                    Thread.Sleep(1000);
            }

            Assert.IsNotNull(filePath, "The downloaded Bi-Weekly Division Staffing Summary Excel file was not found in Downloads folder.");
            Assert.True(File.Exists(filePath), $"The downloaded Excel file was not found at: {filePath}");

            if (!BiWeeklyDivisionStaffingSummaryExcelReport.HasValidationColumns(filePath))
            {
                Console.WriteLine("Report is downloaded but required Excel column names are not available. Validation skipped.");
                CommonFunctions.AddTestStep("Validate Bi-Weekly Division Staffing Summary missing-column report", "Report is downloaded but required Excel column names are not available. Validation skipped.");
                return;
            }

            var excelData = BiWeeklyDivisionStaffingSummaryExcelReport.ParseBiWeeklyDivisionStaffingSummaryExcel(filePath);
            CommonFunctions.AddTestStep("Parse the Bi-Weekly Division Staffing Summary Excel report", $"Successfully parsed {excelData.Count} rows from the report.");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                CommonFunctions.AddTestStep("Validate Bi-Weekly Division Staffing Summary no-data report", "Report is downloaded but there is no data to validate.");
                return;
            }

            var reportCriteria = BiWeeklyDivisionStaffingSummaryExcelReport.GetReportCriteria(filePath);
            CommonFunctions.AddTestStep("Read Bi-Weekly Division Staffing Summary report criteria from Excel", $"Division: {reportCriteria.DivisionName}, Division Number: {reportCriteria.DivisionNumber}, Pay Period Ending Date: {reportCriteria.PayPeriodEndingDate:yyyy-MM-dd}");

            var dbData = BiWeeklyDivisionStaffingSummaryDBLoader.LoadFromDatabase(reportCriteria.DivisionNumber, reportCriteria.PayPeriodEndingDate);
            CommonFunctions.AddTestStep("Load Bi-Weekly Division Staffing Summary from DB2", $"Successfully loaded {dbData.Count} rows from the database.");

            Assert.IsNotEmpty(dbData, "The DB query returned no data for Bi-Weekly Division Staffing Summary, but Excel returned records.");

            BiWeeklyDivisionStaffingSummaryValidator.Validate(excelData, dbData);
            CommonFunctions.AddTestStep("Validate Bi-Weekly Division Staffing Summary Excel vs DB2", "Bi-Weekly Division Staffing Summary data validation passed.");
        }

      /*  [Test]
        [Category("FpcReports")]
        public void VerifyFpcDatabaseConnection()
        {
            string sServerName = RunData.FpcServerName;
            string DB = RunData.FpcDatabaseName;
            string connectionString = $"Server={sServerName};" +
                                      $"Database={DB};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            Console.WriteLine($"Attempting FPC DB2 connection...");
            Console.WriteLine($"  Server: {sServerName}");
            Console.WriteLine($"  Database: {DB}");
            Console.WriteLine($"  UserID: {RunData.UserName}");

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();
                Console.WriteLine($"✓ DB2 Connection successful!");
                Console.WriteLine($"  State: {connection.State}");
                Console.WriteLine($"  ServerVersion: {connection.ServerVersion}");

                // Quick test query
                using (var cmd = new DB2Command("SELECT 1 FROM SYSIBM.SYSDUMMY1", connection))
                {
                    var result = cmd.ExecuteScalar();
                    Console.WriteLine($"  Test query result: {result}");
                }
            }

            Assert.Pass("FPC DB2 Database connection verified successfully.");
        }
        */

    }

}
