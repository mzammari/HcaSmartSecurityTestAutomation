﻿
using System.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;
using System.Threading;
using AutomationCoreLite.Reporting;
using NUnit.Framework;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using static ISAS_Regression_Automation.WFTMainMenu.WFTReports;

namespace ISAS_Regression_Automation
{

    public class Division
    {
        public static int getLobID(string LineOfbusiness)
        {
            int lobID;
            Dictionary<string, int> dLOB = new Dictionary<string, int>()
            {
                {"Physician Practice", 2},
                {"Hospital/Facility",3},
                {"Surgery Centers", 4},
                {"Shared Services",5},
                {"Sold or Closed",6},
                {"Home Health and Hospice" ,7},
                {"Operations Overhead", 8},
                {"Other",9},
                {"Laboratories", 10},
                {"Centralized Service Centers" , 11},
                {"Corporate", 12},
                {"Urgent Care Centers", 13},
                {"Imaging", 14},
                {"Miscellaneous", 15},
                {"Clinical Services Overhead", 16},
                {"Physician Alignment Organization", 17}
            };
            dLOB.TryGetValue(LineOfbusiness, out lobID);
            return lobID;
        }     
        
        public static List<string> getLineOfBusiness()
        {
            Dictionary<string, int> dLOB = new Dictionary<string, int>()
            {
                {"Physician Practice", 2},
                {"Hospital/Facility",3},
                {"Surgery Centers", 4},
                {"Shared Services",5},
                {"Sold or Closed",6},
                {"Home Health and Hospice" ,7},
                {"Operations Overhead", 8},
                {"Other",9},
                {"Laboratories", 10},
                {"Centralized Service Centers" , 11},
                {"Corporate", 12},
                {"Urgent Care Centers", 13},
                {"Imaging", 14},
                {"Miscellaneous", 15},
                {"Clinical Services Overhead", 16},
                {"Physician Alignment Organization", 17}
            };
            List<string> lob = dLOB.Keys.ToList();
            return lob;

        }

        public static List<int> getFacilityCOIDs(string lobID)
        {
            try
            {
                List<int> lstCoid = new List<int>();
                string query = $"SELECT o.LOB, o.Description, s.Coid, s.FacilityName   FROM [ISAS_Security].[dbo].[Facility] s  join [dbo].[Facility_LOB_Order] o  on  s.LOB_ID = o.LOB_ID  where  o.LOB_ID = {lobID}";
                string connString = $"Data Source={RunData.ServerName};Initial Catalog={RunData.SecurityDB};Integrated Security=SSPI;";
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lstCoid.Add(reader.GetInt32(reader.GetOrdinal("Coid")));
                        }

                    }
                    conn.Close();

                    ////convert integer list to a string list
                    //List<string> stringList = lstCoid.Select(i => i.ToString()).ToList();   
                    return lstCoid;
                }
            }
            catch
            {
                Console.WriteLine("ex");
            }
            return null;
        }

        public static void SetWFTDivisionAndFacility()
        {
            string Divison = AdoTestData.Divison;
            string Facility = AdoTestData.Facility;
            CommonFunctions.WaitUntilPageIsAcive();
            By dllFacility = By.XPath("//*/div[@class='page']//select[@id='ddlFacility']");
            //var IWfacility = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10)).Until(ExpectedConditions.ElementToBeClickable(By.XPath("//*/select[@id='ddlFacility']")));
            //IWebElement mnuDivision = CommonFunctions.getElement(By.XPath("//*/select[@id='filterfacilitySelectionList']"));
            //CommonFunctions.SelectItemFromDropdownMenu(mnuDivision, Divison);
            //Thread.Sleep(7000);
            CommonFunctions.IsElementDisplayed(dllFacility, 20);
            IWebElement mnuFacility = CommonFunctions.getElement(dllFacility);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFacility, Facility);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Set WFT facility", "WFT facility");

        }

        public static void SetStaffingGridDivisionAndFacility()
        {
            string Divison = AdoTestData.Divison;
            string Facility = AdoTestData.Facility;
            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement mnuFacility = CommonFunctions.getElement(By.XPath("//*/div[not (@style='display: none')]//div[@class='facility-dropdown-container right']//select[@id='ddlFacility']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuFacility, Facility);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Set SG facility", "SG facility");
            // CommonFunctions.GetElementScreenShot(mnuFacility);

        }

        public static void SetStaffingGridDivisionAndFacility(string? pFacility)
        {
            By bySGFacility = By.XPath("//*/div[not (@style='display: none')]//div[@class='facility-dropdown-container right']//select[@id='ddlFacility']");
            var fac = pFacility ?? AdoTestData.Facility;
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed(bySGFacility, 60);
            IWebElement mnuFacility = CommonFunctions.getElement(bySGFacility);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFacility, fac);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Set SG facility", "SG facility");
            // CommonFunctions.GetElementScreenShot(mnuFacility);

        }

        public static void SetWFTDivisionAndFacility(string Facility)
        {
            //string Divison = TestData.Divison;
           // string Facility = TestData.Facility;
            var IWfacility = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(180)).Until(ExpectedConditions.ElementToBeClickable(By.XPath("//*/select[@id='filterfacilitySelectionList']")));
            IWebElement mnuDivision = CommonFunctions.getElement(By.XPath("//*/select[@id='filterfacilitySelectionList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDivision, "ALL");
            Thread.Sleep(7000);
            IWebElement mnuFacility = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlFacility']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuFacility, Facility);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep($"Set facility {Facility}", $"The {Facility} facility was selected");
        }

        public static void SetPLUSDivisionAndFacility()
        {
            string Divison = AdoTestData.Divison;
            string Facility = AdoTestData.Facility;
            var PlusFacility = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(180)).Until(ExpectedConditions.ElementToBeClickable(By.XPath("//*/select[@id='facilitySelectionList']")));
            IWebElement mnuDivision = CommonFunctions.getElement(By.XPath("//*/select[@id='filterfacilitySelectionList']"));
            //CommonFunctions.SelectItemFromDropdownMenu(mnuDivision, "All");
           // Thread.Sleep(7000);
            IWebElement mnuFacility = CommonFunctions.getElement(By.XPath("//*/select[@id='facilitySelectionList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuFacility, Facility);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep($"Set facility {Facility}", $"The {Facility} facility was selected");
            
        }

        public static void SetPLUSDivisionAndFacility(string pFacility)
        {
            bool bDisplayed;
            By byNavigateAway = By.XPath("//span[normalize-space()='Yes, Discard Changes and Navigate']");
            var PlusFacility = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(180)).Until(ExpectedConditions.ElementToBeClickable(By.XPath("//*/select[@id='facilitySelectionList']")));
            IWebElement mnuDivision = CommonFunctions.getElement(By.XPath("//*/select[@id='filterfacilitySelectionList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDivision, "ALL");
            Thread.Sleep(7000);
            IWebElement mnuFacility = CommonFunctions.getElement(By.XPath("//*/select[@id='facilitySelectionList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuFacility, pFacility);
            bDisplayed = CommonFunctions.IsElementDisplayed(byNavigateAway, 1);
            if(bDisplayed)
            {
                CommonFunctions.getElement(byNavigateAway).Click();
                CommonFunctions.WaitUntilPageIsAcive();
            }

            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep($"Set facility {pFacility}", $"The {pFacility} facility was selected");
        }
    }

    public class MenuSelector
    {
        public static void Select(string topLevelMenuID, string subMenuLinkText)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(topLevelMenuID)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            Driver.Wait(TimeSpan.FromSeconds((Driver.navigatonTimeSpanFromSeconds)));
            var byMenu = By.LinkText(subMenuLinkText);
            if (CommonFunctions.IsElementPresent(byMenu))
                CommonFunctions.getElement(byMenu).Click();
            CommonFunctions.AddTestStep($"Select {subMenuLinkText} from menu", $"{subMenuLinkText} is selected");
        }


        public static void SelectBy(By topLevelMenu, By secondLevelMenu)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(topLevelMenu));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            Driver.Wait(TimeSpan.FromSeconds((Driver.navigatonTimeSpanFromSeconds)));
            if (CommonFunctions.IsElementPresent(secondLevelMenu))
                CommonFunctions.getElement(secondLevelMenu).Click();
            CommonFunctions.AddTestStep($"Select {secondLevelMenu} from menu", $"{secondLevelMenu} is selected");


            //CommonFunctions.getElement(topLevelMenu).Click();
            //WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(20));
            //wait.Until(ExpectedConditions.ElementIsVisible(secondLevelMenu));
            //CommonFunctions.getElement(secondLevelMenu).Click();
        }
    }

    public class MenuLinkSelectorThreeLevels
    {
        public static Actions actions = new Actions(Driver.Instance);


        public static void Select(string topLevelMenuID, string secondLevelMenuID, string subMenuLinkText)
        {
            //CommonFunctions.getElement(By.Id(topLevelMenuID)).Click();
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(topLevelMenuID)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            var secondelement = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(secondLevelMenuID)));
            action.MoveToElement(secondelement).Perform();
            var thirdelement = wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText(subMenuLinkText)));
            action.MoveToElement(thirdelement).Perform();
            Driver.Wait(TimeSpan.FromSeconds((Driver.navigatonTimeSpanFromSeconds)));
            try
            {
                CommonFunctions.getElement(By.LinkText(subMenuLinkText)).Click();
                CommonFunctions.AddTestStep($"Select {subMenuLinkText} from menu", $"{subMenuLinkText} is selected");
            }
            catch
            {
                WebDriverWait waitForPage = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(90));
                waitForPage.Until(ExpectedConditions.ElementIsVisible(By.LinkText(subMenuLinkText)));
            }
        }

        public static void SelectWithMenuText(string topLevelMenuID, string secondLevelMenuID, string subMenuLinkText)
        {
            //CommonFunctions.getElement(By.LinkText(topLevelMenuID)).Click();
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText(topLevelMenuID)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            var secondelement = wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText(secondLevelMenuID)));
            action.MoveToElement(secondelement).Perform();
            var thirdelement = wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText(subMenuLinkText)));
            action.MoveToElement(thirdelement).Perform();
            Driver.Wait(TimeSpan.FromSeconds((Driver.navigatonTimeSpanFromSeconds)));
            CommonFunctions.AddTestStep($"Select {subMenuLinkText} from menu", $"{subMenuLinkText} is selected");
            //try
            //{
            //    CommonFunctions.getElement(By.LinkText(subMenuLinkText)).Click();
            //}
            //catch
            //{
            //    WebDriverWait waitForPage = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(90));
            //    waitForPage.Until(ExpectedConditions.ElementIsVisible(By.LinkText(subMenuLinkText)));
            //}
        }
       
        public static void SelectBy(By topLevelMenu, By secondLevelMenu, By subMenu)
        {
            SelectBy(topLevelMenu, secondLevelMenu, subMenu, 20);
        }

        public static void SelectBy(By topLevelMenu, By secondLevelMenu, By subMenu, int timeoutSeconds)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(timeoutSeconds));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(topLevelMenu));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            var secondelement = wait.Until(ExpectedConditions.ElementIsVisible(secondLevelMenu));
            action.MoveToElement(secondelement).Perform();
            secondelement.Click();
            var subMenuElement = wait.Until(ExpectedConditions.ElementToBeClickable(subMenu));
            action.MoveToElement(subMenuElement).Perform();
            subMenuElement.Click();
        }

        public static void SelectByHover(By topLevelMenu, By secondLevelMenu, By subMenu, int timeoutSeconds)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(timeoutSeconds));
            wait.IgnoreExceptionTypes(typeof(NoSuchElementException), typeof(StaleElementReferenceException));

            Actions action = new Actions(Driver.Instance);
            var element = wait.Until(ExpectedConditions.ElementIsVisible(topLevelMenu));
            action.MoveToElement(element).Perform();
            Thread.Sleep(500);

            var secondelement = wait.Until(ExpectedConditions.ElementIsVisible(secondLevelMenu));
            action.MoveToElement(secondelement).Perform();
            Thread.Sleep(500);

            try
            {
                var subMenuElement = wait.Until(ExpectedConditions.ElementIsVisible(subMenu));
                action.MoveToElement(subMenuElement).Click().Perform();
            }
            catch (WebDriverTimeoutException)
            {
                var subMenuElement = Driver.Instance.FindElements(subMenu).FirstOrDefault();
                if (subMenuElement == null)
                    throw;

                ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", subMenuElement);
            }
        }
    }

    public class MenuSelectorByLink 
    {
        public static void Select(string topLevelMenuLink, string subMenuLinkText)
        {

            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(20));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText(topLevelMenuLink)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            Driver.Wait(TimeSpan.FromSeconds((Driver.navigatonTimeSpanFromSeconds)));
            CommonFunctions.getElement(By.LinkText(subMenuLinkText)).Click();
            CommonFunctions.AddTestStep($"Select {subMenuLinkText} from menu", $"{subMenuLinkText} is selected");
        }

        public static void SelectTop(string topLevelMenuLink)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText(topLevelMenuLink)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Click();
            CommonFunctions.AddTestStep($"Select {topLevelMenuLink} from menu", $"{topLevelMenuLink} is selected");
        }
    }
    public class MenuSelectorByIdXPath
    {
        public static void Select(string topLevelMenuID, string subMenuXPathText)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(20));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(topLevelMenuID)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            Driver.Wait(TimeSpan.FromSeconds((Driver.navigatonTimeSpanFromSeconds)));
            CommonFunctions.getElement(By.XPath(subMenuXPathText)).Click();
            CommonFunctions.AddTestStep($"Select {subMenuXPathText} from menu", $"{subMenuXPathText} is selected");
        }
    }
    public class MenuSelectorByIdCss
    {
        public static void Select(string topLevelMenuID, string subMenuCssText)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(20));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(topLevelMenuID)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            Driver.Wait(TimeSpan.FromSeconds((Driver.navigatonTimeSpanFromSeconds)));
            CommonFunctions.getElement(By.CssSelector(subMenuCssText)).Click();
        }
    }

    public class MenuSelectorThreeLevelsMultiLinks
    {
        public static void Select(string topLevelMenuID, string secondLevelMenuLink, string subMenuLinkText)
        {
            //CommonFunctions.getElement(By.Id(topLevelMenuID)).Click();
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(20));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(topLevelMenuID)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Perform();
            var secondelement = wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText(secondLevelMenuLink)));
            action.MoveToElement(secondelement).Perform();
            Driver.Wait(TimeSpan.FromSeconds((Driver.navigatonTimeSpanFromSeconds)));
            CommonFunctions.getElement(By.LinkText(subMenuLinkText)).Click();
            CommonFunctions.AddTestStep($"Select {subMenuLinkText} from menu", $"{subMenuLinkText} is selected");
        }
    }
    public class MenuSelectorLink
    {
        public static void Select(string subMenuLinkText)
        {
            CommonFunctions.getElement(By.LinkText(subMenuLinkText)).Click();
        }
    }
    public class MenuLinkSelectorThreeLevelsID
    {
        public static void Select(string topLevelMenuID, string secondLevelMenuID, string subMenuID)
        {
            //CommonFunctions.getElement(By.Id(topLevelMenuID)).Click();
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(topLevelMenuID)));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Build().Perform();
            var secondelement = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(secondLevelMenuID)));
            Actions action2 = new Actions(Driver.Instance);
            action2.MoveToElement(secondelement).Build().Perform();
            var thirdelement = wait.Until(ExpectedConditions.ElementIsVisible(By.Id(subMenuID)));
            Actions action3 = new Actions(Driver.Instance);
            action3.MoveToElement(thirdelement).Click().Build().Perform();
            //Try catch adeded in order to PhamtonJS and chrome works, otherwise fails on Chrome
            try
            {
                CommonFunctions.getElement(By.Id(subMenuID)).Click();
            }
            catch
            {
            }
            WebDriverWait waitForPage = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(Driver.waitTime));
            waitForPage.Until(driver2 => ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("return document.readyState").Equals("complete"));
        }
    }

    public class MenuLinkSelectorTwolevels
    {
        public static void SelectBy(By topLevelMenu, By subMenu)
        {

            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
            var element = wait.Until(ExpectedConditions.ElementIsVisible(topLevelMenu));
            Actions action = new Actions(Driver.Instance);
            action.MoveToElement(element).Build().Perform();
            var secondelement = wait.Until(ExpectedConditions.ElementIsVisible(subMenu));
            CommonFunctions.ClickByJE(secondelement);
        }
    }
}

