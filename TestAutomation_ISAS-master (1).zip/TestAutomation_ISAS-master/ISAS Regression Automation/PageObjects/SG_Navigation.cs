﻿using AventStack.ExtentReports;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Threading;

namespace ISAS_Regression_Automation
{
    public class SG_NavigationPage: Driver
    {
        private IWebDriver driver;

        public SG_NavigationPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        By SG_StaffingGridDropdown = By.XPath("//*[@id=\"mainmenu\"]/div[1]/ul/li[2]/a/span");
        By SG_Administration = By.XPath("//*[@id=\"mainmenu\"]/div[1]/ul/li[2]/ul/li[1]/a");
        By SG_FilterFacilitySelectionListDropdown = By.XPath("//*[@id=\"filterfacilitySelectionList\"]");
        By SF_FacilityDropdown = By.XPath("//*[@id=\"ddlFacility\"]");
        By SG_NoOfRequiredApproversDropDown = By.XPath("//*[@id=\"ctrlRequiredApprovers\"]");
        By SG_DepartmentOptions = By.XPath("//*[@id=\"departmentOptionsContainer\"]/fieldset/a/legend");
        By SG_FromDropDown = By.XPath("//*[@id=\"ddlFromDept\"]");
        By SG_ToDropDown = By.XPath("//*[@id=\"ddlToDept\"]");
        By SG_ViewButton = By.XPath("//*[@id='btnView']");
        By SG_PrintButton = By.XPath("//*[@id=\"divButtonContainer\"]/ul/li[1]/a");
        By SG_SaveButton = By.XPath("//*[@id=\"divButtonContainer\"]/ul/li[2]/a");
        By SG_SaveButton_Yes = By.XPath("/html/body/div[4]/div[3]/div/button[1]");
        By SG_SaveButton_No = By.XPath("/html/body/div[4]/div[3]/div/button[2]");        
        By SG_CancelButton = By.XPath("//*[@id=\"divButtonContainer\"]/ul/li[3]/a");        
        By SG_DepartmentDetailsTableHeader = By.XPath("//*[@id=\"Table1\"]");    
        By SG_DepartmentDetailsTable = By.XPath("/html/body/div[2]/form/div[2]/div[4]/div[2]/div[2]/div/div/fieldset/div/a[1]/div/div/table");        
        By SG_SetOptionsForSelectedDepartment = By.XPath("//*[@id=\"deptGlobalValueDisplay\"]");
        By SG_FTEVarianceCheckBox = By.XPath("//*[@id=\"chkVariance\"]");
        By SG_FTEVarianceTextBox = By.XPath("//*[@id=\"txtVariance\"]");
        By SG_ShowPatientstoProfCheckbox = By.XPath("//*[@id=\"chkShowPatToProfRatio\"]");
        By SG_ShowPatientstoProfTextBox = By.XPath("//*[@id=\"ddlShowPatToProfRatio\"]");
        By SG_EnableUOSConversionfactorCheckBox = By.XPath("//*[@id=\"chkEnableUosConversionFactor\"]");
        By SG_EnableUOSConversionfactorDropDown = By.XPath("//*[@id=\"ddlEnableUosConversionFactor\"]");
        By SG_UOSConversionfactorCheckbox = By.XPath("//*[@id=\"chkUosConversionFactor\"]");
        By SG_UOSConversionfactorTextBox = By.XPath("//*[@id=\"txtUosConversionFactor\"]");
        By SG_AllowNegativeProductiveHoursCheckBox = By.XPath("//*[@id=\"chkAllowNegativeProductiveHours\"]");
        By SG_AllowNegativeProductiveHoursDropdown = By.XPath("//*[@id=\"ddlAllowNegativeProductiveHours\"]");
        By SG_SetFreqCountDateRangeCheckBox = By.XPath("//*[@id=\"chkFrequencyCountDateRange\"]");
        By SG_LatestFreqCountDateRangeStart = By.XPath("//*[@id=\"DFpicker\"]");
        By SG_LatestFreqCountDateRangeEnd = By.XPath("//*[@id=\"EFpicker\"]");
        By SG_ApplytoSelectedDepartmentsButton = By.XPath("//*[@id=\"applyToSelectedButton\"]");
               
        public void SelectStaffingGridDropdown() 
        {
            driver.FindElement(SG_StaffingGridDropdown).Click();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(SG_Administration));
        }
        public void ClickAdminstration()
        {
            driver.FindElement(SG_Administration).Click();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(SG_FilterFacilitySelectionListDropdown));
            Test.Log(Status.Info, "Navigation to Administration Page is Successful");
        }
        public void IsFilterFacilitySelectionListDropdownVisible()
        {
            Assert.IsTrue(driver.FindElement(SG_FilterFacilitySelectionListDropdown).Enabled);
            Test.Log(Status.Info, "'Filter Facility Selection List' dropdown is available and enabled");
        }
        public void IsFacilitiesDropdownVisible()
        {
            Assert.IsTrue(driver.FindElement(SF_FacilityDropdown).Enabled);
            Test.Log(Status.Info, "'Facilities' dropdown is available and enabled");
        }
        public void IsNoOfRequiredApproversVisible()
        {
            Assert.IsTrue(driver.FindElement(SG_NoOfRequiredApproversDropDown).Enabled);
            Test.Log(Status.Info, "'Number of Required Approvers' field is visible and enabled");
        }
        public void VerifyNoOfApproversDropdownList()
        {
            String[] strings = { "1 - One", "2 - Two", "3 - Three" };
            IWebElement dropdownElement = driver.FindElement(SG_NoOfRequiredApproversDropDown);
            SelectElement select = new SelectElement(dropdownElement);

            for (int i = strings.GetLowerBound(0); i <= strings.GetUpperBound(0); i++)
                select.SelectByText(strings[i]);

            Test.Log(Status.Info, "'Number of Required Approvers' dropdown values are verified along with Save functionality");
        }
        public void SelectApproversAndSave()
        {
            IWebElement dropdownElement = driver.FindElement(SG_NoOfRequiredApproversDropDown);
            SelectElement select = new SelectElement(dropdownElement);
            select.SelectByText("2 - Two");
            driver.FindElement(SG_SaveButton).Click();
            driver.FindElement(SG_SaveButton_Yes).Click();
        }
        public void IsDepartmentOptionsAvailable()
        {
            IWebElement label = driver.FindElement(SG_DepartmentOptions);            
            Assert.AreEqual("Department Options", label.Text);
            Test.Log(Status.Info, "'Department Options' section is visible");
        }
        public void SelectFromToValues(string fromValue, string toValue)
        {
            Thread.Sleep(1000);
            Assert.True(driver.FindElement(SG_FromDropDown).Enabled);
            SelectElement From = new SelectElement(driver.FindElement(SG_FromDropDown));
            From.SelectByText(fromValue);            
            SelectElement To = new SelectElement(driver.FindElement(SG_ToDropDown));
            To.SelectByText(toValue);            
            driver.FindElement(SG_ViewButton).Click();            
            Test.Log(Status.Info, "From and To options are available to select Department range and View button returns the department options");
        }
        public void AreAdministrationPageButtonsEnabled()
        {
            Assert.IsTrue(driver.FindElement(SG_ViewButton).Enabled);
            Assert.IsTrue(driver.FindElement(SG_PrintButton).Enabled);
            Assert.IsTrue(driver.FindElement(SG_SaveButton).Enabled);
        }
        public void ValidateTheDepartmentGrid()
        {
            IWebElement tableheader = driver.FindElement(SG_DepartmentDetailsTableHeader);
            String[] header = getDataParser().extractDataArray("StaffingGrid_Administration", "DeptHeader");
            var header1 = getDataParser().extractData("StaffingGrid_Administration", "From");

            for (int i = 0; i < 9; i++)
            {
                int j = i + 1;
                IWebElement cell = tableheader.FindElement(By.XPath(".//thead/tr/th[" + j + "]"));
                Assert.AreEqual(cell.Text, header[i]);                
            }
            Test.Log(Status.Info, "The header columns of Department Options section are validated against Test Data sheet");
        }
        public void ValidateSetOptionsforSelectedDept()
        {
            Thread.Sleep(5000);
            driver.FindElement(SG_SetOptionsForSelectedDepartment).Click();
            Assert.IsFalse(driver.FindElement(SG_FTEVarianceTextBox).Enabled);
            Assert.IsFalse(driver.FindElement(SG_ShowPatientstoProfTextBox).Enabled);
            Assert.IsFalse(driver.FindElement(SG_EnableUOSConversionfactorDropDown).Enabled);
            Assert.IsFalse(driver.FindElement(SG_UOSConversionfactorTextBox).Enabled);
            Assert.IsFalse(driver.FindElement(SG_AllowNegativeProductiveHoursDropdown).Enabled);
            Assert.IsFalse(driver.FindElement(SG_LatestFreqCountDateRangeStart).Enabled);
            Assert.IsFalse(driver.FindElement(SG_LatestFreqCountDateRangeEnd).Enabled);

            driver.FindElement(SG_FTEVarianceCheckBox).Click();
            driver.FindElement(SG_FTEVarianceTextBox).SendKeys(getDataParser().extractData("StaffingGrid_Administration", "SG_FTEVarianceTextBox"));
            Assert.IsTrue(driver.FindElement(SG_FTEVarianceTextBox).Enabled);

            driver.FindElement(SG_ShowPatientstoProfCheckbox).Click();
            new SelectElement(driver.FindElement(SG_ShowPatientstoProfTextBox)).SelectByText(getDataParser().extractData("StaffingGrid_Administration", "SG_ShowPatientstoProfTextBox"));
            Assert.IsTrue(driver.FindElement(SG_ShowPatientstoProfTextBox).Enabled);

            driver.FindElement(SG_EnableUOSConversionfactorCheckBox).Click();
            new SelectElement(driver.FindElement(SG_EnableUOSConversionfactorDropDown)).SelectByText(getDataParser().extractData("StaffingGrid_Administration", "SG_EnableUOSConversionfactorDropDown"));
            Assert.IsTrue(driver.FindElement(SG_EnableUOSConversionfactorDropDown).Enabled);

            driver.FindElement(SG_UOSConversionfactorCheckbox).Click();
            driver.FindElement(SG_UOSConversionfactorTextBox).Clear();
            driver.FindElement(SG_UOSConversionfactorTextBox).SendKeys(getDataParser().extractData("StaffingGrid_Administration", "SG_UOSConversionfactorTextBox"));
            Assert.IsTrue(driver.FindElement(SG_UOSConversionfactorTextBox).Enabled);            

            driver.FindElement(SG_AllowNegativeProductiveHoursCheckBox).Click();
            new SelectElement(driver.FindElement(SG_AllowNegativeProductiveHoursDropdown)).SelectByText(getDataParser().extractData("StaffingGrid_Administration", "SG_AllowNegativeProductiveHoursDropdown"));
            Assert.IsTrue(driver.FindElement(SG_AllowNegativeProductiveHoursDropdown).Enabled);

            driver.FindElement(SG_SetFreqCountDateRangeCheckBox).Click();
            driver.FindElement(SG_LatestFreqCountDateRangeStart).SendKeys(getDataParser().extractData("StaffingGrid_Administration", "SG_LatestFreqCountDateRangeStart"));
            driver.FindElement(SG_LatestFreqCountDateRangeEnd).SendKeys(getDataParser().extractData("StaffingGrid_Administration", "SG_LatestFreqCountDateRangeEnd"));
            Assert.IsTrue(driver.FindElement(SG_LatestFreqCountDateRangeStart).Enabled);
            Assert.IsTrue(driver.FindElement(SG_LatestFreqCountDateRangeEnd).Enabled);

            driver.FindElement(SG_ApplytoSelectedDepartmentsButton).Click();


            for (int i = 1; i < 3; i++)
            {
                var FTEVarianceTextBox = driver.FindElement(By.XPath("/html/body/div[2]/form/div[2]/div[4]/div[2]/div[2]/div/div/fieldset/div/a[1]/div/div/table/tbody/tr[" + i + "]/td[3]/input"));
                Assert.AreEqual(FTEVarianceTextBox.GetAttribute("value"), getDataParser().extractData("StaffingGrid_Administration", "SG_FTEVarianceTextBox"));

                var ShowPatientstoProfTextBox = new SelectElement(driver.FindElement(By.XPath("/html/body/div[2]/form/div[2]/div[4]/div[2]/div[2]/div/div/fieldset/div/a[1]/div/div/table/tbody/tr[" + i + "]/td[4]/select"))).SelectedOption.Text;
                Assert.AreEqual(ShowPatientstoProfTextBox, getDataParser().extractData("StaffingGrid_Administration", "SG_ShowPatientstoProfTextBox"));

                var EnableUOSConversionfactorDropDown = new SelectElement(driver.FindElement(By.XPath("/html/body/div[2]/form/div[2]/div[4]/div[2]/div[2]/div/div/fieldset/div/a[1]/div/div/table/tbody/tr[" + i + "]/td[5]/select"))).SelectedOption.Text;
                Assert.AreEqual(EnableUOSConversionfactorDropDown, getDataParser().extractData("StaffingGrid_Administration", "SG_EnableUOSConversionfactorDropDown"));

                var UOSConversionfactorTextBox = driver.FindElement(By.XPath("/html/body/div[2]/form/div[2]/div[4]/div[2]/div[2]/div/div/fieldset/div/a[1]/div/div/table/tbody/tr[" + i + "]/td[6]/input"));
                Assert.AreEqual(UOSConversionfactorTextBox.GetAttribute("value"), getDataParser().extractData("StaffingGrid_Administration", "SG_UOSConversionfactorTextBox"));

                var AllowNegativeProductiveHoursDropdown = new SelectElement(driver.FindElement(By.XPath("/html/body/div[2]/form/div[2]/div[4]/div[2]/div[2]/div/div/fieldset/div/a[1]/div/div/table/tbody/tr[" + i + "]/td[7]/select"))).SelectedOption.Text;
                Assert.AreEqual(AllowNegativeProductiveHoursDropdown, getDataParser().extractData("StaffingGrid_Administration", "SG_AllowNegativeProductiveHoursDropdown"));

                var LatestFreqCountDateRangeStart = driver.FindElement(By.XPath("/html/body/div[2]/form/div[2]/div[4]/div[2]/div[2]/div/div/fieldset/div/a[1]/div/div/table/tbody/tr[" + i + "]/td[8]/input"));
                Assert.AreEqual(LatestFreqCountDateRangeStart.GetAttribute("value"), getDataParser().extractData("StaffingGrid_Administration", "SG_LatestFreqCountDateRangeStart"));

                var LatestFreqCountDateRangeEnd = driver.FindElement(By.XPath("/html/body/div[2]/form/div[2]/div[4]/div[2]/div[2]/div/div/fieldset/div/a[1]/div/div/table/tbody/tr[" + i + "]/td[9]/input"));
                Assert.AreEqual(LatestFreqCountDateRangeEnd.GetAttribute("value"), getDataParser().extractData("StaffingGrid_Administration", "SG_LatestFreqCountDateRangeEnd"));
            }

            var windowHandlerSet = driver.WindowHandles;
            driver.FindElement(SG_SaveButton).Click();
            //// Wait until driver handle is set to something different
            //WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            //wait.Until(driver => !driver.WindowHandles.Equals(windowHandlerSet));
            Thread.Sleep(5000);
            driver.SwitchTo().Window(driver.WindowHandles[1]);
            driver.FindElement(SG_SaveButton_Yes).Click();
            driver.SwitchTo().Window(driver.WindowHandles[0]);
            Test.Log(Status.Info, "Setup Options is validated successfully");
        }
    }
}
