﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class HelpPage
    {
        public static void GoTo()
        {
            WFTMainMenu.Help.SelectContent();
        }

        public static bool IsAt
        {
            get
            {
                Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
                // "//*/div[@aria-labelledby='ui-dialog-title-Load-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='OK']"
                string xpath = "//*/div[@id='contentBody']//div[@id='mc-main-content']//p";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
    }
}
