﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class WFTFacilty
    {
       
        public static void GoTo()
        {
            WFTMainMenu.WorkloadForecast.Administration.SelectFacility();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlCreateNpPctMap']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public static WFTFaciltyCommand SetFacility()
        {
            return new WFTFaciltyCommand();
        }

    }
    #region: Action
    #region: WFTFaciltyCommand
    public class WFTFaciltyCommand
    {
        private string numberOfRequiredApprovers;
        private string newPlanNonProductivePercent;
        private string newPlanStatisticMapping;
        private string newPlanVclPercentOrFixedFtes;
        private string copyingPlanNonProductivePercent;
        private string copyingPlanStatisticMapping;
        private string copyingPlanEE_AHR_Months;
        private string copyingPlanCL_AHR_Months;
        private string copyingPlanCLPercentOrFixedFtes;
        private bool newDept;
        private string number;
        private string description;
        private string departmentType;
        private string defaultFacilityStat;
        private string departmentStat;

        public WFTFaciltyCommand withNumberOfRequiredApprovers(string NumberOfRequiredApprovers)
        {
            this.numberOfRequiredApprovers = NumberOfRequiredApprovers;
            return this;
        }

        public WFTFaciltyCommand withNewDeptartment(bool NewDept)
        {
            this.newDept = NewDept;
            return this;
        }

        public WFTFaciltyCommand withNewPlanNonProductivePercent(string NewPlanNonProductivePercent)
        {
            this.newPlanNonProductivePercent = NewPlanNonProductivePercent;
            return this;
        }

        public WFTFaciltyCommand withNewPlanStatisticMapping(string NewPlanStatisticMapping)
        {
            this.newPlanStatisticMapping = NewPlanStatisticMapping;
            return this;
        }

        public WFTFaciltyCommand withNewPlanVclPercentOrFixedFtes(string NewPlanVclPercentOrFixedFtes)
        {
            this.newPlanVclPercentOrFixedFtes = NewPlanVclPercentOrFixedFtes;
            return this;
        }

        public WFTFaciltyCommand withCopyingPlanNonProductivePercent(string CopyingPlanNonProductivePercent)
        {
            this.copyingPlanNonProductivePercent = CopyingPlanNonProductivePercent;
            return this;
        }

        public WFTFaciltyCommand withCopyingPlanStatisticMapping(string CopyingPlanStatisticMapping)
        {
            this.copyingPlanStatisticMapping = CopyingPlanStatisticMapping;
            return this;
        }

        public WFTFaciltyCommand withCopyingPlanEE_AHR_Months(string CopyingPlanEE_AHR_Months)
        {
            this.copyingPlanEE_AHR_Months = CopyingPlanEE_AHR_Months;
            return this;
        }

        public WFTFaciltyCommand withCopyingPlanCL_AHR_Months(string CopyingPlanCL_AHR_Months)
        {
            this.copyingPlanCL_AHR_Months = CopyingPlanCL_AHR_Months;
            return this;
        }

        public WFTFaciltyCommand withCopyingPlanCLPercentOrFixedFtes(string CopyingPlanCLPercentOrFixedFtes)
        {
            this.copyingPlanCLPercentOrFixedFtes = CopyingPlanCLPercentOrFixedFtes;
            return this;
        }

        public WFTFaciltyCommand withNumber(string Number)
        {
            this.number = Number;
            return this;
        }

        public WFTFaciltyCommand withDescription(string Description)
        {
            this.description = Description;
            return this;
        }

        public WFTFaciltyCommand withDepartmentType(string DepartmentType)
        {
            this.departmentType = DepartmentType;
            return this;
        }

        public WFTFaciltyCommand withDefaultFacilityStat(string DefaultFacilityStat)
        {
            this.defaultFacilityStat = DefaultFacilityStat;
            return this;
        }

        public WFTFaciltyCommand withDepartmentStat(string DepartmentStat)
        {
            this.departmentStat = DepartmentStat;
            return this;
        }

        private void setNumberOfRequiredApprovers()
        {
            IWebElement mnuNumberOfRequiredApprovers = CommonFunctions.getElement(By.XPath("//select[@id='ddlRequiredApprovers']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuNumberOfRequiredApprovers, numberOfRequiredApprovers);
        }

        private void getNumberOfRequiredApprovers()
        {
            IWebElement mnuNumberOfRequiredApprovers = CommonFunctions.getElement(By.XPath("//select[@id='ddlRequiredApprovers']"));
            FacilityMenuOptions.NumberOfRequiredApprovers = mnuNumberOfRequiredApprovers.Text.Trim();
        }

        private void clickMonthsToIncludeInDeptFacilityRatioTotal()
        {

            IList<IWebElement> lstMonths = CommonFunctions.getElements(By.XPath("//*/input[contains(@id,'excludeMonth')]"));
            foreach(var month in lstMonths)
            {
                if(!month.Selected)
                {
                    month.Click();
                }
            }
            //deselect Dec
            IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/input[contains(@id,'excludeMonth')])[12]"));
            if(Dec.Selected)
            {
                CommonFunctions.ClickByJE(Dec);
            }            
        }

        private void setNewPlanNonProductivePercent()
        {
            IWebElement mnuNewPlanNonProductivePercent = CommonFunctions.getElement(By.XPath("//select[@id='ddlCreateNpPctMap']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuNewPlanNonProductivePercent, newPlanNonProductivePercent);
        }

        private void getNewPlanNonProductivePercent()
        {
            IWebElement mnuNewPlanNonProductivePercent = CommonFunctions.getElement(By.XPath("//select[@id='ddlCreateNpPctMap']"));
            FacilityMenuOptions.NewPlanNonProductivePercent = mnuNewPlanNonProductivePercent.Text.Trim();
        }

        private void setNewPlanStatisticMapping()
        {
            IWebElement mnuNewPlanStatisticMapping = CommonFunctions.getElement(By.XPath("//select[@id='ddlCreatePlanStatMap']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuNewPlanStatisticMapping, newPlanStatisticMapping);
        }

        private void getNewPlanStatisticMapping()
        {
            IWebElement mnuNewPlanStatisticMapping = CommonFunctions.getElement(By.XPath("//select[@id='ddlCreatePlanStatMap']"));
            FacilityMenuOptions.NewPlanStatisticMapping = mnuNewPlanStatisticMapping.Text.Trim();
        }

        private void setNewPlanVclPercentOrFixedFtes()
        {
            IWebElement mnuNewPlanVclPercentOrFixedFtes = CommonFunctions.getElement(By.XPath("//select[@id='ddlCreateClPctFixedMap']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuNewPlanVclPercentOrFixedFtes, newPlanVclPercentOrFixedFtes);
        }

        private void getNewPlanVclPercentOrFixedFtes()
        {
            IWebElement mnuNewPlanVclPercentOrFixedFtes = CommonFunctions.getElement(By.XPath("//select[@id='ddlCreateClPctFixedMap']"));
            FacilityMenuOptions.NewPlanClPercentOrFixedFtes = mnuNewPlanVclPercentOrFixedFtes.Text.Trim();
        }

        private void setCopyingPlanNonProductivePercent()
        {
            IWebElement mnuCopyingPlanNonProductivePercent = CommonFunctions.getElement(By.XPath("//select[@id='ddlCopyNpPctSourceMap']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuCopyingPlanNonProductivePercent, copyingPlanNonProductivePercent);
        }

        private void getCopyingPlanNonProductivePercent()
        {
            IWebElement mnuCopyingPlanNonProductivePercent = CommonFunctions.getElement(By.XPath("//select[@id='ddlCopyNpPctSourceMap']"));
            FacilityMenuOptions.CopyingPlanNonProductivePercent = mnuCopyingPlanNonProductivePercent.Text.Trim();
        }

        private void setCopyingPlanStatisticMapping()
        {
            IWebElement mnuCopyingPlanStatisticMapping = CommonFunctions.getElement(By.XPath("//select[@id='ddlCopyePlanStatMap']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuCopyingPlanStatisticMapping, copyingPlanStatisticMapping);
        }

        private void getCopyingPlanStatisticMapping()
        {
            IWebElement mnuCopyingPlanStatisticMapping = CommonFunctions.getElement(By.XPath("//select[@id='ddlCopyePlanStatMap']"));
            FacilityMenuOptions.CopyingPlanStatisticMapping = mnuCopyingPlanStatisticMapping.Text.Trim();
        }

        private void setCopyingPlanEE_AHR_Months()
        {
            IWebElement mnuCopyingPlanEE_AHR_Months = CommonFunctions.getElement(By.XPath("//select[@id='ddlCopyELAHR']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuCopyingPlanEE_AHR_Months, copyingPlanEE_AHR_Months);
        }

        private void setCopyingPlanCL_AHR_Months()
        {
            IWebElement mnuCopyingPlanCL_AHR_Months = CommonFunctions.getElement(By.XPath("//select[@id='ddlCopyCLAHR']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuCopyingPlanCL_AHR_Months, copyingPlanCL_AHR_Months);
        }

        private void setCopyingPlanCLPercentOrFixedFtes()
        {
            IWebElement mnuCopyingPlanCLPercentOrFixedFtes = CommonFunctions.getElement(By.XPath("//select[@id='ddlCopyClPctFixedSourceMap']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuCopyingPlanCLPercentOrFixedFtes, copyingPlanCLPercentOrFixedFtes);
        }

        private void getCopyingPlanCLPercentOrFixedFtes()
        {
            IWebElement mnuCopyingPlanCLPercentOrFixedFtes = CommonFunctions.getElement(By.XPath("//select[@id='ddlCopyClPctFixedSourceMap']"));
            FacilityMenuOptions.CopyingPlanCLPercentOrFixedFtes = mnuCopyingPlanCLPercentOrFixedFtes.Text.Trim();
        }

        private void clickAddNewDepartment()
        {
            IWebElement cmdAddNewDepartment = CommonFunctions.getElement(By.XPath("//a[@id='addNewDeptBtn']"));
            CommonFunctions.ClickByJE(cmdAddNewDepartment);
        }

        private void setNumber()
        {
            IWebElement mnuNumber = CommonFunctions.getElement(By.XPath("//select[@id='ddlDept-new']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuNumber, number);
        }

        private void setDescription()
        {
            IWebElement txtDescription = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptDescription-new']"));
            CommonFunctions.ReplaceAndSetText(txtDescription, description);
        }

        private void setDepartmentType()
        {
            IWebElement mnuDepartmentType = CommonFunctions.getElement(By.XPath("//select[@id='ddlDeptType-new']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartmentType, departmentType);
        }

        private void setDefaultFacilityStat()
        {
            IWebElement mnuDefaultFacilityStat = CommonFunctions.getElement(By.XPath("//select[@id='ddlFacStat-new']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDefaultFacilityStat, defaultFacilityStat);
        }

        private void setDepartmentStat()
        {
            IWebElement txtDepartmentStat = CommonFunctions.getElement(By.XPath("//input[@id='txtStatDescription-new']"));
            CommonFunctions.ReplaceAndSetText(txtDepartmentStat, departmentStat);
        }

        private void clickDelete()
        {
            IWebElement cmdDelete = CommonFunctions.getElement(By.XPath("//*/div[contains(@id,'divDelBtn')]//a"));
            CommonFunctions.ClickByJE(cmdDelete);
        }

        private void clickYes()
        {
            IWebElement cmdYes = CommonFunctions.getElement(By.XPath("//*/div[contains(@aria-labelledby,'ui-dialog-title-delete-user-def-dept-confirm')]//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='Yes']/parent::button"));
            CommonFunctions.ClickByJE(cmdYes);
        }

        private void clickSave()
        {
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//a[@id='saveNewDeptBtn']"));
            CommonFunctions.ClickByJE(cmdSave);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private void clickComfirmSave()
        {
            IWebElement cmdComfirmSave = CommonFunctions.getElement(By.XPath("//*/div[contains(@aria-labelledby,'ui-dialog-title-save-confirm')]//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='Yes']/parent::button"));
            CommonFunctions.ClickByJE(cmdComfirmSave);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public void Save()
        {
            setNumberOfRequiredApprovers();
            clickMonthsToIncludeInDeptFacilityRatioTotal();
            setNewPlanNonProductivePercent();
            setNewPlanStatisticMapping();
            setNewPlanVclPercentOrFixedFtes();
            setCopyingPlanNonProductivePercent();
            setCopyingPlanStatisticMapping();
            setCopyingPlanEE_AHR_Months();
            setCopyingPlanCL_AHR_Months();
            setCopyingPlanCLPercentOrFixedFtes();           
            if(newDept)// add new dept is true
            {
                clickAddNewDepartment();
                setNumber();
                setDescription();
                setDepartmentType();
                setDefaultFacilityStat();
                setDepartmentStat();
                //clickDelete();
                //clickYes();
            }            
            clickSave();
            clickComfirmSave();
        }

        public void getFacilityOptions()
        {
            getNumberOfRequiredApprovers();
            getNewPlanNonProductivePercent();
            getNewPlanStatisticMapping();
            getNewPlanVclPercentOrFixedFtes();
            getCopyingPlanNonProductivePercent();
            getCopyingPlanStatisticMapping();
            getCopyingPlanCLPercentOrFixedFtes();
        }
    }
    #endregion
    public class FacilityMenuOptions
    {        
        public static string NumberOfRequiredApprovers { get; set; }
        public static string NewPlanNonProductivePercent { get; set; }
        public static string NewPlanStatisticMapping { get; set; }
        public static string NewPlanClPercentOrFixedFtes { get; set; }
        public static string CopyingPlanNonProductivePercent { get; set; }
        public static string CopyingPlanStatisticMapping { get; set; }
        public static string CopyingPlanCLPercentOrFixedFtes { get; set; }
    }
    #endregion
}
