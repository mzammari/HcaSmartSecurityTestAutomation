﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System.Threading;

namespace ISAS_Regression_Automation
{
    public class PlusInterface
    {
        public static void GoTo()
        {
            WFTMainMenu.WorkloadForecast.Administration.SelectPLUSInterface();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlYears']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public static PlusInterfaceCommand SelectBy(string Option)
        {
            return new PlusInterfaceCommand(Option);
        }
    }

    #region PlusInterfaceCommand
    public class PlusInterfaceCommand
    {
        private string interfaceTargetsFROM_Year;
        private string interfaceTargetsFROM_PlanStatus;
        private string interfaceTargetsFROM_Plan;
        private string interfaceTargetsFROM_BeginningMonth;
        private string interfaceTargetsFROM_EndMonth;
        private string interfaceTargetsTo_Year;
        private string interfaceTargetsTo_BeginningMonth;
        private string interfaceTargetsTo_EndMonth;
        private string deptOrGroup;
        private string option;

        public PlusInterfaceCommand(string Option)
        {
            this.option = Option; 
        }

        public PlusInterfaceCommand withInterfaceTargetsFROM_Year(string InterfaceTargetsFROM_Year)
        {
            this.interfaceTargetsFROM_Year = InterfaceTargetsFROM_Year;
            return this;
        }

        public PlusInterfaceCommand withDeptOrGroup(string DeptOrGroup)
        {
            this.deptOrGroup = DeptOrGroup;
            return this;
        }

        public PlusInterfaceCommand withInterfaceTargetsFROM_PlanStatus(string InterfaceTargetsFROM_PlanStatus)
        {
            this.interfaceTargetsFROM_PlanStatus = InterfaceTargetsFROM_PlanStatus;
            return this;
        }

        public PlusInterfaceCommand withInterfaceTargetsFROM_Plan(string InterfaceTargetsFROM_Plan)
        {
            this.interfaceTargetsFROM_Plan = InterfaceTargetsFROM_Plan;
            return this;
        }

        public PlusInterfaceCommand withInterfaceTargetsFROM_BeginningMonth(string InterfaceTargetsFROM_BeginningMonth)
        {
            this.interfaceTargetsFROM_BeginningMonth = InterfaceTargetsFROM_BeginningMonth;
            return this;
        }

        public PlusInterfaceCommand withInterfaceTargetsFROM_EndMonth(string InterfaceTargetsFROM_EndMonth)
        {
            this.interfaceTargetsFROM_EndMonth = InterfaceTargetsFROM_EndMonth;
            return this;
        }


        public PlusInterfaceCommand withInterfaceTargetsTo_Year(string InterfaceTargetsTo_Year)
        {
            this.interfaceTargetsTo_Year = InterfaceTargetsTo_Year;
            return this;
        }

        private void setInterfaceTargetsFROM_Year()
        {
            IWebElement mnuInterfaceTargetsFROM_Year = CommonFunctions.getElement(By.XPath("//select[@id='ddlYears']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuInterfaceTargetsFROM_Year, interfaceTargetsFROM_Year);
        }

        private void setInterfaceTargetsFROM_PlanStatus()
        {
            IWebElement mnuInterfaceTargetsFROM_PlanStatus = CommonFunctions.getElement(By.XPath("//select[@id='PlanStatus']"));
            CommonFunctions.SelectElementByValue(mnuInterfaceTargetsFROM_PlanStatus, interfaceTargetsFROM_PlanStatus.Trim());
            //switch (interfaceTargetsFROM_PlanStatus)
            //{
            //    case "Approved & Released":                   
            //        CommonFunctions.SelectItemFromDropdownMenuByIndex(mnuInterfaceTargetsFROM_PlanStatus, 0);
            //        break;
            //        case "Approved":                   
            //        CommonFunctions.SelectItemFromDropdownMenuByIndex(mnuInterfaceTargetsFROM_PlanStatus, 1);
            //        break;
            //}            
        }

        private void setInterfaceTargetsFROM_Plan()
        {
            IWebElement mnuInterfaceTargetsFROM_Plan = CommonFunctions.getElement(By.XPath("//select[@id='PlanStatus']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuInterfaceTargetsFROM_Plan, interfaceTargetsFROM_Plan);
        }

        private void setInterfaceTargetsTo_Year()
        {
            IWebElement mnuInterfaceTargetsTo_Year = CommonFunctions.getElement(By.XPath("//select[@id='ddlToYears']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuInterfaceTargetsTo_Year, interfaceTargetsTo_Year);
        }

        public PlusInterfaceCommand withInterfaceTargetsTo_BeginningMonth(string InterfaceTargetsTo_BeginningMonth)
        {
            this.interfaceTargetsTo_BeginningMonth = InterfaceTargetsTo_BeginningMonth;
            return this;
        }

        public PlusInterfaceCommand withInterfaceTargetsTo_EndMonth(string InterfaceTargetsTo_EndMonth)
        {
            this.interfaceTargetsTo_EndMonth = InterfaceTargetsTo_EndMonth;
            return this;
        }

        private void setSelectBy()
        {
            IWebElement mnuSelectBy = CommonFunctions.getElement(By.XPath("//select[@id='ddlwftGroupDepartments']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuSelectBy, option);
        }

        private void setDeptOrGroup()
        {
            bool bDisplayed;
            string deptXpath = "//*/input[@id='txtdept']";
            bDisplayed = CommonFunctions.IsElementDisplayed(deptXpath, 2);
            if (bDisplayed)
            {
                IWebElement txtDept = CommonFunctions.getElement(By.XPath(deptXpath));
                CommonFunctions.ReplaceAndSetText(txtDept, deptOrGroup);
                Thread.Sleep(2000);
            }
        }


        private void selectFromBeginningMonth()
        {
            if(!string.IsNullOrEmpty(interfaceTargetsFROM_BeginningMonth))
            {
                By byFromBeginningMonth = By.XPath("//select[@id='ddlBegin']");
                CommonFunctions.SelectItemFromDropdownMenu(CommonFunctions.getElement(byFromBeginningMonth), interfaceTargetsFROM_BeginningMonth);
            }
        }      

        private void selectFromEndMonth()
        {
            if (!string.IsNullOrEmpty(interfaceTargetsFROM_EndMonth))
            {
                By byFromEndMonth = By.XPath("//select[@id='ddlEnd']");
                CommonFunctions.SelectItemFromDropdownMenu(CommonFunctions.getElement(byFromEndMonth), interfaceTargetsFROM_EndMonth);
            }
        }
        private void selectToBeginningMonth()
        {
            if (!string.IsNullOrEmpty(interfaceTargetsTo_BeginningMonth))
            {
                By byToBeginningMonth = By.XPath("//select[@id='ddlToBegin']");
                CommonFunctions.SelectItemFromDropdownMenu(CommonFunctions.getElement(byToBeginningMonth), interfaceTargetsTo_BeginningMonth);
            }
        }
        private void selecToEndMonth()
        {
            if (!string.IsNullOrEmpty(interfaceTargetsTo_EndMonth))
            {
                By byToEndMonth = By.XPath("//select[@id='ddlToEnd']");
                CommonFunctions.SelectItemFromDropdownMenu(CommonFunctions.getElement(byToEndMonth), interfaceTargetsTo_EndMonth);
            }
        }

        private void clickSendToPLUS()
        {
            bool bExists;
            string ConfirmationXpath = "//*/div[@aria-describedby=\"data-send-confirmation-alert\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            string ValidationXpath = "//*/div[@aria-describedby=\"data-send-confirmation-message-alert\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='OK']";
            IWebElement cmdSendToPLUS = CommonFunctions.getElement(By.XPath("//input[@id='submit1']"));
            CommonFunctions.ClickByJE(cmdSendToPLUS);
            bExists = CommonFunctions.IsElementDisplayed(ConfirmationXpath, 40);
            if(bExists)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmationXpath));
                CommonFunctions.ClickByJE(cmdYes);
            }
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(2000);
            bExists = CommonFunctions.IsElementDisplayed(ValidationXpath, 40);
            if (bExists)
            {
                IWebElement cmdOK = CommonFunctions.getElement(By.XPath(ValidationXpath));
                CommonFunctions.ClickByJE(cmdOK);
            }
        }


        public void SendToPLUS()
        {
            setSelectBy();
            setInterfaceTargetsFROM_Year();
            setInterfaceTargetsFROM_PlanStatus();
            selectFromBeginningMonth();
            selectFromEndMonth();            
            setDeptOrGroup();
            //setInterfaceTargetsFROM_Plan();
            setInterfaceTargetsTo_Year();
            selectToBeginningMonth();
            selecToEndMonth();
            clickSendToPLUS();
            CommonFunctions.AddTestStep("Click the send to plus button", "The button is enabled and clickable");
        }
    }
    #endregion
}
