﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class CopyPlan
    {
        public static void GoTo()
        {
            string OKXpath = "//*/div[@aria-labelledby='ui-dialog-title-host_volumes_diff']//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='OK']";
            bool isDisplayed = CommonFunctions.IsElementDisplayed(OKXpath, 10);
            if(isDisplayed)
            {
                IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OKXpath));
                CommonFunctions.ClickByJE(cmdOK);
            }
            IWebElement cmdCopy = CommonFunctions.getElement(By.XPath("//*/button[@id='copyPlanBtn']"));
            cmdCopy.Click();
            CommonFunctions.AddTestStep("Click Copy button", "Copy Plan Year is displayed");
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlCopyPlanYear']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        public static CopyPlanCommand Copy()
        {
            return new CopyPlanCommand();
        }
    }
    #region: CopyPlanCommand
    public class CopyPlanCommand
    {
        private string planYear;
        private string description;
        private bool updateForecast;

        public CopyPlanCommand withPlanYear(string PlanYear)
        {
            this.planYear = PlanYear;
            return this;
        }

        public CopyPlanCommand withUpdateForecast(bool UpdateForecast)
        {
            this.updateForecast = UpdateForecast;
            return this;
        }

        public CopyPlanCommand withDescription(string Description)
        {
            this.description = Description;
            return this;
        }

        private void clickCopy()
        {
            IWebElement cmdCopy = CommonFunctions.getElement(By.XPath("//button[@id='copyPlanBtn']"));
            CommonFunctions.ClickByJE(cmdCopy);
        }

        private void setPlanYear()
        {
            IWebElement mnuPlanYear = CommonFunctions.getElement(By.XPath("//*/div[@id='copyWftPlan-dialog']//select[@id='ddlCopyPlanYear']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlanYear, planYear);
        }

        private void setDescription()
        {
            IWebElement txtDescription = CommonFunctions.getElement(By.XPath("//*/div[@id='copyWftPlan-dialog']//input[@id='copyPlanDescription']"));
            CommonFunctions.ReplaceAndSetText(txtDescription, description);
        }

        private void clickSave()
        {
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby=\"copyWftPlan-dialog\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Save']"));
            CommonFunctions.ClickByJE(cmdSave);
        }

        private void UpdateForecast()
        {

            string OKXpath = "//*/div[@aria-describedby=\"host_volumes_diff\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='OK']";
            bool isDisplayed = CommonFunctions.IsElementDisplayed(OKXpath, 10);
            if (isDisplayed)
            {
                if (updateForecast)
                {
                    IWebElement cmdUpdate = CommonFunctions.getElement(By.Id("chkHostUpdate"));
                    CommonFunctions.ClickByJE(cmdUpdate);
                }
                else
                {
                    IWebElement cmdNoUpdate = CommonFunctions.getElement(By.Id("chkNoHostUpdate"));
                    CommonFunctions.ClickByJE(cmdNoUpdate);
                }
                IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OKXpath));
                CommonFunctions.ClickByJE(cmdOK);
                CommonFunctions.IsElementDisplayed("//div[@id='facStatContent']//div[@id='monthly-header']", 30);
            }
        }

        public void Save()
        {
            clickCopy();
            setPlanYear();
            setDescription();
            clickSave();
            UpdateForecast();
            CommonFunctions.AddTestStep("Copy a plan", "New plan is created");
        }
    }
    #endregion
}
