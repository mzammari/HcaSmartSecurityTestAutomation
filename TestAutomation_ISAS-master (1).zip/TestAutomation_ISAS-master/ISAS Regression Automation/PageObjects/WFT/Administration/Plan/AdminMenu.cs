﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using AutomationCoreLite.Reporting;

namespace ISAS_Regression_Automation
{
    public class AdminMenu
    {
        #region: Action
        public static void GoToForecast()
        {
            bool isDisplayed;
            By byGoToForecast = By.XPath("//button[@id='navigateToForecastBudgetPageBtn']");
            isDisplayed = CommonFunctions.IsElementDisplayed(byGoToForecast, 2);
            if (isDisplayed)
            {
                IWebElement cmdGoToForecast = CommonFunctions.getElement(byGoToForecast);
                CommonFunctions.ClickByJE(cmdGoToForecast);
                CommonFunctions.WaitUntilPageIsAcive();
                //Update data dialog
                string OKXpath = "//*/div[@aria-labelledby='ui-dialog-title-host_volumes_diff']//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='OK']";
                isDisplayed = CommonFunctions.IsElementDisplayed(OKXpath, 5);
                if (isDisplayed)
                {
                    IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OKXpath));
                    CommonFunctions.ClickByJE(cmdOK);
                    CommonFunctions.WaitUntilPageIsAcive();
                }

                By byYesXpath = By.XPath("//*/div[@aria-describedby=\"dirtypage-nav-with-save-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']");
                isDisplayed = CommonFunctions.IsElementDisplayed(byYesXpath, 5);
                if (isDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(byYesXpath);
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                }
                CommonFunctions.WaitUntilPageIsAcive();
                string xpath = "//*/label[normalize-space()='Facility Stat']";
                CommonFunctions.IsElementDisplayed(xpath, 20);
                CommonFunctions.AddTestStep("Go to the forecast page", "Forecast page is displayed");
            }
        }

        public static bool DeletePlan(string PlanDescription)
        {
            bool bExists, bDisplayed;
            CommonFunctions.WaitUntilPageIsAcive();
            By byDeletePlan = By.XPath("//*/button[@id='deletePlanBtn']");
            bDisplayed = CommonFunctions.IsElementDisplayed(byDeletePlan, 2);
            if (bDisplayed)
            {

                IWebElement cmdDelete = CommonFunctions.getElement(byDeletePlan);
                CommonFunctions.ClickByJE(cmdDelete);

                string YesXpath = "//*/div[@aria-describedby=\"delete-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
                bExists = CommonFunctions.IsElementDisplayed(YesXpath, 5);
                if (bExists)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(YesXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    Thread.Sleep(10000);
                    CommonFunctions.WaitUntilPageIsAcive();
                }
                CommonFunctions.IsElementDisplayed("//*/div[@id='facilityStatsTab']//label[contains(text(),'proceeding')]", 42);
                CommonFunctions.WaitUntilPageIsAcive();
                ExistingPlanFilter.GoTo();
                bExists = ExistingPlanFilter.IsAt;
                bDisplayed = CommonFunctions.IsItemFoundinDropdownMenu("//select[@id='existingPlanDescriptionDropdown']", PlanDescription);
                CommonFunctions.AddTestStep("Click on the delete plan ", "The button is enabled");
                CommonFunctions.AddTestStep("Verify plan was deleted", $"{bDisplayed} plan was deleted");
                return bDisplayed;
            }
            return false;
        }

        public static void DeleteDefaultPlan()
        {
            bool bExists, bDisplayed;
            CommonFunctions.WaitUntilPageIsAcive();
            By byDeletePlan = By.XPath("//*/button[@id='deletePlanBtn']");
            bDisplayed = CommonFunctions.IsElementDisplayed(byDeletePlan, 2);
            if (bDisplayed)
            {

                IWebElement cmdDelete = CommonFunctions.getElement(byDeletePlan);
                CommonFunctions.ClickByJE(cmdDelete);

                string YesXpath = "//*/div[@aria-describedby=\"delete-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
                bExists = CommonFunctions.IsElementDisplayed(YesXpath, 5);
                if (bExists)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(YesXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                }
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Click on the delete plan ", "The button is enabled");
                CommonFunctions.AddTestStep("Verify plan was deleted", $"The plan was deleted");                
            }
        }

        public static void Save()
        {
            bool bExist;
            string SaveXpath;
            SaveXpath = "//*/button[@id='saveFacilityStatsBtn']";
            bExist = CommonFunctions.IsElementDisplayed(SaveXpath, 1);
            if (bExist)
            {
                IWebElement cmdSave = CommonFunctions.getElement(By.XPath(SaveXpath));
                CommonFunctions.ClickByJE(cmdSave);
                string yesBtnXpath = "//*/div[@aria-describedby=\"save-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
                bExist = CommonFunctions.IsElementDisplayed(yesBtnXpath, 2);
                if (bExist)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(yesBtnXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }
                string OKXpath = "//*/div[@aria-labelledby='ui-dialog-title-host_volumes_diff']//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='OK']";
                bExist = CommonFunctions.IsElementDisplayed(OKXpath, 2);
                if (bExist)
                {
                    IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OKXpath));
                    CommonFunctions.ClickByJE(cmdOK);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();

                }
                CommonFunctions.AddTestStep("Click Save", "Changes were saved");
            }
        }

        public static void Comments()
        {
            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement cmdComments = CommonFunctions.getElement(By.XPath("//*/button[@id='commentBtn']"));
            CommonFunctions.ClickByJE(cmdComments);
            CommonFunctions.AddTestStep("Click on the comment button", "The comment button is enabled");
        }
        #endregion
    }
}
