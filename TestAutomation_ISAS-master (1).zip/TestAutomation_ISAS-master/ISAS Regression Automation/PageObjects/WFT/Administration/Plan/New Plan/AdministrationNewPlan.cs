﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using static ISAS_Regression_Automation.ForecastView_ContractPercent;

namespace ISAS_Regression_Automation
{
    public class AdministrationNewPlan
    {
        public static void GoTo()
        {
            bool bDisplayed;
            By byChoosePlan = By.XPath("//*/h3[contains(@class,'ui-state-active')]");
            By byExpandPanel = By.XPath("//*/div[@id='choosePlanContainer']//a[contains(text(),'Choose')]");
            bDisplayed = CommonFunctions.IsElementDisplayed(byChoosePlan, 2);
            if (!bDisplayed)
            {

                IWebElement tbChoosePlan = CommonFunctions.getElement(byExpandPanel);
                CommonFunctions.ClickByJE(tbChoosePlan);
                CommonFunctions.WaitUntilPageIsAcive();
            }

            IWebElement tbCreateNewPlan = CommonFunctions.getElement(By.XPath("//*/a[@id='createNewPlan']"));
            CommonFunctions.ClickByJE(tbCreateNewPlan);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click new plan ", "New plan page is displayed.");
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='newPlanYearDropdown']";
                CommonFunctions.AddTestStep("Verify the new plan page is displayed", "the new plan page is displayed");
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public static AdministrationNewPlanCommand NewPlan()
        {
            return new AdministrationNewPlanCommand();
        }
    }

    #region: AdministrationNewPlanCommand 
    public class AdministrationNewPlanCommand
    {
        private string year;
        private string planDescription;
        private string approvers;
        private string budgetedvolumepercentage;
        private bool freezeFacilityRatiosAndVolumes;
        private bool freezeCL;
        private bool freezeNPRatiosAndVolumes;
        private bool freezeOT;
        private string forNonProductiveUse;
        private string statisticMapping;
        private string forCLPercentOrFixedFtesUse;
        private bool applyLatestQMIRSMonthRatetoAllMonths;
        private string loadProductivityTargets;
        private string pLUSTargetMonth;
        private string smoothRatios;
        private bool updateForecast;

        public AdministrationNewPlanCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public AdministrationNewPlanCommand withPlanDescription(string PlanDescription)
        {
            this.planDescription = PlanDescription;
            return this;
        }

        public AdministrationNewPlanCommand withUpdateForecast(bool UpdateForecast)
        {
            this.updateForecast = UpdateForecast;
            return this;
        }

        public AdministrationNewPlanCommand withApprovers(string Approvers)
        {
            this.approvers = Approvers;
            return this;
        }

        public AdministrationNewPlanCommand withBudgetedvolumepercentage(string Budgetedvolumepercentage)
        {
            this.budgetedvolumepercentage = Budgetedvolumepercentage;
            return this;
        }

        public AdministrationNewPlanCommand withFreezeFacilityRatiosAndVolumes(bool FreezeFacilityRatiosAndVolumes)
        {
            this.freezeFacilityRatiosAndVolumes = FreezeFacilityRatiosAndVolumes;
            return this;
        }

        public AdministrationNewPlanCommand withFreezeCL(bool FreezeCL)
        {
            this.freezeCL = FreezeCL; 
            return this;
        }

        public AdministrationNewPlanCommand withFreezeNPRatiosAndVolumes(bool FreezeNPRatiosAndVolumes)
        {
            this.freezeNPRatiosAndVolumes = FreezeNPRatiosAndVolumes;
            return this;
        }

        public AdministrationNewPlanCommand withFreezeOT(bool FreezeOT)
        {
            this.freezeOT = FreezeOT;
            return this;
        }

        public AdministrationNewPlanCommand withForNonProductiveUse(string ForNonProductiveUse)
        {
            this.forNonProductiveUse = ForNonProductiveUse;
            return this;
        }

        public AdministrationNewPlanCommand withStatisticMapping(string StatisticMapping)
        {
            this.statisticMapping = StatisticMapping;
            return this;
        }

        public AdministrationNewPlanCommand withForCLPercentOrFixedFtesUse(string ForCLPercentOrFixedFtesUse)
        {
            this.forCLPercentOrFixedFtesUse = ForCLPercentOrFixedFtesUse;
            return this;
        }

        public AdministrationNewPlanCommand withApplyLatestQMIRSMonthRatetoAllMonths(bool ApplyLatestQMIRSMonthRatetoAllMonths)
        {
            this.applyLatestQMIRSMonthRatetoAllMonths = ApplyLatestQMIRSMonthRatetoAllMonths;
            return this;
        }

        public AdministrationNewPlanCommand withLoadProductivityTargets(string LoadProductivityTargets)
        {
            this.loadProductivityTargets = LoadProductivityTargets;
            return this;
        }

        public AdministrationNewPlanCommand withPLUSTargetMonth(string PLUSTargetMonth)
        {
            this.pLUSTargetMonth = PLUSTargetMonth;
            return this;
        }

        public AdministrationNewPlanCommand withSmoothRatios(string SmoothRatios)
        {
            this.smoothRatios = SmoothRatios;
            return this;
        }

        private void setYear()
        {
            IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//*/select[@id='newPlanYearDropdown']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
        }

        private void setPlanDescription()
        {
            IWebElement txtPlanDescription = CommonFunctions.getElement(By.XPath("//*/input[@id='PlanDescription']"));
            CommonFunctions.ReplaceAndSetText(txtPlanDescription, planDescription);
        }

        private void setApprovers()
        {
            string xpath = "//*/fieldset[not(@disabled)]//select[@id='Approvers']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement mnuApprovers = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SelectItemFromDropdownMenu(mnuApprovers, approvers);
            }
        }
        private void getDefalutApprovers()
        {
            string xpath = "//*/fieldset[not(@disabled)]//select[@id='Approvers']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement mnuApprovers = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.Approvers = mnuApprovers.Text.Trim();
            }
        }

        private void setBudgetedvolumepercentage()
        {
            string xpath = "//*/fieldset[not(@disabled)]//input[@id='BudgetedVolumePercentage']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement txtBudgetedvolumepercentage = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.ReplaceAndSetText(txtBudgetedvolumepercentage, budgetedvolumepercentage);
            }
        }

        private void setAllMonths()
        {
            bool bSelected;
            string xpath = "(//*/fieldset[not(@disabled)]//input[@name='MonthsIncludedInRatio'])";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IList<IWebElement> lstMonths = CommonFunctions.getElements(By.XPath(xpath));
                foreach (var month in lstMonths)
                {
                    bSelected = false;
                    bSelected = month.Selected;
                    if (!bSelected)
                    {
                        month.Click();
                    }
                }
                //uncheck Nov and Dec. 
                lstMonths[10].Click();
                lstMonths[11].Click();
            }
        }

        private void getAllMonths()
        {
            By Jan = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[1]/input");
            NewPlanElements.Jan =  CommonFunctions.getElement(Jan).Selected;
            By Feb = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[2]/input");
            NewPlanElements.Feb = CommonFunctions.getElement(Feb).Selected;
            By Mar = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[3]/input");
            NewPlanElements.Mar = CommonFunctions.getElement(Mar).Selected;
            By Apr = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[4]/input");
            NewPlanElements.Apr = CommonFunctions.getElement(Apr).Selected;
            By May = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[5]/input");
            NewPlanElements.May = CommonFunctions.getElement(May).Selected;
            By Jun = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[6]/input");
            NewPlanElements.Jun = CommonFunctions.getElement(Jun).Selected;
            By Jul = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[7]/input");
            NewPlanElements.Jul = CommonFunctions.getElement(Jul).Selected;
            By Aug = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[8]/input");
            NewPlanElements.Aug = CommonFunctions.getElement(Aug).Selected;
            By Sep = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[9]/input");
            NewPlanElements.Sep = CommonFunctions.getElement(Sep).Selected;
            By Oct = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[10]/input");
            NewPlanElements.Oct = CommonFunctions.getElement(Oct).Selected;
            By Nov = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[11]/input");
            NewPlanElements.Nov = CommonFunctions.getElement(Nov).Selected;
            By Dec = By.XPath("//*/ul[@data-bind='foreach: MonthsIncludedInRatioList']//li[12]/input");
            NewPlanElements.Dec = CommonFunctions.getElement(Dec).Selected;
        }

        private void setFreezeFacilityRatiosAndVolumes()
        {
            string xpath = "//*/fieldset[not(@disabled)]//ul[@class='freeze-options']//li/label[contains(text(),'Volume')]/parent::li/input";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement mnuFreezeFacilityRatiosAndVolumes = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SetCheckbox(mnuFreezeFacilityRatiosAndVolumes, freezeFacilityRatiosAndVolumes);
            }
        }

        private void setFreezeCL()
        {
            string xpath = "//*/fieldset[not(@disabled)]//ul[@class='freeze-options']//li/label[contains(text(),'CL')]/parent::li/input";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement chkFreezeCL = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SetCheckbox(chkFreezeCL, freezeCL);
            }
        }

        private void setFreezeNPRatiosAndVolumes()
        {
            string xpath = "//*/fieldset[not(@disabled)]//ul[@class='freeze-options']//li/label[contains(text(),'NP')]/parent::li/input";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement chkFreezeNPRatiosAndVolumes = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SetCheckbox(chkFreezeNPRatiosAndVolumes, freezeNPRatiosAndVolumes);
            }
        }

        private void setFreezeOT()
        {
            string xpath = "//*/fieldset[not(@disabled)]//ul[@class='freeze-options']//li/label[contains(text(),'OT')]/parent::li/input";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement chkFreezeOT = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SetCheckbox(chkFreezeOT, freezeOT);
            }

        }

        private void setForNonProductiveUse()
        {
            if (!string.IsNullOrEmpty(forNonProductiveUse))
            {
                switch (forNonProductiveUse)
                {
                    case "QMIRS Avg. NP %":
                        clickQMIRSAvgNP();
                        break;
                    case "PLUS Avg. NP %":
                        clickPLUSAvgNP();
                        break;
                    case "Most Recent Approved Plan":
                        clickMostRecentApprovedPlan();
                        break;
                    case "Most Recent Approved & Released Plan":
                        clickMostRecentApprovedAndReleasedPlan();
                        break;
                }
            }
        }

        private void clickQMIRSAvgNP()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'QMIRS Avg')]/parent::td/input[@name='NonProductiveUse']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdQMIRSAvgNP = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.NonProductiveQMIRSAvgNpPercent = cmdQMIRSAvgNP.Selected;
                CommonFunctions.ClickByJE(cmdQMIRSAvgNP);
            }
        }

        private void clickQMIRSAvgNPII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'QMIRS Avg')]/parent::td/input[@name='NonProductiveUse']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdQMIRSAvgNP = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.NonProductiveQMIRSAvgNpPercent = cmdQMIRSAvgNP.Selected;
            }
        }

        private void clickPLUSAvgNP()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'PLUS')]/parent::td/input[@name='NonProductiveUse']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdPLUSAvgNP = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.NonProductivePLUSAvgNpPercent = cmdPLUSAvgNP.Selected;
                CommonFunctions.ClickByJE(cmdPLUSAvgNP);
            }
        }

        private void clickPLUSAvgNPII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'PLUS')]/parent::td/input[@name='NonProductiveUse']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdPLUSAvgNP = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.NonProductivePLUSAvgNpPercent = cmdPLUSAvgNP.Selected;
            }
        }

        private void clickMostRecentApprovedPlan()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Approved Plan')]/parent::td/input[@name='NonProductiveUse']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdMostRecentApprovedPlan = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.NonProductiveMostRecentApprovedPlan = cmdMostRecentApprovedPlan.Selected;   
                CommonFunctions.ClickByJE(cmdMostRecentApprovedPlan);
            }
        }
        private void clickMostRecentApprovedPlanII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Approved Plan')]/parent::td/input[@name='NonProductiveUse']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdMostRecentApprovedPlan = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.NonProductiveMostRecentApprovedPlan = cmdMostRecentApprovedPlan.Selected;
            }
        }

        private void clickMostRecentApprovedAndReleasedPlan()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Released')]/parent::td/input[@name='NonProductiveUse']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdMostRecentApprovedAndReleasedPlan = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.NonProductiveMostRecentApprovedAndReleasedPlan = cmdMostRecentApprovedAndReleasedPlan.Selected; 
                CommonFunctions.ClickByJE(cmdMostRecentApprovedAndReleasedPlan);
            }
        }

        private void clickMostRecentApprovedAndReleasedPlanII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Released')]/parent::td/input[@name='NonProductiveUse']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdMostRecentApprovedAndReleasedPlan = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.NonProductiveMostRecentApprovedAndReleasedPlan = cmdMostRecentApprovedAndReleasedPlan.Selected;
            }
        }


        private void setStatisticMapping()
        {
            if (!string.IsNullOrEmpty(statisticMapping))
            {
                switch (statisticMapping)
                {
                    case "System Default":
                        clickSystemDefault();
                        break;
                    case "Most Recent Approved Plan":
                        clickStatisticmappingMostRecentApprovedPlan();
                        break;
                    case "Most Recent Approved & Released Plan":
                        clickStatisticmappingMostRecentApprovedAndReleasedPlan();
                        break;

                }
            }
        }

        private void clickSystemDefault()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'System')]/parent::td/input[@name='StatisticMapping']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdSystemDefault = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.StatisticMappingSystemDefault = cmdSystemDefault.Selected;
                CommonFunctions.ClickByJE(cmdSystemDefault);
            }
        }

        private void clickSystemDefaultII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'System')]/parent::td/input[@name='StatisticMapping']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdSystemDefault = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.StatisticMappingSystemDefault = cmdSystemDefault.Selected;
            }
        }


        private void clickStatisticmappingMostRecentApprovedPlan()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[text()='Most Recent Approved Plan']/parent::td/input[@name='StatisticMapping']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdStatisticmappingMostRecentApprovedPlan = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.StatisticMappingMostRecentApprovedPlan = cmdStatisticmappingMostRecentApprovedPlan.Selected;    
                CommonFunctions.ClickByJE(cmdStatisticmappingMostRecentApprovedPlan);
            }
        }
        private void clickStatisticmappingMostRecentApprovedPlanII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[text()='Most Recent Approved Plan']/parent::td/input[@name='StatisticMapping']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdStatisticmappingMostRecentApprovedPlan = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.StatisticMappingMostRecentApprovedPlan = cmdStatisticmappingMostRecentApprovedPlan.Selected;
            }
        }

        private void clickStatisticmappingMostRecentApprovedAndReleasedPlan()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Released ')]/parent::td/input[@name='StatisticMapping']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdStatisticmappingMostRecentApprovedAndReleasedPlan = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.StatisticMappingMostRecentApprovedAndReleasedPlan = cmdStatisticmappingMostRecentApprovedAndReleasedPlan.Selected;
                CommonFunctions.ClickByJE(cmdStatisticmappingMostRecentApprovedAndReleasedPlan);
            }
        }
        private void clickStatisticmappingMostRecentApprovedAndReleasedPlanII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Released ')]/parent::td/input[@name='StatisticMapping']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdStatisticmappingMostRecentApprovedAndReleasedPlan = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.StatisticMappingMostRecentApprovedAndReleasedPlan = cmdStatisticmappingMostRecentApprovedAndReleasedPlan.Selected;
            }
        }

        private void setForCLPercentOrFixedFtesUse()
        {
            if (!string.IsNullOrEmpty(forCLPercentOrFixedFtesUse))
            {
                switch (forCLPercentOrFixedFtesUse)
                {
                    case "CL Percent":
                        clickCLPercent();
                        break;
                    case "Fixed FTEs":
                        clickFixedFtes();
                        break;
                }
            }
        }

        private void clickCLPercent()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Percent')]/parent::td/input[@name='LaborUsage']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdCLPercent = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.ClPercent = cmdCLPercent.Selected;
                CommonFunctions.ClickByJE(cmdCLPercent); 
            }
        }
        private void clickCLPercentII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Percent')]/parent::td/input[@name='LaborUsage']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdCLPercent = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.ClPercent = cmdCLPercent.Selected;
            }
        }

        private void clickFixedFtes()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Fixed')]/parent::td/input[@name='LaborUsage']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdFixedFtes = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.FixedFTEs = cmdFixedFtes.Selected;  
                CommonFunctions.ClickByJE(cmdFixedFtes);
            }
        }
        private void clickFixedFtesII()
        {
            string xpath = "//*/fieldset[not(@disabled)]//td/label[contains(text(),'Fixed')]/parent::td/input[@name='LaborUsage']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdFixedFtes = CommonFunctions.getElement(By.XPath(xpath));
                NewPlanElements.FixedFTEs = cmdFixedFtes.Selected;
            }
        }

        private void setApplyLatestQMIRSMonthRatetoAllMonths()
        { 
            IWebElement chkApplyLatestQMIRSMonthRatetoAllMonths = CommonFunctions.getElement(By.XPath("//*/ul[@class='freeze-options']//li/label[contains(text(),'Volume')]/parent::li/input"));
            CommonFunctions.SetCheckbox(chkApplyLatestQMIRSMonthRatetoAllMonths, applyLatestQMIRSMonthRatetoAllMonths);
           
        }

        private void setLoadProductivityTargets()
        {
            switch(loadProductivityTargets.ToUpper())
            {
                case "PLUS":
                    clickPLUS();
                    break;
                case "QMIRS":
                    clickQMIRS();
                    break;
            }
        }

        private void clickPLUS()
        {
            string xpath = "//*/td//input[@onclick='chkPlusvarstd()']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdPLUS = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.ClickByJE(cmdPLUS);
            }
        }

        private void clickQMIRS()
        {
            string xpath = "//*/td//input[@onclick='chkQmirsHrsclick()']";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bDisplayed)
            {
                IWebElement cmdQMIRS = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.ClickByJE(cmdQMIRS);
            }
        }

        private void setPLUSTargetMonth()
        {
            IWebElement mnuPLUSTargetMonth = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlPlusTargetMonth']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuPLUSTargetMonth, pLUSTargetMonth);
        }

        private void setSmoothRatios()
        {           
            switch (smoothRatios)
            {
                case "Current":
                    clickCurrent();
                    break;
                case "Historical":
                    clickHistorical();
                    break;
            }
        }

        private void clickCurrent()
        {
            IWebElement cmdCurrent = CommonFunctions.getElement(By.XPath("//*/td/label[contains(text(),'Current')]/parent::td/input[@name='SmoothRatios']"));
            CommonFunctions.ClickByJE(cmdCurrent);
        }

        private void clickHistorical()
        {
            IWebElement cmdHistorical = CommonFunctions.getElement(By.XPath("//*/td/label[contains(text(),'Historical')]/parent::td/input[@name='SmoothRatios']"));
            CommonFunctions.ClickByJE(cmdHistorical);
        }

        private void clickCreate()
        {
            IWebElement cmdCreate = CommonFunctions.getElement(By.XPath("//*/a[@id='createNewPlanBtn']"));
            CommonFunctions.ClickByJE(cmdCreate);
        }

        //get Latest QMIRS month and set it to the class property.
        private void getLatestQMIRSMonth()
        {
            IWebElement month = CommonFunctions.getElement(By.XPath("//*/div[@id='create-plan']//fieldset/legend[contains(text(),'Labor Rates')]/parent::fieldset//table/tbody//td/label[@class='bold']"));
            NewPlanLatestQMIRSMonth.LatestQMIRSMonth = month.Text.Trim();//get the first 3 letter of the month.
            NewPlanElements.LatestQMIRSMonth = month.Text.Trim();
            Console.WriteLine(NewPlanLatestQMIRSMonth.LatestQMIRSMonth);
        }

        private void UpdateForecast()
        {
            string OKXpath = "//*/div[@aria-labelledby='ui-dialog-title-host_volumes_diff']//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='OK']";
            bool isDisplayed = CommonFunctions.IsElementDisplayed(OKXpath, 10);
            if (isDisplayed)
            {
                switch(updateForecast)
                {
                    case true:
                        IWebElement cmdUpdate = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-host_volumes_diff']//input[@id='chkHostUpdate']"));
                        CommonFunctions.ClickByJE(cmdUpdate);
                        break;
                    case false:
                        IWebElement cmdNoUpdate = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-host_volumes_diff']//input[@id='chkNoHostUpdate']"));
                        CommonFunctions.ClickByJE(cmdNoUpdate);
                        break;
                }
                
                IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OKXpath));
                CommonFunctions.ClickByJE(cmdOK);
                CommonFunctions.IsElementDisplayed("//div[@id='facStatContent']//div[@id='monthly-header']", 30);
            }
        }

        public void Create()
        {
            FacilityStats.CancelUpdateCalc();
            setYear();
            setPlanDescription();
            setApprovers();
            setBudgetedvolumepercentage();
            setAllMonths();
            setFreezeFacilityRatiosAndVolumes();
            setFreezeCL();
            setFreezeNPRatiosAndVolumes();
            setFreezeOT();
            setForNonProductiveUse();            
            setStatisticMapping();           
            setForCLPercentOrFixedFtesUse();
            setApplyLatestQMIRSMonthRatetoAllMonths();
            getLatestQMIRSMonth();
            setLoadProductivityTargets();
            setPLUSTargetMonth();
            setSmoothRatios();
            Timer.Start();
            clickCreate();
            CommonFunctions.WaitUntilPageIsAcive();
            //UpdateForecast();
            //CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//*/input[@id='isFreezeFacRatio']", 40);
            Timer.Stop();
            string outputValue = $"{RunData.Facility}, {Timer.GetElapsedTime()}";
            CommonFunctions.WriteToFile(outputValue);
            CommonFunctions.AddTestStep("Verify creating a new plan", "A new plan was created.");
            RunData.PlanID = AdminPlanDetail.getPlanID();
        }

        public void CreateWithDefaultSettings()
        {
            setYear();
            setPlanDescription();            
            clickCreate();
            CommonFunctions.WaitUntilPageIsAcive();
            UpdateForecast();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//div[@id='facStatContent']//div[@id='monthly-header']", 40);
        }

        public void getNewPlanDefaultSetup()
        {
            getDefalutApprovers();
            getAllMonths();
            clickQMIRSAvgNPII();
            clickPLUSAvgNPII();
            clickMostRecentApprovedPlanII();
            clickMostRecentApprovedAndReleasedPlanII();
            clickSystemDefaultII();
            clickStatisticmappingMostRecentApprovedPlanII();
            clickStatisticmappingMostRecentApprovedAndReleasedPlanII();
            clickCLPercentII();
            clickFixedFtesII();
            getLatestQMIRSMonth();
        }
    }
    #endregion
}
