﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class WFTNewPlan
    {
        public class CNewPlan
        {
            public bool NonProductive_QMIRS { get; set; }
            public bool NonProductive_PLUS { get; set; }
            public bool NonProductive_Approved{ get; set; }
            public bool NonProductive_ApprovedAndReleased { get; set; }
            public bool StatisticMapping_SystemDefault { get; set; }
            public bool StatisticMapping_Approved { get; set; }
            public bool StatisticMapping_ApprovedAndReleased { get; set; }
            public bool Percent { get; set; }
            public bool Fixed { get; set; }

        }

        public static CNewPlan GetNewPlanSettings()
        {
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            CNewPlan cNewPlan = new CNewPlan();
            cNewPlan.NonProductive_QMIRS = (bool)js.ExecuteScript("return document.querySelector(\"input[value='2'][name='NonProductiveUse']\").checked");
            cNewPlan.NonProductive_PLUS = (bool)js.ExecuteScript("return document.querySelector(\"input[value='3'][name='NonProductiveUse']\").checked");
            cNewPlan.NonProductive_Approved = (bool)js.ExecuteScript("return document.querySelector(\"input[value='4'][name='NonProductiveUse']\").checked");
            cNewPlan.NonProductive_ApprovedAndReleased = (bool)js.ExecuteScript("return document.querySelector(\"input[value='5'][name='NonProductiveUse']\").checked");
            cNewPlan.StatisticMapping_SystemDefault = (bool)js.ExecuteScript("return document.querySelector(\"input[value='1'][name='StatisticMapping']\").checked");
            cNewPlan.StatisticMapping_Approved = (bool)js.ExecuteScript("return document.querySelector(\"input[value='3'][name='StatisticMapping']\").checked");
            cNewPlan.StatisticMapping_ApprovedAndReleased = (bool)js.ExecuteScript("return document.querySelector(\"input[value='4'][name='StatisticMapping']\").checked");
            cNewPlan.Percent = (bool)js.ExecuteScript("return document.querySelector(\"input[value='2'][name='LaborUsage']\").checked");
            cNewPlan.Fixed = (bool)js.ExecuteScript("return document.querySelector(\"input[value='3'][name='LaborUsage']\").checked");
            return cNewPlan;
        }
    }
}
