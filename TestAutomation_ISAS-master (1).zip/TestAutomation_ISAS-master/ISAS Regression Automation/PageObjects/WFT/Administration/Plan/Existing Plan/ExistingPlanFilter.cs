﻿using AdoTestCasePlugin.Dtos;
using AutomationCoreLite.Reporting;
using DocumentFormat.OpenXml.Bibliography;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class ExistingPlanFilter
    {
        public static void GoTo()
        {
            //Ensure that the filter is visible.
            bool bExist = CommonFunctions.IsElementDisplayed("//*/div[@id='choosePlanContainer']//h3[contains(@class,'ui-state-active')]", 2);
            if (!bExist)
            {
                IWebElement lnkChoosePlan = CommonFunctions.getElement(By.XPath("//*/div[@id='choosePlanContainer']//h3/a"));
                lnkChoosePlan.Click();
                IWebElement tbExistingPlan = CommonFunctions.getElement(By.XPath("//*/a[@id='selectExistingPlan']"));
                CommonFunctions.ClickByJE(tbExistingPlan);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Expand the existing filter", "Filter is expanded");
            }
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='existingPlanYearDropdown']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public static List<string> getExistingPlanCount(string Year, string Status)
        {
            List<string> lstPlans = new List<string>();
            By bySatus = By.XPath($"//*/select[@id='existingPlanDescriptionDropdown']/option[contains(text(),'(W)')]");

            ExistingPlanFilter.ExistingPlan()
                    .withYear(Year)
                    .withPlanStatus(Status)
                    .withPlan(string.Empty)
                    .Select();
            CommonFunctions.WaitUntilPageIsAcive();
            var lstExitingPlans =  CommonFunctions.getElements(bySatus);
            foreach(var plan in lstExitingPlans)
            {
                lstPlans.Add(plan.Text);
            }
            return lstPlans;
        }

        public static string getPlanStatus()
        {
            int index;
            IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            index = Convert.ToInt32(js.ExecuteScript("return document.querySelector('#existingPlanStatus').selectedIndex"));
           
            return getPlanStatus(index);
           // IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//*/select[@id='existingPlanStatus']"));
           // return(mnuPlanStatus.Text);
        }

        public static string getPlanStatus(int index)
        {
            string status;
            Dictionary<int, string> results = new Dictionary<int, string>
            {
                {0, "All" },
                {1, "Working" },
                {2, "Pending Approval" },
                {3, "Approved" },
                {4, "Working Rejected" },
                {5, "Approved Historical" },
                {6, "Approved & Released" }
            };
            results.TryGetValue(index, out status);
            return status;

        }

        public static AdministrationExistingPlanFilterCommand ExistingPlan()
        {
            return new AdministrationExistingPlanFilterCommand();
        }

        public static string getPlanName()
        {
            return(CommonFunctions.getElement(By.XPath("//*/select[@id='existingPlanDescriptionDropdown']")).Text);
            
        }

    }

    #region: AdministrationExistingPlanFilterCommand
    public class AdministrationExistingPlanFilterCommand
    {
        private string year;
        private string planStatus;
        private string plan;
        public AdministrationExistingPlanFilterCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public AdministrationExistingPlanFilterCommand withPlanStatus(string PlanStatus)
        {
            this.planStatus = PlanStatus;
            return this;
        }

        public AdministrationExistingPlanFilterCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }

        private void setYear()
        {
            if (!string.IsNullOrEmpty(year))
            {
                IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//*/select[@id='existingPlanYearDropdown']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
            }
        }

        private void setPlanStatus()
        {
            if (!string.IsNullOrEmpty(planStatus))
            {
                IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//*/select[@id='existingPlanStatus']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, planStatus);
            }
        }

        private void setPlan()
        {
            if (!string.IsNullOrEmpty(plan))
            {
                IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//*/select[@id='existingPlanDescriptionDropdown']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
            }
        }

        private void clickSelect()
        {
            IWebElement cmdSelect = CommonFunctions.getElement(By.XPath("//*/a[@id='selectExistingPlanBtn']"));
            CommonFunctions.ClickByJE(cmdSelect);
        }

        private void UpdateForecast()
        {
            string OKXpath = "//*/div[@aria-labelledby='ui-dialog-title-host_volumes_diff']//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='OK']";
            bool isDisplayed = CommonFunctions.IsElementDisplayed(OKXpath, 10);
            if (isDisplayed)
            {
                IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OKXpath));
                CommonFunctions.ClickByJE(cmdOK);
                CommonFunctions.WaitUntilPageIsAcive();
            }
        }

        public void Select()
        {
            setYear();
            setPlanStatus();
            setPlan();
            clickSelect();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//*/input[@id='isFreezeFacRatio']", 40);
            CommonFunctions.AddTestStep("Select an existing plan", "Plan is selected");
        }
    }
    #endregion
}
