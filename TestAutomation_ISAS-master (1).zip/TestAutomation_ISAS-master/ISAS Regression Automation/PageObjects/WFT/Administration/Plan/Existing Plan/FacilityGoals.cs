﻿using Microsoft.AspNetCore.Routing;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class BudgetGoals
    {
        public double EmployedProductiveFTEs { get; set; }
        public double ContractFTEs { get; set; }
        public double NonProdPercent { get; set; }
        public double OTPercent { get; set; }
        public double Admissions { get; set; }
        public double AdjAdmissions { get; set; }
        public double EEOB { get; set; }
        public double MHAA { get; set; }
        public double PatientDays { get; set; }
        public double ERVisits { get; set; }
        public double OutPatientVisits { get; set; }
        public double EmployedLaborRateExclCL { get; set; }
        public double ContractDollarPerHour { get; set; }
        public double OPFactor { get; set; }
        public double APD { get; set; }
        public double ALOS { get; set; }
        public double EmployedPaidFTEs { get; set; }
        public double TotalFTEsPaidAndContract { get; set; }
        public double AcutePatientDays { get; set; }
        public double AdjustedAcutePatientDays { get; set; }

    }

    public class FacilityGoals
    {
        public static void GoTo()
        {
            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement tbFacilityGoalsTab = CommonFunctions.getElement(By.XPath("//a[@id='facilityGoalsTabLink']"));
            CommonFunctions.ClickByJE(tbFacilityGoalsTab);
        }

        public static bool IsAt
        {
            get
            {
                CommonFunctions.WaitUntilPageIsAcive();
                string xpath = "//label[normalize-space()='Employed Productive FTEs']";
                return CommonFunctions.IsElementDisplayed(xpath, 90);
            }
        }

        public static BudgetGoals GetFacilityBudgetGoals()
        {
            BudgetGoals budgetGoals = new BudgetGoals();
            IWebElement employedProductiveFTEs = CommonFunctions.getElement(By.XPath("//input[@id='txtEmployedProdFtes']"));
            IWebElement contractFTEs = CommonFunctions.getElement(By.XPath("//input[@id='txtContractFtes']"));
            IWebElement nonProdPercent = CommonFunctions.getElement(By.XPath("//input[@id='txtNonProdPercent']"));
            IWebElement oTPercent = CommonFunctions.getElement(By.XPath("//input[@id='txtOtPercent']"));
            IWebElement admissions = CommonFunctions.getElement(By.XPath("//input[@id='txtAdmissions']"));
            IWebElement adjAdmissions = CommonFunctions.getElement(By.XPath("//input[@id='txtAdjAdmissions']"));
            IWebElement eEOB = CommonFunctions.getElement(By.XPath("//input[@id='txtEeob']"));
            IWebElement mHAA = CommonFunctions.getElement(By.XPath("//input[@id='txtMh']"));
            IWebElement patientDays = CommonFunctions.getElement(By.XPath("//input[@id='txtPatientDays']"));
            IWebElement eRVisits = CommonFunctions.getElement(By.XPath("//input[@id='txtTotalErVisits']"));
            IWebElement outPatientVisits = CommonFunctions.getElement(By.XPath("//input[@id='txtPatientVisits']"));
            IWebElement employedLaborRateExclCL = CommonFunctions.getElement(By.XPath("//input[@id='txtAverageHourlyRate']"));
            IWebElement contractDollarPerHour = CommonFunctions.getElement(By.XPath("//input[@id='txtContractDollarsPerHour']"));
            IWebElement oPFactor = CommonFunctions.getElement(By.XPath("//input[@id='txtOpFactor']"));
            IWebElement aPD = CommonFunctions.getElement(By.XPath("//input[@id='txtApd']"));
            IWebElement aLOS = CommonFunctions.getElement(By.XPath("//input[@id='txtAlos']"));
            IWebElement employedPaidFTEs = CommonFunctions.getElement(By.XPath("//input[@id='txtemppaidftes']"));
            IWebElement totalFTEsPaidAndContract = CommonFunctions.getElement(By.XPath("//input[@id='txtemptotalFtes']"));
            IWebElement acutePatientDays = CommonFunctions.getElement(By.XPath("//input[@id='txtAcutePatientdays']"));
            IWebElement adjustedAcutePatientDays = CommonFunctions.getElement(By.XPath("//input[@id='txtAdjustedAcutePatientdays']"));

            budgetGoals.EmployedProductiveFTEs = CommonFunctions.ToDouble(employedProductiveFTEs.GetAttribute("value"));
            budgetGoals.ContractFTEs = CommonFunctions.ToDouble(contractFTEs.GetAttribute("value"));
            budgetGoals.NonProdPercent = CommonFunctions.ToDouble(nonProdPercent.GetAttribute("value"));
            budgetGoals.OTPercent = CommonFunctions.ToDouble(oTPercent.GetAttribute("value"));
            budgetGoals.Admissions = CommonFunctions.ToDouble(admissions.GetAttribute("value"));
            budgetGoals.AdjAdmissions = CommonFunctions.ToDouble(adjAdmissions.GetAttribute("value"));
            budgetGoals.EEOB = CommonFunctions.ToDouble(eEOB.GetAttribute("value"));
            budgetGoals.MHAA = CommonFunctions.ToDouble(mHAA.GetAttribute("value"));
            budgetGoals.PatientDays = CommonFunctions.ToDouble(patientDays.GetAttribute("value"));
            budgetGoals.ERVisits = CommonFunctions.ToDouble(eRVisits.GetAttribute("value"));
            budgetGoals.OutPatientVisits = CommonFunctions.ToDouble(outPatientVisits.GetAttribute("value"));
            budgetGoals.EmployedLaborRateExclCL = CommonFunctions.ToDouble(employedLaborRateExclCL.GetAttribute("value"));
            budgetGoals.ContractDollarPerHour = CommonFunctions.ToDouble(contractDollarPerHour.GetAttribute("value"));
            budgetGoals.OPFactor = CommonFunctions.ToDouble(oPFactor.GetAttribute("value"));
            budgetGoals.APD = CommonFunctions.ToDouble(aPD.GetAttribute("value"));
            budgetGoals.ALOS = CommonFunctions.ToDouble(aLOS.GetAttribute("value"));
            budgetGoals.EmployedPaidFTEs = CommonFunctions.ToDouble(employedPaidFTEs.GetAttribute("value"));
            budgetGoals.TotalFTEsPaidAndContract = CommonFunctions.ToDouble(totalFTEsPaidAndContract.GetAttribute("value"));
            budgetGoals.AcutePatientDays = CommonFunctions.ToDouble(acutePatientDays.GetAttribute("value"));
            budgetGoals.AdjustedAcutePatientDays = CommonFunctions.ToDouble(adjustedAcutePatientDays.GetAttribute("value"));
            return budgetGoals;
        }

    }
}
