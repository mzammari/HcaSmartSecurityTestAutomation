﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.ForecastView_Volume;
using System.Threading;
using AutomationCoreLite.Reporting;

namespace ISAS_Regression_Automation
{

    public class FreezeSVStepSel
    {
        public bool FreezeSVStep { get; set; }
        public string DeptName { get; set; }
    }


    public class FacilityStatsMappingObject
    {
        public string DeptID { get; set; }
        public string DeptNum { get; set; }
        public string DeptName { get; set; }       
        public string WFTDeptType { get; set; }
        public bool IgnoredInPlus { get; set; }
        public bool IgnoredInWFT { get; set; }
        public string PLUSDeptType { get; set; }
        public string DepartmentStat { get; set; }
        public string FacilityStat { get; set; }
        public string CLPercentOrFTE { get; set; }
        public string NPPercent { get; set; }
        public string NPPercentColor { get; set; }
        public bool FreezeRatioVol { get; set; }
        public bool FreezeMinHours { get; set; }
        public bool FreezeStdTgt { get; set; }
        public bool FreezeSVStepSel { get; set; }
        public bool FreezeCLPercent { get; set; }
        public bool FreezeNPPercent { get; set; }
        public bool FreezeOTPercent { get; set; }
    }

    public class FacilityStatsMappingElements
    {
        public IWebElement DeptID { get; set; }
        public IWebElement DeptNum { get; set; }
        public IWebElement DeptName { get; set; }
        public IWebElement WFTDeptType { get; set; }
        public IWebElement IgnoredInPlus { get; set; }
        public IWebElement IgnoredInWFT { get; set; }
        public IWebElement PLUSDeptType { get; set; }
        public IWebElement DepartmentStat { get; set; }
        public IWebElement FacilityStat { get; set; }
        public IWebElement CLPercentOrFTE { get; set; }
        public IWebElement NPPercent { get; set; }
        public IWebElement NPPercentColor { get; set; }
        public IWebElement FreezeRatioVol { get; set; }
        public IWebElement FreezeMinHours { get; set; }
        public IWebElement FreezeStdTgt { get; set; }
        public IWebElement FreezeSVStepSel { get; set; }
        public IWebElement FreezeCLPercent { get; set; }
        public IWebElement FreezeNPPercent { get; set; }
        public IWebElement FreezeOTPercent { get; set; }
    }

    public class FacilityStatsMapping
    {
        public static void GoTo()
        {
           // CommonFunctions.WaitUntilPageIsAcive();
            IWebElement tbFacilityStatMapping = CommonFunctions.getElement(By.XPath("//*/a[@id='facilityStatMappingTabLnk']"));
            CommonFunctions.ClickByJE(tbFacilityStatMapping);
            //CommonFunctions.WaitUntilPageIsAcive();

            string OKXpath = "//*/div[@aria-labelledby='ui-dialog-title-host_volumes_diff']//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='OK']";
            bool isDisplayed = CommonFunctions.IsElementDisplayed(OKXpath, 2);
            if (isDisplayed)
            {
                IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OKXpath));
                CommonFunctions.ClickByJE(cmdOK);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Navigate to Facility Stats Mapping", "Facility Stats Mapping page is displayed");
            } 
        }

        public static bool IsAt
        {
            get
            {   
                CommonFunctions.WaitUntilPageIsAcive();
                string xpath = "//*/label[@class='facstat-map-lbl' and text()='Department Stat']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static string getFirstDeptNum()
        {
            IList<IWebElement> lstFacStatsRows = CommonFunctions.getElements(By.XPath("//*/input[@id='txt']/ancestor::div[contains(@class,'changed')]"));
            return (lstFacStatsRows[1].GetAttribute("deptnum"));
        }

        public static bool IsNpPercentDropdownDisabled(string dept)
        {
            bool bEnabled;
            string nPPercentXpath = $"//*/div[contains(@deptnum,'{dept}')]//select[contains(@id,'facDeptNPfcast') and @disabled]";
            return CommonFunctions.IsElementDisplayed(nPPercentXpath, 5);
        }

        public static string getDeptNumBasedonDeptName(string DeptName)
        {
            IWebElement DeptRow = CommonFunctions.getElement(By.XPath($"//*/input[@id='txt' and contains(@value,'{DeptName}')]/ancestor::div[contains(@class,'changed')]"));
            return (DeptRow.GetAttribute("deptnum"));
        }

        public static List<FacilityStatsMappingObject> GetFacilityStatsMappingVisibleRowsForWorkingPlans()
        {
            List<FacilityStatsMappingObject> lstFacStatsmapping = new List<FacilityStatsMappingObject>();
            By byVisibleRows = By.XPath("//*/div[@class='VerticalScrollStyle']//div[@class='changed-facstat-mapping clear']//tbody//tr[contains(@class,'facilitymapping') and not(@style=\"display: none;\")]//tbody//tr");

            IList<IWebElement> lstRows = CommonFunctions.getElements(byVisibleRows);
            foreach (var row in lstRows)
            {
                lstFacStatsmapping.Add(new FacilityStatsMappingObject()
                {
                    DeptName = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    IgnoredInWFT = row.FindElement(By.XPath("td[3]/input")).Selected,
                    PLUSDeptType = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    WFTDeptType = row.FindElement(By.XPath("td[5]/select")).Text,
                    DepartmentStat = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                    FacilityStat = row.FindElement(By.XPath("td[7]/select")).Text,
                    CLPercentOrFTE = row.FindElement(By.XPath("td[8]/select")).Text,
                    NPPercent = row.FindElement(By.XPath("td[9]/select")).Text,
                    FreezeRatioVol = row.FindElement(By.XPath("td[10]/input")).Selected,
                    FreezeMinHours = row.FindElement(By.XPath("td[11]/input")).Selected,
                    FreezeStdTgt = row.FindElement(By.XPath("td[12]/input")).Selected,
                    FreezeSVStepSel = row.FindElement(By.XPath("td[13]/input")).Selected,
                    FreezeCLPercent = row.FindElement(By.XPath("td[14]/input")).Selected,
                    FreezeNPPercent = row.FindElement(By.XPath("td[15]/input")).Selected,
                    FreezeOTPercent = row.FindElement(By.XPath("td[16]/input")).Selected,
                });
            }
            return lstFacStatsmapping;
        }

        public static List<FacilityStatsMappingElements> GetFacilityStatsMappingVisibleRowsElementsForWorkingPlans()
        {
            List<FacilityStatsMappingElements> lstFacStatsmapping = new List<FacilityStatsMappingElements>();
            By byVisibleRows = By.XPath("//*/div[@class='VerticalScrollStyle']//div[@class='changed-facstat-mapping clear']//tbody//tr[contains(@class,'facilitymapping') and not(@style=\"display: none;\")]//tbody//tr");

            IList<IWebElement> lstRows = CommonFunctions.getElements(byVisibleRows);
            foreach (var row in lstRows)
            {
                lstFacStatsmapping.Add(new FacilityStatsMappingElements()
                {
                    DeptName = row.FindElement(By.XPath("td[1]/input")),
                    IgnoredInWFT = row.FindElement(By.XPath("td[3]/input")),
                    PLUSDeptType = row.FindElement(By.XPath("td[4]/input")),
                    WFTDeptType = row.FindElement(By.XPath("td[5]/select")),
                    DepartmentStat = row.FindElement(By.XPath("td[6]/input")),
                    FacilityStat = row.FindElement(By.XPath("td[7]/select")),
                    CLPercentOrFTE = row.FindElement(By.XPath("td[8]/select")),
                    NPPercent = row.FindElement(By.XPath("td[9]/select")),
                    FreezeRatioVol = row.FindElement(By.XPath("td[10]/input")),
                    FreezeMinHours = row.FindElement(By.XPath("td[11]/input")),
                    FreezeStdTgt = row.FindElement(By.XPath("td[12]/input")),
                    FreezeSVStepSel = row.FindElement(By.XPath("td[13]/input")),
                    FreezeCLPercent = row.FindElement(By.XPath("td[14]/input")),
                    FreezeNPPercent = row.FindElement(By.XPath("td[15]/input")),
                    FreezeOTPercent = row.FindElement(By.XPath("td[16]/input"))
                });
            }
            return lstFacStatsmapping;
        }

        public static List<FacilityStatsMappingObject> GetFacilityStatsMappingData()
        {
            bool isCheckedWFTDeptType, isMismatchedWFTDeptType;
            string xpath, CheckedWFT_DeptTypeXpath, mismatchedWFTDeptTypeXpath;
            List<FacilityStatsMappingObject> lstFacStatsmapping = new List<FacilityStatsMappingObject>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/table[@class='tblFacStat']//tr//td"));

            #region: foreach part
            foreach (IWebElement row in lstRows)
            {
               
                try
                {
                    // if the WFT Dept type is checked, skip it
                    IWebElement CheckedWFT_DeptType = row.FindElement(By.XPath("input[contains(@id,'isInactiveWft') and @checked]"));

                }
                catch
                {
                    try
                    {
                        // If there is a mismatched between PLUS and WFT, skip it
                        IWebElement mismatchedWFTDeptType = row.FindElement(By.XPath("select[contains(@id,'facStatDeptType') and contains(@class,'validation-errors')]"));

                    }
                    catch
                    {
                        IWebElement Dept = row.FindElement(By.XPath("ancestor::div[@deptid]"));
                        IWebElement deptName = row.FindElement(By.XPath("input[@id='txt']"));
                        IWebElement WFT_DeptType = row.FindElement(By.XPath("select[contains(@id,'facStatDeptType')]"));                       
                        IWebElement WFT_DepartmentStat = row.FindElement(By.XPath("input[contains(@id,'txt3')]"));
                        IWebElement WFT_FacilityStat = row.FindElement(By.XPath("select[contains(@class,'facstat-map-val-dd')]/option[@selected]"));
                        IWebElement WFT_CLPercentOrFTE = row.FindElement(By.XPath("select[contains(@id,'facDeptClfcast')]"));
                        IWebElement WFT_NPPercent = row.FindElement(By.XPath("select[contains(@id,'facDeptNPfcast')]/option[@selected]"));



                        lstFacStatsmapping.Add(new FacilityStatsMappingObject()
                        {
                            DeptID = Dept.GetAttribute("deptid"),
                            DeptNum = Dept.GetAttribute("deptnum"),
                            DeptName = deptName.GetAttribute("value"),
                            WFTDeptType = WFT_DeptType.GetAttribute("title"),
                            DepartmentStat = WFT_DepartmentStat.GetAttribute("value"),
                            FacilityStat = WFT_FacilityStat.GetAttribute("value"),
                            CLPercentOrFTE = WFT_CLPercentOrFTE.GetAttribute("title"),
                            NPPercent = WFT_NPPercent.GetAttribute("value")
                        });
                        continue;
                    }
                }

                    
               
            }
            #endregion

            #region: for loop
            //for (int i = 1; i <= lstRows.Count; i++)
            //{
            //    CheckedWFT_DeptTypeXpath = $"//*/table[@class='tblFacStat']//tr[{i}]//td//input[contains(@id,'isInactiveWft') and @checked]";
            //    mismatchedWFTDeptTypeXpath = $"//*/table[@class='tblFacStat']//tr[{i}]//td//select[contains(@id,'facStatDeptType') and contains(@class,'validation-errors')]";
            //    isCheckedWFTDeptType = CommonFunctions.IsElementDisplayed(CheckedWFT_DeptTypeXpath, 1);
            //    isMismatchedWFTDeptType = CommonFunctions.IsElementDisplayed(mismatchedWFTDeptTypeXpath, 1);

            //    //IWebElement row = CommonFunctions.getElement(By.XPath($"//*/table[@class='tblFacStat']//tr[{i}]//td"));
            //    try
            //    {
            //        //// if the WFT Dept type is checked, skip it
            //        //IWebElement CheckedWFT_DeptType = row.FindElement(By.XPath("input[contains(@id,'isInactiveWft') and @checked]"));
            //        //isCheckedWFTDeptType = CheckedWFT_DeptType.Displayed;
            //        //// If there is a mismatched between PLUS and WFT, skip it
            //        //IWebElement mismatchedWFTDeptType = row.FindElement(By.XPath("select[contains(@id,'facStatDeptType') and contains(@class,'validation-errors')]"));
            //        //isMismatchedWFTDeptType = mismatchedWFTDeptType.Displayed;

            //        if (isCheckedWFTDeptType || isMismatchedWFTDeptType)
            //        {
            //            // skip the row. 
            //        }
            //        else
            //        {
            //            IWebElement Dept = CommonFunctions.getElement(By.XPath($"//*/table[@class='tblFacStat']//tr[{i}]//td/ancestor::div[@deptid]"));
            //            IWebElement deptName = CommonFunctions.getElement(By.XPath($"//*/table[@class='tblFacStat']//tr[{i}]//td//input[@id='txt']"));
            //            IWebElement WFT_DeptType = CommonFunctions.getElement(By.XPath($"//*/table[@class='tblFacStat']//tr[{i}]//td//select[contains(@id,'facStatDeptType')]"));

            //            lstFacStatsmapping.Add(new FacilityStatsMappingObject()
            //            {
            //                DeptID = Dept.GetAttribute("deptid"),
            //                DeptNum = Dept.GetAttribute("deptnum"),
            //                DeptName = deptName.GetAttribute("value"),
            //                WFTDeptType = WFT_DeptType.GetAttribute("title")
            //            });
            //        }
            //    }
            //    catch
            //    {
            //        //i++;
            //        continue;
            //    }
            //}
            #endregion





            return lstFacStatsmapping;
        }

        public static List<FacilityStatsMappingObject> GetFacilityStatsMappingForReleasedAndAppprovedPlanData()
        {
            bool isCheckedWFTDeptType, isMismatchedWFTDeptType;
            string xpath, CheckedWFT_DeptTypeXpath, mismatchedWFTDeptTypeXpath;
            List<FacilityStatsMappingObject> lstFacStatsmapping = new List<FacilityStatsMappingObject>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/table[@class='tblFacStat']//tr//td"));           
            foreach (IWebElement row in lstRows)
            {
                try
                {
                    // if the WFT Dept type is checked, skip it
                    IWebElement CheckedWFT_DeptType = row.FindElement(By.XPath("input[contains(@id,'isInactiveWft') and @checked]"));

                }
                catch
                {
                    try
                    {
                        // If there is a mismatched between PLUS and WFT, skip it
                        IWebElement mismatchedWFTDeptType = row.FindElement(By.XPath("select[contains(@id,'facStatDeptType') and contains(@class,'validation-errors')]"));

                    }
                    catch
                    {
                        IWebElement Dept = row.FindElement(By.XPath("ancestor::div[@deptid]"));
                        IWebElement deptName = row.FindElement(By.XPath("input[@id='txt']"));
                        IWebElement WFT_DeptType = row.FindElement(By.XPath("input[contains(@id,'facStatDeptType')]"));
                        IWebElement WFT_DepartmentStat = row.FindElement(By.XPath("input[contains(@id,'txt3')]"));
                        IWebElement WFT_FacilityStat = row.FindElement(By.XPath("input[contains(@class,'facstat-map-val-dd')]"));
                        IWebElement WFT_CLPercentOrFTE = row.FindElement(By.XPath("input[contains(@id,'facDeptclfcast')]"));
                        IWebElement WFT_NPPercent = row.FindElement(By.XPath("input[contains(@id,'facDeptnpfcast')]"));



                        lstFacStatsmapping.Add(new FacilityStatsMappingObject()
                        {
                            DeptID = Dept.GetAttribute("deptid"),
                            DeptNum = Dept.GetAttribute("deptnum"),
                            DeptName = deptName.GetAttribute("value"),
                            WFTDeptType = WFT_DeptType.GetAttribute("title"),
                            DepartmentStat = WFT_DepartmentStat.GetAttribute("value"),
                            FacilityStat = WFT_FacilityStat.GetAttribute("value"),
                            CLPercentOrFTE = WFT_CLPercentOrFTE.GetAttribute("title"),
                            NPPercent = WFT_NPPercent.GetAttribute("value")
                        }); 
                        continue;
                    }
                }
            }
            return lstFacStatsmapping;
        }

        public static FacilityStatsMappingObject GetFacilityStatsMappingData(string DeptName)
        {
            Console.WriteLine($"Dept name: {DeptName}");
            //CommonFunctions.BrowserRefresh();
            CommonFunctions.WaitUntilPageIsAcive();
            //verify you landed on FacilityStatsMapping tab.
            bool bDisplayed = IsAt;
            IWebElement Dept = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[@id='txt']/ancestor::div[@deptid]"));
            CommonFunctions.Focus(Dept);
            IWebElement deptName = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[@id='txt']"));
            IWebElement WFT_DeptType = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//select[contains(@id,'facStatDeptType')]"));
            IWebElement WFT_DepartmentStat = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'txt3')]"));
            IWebElement WFT_FacilityStat = CommonFunctions.getElement(By.XPath($"(//*/div[contains(@deptnum,'{DeptName}')]//select[contains(@class, 'facstat-map-val-change')])[2]/option[@selected]"));
            IWebElement WFT_CLPercentOrFTE = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//select[contains(@id,'facDeptClfcast')]"));
            IWebElement WFT_NPPercent = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//select[contains(@id,'facDeptNPfcast')]/option[@selected]"));
            IWebElement chkIgnoredInWFT = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isInactiveWft')]"));
            IWebElement mnuFreezeRatioVol = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeFacRatio')]"));
            IWebElement mnuFreezeStdTgt = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeTarget')]"));
            IWebElement mnuFreezeSVStepSel = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeSv')]"));
            IWebElement chkFreezeCLPercent = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeCL')]"));
            IWebElement mnuFreezeNPPercent = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeNP')]"));
            IWebElement mnuFreezeOTPercent = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeOt')]"));


            FacilityStatsMappingObject DeptFacStatsmapping = new FacilityStatsMappingObject()
            {
                DeptID = Dept.GetAttribute("deptid"),
                DeptNum = Dept.GetAttribute("deptnum"),
                DeptName = deptName.GetAttribute("value"),
                WFTDeptType = WFT_DeptType.GetAttribute("title"),
                DepartmentStat = WFT_DepartmentStat.GetAttribute("value"),
                FacilityStat = WFT_FacilityStat.Text.ToString(),
                CLPercentOrFTE = WFT_CLPercentOrFTE.GetAttribute("title"),
                NPPercent = WFT_NPPercent.Text.ToString(),
                IgnoredInWFT = chkIgnoredInWFT.Selected,
                FreezeRatioVol = mnuFreezeRatioVol.Selected,
                FreezeStdTgt = mnuFreezeStdTgt.Selected,
                FreezeSVStepSel = mnuFreezeSVStepSel.Selected,
                FreezeCLPercent = chkFreezeCLPercent.Selected,
                FreezeNPPercent = mnuFreezeNPPercent.Selected,
                FreezeOTPercent = mnuFreezeOTPercent.Selected,
                NPPercentColor = WFT_NPPercent.GetCssValue("background-color")
            };
            return DeptFacStatsmapping;
        }

        public static FacilityStatsMappingObject GetFacilityStatsMappingDataForNonWorkingPlan(string DeptName)
        {
            //CommonFunctions.BrowserRefresh();
            Thread.Sleep(5000);
            CommonFunctions.WaitUntilPageIsAcive();
            //Go to Facility Stats Mapping tab
            GoTo();
            //verify you landed on FacilityStatsMapping tab.
            bool bDisplayed = IsAt;
            IWebElement Dept = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[@id='txt']/ancestor::div[@deptid]"));
            CommonFunctions.Focus(Dept);
            IWebElement deptName = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[@id='txt']"));
            IWebElement WFT_DeptType = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'facStatDeptType')]"));
            IWebElement WFT_DepartmentStat = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'txt3')]"));
            IWebElement WFT_FacilityStat = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@class,'facstat-map-val-dd-readonly facstat-map-readonly')]"));
            IWebElement WFT_CLPercentOrFTE = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'facDeptclfcast')]"));
            IWebElement WFT_NPPercent = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'facDeptnpfcast')]"));
            IWebElement chkIgnoredInWFT = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isInactiveWft')]"));
            IWebElement mnuFreezeRatioVol = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeFacRatio')]"));
            IWebElement mnuFreezeStdTgt = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeTarget')]"));
            IWebElement mnuFreezeSVStepSel = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeSv')]"));
            IWebElement chkFreezeCLPercent = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeCL')]"));
            IWebElement mnuFreezeNPPercent = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeNP')]"));
            IWebElement mnuFreezeOTPercent = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{DeptName}')]//input[contains(@id,'isFreezeOt')]"));


            FacilityStatsMappingObject DeptFacStatsmapping = new FacilityStatsMappingObject()
            {
                DeptID = Dept.GetAttribute("deptid"),
                DeptNum = Dept.GetAttribute("deptnum"),
                DeptName = deptName.GetAttribute("value"),
                WFTDeptType = WFT_DeptType.GetAttribute("title"),
                DepartmentStat = WFT_DepartmentStat.GetAttribute("value"),
                FacilityStat = WFT_FacilityStat.GetAttribute("value"),
                CLPercentOrFTE = WFT_CLPercentOrFTE.GetAttribute("title"),
                NPPercent = WFT_NPPercent.GetAttribute("value"),
                IgnoredInWFT = chkIgnoredInWFT.Selected,
                FreezeRatioVol = mnuFreezeRatioVol.Selected,
                FreezeStdTgt = mnuFreezeStdTgt.Selected,
                FreezeSVStepSel = mnuFreezeSVStepSel.Selected,
                FreezeCLPercent = chkFreezeCLPercent.Selected,
                FreezeNPPercent = mnuFreezeNPPercent.Selected,
                FreezeOTPercent = mnuFreezeOTPercent.Selected
            };
            return DeptFacStatsmapping;
        }

        public static ExistingFacilityStatsCommand ModifyFacilityStatsMapping(string DeptNum)
        {
            return new ExistingFacilityStatsCommand(DeptNum);
        }

        public static List<FreezeSVStepSel> getDeptNameWithFreezeSVStepSel()
        {
            string xpath = "//*/table[@class='tblFacStat']//select[@title='SemiVariable']/preceding-sibling::input[contains(@id,'isInactiveWft') and not(@checked)]/following-sibling::input[contains(@id,'isFreezeSv')]";
            List<FreezeSVStepSel> lstFreezeSVStepSels = new List<FreezeSVStepSel>();
            IList<IWebElement> FreezeSVStep = CommonFunctions.getElements(By.XPath(xpath));
            foreach (var ele in FreezeSVStep)
            {
                lstFreezeSVStepSels.Add(new FreezeSVStepSel()
                {
                    DeptName = ele.FindElement(By.XPath("preceding-sibling::input[@id='txt']")).GetAttribute("value"),
                    FreezeSVStep = ele.Selected
                });
            }
            return lstFreezeSVStepSels;
        }

        public static void SetFreezeSVStepSel(string DeptName, bool Toggle)
        {
            bool bDisplayed;
            string YesXpath = "//*/div[@aria-labelledby='ui-dialog-title-save-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string xpath = $"//*/table[@class='tblFacStat']//select[@title='SemiVariable']/preceding-sibling::input[contains(@id,'isInactiveWft') and not(@checked)]/preceding-sibling::input[@id='txt' and contains(@value,'{DeptName}')]/following-sibling::input[contains(@id,'isFreezeSv')]";
            IWebElement chkFreezeSV = CommonFunctions.getElement(By.XPath(xpath));
            switch (Toggle)
            {
                case true:
                    if(!chkFreezeSV.Selected)
                        chkFreezeSV.Click();
                    break;
                case false:
                    if (chkFreezeSV.Selected)
                        chkFreezeSV.Click();
                    break;
            }
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//button[@id='saveFacilityStatsBtn']"));
            CommonFunctions.ClickByJE(cmdSave);
            bDisplayed = CommonFunctions.IsElementDisplayed(YesXpath, 10);
            if(bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(YesXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }
            
        }

        public static FacilityStatMappingFiltersCommands Filters()
        {
            return new FacilityStatMappingFiltersCommands();
        }
    }

    #region: ExistingFacilityStatsCommand
    public class ExistingFacilityStatsCommand
    {
        private string dept;
        private bool ignoredInWFT;
        //private string pLUSDeptType;
        private string facilityStat;
        private string cLPercentOrFTE;
        private string nPPercent;
        private bool freezeRatioVol;
        private bool freezeStdTgt;
        private bool freezeSVStepSel;
        private bool freezeCLPercent;
        private bool freezeNPPercent;
        private bool freezeOTPercent;

        public ExistingFacilityStatsCommand(string DeptNum)
        {
            this.dept = DeptNum;
        }

        public ExistingFacilityStatsCommand withIgnoredInWFT(bool IgnoredInWFT)
        {
            this.ignoredInWFT = IgnoredInWFT;
            return this;
        }

        //public ExistingFacilityStatsCommand withPLUSDeptType(string PLUSDeptType)
        //{
        //    this.pLUSDeptType = PLUSDeptType;
        //    return this;
        //}

        public ExistingFacilityStatsCommand withFacilityStat(string FacilityStat)
        {
            this.facilityStat = FacilityStat;
            return this;
        }

        public ExistingFacilityStatsCommand withCLPercentOrFTE(string CLPercentOrFTE)
        {
            this.cLPercentOrFTE = CLPercentOrFTE;
            return this;
        }

        public ExistingFacilityStatsCommand withNPPercent(string NPPercent)
        {
            this.nPPercent = NPPercent;
            return this;
        }

        public ExistingFacilityStatsCommand withFreezeRatioVol(bool FreezeRatioVol)
        {
            this.freezeRatioVol = FreezeRatioVol;
            return this;
        }

        public ExistingFacilityStatsCommand withFreezeStdTgt(bool FreezeStdTgt)
        {
            this.freezeStdTgt = FreezeStdTgt;
            return this;
        }

        public ExistingFacilityStatsCommand withFreezeSVStepSel(bool FreezeSVStepSel)
        {
            this.freezeSVStepSel = FreezeSVStepSel;
            return this;
        }

        public ExistingFacilityStatsCommand withFreezeCLPercent(bool FreezeCLPercent)
        {
            this.freezeCLPercent = FreezeCLPercent;
            return this;
        }

        public ExistingFacilityStatsCommand withFreezeNPPercent(bool FreezeNPPercent)
        {
            this.freezeNPPercent = FreezeNPPercent;
            return this;
        }

        public ExistingFacilityStatsCommand withFreezeOTPercent(bool FreezeOTPercent)
        {
            this.freezeOTPercent = FreezeOTPercent;
            return this;
        }

        private void clickDept()
        {
            IWebElement cmdDept = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlYears']"));
            CommonFunctions.ClickByJE(cmdDept);
        }

        private void Focus()
        {
            IWebElement chkIgnoredInWFT = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isInactiveWft')]"));
            CommonFunctions.Focus(chkIgnoredInWFT);
        }
        private void setIgnoredInWFT()
        {
            
            IWebElement chkIgnoredInWFT = CommonFunctions.getElement(By.XPath($"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isInactiveWft')]"));
            CommonFunctions.Focus(chkIgnoredInWFT);
            //Already checked -- true
            string xpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isInactiveWft') and @checked]";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
            switch (ignoredInWFT)
            {                
                case true:
                    if (!bDisplayed)
                    {
                        CommonFunctions.AddTestStep($"Set ignore WFT option to {ignoredInWFT}", "checkbox is set");
                        CommonFunctions.ClickByJE(chkIgnoredInWFT);
                    }
                    break;
                case false:
                    if (bDisplayed)
                    {
                        CommonFunctions.AddTestStep($"Set ignore WFT option to {ignoredInWFT}", "checkbox is set");
                        CommonFunctions.ClickByJE(chkIgnoredInWFT);
                    }
                    break;
            }            
        }

        //private void setPLUSDeptType()
        //{
        //    IWebElement mnuPLUSDeptType = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlPlans']"));
        //    CommonFunctions.SelectItemFromDropdownMenu(mnuPLUSDeptType, pLUSDeptType);
        //}

        //private void clickWFTDeptType()
        //{            
        //    IWebElement cmdWFTDeptType = CommonFunctions.getElement(By.XPath("//*/a[@id='btnView']"));
        //    CommonFunctions.ClickByJE(cmdWFTDeptType);
        //}

        //private void clickDepartmentStat()
        //{
        //    IWebElement cmdDepartmentStat = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlYears']"));
        //    CommonFunctions.ClickByJE(cmdDepartmentStat);
        //}

        private void setFacilityStat()
        {
            
            if (!string.IsNullOrEmpty(facilityStat))
            {
                string facilityStatpath = $"//*/div[contains(@deptnum,'{dept}')]//select[contains(@id,'facStat')]";
                IWebElement mnuFacilityStat = CommonFunctions.getElement(By.XPath(facilityStatpath));
                CommonFunctions.Focus(mnuFacilityStat);
                CommonFunctions.SelectItemFromDropdownMenu(mnuFacilityStat, facilityStat);
            }
        }

        private void setCLPercentOrFTE()
        {            
            if (!string.IsNullOrEmpty(cLPercentOrFTE))
            {
                string cLPercentOrFTEXpath = $"//*/div[contains(@deptnum,'{dept}')]//select[contains(@id,'facDeptClfcast')]";
                IWebElement mnuCLPercentOrFTE = CommonFunctions.getElement(By.XPath(cLPercentOrFTEXpath));               
                CommonFunctions.SelectItemFromDropdownMenu(mnuCLPercentOrFTE, cLPercentOrFTE);
                CommonFunctions.AddTestStep($"Select CLPercentOrFTE to {cLPercentOrFTE} ", $"{cLPercentOrFTE} was set correctly");
            }
        }

        private void setNPPercent()
        {            
            bool bDiaplayed;
            Thread.Sleep(2000);
            if (!string.IsNullOrEmpty(nPPercent))
            {
                string nPPercentXpath = $"//*/div[contains(@deptnum,'{dept}')]//select[contains(@id,'facDeptNPfcast') and not(@disabled)]";
                bDiaplayed = CommonFunctions.IsElementDisplayed(nPPercentXpath, 2);
                if (bDiaplayed)
                {
                    IWebElement mnuNPPercent = CommonFunctions.getElement(By.XPath(nPPercentXpath));
                    CommonFunctions.Focus(mnuNPPercent);
                    CommonFunctions.SelectItemFromDropdownMenu(mnuNPPercent, nPPercent);
                    CommonFunctions.AddTestStep($"Select NP % to {nPPercent} ", $"{nPPercent} was set correctly");
                    // CommonFunctions.SelectElementByValue(mnuNPPercent, nPPercent);
                }
            }
        }

        private void setFreezeRatioVol()
        {            
            bool bDisplayed;
            string FreezeRatioVolXpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeFacRatio') and not(@disabled)]";
            bDisplayed = CommonFunctions.IsElementDisplayed(FreezeRatioVolXpath, 1);
            if (bDisplayed)
            {
                IWebElement mnuFreezeRatioVol = CommonFunctions.getElement(By.XPath(FreezeRatioVolXpath));
                CommonFunctions.Focus(mnuFreezeRatioVol);
                //Already checked -- true
                string xpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeFacRatio') and @checked]";
                bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
                switch (freezeRatioVol)
                {
                    case true:
                        if (!bDisplayed)
                        {
                            CommonFunctions.AddTestStep($"Set Freeze Ratio Vol option to {freezeRatioVol}", "checkbox is set");
                            mnuFreezeRatioVol.Click();
                        }
                        break;
                    case false:
                        if (bDisplayed)
                        {
                            CommonFunctions.AddTestStep($"Set Freeze Ratio Vol option to {freezeRatioVol}", "checkbox is set");
                            mnuFreezeRatioVol.Click();
                        }
                        break;
                }
            }
        }

        private void setFreezeStdTgt()
        {
            string FreezeStdTgtXpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeTarget') and not(@disabled)]";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(FreezeStdTgtXpath, 1);
            if (bDisplayed)
            {
                IWebElement mnuFreezeStdTgt = CommonFunctions.getElement(By.XPath(FreezeStdTgtXpath));
                CommonFunctions.Focus(mnuFreezeStdTgt);
                //Already checked -- true
                string xpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeTarget') and @checked]";
                bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
                switch (freezeStdTgt)
                {
                    case true:
                        if (!bDisplayed)
                        {
                            CommonFunctions.AddTestStep($"Set Freeze Std Tgt option to {freezeStdTgt}", "checkbox is set");
                            mnuFreezeStdTgt.Click();
                        }
                        break;
                    case false:
                        if (bDisplayed)
                        {
                            CommonFunctions.AddTestStep($"Set Freeze Std Tgt option to {freezeStdTgt}", "checkbox is set");
                            mnuFreezeStdTgt.Click();
                        }
                        break;
                }
            }
        }

        private void setFreezeSVStepSel()
        {            
            string FreezeSVStepSelXpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeSv') and not(@disabled)]";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(FreezeSVStepSelXpath, 1);
            if (bDisplayed)
            {
                IWebElement mnuFreezeSVStepSel = CommonFunctions.getElement(By.XPath(FreezeSVStepSelXpath));
                CommonFunctions.Focus(mnuFreezeSVStepSel);
                //Already checked -- true
                string xpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeSv') and @checked]";
                bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
                CommonFunctions.AddTestStep($"Set Freeze SV Step Sel option to {freezeSVStepSel}", "checkbox is set");
                switch (freezeSVStepSel)
                {
                    case true:
                        if (!bDisplayed)
                        {

                            CommonFunctions.ClickByJE(mnuFreezeSVStepSel);
                        }
                        break;
                    case false:
                        if (bDisplayed)
                        {
                            CommonFunctions.ClickByJE(mnuFreezeSVStepSel);
                        }
                        break;
                }
            }
            
        }

        private void setFreezeCLPercent()
        {
            string FreezeCLPercentXpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeCL') and not(@disabled)]";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(FreezeCLPercentXpath, 1);
            if (bDisplayed)
            {
                IWebElement chkFreezeCLPercent = CommonFunctions.getElement(By.XPath(FreezeCLPercentXpath));
                CommonFunctions.Focus(chkFreezeCLPercent);
                //Already checked -- true
                string xpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeCL') and @checked]";
                bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
                CommonFunctions.AddTestStep($"Set Freeze CL Percent option to {freezeCLPercent}", "checkbox is set");
                switch (freezeCLPercent)
                {
                    case true:
                        if (!bDisplayed)
                        {
                            CommonFunctions.ClickByJE(chkFreezeCLPercent);
                        }
                        break;
                    case false:
                        if (bDisplayed)
                        {
                            CommonFunctions.ClickByJE(chkFreezeCLPercent);
                        }
                        break;
                }
            }
        }

        private void setFreezeNPPercent()
        {
            string FreezeNPPercentXpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeNP') and not(@disabled)]";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(FreezeNPPercentXpath, 1);
            if (bDisplayed)
            {
                IWebElement mnuFreezeNPPercent = CommonFunctions.getElement(By.XPath(FreezeNPPercentXpath));
                CommonFunctions.Focus(mnuFreezeNPPercent); 
                //Already checked -- true
                string xpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeNP') and @checked]";
                bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
                CommonFunctions.AddTestStep($"Set Freeze NP Percent option to {freezeNPPercent}", "checkbox is set");
                switch (freezeNPPercent)
                {
                    case true:
                        if (!bDisplayed)
                        {
                            CommonFunctions.ClickByJE(mnuFreezeNPPercent);
                        }
                        break;
                    case false:
                        if (bDisplayed)
                        {
                            CommonFunctions.ClickByJE(mnuFreezeNPPercent);
                        }
                        break;
                }
            }
        }

        private void setFreezeOTPercent()
        {
            string FreezeOTPercentXpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeOt') and not(@disabled)]";
            bool bDisplayed = CommonFunctions.IsElementDisplayed(FreezeOTPercentXpath, 1);
            if (bDisplayed)
            {
                IWebElement mnuFreezeOTPercent = CommonFunctions.getElement(By.XPath(FreezeOTPercentXpath));
                CommonFunctions.Focus(mnuFreezeOTPercent);
                //Already checked -- true
                string xpath = $"//*/div[contains(@deptnum,'{dept}')]//input[contains(@id,'isFreezeOt') and @checked]";
                bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 1);
                CommonFunctions.AddTestStep($"Set Freeze OT% option to {freezeOTPercent}", "checkbox is set");
                switch (freezeOTPercent)
                {
                    case true:
                        if (!bDisplayed)
                        {
                            CommonFunctions.ClickByJE(mnuFreezeOTPercent);
                        }
                        break;
                    case false:
                        if (bDisplayed)
                        {
                            CommonFunctions.ClickByJE(mnuFreezeOTPercent);
                        }
                        break;
                }
            }
        }        

        public void Save()
        {
            //clickDept();
            setIgnoredInWFT();
            //setPLUSDeptType();
            //clickWFTDeptType();
            //clickDepartmentStat();
            setFacilityStat();
            setCLPercentOrFTE();
            setFreezeNPPercent();//Set freeze Np first before you select from the menu.
            setNPPercent();
            setFreezeRatioVol();
            setFreezeStdTgt();
            setFreezeSVStepSel();
            setFreezeCLPercent();            
            setFreezeOTPercent();
            AdminMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep($"Set {dept} with differnt options", "Different selections were selected");
        }
    }
    #endregion


    #region: FacilityStatMappingFiltersCommands
    public class FacilityStatMappingFiltersCommands
    {
        private string dept;
        private string ignoredInPlus;
        private string ignoredInWFT;
        private string pLUSDeptType;
        private string wFTDeptType;
        private string departmentStat;
        private string facilityStat;
        private string cLPercentOrFTE;
        private string nPPercent;
        private string freezeVolumes;
        private string freezeMinHours;
        private string freezeStdTgt;
        private string freezeSVStepSel;
        private string freezeCLPercent;
        private string freezeNPPercent;
        private string freezeOTPercent;

        public FacilityStatMappingFiltersCommands withDept(string Dept)
        {
            this.dept = Dept;
            return this;
        }

        public FacilityStatMappingFiltersCommands withIgnoredInPlus(string IgnoredInPlus)
        {
            this.ignoredInPlus = IgnoredInPlus;
            return this;
        }

        public FacilityStatMappingFiltersCommands withIgnoredInWFT(string IgnoredInWFT)
        {
            this.ignoredInWFT = IgnoredInWFT;
            return this;
        }

        public FacilityStatMappingFiltersCommands withPLUSDeptType(string PLUSDeptType)
        {
            this.pLUSDeptType = PLUSDeptType;
            return this;
        }

        public FacilityStatMappingFiltersCommands withWFTDeptType(string WFTDeptType)
        {
            this.wFTDeptType = WFTDeptType;
            return this;
        }

        public FacilityStatMappingFiltersCommands withDepartmentStat(string DepartmentStat)
        {
            this.departmentStat = DepartmentStat;
            return this;
        }

        public FacilityStatMappingFiltersCommands withFacilityStat(string FacilityStat)
        {
            this.facilityStat = FacilityStat;
            return this;
        }

        public FacilityStatMappingFiltersCommands withCLPercentOrFTE(string CLPercentOrFTE)
        {
            this.cLPercentOrFTE = CLPercentOrFTE;
            return this;
        }

        public FacilityStatMappingFiltersCommands withNPPercent(string NPPercent)
        {
            this.nPPercent = NPPercent;
            return this;
        }

        public FacilityStatMappingFiltersCommands withFreezeVolumes(string FreezeVolumes)
        {
            this.freezeVolumes = FreezeVolumes;
            return this;
        }

        public FacilityStatMappingFiltersCommands withFreezeMinHours(string FreezeMinHours)
        {
            this.freezeMinHours = FreezeMinHours;
            return this;
        }

        public FacilityStatMappingFiltersCommands withFreezeStdTgt(string FreezeStdTgt)
        {
            this.freezeStdTgt = FreezeStdTgt;
            return this;
        }

        public FacilityStatMappingFiltersCommands withFreezeSVStepSel(string FreezeSVStepSel)
        {
            this.freezeSVStepSel = FreezeSVStepSel;
            return this;
        }

        public FacilityStatMappingFiltersCommands withFreezeCLPercent(string FreezeCLPercent)
        {
            this.freezeCLPercent = FreezeCLPercent;
            return this;
        }

        public FacilityStatMappingFiltersCommands withFreezeNPPercent(string FreezeNPPercent)
        {
            this.freezeNPPercent = FreezeNPPercent;
            return this;
        }

        public FacilityStatMappingFiltersCommands withFreezeOTPercent(string FreezeOTPercent)
        {
            this.freezeOTPercent = FreezeOTPercent;
            return this;
        }

        private void setDept()
        {
            By byDept = By.XPath("//select[@id='facStatDeptType']");
            IWebElement mnuDept = CommonFunctions.getElement(byDept);
            CommonFunctions.SelectItemFromDropdownMenu(mnuDept, dept);
            CommonFunctions.AddTestStep($"Verify a user can select {dept} from Dept dropdown", $"The {dept} is selected correctly");
        }

        private void setIgnoredInPlus()
        {
            By byIgnoredInPlus = By.XPath("//select[@id='facDeptActiveInPlus']");
            IWebElement mnuIgnoredInPlus = CommonFunctions.getElement(byIgnoredInPlus);
            CommonFunctions.SelectItemFromDropdownMenu(mnuIgnoredInPlus, ignoredInPlus);
            CommonFunctions.AddTestStep($"Verify a user can select {ignoredInPlus} from Ignored In Plus dropdown", $"The {ignoredInPlus} is selected correctly");
        }

        private void setIgnoredInWFT()
        {
            By byIgnoredInWFT = By.XPath("//select[@id='facDeptActiveInWFT']");
            IWebElement mnuIgnoredInWFT = CommonFunctions.getElement(byIgnoredInWFT);
            CommonFunctions.SelectItemFromDropdownMenu(mnuIgnoredInWFT, ignoredInWFT);
            CommonFunctions.AddTestStep($"Verify a user can select {ignoredInWFT} from Ignored In WFT dropdown", $"The {ignoredInWFT} is selected correctly");
        }

        private void setPLUSDeptType()
        {
            By byPLUSDeptType = By.XPath("//select[@id='plusDeptTypeFilter']");
            IWebElement mnuPLUSDeptType = CommonFunctions.getElement(byPLUSDeptType);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPLUSDeptType, pLUSDeptType);
            CommonFunctions.AddTestStep($"Verify a user can select {pLUSDeptType} from PLUS Dept Type dropdown", $"The {pLUSDeptType} is selected correctly");
        }

        private void setWFTDeptType()
        {
            By byWFTDeptType = By.XPath("//select[@id='wftDeptTypeFilter']");
            IWebElement mnuWFTDeptType = CommonFunctions.getElement(byWFTDeptType);
            CommonFunctions.SelectItemFromDropdownMenu(mnuWFTDeptType, wFTDeptType);
            CommonFunctions.AddTestStep($"Verify a user can select {wFTDeptType} from WFT Dept Type dropdown", $"The {wFTDeptType} is selected correctly");
        }

        private void setDepartmentStat()
        {
            By byDepartmentStat = By.XPath("//select[@id='facStat-header-dept']");
            IWebElement mnuDepartmentStat = CommonFunctions.getElement(byDepartmentStat);
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartmentStat, departmentStat);
            CommonFunctions.AddTestStep($"Verify a user can select {departmentStat} from Department Stat dropdown", $"The {departmentStat} is selected correctly");
        }

        private void setFacilityStat()
        {
            By byFacilityStat = By.XPath("//select[@id='facStat-header-fac']");
            IWebElement mnuFacilityStat = CommonFunctions.getElement(byFacilityStat);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFacilityStat, facilityStat);
            CommonFunctions.AddTestStep($"Verify a user can select {facilityStat} from Facility Stat dropdown", $"The {facilityStat} is selected correctly");
        }

        private void setCLPercentOrFTE()
        {
            By byCLPercentOrFTE = By.XPath("//select[@id='ClPercentFteFilter']");
            IWebElement mnuCLPercentOrFTE = CommonFunctions.getElement(byCLPercentOrFTE);
            CommonFunctions.SelectItemFromDropdownMenu(mnuCLPercentOrFTE, cLPercentOrFTE);
            CommonFunctions.AddTestStep($"Verify a user can select {cLPercentOrFTE} from CL Percent or FTE dropdown", $"The {cLPercentOrFTE} is selected correctly");
        }

        private void setNPPercent()
        {
            By byNPPercent = By.XPath("//select[@id='NpPercentFilter']");
            IWebElement mnuNPPercent = CommonFunctions.getElement(byNPPercent);
            CommonFunctions.SelectItemFromDropdownMenu(mnuNPPercent, nPPercent);
            CommonFunctions.AddTestStep($"Verify a user can select {nPPercent} from NP Percent dropdown", $"The {nPPercent} is selected correctly");
        }

        private void setFreezeVolumes()
        {
            By byFreezeVolumes = By.XPath("//select[@id='FreezeVolumeFilter']");
            IWebElement mnuFreezeVolumes = CommonFunctions.getElement(byFreezeVolumes);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFreezeVolumes, freezeVolumes);
            CommonFunctions.AddTestStep($"Verify a user can select {freezeVolumes} from Freeze Volumes dropdown", $"The {freezeVolumes} is selected correctly");
        }

        private void setFreezeMinHours()
        {
            By byFreezeMinHours = By.XPath("//select[@id='FreezeMinHrsFilter']");
            IWebElement mnuFreezeMinHours = CommonFunctions.getElement(byFreezeMinHours);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFreezeMinHours, freezeMinHours);
            CommonFunctions.AddTestStep($"Verify a user can select {freezeMinHours} from Freeze Min Hours dropdown", $"The {freezeMinHours} is selected correctly");
        }

        private void setFreezeStdTgt()
        {
            By byFreezeStdTgt = By.XPath("//select[@id='FreezeStdTgtFilter']");
            IWebElement mnuFreezeStdTgt = CommonFunctions.getElement(byFreezeStdTgt);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFreezeStdTgt, freezeStdTgt);
            CommonFunctions.AddTestStep($"Verify a user can select {freezeStdTgt} from Freeze Std Tgt dropdown", $"The {freezeStdTgt} is selected correctly");
        }

        private void setFreezeSVStepSel()
        {
            By byFreezeSVStepSel = By.XPath("//select[@id='FreezeSVStepSelFilter']");
            IWebElement mnuFreezeSVStepSel = CommonFunctions.getElement(byFreezeSVStepSel);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFreezeSVStepSel, freezeSVStepSel);
            CommonFunctions.AddTestStep($"Verify a user can select {freezeSVStepSel} from Freeze SV Step Sel dropdown", $"The {freezeSVStepSel} is selected correctly");
        }

        private void setFreezeCLPercent()
        {
            By byFreezeCLPercent = By.XPath("//select[@id='FreezeClPctFilter']");
            IWebElement mnuFreezeCLPercent = CommonFunctions.getElement(byFreezeCLPercent);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFreezeCLPercent, freezeCLPercent);
            CommonFunctions.AddTestStep($"Verify a user can select {freezeCLPercent} from Freeze CL Percent dropdown", $"The {freezeCLPercent} is selected correctly");
        }

        private void setFreezeNPPercent()
        {
            By byFreezeNPPercent = By.XPath("//select[@id='FreezeNPPCtFilter']");
            IWebElement mnuFreezeNPPercent = CommonFunctions.getElement(byFreezeNPPercent);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFreezeNPPercent, freezeNPPercent);
            CommonFunctions.AddTestStep($"Verify a user can select {freezeNPPercent} from Freeze NP Percent dropdown", $"The {freezeNPPercent} is selected correctly");
        }

        private void setFreezeOTPercent()
        {
            By byFreezeOTPercent = By.XPath("//select[@id='FreezeOtPCTFilter']");
            IWebElement mnuFreezeOTPercent = CommonFunctions.getElement(byFreezeOTPercent);
            CommonFunctions.SelectItemFromDropdownMenu(mnuFreezeOTPercent, freezeOTPercent);
            CommonFunctions.AddTestStep($"Verify a user can select {freezeOTPercent} from Freeze OT Percent dropdown", $"The {freezeOTPercent} is selected correctly");
        }

        public void Set()
        {
            setDept();
            setIgnoredInPlus();
            setIgnoredInWFT();
            setPLUSDeptType();
            setWFTDeptType();
            setDepartmentStat();
            setFacilityStat();
            setCLPercentOrFTE();
            setNPPercent();
            setFreezeVolumes();
            setFreezeMinHours();
            setFreezeStdTgt();
            setFreezeSVStepSel();
            setFreezeCLPercent();
            setFreezeNPPercent();
            setFreezeOTPercent();
        }
    }
    #endregion
}

