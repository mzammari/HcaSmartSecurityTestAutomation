﻿using AutomationCoreLite.Reporting;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class AdminPlanDetail
    {
        public class AdminPlanDetailData
        {
            public string PlanID { get; set; }
            public string PlanYear { get; set; }
            public string Status { get; set; }
            public string Description { get; set; }
            public string Created { get; set; }
            public string LastModified { get; set; }
            public string PLUSLastUpdatedOn { get; set; }
            public string QMIRSLatestMonth { get; set; }
            public string HostBudgetLastUpdatedOn { get; set; }
        }

        public static AdminPlanDetailData getAdminPlanDetailData()
        {
            CommonFunctions.AddTestStep("Get Admin Plan Detail Data", "Admin Plan Detail Data");

            By byPlanID = By.XPath("//input[@id='selectedPlanId']");
            By byPlanYear = By.XPath("//select[@id='ddlSelectPlanYear']");
            By byStatus = By.XPath("//input[@id='selectedPlanStatus']");
            By byDescription = By.XPath("//input[@id='selectedPlanDescription']");
            By byCreated = By.XPath("//input[@id='selectedPlanCreatedByOn']");
            By byLastModified = By.XPath("//input[@id='selectedPlanUpdatedByOn']");
            By byPLUSLastUpdatedOn = By.XPath("//input[@id='lblSelectedPlanPlusLastUpdtedOn']");
            By byQMIRSLatestMonth = By.XPath("//input[@id='lblSelectedPlanQMIRSLastUpdtedOn']");
            By byHostBudgetLastUpdatedOn = By.XPath("//input[@id='lblSelectedPlanHostLastUpdtedOn']");

            return new AdminPlanDetailData()
            {
                PlanID = CommonFunctions.getElement(byPlanID).Text,
                //PlanYear = CommonFunctions.getElement(byPlanYear).Text,
                //Status = CommonFunctions.getElement(byStatus).Text,
                //Description = CommonFunctions.getElement(byDescription).Text,
                //Created = CommonFunctions.getElement(byCreated).Text,
                //LastModified = CommonFunctions.getElement(byLastModified).Text,
                //PLUSLastUpdatedOn = CommonFunctions.getElement(byPLUSLastUpdatedOn).Text,
                //QMIRSLatestMonth = CommonFunctions.getElement(byQMIRSLatestMonth).Text,
                //HostBudgetLastUpdatedOn = CommonFunctions.getElement(byHostBudgetLastUpdatedOn).Text
            };
        }

        public static string getPlanID()
        {
            string planID;
            string url = Driver.Instance.Url;
            var arr = url.Split('/');
            planID = arr.Last();
            return planID;
        }
    }

     
}
