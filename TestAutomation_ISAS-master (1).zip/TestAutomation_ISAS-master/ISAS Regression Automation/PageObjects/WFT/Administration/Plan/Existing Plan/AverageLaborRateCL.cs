﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Threading;

namespace ISAS_Regression_Automation
{
    public class AverageLaborRateCL
    {
        public static void GoTo()
        {
            IWebElement tbAverageLaborRateCL = CommonFunctions.getElement(By.XPath("//a[@id='contractLaborRateLnk']"));
            CommonFunctions.ClickByJE(tbAverageLaborRateCL);
            CommonFunctions.WaitUntilPageIsAcive();
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//input[@id='qmirsRateTotalCl']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public class QMIRSContractRate
        {
            public static MonthlyForcastView getQMIRSContractRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateCl-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateTotalCl']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

            public static double getLatestQMIRSMonthValue(string latestMonth)
            {
                var dicQMRIS = new Dictionary<string, double>();
                var QMIRSMonthlyValues = getQMIRSContractRateData();
                dicQMRIS.Add("Jan", QMIRSMonthlyValues.Jan);
                dicQMRIS.Add("Feb", QMIRSMonthlyValues.Feb);
                dicQMRIS.Add("Mar", QMIRSMonthlyValues.Mar);
                dicQMRIS.Add("Apr", QMIRSMonthlyValues.Apr);
                dicQMRIS.Add("May", QMIRSMonthlyValues.May);
                dicQMRIS.Add("Jun", QMIRSMonthlyValues.Jun);
                dicQMRIS.Add("Jul", QMIRSMonthlyValues.Jul);
                dicQMRIS.Add("Aug", QMIRSMonthlyValues.Aug);
                dicQMRIS.Add("Sep", QMIRSMonthlyValues.Sep);
                dicQMRIS.Add("Oct", QMIRSMonthlyValues.Oct);
                dicQMRIS.Add("Nov", QMIRSMonthlyValues.Nov);
                dicQMRIS.Add("Dec", QMIRSMonthlyValues.Dec);
                dicQMRIS.Add("Total", QMIRSMonthlyValues.Total);
                return(dicQMRIS.GetValueOrDefault(latestMonth.Trim()));
            }

        }

        public class PercentIncreaseDecreaseQMIRS_CLRate
        {
            public static MonthlyForcastView getPercentIncreaseDecreaseQMIRS_CLRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseCl-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseTotalCl']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class PercentIncreaseDecreaseContractRate
        {
            public static MonthlyForcastView getPercentIncreaseDecreaseContractRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastContractLabrRate-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeTotalOnForecastContractLabrRate']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class ContractRate
        {
            public static void ClickFill()
            {
                string FillXpath = "//*/a[@id='contractRateFillBtn']";
                IWebElement cmdFill = CommonFunctions.getElement(By.XPath(FillXpath));
                CommonFunctions.ClickByJE(cmdFill);
            }

            public static MonthlyForcastView getContractRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRateTotal']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

            public static void SetContractRateData(string value)
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='contractRate-1']"));
                CommonFunctions.ReplaceAndSetText(Jan, value);                
                ClickFill();
                Thread.Sleep(1000);
                CommonFunctions.WaitUntilPageIsAcive();
            }

        }

        public class LastSavedbaseContractLaborRate
        {
            public static MonthlyForcastView getLastSavedbaseContractLaborRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRate-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='baseContractLaborRateTotal']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class ContractLaborNetPercentIncreaseDecreaseOnLastSaved
        {
            public static MonthlyForcastView getContractLaborNetPercentIncreaseDecreaseOnLastSavedData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChange-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divNetPrecentChangeforContractLaborRate']/input[@id='netPercentageChangeTotal']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class CL
        {
            public static MonthlyForcastView getCLData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='contractLaborDollarsTotal']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        
    }
}
