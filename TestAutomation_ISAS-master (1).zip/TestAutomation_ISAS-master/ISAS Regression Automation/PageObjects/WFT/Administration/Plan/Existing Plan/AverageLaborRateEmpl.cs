﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.ForecastView_ContractPercent;

namespace ISAS_Regression_Automation
{
    public class AverageLaborRateEmpl
    {
        public static void GoTo()
        {
            By tbAverageLaborRateEmpl = By.XPath("//a[@id='employeeLaborRateLnk']");            
            CommonFunctions.ClickByJE(CommonFunctions.getElement(tbAverageLaborRateEmpl));
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Go to Average Labor Rate Empl", "Average Labor Rate Empl page is displayed");
        }

        public static void DoubleClickMarch(string xpath)
        {
            By ByValue = By.XPath(xpath);
            CommonFunctions.DoubleClickMonth(ByValue);
            AdminMenu.Save();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/input[@id='qmirsRateTotal']";
                return CommonFunctions.IsElementDisplayed(xpath, 90);
            }
        }

        public class QMIRSEmplLbrRate
        {
            public static void ClickLatest()
            {
                string LatestXpath = "//*/a[@id='applyLatestEmplRateBtn']";
                bool isExist = CommonFunctions.IsElementDisplayed(LatestXpath, 2);
                if (isExist)
                {
                    IWebElement cmdLatest = CommonFunctions.getElement(By.XPath(LatestXpath));
                    CommonFunctions.ClickByJE(cmdLatest);
                    CommonFunctions.AddTestStep("Click the latest button", "The latest button is enabled");
                }
            }

            public static void ClickReset()
            {
                string ResetXpath = "//*/a[@id='applyLatestEmplRateBtn']";
                bool isExist = CommonFunctions.IsElementDisplayed(ResetXpath, 2);
                if (isExist)
                {
                    IWebElement cmdReset = CommonFunctions.getElement(By.XPath(ResetXpath));
                    CommonFunctions.ClickByJE(cmdReset);
                    CommonFunctions.AddTestStep("Click the reset button", "The reset button is enabled");
                }
            }

            public static void DoubleClickMonth()
            {
                DoubleClickMarch("//*/input[@id='qmirsRate-3']");
                CommonFunctions.AddTestStep("Double-click the Mar cell", "The Mar cell is enabled.");
            }           

            public static MonthlyForcastView getQMIRSEmplLbrRateData()
            {
                CommonFunctions.AddTestStep("Get QMIRS Empl Lbr Rate Data", "QMIRS Empl Lbr Rate Data");
                var data = new MonthlyForcastView()
                {                    
                    Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-1']")).GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-2']")).GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-3']")).GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-4']")).GetAttribute("value")),
                    May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-5']")).GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-6']")).GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-7']")).GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-8']")).GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-9']")).GetAttribute("value")), 
                    Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-10']")).GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-11']")).GetAttribute("value")), 
                    Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRate-12']")).GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='qmirsRateTotal']")).GetAttribute("value"))
                };
                return data;
            }
        }

        public class PercentIncreaseDecreaseQMIRSEmplLbrRate
        {
            public static void ClickFill()
            {
                string FillXpath = "//*/fieldset[@class='employee-labor-rate-fieldset']//a[@id='percentIncreaseFillBtn']";
                IWebElement cmdFill = CommonFunctions.getElement(By.XPath(FillXpath));
                CommonFunctions.ClickByJE(cmdFill);
            }

            public static MonthlyForcastView getPercentIncreaseDecreaseQMIRSEmplLbrRateData()
            {
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-1']")).GetAttribute("value")), 2),
                    Feb = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-2']")).GetAttribute("value")), 2),
                    Mar = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-3']")).GetAttribute("value")), 2),
                    Apr = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-4']")).GetAttribute("value")), 2),
                    May = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-5']")).GetAttribute("value")), 2),
                    Jun = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-6']")).GetAttribute("value")), 2),
                    Jul = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-7']")).GetAttribute("value")), 2),
                    Aug = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-8']")).GetAttribute("value")), 2),
                    Sep = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-9']")).GetAttribute("value")), 2),
                    Oct = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-10']")).GetAttribute("value")), 2),
                    Nov = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-11']")).GetAttribute("value")), 2),
                    Dec = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncrease-12']")).GetAttribute("value")), 2),
                    Total = Math.Round(CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("//*/input[@id='percentIncreaseTotal']")).GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class PercentIncreaseDecreaseEmplLabrRate
        {
            public static void ClickFill()
            {
                string FillXpath = "//*/div[@id='divPercentChangeOnForecastEmplLabrRate']//a[@id='perecentageChangeFillOnForecastLabrRate']";
                IWebElement cmdFill = CommonFunctions.getElement(By.XPath(FillXpath));
                CommonFunctions.ClickByJE(cmdFill);
            }

            public static MonthlyForcastView getPercentIncreaseDecreaseEmplLabrRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeOnForecastEmplLabrRate-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='percetageChangeTotalOnForecastEmplLabrRate']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(CommonFunctions.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(CommonFunctions.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(CommonFunctions.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(CommonFunctions.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(CommonFunctions.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(CommonFunctions.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(CommonFunctions.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(CommonFunctions.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(CommonFunctions.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(CommonFunctions.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(CommonFunctions.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(CommonFunctions.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(CommonFunctions.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class EmployedLaborRate
        {
            public static void ClickFill()
            {
                string FillXpath = "//*/a[@id='employedLaborRateFillBtn']";
                IWebElement cmdFill = CommonFunctions.getElement(By.XPath(FillXpath));
                CommonFunctions.ClickByJE(cmdFill);
            }

            public static void ClickQMIRS()
            {
                string QMIRSXpath = "//a[@id='qmirsValueFillBtn']";
                IWebElement cmdQ = CommonFunctions.getElement(By.XPath(QMIRSXpath));
                CommonFunctions.ClickByJE(cmdQ);
            }

            public static MonthlyForcastView getEmployedLaborRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRateTotal']"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

            public static void SetEmployedLaborRateData(string value)
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='employedLaborRate-1']"));
                CommonFunctions.ReplaceAndSetText(Jan, value);
                ClickFill();
                Thread.Sleep(1000);
                CommonFunctions.WaitUntilPageIsAcive();
            }

        }

        public class LastSavedEmployedLaborRate
        {
            public static void DoubleClickMonth()
            {
                DoubleClickMarch("//*/input[@id='baseEmployeeLaborRate-3']");
            }

            public static MonthlyForcastView getLastSavedEmployedLaborRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRate-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='baseEmployeeLaborRateTotal']"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")), 
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")), 
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")), 
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")), 
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")), 
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")), 
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")), 
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")), 
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")), 
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")), 
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

        }

        public class NetPercentIncreaseDecreaseOnLastSaved
        {
            public static MonthlyForcastView getNetPercentIncreaseDecreaseOnLastSavedData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChange-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='netPercentageChangeTotal']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(CommonFunctions.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(CommonFunctions.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(CommonFunctions.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(CommonFunctions.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(CommonFunctions.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(CommonFunctions.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(CommonFunctions.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(CommonFunctions.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(CommonFunctions.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(CommonFunctions.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(CommonFunctions.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(CommonFunctions.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(CommonFunctions.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class EmployeeSalaries
        {
            public static MonthlyForcastView getEmployeeSalariesData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalariesTotal']"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(CommonFunctions.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(CommonFunctions.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(CommonFunctions.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(CommonFunctions.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(CommonFunctions.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(CommonFunctions.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(CommonFunctions.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(CommonFunctions.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(CommonFunctions.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(CommonFunctions.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(CommonFunctions.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(CommonFunctions.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(CommonFunctions.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }
        }

        public static void ApplyHistoricalOrLatestQMIRStoAllDepts(string option)
        {
            switch(option)
            {
                case "Latest QMIRS Month":
                    IWebElement rdLatestQMIRSMonth = CommonFunctions.getElement(By.XPath("//div[@id='divPercentOptions']/input[@value='latest']"));
                    CommonFunctions.ClickByJE(rdLatestQMIRSMonth);
                    break;
                case "% (+/-) on QMIRS Lbr Rate":
                    IWebElement rdQMIRSLbrRate = CommonFunctions.getElement(By.XPath("//div[@id='divPercentOptions']/input[@value='qmirs']"));
                    CommonFunctions.ClickByJE(rdQMIRSLbrRate);
                    break;
                case "% (+/-) on Empl Lbr Rate":
                    IWebElement rdEmplLbrRate = CommonFunctions.getElement(By.XPath("//div[@id='divPercentOptions']/input[@value='forecast']"));
                    CommonFunctions.ClickByJE(rdEmplLbrRate);
                    break;
            }
            IWebElement cmdApplyToAllDept = CommonFunctions.getElement(By.XPath("//input[@id='chkApplyToAllDept']"));
            CommonFunctions.ClickByJE(cmdApplyToAllDept);
            IWebElement cmdYes = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby=\"applyall-qmirs-total\"]//div[@class='ui-dialog-buttonset']//button[text()='Yes']"));
            CommonFunctions.ClickByJE(cmdYes);
            CommonFunctions.WaitUntilPageIsAcive();
            AdminMenu.Save();
            Thread.Sleep(5000);
            CommonFunctions.WaitUntilPageIsAcive();

        }
    }

}
