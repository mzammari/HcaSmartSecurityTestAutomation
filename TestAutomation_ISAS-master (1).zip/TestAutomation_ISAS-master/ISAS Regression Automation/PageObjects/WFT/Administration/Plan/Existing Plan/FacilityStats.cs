﻿using NUnit.Framework;
using System.Threading;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.WFTMainMenu.WFTReports;
using AventStack.ExtentReports;
using static ISAS_Regression_Automation.FacilityVolumeSummary;

namespace ISAS_Regression_Automation
{
    public class FacilityStats
    {
        public static void GoTo()
        {

            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement tbFacilityStatsTab = CommonFunctions.getElement(By.XPath("//a[@id='facilityStatsTabLnk']"));
            CommonFunctions.ClickByJE(tbFacilityStatsTab);
            CommonFunctions.AddTestStep("Go to Facility Stats ", "Facility Stats tab is selected");
            CancelUpdatePlan();
        }

        public static void CancelUpdatePlan()
        {
            bool bExist;
            By OKXpath = By.XPath("//*/div[@aria-describedby=\"host_volumes_diff\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='OK']");
            bExist = CommonFunctions.IsElementDisplayed(OKXpath, 10);
            if (bExist)
            {
                IWebElement cmdOK = CommonFunctions.getElement(OKXpath);
                CommonFunctions.Focus(cmdOK);
                CommonFunctions.ClickByJE(cmdOK);
                CommonFunctions.AddTestStep("Click cancel update plan", "Update is canceled.");
            }
        }
        private static void ClickAway()
        {
            By byPlanID = By.XPath("//input[@id='selectedPlanUpdatedByOn']");
            CommonFunctions.getElement(byPlanID).Click();
            Thread.Sleep(1000);
        }

        public static Dictionary<string, string> getAllStatIdAndCodes()
        {
            var dict = new Dictionary<string, string>();
            By bylstCode = By.XPath("(//*/div[@class='corp-fac-stat' and @statid])[1]//input[contains(@class, 'stat-code')]");
            var lstCode = CommonFunctions.getElements(bylstCode);
            for (int i = 1; i < lstCode.Count; i++)
            {
                IWebElement StatID = CommonFunctions.getElement(By.XPath($"(//*/div[@class='corp-fac-stat' and @statid])[{i}]"));
                IWebElement Code = CommonFunctions.getElement(By.XPath($"(//*/div[@class='corp-fac-stat' and @statid])[{i}]//input[contains(@class, 'stat-code')]"));
                dict.Add(StatID.GetAttribute("statid"), Code.GetAttribute("value"));
            }
            CommonFunctions.AddTestStep("Get all stat ID and Codes in the facility stats page", "All stat ID and Codes are retrieved.");
            return dict;
        }


        public static bool IsAt
        {
            get
            {
                string xpath = "(//*/div//input[@title='BIRTHS']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[1]";
                return CommonFunctions.IsElementDisplayed(xpath, 15);
            }
        }

        public static bool IsHostBudgetWarningDispayed()
        {
            bool bHostBudgetWarning;
            bHostBudgetWarning = CommonFunctions.IsElementDisplayed("//*/label[contains(@style,'background-color:lightgoldenrodyellow') and contains(text(),'HOST')]", 2);
            return (bHostBudgetWarning ? true : false);
        }

        public static bool IsForecastWarningDispayed()
        {
            bool bForecastWarning;
            bForecastWarning = CommonFunctions.IsElementDisplayed("//*/label[contains(@style,'background-color:lightgoldenrodyellow') and contains(text(),'Forecast')]", 2);
            return (bForecastWarning ? true : false);
        }

        public static MonthlyForcastView getFacilityStatForecastsDataWithWarning()
        {
            IWebElement Jan = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[12]"));
            IWebElement Total = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[13]"));
            IWebElement StatID = CommonFunctions.getElement(By.XPath("((//*/div[contains(@class,'forecast')]//label[contains(@style,'background-color')])[1]/parent::div//input[not(@style='display:none')])[1]//ancestor::div[@statid]"));
            var data = new MonthlyForcastView()
            {
                
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                Total = CommonFunctions.ToDouble(Total.GetAttribute("value")),
                FacilityStatID = StatID.GetAttribute("statid")
            };
            return data;
        }

        public static MonthlyForcastView getFacilityStatForecastsDataAfterUpdaingVolume(string StatID)
        {
            IWebElement Jan = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[12]"));
            IWebElement Total = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[13]"));
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                Total = CommonFunctions.ToDouble(Total.GetAttribute("value")),
            };
            return data;
        }

        public static void InsertAndDoubClickInForecastCell(string StatID, string input)
        {
            By byXpath = By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[3]");
            IWebElement Mar = CommonFunctions.getElement(byXpath);
            CommonFunctions.SetText(Mar, input);
            Thread.Sleep(1000);
            CommonFunctions.DoubleClickMonth(byXpath);
        }

        public static void DoubClickQMIRS_HistCell(string StatID)
        {
            By byXpathMar = By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[3]");
            CommonFunctions.DoubleClickMonth(byXpathMar);

        }

        public static void DoubClickHostBudgetCell(string StatID)
        {
            By byXpathMar = By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[3]");
            CommonFunctions.DoubleClickMonth(byXpathMar);
        }

        public static void DoubClickPercentChangeCell(string StatID)
        {
            By byXpathMar = By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[3]");
            CommonFunctions.DoubleClickMonth(byXpathMar);
        }

        public static MonthlyForcastView getFacilityStatForecastsData(string StatName)
        {
            ClickAway();
            IWebElement Jan = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[12]"));
            IWebElement Total = CommonFunctions.getElement(By.XPath($"(//*/div//input[@title='{StatName.ToUpper()}']/ancestor::div[@statid]//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[13]"));

            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
            };
            return data;
        }

        public static MonthlyForcastView getFacilityStatForecastDataWithStatID(string StatID)
        {
            ClickAway();
            IWebElement Jan = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'cls-forecast') and not(contains(@class,'hide'))])[12]"));
            IWebElement Total = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'budget-data-total') and not(contains(@class,'hide'))])[2]"));
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                Total = CommonFunctions.ToDouble(Total.GetAttribute("value")),
            };
            return data;
        }

        public static MonthlyForcastView getFacilityStatHostBudget(string StatID)
        {
            IWebElement Jan = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[12]"));
            IWebElement Total = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'hostBudget') and not(contains(@class,'hide'))])[13]"));
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                Total = CommonFunctions.ToDouble(Total.GetAttribute("value")),
            };
            return data;
        }

        public static MonthlyForcastView getFacilityStatPercentChange(string StatID)
        {
            ClickAway();
            IWebElement Jan = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'pct-change') and not(contains(@class,'hide'))])[12]"));
            IWebElement Total = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'percent-incr-amt-total') and not(contains(@class,'hide'))])"));
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")), 
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                Total = CommonFunctions.ToDouble(Total.GetAttribute("value")),
            };
            return data;
        }

        public static MonthlyForcastView getFacilityStatQMIRS_HistAndProjectionWithStatID(string StatID)
        {
            ClickAway();
            IWebElement Jan = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist fac-stat-val history-data qmirs') and not(contains(@class,'hide'))])[12]"));
            IWebElement Total = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//input[contains(@class,'from-hist') and not(contains(@class,'hide'))])[13]"));
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                Total = CommonFunctions.ToDouble(Total.GetAttribute("value")),
            };
            return data;
        }

        public static MonthlyForcastView getFacilityStatQMIRS_HistAndProjection(string StatName)
        {
            IWebElement Jan = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[12]"));
            IWebElement Total = CommonFunctions.getElement(By.XPath($"(//*/div/input[@title='{StatName}']/ancestor::div[@class='corp-fac-stat']//label[@class='long-lbl qmirs']/parent::div//input)[13]"));

            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
            };
            return data;
        }    

        public static void LoadVolume(string option)
        {
            
            FacilityStats.GoTo();
            Assert.True(FacilityStats.IsAt, "Facility Stat tab was not displayed.");
            IWebElement cmdLoadVolume = CommonFunctions.getElement(By.XPath("//a[@id='loadVolumeBtn']"));
            cmdLoadVolume.Click();
            switch (option)
            {
                case "Budget Volume":
                    IWebElement chkBudgetVolume = CommonFunctions.getElement(By.XPath("//input[@id='chkHostBudgetVolume']"));
                    CommonFunctions.ClickByJE(chkBudgetVolume);
                    break;
                case "QMIRS Volume":
                    IWebElement chkQMIRSVolume = CommonFunctions.getElement(By.XPath("//input[@id='chkQmirsVolume']"));
                    CommonFunctions.ClickByJE(chkQMIRSVolume);
                    break;
            }
            IWebElement cmdOK = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='Load_volumes_confirm']//div[@class='ui-dialog-buttonset']//button[normalize-space()='OK']"));
            CommonFunctions.ClickByJE(cmdOK);
            CommonFunctions.WaitUntilPageIsAcive();
            CancelUpdateCalc();

        }

        public static void CancelUpdateCalc()
        {
            string OkXpath = "//*/div[@aria-describedby='host_volumes_diff']//div[@class='ui-dialog-buttonset']//button[normalize-space()='OK']";
            bool bExist = CommonFunctions.IsElementDisplayed(OkXpath, 3);
            if (bExist)
            {
                IWebElement cmdUpdateForecast = CommonFunctions.getElement(By.XPath(OkXpath));
                CommonFunctions.ClickByJE(cmdUpdateForecast);
                CommonFunctions.WaitUntilPageIsAcive();
            }
           
        }
        
        private static void SaveChanges()
        {
            bool bExist;
            bool isDisplayed = FacilityStats.IsAt;
            string yesBtnXpath = "//*/div[@aria-describedby=\"save-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            bExist = CommonFunctions.IsElementDisplayed(yesBtnXpath, 5);
            if (bExist)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(yesBtnXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }
        }

        public static void ClickQMIRS(string StatID)
        {
            
            CancelUpdateCalc();
            FacilityStats.GoTo();
            SaveChanges();
            IWebElement cmdQMIRS = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[1]/following-sibling::a[@class='qmirsfill-button custom-button qmirs']"));
            cmdQMIRS.Click();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static void ClickHostBudget(string StatID)
        {
            CancelUpdateCalc();
            FacilityStats.GoTo();
            SaveChanges();
            bool isDisplayed = FacilityStats.IsAt;
            IWebElement cmdH = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[1]/following-sibling::a[@class='hostfill-button custom-button hostBudget']"));
            cmdH.Click();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static void ClickFill(string StatID)
        {
            SaveChanges();
            CancelUpdateCalc();
            FacilityStats.GoTo();
            bool isDisplayed = FacilityStats.IsAt;
            SaveChanges();
            CancelUpdateCalc();
            IWebElement cmdFill = CommonFunctions.getElement(By.XPath($"(//*/div[@statid='{StatID}']//div[contains(@class,'forecast')]//input[not(contains(@class,'hide'))])[1]/following-sibling::a[@class='fill-button custom-button']"));
            cmdFill.Click();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool DeleteFacStat()
        {
            bool bExist;
            string statID, yesBtnXpath, DelXpath, statIDXpath;
            CancelUpdateCalc();
            CommonFunctions.scrollToBottomOfPage();
            statIDXpath = "(//*/div[@id='userDefinedFacilityStatsContainer']//input[contains(@class,'percent')])[1]/following-sibling::a[contains(text(),'Del')]/ancestor::div[@class='user-def-fac-stat clear']";
            IWebElement IWStatID = CommonFunctions.getElement(By.XPath(statIDXpath));
            CommonFunctions.Focus(IWStatID);
            //Get stat ID for added fac stat. 
            statID = IWStatID.GetAttribute("statid");
            DelXpath = $"(//*/div[@id='userDefinedFacilityStatsContainer']//div[@statid='{statID}']//input[contains(@class,'percent')])[1]/following-sibling::a[contains(text(),'Del')]";
            IWebElement cmdDelete = CommonFunctions.getElement(By.XPath(DelXpath));
            cmdDelete.Click();
            yesBtnXpath = "//*/div[@aria-describedby=\"delete-user-def-stat-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            bExist = CommonFunctions.IsElementDisplayed(yesBtnXpath, 5);
            if (bExist)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(yesBtnXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }
            AdminMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
            bExist = CommonFunctions.IsElementDisplayed(DelXpath, 5);
            return (bExist ? true : false);
        }

        public static MonthlyForcastView GetQmirsHistAndProjection(string StatName)
        {
            By ByQmirsHistAndProjection = By.XPath($"//*/div[@class='corp-fac-stat']//input[@class='fac-stat-name' and @value='{StatName}']/../following-sibling::div//label[@class='long-lbl qmirs']/following-sibling::input[not(contains(@style,'none'))]");
            var lstMonth = CommonFunctions.getElements(ByQmirsHistAndProjection);
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(lstMonth[1].GetAttribute("value"),2),
                Feb = CommonFunctions.ToDouble(lstMonth[2].GetAttribute("value"), 2),
                Mar = CommonFunctions.ToDouble(lstMonth[3].GetAttribute("value"), 2),
                Apr = CommonFunctions.ToDouble(lstMonth[4].GetAttribute("value"), 2),
                May = CommonFunctions.ToDouble(lstMonth[5].GetAttribute("value"), 2),
                Jun = CommonFunctions.ToDouble(lstMonth[6].GetAttribute("value"), 2),
                Jul = CommonFunctions.ToDouble(lstMonth[7].GetAttribute("value"), 2),
                Aug = CommonFunctions.ToDouble(lstMonth[8].GetAttribute("value"), 2),
                Sep = CommonFunctions.ToDouble(lstMonth[9].GetAttribute("value"), 2),
                Oct = CommonFunctions.ToDouble(lstMonth[10].GetAttribute("value"), 2),
                Nov = CommonFunctions.ToDouble(lstMonth[11].GetAttribute("value"), 2),
                Dec = CommonFunctions.ToDouble(lstMonth[12].GetAttribute("value"), 2),
                Total = CommonFunctions.ToDouble(lstMonth[13].GetAttribute("value"), 2)
            };
            return data;
        }

        public static MonthlyForcastView GetHostBudgetNextYear(string StatName)
        {
            By ByHostBudgetNextYear = By.XPath($"//*/div[@class='corp-fac-stat']//input[@class='fac-stat-name' and @value='{StatName}']/../following-sibling::div//label[@class='long-lbl hostBudget']/following-sibling::input[not(contains(@style,'none'))]");
            var lstMonth = CommonFunctions.getElements(ByHostBudgetNextYear);
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(lstMonth[1].GetAttribute("value"), 2),
                Feb = CommonFunctions.ToDouble(lstMonth[2].GetAttribute("value"), 2),
                Mar = CommonFunctions.ToDouble(lstMonth[3].GetAttribute("value"), 2),
                Apr = CommonFunctions.ToDouble(lstMonth[4].GetAttribute("value"), 2),
                May = CommonFunctions.ToDouble(lstMonth[5].GetAttribute("value"), 2),
                Jun = CommonFunctions.ToDouble(lstMonth[6].GetAttribute("value"), 2),
                Jul = CommonFunctions.ToDouble(lstMonth[7].GetAttribute("value"), 2),
                Aug = CommonFunctions.ToDouble(lstMonth[8].GetAttribute("value"), 2),
                Sep = CommonFunctions.ToDouble(lstMonth[9].GetAttribute("value"), 2),
                Oct = CommonFunctions.ToDouble(lstMonth[10].GetAttribute("value"), 2),
                Nov = CommonFunctions.ToDouble(lstMonth[11].GetAttribute("value"), 2),
                Dec = CommonFunctions.ToDouble(lstMonth[12].GetAttribute("value"), 2),
                Total = CommonFunctions.ToDouble(lstMonth[13].GetAttribute("value"), 2)
            };
            return data;
        }

        public static MonthlyForcastView GetForecast(string StatName)
        {
            By ByForecast = By.XPath($"//*/div[@class='corp-fac-stat']//input[@class='fac-stat-name' and @value='{StatName}']/../following-sibling::div//label[@class='long-lbl cls-forecast']/following-sibling::input[not(contains(@style,'none'))]");
            var lstMonth = CommonFunctions.getElements(ByForecast);
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(lstMonth[1].GetAttribute("value"), 2),
                Feb = CommonFunctions.ToDouble(lstMonth[2].GetAttribute("value"), 2),
                Mar = CommonFunctions.ToDouble(lstMonth[3].GetAttribute("value"), 2),
                Apr = CommonFunctions.ToDouble(lstMonth[4].GetAttribute("value"), 2),
                May = CommonFunctions.ToDouble(lstMonth[5].GetAttribute("value"), 2),
                Jun = CommonFunctions.ToDouble(lstMonth[6].GetAttribute("value"), 2),
                Jul = CommonFunctions.ToDouble(lstMonth[7].GetAttribute("value"), 2),
                Aug = CommonFunctions.ToDouble(lstMonth[8].GetAttribute("value"), 2),
                Sep = CommonFunctions.ToDouble(lstMonth[9].GetAttribute("value"), 2),
                Oct = CommonFunctions.ToDouble(lstMonth[10].GetAttribute("value"), 2),
                Nov = CommonFunctions.ToDouble(lstMonth[11].GetAttribute("value"), 2),
                Dec = CommonFunctions.ToDouble(lstMonth[12].GetAttribute("value"), 2),
                Total = CommonFunctions.ToDouble(lstMonth[13].GetAttribute("value"), 2)
            };
            return data;
        }

        public static MonthlyForcastView GetPercentChange(string StatName)
        {
            By ByPercentChange = By.XPath($"//*/div[@class='corp-fac-stat']//input[@class='fac-stat-name' and @value='{StatName}']/../following-sibling::div//label[@class='long-lbl']/following-sibling::input[not(contains(@style,'none'))]");
            var lst = CommonFunctions.getElements(ByPercentChange);
            Console.WriteLine($"lst count = {lst.Count.ToString()}");
            var lstMonth = CommonFunctions.getElements(ByPercentChange);
            Console.WriteLine($"lstMonth count = {lstMonth.Count.ToString()}");
            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(lstMonth[0].GetAttribute("value"), 2),
                Feb = CommonFunctions.ToDouble(lstMonth[1].GetAttribute("value"), 2),
                Mar = CommonFunctions.ToDouble(lstMonth[2].GetAttribute("value"), 2),
                Apr = CommonFunctions.ToDouble(lstMonth[3].GetAttribute("value"), 2),
                May = CommonFunctions.ToDouble(lstMonth[4].GetAttribute("value"), 2),
                Jun = CommonFunctions.ToDouble(lstMonth[5].GetAttribute("value"), 2),
                Jul = CommonFunctions.ToDouble(lstMonth[6].GetAttribute("value"), 2),
                Aug = CommonFunctions.ToDouble(lstMonth[7].GetAttribute("value"), 2),
                Sep = CommonFunctions.ToDouble(lstMonth[8].GetAttribute("value"), 2),
                Oct = CommonFunctions.ToDouble(lstMonth[9].GetAttribute("value"), 2),
                Nov = CommonFunctions.ToDouble(lstMonth[10].GetAttribute("value"), 2),
                Dec = CommonFunctions.ToDouble(lstMonth[11].GetAttribute("value"), 2),
                Total = CommonFunctions.ToDouble(lstMonth[12].GetAttribute("value"), 2)
            };
            return data;
        }

        public static MonthElements GetPercentChangeRow(string StatName)
        {
            By ByPercentChange = By.XPath($"//*/div[@class='corp-fac-stat']//input[@class='fac-stat-name' and @value='{StatName}']/../following-sibling::div//label[@class='long-lbl']/following-sibling::input[not(contains(@style,'none'))]");
            var lstMonth = CommonFunctions.getElements(ByPercentChange);
            var data = new MonthElements()
            {
                Jan = lstMonth[0],
                Feb = lstMonth[1],
                Mar = lstMonth[2],
                Apr = lstMonth[3],
                May = lstMonth[4],
                Jun = lstMonth[5],
                Jul = lstMonth[6],
                Aug = lstMonth[7],
                Sep = lstMonth[8],
                Oct = lstMonth[9],
                Nov = lstMonth[10],
                Dec = lstMonth[11],
                Total = lstMonth[12]
            };
            return data;
        }

        public static List<string> getStatNames()
        {
            CommonFunctions.AddTestStep("Get all stat names in the facility stats page", "The stat names are fetched");
            List<string> statNames = new List<string>();
            By ByStatName = By.XPath("//*/div[@class='corp-fac-stat']//input[@class='fac-stat-name']");
            var lstStatName = CommonFunctions.getElements(ByStatName);
            foreach (var stat in lstStatName)
            {
                statNames.Add(stat.GetAttribute("value"));
            }
            return statNames;
        }

        public static List<string> getNewAddedStatNames()
        {
            CommonFunctions.AddTestStep("Get all new stat names in the facility stats page", "The new added stat names are fetched");
            List<string> lstNewstatNames = new List<string>();
            By ByStatName = By.XPath("//*/div[@id='userDefinedFacilityStatsContainer']//div[@class='user-def-fac-stat clear']//div/input[@title]");
            var lstStatName = CommonFunctions.getElements(ByStatName);
            foreach (var stat in lstStatName)
            {
                lstNewstatNames.Add(stat.GetAttribute("value"));
            }
            return lstNewstatNames;
        }

        public static AddFacilityStatCommand AddFacilityStat()
        {
            return new AddFacilityStatCommand();
        }

        public static MonthlyForcastView CalculatePercentChange(MonthlyForcastView Forecast, MonthlyForcastView FacilityStatQmrisHistAndProjection)
        {
            //Formula ((forecast/qmirsorprojection)-1)* 100

            MonthlyForcastView Result = new MonthlyForcastView();
            Result.Jan = CommonFunctions.ToDouble(((Forecast.Jan / FacilityStatQmrisHistAndProjection.Jan) - 1) * 100, 2);
            Result.Feb = CommonFunctions.ToDouble(((Forecast.Feb / FacilityStatQmrisHistAndProjection.Feb) - 1) * 100, 2);
            Result.Mar = CommonFunctions.ToDouble(((Forecast.Mar / FacilityStatQmrisHistAndProjection.Mar) - 1) * 100, 2);
            Result.Apr = CommonFunctions.ToDouble(((Forecast.Apr / FacilityStatQmrisHistAndProjection.Apr) - 1) * 100, 2);
            Result.May = CommonFunctions.ToDouble(((Forecast.May / FacilityStatQmrisHistAndProjection.May) - 1) * 100, 2);
            Result.Jun = CommonFunctions.ToDouble(((Forecast.Jun / FacilityStatQmrisHistAndProjection.Jun) - 1) * 100, 2);
            Result.Jul = CommonFunctions.ToDouble(((Forecast.Jul / FacilityStatQmrisHistAndProjection.Jul) - 1) * 100, 2);
            Result.Aug = CommonFunctions.ToDouble(((Forecast.Aug / FacilityStatQmrisHistAndProjection.Aug) - 1) * 100, 2);
            Result.Sep = CommonFunctions.ToDouble(((Forecast.Sep / FacilityStatQmrisHistAndProjection.Sep) - 1) * 100, 2);
            Result.Oct = CommonFunctions.ToDouble(((Forecast.Oct / FacilityStatQmrisHistAndProjection.Oct) - 1) * 100, 2);
            Result.Nov = CommonFunctions.ToDouble(((Forecast.Nov / FacilityStatQmrisHistAndProjection.Nov) - 1) * 100, 2);
            Result.Dec = CommonFunctions.ToDouble(((Forecast.Dec / FacilityStatQmrisHistAndProjection.Dec) - 1) * 100, 2);
            Result.Total = CommonFunctions.ToDouble(((Forecast.Total / FacilityStatQmrisHistAndProjection.Total) - 1) * 100, 2);
           return Result;
        }

    }

    #region: AddFacilityStatCommand
    public class AddFacilityStatCommand
    {
        private string statDescription;
        private string statJanuary;
        private string forecastJanuary;
        private string percentChange;

        public AddFacilityStatCommand withStatDescription(string StatDescription)
        {
            this.statDescription = StatDescription;
            return this;
        }

        public AddFacilityStatCommand withStatJanuary(string StatJanuary)
        {
            this.statJanuary = StatJanuary;
            return this;
        }

        public AddFacilityStatCommand withForecastJanuary(string ForecastJanuary)
        {
            this.forecastJanuary = ForecastJanuary;
            return this;
        }

        public AddFacilityStatCommand withPercentChange(string PercentChange)
        {
            this.percentChange = PercentChange;
            return this;
        }

        private void clickAddFacilityStat()
        {
            IWebElement cmdSelectedPlan = CommonFunctions.getElement(By.XPath("//input[@id='lblSelectedPlanHostLastUpdtedOn']"));
            CommonFunctions.ClickByJE(cmdSelectedPlan);
            Thread.Sleep(1000);
            IWebElement cmdAddFacilityStat = CommonFunctions.getElement(By.XPath("//*/a[@id='addUserDefFacilityStatBtn']"));
            CommonFunctions.ClickByJE(cmdAddFacilityStat);
        }

        private void setStatDescription()
        {

            IWebElement txtStatDescription = CommonFunctions.getElement(By.XPath("//*/div[@id='userDefinedFacilityStatsContainer']//input[@class='fac-stat-name user-def validation-errors']"));
            CommonFunctions.Focus(txtStatDescription);
            Thread.Sleep(2000);
            //txtStatDescription.Click();
            CommonFunctions.SetText(txtStatDescription, statDescription);
        }

        private void setStatJanuary()
        {
            IWebElement txtStatJanuary = CommonFunctions.getElement(By.XPath("(//*/div[@id='userDefinedFacilityStatsContainer']//input[contains(@class,'history')])[1]"));
            CommonFunctions.scrollToBottomOfPage();
            Thread.Sleep(2000);
            CommonFunctions.SetText(txtStatJanuary, statJanuary);
        }

        private void setForecastJanuary()
        {
            IWebElement txtForecastJanuary = CommonFunctions.getElement(By.XPath("(//*/div[@id='userDefinedFacilityStatsContainer']//input[contains(@class,'budget')])[1]"));
            CommonFunctions.scrollToBottomOfPage();
            Thread.Sleep(2000);
            CommonFunctions.SetText(txtForecastJanuary, forecastJanuary);
        }

        private void setPercentChange()
        {
            IWebElement txtPercentChange = CommonFunctions.getElement(By.XPath("(//*/div[@id='userDefinedFacilityStatsContainer']//input[contains(@class,'percent')])[1]"));
            CommonFunctions.scrollToBottomOfPage();
            Thread.Sleep(2000);
            CommonFunctions.SetText(txtPercentChange, percentChange);
        }

        private void clickStatFill()
        {
            IWebElement cmdStatFill = CommonFunctions.getElement(By.XPath("(//*/div[@id='userDefinedFacilityStatsContainer']//input[contains(@class,'history')])[1]/following-sibling::a[contains(text(),'Fill')]"));
            CommonFunctions.scrollToBottomOfPage();
            CommonFunctions.ClickByJE(cmdStatFill);
        }

        private void clickForecastFill()
        {
            IWebElement cmdForecastFill = CommonFunctions.getElement(By.XPath("(//*/div[@id='userDefinedFacilityStatsContainer']//input[contains(@class,'budget')])[1]/following-sibling::a[contains(text(),'Fill')]"));
            CommonFunctions.scrollToBottomOfPage();
            CommonFunctions.ClickByJE(cmdForecastFill);
        }

        private void clickPercentChangeFill()
        {
            IWebElement cmdPercentChangeFill = CommonFunctions.getElement(By.XPath("(//*/div[@id='userDefinedFacilityStatsContainer']//input[contains(@class,'percent')])[1]/following-sibling::a[contains(text(),'Fill')]"));
            CommonFunctions.scrollToBottomOfPage();
            CommonFunctions.ClickByJE(cmdPercentChangeFill);
        }

        public void Save()
        {
            clickAddFacilityStat();
            setStatDescription();
            setStatJanuary();
            setForecastJanuary();
            setPercentChange();
            //clickStatFill();
            //clickForecastFill();
            //clickPercentChangeFill();
            AdminMenu.Save();
            Thread.Sleep(2000);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
        }
    }
    #endregion
}
