﻿using OpenQA.Selenium;
using RazorEngine.Compilation.ImpromptuInterface.Optimization;
using System.Collections.Generic;
using System.Configuration;

namespace ISAS_Regression_Automation
{
    public class AHRRate
    {
        public static void GoTo()
        {
            IWebElement cmdAHR = CommonFunctions.getElement(By.XPath("//*/input[@id='AHRMonths']"));
            CommonFunctions.ClickByJE(cmdAHR);
            CommonFunctions.WaitUntilPageIsAcive();
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//*/input[@id='excludeMonthEL7']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        public static AHRRateCommand QMIRSHistoricalMonth()
        {
            return new AHRRateCommand();
        }
    }
    #region:AHRRateCommand
    public class AHRRateCommand
    {
        private string month;
        public AHRRateCommand withMonth(string Month)
        {
            this.month = Month;
            return this;
        }

        private static void UnselectAllMonthCheckboxes()
        {
            IList<IWebElement> lstMonths = CommonFunctions.getElements(By.XPath("//*/input[contains(@id,'excludeMonthEL')]"));
            foreach (IWebElement element in lstMonths)
            {
                if (element.Selected)
                {
                    element.Click();
                }
            }
        }

        private void SelectMonth()
        {
            IList<IWebElement> lstMonths = CommonFunctions.getElements(By.XPath("//*/input[contains(@id,'excludeMonthEL')]/parent::label"));
            foreach (IWebElement element in lstMonths)
            {
                if (element.Text.Contains(month))
                {
                    element.FindElement(By.TagName("input")).Click();
                }
            }
        }

        private void ClickApplyToAllDept()
        {
            IWebElement cmdAHRApplyAllDept = CommonFunctions.getElement(By.XPath("//*/input[@id='btnAHRApplyAllDept']"));
            CommonFunctions.ClickByJE(cmdAHRApplyAllDept);
        }
        private void Confirm()
        {
            bool bExists;
            string confirmSave = "//*/div[@aria-describedby=\"save-confirm_AHR_All_Dept\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            bExists = CommonFunctions.IsElementDisplayed(confirmSave, 5);
            if (bExists)
            {
                IWebElement cmdConfirmSave = CommonFunctions.getElement(By.XPath(confirmSave));
                CommonFunctions.ClickByJE(cmdConfirmSave);
                CommonFunctions.WaitUntilPageIsAcive();
            }
        }

        public void ApplyToAllDept()
        {
            UnselectAllMonthCheckboxes();
            SelectMonth();
            ClickApplyToAllDept();
            Confirm();
            AverageLaborRateEmpl.GoTo();
            AdminMenu.Save();
        }
    }
    #endregion
}
