﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    class FacilityStatMappingExcelReport
    {
        public class Clfacilitystatmapping
        {
            public string Dept { get; set; }
            public string DeptDesc { get; set; }
            public string PLUSDeptType { get; set; }
            public string WFTDeptType { get; set; }
            public string DepartmentStat { get; set; }
            public string FacilityStat { get; set; }
            public string CLPercentOrFixedFtes { get; set; }
        }

        public static List<Clfacilitystatmapping> ParseFacilitystatMappingExcelReport(string filePath)
        {
            var result = new List<Clfacilitystatmapping>();

            // Register the code page provider (required for .xls files)
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var allRows = new List<object[]>();

                    // Read all rows into memory
                    do
                    {
                        while (reader.Read())
                        {
                            var row = new object[reader.FieldCount];
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row[i] = reader.GetValue(i);
                            }
                            allRows.Add(row);
                        }
                    } while (reader.NextResult());

                    // Find the row that contains "Dept" in the first column
                    int startRowIndex = CommonFunctions.FindDeptRow("Dept", allRows);

                    if (startRowIndex == -1)
                    {
                        throw new InvalidOperationException("Could not find 'Dept' in the first column");
                    }

                    // Process rows starting after the "Dept" header row
                    for (int i = startRowIndex + 1; i < allRows.Count; i++)
                    {
                        var row = allRows[i];

                        // Skip empty rows
                        if (CommonFunctions.IsEmptyRow(row))
                            continue;

                        var lstRows = new Clfacilitystatmapping()
                        {
                            Dept = CommonFunctions.GetStringValue(row, 0),
                            DeptDesc = CommonFunctions.GetStringValue(row, 1),
                            PLUSDeptType = CommonFunctions.GetStringValue(row, 2),
                            WFTDeptType = CommonFunctions.GetStringValue(row, 3),
                            DepartmentStat = CommonFunctions.GetStringValue(row, 4),
                            FacilityStat = CommonFunctions.GetStringValue(row, 5),
                            CLPercentOrFixedFtes = CommonFunctions.GetStringValue(row, 6),
                        };


                        result.Add(lstRows);
                    }
                }
            }
            return result;
        }
    }
}
