﻿using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class DeptFacilityRatioImpactAnalysisReport
    {
        public static void GoTo()
        {
            WFTMainMenu.WFTReports.Facility.SelectDeptFacilityRatioImpactAnalysis();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to Dept Facility Ratio Impact Analysis report", "Dept Facility Ratio Impact Analysis  report page is displayed.");
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlReportYear']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        public static DeptFacilityRatioImpactAnalysisReportCommand Report()
        {
            return new DeptFacilityRatioImpactAnalysisReportCommand();
        }
    }
    #region: DeptFacilityRatioImpactAnalysisReportCommand
    public class DeptFacilityRatioImpactAnalysisReportCommand
    {
        private string year;
        private string planStatus;
        private string plan;
        private string smoothingnVariancePercent
;

        public DeptFacilityRatioImpactAnalysisReportCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public DeptFacilityRatioImpactAnalysisReportCommand withPlanStatus(string PlanStatus)
        {
            this.planStatus = PlanStatus;
            return this;
        }

        public DeptFacilityRatioImpactAnalysisReportCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }

        public DeptFacilityRatioImpactAnalysisReportCommand withSmoothingnVariancePercent(string SmoothingnVariancePercent)
        {
            this.smoothingnVariancePercent = SmoothingnVariancePercent;
            return this;
        }

        private void setYear()
        {
            if (!string.IsNullOrEmpty(year))
            {
                IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//select[@id='ddlReportYear']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
            }
        }

        private void setPlanStatus()
        {
            if (!string.IsNullOrEmpty(planStatus))
            {
                IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlanStatuses']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, planStatus);
            }
        }

        private void setSmoothingnVariancePercent()
        {
            if (!string.IsNullOrEmpty(smoothingnVariancePercent))
            {
                IWebElement mnuSmoothingnVariancePercent = CommonFunctions.getElement(By.XPath("//select[@id='ddlSmoothingVariance']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuSmoothingnVariancePercent, smoothingnVariancePercent);
            }
        }

        private void setPlan()
        {
            if (!string.IsNullOrEmpty(plan))
            {
                IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlans']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
            }
        }

        private void clickPDF()
        {
            IWebElement cmdPDF = CommonFunctions.getElement(By.XPath("//img[@title='PDF Format']"));
            CommonFunctions.ClickByJE(cmdPDF);
        }
        private void clickExcel()
        {
            IWebElement cmdExcel = CommonFunctions.getElement(By.XPath("//img[@title='Excel Format']"));
            CommonFunctions.ClickByJE(cmdExcel);
        }



        public void SelectPDF()
        {
            setYear();
            setPlanStatus();
            setPlan();
            setSmoothingnVariancePercent();
            clickPDF();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the PDF button", "Verify the PDF report is downloaded");
        }

        public void SelectExcel()
        {
            setYear();
            setPlanStatus();
            setPlan();
            setSmoothingnVariancePercent();
            clickExcel();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the Excel button", "Verify the Excel report is downloaded");
        }
    }
    #endregion
}




