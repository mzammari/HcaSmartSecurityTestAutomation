﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DeptFacilityRatioImpactAnalysisSP
    {
        public static string GetDeptFacilityRatioImpactAnalysisSPData()
        {
            RunData.PlanID = AdminPlanDetail.getPlanID();
            string query = $"DECLARE @PlanID int={RunData.PlanID}" + Environment.NewLine +
            "DECLARE @SmoothingVar DECIMAL(19, 3) =1.000" + Environment.NewLine +
            "BEGIN" + Environment.NewLine +
            "DECLARE @TAB TABLE(" + Environment.NewLine +
            "Number VARCHAR(100)," + Environment.NewLine +
            "Name VARCHAR(100)," + Environment.NewLine +
            "FName VARCHAR(100)," + Environment.NewLine +
            "DeptType VARCHAR(100)," + Environment.NewLine +
            "Month INT," + Environment.NewLine +
            "DeptFacilityRatio DECIMAL(19, 3)," + Environment.NewLine +
            "HistoricalDepartmentTotalUos DECIMAL(19, 3)," + Environment.NewLine +
            "HistoricalValue DECIMAL(19, 3)," + Environment.NewLine +
            "HistDFRValue DECIMAL (19, 3)," + Environment.NewLine +
            "BudgetTotal DECIMAL(19, 3)," + Environment.NewLine +
            "DeptVolumeTotal DECIMAL(19, 3)," + Environment.NewLine +
            "DeptFacilityRatioTotal DECIMAL(19,3)," + Environment.NewLine +
            "--PlusHoursPerUos DECIMAL(19,3)," + Environment.NewLine +
            "VariableHoursPerUosTotal DECIMAL(19,3)," + Environment.NewLine +
            "DfrtUpperLimit DECIMAL(19,3)," + Environment.NewLine +
            "DfrtLowerLimit DECIMAL(19,3)" + Environment.NewLine +
            ")" + Environment.NewLine +
            "INSERT INTO @TAB(" + Environment.NewLine +
            "Number," + Environment.NewLine +
            "Name," + Environment.NewLine +
            "FName," + Environment.NewLine +
            "DeptType," + Environment.NewLine +
            "[Month]," + Environment.NewLine +
            "DeptFacilityRatio," + Environment.NewLine +
            "HistoricalDepartmentTotalUos," + Environment.NewLine +
            "HistoricalValue," + Environment.NewLine +
            "HistDFRValue," + Environment.NewLine +
            "BudgetTotal," + Environment.NewLine +
            "DeptVolumeTotal," + Environment.NewLine +
            "DeptFacilityRatioTotal," + Environment.NewLine +
            "--PlusHoursPerUos," + Environment.NewLine +
            "VariableHoursPerUosTotal," + Environment.NewLine +
            "DfrtUpperLimit," + Environment.NewLine +
            "DfrtLowerLimit" + Environment.NewLine +
            ")" + Environment.NewLine +
            "SELECT DPT.Number, DPT.[Name], Fstat.Name As FName," + Environment.NewLine +
            "(SELECT Description FROM DepartmentType WHERE Id = WFTDPT.DepartmentType_ID) AS DeptType," + Environment.NewLine +
            "WMV.Month, WMV.DeptFacilityRatio," + Environment.NewLine +
            "RMV.[HistoricalDepartmentTotalUos] ," + Environment.NewLine +
            "FSV.HistoricalValue," + Environment.NewLine +
            "ISNULL(RMV.[HistoricalDepartmentTotalUos]/NULLIF(FSV.HistoricalValue, 0),0) AS HistDFRValue," + Environment.NewLine +
            "WFTSTAT.BudgetTotal," + Environment.NewLine +
            "WFTDPT.DeptVolumeTotal," + Environment.NewLine +
            "WFTDPT.DeptFacilityRatioTotal," + Environment.NewLine +
            "--RMV.PlusHoursPerUos," + Environment.NewLine +
            "WFTDPT.VariableHoursPerUosTotal," + Environment.NewLine +
            "(WFTDPT.DeptFacilityRatioTotal + (WFTDPT.DeptFacilityRatioTotal*@SmoothingVar/100))," + Environment.NewLine +
            "(WFTDPT.DeptFacilityRatioTotal - (WFTDPT.DeptFacilityRatioTotal*@SmoothingVar/100))" + Environment.NewLine +
            "FROM [ISAS_WorkloadForecaster].[dbo].[WftDepartment] WFTDPT" + Environment.NewLine +
            "JOIN Department DPT ON WFTDPT.Department_ID = DPT.Id" + Environment.NewLine +
            "JOIN WftFacilityStat WFTSTAT ON WFTSTAT.ID = WFTDPT.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FACSTAT ON FACSTAT.Id= WFTSTAT.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "Join FacilityStat Fstat on Fstat.Id=FACSTAT.FacilityStat_ID" + Environment.NewLine +
            "JOIN WftMonthlyValue WMV ON WMV.WftDepartment_ID = WFTDPT.Id" + Environment.NewLine +
            "LEFT JOIN FacilityStatValue FSV ON FSV.FacilityRelatedFacilityStat_ID = facstat.Id AND FSV.Month = WMV.Month" + Environment.NewLine +
            "JOIN ReferenceMonthlyValue RMV ON RMV.Department_ID = DPT.Id AND WMV.Month = RMV.Month" + Environment.NewLine +
            "WHERE WFTDPT.WftPlan_ID = @PlanId  and DPT.IsInactiveInWFT=0" + Environment.NewLine +
            "order by number" + Environment.NewLine +
            "DECLARE @DFRatioResult TABLE(" + Environment.NewLine +
            "Number VARCHAR(100), Name VARCHAR(100), FName VARCHAR(100), DeptType VARCHAR(100),  DeptFacilityRatioTotal DECIMAL(19, 3)," + Environment.NewLine +
            "PlusVarStd DECIMAL(19, 3), DfrtUpperLimit DECIMAL(19, 3), DfrtLowerLimit DECIMAL(19, 3),Jan DECIMAL(19, 3)," + Environment.NewLine +
            "Feb DECIMAL(19, 3), Mar DECIMAL(19, 3), Apr DECIMAL(19, 3), May DECIMAL(19, 3), Jun DECIMAL(19, 3), Jul DECIMAL(19, 3)," + Environment.NewLine +
            "Aug DECIMAL(19, 3), Sep DECIMAL(19, 3), Oct DECIMAL(19, 3), Nov DECIMAL(19, 3), Dec DECIMAL(19, 3)" + Environment.NewLine +
            ")" + Environment.NewLine +
            "DECLARE @HistDFRatioResult2 TABLE(" + Environment.NewLine +
            "Number VARCHAR(100),  HVJan DECIMAL(19, 3), HVFeb DECIMAL(19, 3), HVMar DECIMAL(19, 3)," + Environment.NewLine +
            "HVApr DECIMAL(19, 3), HVMay DECIMAL(19, 3), HVJun DECIMAL(19, 3), HVJul DECIMAL(19, 3)," + Environment.NewLine +
            "HVAug DECIMAL(19, 3), HVSep DECIMAL(19, 3), HVOct DECIMAL(19, 3), HVNov DECIMAL(19, 3)," + Environment.NewLine +
            "HVDec DECIMAL(19, 3), FacilityStatTotal DECIMAL(19, 3), VolumeFCastTotal DECIMAL(19, 3)" + Environment.NewLine +
            ")" + Environment.NewLine +
            "DECLARE @HistDeptRatioTotalResult3 TABLE(" + Environment.NewLine +
            "Number VARCHAR(100), HistoricalDeptFacilityRatioTotal DECIMAL(19, 3)--, PlusVarStd DECIMAL(19,3)" + Environment.NewLine +
            ")" + Environment.NewLine +
            "INSERT INTO @DFRatioResult(" + Environment.NewLine +
            "Number," + Environment.NewLine +
            "Name," + Environment.NewLine +
            "FName," + Environment.NewLine +
            "DeptType," + Environment.NewLine +
            "DeptFacilityRatioTotal," + Environment.NewLine +
            "PlusVarStd," + Environment.NewLine +
            "DfrtUpperLimit," + Environment.NewLine +
            "DfrtLowerLimit," + Environment.NewLine +
            "Jan," + Environment.NewLine +
            "Feb," + Environment.NewLine +
            "Mar," + Environment.NewLine +
            "Apr," + Environment.NewLine +
            "May," + Environment.NewLine +
            "Jun," + Environment.NewLine +
            "Jul," + Environment.NewLine +
            "Aug," + Environment.NewLine +
            "Sep," + Environment.NewLine +
            "Oct," + Environment.NewLine +
            "Nov," + Environment.NewLine +
            "Dec" + Environment.NewLine +
            ")" + Environment.NewLine +
            "SELECT * FROM" + Environment.NewLine +
            "(SELECT Number," + Environment.NewLine +
            "Name," + Environment.NewLine +
            "FName," + Environment.NewLine +
            "DeptType," + Environment.NewLine +
            "Month," + Environment.NewLine +
            "DeptFacilityRatio," + Environment.NewLine +
            "DeptFacilityRatioTotal," + Environment.NewLine +
            "VariableHoursPerUosTotal," + Environment.NewLine +
            "DfrtUpperLimit," + Environment.NewLine +
            "DfrtLowerLimit" + Environment.NewLine +
            "FROM @TAB" + Environment.NewLine +
            ") AS SourceTable" + Environment.NewLine +
            "PIVOT(AVG(DeptFacilityRatio) FOR Month in (" + Environment.NewLine +
            "[1], [2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])" + Environment.NewLine +
            ") AS PivotTable" + Environment.NewLine +
            "INSERT INTO @HistDFRatioResult2(" + Environment.NewLine +
            "Number," + Environment.NewLine +
            "FacilityStatTotal," + Environment.NewLine +
            "VolumeFCastTotal," + Environment.NewLine +
            "HVJan," + Environment.NewLine +
            "HVFeb," + Environment.NewLine +
            "HVMar," + Environment.NewLine +
            "HVApr," + Environment.NewLine +
            "HVMay," + Environment.NewLine +
            "HVJun," + Environment.NewLine +
            "HVJul," + Environment.NewLine +
            "HVAug," + Environment.NewLine +
            "HVSep," + Environment.NewLine +
            "HVOct," + Environment.NewLine +
            "HVNov," + Environment.NewLine +
            "HVDec" + Environment.NewLine +
            ")" + Environment.NewLine +
            "SELECT * FROM" + Environment.NewLine +
            "(SELECT Number," + Environment.NewLine +
            "BudgetTotal," + Environment.NewLine +
            "Month," + Environment.NewLine +
            "CONVERT(INT, ROUND(DeptVolumeTotal, 0,0),0) as DeptVolTotal," + Environment.NewLine +
            "HistDFRValue" + Environment.NewLine +
            "FROM @TAB ) AS SourceTable" + Environment.NewLine +
            "PIVOT(avg(HistDFRValue) FOR Month in (" + Environment.NewLine +
            "[1], [2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])" + Environment.NewLine +
            ") AS PivotTable" + Environment.NewLine +
            "declare @excludedMonth varchar(26)" + Environment.NewLine +
            "set @excludedMonth = (select ExcludedMonths from Facility where Id in(select Facility_Id from wftplan where Id =@PlanID and ExcludedMonths is not null))" + Environment.NewLine +
            "INSERT INTO @HistDeptRatioTotalResult3(" + Environment.NewLine +
            "Number," + Environment.NewLine +
            "HistoricalDeptFacilityRatioTotal" + Environment.NewLine +
            "--PlusVarStd" + Environment.NewLine +
            ")" + Environment.NewLine +
            "SELECT Number," + Environment.NewLine +
            "ISNULL(SUM(HistoricalDepartmentTotalUos)/SUM(nullif(HistoricalValue, 0)),0)" + Environment.NewLine +
            "--AVG(PlusHoursPerUos) AS PlusVarStd" + Environment.NewLine +
            "FROM @TAB where Month not in(select * FROM string_split(@excludedMonth,','))" + Environment.NewLine +
            "GROUP BY Number" + Environment.NewLine +
            "print @excludedMonth" + Environment.NewLine +
            "SELECT  R.*," + Environment.NewLine +
            "CAST(CASE WHEN" + Environment.NewLine +
            "(Jan NOT BETWEEN  DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Feb NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Mar NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Apr NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (May NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Jun NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Jul NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Aug NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Sep NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Oct NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Nov NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "OR (Dec NOT BETWEEN DfrtLowerLimit AND DfrtUpperLimit)" + Environment.NewLine +
            "THEN 0" + Environment.NewLine +
            "ELSE 1" + Environment.NewLine +
            "END AS bit" + Environment.NewLine +
            ") AS Smoothed," + Environment.NewLine +
            "HVJan," + Environment.NewLine +
            "HVFeb," + Environment.NewLine +
            "HVMar," + Environment.NewLine +
            "HVApr," + Environment.NewLine +
            "HVMay," + Environment.NewLine +
            "HVJun," + Environment.NewLine +
            "HVJul," + Environment.NewLine +
            "HVAug," + Environment.NewLine +
            "HVSep," + Environment.NewLine +
            "HVOct," + Environment.NewLine +
            "HVNov," + Environment.NewLine +
            "HVDec," + Environment.NewLine +
            "FacilityStatTotal," + Environment.NewLine +
            "VolumeFCastTotal," + Environment.NewLine +
            "R3.HistoricalDeptFacilityRatioTotal," + Environment.NewLine +
            "Round((((FacilityStatTotal * HistoricalDeptFacilityRatioTotal)-VolumeFCastTotal)*R.PlusVarStd)/(365*5.714), 3) as FteImpact" + Environment.NewLine +
            "--PlusVarStd" + Environment.NewLine +
            "FROM" + Environment.NewLine +
            "(SELECT *" + Environment.NewLine +
            "FROM @DFRatioResult)  R" + Environment.NewLine +
            "right JOIN" + Environment.NewLine +
            "(SELECT * FROM @HistDFRatioResult2) R2" + Environment.NewLine +
            "ON R.Number = R2.Number" + Environment.NewLine +
            "JOIN" + Environment.NewLine +
            "(SELECT * FROM @HistDeptRatioTotalResult3) R3" + Environment.NewLine +
            "ON R2.Number = R3.Number" + Environment.NewLine +
            "END";

            return query;
        }
    }
}
