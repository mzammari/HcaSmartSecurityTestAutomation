﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DeptFacilityRatioImpactAnalysis
    {
        public string Dept { get; set; }
        public string DeptDesc { get; set; }
        public string DeptType { get; set; }
        public string DFRatio { get; set; }
        public string FacilityStatToUse { get; set; }
        public decimal Jan { get; set; }
        public decimal Feb { get; set; }
        public decimal Mar { get; set; }
        public decimal Apr { get; set; }
        public decimal May { get; set; }
        public decimal Jun { get; set; }
        public decimal Jul { get; set; }
        public decimal Aug { get; set; }
        public decimal Sep { get; set; }
        public decimal Oct { get; set; }
        public decimal Nov { get; set; }
        public decimal Dec { get; set; }
        public decimal Total { get; set; }
        public decimal Smooth { get; set; }
        public decimal VolpercentImppercent { get; set; }
        public decimal FTEImppercent { get; set; }
    }

    public class DeptFacilityRatioImpactAnalysisExcelReport
    {
        public static List<DeptFacilityRatioImpactAnalysis> ParseDeptFacilityRatioImpactAnalysisExcelReport(string filePath)
        {
            var result = new List<DeptFacilityRatioImpactAnalysis>();

            // Register the code page provider (required for .xls files)
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var allRows = new List<object[]>();

                    // Read all rows into memory
                    do
                    {
                        while (reader.Read())
                        {
                            var row = new object[reader.FieldCount];
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row[i] = reader.GetValue(i);
                            }
                            allRows.Add(row);
                        }
                    } while (reader.NextResult());

                    // Find the row that contains "Dept" in the first column
                    int startRowIndex = CommonFunctions.FindDeptRow("Dept", allRows);

                    if (startRowIndex == -1)
                    {
                        throw new InvalidOperationException("Could not find 'Dept' in the first column");
                    }

                    // Process rows starting after the "Dept" header row
                    for (int i = startRowIndex + 1; i < allRows.Count; i++)
                    {
                        var row = allRows[i];

                        // Skip empty rows
                        if (CommonFunctions.IsEmptyRow(row))
                            continue;

                        var lstRows = new DeptFacilityRatioImpactAnalysis()
                        {
                            Dept = CommonFunctions.GetStringValue(row, 0),
                            DeptDesc = CommonFunctions.GetStringValue(row, 1),
                            DeptType = CommonFunctions.GetStringValue(row, 2),
                            DFRatio = CommonFunctions.GetStringValue(row, 3),
                            FacilityStatToUse = CommonFunctions.GetStringValue(row, 4),
                            Jan = CommonFunctions.GetDecimalValue(row, 5),
                            Feb = CommonFunctions.GetDecimalValue(row, 6),
                            Mar = CommonFunctions.GetDecimalValue(row, 7),
                            Apr = CommonFunctions.GetDecimalValue(row, 8),
                            May = CommonFunctions.GetDecimalValue(row, 9),
                            Jun = CommonFunctions.GetDecimalValue(row, 10),
                            Jul = CommonFunctions.GetDecimalValue(row, 11),
                            Aug = CommonFunctions.GetDecimalValue(row, 12),
                            Sep = CommonFunctions.GetDecimalValue(row, 13),
                            Oct = CommonFunctions.GetDecimalValue(row, 14),
                            Nov = CommonFunctions.GetDecimalValue(row, 15),
                            Dec = CommonFunctions.GetDecimalValue(row, 16),
                            Total = CommonFunctions.GetDecimalValue(row, 17),
                            Smooth = CommonFunctions.GetDecimalValue(row, 18),
                            VolpercentImppercent = CommonFunctions.GetDecimalValue(row, 19),
                            FTEImppercent = CommonFunctions.GetDecimalValue(row, 20),
                        };

                        result.Add(lstRows);
                    }
                }
            }
            return result;
        }
    }
}
