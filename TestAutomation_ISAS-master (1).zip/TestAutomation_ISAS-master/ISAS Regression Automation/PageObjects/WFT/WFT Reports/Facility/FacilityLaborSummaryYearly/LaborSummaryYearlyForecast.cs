﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation;

/// <summary>
/// Yearly forecast summary. Each property is a display metric from the summary
/// grid, prefixed with "Forecast", populated from the matching DB column on a
/// <see cref="LaborMetricRow"/>.
/// </summary>
public class LaborSummaryYearlyForecast
{
    public double? ForecastAdmissions { get; set; }
    public double? ForecastAdjustedAdmissions { get; set; }
    public double? ForecastPatientDays { get; set; }
    public double? ForecastAPD { get; set; }
    public double? ForecastERVisits { get; set; }
    public double? ForecastOutpatientVisits { get; set; }
    public double? ForecastOPFactor { get; set; }
    public double? ForecastALOS { get; set; }
    public double? ForecastEEOB { get; set; }
    public double? ForecastMHAA { get; set; }

    // ---- Labor cost & overtime --------------------------------------------
    public double? ForecastTotalSalariesAndWages { get; set; }   // ($000) — thousands
    public double? ForecastTotalContractLabor { get; set; }      // ($000) — thousands
    public double? ForecastTotalLaborExpense { get; set; }       // ($000) — thousands
    public double? ForecastEmployedLaborRate { get; set; }       // raw rate; grid shows FormatGRV3(...)
    public double? ForecastContractLaborRate { get; set; }
    public double? ForecastOvertimePremiumDollars { get; set; }
    public double? ForecastOvertimePercent { get; set; }
    public double? ForecastOvertimeFTEs { get; set; }

    // ---- Facility FTE summary ---------------------------------------------
    public double? ForecastEmployedProductiveFTEs { get; set; }
    public double? ForecastContractLaborPercent { get; set; }
    public double? ForecastContractFTEs { get; set; }
    public double? ForecastTotalProductiveFTEs { get; set; }
    public double? ForecastNonProductivePercent { get; set; }
    public double? ForecastNonProductiveFTEs { get; set; }
    public double? ForecastEmployedPaidFTEs { get; set; }
    public double? ForecastTotalFTEs { get; set; }

    // -----------------------------------------------------------------------
    // Mapping: assign each DB value from the row to its Forecast property.
    // -----------------------------------------------------------------------

    /// <summary>Builds a forecast summary from one DB row.</summary>
    public static LaborSummaryYearlyForecast FromLaborMetricRow(LaborMetricRow row)
    {
        ArgumentNullException.ThrowIfNull(row);

        return new LaborSummaryYearlyForecast
        {
            ForecastAdmissions = row.Admissions,
            ForecastAdjustedAdmissions = row.AAdmissions,
            ForecastPatientDays = row.PatientDays,
            ForecastAPD = row.APatientDays,
            ForecastERVisits = row.ERVisits,
            ForecastOutpatientVisits = row.Outpatient,
            ForecastOPFactor = row.OPFactorTotal,
            ForecastALOS = row.ALOSTotal,
            ForecastEEOB = row.EeobTotal,
            ForecastMHAA = row.MhAaTotal,

            // Labor cost & overtime
            ForecastTotalSalariesAndWages = row.TotalSalariesAndWagesTotal,
            ForecastTotalContractLabor = row.TotalContractLaborDollarsTotal,
            ForecastTotalLaborExpense = row.TotalLaborExpenseTotal,
            ForecastEmployedLaborRate = row.EmployedLaborRateTotal, // grid: FormatGRV3(...) at display
            ForecastContractLaborRate = row.ContractLaborRateTotal,
            ForecastOvertimePremiumDollars = row.OverTimePremiumDollarsTotal,
            ForecastOvertimePercent = row.OtPercentTotal,
            ForecastOvertimeFTEs = row.OTFTEsTotal,

            // Facility FTE summary (sourced from current-period *Total columns)
            ForecastEmployedProductiveFTEs = row.EmployedProductiveFtesTotal,
            ForecastContractLaborPercent = row.ContractPercentTotal,
            ForecastContractFTEs = row.ContractFtesTotal,
            ForecastTotalProductiveFTEs = row.TotalProductiveFtesTotal,
            ForecastNonProductivePercent = row.NonProductivePercentTotal,
            ForecastNonProductiveFTEs = row.NonProductiveFtesTotal,
            ForecastEmployedPaidFTEs = row.EmployedPaidFtesTotal,
            ForecastTotalFTEs = row.TotalFtesTotal,
        };
    }

    /// <summary>Builds a forecast summary for each DB row.</summary>
    public static IReadOnlyList<LaborSummaryYearlyForecast> FromLaborMetricRows(
        IEnumerable<LaborMetricRow> rows)
    {
        ArgumentNullException.ThrowIfNull(rows);
        return rows.Select(FromLaborMetricRow).ToList();
    }


    public Dictionary<string, double?> ToLabeledValues() =>
            new(StringComparer.Ordinal)
            {
                ["Admissions"] = ForecastAdmissions,
                ["Adjusted Admissions"] = ForecastAdjustedAdmissions,
                ["Patient Days"] = ForecastPatientDays,
                ["APD"] = ForecastAPD,
                ["ER Visits"] = ForecastERVisits,
                ["Outpatient Visits"] = ForecastOutpatientVisits,
                ["OP Factor"] = ForecastOPFactor,
                ["ALOS"] = ForecastALOS,
                ["EEOB"] = ForecastEEOB,
                ["MH/AA"] = ForecastMHAA,
                ["Total Salaries & Wages ($000)"] = ForecastTotalSalariesAndWages,
                ["Total Contract Labor  ($000)"] = ForecastTotalContractLabor,
                ["Total Labor Expense  ($000)"] = ForecastTotalLaborExpense,
                ["Employed Labor Rate"] = ForecastEmployedLaborRate,
                ["Contract Labor Rate"] = ForecastContractLaborRate,
                ["Overtime Premium Dollars"] = ForecastOvertimePremiumDollars,
                ["Overtime %"] = ForecastOvertimePercent,
                ["Overtime FTEs"] = ForecastOvertimeFTEs,
                ["Employed (Productive) FTEs"] = ForecastEmployedProductiveFTEs,
                ["Contract Labor %"] = ForecastContractLaborPercent,
                ["Contract FTEs"] = ForecastContractFTEs,
                ["Total Productive FTEs"] = ForecastTotalProductiveFTEs,
                ["Employed Non-Productive %"] = ForecastNonProductivePercent,
                ["Non-Productive FTEs"] = ForecastNonProductiveFTEs,
                ["Employed (Paid) FTEs"] = ForecastEmployedPaidFTEs,
                ["Total FTEs (Paid + Contract)"] = ForecastTotalFTEs,
            };
}
