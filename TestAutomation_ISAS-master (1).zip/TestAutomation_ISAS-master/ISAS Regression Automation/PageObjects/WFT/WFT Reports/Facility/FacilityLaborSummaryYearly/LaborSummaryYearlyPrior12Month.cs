﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation;

/// <summary>
/// Yearly prior-12-month summary. Each property is a display metric from the
/// summary grid, prefixed with "Prior12Month", populated from the matching
/// Prior* column on a <see cref="LaborMetricRow"/>.
/// Source proc: rpt_GetLaborSumFacility.
/// </summary>
public class LaborSummaryYearlyPrior12Month
{
    // ---- Volume & productivity --------------------------------------------
    public double? Prior12MonthAdmissions { get; set; }
    public double? Prior12MonthAdjustedAdmissions { get; set; }
    public double? Prior12MonthPatientDays { get; set; }
    public double? Prior12MonthAPD { get; set; }
    public double? Prior12MonthERVisits { get; set; }
    public double? Prior12MonthOutpatientVisits { get; set; }
    public double? Prior12MonthOPFactor { get; set; }
    public double? Prior12MonthALOS { get; set; }
    public double? Prior12MonthEEOB { get; set; }
    public double? Prior12MonthMHAA { get; set; }

    // ---- Labor cost & overtime --------------------------------------------
    public double? Prior12MonthTotalSalariesAndWages { get; set; }   // ($000) — thousands
    public double? Prior12MonthTotalContractLabor { get; set; }      // ($000) — thousands
    public double? Prior12MonthTotalLaborExpense { get; set; }       // ($000) — thousands
    public double? Prior12MonthEmployedLaborRate { get; set; }
    public double? Prior12MonthContractLaborRate { get; set; }
    public double? Prior12MonthOvertimePremiumDollars { get; set; }
    public double? Prior12MonthOvertimePercent { get; set; }         // grid shows FormatDec(...)
    public double? Prior12MonthOvertimeFTEs { get; set; }            // grid shows FormatGRV3(...)

    // ---- Facility FTE summary ---------------------------------------------
    public double? Prior12MonthEmployedProductiveFTEs { get; set; }
    public double? Prior12MonthContractLaborPercent { get; set; }    // source * 100
    public double? Prior12MonthContractFTEs { get; set; }
    public double? Prior12MonthTotalProductiveFTEs { get; set; }     // grid shows FormatGRV3(...)
    public double? Prior12MonthNonProductivePercent { get; set; }
    public double? Prior12MonthNonProductiveFTEs { get; set; }       // grid shows FormatGRV3(...)
    public double? Prior12MonthEmployedPaidFTEs { get; set; }
    public double? Prior12MonthTotalFTEs { get; set; }               // computed: paid + contract

    // -----------------------------------------------------------------------
    // Mapping: assign each DB value from the row to its Prior12Month property.
    // -----------------------------------------------------------------------

    /// <summary>Builds a prior-12-month summary from one DB row.</summary>
    public static LaborSummaryYearlyPrior12Month FromLaborMetricRow(LaborMetricRow row)
    {
        ArgumentNullException.ThrowIfNull(row);

        return new LaborSummaryYearlyPrior12Month
        {
            // Volume & productivity
            Prior12MonthAdmissions = row.PriorAdmissions,
            Prior12MonthAdjustedAdmissions = row.PriorAdjustedAdmissions,
            Prior12MonthPatientDays = row.PriorPatientDays,
            Prior12MonthAPD = row.PriorAPD,
            Prior12MonthERVisits = row.PriorERVisits,
            Prior12MonthOutpatientVisits = row.PriorOutpatientVisits,
            Prior12MonthOPFactor = row.PriorOPFactor,
            Prior12MonthALOS = row.PriorALOS,
            Prior12MonthEEOB = row.PrioEeob,
            Prior12MonthMHAA = row.PriorMHAA,

            // Labor cost & overtime
            Prior12MonthTotalSalariesAndWages = row.PriorTotalSalariesWages,
            Prior12MonthTotalContractLabor = row.PriorTotalContractLabor,
            Prior12MonthTotalLaborExpense = row.PriorTotalLaborExpense,
            Prior12MonthEmployedLaborRate = row.PriorEmployedLaborRate,
            Prior12MonthContractLaborRate = row.PriorContractLaborRate,
            Prior12MonthOvertimePremiumDollars = row.PriorOvertimePremiumDollars,
            Prior12MonthOvertimePercent = row.PriorOvertimePercent, // grid: FormatDec(...) at display
            Prior12MonthOvertimeFTEs = row.PriorOvertimeFTEs,    // grid: FormatGRV3(...) at display

            // Facility FTE summary
            Prior12MonthEmployedProductiveFTEs = row.PriorEmployedProductiveFTEs,
            Prior12MonthContractLaborPercent = row.PriorContractLaborPercent * 100,
            Prior12MonthContractFTEs = row.PriorContractFTEs,
            Prior12MonthTotalProductiveFTEs = row.PriorTotalProductiveFTEs, // grid: FormatGRV3(...) at display
            Prior12MonthNonProductivePercent = row.PriorEmployedNonProductivePercent,
            Prior12MonthNonProductiveFTEs = row.PriorNonProductiveFTEs,   // grid: FormatGRV3(...) at display
            Prior12MonthEmployedPaidFTEs = row.PriorEmployedPaidFTEs,
            // Grid computes this as a sum rather than reading a single column.
            Prior12MonthTotalFTEs = row.PriorEmployedPaidFTEs + row.PriorContractFTEs,
        };
    }

    /// <summary>Builds a prior-12-month summary for each DB row.</summary>
    public static IReadOnlyList<LaborSummaryYearlyPrior12Month> FromLaborMetricRows(
        IEnumerable<LaborMetricRow> rows)
    {
        ArgumentNullException.ThrowIfNull(rows);
        return rows.Select(FromLaborMetricRow).ToList();
    }

    public Dictionary<string, double?> ToLabeledValues() =>
        new(StringComparer.Ordinal)
        {
            ["Admissions"] = Prior12MonthAdmissions,
            ["Adjusted Admissions"] = Prior12MonthAdjustedAdmissions,
            ["Patient Days"] = Prior12MonthPatientDays,
            ["APD"] = Prior12MonthAPD,
            ["ER Visits"] = Prior12MonthERVisits,
            ["Outpatient Visits"] = Prior12MonthOutpatientVisits,
            ["OP Factor"] = Prior12MonthOPFactor,
            ["ALOS"] = Prior12MonthALOS,
            ["EEOB"] = Prior12MonthEEOB,
            ["MH/AA"] = Prior12MonthMHAA,
            ["Total Salaries & Wages ($000)"] = Prior12MonthTotalSalariesAndWages,
            ["Total Contract Labor  ($000)"] = Prior12MonthTotalContractLabor,
            ["Total Labor Expense  ($000)"] = Prior12MonthTotalLaborExpense,
            ["Employed Labor Rate"] = Prior12MonthEmployedLaborRate,
            ["Contract Labor Rate"] = Prior12MonthContractLaborRate,
            ["Overtime Premium Dollars"] = Prior12MonthOvertimePremiumDollars,
            ["Overtime %"] = Prior12MonthOvertimePercent,
            ["Overtime FTEs"] = Prior12MonthOvertimeFTEs,
            ["Employed (Productive) FTEs"] = Prior12MonthEmployedProductiveFTEs,
            ["Contract Labor %"] = Prior12MonthContractLaborPercent,
            ["Contract FTEs"] = Prior12MonthContractFTEs,
            ["Total Productive FTEs"] = Prior12MonthTotalProductiveFTEs,
            ["Employed Non-Productive %"] = Prior12MonthNonProductivePercent,
            ["Non-Productive FTEs"] = Prior12MonthNonProductiveFTEs,
            ["Employed (Paid) FTEs"] = Prior12MonthEmployedPaidFTEs,
            ["Total FTEs (Paid + Contract)"] = Prior12MonthTotalFTEs,
        };
}

