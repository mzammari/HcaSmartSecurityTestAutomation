﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation;

/// <summary>
/// Yearly percent-change summary. Each property is the % change from the prior
/// value to the current value for a metric, prefixed with "PercentChange".
///   % Change = ((Current - Previous) / Previous) * 100, rounded to 2 decimals.
/// Previous = Prior* column, Current = current-period *Total column.
/// </summary>
public class LaborSummaryYearlyPercentChange
{
    // ---- Volume & productivity --------------------------------------------
    public double? PercentChangeAdmissions { get; set; }
    public double? PercentChangeAdjustedAdmissions { get; set; }
    public double? PercentChangePatientDays { get; set; }
    public double? PercentChangeAPD { get; set; }
    public double? PercentChangeERVisits { get; set; }
    public double? PercentChangeOutpatientVisits { get; set; }
    public double? PercentChangeOPFactor { get; set; }
    public double? PercentChangeALOS { get; set; }
    public double? PercentChangeEEOB { get; set; }
    public double? PercentChangeMHAA { get; set; }

    // ---- Labor cost & overtime --------------------------------------------
    public double? PercentChangeTotalSalariesAndWages { get; set; }
    public double? PercentChangeTotalContractLabor { get; set; }
    public double? PercentChangeTotalLaborExpense { get; set; }
    public double? PercentChangeEmployedLaborRate { get; set; }
    public double? PercentChangeContractLaborRate { get; set; }
    public double? PercentChangeOvertimePremiumDollars { get; set; }
    public double? PercentChangeOvertimePercent { get; set; }
    public double? PercentChangeOvertimeFTEs { get; set; }

    // ---- Facility FTE summary ---------------------------------------------
    public double? PercentChangeEmployedProductiveFTEs { get; set; }
    public double? PercentChangeContractLaborPercent { get; set; }   // previous side scaled *100
    public double? PercentChangeContractFTEs { get; set; }
    public double? PercentChangeTotalProductiveFTEs { get; set; }
    public double? PercentChangeNonProductivePercent { get; set; }
    public double? PercentChangeNonProductiveFTEs { get; set; }
    public double? PercentChangeEmployedPaidFTEs { get; set; }
    public double? PercentChangeTotalFTEs { get; set; }

    // -----------------------------------------------------------------------
    // Mapping: compute each % change from the row's prior & current columns.
    // -----------------------------------------------------------------------

    /// <summary>Builds a percent-change summary from one DB row.</summary>
    public static LaborSummaryYearlyPercentChange FromLaborMetricRow(LaborMetricRow row)
    {
        ArgumentNullException.ThrowIfNull(row);

        return new LaborSummaryYearlyPercentChange
        {
            // Volume & productivity          
            PercentChangeAdmissions = PctChange(row.Admissions, row.PriorAdmissions),
            PercentChangeAdjustedAdmissions = PctChange(row.AAdmissions, row.PriorAdjustedAdmissions),
            PercentChangePatientDays = PctChange(row.PatientDays, row.PriorPatientDays),
            PercentChangeAPD = PctChange(row.APatientDays, row.PriorAPD),
            PercentChangeERVisits = PctChange(row.ERVisits, row.PriorERVisits),
            PercentChangeOutpatientVisits = PctChange(row.Outpatient, row.PriorOutpatientVisits),
            PercentChangeOPFactor = PctChange(row.OPFactorTotal, row.PriorOPFactor),
            PercentChangeALOS = PctChange(row.ALOSTotal, row.PriorALOS),
            PercentChangeEEOB = PctChange(row.EeobTotal, row.PrioEeob),
            PercentChangeMHAA = PctChange(row.MhAaTotal, row.PriorMHAA),

            // Labor cost & overtime
            PercentChangeTotalSalariesAndWages = PctChange(row.TotalSalariesAndWagesTotal, row.PriorTotalSalariesWages),
            PercentChangeTotalContractLabor = PctChange(row.TotalContractLaborDollarsTotal, row.PriorTotalContractLabor),
            PercentChangeTotalLaborExpense = PctChange(row.TotalLaborExpenseTotal, row.PriorTotalLaborExpense),
            PercentChangeEmployedLaborRate = PctChange(row.EmployedLaborRateTotal, row.PriorEmployedLaborRate),
            PercentChangeContractLaborRate = PctChange(row.ContractLaborRateTotal, row.PriorContractLaborRate),
            PercentChangeOvertimePremiumDollars = PctChange(row.OverTimePremiumDollarsTotal, row.PriorOvertimePremiumDollars),
            PercentChangeOvertimePercent = PctChange(row.OtPercentTotal, row.PriorOvertimePercent),
            PercentChangeOvertimeFTEs = PctChange(row.OTFTEsTotal, row.PriorOvertimeFTEs),

            // Facility FTE summary
            PercentChangeEmployedProductiveFTEs = PctChange(row.EmployedProductiveFtesTotal, row.PriorEmployedProductiveFTEs),
            PercentChangeContractLaborPercent = PctChange(row.ContractPercentTotal, row.PriorContractLaborPercent * 100),
            PercentChangeContractFTEs = PctChange(row.ContractFtesTotal, row.PriorContractFTEs),
            PercentChangeTotalProductiveFTEs = PctChange(row.TotalProductiveFtesTotal, row.PriorTotalProductiveFTEs),
            PercentChangeNonProductivePercent = PctChange(row.NonProductivePercentTotal, row.PriorEmployedNonProductivePercent),
            PercentChangeNonProductiveFTEs = PctChange(row.NonProductiveFtesTotal, row.PriorNonProductiveFTEs),
            PercentChangeEmployedPaidFTEs = PctChange(row.EmployedPaidFtesTotal, row.PriorEmployedPaidFTEs),
            PercentChangeTotalFTEs = PctChange(row.TotalFtesTotal, row.PriorTotalFTEsPaidContract),
        };
    }

    /// <summary>Builds a percent-change summary for each DB row.</summary>
    public static IReadOnlyList<LaborSummaryYearlyPercentChange> FromLaborMetricRows(
        IEnumerable<LaborMetricRow> rows)
    {
        ArgumentNullException.ThrowIfNull(rows);
        return rows.Select(FromLaborMetricRow).ToList();
    }

    /// <summary>
    /// ((current - previous) / previous) * 100, rounded to 2 decimals.
    /// Returns null when either side is missing or the previous value is zero
    /// (division by zero / undefined base).
    /// </summary>
    private static double? PctChange(double? current, double? previous)
    {
        if (current is null || previous is null || previous.Value == 0.0)
            return null;

        return Math.Round(
            (current.Value - previous.Value) / previous.Value * 100.0,
            2, MidpointRounding.AwayFromZero);
    }

    public Dictionary<string, double?> ToLabeledValues() =>
        new(StringComparer.Ordinal)
        {
            ["Admissions"] = PercentChangeAdmissions,
            ["Adjusted Admissions"] = PercentChangeAdjustedAdmissions,
            ["Patient Days"] = PercentChangePatientDays,
            ["APD"] = PercentChangeAPD,
            ["ER Visits"] = PercentChangeERVisits,
            ["Outpatient Visits"] = PercentChangeOutpatientVisits,
            ["OP Factor"] = PercentChangeOPFactor,
            ["ALOS"] = PercentChangeALOS,
            ["EEOB"] = PercentChangeEEOB,
            ["MH/AA"] = PercentChangeMHAA,
            ["Total Salaries & Wages ($000)"] = PercentChangeTotalSalariesAndWages,
            ["Total Contract Labor  ($000)"] = PercentChangeTotalContractLabor,
            ["Total Labor Expense  ($000)"] = PercentChangeTotalLaborExpense,
            ["Employed Labor Rate"] = PercentChangeEmployedLaborRate,
            ["Contract Labor Rate"] = PercentChangeContractLaborRate,
            ["Overtime Premium Dollars"] = PercentChangeOvertimePremiumDollars,
            ["Overtime %"] = PercentChangeOvertimePercent,
            ["Overtime FTEs"] = PercentChangeOvertimeFTEs,
            ["Employed (Productive) FTEs"] = PercentChangeEmployedProductiveFTEs,
            ["Contract Labor %"] = PercentChangeContractLaborPercent,
            ["Contract FTEs"] = PercentChangeContractFTEs,
            ["Total Productive FTEs"] = PercentChangeTotalProductiveFTEs,
            ["Employed Non-Productive %"] = PercentChangeNonProductivePercent,
            ["Non-Productive FTEs"] = PercentChangeNonProductiveFTEs,
            ["Employed (Paid) FTEs"] = PercentChangeEmployedPaidFTEs,
            ["Total FTEs (Paid + Contract)"] = PercentChangeTotalFTEs,
        };
}

