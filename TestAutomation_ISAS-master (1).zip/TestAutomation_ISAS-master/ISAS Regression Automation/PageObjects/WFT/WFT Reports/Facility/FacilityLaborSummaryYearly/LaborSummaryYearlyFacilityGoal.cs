﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation;

/// <summary>
/// Yearly facility-goal summary. Each property is a display metric from the
/// summary grid, prefixed with "FacilityGoal", populated from the matching
/// Facility*/BudgetGoal* column on a <see cref="LaborMetricRow"/>.
/// </summary>
public  class LaborSummaryYearlyFacilityGoal
{
    // ---- Volume & productivity --------------------------------------------
    public double? FacilityGoalAdmissions { get; set; }
    public double? FacilityGoalAdjustedAdmissions { get; set; }
    public double? FacilityGoalPatientDays { get; set; }
    public double? FacilityGoalAPD { get; set; }
    public double? FacilityGoalERVisits { get; set; }
    public double? FacilityGoalOutpatientVisits { get; set; }
    public double? FacilityGoalOPFactor { get; set; }
    public double? FacilityGoalALOS { get; set; }
    public double? FacilityGoalEEOB { get; set; }   // from BudgetGoalEeob
    public double? FacilityGoalMHAA { get; set; }    // from BudgetGoalMh

    // ---- Labor cost & overtime --------------------------------------------
    public double? FacilityGoalTotalSalariesAndWages { get; set; }   // ($000) — thousands
    public double? FacilityGoalTotalContractLabor { get; set; }      // ($000) — thousands
    public double? FacilityGoalTotalLaborExpense { get; set; }       // ($000) — thousands
    public double? FacilityGoalEmployedLaborRate { get; set; }       // raw rate; grid shows FormatGRV3(...)
    public double? FacilityGoalContractLaborRate { get; set; }
    public double? FacilityGoalOvertimePremiumDollars { get; set; }
    public double? FacilityGoalOvertimePercent { get; set; }
    public double? FacilityGoalOvertimeFTEs { get; set; }

    // ---- Facility FTE summary ---------------------------------------------
    public double? FacilityGoalEmployedProductiveFTEs { get; set; }
    public double? FacilityGoalContractLaborPercent { get; set; }    // source * 100
    public double? FacilityGoalContractFTEs { get; set; }
    public double? FacilityGoalTotalProductiveFTEs { get; set; }
    public double? FacilityGoalNonProductivePercent { get; set; }
    public double? FacilityGoalNonProductiveFTEs { get; set; }
    public double? FacilityGoalEmployedPaidFTEs { get; set; }
    public double? FacilityGoalTotalFTEs { get; set; }

    // -----------------------------------------------------------------------
    // Mapping: assign each DB value from the row to its FacilityGoal property.
    // -----------------------------------------------------------------------

    /// <summary>Builds a facility-goal summary from one DB row.</summary>
    public static LaborSummaryYearlyFacilityGoal FromLaborMetricRow(LaborMetricRow row)
    {
        ArgumentNullException.ThrowIfNull(row);

        return new LaborSummaryYearlyFacilityGoal
        {
            // Volume & productivity
            FacilityGoalAdmissions = row.FacilityAdmissions,
            FacilityGoalAdjustedAdmissions = row.FacilityAdjustedAdmissions,
            FacilityGoalPatientDays = row.FacilityPatientDays,
            FacilityGoalAPD = row.FacilityAPD,
            FacilityGoalERVisits = row.FacilityERVisits,
            FacilityGoalOutpatientVisits = row.FacilityOutpatientVisits,
            FacilityGoalOPFactor = row.FacilityOPFactor,
            FacilityGoalALOS = row.FacilityALOS,
            FacilityGoalEEOB = row.BudgetGoalEeob,
            FacilityGoalMHAA = row.BudgetGoalMh,

            // Labor cost & overtime
            FacilityGoalTotalSalariesAndWages = row.FacilityTotalSalariesWages,
            FacilityGoalTotalContractLabor = row.FacilityTotalContractLabor,
            FacilityGoalTotalLaborExpense = row.FacilityTotalLaborExpense,
            FacilityGoalEmployedLaborRate = row.FacilityEmployedLaborRate, // grid: FormatGRV3(...) at display
            FacilityGoalContractLaborRate = row.FacilityContractLaborRate,
            FacilityGoalOvertimePremiumDollars = row.FacilityOvertimePremiumDollars,
            FacilityGoalOvertimePercent = row.FacilityOvertimePercent,
            FacilityGoalOvertimeFTEs = row.FacilityOvertimeFTEs,

            // Facility FTE summary
            FacilityGoalEmployedProductiveFTEs = row.FacilityEmployedProductiveFTEs,
            FacilityGoalContractLaborPercent = row.FacilityContractLaborPercent * 100,
            FacilityGoalContractFTEs = row.FacilityContractFTEs,
            FacilityGoalTotalProductiveFTEs = row.FacilityTotalProductiveFTEs,
            FacilityGoalNonProductivePercent = row.FacilityEmployedNonProductivePercent,
            FacilityGoalNonProductiveFTEs = row.FacilityNonProductiveFTEs,
            FacilityGoalEmployedPaidFTEs = row.FacilityEmployedPaidFTEs,
            FacilityGoalTotalFTEs = row.FacilityTotalFTEsPaidContract,
        };
    }

    /// <summary>Builds a facility-goal summary for each DB row.</summary>
    public static IReadOnlyList<LaborSummaryYearlyFacilityGoal> FromLaborMetricRows(
        IEnumerable<LaborMetricRow> rows)
    {
        ArgumentNullException.ThrowIfNull(rows);
        return rows.Select(FromLaborMetricRow).ToList();
    }

    /// <summary>DB "Facility Goal" column keyed by the exact Excel metric labels.</summary>
    public Dictionary<string, double?> ToLabeledValues() =>
        new(StringComparer.Ordinal)
        {
            ["Admissions"] = FacilityGoalAdmissions,
            ["Adjusted Admissions"] = FacilityGoalAdjustedAdmissions,
            ["Patient Days"] = FacilityGoalPatientDays,
            ["APD"] = FacilityGoalAPD,
            ["ER Visits"] = FacilityGoalERVisits,
            ["Outpatient Visits"] = FacilityGoalOutpatientVisits,
            ["OP Factor"] = FacilityGoalOPFactor,
            ["ALOS"] = FacilityGoalALOS,
            ["EEOB"] = FacilityGoalEEOB,
            ["MH/AA"] = FacilityGoalMHAA,
            ["Total Salaries & Wages ($000)"] = FacilityGoalTotalSalariesAndWages,
            ["Total Contract Labor  ($000)"] = FacilityGoalTotalContractLabor,   // double space
            ["Total Labor Expense  ($000)"] = FacilityGoalTotalLaborExpense,    // double space
            ["Employed Labor Rate"] = FacilityGoalEmployedLaborRate,
            ["Contract Labor Rate"] = FacilityGoalContractLaborRate,
            ["Overtime Premium Dollars"] = FacilityGoalOvertimePremiumDollars,
            ["Overtime %"] = FacilityGoalOvertimePercent,
            ["Overtime FTEs"] = FacilityGoalOvertimeFTEs,
            ["Employed (Productive) FTEs"] = FacilityGoalEmployedProductiveFTEs,
            ["Contract Labor %"] = FacilityGoalContractLaborPercent,
            ["Contract FTEs"] = FacilityGoalContractFTEs,
            ["Total Productive FTEs"] = FacilityGoalTotalProductiveFTEs,
            ["Employed Non-Productive %"] = FacilityGoalNonProductivePercent,
            ["Non-Productive FTEs"] = FacilityGoalNonProductiveFTEs,
            ["Employed (Paid) FTEs"] = FacilityGoalEmployedPaidFTEs,
            ["Total FTEs (Paid + Contract)"] = FacilityGoalTotalFTEs,
        };
}

