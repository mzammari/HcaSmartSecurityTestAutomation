﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FacilityLaborSummaryYearlyExcel
    {

        public static Dictionary<string, Dictionary<string, double>> getFacilityLaborSummaryYearlyExcelData(string fileLocation, List<string> metrics, List<string> columns)
        {
            var excelData = ExcelParser.ParseExcel(fileLocation, metrics, columns);
            // Employed (Productive) FTEs
            var EmployedProductiveFTEs_Forecast = excelData["Employed (Productive) FTEs"]["Forecast"];
            var EmployedProductiveFTEs_FacilityGoal = excelData["Employed (Productive) FTEs"]["Facility Goal"];
            var EmployedProductiveFTEs_Prior12Mon = excelData["Employed (Productive) FTEs"]["Prior 12 Mon"];
            var EmployedProductiveFTEs_PercentageChange = excelData["Employed (Productive) FTEs"]["% Change"];

            // Contract Labor %
            var ContractLaborPercentage_Forecast = excelData["Contract Labor %"]["Forecast"];
            var ContractLaborPercentage_FacilityGoal = excelData["Contract Labor %"]["Facility Goal"];
            var ContractLaborPercentage_Prior12Mon = excelData["Contract Labor %"]["Prior 12 Mon"];
            var ContractLaborPercentage_PercentageChange = excelData["Contract Labor %"]["% Change"];

            // Contract FTEs
            var ContractFTEs_Forecast = excelData["Contract FTEs"]["Forecast"];
            var ContractFTEs_FacilityGoal = excelData["Contract FTEs"]["Facility Goal"];
            var ContractFTEs_Prior12Mon = excelData["Contract FTEs"]["Prior 12 Mon"];
            var ContractFTEs_PercentageChange = excelData["Contract FTEs"]["% Change"];

            // Total Productive FTEs
            var TotalProductiveFTEs_Forecast = excelData["Total Productive FTEs"]["Forecast"];
            var TotalProductiveFTEs_FacilityGoal = excelData["Total Productive FTEs"]["Facility Goal"];
            var TotalProductiveFTEs_Prior12Mon = excelData["Total Productive FTEs"]["Prior 12 Mon"];
            var TotalProductiveFTEs_PercentageChange = excelData["Total Productive FTEs"]["% Change"];

            // Employed Non-Productive %
            var EmployedNonProductivePercentage_Forecast = excelData["Employed Non-Productive %"]["Forecast"];
            var EmployedNonProductivePercentage_FacilityGoal = excelData["Employed Non-Productive %"]["Facility Goal"];
            var EmployedNonProductivePercentage_Prior12Mon = excelData["Employed Non-Productive %"]["Prior 12 Mon"];
            var EmployedNonProductivePercentage_PercentageChange = excelData["Employed Non-Productive %"]["% Change"];

            // Non-Productive FTEs
            var NonProductiveFTEs_Forecast = excelData["Non-Productive FTEs"]["Forecast"];
            var NonProductiveFTEs_FacilityGoal = excelData["Non-Productive FTEs"]["Facility Goal"];
            var NonProductiveFTEs_Prior12Mon = excelData["Non-Productive FTEs"]["Prior 12 Mon"];
            var NonProductiveFTEs_PercentageChange = excelData["Non-Productive FTEs"]["% Change"];

            // Employed (Paid) FTEs
            var EmployedPaidFTEs_Forecast = excelData["Employed (Paid) FTEs"]["Forecast"];
            var EmployedPaidFTEs_FacilityGoal = excelData["Employed (Paid) FTEs"]["Facility Goal"];
            var EmployedPaidFTEs_Prior12Mon = excelData["Employed (Paid) FTEs"]["Prior 12 Mon"];
            var EmployedPaidFTEs_PercentageChange = excelData["Employed (Paid) FTEs"]["% Change"];

            // Total FTEs (Paid + Contract)
            var TotalFTEsPaidPlusContract_Forecast = excelData["Total FTEs (Paid + Contract)"]["Forecast"];
            var TotalFTEsPaidPlusContract_FacilityGoal = excelData["Total FTEs (Paid + Contract)"]["Facility Goal"];
            var TotalFTEsPaidPlusContract_Prior12Mon = excelData["Total FTEs (Paid + Contract)"]["Prior 12 Mon"];
            var TotalFTEsPaidPlusContract_PercentageChange = excelData["Total FTEs (Paid + Contract)"]["% Change"];

            // Total Salaries & Wages ($000)
            var TotalSalariesAndWagesDollar000_Forecast = excelData["Total Salaries & Wages ($000)"]["Forecast"];
            var TotalSalariesAndWagesDollar000_FacilityGoal = excelData["Total Salaries & Wages ($000)"]["Facility Goal"];
            var TotalSalariesAndWagesDollar000_Prior12Mon = excelData["Total Salaries & Wages ($000)"]["Prior 12 Mon"];
            var TotalSalariesAndWagesDollar000_PercentageChange = excelData["Total Salaries & Wages ($000)"]["% Change"];

            // Total Contract Labor  ($000)
            var TotalContractLaborDollar000_Forecast = excelData["Total Contract Labor  ($000)"]["Forecast"];
            var TotalContractLaborDollar000_FacilityGoal = excelData["Total Contract Labor  ($000)"]["Facility Goal"];
            var TotalContractLaborDollar000_Prior12Mon = excelData["Total Contract Labor  ($000)"]["Prior 12 Mon"];
            var TotalContractLaborDollar000_PercentageChange = excelData["Total Contract Labor  ($000)"]["% Change"];

            // Total Labor Expense  ($000)
            var TotalLaborExpenseDollar000_Forecast = excelData["Total Labor Expense  ($000)"]["Forecast"];
            var TotalLaborExpenseDollar000_FacilityGoal = excelData["Total Labor Expense  ($000)"]["Facility Goal"];
            var TotalLaborExpenseDollar000_Prior12Mon = excelData["Total Labor Expense  ($000)"]["Prior 12 Mon"];
            var TotalLaborExpenseDollar000_PercentageChange = excelData["Total Labor Expense  ($000)"]["% Change"];

            // Employed Labor Rate
            var EmployedLaborRate_Forecast = excelData["Employed Labor Rate"]["Forecast"];
            var EmployedLaborRate_FacilityGoal = excelData["Employed Labor Rate"]["Facility Goal"];
            var EmployedLaborRate_Prior12Mon = excelData["Employed Labor Rate"]["Prior 12 Mon"];
            var EmployedLaborRate_PercentageChange = excelData["Employed Labor Rate"]["% Change"];

            // Contract Labor Rate
            var ContractLaborRate_Forecast = excelData["Contract Labor Rate"]["Forecast"];
            var ContractLaborRate_FacilityGoal = excelData["Contract Labor Rate"]["Facility Goal"];
            var ContractLaborRate_Prior12Mon = excelData["Contract Labor Rate"]["Prior 12 Mon"];
            var ContractLaborRate_PercentageChange = excelData["Contract Labor Rate"]["% Change"];

            // Overtime Premium Dollars
            var OvertimePremiumDollars_Forecast = excelData["Overtime Premium Dollars"]["Forecast"];
            var OvertimePremiumDollars_FacilityGoal = excelData["Overtime Premium Dollars"]["Facility Goal"];
            var OvertimePremiumDollars_Prior12Mon = excelData["Overtime Premium Dollars"]["Prior 12 Mon"];
            var OvertimePremiumDollars_PercentageChange = excelData["Overtime Premium Dollars"]["% Change"];

            // Overtime %
            var OvertimePercentage_Forecast = excelData["Overtime %"]["Forecast"];
            var OvertimePercentage_FacilityGoal = excelData["Overtime %"]["Facility Goal"];
            var OvertimePercentage_Prior12Mon = excelData["Overtime %"]["Prior 12 Mon"];
            var OvertimePercentage_PercentageChange = excelData["Overtime %"]["% Change"];

            // Overtime FTEs
            var OvertimeFTEs_Forecast = excelData["Overtime FTEs"]["Forecast"];
            var OvertimeFTEs_FacilityGoal = excelData["Overtime FTEs"]["Facility Goal"];
            var OvertimeFTEs_Prior12Mon = excelData["Overtime FTEs"]["Prior 12 Mon"];
            var OvertimeFTEs_PercentageChange = excelData["Overtime FTEs"]["% Change"];

            // Admissions
            var Admissions_Forecast = excelData["Admissions"]["Forecast"];
            var Admissions_FacilityGoal = excelData["Admissions"]["Facility Goal"];
            var Admissions_Prior12Mon = excelData["Admissions"]["Prior 12 Mon"];
            var Admissions_PercentageChange = excelData["Admissions"]["% Change"];

            // Adjusted Admissions
            var AdjustedAdmissions_Forecast = excelData["Adjusted Admissions"]["Forecast"];
            var AdjustedAdmissions_FacilityGoal = excelData["Adjusted Admissions"]["Facility Goal"];
            var AdjustedAdmissions_Prior12Mon = excelData["Adjusted Admissions"]["Prior 12 Mon"];
            var AdjustedAdmissions_PercentageChange = excelData["Adjusted Admissions"]["% Change"];

            // Patient Days
            var PatientDays_Forecast = excelData["Patient Days"]["Forecast"];
            var PatientDays_FacilityGoal = excelData["Patient Days"]["Facility Goal"];
            var PatientDays_Prior12Mon = excelData["Patient Days"]["Prior 12 Mon"];
            var PatientDays_PercentageChange = excelData["Patient Days"]["% Change"];

            // APD
            var APD_Forecast = excelData["APD"]["Forecast"];
            var APD_FacilityGoal = excelData["APD"]["Facility Goal"];
            var APD_Prior12Mon = excelData["APD"]["Prior 12 Mon"];
            var APD_PercentageChange = excelData["APD"]["% Change"];

            // ER Visits
            var ERVisits_Forecast = excelData["ER Visits"]["Forecast"];
            var ERVisits_FacilityGoal = excelData["ER Visits"]["Facility Goal"];
            var ERVisits_Prior12Mon = excelData["ER Visits"]["Prior 12 Mon"];
            var ERVisits_PercentageChange = excelData["ER Visits"]["% Change"];

            // Outpatient Visits
            var OutpatientVisits_Forecast = excelData["Outpatient Visits"]["Forecast"];
            var OutpatientVisits_FacilityGoal = excelData["Outpatient Visits"]["Facility Goal"];
            var OutpatientVisits_Prior12Mon = excelData["Outpatient Visits"]["Prior 12 Mon"];
            var OutpatientVisits_PercentageChange = excelData["Outpatient Visits"]["% Change"];

            // OP Factor
            var OPFactor_Forecast = excelData["OP Factor"]["Forecast"];
            var OPFactor_FacilityGoal = excelData["OP Factor"]["Facility Goal"];
            var OPFactor_Prior12Mon = excelData["OP Factor"]["Prior 12 Mon"];
            var OPFactor_PercentageChange = excelData["OP Factor"]["% Change"];

            // ALOS
            var ALOS_Forecast = excelData["ALOS"]["Forecast"];
            var ALOS_FacilityGoal = excelData["ALOS"]["Facility Goal"];
            var ALOS_Prior12Mon = excelData["ALOS"]["Prior 12 Mon"];
            var ALOS_PercentageChange = excelData["ALOS"]["% Change"];

            // EEOB
            var EEOB_Forecast = excelData["EEOB"]["Forecast"];
            var EEOB_FacilityGoal = excelData["EEOB"]["Facility Goal"];
            var EEOB_Prior12Mon = excelData["EEOB"]["Prior 12 Mon"];
            var EEOB_PercentageChange = excelData["EEOB"]["% Change"];

            // MH/AA
            var MHAA_Forecast = excelData["MH/AA"]["Forecast"];
            var MHAA_FacilityGoal = excelData["MH/AA"]["Facility Goal"];
            var MHAA_Prior12Mon = excelData["MH/AA"]["Prior 12 Mon"];
            var MHAA_PercentageChange = excelData["MH/AA"]["% Change"];

            return excelData;
        }

    }

    
    public class FacilityLaborSummaryYearlyExcelMetrics
        {
            // Employed (Productive) FTEs
            public double EmployedProductiveFTEs_Forecast { get; set; }
            public double EmployedProductiveFTEs_FacilityGoal { get; set; }
            public double EmployedProductiveFTEs_Prior12Mon { get; set; }
            public double EmployedProductiveFTEs_PercentageChange { get; set; }

            // Contract Labor %
            public double ContractLaborPercentage_Forecast { get; set; }
            public double ContractLaborPercentage_FacilityGoal { get; set; }
            public double ContractLaborPercentage_Prior12Mon { get; set; }
            public double ContractLaborPercentage_PercentageChange { get; set; }

            // Contract FTEs
            public double ContractFTEs_Forecast { get; set; }
            public double ContractFTEs_FacilityGoal { get; set; }
            public double ContractFTEs_Prior12Mon { get; set; }
            public double ContractFTEs_PercentageChange { get; set; }

            // Total Productive FTEs
            public double TotalProductiveFTEs_Forecast { get; set; }
            public double TotalProductiveFTEs_FacilityGoal { get; set; }
            public double TotalProductiveFTEs_Prior12Mon { get; set; }
            public double TotalProductiveFTEs_PercentageChange { get; set; }

            // Employed Non-Productive %
            public double EmployedNonProductivePercentage_Forecast { get; set; }
            public double EmployedNonProductivePercentage_FacilityGoal { get; set; }
            public double EmployedNonProductivePercentage_Prior12Mon { get; set; }
            public double EmployedNonProductivePercentage_PercentageChange { get; set; }

            // Non-Productive FTEs
            public double NonProductiveFTEs_Forecast { get; set; }
            public double NonProductiveFTEs_FacilityGoal { get; set; }
            public double NonProductiveFTEs_Prior12Mon { get; set; }
            public double NonProductiveFTEs_PercentageChange { get; set; }

            // Employed (Paid) FTEs
            public double EmployedPaidFTEs_Forecast { get; set; }
            public double EmployedPaidFTEs_FacilityGoal { get; set; }
            public double EmployedPaidFTEs_Prior12Mon { get; set; }
            public double EmployedPaidFTEs_PercentageChange { get; set; }

            // Total FTEs (Paid + Contract)
            public double TotalFTEsPaidPlusContract_Forecast { get; set; }
            public double TotalFTEsPaidPlusContract_FacilityGoal { get; set; }
            public double TotalFTEsPaidPlusContract_Prior12Mon { get; set; }
            public double TotalFTEsPaidPlusContract_PercentageChange { get; set; }

            // Total Salaries & Wages ($000)
            public double TotalSalariesAndWagesDollar000_Forecast { get; set; }
            public double TotalSalariesAndWagesDollar000_FacilityGoal { get; set; }
            public double TotalSalariesAndWagesDollar000_Prior12Mon { get; set; }
            public double TotalSalariesAndWagesDollar000_PercentageChange { get; set; }

            // Total Contract Labor  ($000)
            public double TotalContractLaborDollar000_Forecast { get; set; }
            public double TotalContractLaborDollar000_FacilityGoal { get; set; }
            public double TotalContractLaborDollar000_Prior12Mon { get; set; }
            public double TotalContractLaborDollar000_PercentageChange { get; set; }

            // Total Labor Expense  ($000)
            public double TotalLaborExpenseDollar000_Forecast { get; set; }
            public double TotalLaborExpenseDollar000_FacilityGoal { get; set; }
            public double TotalLaborExpenseDollar000_Prior12Mon { get; set; }
            public double TotalLaborExpenseDollar000_PercentageChange { get; set; }

            // Employed Labor Rate
            public double EmployedLaborRate_Forecast { get; set; }
            public double EmployedLaborRate_FacilityGoal { get; set; }
            public double EmployedLaborRate_Prior12Mon { get; set; }
            public double EmployedLaborRate_PercentageChange { get; set; }

            // Contract Labor Rate
            public double ContractLaborRate_Forecast { get; set; }
            public double ContractLaborRate_FacilityGoal { get; set; }
            public double ContractLaborRate_Prior12Mon { get; set; }
            public double ContractLaborRate_PercentageChange { get; set; }

            // Overtime Premium Dollars
            public double OvertimePremiumDollars_Forecast { get; set; }
            public double OvertimePremiumDollars_FacilityGoal { get; set; }
            public double OvertimePremiumDollars_Prior12Mon { get; set; }
            public double OvertimePremiumDollars_PercentageChange { get; set; }

            // Overtime %
            public double OvertimePercentage_Forecast { get; set; }
            public double OvertimePercentage_FacilityGoal { get; set; }
            public double OvertimePercentage_Prior12Mon { get; set; }
            public double OvertimePercentage_PercentageChange { get; set; }

            // Overtime FTEs
            public double OvertimeFTEs_Forecast { get; set; }
            public double OvertimeFTEs_FacilityGoal { get; set; }
            public double OvertimeFTEs_Prior12Mon { get; set; }
            public double OvertimeFTEs_PercentageChange { get; set; }

            // Admissions
            public double Admissions_Forecast { get; set; }
            public double Admissions_FacilityGoal { get; set; }
            public double Admissions_Prior12Mon { get; set; }
            public double Admissions_PercentageChange { get; set; }

            // Adjusted Admissions
            public double AdjustedAdmissions_Forecast { get; set; }
            public double AdjustedAdmissions_FacilityGoal { get; set; }
            public double AdjustedAdmissions_Prior12Mon { get; set; }
            public double AdjustedAdmissions_PercentageChange { get; set; }

            // Patient Days
            public double PatientDays_Forecast { get; set; }
            public double PatientDays_FacilityGoal { get; set; }
            public double PatientDays_Prior12Mon { get; set; }
            public double PatientDays_PercentageChange { get; set; }

            // APD
            public double APD_Forecast { get; set; }
            public double APD_FacilityGoal { get; set; }
            public double APD_Prior12Mon { get; set; }
            public double APD_PercentageChange { get; set; }

            // ER Visits
            public double ERVisits_Forecast { get; set; }
            public double ERVisits_FacilityGoal { get; set; }
            public double ERVisits_Prior12Mon { get; set; }
            public double ERVisits_PercentageChange { get; set; }

            // Outpatient Visits
            public double OutpatientVisits_Forecast { get; set; }
            public double OutpatientVisits_FacilityGoal { get; set; }
            public double OutpatientVisits_Prior12Mon { get; set; }
            public double OutpatientVisits_PercentageChange { get; set; }

            // OP Factor
            public double OPFactor_Forecast { get; set; }
            public double OPFactor_FacilityGoal { get; set; }
            public double OPFactor_Prior12Mon { get; set; }
            public double OPFactor_PercentageChange { get; set; }

            // ALOS
            public double ALOS_Forecast { get; set; }
            public double ALOS_FacilityGoal { get; set; }
            public double ALOS_Prior12Mon { get; set; }
            public double ALOS_PercentageChange { get; set; }

            // EEOB
            public double EEOB_Forecast { get; set; }
            public double EEOB_FacilityGoal { get; set; }
            public double EEOB_Prior12Mon { get; set; }
            public double EEOB_PercentageChange { get; set; }

            // MH/AA
            public double MHAA_Forecast { get; set; }
            public double MHAA_FacilityGoal { get; set; }
            public double MHAA_Prior12Mon { get; set; }
            public double MHAA_PercentageChange { get; set; }

        }
   

}
