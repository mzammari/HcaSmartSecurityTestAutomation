﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FacilityLaborSummaryMonthlyDB
    {
        /// <summary>
        /// Runs a SQL query and pivots the result into Dictionary&lt;metric, Dictionary&lt;month, value&gt;&gt;.
        /// 
        /// Usage:
        ///   var dbColumns = ExcelParser.ToList("EmployedProductiveFtes, ContractFTEs, TotalProductiveFtes");
        ///   var dbData = DbQueryParser.ExecuteAndPivot(connectionString, sqlQuery, dbColumns);
        ///   double val = dbData["ContractFTEs"]["Feb"];  // 0
        /// </summary>
        public static Dictionary<string, Dictionary<string, double>> ExecuteAndPivot(
            string sqlQuery,
            List<string> metricColumns,
            string monthColumn = "MonthName")
        {
            string DB = RunData.DatabaseName;
            string sServerName = RunData.ServerName;
            string connectionString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";

            var result = new Dictionary<string, Dictionary<string, double>>(StringComparer.OrdinalIgnoreCase);

            foreach (var metric in metricColumns)
                result[metric] = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

            using var conn = new SqlConnection(connectionString);
            conn.Open();

            using var cmd = new SqlCommand(sqlQuery, conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string month = reader[monthColumn]?.ToString()?.Trim();
                if (string.IsNullOrWhiteSpace(month)) continue;

                foreach (var metric in metricColumns)
                {
                    try
                    {
                        var val = reader[metric];
                        result[metric][month] = val == DBNull.Value ? 0.0 : Convert.ToDouble(val);
                    }
                    catch { result[metric][month] = 0.0; }
                }
            }

            return result;
        }
    }

}
