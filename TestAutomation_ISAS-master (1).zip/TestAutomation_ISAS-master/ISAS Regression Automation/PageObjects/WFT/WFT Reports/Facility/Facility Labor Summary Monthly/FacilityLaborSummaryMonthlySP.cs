﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FacilityLaborSummaryMonthlySP
    {
        public static string getFacilityLaborSummaryMonthlySP()
        {
            RunData.PlanID = AdminPlanDetail.getPlanID();
            return ($"--*************************************" + Environment.NewLine +
            $"-- Warmup Script" + Environment.NewLine +
            $"-- EXEC [rpt_GetLaborSumMonthlyFacility] {RunData.PlanID}" + Environment.NewLine +
            "--" + Environment.NewLine +
            "--*************************************" + Environment.NewLine +
            "declare		@PlanID BIGINT=253173932" + Environment.NewLine +
            "BEGIN" + Environment.NewLine +
            "IF EXISTS(	SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
            "WHERE ID = OBJECT_ID(N'tempdb..#TempMonthlyValue') 	)" + Environment.NewLine +
            "BEGIN" + Environment.NewLine +
            "DROP TABLE #TempMonthlyValue;" + Environment.NewLine +
            "END;" + Environment.NewLine +
            "IF EXISTS(	SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
            "WHERE ID = OBJECT_ID(N'tempdb..#TempAllValue') 	)" + Environment.NewLine +
            "BEGIN" + Environment.NewLine +
            "DROP TABLE #TempAllValue;" + Environment.NewLine +
            "END;" + Environment.NewLine +
            "IF EXISTS(	SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
            "WHERE ID = OBJECT_ID(N'tempdb..#TempFacStatValue') 	)" + Environment.NewLine +
            "BEGIN" + Environment.NewLine +
            "DROP TABLE #TempFacStatValue;" + Environment.NewLine +
            "END;" + Environment.NewLine +
            "-- Variable to store Second Hightest and Second Lowest value" + Environment.NewLine +
            "declare @Max_EmployedProductiveFtes decimal(19,5)," + Environment.NewLine +
            "@Max_ContractLaborPercent decimal(19,5)," + Environment.NewLine +
            "@Max_ContractFtes decimal(19,5)," + Environment.NewLine +
            "@Max_TotalProductiveFtes decimal(19,5)," + Environment.NewLine +
            "@Max_NonProductivePercent decimal(19,5)," + Environment.NewLine +
            "@Max_NonProductiveFtes decimal(19,5)," + Environment.NewLine +
            "@Max_EmployedPaidFtes decimal(19,5)," + Environment.NewLine +
            "@Max_TotalFtes decimal(19,5)," + Environment.NewLine +
            "@Max_TotalSalariesAndWages decimal(19,5)," + Environment.NewLine +
            "@Max_TotalContractLaborDollars decimal(19,5)," + Environment.NewLine +
            "@Max_TotalLaborExpense decimal(19,5)," + Environment.NewLine +
            "@Max_EmployedLaborRate decimal(19,5)," + Environment.NewLine +
            "@Max_ContractLaborRate decimal(19,5)," + Environment.NewLine +
            "@Max_OverTimePremiumDollars decimal(19,5)," + Environment.NewLine +
            "@Max_OtPercent decimal(19,5)," + Environment.NewLine +
            "@Max_OtFte decimal(19,5)," + Environment.NewLine +
            "@Max_Eeob  decimal(19,5)," + Environment.NewLine +
            "@Max_MhAa decimal(19,5)" + Environment.NewLine +
            "declare @Min_EmployedProductiveFtes decimal(19,5)," + Environment.NewLine +
            "@Min_ContractLaborPercent decimal(19,5)," + Environment.NewLine +
            "@Min_ContractFtes decimal(19,5)," + Environment.NewLine +
            "@Min_TotalProductiveFtes decimal(19,5)," + Environment.NewLine +
            "@Min_NonProductivePercent decimal(19,5)," + Environment.NewLine +
            "@Min_NonProductiveFtes decimal(19,5)," + Environment.NewLine +
            "@Min_EmployedPaidFtes decimal(19,5)," + Environment.NewLine +
            "@Min_TotalFtes decimal(19,5)," + Environment.NewLine +
            "@Min_TotalSalariesAndWages decimal(19,5)," + Environment.NewLine +
            "@Min_TotalContractLaborDollars decimal(19,5)," + Environment.NewLine +
            "@Min_TotalLaborExpense decimal(19,5)," + Environment.NewLine +
            "@Min_EmployedLaborRate decimal(19,5)," + Environment.NewLine +
            "@Min_ContractLaborRate decimal(19,5)," + Environment.NewLine +
            "@Min_OverTimePremiumDollars decimal(19,5)," + Environment.NewLine +
            "@Min_OtPercent decimal(19,5)," + Environment.NewLine +
            "@Min_OtFte decimal(19,5)," + Environment.NewLine +
            "@Min_Eeob  decimal(19,5)," + Environment.NewLine +
            "@Min_MhAa decimal(19,5)" + Environment.NewLine +
            "declare @Max_Admissions decimal(19,5)," + Environment.NewLine +
            "@Max_AAdmissions decimal(19,5) ," + Environment.NewLine +
            "@Max_PatientDays decimal(19,5) ," + Environment.NewLine +
            "@Max_APatientDays decimal(19,5)," + Environment.NewLine +
            "@Max_ERVisits decimal(19,5) ," + Environment.NewLine +
            "@Max_Outpatient	 decimal(19,5)" + Environment.NewLine +
            "declare @Min_Admissions decimal(19,5)," + Environment.NewLine +
            "@Min_AAdmissions decimal(19,5) ," + Environment.NewLine +
            "@Min_PatientDays decimal(19,5) ," + Environment.NewLine +
            "@Min_APatientDays decimal(19,5)," + Environment.NewLine +
            "@Min_ERVisits decimal(19,5) ," + Environment.NewLine +
            "@Min_Outpatient	 decimal(19,5)" + Environment.NewLine +
            "CREATE TABLE #TempFacStatValue(" + Environment.NewLine +
            "MonthNum INT NOT NULL," + Environment.NewLine +
            "Admissions decimal(19,5) not null default(0.0)," + Environment.NewLine +
            "AAdmissions decimal(19,5) not null default(0.0)," + Environment.NewLine +
            "PatientDays decimal(19,5) not null default(0.0)," + Environment.NewLine +
            "APatientDays decimal(19,5) not null default(0.0)," + Environment.NewLine +
            "ERVisits decimal(19,5) not null default(0.0)," + Environment.NewLine +
            "Outpatient	 decimal(19,5) not null default(0.0)" + Environment.NewLine +
            ")" + Environment.NewLine +
            "--SELECT * FROM @TempFacStatValue" + Environment.NewLine +
            "SELECT PMV.[Id] as PlanMonthlyValue_ID" + Environment.NewLine +
            ",pmv.[Month] as MonthNum" + Environment.NewLine +
            ",CONVERT(VARCHAR(3),DateName( month , DateAdd( Month , pmv.Month ,0)-1)) as 'MonthName'" + Environment.NewLine +
            ",DAY(dateadd(mm,datediff(mm,-1,(DATEADD(Month, MONTH(GETDATE()) - 12 + pmv.Month, GETDATE()))),-1))   as  'DaysInMonth'" + Environment.NewLine +
            ",pmv.[EmployedProductiveFtes] as [EmployedProductiveFtes]" + Environment.NewLine +
            ",pmv.[ContractLaborPercent] as 'ContractPercent'" + Environment.NewLine +
            ",pmv.[ContractFtes] as 'ContractFTEs'" + Environment.NewLine +
            ",pmv.[TotalProductiveFtes]  as 'TotalProductiveFtes'" + Environment.NewLine +
            ",pmv.[NonProductivePercent] as 'NonProductivePercent'" + Environment.NewLine +
            ",pmv.[NonProductiveFtes] as [NonProductiveFtes]" + Environment.NewLine +
            ",pmv.[EmployedPaidFtes] as [EmployedPaidFtes]" + Environment.NewLine +
            ",pmv.[TotalFtes] as 'TotalFtes'" + Environment.NewLine +
            ",pmv.[TotalSalariesAndWages] as [TotalSalariesAndWages]" + Environment.NewLine +
            ",pmv.[TotalContractLaborDollars] as [TotalContractLaborDollars]" + Environment.NewLine +
            ",pmv.[TotalLaborExpense] as [TotalLaborExpense]" + Environment.NewLine +
            ",pmv.[EmployedLaborRate] as [EmployedLaborRate]" + Environment.NewLine +
            ",pmv.[ContactLaborRate] as [ContactLaborRate]" + Environment.NewLine +
            ",pmv.[OverTimePremiumDollars] as [OverTimePremiumDollars]" + Environment.NewLine +
            ",pmv.[OtPercent] as 'OtPercent'" + Environment.NewLine +
            ",pmv.[OtFte]  as 'OTFTEs'" + Environment.NewLine +
            ",pmv.[WftPlan_ID]" + Environment.NewLine +
            ",pmv.Eeob as Eeob" + Environment.NewLine +
            ",pmv.MhAa as MhAa" + Environment.NewLine +
            "INTO #TempMonthlyValue" + Environment.NewLine +
            "FROM [dbo].[WftPlanMonthlyValue] pmv INNER JOIN WftPlan p on pmv.WftPlan_Id= p.Id" + Environment.NewLine +
            "WHERE P.Id=@PlanID;" + Environment.NewLine +
            "------------------------------------------------------------------------------" + Environment.NewLine +
            "DECLARE @SubmissionID BIGINT;" + Environment.NewLine +
            "EXEC [rpt_GetSubmittedId]  @PlanID,  @SubmissionID=@SubmissionID  OUTPUT;" + Environment.NewLine +
            "IF (@SubmissionID is null)" + Environment.NewLine +
            "BEGIN" + Environment.NewLine +
            "INSERT INTO #TempFacStatValue(" + Environment.NewLine +
            "MonthNum," + Environment.NewLine +
            "Admissions," + Environment.NewLine +
            "AAdmissions," + Environment.NewLine +
            "PatientDays," + Environment.NewLine +
            "APatientDays," + Environment.NewLine +
            "ERVisits," + Environment.NewLine +
            "Outpatient" + Environment.NewLine +
            ")" + Environment.NewLine +
            "SELECT t2.[Month]" + Environment.NewLine +
            ",T2.Admissions" + Environment.NewLine +
            ",T3.AAdmissions" + Environment.NewLine +
            ",T4.PatientDays" + Environment.NewLine +
            ",T5.APatientDays" + Environment.NewLine +
            ",T6.ERVisits" + Environment.NewLine +
            ",T7.Outpatient" + Environment.NewLine +
            "FROM" + Environment.NewLine +
            "(SELECT BudgetValue as [Admissions],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '81' AND WF.WftPlan_ID = @PlanID) T2" + Environment.NewLine +
            "--ON T2.[Month] = T2.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [AAdmissions],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '334' AND WF.WftPlan_ID = @PlanID) T3" + Environment.NewLine +
            "ON T2.[Month] = T3.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [PatientDays],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '3' AND WF.WftPlan_ID = @PlanID) T4" + Environment.NewLine +
            "ON T2.[Month] = T4.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [APatientDays],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '1' AND WF.WftPlan_ID = @PlanID) T5" + Environment.NewLine +
            "ON T2.[Month] = T5.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [ERVisits],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '319' AND WF.WftPlan_ID = @PlanID) T6" + Environment.NewLine +
            "ON T2.[Month] = T6.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [Outpatient],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '320' AND WF.WftPlan_ID = @PlanID) T7" + Environment.NewLine +
            "ON T2.[Month] = T7.[Month]" + Environment.NewLine +
            "END" + Environment.NewLine +
            "ELSE" + Environment.NewLine +
            "BEGIN" + Environment.NewLine +
            "INSERT INTO #TempFacStatValue(" + Environment.NewLine +
            "MonthNum," + Environment.NewLine +
            "Admissions," + Environment.NewLine +
            "AAdmissions," + Environment.NewLine +
            "PatientDays," + Environment.NewLine +
            "APatientDays," + Environment.NewLine +
            "ERVisits," + Environment.NewLine +
            "Outpatient" + Environment.NewLine +
            ")" + Environment.NewLine +
            "SELECT t2.[Month]" + Environment.NewLine +
            ",T2.Admissions" + Environment.NewLine +
            ",T3.AAdmissions" + Environment.NewLine +
            ",T4.PatientDays" + Environment.NewLine +
            ",T5.APatientDays" + Environment.NewLine +
            ",T6.ERVisits" + Environment.NewLine +
            ",T7.Outpatient" + Environment.NewLine +
            "FROM" + Environment.NewLine +
            "--(SELECT HistoricalValue as [Admissions], [Month]" + Environment.NewLine +
            "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
            "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
            "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
            "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
            "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
            "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '81' and S.Id = @SubmissionID) T2" + Environment.NewLine +
            "--ON T1.MonthNum = T2.[Month]" + Environment.NewLine +
            "(SELECT BudgetValue as [Admissions],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '81' AND WF.WftPlan_ID = @PlanID) T2" + Environment.NewLine +
            "--LEFT OUTER JOIN" + Environment.NewLine +
            "--(SELECT HistoricalValue as [AAdmissions], [Month]" + Environment.NewLine +
            "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
            "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
            "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
            "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
            "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
            "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '334' and S.Id = @SubmissionID) T3" + Environment.NewLine +
            "-- ON T2.[Month] = T3.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [AAdmissions],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '334' AND WF.WftPlan_ID = @PlanID) T3" + Environment.NewLine +
            "ON T2.[Month] = T3.[Month]" + Environment.NewLine +
            "--LEFT OUTER JOIN" + Environment.NewLine +
            "--(SELECT HistoricalValue as [PatientDays], [Month]" + Environment.NewLine +
            "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
            "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
            "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
            "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
            "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
            "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '3' and S.Id = @SubmissionID) T4" + Environment.NewLine +
            "-- ON T2.[Month] = T4.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [PatientDays],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '3' AND WF.WftPlan_ID = @PlanID) T4" + Environment.NewLine +
            "ON T2.[Month] = T4.[Month]" + Environment.NewLine +
            "--LEFT OUTER JOIN" + Environment.NewLine +
            "--(SELECT HistoricalValue as [APatientDays], [Month]" + Environment.NewLine +
            "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
            "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
            "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
            "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
            "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
            "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '1' and S.Id = @SubmissionID) T5" + Environment.NewLine +
            "-- ON T2.[Month] = T5.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [APatientDays],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '1' AND WF.WftPlan_ID = @PlanID) T5" + Environment.NewLine +
            "ON T2.[Month] = T5.[Month]" + Environment.NewLine +
            "--LEFT OUTER JOIN" + Environment.NewLine +
            "--(SELECT HistoricalValue as [ERVisits], [Month]" + Environment.NewLine +
            "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
            "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
            "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
            "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
            "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
            "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '319' and S.Id = @SubmissionID) T6" + Environment.NewLine +
            "-- ON T2.[Month] = T6.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [ERVisits],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '319' AND WF.WftPlan_ID = @PlanID) T6" + Environment.NewLine +
            "ON T2.[Month] = T6.[Month]" + Environment.NewLine +
            "--LEFT OUTER JOIN" + Environment.NewLine +
            "--(SELECT HistoricalValue as [Outpatient], [Month]" + Environment.NewLine +
            "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
            "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
            "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
            "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
            "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
            "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '320' and S.Id = @SubmissionID) T7" + Environment.NewLine +
            "-- ON T2.[Month] = T7.[Month]" + Environment.NewLine +
            "LEFT OUTER JOIN" + Environment.NewLine +
            "(SELECT BudgetValue as [Outpatient],[Month]" + Environment.NewLine +
            "FROM WftFacilityStatValue W" + Environment.NewLine +
            "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
            "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
            "WHERE FS.Code = '320' AND WF.WftPlan_ID = @PlanID) T7" + Environment.NewLine +
            "ON T2.[Month] = T7.[Month]" + Environment.NewLine +
            "END" + Environment.NewLine +
            "--SELECT * FROM #TempFacStatValue" + Environment.NewLine +
            "--SELECT * FROM #TempMonthlyValue order by EmployedProductiveFtes" + Environment.NewLine +
            "--- Get Second Highest and Second Lowest Value to do color coding for Top 2 and bottom 2 values" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue','EmployedProductiveFtes',1,2,@Max_EmployedProductiveFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'ContractPercent', 1,2, @Max_ContractLaborPercent out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'ContractFtes', 1 ,2, @Max_ContractFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalProductiveFtes', 1 ,2, @Max_TotalProductiveFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'NonProductivePercent', 1 ,2, @Max_NonProductivePercent out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'NonProductiveFtes', 1 ,2, @Max_NonProductiveFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'EmployedPaidFtes', 1 ,2, @Max_EmployedPaidFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalFtes', 1 ,2, @Max_TotalFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalSalariesAndWages', 1 ,2, @Max_TotalSalariesAndWages out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalContractLaborDollars', 1 ,2, @Max_TotalContractLaborDollars out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalLaborExpense', 1 ,2, @Max_TotalLaborExpense out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'EmployedLaborRate', 1 ,2, @Max_EmployedLaborRate out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'ContactLaborRate', 1 ,2, @Max_ContractLaborRate out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'OverTimePremiumDollars', 1 ,0, @Max_OverTimePremiumDollars out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'OtPercent', 1 ,2, @Max_OtPercent out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'OTFTEs ', 1 ,2, @Max_OtFte out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'Eeob', 1 ,3, @Max_Eeob out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'MhAa', 1 ,3, @Max_MhAa out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue','EmployedProductiveFtes', 0 ,2,@Min_EmployedProductiveFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'ContractPercent', 0 ,2,@Min_ContractLaborPercent out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'ContractFtes', 0 ,2,@Min_ContractFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalProductiveFtes', 0 ,2,@Min_TotalProductiveFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'NonProductivePercent', 0 ,2,@Min_NonProductivePercent out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'NonProductiveFtes', 0 ,2,@Min_NonProductiveFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'EmployedPaidFtes', 0 ,2,@Min_EmployedPaidFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalFtes', 0 ,2,@Min_TotalFtes out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalSalariesAndWages', 0 ,2,@Min_TotalSalariesAndWages out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalContractLaborDollars', 0 ,2,@Min_TotalContractLaborDollars out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'TotalLaborExpense', 0 ,2,@Min_TotalLaborExpense out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'EmployedLaborRate', 0 ,2,@Min_EmployedLaborRate out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'ContactLaborRate', 0 ,2,@Min_ContractLaborRate out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'OverTimePremiumDollars', 0 ,2,@Min_OverTimePremiumDollars out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'OtPercent', 0, 2,@Min_OtPercent out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'OTFTEs ', 0 ,2,@Min_OtFte out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'Eeob', 0 ,3, @Min_Eeob out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempMonthlyValue', 'MhAa', 0 ,3, @Min_MhAa out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'Admissions', 1 ,0, @Max_Admissions  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'AAdmissions', 1 ,0, @Max_AAdmissions  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'PatientDays', 1 ,0, @Max_PatientDays  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'APatientDays', 1 ,0, @Max_APatientDays  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'ERVisits', 1 ,0, @Max_ERVisits  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'Outpatient', 1 ,0, @Max_Outpatient	 out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'Admissions', 0 ,0, @MIN_Admissions  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'AAdmissions', 0 ,0, @Min_AAdmissions  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'PatientDays', 0 ,0, @Min_PatientDays  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'APatientDays', 0 ,0, @Min_APatientDays  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'ERVisits', 0 ,0, @Min_ERVisits  out" + Environment.NewLine +
            "exec [sp_GetTopNValue] '#TempFacStatValue', 'Outpatient', 0 ,0, @Min_Outpatient	 out" + Environment.NewLine +
            "SELECT" + Environment.NewLine +
            "pmv.MonthNum" + Environment.NewLine +
            ",pmv.[MonthName]" + Environment.NewLine +
            ",pmv.DaysInMonth" + Environment.NewLine +
            ",pmv.[EmployedProductiveFtes]" + Environment.NewLine +
            ",pmv.ContractPercent" + Environment.NewLine +
            ",pmv.[ContractFtes] AS ContractFTEs" + Environment.NewLine +
            ",pmv.[TotalProductiveFtes]" + Environment.NewLine +
            ",pmv.[NonProductivePercent]" + Environment.NewLine +
            ",pmv.[NonProductiveFtes]" + Environment.NewLine +
            ",pmv.[EmployedPaidFtes]" + Environment.NewLine +
            ",pmv.[TotalFtes]" + Environment.NewLine +
            ",pmv.[TotalSalariesAndWages]" + Environment.NewLine +
            ",pmv.[TotalContractLaborDollars]" + Environment.NewLine +
            ",pmv.[TotalLaborExpense]" + Environment.NewLine +
            ",pmv.[EmployedLaborRate]" + Environment.NewLine +
            ",pmv.[ContactLaborRate] AS ContractLaborRate" + Environment.NewLine +
            ",pmv.[OverTimePremiumDollars]" + Environment.NewLine +
            ",pmv.[OtPercent]" + Environment.NewLine +
            ",pmv.[OTFTEs]" + Environment.NewLine +
            ",pmv.Eeob" + Environment.NewLine +
            ",pmv.MhAa," + Environment.NewLine +
            "SV.Admissions," + Environment.NewLine +
            "SV.AAdmissions ," + Environment.NewLine +
            "sv.PatientDays ," + Environment.NewLine +
            "sv.APatientDays," + Environment.NewLine +
            "sv.ERVisits ," + Environment.NewLine +
            "sv.Outpatient," + Environment.NewLine +
            "@Max_EmployedProductiveFtes as Max_EmployedProductiveFtes ," + Environment.NewLine +
            "@Max_ContractLaborPercent as Max_ContractLaborPercent ," + Environment.NewLine +
            "@Max_ContractFtes  as Max_ContractFtes ," + Environment.NewLine +
            "@Max_TotalProductiveFtes  as Max_TotalProductiveFtes ," + Environment.NewLine +
            "@Max_NonProductivePercent  as Max_NonProductivePercent ," + Environment.NewLine +
            "@Max_NonProductiveFtes  as Max_NonProductiveFtes ," + Environment.NewLine +
            "@Max_EmployedPaidFtes  as Max_EmployedPaidFtes ," + Environment.NewLine +
            "@Max_TotalFtes  as Max_TotalFtes ," + Environment.NewLine +
            "@Max_TotalSalariesAndWages  as Max_TotalSalariesAndWages ," + Environment.NewLine +
            "@Max_TotalContractLaborDollars  as Max_TotalContractLaborDollars ," + Environment.NewLine +
            "@Max_TotalLaborExpense  as Max_TotalLaborExpense ," + Environment.NewLine +
            "@Max_EmployedLaborRate  as Max_EmployedLaborRate ," + Environment.NewLine +
            "@Max_ContractLaborRate  as Max_ContractLaborRate ," + Environment.NewLine +
            "@Max_OverTimePremiumDollars  as Max_OverTimePremiumDollars ," + Environment.NewLine +
            "@Max_OtPercent  as Max_OtPercent ," + Environment.NewLine +
            "@Max_OtFte as Max_OtFte," + Environment.NewLine +
            "@Max_Eeob  as Max_Eeob," + Environment.NewLine +
            "@Max_MhAa as Max_MhAa," + Environment.NewLine +
            "@Min_EmployedProductiveFtes  as Min_EmployedProductiveFtes ," + Environment.NewLine +
            "@Min_ContractLaborPercent  as Min_ContractLaborPercent ," + Environment.NewLine +
            "@Min_ContractFtes  as Min_ContractFtes ," + Environment.NewLine +
            "@Min_TotalProductiveFtes  as Min_TotalProductiveFtes ," + Environment.NewLine +
            "@Min_NonProductivePercent  as Min_NonProductivePercent ," + Environment.NewLine +
            "@Min_NonProductiveFtes  as Min_NonProductiveFtes ," + Environment.NewLine +
            "@Min_EmployedPaidFtes  as Min_EmployedPaidFtes ," + Environment.NewLine +
            "@Min_TotalFtes  as Min_TotalFtes ," + Environment.NewLine +
            "@Min_TotalSalariesAndWages  as Min_TotalSalariesAndWages ," + Environment.NewLine +
            "@Min_TotalContractLaborDollars  as Min_TotalContractLaborDollars ," + Environment.NewLine +
            "@Min_TotalLaborExpense  as Min_TotalLaborExpense ," + Environment.NewLine +
            "@Min_EmployedLaborRate  as Min_EmployedLaborRate ," + Environment.NewLine +
            "@Min_ContractLaborRate  as Min_ContractLaborRate ," + Environment.NewLine +
            "@Min_OverTimePremiumDollars  as Min_OverTimePremiumDollars ," + Environment.NewLine +
            "@Min_OtPercent  as Min_OtPercent ," + Environment.NewLine +
            "@Min_OtFte as Min_OtFte," + Environment.NewLine +
            "@Max_Admissions  as Max_Admissions ," + Environment.NewLine +
            "@Max_AAdmissions as Max_AAdmissions," + Environment.NewLine +
            "@Max_PatientDays as Max_PatientDays," + Environment.NewLine +
            "@Max_APatientDays  as Max_APatientDays ," + Environment.NewLine +
            "@Max_ERVisits as Max_ERVisits," + Environment.NewLine +
            "@Max_Outpatient as Max_Outpatient," + Environment.NewLine +
            "@Min_Admissions  as Min_Admissions ," + Environment.NewLine +
            "@Min_AAdmissions  as Min_AAdmissions ," + Environment.NewLine +
            "@Min_PatientDays  as Min_PatientDays ," + Environment.NewLine +
            "@Min_APatientDays  as Min_APatientDays ," + Environment.NewLine +
            "@Min_ERVisits  as Min_ERVisits ," + Environment.NewLine +
            "@Min_Outpatient as Min_Outpatient," + Environment.NewLine +
            "@Min_Eeob  as Min_Eeob," + Environment.NewLine +
            "@Min_MhAa as Min_MhAa" + Environment.NewLine +
            ",p.EmployedProductiveFtesTotal" + Environment.NewLine +
            ",p.ContractLaborPercentTotal as ContractPercentTotal" + Environment.NewLine +
            ",p.ContractFtesTotal" + Environment.NewLine +
            ",p.TotalProductiveFtesTotal" + Environment.NewLine +
            ",p.NonProductivePercentTotal" + Environment.NewLine +
            ",p.NonProductiveFtesTotal" + Environment.NewLine +
            ",p.EmployedPaidFtesTotal" + Environment.NewLine +
            ",p.TotalFtesTotal" + Environment.NewLine +
            ",p.TotalSalariesAndWagesTotal" + Environment.NewLine +
            ",p.TotalContractLaborDollarsTotal" + Environment.NewLine +
            ",p.TotalLaborExpenseTotal" + Environment.NewLine +
            ",p.EmployedLaborRateTotal" + Environment.NewLine +
            ",p.ContactLaborRateTotal AS ContractLaborRateTotal" + Environment.NewLine +
            ",p.OverTimePremiumDollarsTotal" + Environment.NewLine +
            ",p.OtPercentTotal" + Environment.NewLine +
            ",p.OTFTEsTotal" + Environment.NewLine +
            ",p.EeobTotal" + Environment.NewLine +
            ",p.MhAaTotal" + Environment.NewLine +
            "FROM #TempMonthlyValue PMV" + Environment.NewLine +
            "INNER JOIN #TempFacStatValue SV ON PMV.MonthNum = SV.MonthNum" + Environment.NewLine +
            "INNER JOIN WftPlan p on pmv.WftPlan_ID=p.Id" + Environment.NewLine +
            "END" 
            );
        }
    }
}
