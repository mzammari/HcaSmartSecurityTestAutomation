﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FacilityLaborSummaryMonthlyExcel
    {
        public static Dictionary<string, Dictionary<string, double>> getFacilityLaborSummaryMonthlyExcelData(string fileLocation, List<string> metrics, List<string> columns)
        {
            var excelData = ExcelParser.ParseExcel(fileLocation, metrics, columns);

            // Employed (Productive) FTEs
            var EmployedProductiveFTEs_Jan = excelData["Employed (Productive) FTEs"]["Jan"];
            var EmployedProductiveFTEs_Feb = excelData["Employed (Productive) FTEs"]["Feb"];
            var EmployedProductiveFTEs_Mar = excelData["Employed (Productive) FTEs"]["Mar"];
            var EmployedProductiveFTEs_Apr = excelData["Employed (Productive) FTEs"]["Apr"];
            var EmployedProductiveFTEs_May = excelData["Employed (Productive) FTEs"]["May"];
            var EmployedProductiveFTEs_Jun = excelData["Employed (Productive) FTEs"]["Jun"];
            var EmployedProductiveFTEs_Jul = excelData["Employed (Productive) FTEs"]["Jul"];
            var EmployedProductiveFTEs_Aug = excelData["Employed (Productive) FTEs"]["Aug"];
            var EmployedProductiveFTEs_Sep = excelData["Employed (Productive) FTEs"]["Sep"];
            var EmployedProductiveFTEs_Oct = excelData["Employed (Productive) FTEs"]["Oct"];
            var EmployedProductiveFTEs_Nov = excelData["Employed (Productive) FTEs"]["Nov"];
            var EmployedProductiveFTEs_Dec = excelData["Employed (Productive) FTEs"]["Dec"];
            var EmployedProductiveFTEs_Total = excelData["Employed (Productive) FTEs"]["Total"];

            // Contract Labor %
            var ContractLaborPercentage_Jan = excelData["Contract Labor %"]["Jan"];
            var ContractLaborPercentage_Feb = excelData["Contract Labor %"]["Feb"];
            var ContractLaborPercentage_Mar = excelData["Contract Labor %"]["Mar"];
            var ContractLaborPercentage_Apr = excelData["Contract Labor %"]["Apr"];
            var ContractLaborPercentage_May = excelData["Contract Labor %"]["May"];
            var ContractLaborPercentage_Jun = excelData["Contract Labor %"]["Jun"];
            var ContractLaborPercentage_Jul = excelData["Contract Labor %"]["Jul"];
            var ContractLaborPercentage_Aug = excelData["Contract Labor %"]["Aug"];
            var ContractLaborPercentage_Sep = excelData["Contract Labor %"]["Sep"];
            var ContractLaborPercentage_Oct = excelData["Contract Labor %"]["Oct"];
            var ContractLaborPercentage_Nov = excelData["Contract Labor %"]["Nov"];
            var ContractLaborPercentage_Dec = excelData["Contract Labor %"]["Dec"];
            var ContractLaborPercentage_Total = excelData["Contract Labor %"]["Total"];

            // Contract FTEs
            var ContractFTEs_Jan = excelData["Contract FTEs"]["Jan"];
            var ContractFTEs_Feb = excelData["Contract FTEs"]["Feb"];
            var ContractFTEs_Mar = excelData["Contract FTEs"]["Mar"];
            var ContractFTEs_Apr = excelData["Contract FTEs"]["Apr"];
            var ContractFTEs_May = excelData["Contract FTEs"]["May"];
            var ContractFTEs_Jun = excelData["Contract FTEs"]["Jun"];
            var ContractFTEs_Jul = excelData["Contract FTEs"]["Jul"];
            var ContractFTEs_Aug = excelData["Contract FTEs"]["Aug"];
            var ContractFTEs_Sep = excelData["Contract FTEs"]["Sep"];
            var ContractFTEs_Oct = excelData["Contract FTEs"]["Oct"];
            var ContractFTEs_Nov = excelData["Contract FTEs"]["Nov"];
            var ContractFTEs_Dec = excelData["Contract FTEs"]["Dec"];
            var ContractFTEs_Total = excelData["Contract FTEs"]["Total"];

            // Total Productive FTEs
            var TotalProductiveFTEs_Jan = excelData["Total Productive FTEs"]["Jan"];
            var TotalProductiveFTEs_Feb = excelData["Total Productive FTEs"]["Feb"];
            var TotalProductiveFTEs_Mar = excelData["Total Productive FTEs"]["Mar"];
            var TotalProductiveFTEs_Apr = excelData["Total Productive FTEs"]["Apr"];
            var TotalProductiveFTEs_May = excelData["Total Productive FTEs"]["May"];
            var TotalProductiveFTEs_Jun = excelData["Total Productive FTEs"]["Jun"];
            var TotalProductiveFTEs_Jul = excelData["Total Productive FTEs"]["Jul"];
            var TotalProductiveFTEs_Aug = excelData["Total Productive FTEs"]["Aug"];
            var TotalProductiveFTEs_Sep = excelData["Total Productive FTEs"]["Sep"];
            var TotalProductiveFTEs_Oct = excelData["Total Productive FTEs"]["Oct"];
            var TotalProductiveFTEs_Nov = excelData["Total Productive FTEs"]["Nov"];
            var TotalProductiveFTEs_Dec = excelData["Total Productive FTEs"]["Dec"];
            var TotalProductiveFTEs_Total = excelData["Total Productive FTEs"]["Total"];

            // Non-Productive %
            var NonProductivePercentage_Jan = excelData["Non-Productive %"]["Jan"];
            var NonProductivePercentage_Feb = excelData["Non-Productive %"]["Feb"];
            var NonProductivePercentage_Mar = excelData["Non-Productive %"]["Mar"];
            var NonProductivePercentage_Apr = excelData["Non-Productive %"]["Apr"];
            var NonProductivePercentage_May = excelData["Non-Productive %"]["May"];
            var NonProductivePercentage_Jun = excelData["Non-Productive %"]["Jun"];
            var NonProductivePercentage_Jul = excelData["Non-Productive %"]["Jul"];
            var NonProductivePercentage_Aug = excelData["Non-Productive %"]["Aug"];
            var NonProductivePercentage_Sep = excelData["Non-Productive %"]["Sep"];
            var NonProductivePercentage_Oct = excelData["Non-Productive %"]["Oct"];
            var NonProductivePercentage_Nov = excelData["Non-Productive %"]["Nov"];
            var NonProductivePercentage_Dec = excelData["Non-Productive %"]["Dec"];
            var NonProductivePercentage_Total = excelData["Non-Productive %"]["Total"];

            // Non-Productive FTEs
            var NonProductiveFTEs_Jan = excelData["Non-Productive FTEs"]["Jan"];
            var NonProductiveFTEs_Feb = excelData["Non-Productive FTEs"]["Feb"];
            var NonProductiveFTEs_Mar = excelData["Non-Productive FTEs"]["Mar"];
            var NonProductiveFTEs_Apr = excelData["Non-Productive FTEs"]["Apr"];
            var NonProductiveFTEs_May = excelData["Non-Productive FTEs"]["May"];
            var NonProductiveFTEs_Jun = excelData["Non-Productive FTEs"]["Jun"];
            var NonProductiveFTEs_Jul = excelData["Non-Productive FTEs"]["Jul"];
            var NonProductiveFTEs_Aug = excelData["Non-Productive FTEs"]["Aug"];
            var NonProductiveFTEs_Sep = excelData["Non-Productive FTEs"]["Sep"];
            var NonProductiveFTEs_Oct = excelData["Non-Productive FTEs"]["Oct"];
            var NonProductiveFTEs_Nov = excelData["Non-Productive FTEs"]["Nov"];
            var NonProductiveFTEs_Dec = excelData["Non-Productive FTEs"]["Dec"];
            var NonProductiveFTEs_Total = excelData["Non-Productive FTEs"]["Total"];

            // Employed (Paid) FTEs
            var EmployedPaidFTEs_Jan = excelData["Employed (Paid) FTEs"]["Jan"];
            var EmployedPaidFTEs_Feb = excelData["Employed (Paid) FTEs"]["Feb"];
            var EmployedPaidFTEs_Mar = excelData["Employed (Paid) FTEs"]["Mar"];
            var EmployedPaidFTEs_Apr = excelData["Employed (Paid) FTEs"]["Apr"];
            var EmployedPaidFTEs_May = excelData["Employed (Paid) FTEs"]["May"];
            var EmployedPaidFTEs_Jun = excelData["Employed (Paid) FTEs"]["Jun"];
            var EmployedPaidFTEs_Jul = excelData["Employed (Paid) FTEs"]["Jul"];
            var EmployedPaidFTEs_Aug = excelData["Employed (Paid) FTEs"]["Aug"];
            var EmployedPaidFTEs_Sep = excelData["Employed (Paid) FTEs"]["Sep"];
            var EmployedPaidFTEs_Oct = excelData["Employed (Paid) FTEs"]["Oct"];
            var EmployedPaidFTEs_Nov = excelData["Employed (Paid) FTEs"]["Nov"];
            var EmployedPaidFTEs_Dec = excelData["Employed (Paid) FTEs"]["Dec"];
            var EmployedPaidFTEs_Total = excelData["Employed (Paid) FTEs"]["Total"];

            // Total FTEs (Paid + Contract)
            var TotalFTEsPaidPlusContract_Jan = excelData["Total FTEs (Paid + Contract)"]["Jan"];
            var TotalFTEsPaidPlusContract_Feb = excelData["Total FTEs (Paid + Contract)"]["Feb"];
            var TotalFTEsPaidPlusContract_Mar = excelData["Total FTEs (Paid + Contract)"]["Mar"];
            var TotalFTEsPaidPlusContract_Apr = excelData["Total FTEs (Paid + Contract)"]["Apr"];
            var TotalFTEsPaidPlusContract_May = excelData["Total FTEs (Paid + Contract)"]["May"];
            var TotalFTEsPaidPlusContract_Jun = excelData["Total FTEs (Paid + Contract)"]["Jun"];
            var TotalFTEsPaidPlusContract_Jul = excelData["Total FTEs (Paid + Contract)"]["Jul"];
            var TotalFTEsPaidPlusContract_Aug = excelData["Total FTEs (Paid + Contract)"]["Aug"];
            var TotalFTEsPaidPlusContract_Sep = excelData["Total FTEs (Paid + Contract)"]["Sep"];
            var TotalFTEsPaidPlusContract_Oct = excelData["Total FTEs (Paid + Contract)"]["Oct"];
            var TotalFTEsPaidPlusContract_Nov = excelData["Total FTEs (Paid + Contract)"]["Nov"];
            var TotalFTEsPaidPlusContract_Dec = excelData["Total FTEs (Paid + Contract)"]["Dec"];
            var TotalFTEsPaidPlusContract_Total = excelData["Total FTEs (Paid + Contract)"]["Total"];

            // Total Salaries & Wages ($000)
            var TotalSalariesAndWagesDollar000_Jan = excelData["Total Salaries & Wages ($000)"]["Jan"];
            var TotalSalariesAndWagesDollar000_Feb = excelData["Total Salaries & Wages ($000)"]["Feb"];
            var TotalSalariesAndWagesDollar000_Mar = excelData["Total Salaries & Wages ($000)"]["Mar"];
            var TotalSalariesAndWagesDollar000_Apr = excelData["Total Salaries & Wages ($000)"]["Apr"];
            var TotalSalariesAndWagesDollar000_May = excelData["Total Salaries & Wages ($000)"]["May"];
            var TotalSalariesAndWagesDollar000_Jun = excelData["Total Salaries & Wages ($000)"]["Jun"];
            var TotalSalariesAndWagesDollar000_Jul = excelData["Total Salaries & Wages ($000)"]["Jul"];
            var TotalSalariesAndWagesDollar000_Aug = excelData["Total Salaries & Wages ($000)"]["Aug"];
            var TotalSalariesAndWagesDollar000_Sep = excelData["Total Salaries & Wages ($000)"]["Sep"];
            var TotalSalariesAndWagesDollar000_Oct = excelData["Total Salaries & Wages ($000)"]["Oct"];
            var TotalSalariesAndWagesDollar000_Nov = excelData["Total Salaries & Wages ($000)"]["Nov"];
            var TotalSalariesAndWagesDollar000_Dec = excelData["Total Salaries & Wages ($000)"]["Dec"];
            var TotalSalariesAndWagesDollar000_Total = excelData["Total Salaries & Wages ($000)"]["Total"];

            // Total Contract Labor ($000)
            var TotalContractLaborDollar000_Jan = excelData["Total Contract Labor ($000)"]["Jan"];
            var TotalContractLaborDollar000_Feb = excelData["Total Contract Labor ($000)"]["Feb"];
            var TotalContractLaborDollar000_Mar = excelData["Total Contract Labor ($000)"]["Mar"];
            var TotalContractLaborDollar000_Apr = excelData["Total Contract Labor ($000)"]["Apr"];
            var TotalContractLaborDollar000_May = excelData["Total Contract Labor ($000)"]["May"];
            var TotalContractLaborDollar000_Jun = excelData["Total Contract Labor ($000)"]["Jun"];
            var TotalContractLaborDollar000_Jul = excelData["Total Contract Labor ($000)"]["Jul"];
            var TotalContractLaborDollar000_Aug = excelData["Total Contract Labor ($000)"]["Aug"];
            var TotalContractLaborDollar000_Sep = excelData["Total Contract Labor ($000)"]["Sep"];
            var TotalContractLaborDollar000_Oct = excelData["Total Contract Labor ($000)"]["Oct"];
            var TotalContractLaborDollar000_Nov = excelData["Total Contract Labor ($000)"]["Nov"];
            var TotalContractLaborDollar000_Dec = excelData["Total Contract Labor ($000)"]["Dec"];
            var TotalContractLaborDollar000_Total = excelData["Total Contract Labor ($000)"]["Total"];

            // Total Labor Expense ($000)
            var TotalLaborExpenseDollar000_Jan = excelData["Total Labor Expense ($000)"]["Jan"];
            var TotalLaborExpenseDollar000_Feb = excelData["Total Labor Expense ($000)"]["Feb"];
            var TotalLaborExpenseDollar000_Mar = excelData["Total Labor Expense ($000)"]["Mar"];
            var TotalLaborExpenseDollar000_Apr = excelData["Total Labor Expense ($000)"]["Apr"];
            var TotalLaborExpenseDollar000_May = excelData["Total Labor Expense ($000)"]["May"];
            var TotalLaborExpenseDollar000_Jun = excelData["Total Labor Expense ($000)"]["Jun"];
            var TotalLaborExpenseDollar000_Jul = excelData["Total Labor Expense ($000)"]["Jul"];
            var TotalLaborExpenseDollar000_Aug = excelData["Total Labor Expense ($000)"]["Aug"];
            var TotalLaborExpenseDollar000_Sep = excelData["Total Labor Expense ($000)"]["Sep"];
            var TotalLaborExpenseDollar000_Oct = excelData["Total Labor Expense ($000)"]["Oct"];
            var TotalLaborExpenseDollar000_Nov = excelData["Total Labor Expense ($000)"]["Nov"];
            var TotalLaborExpenseDollar000_Dec = excelData["Total Labor Expense ($000)"]["Dec"];
            var TotalLaborExpenseDollar000_Total = excelData["Total Labor Expense ($000)"]["Total"];

            // Employed Labor Rate
            var EmployedLaborRate_Jan = excelData["Employed Labor Rate"]["Jan"];
            var EmployedLaborRate_Feb = excelData["Employed Labor Rate"]["Feb"];
            var EmployedLaborRate_Mar = excelData["Employed Labor Rate"]["Mar"];
            var EmployedLaborRate_Apr = excelData["Employed Labor Rate"]["Apr"];
            var EmployedLaborRate_May = excelData["Employed Labor Rate"]["May"];
            var EmployedLaborRate_Jun = excelData["Employed Labor Rate"]["Jun"];
            var EmployedLaborRate_Jul = excelData["Employed Labor Rate"]["Jul"];
            var EmployedLaborRate_Aug = excelData["Employed Labor Rate"]["Aug"];
            var EmployedLaborRate_Sep = excelData["Employed Labor Rate"]["Sep"];
            var EmployedLaborRate_Oct = excelData["Employed Labor Rate"]["Oct"];
            var EmployedLaborRate_Nov = excelData["Employed Labor Rate"]["Nov"];
            var EmployedLaborRate_Dec = excelData["Employed Labor Rate"]["Dec"];
            var EmployedLaborRate_Total = excelData["Employed Labor Rate"]["Total"];

            // Contract Labor Rate
            var ContractLaborRate_Jan = excelData["Contract Labor Rate"]["Jan"];
            var ContractLaborRate_Feb = excelData["Contract Labor Rate"]["Feb"];
            var ContractLaborRate_Mar = excelData["Contract Labor Rate"]["Mar"];
            var ContractLaborRate_Apr = excelData["Contract Labor Rate"]["Apr"];
            var ContractLaborRate_May = excelData["Contract Labor Rate"]["May"];
            var ContractLaborRate_Jun = excelData["Contract Labor Rate"]["Jun"];
            var ContractLaborRate_Jul = excelData["Contract Labor Rate"]["Jul"];
            var ContractLaborRate_Aug = excelData["Contract Labor Rate"]["Aug"];
            var ContractLaborRate_Sep = excelData["Contract Labor Rate"]["Sep"];
            var ContractLaborRate_Oct = excelData["Contract Labor Rate"]["Oct"];
            var ContractLaborRate_Nov = excelData["Contract Labor Rate"]["Nov"];
            var ContractLaborRate_Dec = excelData["Contract Labor Rate"]["Dec"];
            var ContractLaborRate_Total = excelData["Contract Labor Rate"]["Total"];

            // Overtime Premium Dollars
            var OvertimePremiumDollars_Jan = excelData["Overtime Premium Dollars"]["Jan"];
            var OvertimePremiumDollars_Feb = excelData["Overtime Premium Dollars"]["Feb"];
            var OvertimePremiumDollars_Mar = excelData["Overtime Premium Dollars"]["Mar"];
            var OvertimePremiumDollars_Apr = excelData["Overtime Premium Dollars"]["Apr"];
            var OvertimePremiumDollars_May = excelData["Overtime Premium Dollars"]["May"];
            var OvertimePremiumDollars_Jun = excelData["Overtime Premium Dollars"]["Jun"];
            var OvertimePremiumDollars_Jul = excelData["Overtime Premium Dollars"]["Jul"];
            var OvertimePremiumDollars_Aug = excelData["Overtime Premium Dollars"]["Aug"];
            var OvertimePremiumDollars_Sep = excelData["Overtime Premium Dollars"]["Sep"];
            var OvertimePremiumDollars_Oct = excelData["Overtime Premium Dollars"]["Oct"];
            var OvertimePremiumDollars_Nov = excelData["Overtime Premium Dollars"]["Nov"];
            var OvertimePremiumDollars_Dec = excelData["Overtime Premium Dollars"]["Dec"];
            var OvertimePremiumDollars_Total = excelData["Overtime Premium Dollars"]["Total"];

            // Overtime %
            var OvertimePercentage_Jan = excelData["Overtime %"]["Jan"];
            var OvertimePercentage_Feb = excelData["Overtime %"]["Feb"];
            var OvertimePercentage_Mar = excelData["Overtime %"]["Mar"];
            var OvertimePercentage_Apr = excelData["Overtime %"]["Apr"];
            var OvertimePercentage_May = excelData["Overtime %"]["May"];
            var OvertimePercentage_Jun = excelData["Overtime %"]["Jun"];
            var OvertimePercentage_Jul = excelData["Overtime %"]["Jul"];
            var OvertimePercentage_Aug = excelData["Overtime %"]["Aug"];
            var OvertimePercentage_Sep = excelData["Overtime %"]["Sep"];
            var OvertimePercentage_Oct = excelData["Overtime %"]["Oct"];
            var OvertimePercentage_Nov = excelData["Overtime %"]["Nov"];
            var OvertimePercentage_Dec = excelData["Overtime %"]["Dec"];
            var OvertimePercentage_Total = excelData["Overtime %"]["Total"];

            // Overtime FTEs
            var OvertimeFTEs_Jan = excelData["Overtime FTEs"]["Jan"];
            var OvertimeFTEs_Feb = excelData["Overtime FTEs"]["Feb"];
            var OvertimeFTEs_Mar = excelData["Overtime FTEs"]["Mar"];
            var OvertimeFTEs_Apr = excelData["Overtime FTEs"]["Apr"];
            var OvertimeFTEs_May = excelData["Overtime FTEs"]["May"];
            var OvertimeFTEs_Jun = excelData["Overtime FTEs"]["Jun"];
            var OvertimeFTEs_Jul = excelData["Overtime FTEs"]["Jul"];
            var OvertimeFTEs_Aug = excelData["Overtime FTEs"]["Aug"];
            var OvertimeFTEs_Sep = excelData["Overtime FTEs"]["Sep"];
            var OvertimeFTEs_Oct = excelData["Overtime FTEs"]["Oct"];
            var OvertimeFTEs_Nov = excelData["Overtime FTEs"]["Nov"];
            var OvertimeFTEs_Dec = excelData["Overtime FTEs"]["Dec"];
            var OvertimeFTEs_Total = excelData["Overtime FTEs"]["Total"];

            // Admissions
            var Admissions_Jan = excelData["Admissions"]["Jan"];
            var Admissions_Feb = excelData["Admissions"]["Feb"];
            var Admissions_Mar = excelData["Admissions"]["Mar"];
            var Admissions_Apr = excelData["Admissions"]["Apr"];
            var Admissions_May = excelData["Admissions"]["May"];
            var Admissions_Jun = excelData["Admissions"]["Jun"];
            var Admissions_Jul = excelData["Admissions"]["Jul"];
            var Admissions_Aug = excelData["Admissions"]["Aug"];
            var Admissions_Sep = excelData["Admissions"]["Sep"];
            var Admissions_Oct = excelData["Admissions"]["Oct"];
            var Admissions_Nov = excelData["Admissions"]["Nov"];
            var Admissions_Dec = excelData["Admissions"]["Dec"];
            var Admissions_Total = excelData["Admissions"]["Total"];

            // Adjusted Admissions
            var AdjustedAdmissions_Jan = excelData["Adjusted Admissions"]["Jan"];
            var AdjustedAdmissions_Feb = excelData["Adjusted Admissions"]["Feb"];
            var AdjustedAdmissions_Mar = excelData["Adjusted Admissions"]["Mar"];
            var AdjustedAdmissions_Apr = excelData["Adjusted Admissions"]["Apr"];
            var AdjustedAdmissions_May = excelData["Adjusted Admissions"]["May"];
            var AdjustedAdmissions_Jun = excelData["Adjusted Admissions"]["Jun"];
            var AdjustedAdmissions_Jul = excelData["Adjusted Admissions"]["Jul"];
            var AdjustedAdmissions_Aug = excelData["Adjusted Admissions"]["Aug"];
            var AdjustedAdmissions_Sep = excelData["Adjusted Admissions"]["Sep"];
            var AdjustedAdmissions_Oct = excelData["Adjusted Admissions"]["Oct"];
            var AdjustedAdmissions_Nov = excelData["Adjusted Admissions"]["Nov"];
            var AdjustedAdmissions_Dec = excelData["Adjusted Admissions"]["Dec"];
            var AdjustedAdmissions_Total = excelData["Adjusted Admissions"]["Total"];

            // Patient Days
            var PatientDays_Jan = excelData["Patient Days"]["Jan"];
            var PatientDays_Feb = excelData["Patient Days"]["Feb"];
            var PatientDays_Mar = excelData["Patient Days"]["Mar"];
            var PatientDays_Apr = excelData["Patient Days"]["Apr"];
            var PatientDays_May = excelData["Patient Days"]["May"];
            var PatientDays_Jun = excelData["Patient Days"]["Jun"];
            var PatientDays_Jul = excelData["Patient Days"]["Jul"];
            var PatientDays_Aug = excelData["Patient Days"]["Aug"];
            var PatientDays_Sep = excelData["Patient Days"]["Sep"];
            var PatientDays_Oct = excelData["Patient Days"]["Oct"];
            var PatientDays_Nov = excelData["Patient Days"]["Nov"];
            var PatientDays_Dec = excelData["Patient Days"]["Dec"];
            var PatientDays_Total = excelData["Patient Days"]["Total"];

            // APD
            var APD_Jan = excelData["APD"]["Jan"];
            var APD_Feb = excelData["APD"]["Feb"];
            var APD_Mar = excelData["APD"]["Mar"];
            var APD_Apr = excelData["APD"]["Apr"];
            var APD_May = excelData["APD"]["May"];
            var APD_Jun = excelData["APD"]["Jun"];
            var APD_Jul = excelData["APD"]["Jul"];
            var APD_Aug = excelData["APD"]["Aug"];
            var APD_Sep = excelData["APD"]["Sep"];
            var APD_Oct = excelData["APD"]["Oct"];
            var APD_Nov = excelData["APD"]["Nov"];
            var APD_Dec = excelData["APD"]["Dec"];
            var APD_Total = excelData["APD"]["Total"];

            // ER Visits
            var ERVisits_Jan = excelData["ER Visits"]["Jan"];
            var ERVisits_Feb = excelData["ER Visits"]["Feb"];
            var ERVisits_Mar = excelData["ER Visits"]["Mar"];
            var ERVisits_Apr = excelData["ER Visits"]["Apr"];
            var ERVisits_May = excelData["ER Visits"]["May"];
            var ERVisits_Jun = excelData["ER Visits"]["Jun"];
            var ERVisits_Jul = excelData["ER Visits"]["Jul"];
            var ERVisits_Aug = excelData["ER Visits"]["Aug"];
            var ERVisits_Sep = excelData["ER Visits"]["Sep"];
            var ERVisits_Oct = excelData["ER Visits"]["Oct"];
            var ERVisits_Nov = excelData["ER Visits"]["Nov"];
            var ERVisits_Dec = excelData["ER Visits"]["Dec"];
            var ERVisits_Total = excelData["ER Visits"]["Total"];

            // Outpatient Visits
            var OutpatientVisits_Jan = excelData["Outpatient Visits"]["Jan"];
            var OutpatientVisits_Feb = excelData["Outpatient Visits"]["Feb"];
            var OutpatientVisits_Mar = excelData["Outpatient Visits"]["Mar"];
            var OutpatientVisits_Apr = excelData["Outpatient Visits"]["Apr"];
            var OutpatientVisits_May = excelData["Outpatient Visits"]["May"];
            var OutpatientVisits_Jun = excelData["Outpatient Visits"]["Jun"];
            var OutpatientVisits_Jul = excelData["Outpatient Visits"]["Jul"];
            var OutpatientVisits_Aug = excelData["Outpatient Visits"]["Aug"];
            var OutpatientVisits_Sep = excelData["Outpatient Visits"]["Sep"];
            var OutpatientVisits_Oct = excelData["Outpatient Visits"]["Oct"];
            var OutpatientVisits_Nov = excelData["Outpatient Visits"]["Nov"];
            var OutpatientVisits_Dec = excelData["Outpatient Visits"]["Dec"];
            var OutpatientVisits_Total = excelData["Outpatient Visits"]["Total"];

            // EEOB
            var EEOB_Jan = excelData["EEOB"]["Jan"];
            var EEOB_Feb = excelData["EEOB"]["Feb"];
            var EEOB_Mar = excelData["EEOB"]["Mar"];
            var EEOB_Apr = excelData["EEOB"]["Apr"];
            var EEOB_May = excelData["EEOB"]["May"];
            var EEOB_Jun = excelData["EEOB"]["Jun"];
            var EEOB_Jul = excelData["EEOB"]["Jul"];
            var EEOB_Aug = excelData["EEOB"]["Aug"];
            var EEOB_Sep = excelData["EEOB"]["Sep"];
            var EEOB_Oct = excelData["EEOB"]["Oct"];
            var EEOB_Nov = excelData["EEOB"]["Nov"];
            var EEOB_Dec = excelData["EEOB"]["Dec"];
            var EEOB_Total = excelData["EEOB"]["Total"];

            // MH/AA
            var MHAA_Jan = excelData["MH/AA"]["Jan"];
            var MHAA_Feb = excelData["MH/AA"]["Feb"];
            var MHAA_Mar = excelData["MH/AA"]["Mar"];
            var MHAA_Apr = excelData["MH/AA"]["Apr"];
            var MHAA_May = excelData["MH/AA"]["May"];
            var MHAA_Jun = excelData["MH/AA"]["Jun"];
            var MHAA_Jul = excelData["MH/AA"]["Jul"];
            var MHAA_Aug = excelData["MH/AA"]["Aug"];
            var MHAA_Sep = excelData["MH/AA"]["Sep"];
            var MHAA_Oct = excelData["MH/AA"]["Oct"];
            var MHAA_Nov = excelData["MH/AA"]["Nov"];
            var MHAA_Dec = excelData["MH/AA"]["Dec"];
            var MHAA_Total = excelData["MH/AA"]["Total"];

            return excelData;

        }
    }
}
