﻿using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class ExportsReport
    {
        public static void GoTo()
        {
            WFTMainMenu.WFTReports.Exports.SelectExports();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to Exports report", "Exports report page is displayed.");
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlReportYear']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        public static ExportsReportCommand Report()
        {
            return new ExportsReportCommand();
        }
    }
    #region: ExportsReportCommand
    public class ExportsReportCommand
    {
        private string year;
        private string exportType;
        private string plan;

        public ExportsReportCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public ExportsReportCommand withExportType(string ExportType)
        {
            this.exportType = ExportType;
            return this;
        }

        public ExportsReportCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }


        private void setYear()
        {
            if (!string.IsNullOrEmpty(year))
            {
                IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//select[@id='ddlReportYear']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
            }
        }

        private void setExportType()
        {
            if (!string.IsNullOrEmpty(exportType))
            {
                IWebElement mnuExportType = CommonFunctions.getElement(By.XPath("//select[@id='ddlExportTypes']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuExportType, exportType);
            }
        }      

        private void setPlan()
        {
            if (!string.IsNullOrEmpty(plan))
            {
                IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlans']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
            }
        }

        private void clickPDF()
        {
            IWebElement cmdPDF = CommonFunctions.getElement(By.XPath("//img[@title='PDF Format']"));
            CommonFunctions.ClickByJE(cmdPDF);
        }
        private void clickExcel()
        {
            IWebElement cmdExcel = CommonFunctions.getElement(By.XPath("//img[@title='Excel Format']"));
            CommonFunctions.ClickByJE(cmdExcel);
        }



        public void SelectPDF()
        {
            setYear();
            setPlan();
            setExportType();           
            clickPDF();
            CommonFunctions.AddTestStep("Click on the PDF button", "Verify the PDF report is downloaded");
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public void SelectExcel()
        {
            setYear();
            setPlan();
            setExportType();
            clickExcel();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the Excel button", "Verify the Excel report is downloaded");
        }
    }
    #endregion
}





