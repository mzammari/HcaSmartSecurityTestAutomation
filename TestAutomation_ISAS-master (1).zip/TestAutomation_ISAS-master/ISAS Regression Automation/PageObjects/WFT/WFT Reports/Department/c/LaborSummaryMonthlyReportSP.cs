﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class LaborSummaryMonthlyReportSP
    {
        public static string getLaborSummaryMonthlyReportSP(string DeptNumber)
        {
            
            int Dept = int.Parse(DeptNumber);

            var LaborSummaryMonthlyReportSp = $"Declare @PlanId BIGINT={RunData.PlanID}" + Environment.NewLine +
                    $"Declare @DeptNumber INT = {Dept}" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +                    
                    "IF EXISTS( SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                    "WHERE ID = OBJECT_ID(N'tempdb..#TempMonthlyValue')  )" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "DROP TABLE #TempMonthlyValue;" + Environment.NewLine +
                    "END;" + Environment.NewLine +
                    "IF EXISTS( SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                    "WHERE ID = OBJECT_ID(N'tempdb..#TempAllValue')  )" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "DROP TABLE #TempAllValue;" + Environment.NewLine +
                    "END;" + Environment.NewLine +
                    "IF EXISTS( SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                    "WHERE ID = OBJECT_ID(N'tempdb..#TempFacStatValue')  )" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "DROP TABLE #TempFacStatValue;" + Environment.NewLine +
                    "END;" + Environment.NewLine +
                    "Declare @StDept INT" + Environment.NewLine +
                    "DECLARE @EndDept INT" + Environment.NewLine +
                    "IF (@DeptNumber is null OR @DeptNumber <= 0)" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "SET @StDept=1" + Environment.NewLine +
                    "SET @EndDept=999" + Environment.NewLine +
                    "END" + Environment.NewLine +
                    "ELSE" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "SET @StDept=@DeptNumber" + Environment.NewLine +
                    "SET @EndDept=@DeptNumber" + Environment.NewLine +
                    "END" + Environment.NewLine +
                    "-- to get second highest and second lowest value keep result set in temp table" + Environment.NewLine +
                    "CREATE TABLE #TempMonthlyValue(" + Environment.NewLine +
                    "WftDepartment_ID BIGINT NOT NULL,[Year] INT," + Environment.NewLine +
                    "MonthNum INT ," + Environment.NewLine +
                    "[MonthName] VARCHAR(25)," + Environment.NewLine +
                    "EmployedProductiveFtes decimal(19,5)," + Environment.NewLine +
                    "ContractLaborPercent decimal(19,5)," + Environment.NewLine +
                    "ContractFtes decimal(19,5)," + Environment.NewLine +
                    "TotalProductiveFtes decimal(19,5)," + Environment.NewLine +
                    "NonProductivePercent decimal(19,5)," + Environment.NewLine +
                    "NonProductiveFtes decimal(19,5)," + Environment.NewLine +
                    "EmployedPaidFtes decimal(19,5)," + Environment.NewLine +
                    "TotalFtes decimal(19,5)," + Environment.NewLine +
                    "TotalSalariesAndWages decimal(19,5)," + Environment.NewLine +
                    "TotalContractLaborDollars decimal(19,5)," + Environment.NewLine +
                    "TotalLaborExpense decimal(19,5)," + Environment.NewLine +
                    "EmployedLaborRate decimal(19,5)," + Environment.NewLine +
                    "ContactLaborRate decimal(19,5)," + Environment.NewLine +
                    "OverTimePremiumDollars decimal(19,5)," + Environment.NewLine +
                    "OtPercent decimal(19,5)," + Environment.NewLine +
                    "OtFte decimal(19,5)," + Environment.NewLine +
                    "DeptUOS decimal(19,5)," + Environment.NewLine +
                    "SemiVariableFtes  decimal(19,5)," + Environment.NewLine +
                    "VariableProdHrsPerUOS  decimal(19,5)," + Environment.NewLine +
                    "TotalProdHrsPerUOS  decimal(19,5)," + Environment.NewLine +
                    "TotalPaidHrsPerUOS  decimal(19,5)," + Environment.NewLine +
                    "ProductiveMinFtes decimal(19,5)," + Environment.NewLine +
                    "MaxEmployedProductiveFtes decimal(19,5) ," + Environment.NewLine +
                    "MaxContractLaborPercent decimal(19,5) ," + Environment.NewLine +
                    "MaxContractFtes decimal(19,5) ," + Environment.NewLine +
                    "MaxTotalProductiveFtes decimal(19,5) ," + Environment.NewLine +
                    "MaxNonProductivePercent decimal(19,5) ," + Environment.NewLine +
                    "MaxNonProductiveFtes decimal(19,5) ," + Environment.NewLine +
                    "MaxEmployedPaidFtes decimal(19,5)," + Environment.NewLine +
                    "MaxTotalFtes decimal(19,5) ," + Environment.NewLine +
                    "MaxTotalSalariesAndWages decimal(19,5) ," + Environment.NewLine +
                    "MaxTotalContractLaborDollars decimal(19,5) ," + Environment.NewLine +
                    "MaxTotalLaborExpense decimal(19,5) ," + Environment.NewLine +
                    "MaxEmployedLaborRate decimal(19,5) ," + Environment.NewLine +
                    "MaxContactLaborRate decimal(19,5) ," + Environment.NewLine +
                    "MaxOverTimePremiumDollars decimal(19,5) ," + Environment.NewLine +
                    "MaxOtPercent decimal(19,5) ," + Environment.NewLine +
                    "MaxOtFte decimal(19,5) ," + Environment.NewLine +
                    "MaxDeptUOS decimal(19,5)," + Environment.NewLine +
                    "MaxSemiVariableFtes decimal(19,5)  ," + Environment.NewLine +
                    "MaxVariableProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                    "MaxTotalProdHrsPerUOS decimal(19,5)  ," + Environment.NewLine +
                    "MaxTotalPaidHrsPerUOS decimal(19,5)," + Environment.NewLine +
                    "MaxProductiveMinFtes decimal(19,5)," + Environment.NewLine +
                    "MinEmployedProductiveFtes decimal(19,5) ," + Environment.NewLine +
                    "MinContractLaborPercent decimal(19,5) ," + Environment.NewLine +
                    "MinContractFtes decimal(19,5) ," + Environment.NewLine +
                    "MinTotalProductiveFtes decimal(19,5) ," + Environment.NewLine +
                    "MinNonProductivePercent decimal(19,5) ," + Environment.NewLine +
                    "MinNonProductiveFtes decimal(19,5) ," + Environment.NewLine +
                    "MinEmployedPaidFtes decimal(19,5) ," + Environment.NewLine +
                    "MinTotalFtes decimal(19,5) ," + Environment.NewLine +
                    "MinTotalSalariesAndWages decimal(19,5) ," + Environment.NewLine +
                    "MinTotalContractLaborDollars decimal(19,5) ," + Environment.NewLine +
                    "MinTotalLaborExpense decimal(19,5) ," + Environment.NewLine +
                    "MinEmployedLaborRate decimal(19,5) ," + Environment.NewLine +
                    "MinContactLaborRate decimal(19,5) ," + Environment.NewLine +
                    "MinOverTimePremiumDollars decimal(19,5) ," + Environment.NewLine +
                    "MinOtPercent decimal(19,5) ," + Environment.NewLine +
                    "MinOtFte decimal(19,5) ," + Environment.NewLine +
                    "MinDeptUOS  decimal(19,5)," + Environment.NewLine +
                    "MinSemiVariableFtes  decimal(19,5) ," + Environment.NewLine +
                    "MinVariableProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                    "MinTotalProdHrsPerUOS decimal(19,5)  ," + Environment.NewLine +
                    "MinTotalPaidHrsPerUOS decimal(19,5)," + Environment.NewLine +
                    "MinProductiveMinFtes decimal(19,5)," + Environment.NewLine +
                    ")" + Environment.NewLine +
                    "DECLARE @totalVal decimal(19,5)" + Environment.NewLine +
                    "DECLARE @CoId BIGINT" + Environment.NewLine +
                    "DECLARE @DeptId BIGINT" + Environment.NewLine +
                    "DECLARE @FacilityID BIGINT" + Environment.NewLine +
                    "DECLARE @planYear BIGINT" + Environment.NewLine +
                    "SELECT @CoId=CoId, @DeptId=D.Id , @FacilityID = F.Id" + Environment.NewLine +
                    "FROM Facility F" + Environment.NewLine +
                    "JOIN Department D ON D.Facility_ID = F.Id" + Environment.NewLine +
                    "JOIN WftDepartment WD ON WD.Department_ID = D.Id" + Environment.NewLine +
                    "WHERE WD.WftPlan_ID = @PlanId --AND D.Number = @DeptNumber" + Environment.NewLine +
                    "AND D.IsInactiveInWFT=0" + Environment.NewLine +
                    "SELECT @planYear =  P.[Year] from WFTPLAN P where P.Id = @PlanId" + Environment.NewLine +
                    "INSERT INTO #TempMonthlyValue(" + Environment.NewLine +
                    "WftDepartment_ID,[Year]," + Environment.NewLine +
                    "MonthNum ," + Environment.NewLine +
                    "[MonthName] ," + Environment.NewLine +
                    "EmployedProductiveFtes," + Environment.NewLine +
                    "ContractLaborPercent," + Environment.NewLine +
                    "ContractFtes," + Environment.NewLine +
                    "TotalProductiveFtes," + Environment.NewLine +
                    "NonProductivePercent," + Environment.NewLine +
                    "NonProductiveFtes," + Environment.NewLine +
                    "EmployedPaidFtes," + Environment.NewLine +
                    "TotalFtes," + Environment.NewLine +
                    "TotalSalariesAndWages," + Environment.NewLine +
                    "TotalContractLaborDollars," + Environment.NewLine +
                    "TotalLaborExpense," + Environment.NewLine +
                    "EmployedLaborRate," + Environment.NewLine +
                    "ContactLaborRate," + Environment.NewLine +
                    "OverTimePremiumDollars," + Environment.NewLine +
                    "OtPercent," + Environment.NewLine +
                    "OtFte," + Environment.NewLine +
                    "DeptUOS," + Environment.NewLine +
                    "SemiVariableFtes ," + Environment.NewLine +
                    "VariableProdHrsPerUOS ," + Environment.NewLine +
                    "TotalProdHrsPerUOS ," + Environment.NewLine +
                    "TotalPaidHrsPerUOS," + Environment.NewLine +
                    "ProductiveMinFtes" + Environment.NewLine +
                    ")" + Environment.NewLine +
                    "--declare @planYear int = 2020" + Environment.NewLine +
                    "SELECT" + Environment.NewLine +
                    "V.WftDepartment_ID,@planYear as planYear," + Environment.NewLine +
                    "v.[Month] as MonthNum," + Environment.NewLine +
                    "CONVERT(VARCHAR(3),DateName( month , DateAdd( Month ,V.[Month] , 0 ) - 1))  as 'MonthName'" + Environment.NewLine +
                    ",V.EmployeeProductiveHours/dbo.fn_GetFortyBySevenDaysInMonth(@planYear,v.[Month]) as 'EmployedProductiveFtes'" + Environment.NewLine +
                    ",ContractLaborPercent" + Environment.NewLine +
                    ",V.ContractLaborFtes as 'ContractFTEs'," + Environment.NewLine +
                    "TotalProductiveFtes AS  TotalProductiveFtes," + Environment.NewLine +
                    "NonProductivePercent," + Environment.NewLine +
                    "--([TotalPaidFtes] * NonProductivePercent /100) as NonProductiveFtes," + Environment.NewLine +
                    "NonProductiveHours /dbo.fn_GetFortyBySevenDaysInMonth(@planYear,v.[Month])  as NonProductiveFtes," + Environment.NewLine +
                    "EmployeePaidManHours/dbo.fn_GetFortyBySevenDaysInMonth(@planYear,v.[Month]) as EmployedPaidFtes," + Environment.NewLine +
                    "V.TotalPaidFtes  as TotalFtes," + Environment.NewLine +
                    "EmployedSalaries as TotalSalariesAndWages," + Environment.NewLine +
                    "ContractAmount as TotalContractLaborDollars," + Environment.NewLine +
                    "[EmployedSalaries] + ContractAmount as TotalLaborExpense," + Environment.NewLine +
                    "EmployedLaborRate," + Environment.NewLine +
                    "ContractRate as 'ContractLaborRate'," + Environment.NewLine +
                    "--OT Premium = OT% x Paid Empl Hours x Paid Empl Rate x 0.5" + Environment.NewLine +
                    "--([OtHours] * EmployedLaborRate * 0.5) as 'OTPremium'," + Environment.NewLine +
                    "(OtPercent/100 * EmployeePaidManHours * EmployedLaborRate * 0.5) as 'OTPremium'," + Environment.NewLine +
                    "OtPercent," + Environment.NewLine +
                    "OtFte," + Environment.NewLine +
                    "DeptVolume  as 'DeptUOS'" + Environment.NewLine +
                    ",V.SemiVariableProductiveFtes" + Environment.NewLine +
                    ",PlusHoursPerUos as 'VariableProdHrsUOS'" + Environment.NewLine +
                    ",CASE WHEN ISNULL(DeptVolume,0)= 0 THEN 0 ELSE  [TotalProductiveHours]/DeptVolume end  as 'TotalProdHrsUOS'" + Environment.NewLine +
                    ",CASE WHEN ISNULL(DeptVolume,0)= 0 THEN 0 ELSE  TotalPaidHours/DeptVolume end as 'TotalPaidHrsUOS'" + Environment.NewLine +
                    ",V.ProductiveMinFtes" + Environment.NewLine +
                    "--into dbo.temp1" + Environment.NewLine +
                    "FROM WftMonthlyValue V  (nolock)" + Environment.NewLine +
                    "JOIN WftDepartment D (nolock) ON D.Id = V.WftDepartment_ID" + Environment.NewLine +
                    "JOIN ReferenceSourceYear RY (nolock) ON RY.Month = V.Month" + Environment.NewLine +
                    "JOIN Department DT ON D.Department_ID = DT.Id" + Environment.NewLine +
                    "join Facility F ON  DT.Facility_ID = F.Id And RY.CoId = f.CoId" + Environment.NewLine +
                    "--JOIN WftDepartment WD ON WD.Department_ID = D.Id" + Environment.NewLine +
                    "WHERE D.WftPlan_ID = @PlanId AND RY.SourceType = 1" + Environment.NewLine +
                    "AND DT.Number between @StDept AND @EndDept" + Environment.NewLine +
                    "AND DT.IsInactiveInWFT=0" + Environment.NewLine +
                    "--- Update Second Highest and Second Lowest Value to do color coding for Top 2 and bottom 2 values" + Environment.NewLine +
                    "UPDATE #TempMonthlyValue" + Environment.NewLine +
                    "SET MaxEmployedProductiveFtes    = t2.MaxEmployedProductiveFtes," + Environment.NewLine +
                    "MaxContractLaborPercent   = t2.MaxContractLaborPercent," + Environment.NewLine +
                    "MaxContractFtes     = t2.MaxContractFtes," + Environment.NewLine +
                    "MaxTotalProductiveFtes   = t2.MaxTotalProductiveFtes," + Environment.NewLine +
                    "MaxNonProductivePercent   = t2.MaxNonProductivePercent," + Environment.NewLine +
                    "MaxNonProductiveFtes   = t2.MaxNonProductiveFtes," + Environment.NewLine +
                    "MaxEmployedPaidFtes    = t2.MaxEmployedPaidFtes," + Environment.NewLine +
                    "MaxTotalFtes     = t2.MaxTotalFtes," + Environment.NewLine +
                    "MaxTotalSalariesAndWages  = t2.MaxTotalSalariesAndWages," + Environment.NewLine +
                    "MaxTotalContractLaborDollars = t2.MaxTotalContractLaborDollars," + Environment.NewLine +
                    "MaxTotalLaborExpense   = t2.MaxTotalLaborExpense," + Environment.NewLine +
                    "MaxEmployedLaborRate   = t2.MaxEmployedLaborRate," + Environment.NewLine +
                    "MaxContactLaborRate    = t2.MaxContactLaborRate," + Environment.NewLine +
                    "MaxOverTimePremiumDollars  = t2.MaxOverTimePremiumDollars," + Environment.NewLine +
                    "MaxOtPercent     = t2.MaxOtPercent," + Environment.NewLine +
                    "MaxOTFTE      = t2.MaxOTFTE," + Environment.NewLine +
                    "MaxDeptUOS      = t2.MaxDeptUOS," + Environment.NewLine +
                    "MaxSemiVariableFtes    = t2.MaxSemiVariableFtes," + Environment.NewLine +
                    "MaxVariableProdHrsPerUOS  = t2.MaxVariableProdHrsPerUOS," + Environment.NewLine +
                    "MaxTotalProdHrsPerUOS   = t2.MaxTotalProdHrsPerUOS," + Environment.NewLine +
                    "MaxTotalPaidHrsPerUOS   = t2.MaxTotalPaidHrsPerUOS," + Environment.NewLine +
                    "MaxProductiveMinFtes   = t2.MaxProductiveMinFtes" + Environment.NewLine +
                    "FROM #TempMonthlyValue FO" + Environment.NewLine +
                    "INNER JOIN" + Environment.NewLine +
                    "(" + Environment.NewLine +
                    "Select WftDepartment_ID," + Environment.NewLine +
                    "Min(EmployedProductiveFtes)  MaxEmployedProductiveFtes," + Environment.NewLine +
                    "Min(ContractLaborPercent)   MaxContractLaborPercent," + Environment.NewLine +
                    "Min(ContractFtes)     MaxContractFtes," + Environment.NewLine +
                    "Min(TotalProductiveFtes)   MaxTotalProductiveFtes," + Environment.NewLine +
                    "Min(NonProductivePercent)   MaxNonProductivePercent," + Environment.NewLine +
                    "Min(NonProductiveFtes)   MaxNonProductiveFtes," + Environment.NewLine +
                    "Min(EmployedPaidFtes)    MaxEmployedPaidFtes," + Environment.NewLine +
                    "Min(TotalFtes)     MaxTotalFtes," + Environment.NewLine +
                    "Min(TotalSalariesAndWages)  MaxTotalSalariesAndWages," + Environment.NewLine +
                    "Min(TotalContractLaborDollars) MaxTotalContractLaborDollars," + Environment.NewLine +
                    "Min(TotalLaborExpense)   MaxTotalLaborExpense," + Environment.NewLine +
                    "Min(EmployedLaborRate)   MaxEmployedLaborRate," + Environment.NewLine +
                    "Min(ContactLaborRate)    MaxContactLaborRate," + Environment.NewLine +
                    "Min(OverTimePremiumDollars)  MaxOverTimePremiumDollars," + Environment.NewLine +
                    "Min(OtPercent)     MaxOtPercent," + Environment.NewLine +
                    "Min(OTFTE)      MaxOTFTE," + Environment.NewLine +
                    "Min(DeptUOS)      MaxDeptUOS," + Environment.NewLine +
                    "Min(SemiVariableFtes)    MaxSemiVariableFtes," + Environment.NewLine +
                    "Min(VariableProdHrsPerUOS)  MaxVariableProdHrsPerUOS," + Environment.NewLine +
                    "Min(TotalProdHrsPerUOS)   MaxTotalProdHrsPerUOS," + Environment.NewLine +
                    "Min(TotalPaidHrsPerUOS)   MaxTotalPaidHrsPerUOS," + Environment.NewLine +
                    "Min(ProductiveMinFtes)   MaxProductiveMinFtes" + Environment.NewLine +
                    "FROM (" + Environment.NewLine +
                    "SELECT WftDepartment_ID," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(EmployedProductiveFtes, 2) DESC)  <=2 THEN ROUND(EmployedProductiveFtes, 2)  Else NULL END EmployedProductiveFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(ContractLaborPercent, 2) DESC)   <=2 THEN ROUND(ContractLaborPercent, 2)   ELSE NULL END ContractLaborPercent," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(ContractFtes, 2) DESC)     <=2 THEN ROUND(ContractFtes, 2)     ELSE NULL END ContractFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalProductiveFtes, 2) DESC)   <=2 THEN ROUND(TotalProductiveFtes, 2)   ELSE NULL END TotalProductiveFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(NonProductivePercent, 2) DESC)   <=2 THEN ROUND(NonProductivePercent, 2)   ELSE NULL END NonProductivePercent," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(NonProductiveFtes, 2) DESC)   <=2 THEN ROUND(NonProductiveFtes, 2)   ELSE NULL END NonProductiveFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(EmployedPaidFtes, 2) DESC)    <=2 THEN ROUND(EmployedPaidFtes, 2)    ELSE NULL END EmployedPaidFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalFtes, 2) DESC)     <=2 THEN ROUND(TotalFtes, 2)     ELSE NULL END TotalFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalSalariesAndWages, 2) DESC)  <=2 THEN ROUND(TotalSalariesAndWages, 2)  ELSE NULL END TotalSalariesAndWages," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalContractLaborDollars, 2) DESC) <=2 THEN ROUND(TotalContractLaborDollars, 2) ELSE NULL END TotalContractLaborDollars," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalLaborExpense, 2) DESC)   <=2 THEN ROUND(TotalLaborExpense, 2)   ELSE NULL END TotalLaborExpense," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(EmployedLaborRate, 2) DESC)   <=2 THEN ROUND(EmployedLaborRate, 2)   ELSE NULL END EmployedLaborRate," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(ContactLaborRate, 2) DESC)    <=2 THEN ROUND(ContactLaborRate, 2)    ELSE NULL END ContactLaborRate," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(OverTimePremiumDollars, 0) DESC)  <=2 THEN ROUND(OverTimePremiumDollars, 0)  ELSE NULL END OverTimePremiumDollars," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(OtPercent, 2) DESC)     <=2 THEN ROUND(OtPercent, 2)     ELSE NULL END OtPercent," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(OTFTE, 2) DESC)      <=2 THEN ROUND(OTFTE, 2)      ELSE NULL END OTFTE," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(DeptUOS, 0) DESC)      <=2 THEN ROUND(DeptUOS, 0)      ELSE NULL END DeptUOS," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(SemiVariableFtes, 2) DESC)    <=2 THEN ROUND(SemiVariableFtes, 2)    ELSE NULL END SemiVariableFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(VariableProdHrsPerUOS, 3) DESC)  <=2 THEN ROUND(VariableProdHrsPerUOS, 3)  ELSE NULL END VariableProdHrsPerUOS," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalProdHrsPerUOS, 3) DESC)   <=2 THEN ROUND(TotalProdHrsPerUOS, 3)   ELSE NULL END TotalProdHrsPerUOS," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalPaidHrsPerUOS, 3) DESC)   <=2 THEN ROUND(TotalPaidHrsPerUOS, 3)   ELSE NULL END TotalPaidHrsPerUOS," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(ProductiveMinFtes, 3) DESC)   <=2 THEN ROUND(ProductiveMinFtes, 3)      ELSE NULL END ProductiveMinFtes" + Environment.NewLine +
                    "from #TempMonthlyValue" + Environment.NewLine +
                    ")  t1" + Environment.NewLine +
                    "GROUP BY WftDepartment_ID" + Environment.NewLine +
                    ")t2 ON FO.WftDepartment_ID=t2.WftDepartment_ID" + Environment.NewLine +
                    "--Update Min value with second lowest values" + Environment.NewLine +
                    "UPDATE #TempMonthlyValue" + Environment.NewLine +
                    "SET MinEmployedProductiveFtes    = t2.MinEmployedProductiveFtes," + Environment.NewLine +
                    "MinContractLaborPercent   = t2.MinContractLaborPercent," + Environment.NewLine +
                    "MinContractFtes     = t2.MinContractFtes," + Environment.NewLine +
                    "MinTotalProductiveFtes   = t2.MinTotalProductiveFtes," + Environment.NewLine +
                    "MinNonProductivePercent   = t2.MinNonProductivePercent," + Environment.NewLine +
                    "MinNonProductiveFtes   = t2.MinNonProductiveFtes," + Environment.NewLine +
                    "MinEmployedPaidFtes    = t2.MinEmployedPaidFtes," + Environment.NewLine +
                    "MinTotalFtes     = t2.MinTotalFtes," + Environment.NewLine +
                    "MinTotalSalariesAndWages  = t2.MinTotalSalariesAndWages," + Environment.NewLine +
                    "MinTotalContractLaborDollars = t2.MinTotalContractLaborDollars," + Environment.NewLine +
                    "MinTotalLaborExpense   = t2.MinTotalLaborExpense," + Environment.NewLine +
                    "MinEmployedLaborRate   = t2.MinEmployedLaborRate," + Environment.NewLine +
                    "MinContactLaborRate    = t2.MinContactLaborRate," + Environment.NewLine +
                    "MinOverTimePremiumDollars  = t2.MinOverTimePremiumDollars," + Environment.NewLine +
                    "MinOtPercent     = t2.MinOtPercent," + Environment.NewLine +
                    "MinOTFTE      = t2.MinOTFTE," + Environment.NewLine +
                    "MinDeptUOS      = t2.MinDeptUOS," + Environment.NewLine +
                    "MinSemiVariableFtes    = t2.MinSemiVariableFtes," + Environment.NewLine +
                    "MinVariableProdHrsPerUOS  = t2.MinVariableProdHrsPerUOS," + Environment.NewLine +
                    "MinTotalProdHrsPerUOS   = t2.MinTotalProdHrsPerUOS," + Environment.NewLine +
                    "MinTotalPaidHrsPerUOS   = t2.MinTotalPaidHrsPerUOS," + Environment.NewLine +
                    "MinProductiveMinFtes   = t2.MinProductiveMinFtes" + Environment.NewLine +
                    "FROM #TempMonthlyValue FO" + Environment.NewLine +
                    "INNER JOIN" + Environment.NewLine +
                    "(" + Environment.NewLine +
                    "Select WftDepartment_ID," + Environment.NewLine +
                    "Max(EmployedProductiveFtes)  MinEmployedProductiveFtes," + Environment.NewLine +
                    "Max(ContractLaborPercent)   MinContractLaborPercent," + Environment.NewLine +
                    "Max(ContractFtes)     MinContractFtes," + Environment.NewLine +
                    "Max(TotalProductiveFtes)   MinTotalProductiveFtes," + Environment.NewLine +
                    "Max(NonProductivePercent)   MinNonProductivePercent," + Environment.NewLine +
                    "Max(NonProductiveFtes)   MinNonProductiveFtes," + Environment.NewLine +
                    "Max(EmployedPaidFtes)    MinEmployedPaidFtes," + Environment.NewLine +
                    "Max(TotalFtes)     MinTotalFtes," + Environment.NewLine +
                    "Max(TotalSalariesAndWages)  MinTotalSalariesAndWages," + Environment.NewLine +
                    "Max(TotalContractLaborDollars) MinTotalContractLaborDollars," + Environment.NewLine +
                    "Max(TotalLaborExpense)   MinTotalLaborExpense," + Environment.NewLine +
                    "Max(EmployedLaborRate)   MinEmployedLaborRate," + Environment.NewLine +
                    "Max(ContactLaborRate)    MinContactLaborRate," + Environment.NewLine +
                    "Max(OverTimePremiumDollars)  MinOverTimePremiumDollars," + Environment.NewLine +
                    "Max(OtPercent)     MinOtPercent," + Environment.NewLine +
                    "Max(OTFTE)      MinOTFTE," + Environment.NewLine +
                    "Max(DeptUOS)      MinDeptUOS," + Environment.NewLine +
                    "Max(SemiVariableFtes)    MinSemiVariableFtes," + Environment.NewLine +
                    "Max(VariableProdHrsPerUOS)  MinVariableProdHrsPerUOS," + Environment.NewLine +
                    "Max(TotalProdHrsPerUOS)   MinTotalProdHrsPerUOS," + Environment.NewLine +
                    "Max(TotalPaidHrsPerUOS)   MinTotalPaidHrsPerUOS," + Environment.NewLine +
                    "Max(ProductiveMinFtes)   MinProductiveMinFtes" + Environment.NewLine +
                    "FROM (" + Environment.NewLine +
                    "SELECT WftDepartment_ID," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(EmployedProductiveFtes, 2) ASC)  <=2 THEN ROUND(EmployedProductiveFtes, 2)  Else NULL END EmployedProductiveFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(ContractLaborPercent, 2) ASC)   <=2 THEN ROUND(ContractLaborPercent, 2)   ELSE NULL END ContractLaborPercent," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(ContractFtes, 2) ASC)     <=2 THEN ROUND(ContractFtes, 2)     ELSE NULL END ContractFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalProductiveFtes, 2) ASC)   <=2 THEN ROUND(TotalProductiveFtes, 2)   ELSE NULL END TotalProductiveFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(NonProductivePercent, 2) ASC)   <=2 THEN ROUND(NonProductivePercent, 2)   ELSE NULL END NonProductivePercent," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(NonProductiveFtes, 2) ASC)    <=2 THEN ROUND(NonProductiveFtes, 2)   ELSE NULL END NonProductiveFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(EmployedPaidFtes, 2) ASC)    <=2 THEN ROUND(EmployedPaidFtes, 2)    ELSE NULL END EmployedPaidFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalFtes, 2) ASC)      <=2 THEN ROUND(TotalFtes, 2)     ELSE NULL END TotalFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalSalariesAndWages, 2) ASC)   <=2 THEN ROUND(TotalSalariesAndWages, 2)  ELSE NULL END TotalSalariesAndWages," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalContractLaborDollars, 2) ASC)  <=2 THEN ROUND(TotalContractLaborDollars, 2) ELSE NULL END TotalContractLaborDollars," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalLaborExpense, 2) ASC)    <=2 THEN ROUND(TotalLaborExpense, 2)   ELSE NULL END TotalLaborExpense," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(EmployedLaborRate, 2) ASC)    <=2 THEN ROUND(EmployedLaborRate, 2)   ELSE NULL END EmployedLaborRate," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(ContactLaborRate, 2) ASC)    <=2 THEN ROUND(ContactLaborRate, 2)    ELSE NULL END ContactLaborRate," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(OverTimePremiumDollars, 0) ASC)  <=2 THEN ROUND(OverTimePremiumDollars, 0)  ELSE NULL END OverTimePremiumDollars," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(OtPercent, 2) ASC)      <=2 THEN ROUND(OtPercent, 2)     ELSE NULL END OtPercent," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(OTFTE, 2) ASC)       <=2 THEN ROUND(OTFTE, 2)      ELSE NULL END OTFTE," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(DeptUOS, 0) ASC)      <=2 THEN ROUND(DeptUOS, 0)      ELSE NULL END DeptUOS," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(SemiVariableFtes, 2) ASC)    <=2 THEN ROUND(SemiVariableFtes, 2)    ELSE NULL END SemiVariableFtes," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(VariableProdHrsPerUOS, 3) ASC)   <=2 THEN ROUND(VariableProdHrsPerUOS, 3)  ELSE NULL END VariableProdHrsPerUOS," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalProdHrsPerUOS, 3) ASC)   <=2 THEN ROUND(TotalProdHrsPerUOS, 3)   ELSE NULL END TotalProdHrsPerUOS," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(TotalPaidHrsPerUOS, 3) ASC)   <=2 THEN ROUND(TotalPaidHrsPerUOS, 3)   ELSE NULL END TotalPaidHrsPerUOS," + Environment.NewLine +
                    "CASE WHEN DENSE_RANK() OVER( PARTITION BY WftDepartment_ID ORDER BY ROUND(ProductiveMinFtes, 3) ASC)    <=2 THEN ROUND(ProductiveMinFtes, 3)   ELSE NULL END ProductiveMinFtes" + Environment.NewLine +
                    "from #TempMonthlyValue" + Environment.NewLine +
                    ")  t1" + Environment.NewLine +
                    "GROUP BY WftDepartment_ID" + Environment.NewLine +
                    ")t2 ON FO.WftDepartment_ID=t2.WftDepartment_ID" + Environment.NewLine +
                    "-- Return Result Set" + Environment.NewLine +
                    "SELECT V.*," + Environment.NewLine +
                    "-- Get Dept Level Total from wftDepartment Table" + Environment.NewLine +
                    "EmployeeProductiveHoursTotal/ dbo.fn_GetFortyBySevenDaysInYear(@planYear) as 'EmployedProductiveFtesTotal'" + Environment.NewLine +
                    ",ContractLaborPercentTotal" + Environment.NewLine +
                    ",ContractLaborFtesTotal as 'ContractFTEsTotal'," + Environment.NewLine +
                    "TotalProductiveFtesTotal AS  TotalProductiveFtesTotal," + Environment.NewLine +
                    "NonProductivePercentTotal," + Environment.NewLine +
                    "--([TotalPaidFtesTotal] * NonProductivePercentTotal /100) as NonProductiveFtesTotal," + Environment.NewLine +
                    "NonProductiveHoursTotal / dbo.fn_GetFortyBySevenDaysInYear(@planYear) as NonProductiveFtesTotal," + Environment.NewLine +
                    "EmployeePaidManHoursTotal/dbo.fn_GetFortyBySevenDaysInYear(@planYear) as EmployedPaidFtesTotal," + Environment.NewLine +
                    "TotalPaidFtesTotal  as TotalFtesTotal," + Environment.NewLine +
                    "EmployedSalariesTotal as TotalSalariesAndWagesTotal," + Environment.NewLine +
                    "ContractLaborDollarsTotal as TotalContractLaborDollarsTotal," + Environment.NewLine +
                    "[EmployedSalariesTotal] + ContractLaborDollarsTotal as TotalLaborExpenseTotal," + Environment.NewLine +
                    "EmployedLaborRateTotal," + Environment.NewLine +
                    "ContractRateTotal as 'ContractLaborRateTotal'," + Environment.NewLine +
                    "--OT Premium = OT% x Paid Empl Hours x Paid Empl Rate x 0.5" + Environment.NewLine +
                    "--[OtHoursTotal] * EmployedLaborRateTotal * 0.5  as 'OTPremiumTotal'," + Environment.NewLine +
                    "--OtPercentTotal/100 * EmployeePaidManHoursTotal * EmployedLaborRateTotal * 0.5  as 'OTPremiumTotal'," + Environment.NewLine +
                    "V1.SumOfOTPremium AS OTPremiumTotal," + Environment.NewLine +
                    "OtPercentTotal," + Environment.NewLine +
                    "OtFtesTotal," + Environment.NewLine +
                    "DeptVolumeTotal   as 'DeptUOSTotal'" + Environment.NewLine +
                    ", SemiVariableProductiveFtesTotal" + Environment.NewLine +
                    ",VariableHoursPerUosTotal as 'VariableProdHrsUOSTotal'" + Environment.NewLine +
                    ",CASE WHEN ISNULL(DeptVolumeTotal,0)= 0 THEN 0 ELSE  [TotalProductiveHoursTotal]/DeptVolumeTotal END as 'TotalProdHrsUOSTotal'" + Environment.NewLine +
                    ",CASE WHEN ISNULL(DeptVolumeTotal,0)= 0 THEN 0 ELSE  [TotalPaidHoursTotal]/DeptVolumeTotal END as 'TotalPaidHrsUOSTotal'" + Environment.NewLine +
                    ",ProductiveMinFtesTotal" + Environment.NewLine +
                    ",HD.FactilityDesc," + Environment.NewLine +
                    "HD.[Name] AS DeptName," + Environment.NewLine +
                    "HD.[StatDescription]," + Environment.NewLine +
                    "HD.DeptType," + Environment.NewLine +
                    "HD.Number AS DeptNumber" + Environment.NewLine +
                    "--rewrite" + Environment.NewLine +
                    "FROM #TempMonthlyValue V INNER JOIN  WftDepartment D (nolock) ON V.WftDepartment_id=d.Id" + Environment.NewLine +
                    "inner join ( SELECT  DT.Number," + Environment.NewLine +
                    "MV.WftDepartment_ID," + Environment.NewLine +
                    "--OT Premium = OT% x Paid Empl Hours x Paid Empl Rate x 0.5" + Environment.NewLine +
                    "--([OtHours] * EmployedLaborRate * 0.5) as 'OTPremium'," + Environment.NewLine +
                    "sum(OtPercent/100 * EmployeePaidManHours * EmployedLaborRate * 0.5) as SumOfOTPremium" + Environment.NewLine +
                    "FROM WftMonthlyValue MV (nolock)" + Environment.NewLine +
                    "JOIN WftDepartment D (nolock) ON D.Id = MV.WftDepartment_ID" + Environment.NewLine +
                    "JOIN ReferenceSourceYear RY (nolock) ON RY.Month = MV.Month" + Environment.NewLine +
                    "JOIN Department DT ON D.Department_ID = DT.Id" + Environment.NewLine +
                    "join Facility F ON  DT.Facility_ID = F.Id And RY.CoId = f.CoId" + Environment.NewLine +
                    "WHERE D.WftPlan_ID = @PlanId AND  RY.SourceType = 1 AND DT.IsInactiveInWFT=0" + Environment.NewLine +
                    "GROUP BY MV.WftDepartment_ID,DT.Number" + Environment.NewLine +
                    ") V1 on V.WftDepartment_id=V1.WftDepartment_ID" + Environment.NewLine +
                    "LEFT  JOIN" + Environment.NewLine +
                    "(" + Environment.NewLine +
                    "--declare @CoId Bigint = 31054" + Environment.NewLine +
                    "SELECT F.[Description] as FactilityDesc, [Name],[StatDescription],F.CoId,D.Number," + Environment.NewLine +
                    "(case when d.IsUserDefined=1 then 'User Defined'" + Environment.NewLine +
                    "else  T.Description end) as DeptType" + Environment.NewLine +
                    "FROM [Department] D" + Environment.NewLine +
                    "JOIN [Facility] F ON F.Id = D.Facility_ID" + Environment.NewLine +
                    "JOIN [DepartmentType] T ON T.Id = D.DepartmentType_ID" + Environment.NewLine +
                    "WHERE F.CoId = @CoId" + Environment.NewLine +
                    "AND D.Number between @StDept and @EndDept" + Environment.NewLine +
                    "--AND D.Number = @DeptNumber" + Environment.NewLine +
                    "and D.IsInactiveInWFT=0) HD" + Environment.NewLine +
                    "on HD.Number = V1.Number" + Environment.NewLine +
                    "WHERE D.WftPlan_ID = @PlanId" + Environment.NewLine +
                    "--AND V1.WftDepartment_ID in (120277696)" + Environment.NewLine +
                    "order by DeptNumber, MonthNum ASC" + Environment.NewLine +
                    "END";




            return LaborSummaryMonthlyReportSp;

        }

        

    }
}
