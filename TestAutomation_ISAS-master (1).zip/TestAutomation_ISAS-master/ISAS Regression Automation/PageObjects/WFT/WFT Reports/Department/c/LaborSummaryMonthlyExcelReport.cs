﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ExcelDataReader;

namespace ISAS_Regression_Automation
{
    public class LaborSummaryMonthlyExcelReport
    {
        /// <summary>
        /// Get department data by department number - supports both .xls and .xlsx files
        /// </summary>
        /// <param name="filePath">Path to the Excel file (.xls or .xlsx)</param>
        /// <param name="deptNumber">Department number to find</param>
        /// <param name="debug">Set to true to print debug information</param>
        /// <returns>DepartmentData if found, null otherwise</returns>
        public DepartmentData GetDepartmentData(string filePath, string deptNumber, bool debug = false)
        {
            // Register encoding provider for Excel compatibility
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var dataSet = reader.AsDataSet();
                    var worksheet = dataSet.Tables[0]; // First worksheet

                    if (debug)
                    {
                        Console.WriteLine($"Total rows in worksheet: {worksheet.Rows.Count}");
                        Console.WriteLine($"Total columns in worksheet: {worksheet.Columns.Count}");
                        Console.WriteLine("\nSearching for department: {0}\n", deptNumber);
                    }

                    // Find the department starting row
                    int deptRow = 8;// FindDepartmentRow(worksheet, deptNumber, debug);

                    if (deptRow == -1)
                    {
                        if (debug)
                        {
                            Console.WriteLine($"\nDepartment {deptNumber} NOT FOUND");
                        }
                        return null; // Department not found
                    }

                    if (debug)
                    {
                        Console.WriteLine($"\nDepartment {deptNumber} FOUND at row {deptRow + 1}");
                    }

                    // Parse only this department's data (next 30 rows)
                    var deptData = ParseDepartmentSection(worksheet, deptRow);
                    Console.WriteLine();
                    return deptData;
                }
            }
        }

        /// <summary>
                /// Find the row containing the specified department number
                /// </summary>
        private int FindDepartmentRow(System.Data.DataTable worksheet, string deptNumber, bool debug = false)
        {
            // Scan through column B (column index 1) looking for "Dept#Name:XXX" pattern
            for (int row = 0; row < worksheet.Rows.Count; row++)
            {
                var cellValue = worksheet.Rows[row][1]?.ToString(); // Column B (index 1)

                if (debug && !string.IsNullOrEmpty(cellValue))
                {
                    // Print first 50 chars of each non-empty cell in column B
                    var preview = cellValue.Length > 50 ? cellValue.Substring(0, 50) + "..." : cellValue;
                    Console.WriteLine($"Row {row + 1}, Col B: {preview}");
                }

                // Check if this is a Dept#Name cell (flexible matching)
                if (!string.IsNullOrEmpty(cellValue) &&
                      (cellValue.Contains("Dept#/Name", StringComparison.OrdinalIgnoreCase) ||
                      cellValue.Contains("Dept #Name", StringComparison.OrdinalIgnoreCase) ||
                      cellValue.Contains("Dept#", StringComparison.OrdinalIgnoreCase)))
                {
                    if (debug)
                    {
                        Console.WriteLine($"\n>>> Found Dept#Name cell at row {row + 1}: {cellValue}");
                    }

                    // Parse the department number from "Dept#Name:900 NURS ADMIN"
                    if (cellValue.Contains(":"))
                    {
                        var parts = cellValue.Split(':');
                        if (parts.Length >= 2)
                        {
                            var deptDetails = parts[1].Trim().Split(new[] { ' ' }, 2);
                            var foundDeptNumber = deptDetails[0];

                            if (debug)
                            {
                                Console.WriteLine($"    Extracted dept number: '{foundDeptNumber}'");
                                Console.WriteLine($"    Looking for: '{deptNumber}'");
                                Console.WriteLine($"    Match: {foundDeptNumber.Equals(deptNumber, StringComparison.OrdinalIgnoreCase)}");
                            }

                            // Check if this matches the requested department number
                            if (foundDeptNumber.Equals(deptNumber, StringComparison.OrdinalIgnoreCase))
                            {
                                return row; // Found it!
                            }
                        }
                    }
                }
            }

            return -1; // Not found
        }

        private DepartmentData ParseDepartmentSection(System.Data.DataTable worksheet, int startRow)
        {
            var deptData = new DepartmentData
            {
                Info = ParseDepartmentInfo(worksheet, startRow),
                FTESummary = ParseFTESummary(worksheet, startRow),
                LaborExpenseSummary = ParseLaborExpenseSummary(worksheet, startRow),
                VolumeSummary = ParseVolumeSummary(worksheet, startRow)
            };

            return deptData;
        }

        private DepartmentInfo ParseDepartmentInfo(System.Data.DataTable worksheet, int deptRow)
        {
            var deptInfo = new DepartmentInfo();

            // Parse "Dept#Name:900 NURS ADMIN" format from column B (index 1)
            var deptCell = worksheet.Rows[deptRow][1]?.ToString();
            if (!string.IsNullOrEmpty(deptCell) && deptCell.Contains(":"))
            {
                var parts = deptCell.Split(':');
                if (parts.Length >= 2)
                {
                    var deptDetails = parts[1].Trim().Split(new[] { ' ' }, 2);
                    deptInfo.DeptNumber = deptDetails[0];
                    deptInfo.DeptName = deptDetails.Length > 1 ? deptDetails[1] : "";
                }
            }

            // Type is in the next row, column B (index 1)
            if (deptRow + 1 < worksheet.Rows.Count)
            {
                var typeCell = worksheet.Rows[deptRow + 1][1]?.ToString();
                deptInfo.Type = typeCell?.Replace("Type:", "").Trim();
            }

            return deptInfo;
        }

        private DepartmentFTESummary ParseFTESummary(System.Data.DataTable worksheet, int deptRow)
        {
            // FTE Summary starts 2 rows after the "Department FTE Summary" header
            int summaryHeaderRow = FindRowWithText(worksheet, deptRow, "Department FTE Summary", 10);
            if (summaryHeaderRow == -1) return null;

            int dataStartRow = summaryHeaderRow + 2;

            return new DepartmentFTESummary
            {
                EmployedProductiveFTEs = ParseMonthlyRow<EmployedProductiveFTEs>(worksheet, dataStartRow),
                ContractLaborPercent = ParseMonthlyRow<ContractLaborPercent>(worksheet, dataStartRow + 1),
                ContractFTEs = ParseMonthlyRow<ContractFTEs>(worksheet, dataStartRow + 2),
                TotalProductiveFTEs = ParseMonthlyRow<TotalProductiveFTEs>(worksheet, dataStartRow + 3),
                NonProducingPercent = ParseMonthlyRow<NonProducingPercent>(worksheet, dataStartRow + 4),
                NonProductiveFTEs = ParseMonthlyRow<NonProductiveFTEs>(worksheet, dataStartRow + 5),
                EmployedPaidFTEs = ParseMonthlyRow<EmployedPaidFTEs>(worksheet, dataStartRow + 6),
                TotalFTEsPaidAndContract = ParseMonthlyRow<TotalFTEsPaidAndContract>(worksheet, dataStartRow + 7)
            };
        }

        private DepartmentLaborExpenseSummary ParseLaborExpenseSummary(System.Data.DataTable worksheet, int deptRow)
        {
            int summaryHeaderRow = FindRowWithText(worksheet, deptRow, "Department Labor Expense Summary", 25);
            if (summaryHeaderRow == -1) return null;

            int dataStartRow = summaryHeaderRow + 2;

            return new DepartmentLaborExpenseSummary
            {
                TotalSalariesAndWages = ParseMonthlyRow<TotalSalariesAndWages>(worksheet, dataStartRow),
                TotalContractLabor = ParseMonthlyRow<TotalContractLabor>(worksheet, dataStartRow + 1),
                TotalLaborCost = ParseMonthlyRow<TotalLaborCost>(worksheet, dataStartRow + 2),
                EmployedLaborRate = ParseMonthlyRow<EmployedLaborRate>(worksheet, dataStartRow + 3),
                ContractLaborRate = ParseMonthlyRow<ContractLaborRate>(worksheet, dataStartRow + 4),
                OvertimePremiumDollars = ParseMonthlyRow<OvertimePremiumDollars>(worksheet, dataStartRow + 5),
                OvertimePercent = ParseMonthlyRow<OvertimePercent>(worksheet, dataStartRow + 6),
                OvertimeFTEs = ParseMonthlyRow<OvertimeFTEs>(worksheet, dataStartRow + 7)
            };
        }

        private DepartmentVolumeSummary ParseVolumeSummary(System.Data.DataTable worksheet, int deptRow)
        {
            int summaryHeaderRow = FindRowWithText(worksheet, deptRow, "Department Volume Summary", 35);
            if (summaryHeaderRow == -1) return null;

            int dataStartRow = summaryHeaderRow + 2;

            return new DepartmentVolumeSummary
            {
                DepartmentUOS = ParseMonthlyRow<DepartmentUOS>(worksheet, dataStartRow),
                SemiVariableFTEs = ParseMonthlyRow<SemiVariableFTEs>(worksheet, dataStartRow + 1),
                VariableProductiveHrsPerUOS = ParseMonthlyRow<VariableProductiveHrsPerUOS>(worksheet, dataStartRow + 2),
                MinFTEs = ParseMonthlyRow<MinFTEs>(worksheet, dataStartRow + 3),
                TotalProductiveHrsPerUOS = ParseMonthlyRow<TotalProductiveHrsPerUOS>(worksheet, dataStartRow + 4)
            };
        }

        private int FindRowWithText(System.Data.DataTable worksheet, int startRow, string searchText, int maxRows)
        {
            int endRow = Math.Min(startRow + maxRows, worksheet.Rows.Count);

            for (int i = startRow; i < endRow; i++)
            {
                var cellValue = worksheet.Rows[i][1]?.ToString(); // Column B (index 1)
                if (!string.IsNullOrEmpty(cellValue) && cellValue.Contains(searchText, StringComparison.OrdinalIgnoreCase))
                {
                    return i;
                }
            }
            return -1;
        }

        private T ParseMonthlyRow<T>(System.Data.DataTable worksheet, int row) where T : MonthlyData, new()
        {
            var monthlyData = new T();

            if (row >= worksheet.Rows.Count) return monthlyData;

            var dataRow = worksheet.Rows[row];

            // Column layout (Column A ignored, starting from B):
            // B=Label, C=Jan, D=Feb, E=Mar, F=Apr, G=May, H=Jun,
            // I=Jul, J=Aug, K=Sep, L=Oct, M=Nov, N=Dec, O=Total
            // In DataTable: B=1, C=2, D=3, E=4, F=5, G=6, H=7, I=8, J=9, K=10, L=11, M=12, N=13, O=14

            monthlyData.Jan = ParseDouble(dataRow[2]);    // Column C
            monthlyData.Feb = ParseDouble(dataRow[3]);    // Column D
            monthlyData.Mar = ParseDouble(dataRow[4]);    // Column E
            monthlyData.Apr = ParseDouble(dataRow[5]);    // Column F
            monthlyData.May = ParseDouble(dataRow[6]);    // Column G
            monthlyData.Jun = ParseDouble(dataRow[7]);    // Column H
            monthlyData.Jul = ParseDouble(dataRow[8]);    // Column I
            monthlyData.Aug = ParseDouble(dataRow[9]);    // Column J
            monthlyData.Sep = ParseDouble(dataRow[10]);   // Column K
            monthlyData.Oct = ParseDouble(dataRow[11]);   // Column L
            monthlyData.Nov = ParseDouble(dataRow[12]);   // Column M
            monthlyData.Dec = ParseDouble(dataRow[13]);   // Column N
            monthlyData.Total = ParseDouble(dataRow[14]); // Column O

            return monthlyData;
        }

        private double ParseDouble(object value)
        {
            if (value == null || value == DBNull.Value) return 0.0;

            try
            {
                if (value is double doubleValue)
                    return doubleValue;

                if (value is decimal decimalValue)
                    return (double)decimalValue;

                if (value is int intValue)
                    return (double)intValue;

                if (value is long longValue)
                    return (double)longValue;

                var stringValue = value.ToString();
                if (double.TryParse(stringValue, out double result))
                    return result;

                return 0.0;
            }
            catch
            {
                return 0.0;
            }
        }
    }
}