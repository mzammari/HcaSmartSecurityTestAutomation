﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Loads a single department's data from SQL (12 rows) and pivots into monthly structure
    /// </summary>
    public static class WftDepartmentLoader
    {
        /// <summary>
        /// Get a single department's data from SQL
        /// Returns 12 rows from SQL, pivots into WftLaborSummaryData with monthly properties
        /// </summary>
        /// <param name="connectionString">Database connection string</param>
        /// <param name="deptNumber">Department number to query</param>
        /// <param name="year">Year to query</param>
        /// <returns>WftLaborSummaryData with all metrics containing monthly values</returns>
        public static WftLaborSummaryData GetLaborSummaryMonthlyDBData(string DeptNumber)
        {
            string DB = RunData.DatabaseName;
            string sServerName = RunData.ServerName;
            string connectionString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";

            var query = LaborSummaryMonthlyReportSP.getLaborSummaryMonthlyReportSP(DeptNumber);

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (var command = new SqlCommand(query, connection))
                {
                    

                    using (var reader = command.ExecuteReader())
                    {
                        return ParseDepartmentData(reader);
                    }
                }
            }
        }

        private static WftLaborSummaryData ParseDepartmentData(SqlDataReader reader)
        {
            var monthlyRows = new List<SqlMonthlyRow>();

            // Read exactly 12 rows (one per month)
            while (reader.Read())
            {
                monthlyRows.Add(ReadSingleRow(reader));
            }

            if (monthlyRows.Count == 0)
                return null;

            // Pivot 12 rows into single object with monthly properties
            return PivotToMonthlyData(monthlyRows);
        }

        // Helper class to hold a single row's data
        private class SqlMonthlyRow
        {
            public int MonthNum { get; set; }
            public string MonthName { get; set; }
            public int WftDepartment_ID { get; set; }
            public int Year { get; set; }
            public string DeptNumber { get; set; }
            public string DeptName { get; set; }
            public string FactilityDesc { get; set; }
            public string StatDescription { get; set; }
            public string DeptType { get; set; }

            // All numeric values for this month
            public double EmployedProductiveFtes { get; set; }
            public double ContractLaborPercent { get; set; }
            public double ContractFtes { get; set; }
            public double TotalProductiveFtes { get; set; }
            public double NonProductivePercent { get; set; }
            public double NonProductiveFtes { get; set; }
            public double EmployedPaidFtes { get; set; }
            public double TotalFtes { get; set; }
            public double TotalSalariesAndWages { get; set; }
            public double TotalContractLaborDollars { get; set; }
            public double TotalLaborExpense { get; set; }
            public double EmployedLaborRate { get; set; }
            public double ContactLaborRate { get; set; }
            public double OverTimePremiumDollars { get; set; }
            public double OtPercent { get; set; }
            public double OtFte { get; set; }
            public double DeptUOS { get; set; }
            public double SemiVariableFtes { get; set; }
            public double VariableProdHrsPerUOS { get; set; }
            public double TotalProdHrsPerUOS { get; set; }
            public double TotalPaidHrsPerUOS { get; set; }
            public double ProductiveMinFtes { get; set; }

            // Max values
            public double MaxEmployedProductiveFtes { get; set; }
            public double MaxContractLaborPercent { get; set; }
            public double MaxContractFtes { get; set; }
            public double MaxTotalProductiveFtes { get; set; }
            public double MaxNonProductivePercent { get; set; }
            public double MaxNonProductiveFtes { get; set; }
            public double MaxEmployedPaidFtes { get; set; }
            public double MaxTotalFtes { get; set; }
            public double MaxTotalSalariesAndWages { get; set; }
            public double MaxTotalContractLaborDollars { get; set; }
            public double MaxTotalLaborExpense { get; set; }
            public double MaxEmployedLaborRate { get; set; }
            public double MaxContactLaborRate { get; set; }
            public double MaxOverTimePremiumDollars { get; set; }
            public double MaxOtPercent { get; set; }
            public double MaxOtFte { get; set; }
            public double MaxDeptUOS { get; set; }
            public double MaxSemiVariableFtes { get; set; }
            public double MaxVariableProdHrsPerUOS { get; set; }
            public double MaxTotalProdHrsPerUOS { get; set; }
            public double MaxTotalPaidHrsPerUOS { get; set; }
            public double MaxProductiveMinFtes { get; set; }

            // Min values
            public double MinEmployedProductiveFtes { get; set; }
            public double MinContractLaborPercent { get; set; }
            public double MinContractFtes { get; set; }
            public double MinTotalProductiveFtes { get; set; }
            public double MinNonProductivePercent { get; set; }
            public double MinNonProductiveFtes { get; set; }
            public double MinEmployedPaidFtes { get; set; }
            public double MinTotalFtes { get; set; }
            public double MinTotalSalariesAndWages { get; set; }
            public double MinTotalContractLaborDollars { get; set; }
            public double MinTotalLaborExpense { get; set; }
            public double MinEmployedLaborRate { get; set; }
            public double MinContactLaborRate { get; set; }
            public double MinOverTimePremiumDollars { get; set; }
            public double MinOtPercent { get; set; }
            public double MinOtFte { get; set; }
            public double MinDeptUOS { get; set; }
            public double MinSemiVariableFtes { get; set; }
            public double MinVariableProdHrsPerUOS { get; set; }
            public double MinTotalProdHrsPerUOS { get; set; }
            public double MinTotalPaidHrsPerUOS { get; set; }
            public double MinProductiveMinFtes { get; set; }

            // Total values (will be same for all months, we'll take from last row)
            public double EmployedProductiveFtesTotal { get; set; }
            public double ContractLaborPercentTotal { get; set; }
            public double ContractFTEsTotal { get; set; }
            public double TotalProductiveFtesTotal { get; set; }
            public double NonProductivePercentTotal { get; set; }
            public double NonProductiveFtesTotal { get; set; }
            public double EmployedPaidFtesTotal { get; set; }
            public double TotalFtesTotal { get; set; }
            public double TotalSalariesAndWagesTotal { get; set; }
            public double TotalContractLaborDollarsTotal { get; set; }
            public double TotalLaborExpenseTotal { get; set; }
            public double EmployedLaborRateTotal { get; set; }
            public double ContractLaborRateTotal { get; set; }
            public double OTPremiumTotal { get; set; }
            public double OtPercentTotal { get; set; }
            public double OtFtesTotal { get; set; }
            public double DeptUOSTotal { get; set; }
            public double SemiVariableProductiveFtesTotal { get; set; }
            public double VariableProdHrsUOSTotal { get; set; }
            public double TotalProdHrsUOSTotal { get; set; }
            public double TotalPaidHrsUOSTotal { get; set; }
            public double ProductiveMinFtesTotal { get; set; }
        }

        private static SqlMonthlyRow ReadSingleRow(SqlDataReader reader)
        {
            return new SqlMonthlyRow
            {
                MonthNum = GetInt(reader, "MonthNum"),
                MonthName = GetString(reader, "MonthName"),
                WftDepartment_ID = GetInt(reader, "WftDepartment_ID"),
                Year = GetInt(reader, "Year"),
                DeptNumber = GetString(reader, "DeptNumber"),
                DeptName = GetString(reader, "DeptName"),
                FactilityDesc = GetString(reader, "FactilityDesc"),
                StatDescription = GetString(reader, "StatDescription"),
                DeptType = GetString(reader, "DeptType"),

                EmployedProductiveFtes = GetDouble(reader, "EmployedProductiveFtes"),
                ContractLaborPercent = GetDouble(reader, "ContractLaborPercent"),
                ContractFtes = GetDouble(reader, "ContractFtes"),
                TotalProductiveFtes = GetDouble(reader, "TotalProductiveFtes"),
                NonProductivePercent = GetDouble(reader, "NonProductivePercent"),
                NonProductiveFtes = GetDouble(reader, "NonProductiveFtes"),
                EmployedPaidFtes = GetDouble(reader, "EmployedPaidFtes"),
                TotalFtes = GetDouble(reader, "TotalFtes"),
                TotalSalariesAndWages = GetDouble(reader, "TotalSalariesAndWages"),
                TotalContractLaborDollars = GetDouble(reader, "TotalContractLaborDollars"),
                TotalLaborExpense = GetDouble(reader, "TotalLaborExpense"),
                EmployedLaborRate = GetDouble(reader, "EmployedLaborRate"),
                ContactLaborRate = GetDouble(reader, "ContactLaborRate"),
                OverTimePremiumDollars = GetDouble(reader, "OverTimePremiumDollars"),
                OtPercent = GetDouble(reader, "OtPercent"),
                OtFte = GetDouble(reader, "OtFte"),
                DeptUOS = GetDouble(reader, "DeptUOS"),
                SemiVariableFtes = GetDouble(reader, "SemiVariableFtes"),
                VariableProdHrsPerUOS = GetDouble(reader, "VariableProdHrsPerUOS"),
                TotalProdHrsPerUOS = GetDouble(reader, "TotalProdHrsPerUOS"),
                TotalPaidHrsPerUOS = GetDouble(reader, "TotalPaidHrsPerUOS"),
                ProductiveMinFtes = GetDouble(reader, "ProductiveMinFtes"),

                MaxEmployedProductiveFtes = GetDouble(reader, "MaxEmployedProductiveFtes"),
                MaxContractLaborPercent = GetDouble(reader, "MaxContractLaborPercent"),
                MaxContractFtes = GetDouble(reader, "MaxContractFtes"),
                MaxTotalProductiveFtes = GetDouble(reader, "MaxTotalProductiveFtes"),
                MaxNonProductivePercent = GetDouble(reader, "MaxNonProductivePercent"),
                MaxNonProductiveFtes = GetDouble(reader, "MaxNonProductiveFtes"),
                MaxEmployedPaidFtes = GetDouble(reader, "MaxEmployedPaidFtes"),
                MaxTotalFtes = GetDouble(reader, "MaxTotalFtes"),
                MaxTotalSalariesAndWages = GetDouble(reader, "MaxTotalSalariesAndWages"),
                MaxTotalContractLaborDollars = GetDouble(reader, "MaxTotalContractLaborDollars"),
                MaxTotalLaborExpense = GetDouble(reader, "MaxTotalLaborExpense"),
                MaxEmployedLaborRate = GetDouble(reader, "MaxEmployedLaborRate"),
                MaxContactLaborRate = GetDouble(reader, "MaxContactLaborRate"),
                MaxOverTimePremiumDollars = GetDouble(reader, "MaxOverTimePremiumDollars"),
                MaxOtPercent = GetDouble(reader, "MaxOtPercent"),
                MaxOtFte = GetDouble(reader, "MaxOtFte"),
                MaxDeptUOS = GetDouble(reader, "MaxDeptUOS"),
                MaxSemiVariableFtes = GetDouble(reader, "MaxSemiVariableFtes"),
                MaxVariableProdHrsPerUOS = GetDouble(reader, "MaxVariableProdHrsPerUOS"),
                MaxTotalProdHrsPerUOS = GetDouble(reader, "MaxTotalProdHrsPerUOS"),
                MaxTotalPaidHrsPerUOS = GetDouble(reader, "MaxTotalPaidHrsPerUOS"),
                MaxProductiveMinFtes = GetDouble(reader, "MaxProductiveMinFtes"),

                MinEmployedProductiveFtes = GetDouble(reader, "MinEmployedProductiveFtes"),
                MinContractLaborPercent = GetDouble(reader, "MinContractLaborPercent"),
                MinContractFtes = GetDouble(reader, "MinContractFtes"),
                MinTotalProductiveFtes = GetDouble(reader, "MinTotalProductiveFtes"),
                MinNonProductivePercent = GetDouble(reader, "MinNonProductivePercent"),
                MinNonProductiveFtes = GetDouble(reader, "MinNonProductiveFtes"),
                MinEmployedPaidFtes = GetDouble(reader, "MinEmployedPaidFtes"),
                MinTotalFtes = GetDouble(reader, "MinTotalFtes"),
                MinTotalSalariesAndWages = GetDouble(reader, "MinTotalSalariesAndWages"),
                MinTotalContractLaborDollars = GetDouble(reader, "MinTotalContractLaborDollars"),
                MinTotalLaborExpense = GetDouble(reader, "MinTotalLaborExpense"),
                MinEmployedLaborRate = GetDouble(reader, "MinEmployedLaborRate"),
                MinContactLaborRate = GetDouble(reader, "MinContactLaborRate"),
                MinOverTimePremiumDollars = GetDouble(reader, "MinOverTimePremiumDollars"),
                MinOtPercent = GetDouble(reader, "MinOtPercent"),
                MinOtFte = GetDouble(reader, "MinOtFte"),
                MinDeptUOS = GetDouble(reader, "MinDeptUOS"),
                MinSemiVariableFtes = GetDouble(reader, "MinSemiVariableFtes"),
                MinVariableProdHrsPerUOS = GetDouble(reader, "MinVariableProdHrsPerUOS"),
                MinTotalProdHrsPerUOS = GetDouble(reader, "MinTotalProdHrsPerUOS"),
                MinTotalPaidHrsPerUOS = GetDouble(reader, "MinTotalPaidHrsPerUOS"),
                MinProductiveMinFtes = GetDouble(reader, "MinProductiveMinFtes"),

                EmployedProductiveFtesTotal = GetDouble(reader, "EmployedProductiveFtesTotal"),
                ContractLaborPercentTotal = GetDouble(reader, "ContractLaborPercentTotal"),
                ContractFTEsTotal = GetDouble(reader, "ContractFTEsTotal"),
                TotalProductiveFtesTotal = GetDouble(reader, "TotalProductiveFtesTotal"),
                NonProductivePercentTotal = GetDouble(reader, "NonProductivePercentTotal"),
                NonProductiveFtesTotal = GetDouble(reader, "NonProductiveFtesTotal"),
                EmployedPaidFtesTotal = GetDouble(reader, "EmployedPaidFtesTotal"),
                TotalFtesTotal = GetDouble(reader, "TotalFtesTotal"),
                TotalSalariesAndWagesTotal = GetDouble(reader, "TotalSalariesAndWagesTotal"),
                TotalContractLaborDollarsTotal = GetDouble(reader, "TotalContractLaborDollarsTotal"),
                TotalLaborExpenseTotal = GetDouble(reader, "TotalLaborExpenseTotal"),
                EmployedLaborRateTotal = GetDouble(reader, "EmployedLaborRateTotal"),
                ContractLaborRateTotal = GetDouble(reader, "ContractLaborRateTotal"),
                OTPremiumTotal = GetDouble(reader, "OTPremiumTotal"),
                OtPercentTotal = GetDouble(reader, "OtPercentTotal"),
                OtFtesTotal = GetDouble(reader, "OtFtesTotal"),
                DeptUOSTotal = GetDouble(reader, "DeptUOSTotal"),
                SemiVariableProductiveFtesTotal = GetDouble(reader, "SemiVariableProductiveFtesTotal"),
                VariableProdHrsUOSTotal = GetDouble(reader, "VariableProdHrsUOSTotal"),
                TotalProdHrsUOSTotal = GetDouble(reader, "TotalProdHrsUOSTotal"),
                TotalPaidHrsUOSTotal = GetDouble(reader, "TotalPaidHrsUOSTotal"),
                ProductiveMinFtesTotal = GetDouble(reader, "ProductiveMinFtesTotal")
            };
        }

        private static WftLaborSummaryData PivotToMonthlyData(List<SqlMonthlyRow> monthlyRows)
        {
            if (monthlyRows.Count == 0) return null;

            var data = new WftLaborSummaryData();
            var firstRow = monthlyRows.First();

            // Set basic info from first row
            data.WftDepartment_ID = firstRow.WftDepartment_ID;
            data.Year = firstRow.Year;
            data.DeptNumber = firstRow.DeptNumber;
            data.DeptName = firstRow.DeptName;
            data.FactilityDesc = firstRow.FactilityDesc;
            data.StatDescription = firstRow.StatDescription;
            data.DeptType = firstRow.DeptType;

            // Pivot each month's data into the monthly properties
            foreach (var row in monthlyRows)
            {
                SetMonthValue(data.EmployedProductiveFtes, row.MonthNum, row.EmployedProductiveFtes);
                SetMonthValue(data.ContractLaborPercent, row.MonthNum, row.ContractLaborPercent);
                SetMonthValue(data.ContractFtes, row.MonthNum, row.ContractFtes);
                SetMonthValue(data.TotalProductiveFtes, row.MonthNum, row.TotalProductiveFtes);
                SetMonthValue(data.NonProductivePercent, row.MonthNum, row.NonProductivePercent);
                SetMonthValue(data.NonProductiveFtes, row.MonthNum, row.NonProductiveFtes);
                SetMonthValue(data.EmployedPaidFtes, row.MonthNum, row.EmployedPaidFtes);
                SetMonthValue(data.TotalFtes, row.MonthNum, row.TotalFtes);

                SetMonthValue(data.TotalSalariesAndWages, row.MonthNum, row.TotalSalariesAndWages);
                SetMonthValue(data.TotalContractLaborDollars, row.MonthNum, row.TotalContractLaborDollars);
                SetMonthValue(data.TotalLaborExpense, row.MonthNum, row.TotalLaborExpense);
                SetMonthValue(data.EmployedLaborRate, row.MonthNum, row.EmployedLaborRate);
                SetMonthValue(data.ContactLaborRate, row.MonthNum, row.ContactLaborRate);
                SetMonthValue(data.OverTimePremiumDollars, row.MonthNum, row.OverTimePremiumDollars);
                SetMonthValue(data.OtPercent, row.MonthNum, row.OtPercent);
                SetMonthValue(data.OtFte, row.MonthNum, row.OtFte);

                SetMonthValue(data.DeptUOS, row.MonthNum, row.DeptUOS);
                SetMonthValue(data.SemiVariableFtes, row.MonthNum, row.SemiVariableFtes);
                SetMonthValue(data.VariableProdHrsPerUOS, row.MonthNum, row.VariableProdHrsPerUOS);
                SetMonthValue(data.TotalProdHrsPerUOS, row.MonthNum, row.TotalProdHrsPerUOS);
                SetMonthValue(data.TotalPaidHrsPerUOS, row.MonthNum, row.TotalPaidHrsPerUOS);
                SetMonthValue(data.ProductiveMinFtes, row.MonthNum, row.ProductiveMinFtes);

                // Max values
                SetMonthValue(data.MaxEmployedProductiveFtes, row.MonthNum, row.MaxEmployedProductiveFtes);
                SetMonthValue(data.MaxContractLaborPercent, row.MonthNum, row.MaxContractLaborPercent);
                SetMonthValue(data.MaxContractFtes, row.MonthNum, row.MaxContractFtes);
                SetMonthValue(data.MaxTotalProductiveFtes, row.MonthNum, row.MaxTotalProductiveFtes);
                SetMonthValue(data.MaxNonProductivePercent, row.MonthNum, row.MaxNonProductivePercent);
                SetMonthValue(data.MaxNonProductiveFtes, row.MonthNum, row.MaxNonProductiveFtes);
                SetMonthValue(data.MaxEmployedPaidFtes, row.MonthNum, row.MaxEmployedPaidFtes);
                SetMonthValue(data.MaxTotalFtes, row.MonthNum, row.MaxTotalFtes);
                SetMonthValue(data.MaxTotalSalariesAndWages, row.MonthNum, row.MaxTotalSalariesAndWages);
                SetMonthValue(data.MaxTotalContractLaborDollars, row.MonthNum, row.MaxTotalContractLaborDollars);
                SetMonthValue(data.MaxTotalLaborExpense, row.MonthNum, row.MaxTotalLaborExpense);
                SetMonthValue(data.MaxEmployedLaborRate, row.MonthNum, row.MaxEmployedLaborRate);
                SetMonthValue(data.MaxContactLaborRate, row.MonthNum, row.MaxContactLaborRate);
                SetMonthValue(data.MaxOverTimePremiumDollars, row.MonthNum, row.MaxOverTimePremiumDollars);
                SetMonthValue(data.MaxOtPercent, row.MonthNum, row.MaxOtPercent);
                SetMonthValue(data.MaxOtFte, row.MonthNum, row.MaxOtFte);
                SetMonthValue(data.MaxDeptUOS, row.MonthNum, row.MaxDeptUOS);
                SetMonthValue(data.MaxSemiVariableFtes, row.MonthNum, row.MaxSemiVariableFtes);
                SetMonthValue(data.MaxVariableProdHrsPerUOS, row.MonthNum, row.MaxVariableProdHrsPerUOS);
                SetMonthValue(data.MaxTotalProdHrsPerUOS, row.MonthNum, row.MaxTotalProdHrsPerUOS);
                SetMonthValue(data.MaxTotalPaidHrsPerUOS, row.MonthNum, row.MaxTotalPaidHrsPerUOS);
                SetMonthValue(data.MaxProductiveMinFtes, row.MonthNum, row.MaxProductiveMinFtes);

                // Min values
                SetMonthValue(data.MinEmployedProductiveFtes, row.MonthNum, row.MinEmployedProductiveFtes);
                SetMonthValue(data.MinContractLaborPercent, row.MonthNum, row.MinContractLaborPercent);
                SetMonthValue(data.MinContractFtes, row.MonthNum, row.MinContractFtes);
                SetMonthValue(data.MinTotalProductiveFtes, row.MonthNum, row.MinTotalProductiveFtes);
                SetMonthValue(data.MinNonProductivePercent, row.MonthNum, row.MinNonProductivePercent);
                SetMonthValue(data.MinNonProductiveFtes, row.MonthNum, row.MinNonProductiveFtes);
                SetMonthValue(data.MinEmployedPaidFtes, row.MonthNum, row.MinEmployedPaidFtes);
                SetMonthValue(data.MinTotalFtes, row.MonthNum, row.MinTotalFtes);
                SetMonthValue(data.MinTotalSalariesAndWages, row.MonthNum, row.MinTotalSalariesAndWages);
                SetMonthValue(data.MinTotalContractLaborDollars, row.MonthNum, row.MinTotalContractLaborDollars);
                SetMonthValue(data.MinTotalLaborExpense, row.MonthNum, row.MinTotalLaborExpense);
                SetMonthValue(data.MinEmployedLaborRate, row.MonthNum, row.MinEmployedLaborRate);
                SetMonthValue(data.MinContactLaborRate, row.MonthNum, row.MinContactLaborRate);
                SetMonthValue(data.MinOverTimePremiumDollars, row.MonthNum, row.MinOverTimePremiumDollars);
                SetMonthValue(data.MinOtPercent, row.MonthNum, row.MinOtPercent);
                SetMonthValue(data.MinOtFte, row.MonthNum, row.MinOtFte);
                SetMonthValue(data.MinDeptUOS, row.MonthNum, row.MinDeptUOS);
                SetMonthValue(data.MinSemiVariableFtes, row.MonthNum, row.MinSemiVariableFtes);
                SetMonthValue(data.MinVariableProdHrsPerUOS, row.MonthNum, row.MinVariableProdHrsPerUOS);
                SetMonthValue(data.MinTotalProdHrsPerUOS, row.MonthNum, row.MinTotalProdHrsPerUOS);
                SetMonthValue(data.MinTotalPaidHrsPerUOS, row.MonthNum, row.MinTotalPaidHrsPerUOS);
                SetMonthValue(data.MinProductiveMinFtes, row.MonthNum, row.MinProductiveMinFtes);
            }

            // Set Total values from last row (they're the same for all months)
            var lastRow = monthlyRows.Last();
            data.EmployedProductiveFtes.Total = lastRow.EmployedProductiveFtesTotal;
            data.ContractLaborPercent.Total = lastRow.ContractLaborPercentTotal;
            data.ContractFtes.Total = lastRow.ContractFTEsTotal;
            data.TotalProductiveFtes.Total = lastRow.TotalProductiveFtesTotal;
            data.NonProductivePercent.Total = lastRow.NonProductivePercentTotal;
            data.NonProductiveFtes.Total = lastRow.NonProductiveFtesTotal;
            data.EmployedPaidFtes.Total = lastRow.EmployedPaidFtesTotal;
            data.TotalFtes.Total = lastRow.TotalFtesTotal;
            data.TotalSalariesAndWages.Total = lastRow.TotalSalariesAndWagesTotal;
            data.TotalContractLaborDollars.Total = lastRow.TotalContractLaborDollarsTotal;
            data.TotalLaborExpense.Total = lastRow.TotalLaborExpenseTotal;
            data.EmployedLaborRate.Total = lastRow.EmployedLaborRateTotal;
            data.ContactLaborRate.Total = lastRow.ContractLaborRateTotal;
            data.OverTimePremiumDollars.Total = lastRow.OTPremiumTotal;
            data.OtPercent.Total = lastRow.OtPercentTotal;
            data.OtFte.Total = lastRow.OtFtesTotal;
            data.DeptUOS.Total = lastRow.DeptUOSTotal;
            data.SemiVariableFtes.Total = lastRow.SemiVariableProductiveFtesTotal;
            data.VariableProdHrsPerUOS.Total = lastRow.VariableProdHrsUOSTotal;
            data.TotalProdHrsPerUOS.Total = lastRow.TotalProdHrsUOSTotal;
            data.TotalPaidHrsPerUOS.Total = lastRow.TotalPaidHrsUOSTotal;
            data.ProductiveMinFtes.Total = lastRow.ProductiveMinFtesTotal;

            return data;
        }

        private static void SetMonthValue(MonthlyData monthlyData, int monthNum, double value)
        {
            switch (monthNum)
            {
                case 1: monthlyData.Jan = value; break;
                case 2: monthlyData.Feb = value; break;
                case 3: monthlyData.Mar = value; break;
                case 4: monthlyData.Apr = value; break;
                case 5: monthlyData.May = value; break;
                case 6: monthlyData.Jun = value; break;
                case 7: monthlyData.Jul = value; break;
                case 8: monthlyData.Aug = value; break;
                case 9: monthlyData.Sep = value; break;
                case 10: monthlyData.Oct = value; break;
                case 11: monthlyData.Nov = value; break;
                case 12: monthlyData.Dec = value; break;
            }
        }

        private static int GetInt(SqlDataReader reader, string columnName)
        {
            var ordinal = reader.GetOrdinal(columnName);
            // Convert.ToInt32 safely converts both Int32 and Int64 to int
            return reader.IsDBNull(ordinal) ? 0 : Convert.ToInt32(reader.GetValue(ordinal));
        }

        private static double GetDouble(SqlDataReader reader, string columnName)
        {
            var ordinal = reader.GetOrdinal(columnName);
            if (reader.IsDBNull(ordinal)) return 0.0;

            var value = reader.GetValue(ordinal);
            if (value is double d) return d;
            if (value is decimal dec) return (double)dec;
            if (value is float f) return (double)f;
            if (value is int i) return (double)i;

            return Math.Round(Convert.ToDouble(value),2);
        }

        private static string GetString(SqlDataReader reader, string columnName)
        {
            var ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? string.Empty : reader.GetValue(ordinal).ToString();
        }
    }
}