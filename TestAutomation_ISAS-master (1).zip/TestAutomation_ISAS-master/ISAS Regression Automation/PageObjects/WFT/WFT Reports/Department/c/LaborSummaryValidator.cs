﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Validates Labor Summary data between Excel and Database using NUnit assertions
    /// </summary>
    public class LaborSummaryValidator
    {
        private const double TOLERANCE = 0.02; // Comparison tolerance

        /// <summary>
                /// Validate all sections (FTE, Labor Expense, Volume) between Excel and Database
                /// Throws AssertionException if any mismatches are found
                /// </summary>
                /// <param name="excelData">Data from Excel</param>
                /// <param name="dbData">Data from Database</param>
        public static void Validate(DepartmentData excelData, WftLaborSummaryData dbData)
        {
            Console.WriteLine($"=== Validating Department {excelData.Info.DeptNumber} ===\n");

            var results = CompareAllSections(excelData, dbData);

            // Print summary
            PrintValidationSummary(results);

            // Print mismatches if any
            var mismatches = GetAllMismatches(results);
            if (mismatches.Any())
            {
                PrintDetailedMismatches(results);

                // Build assertion failure message
                var message = BuildFailureMessage(results, mismatches);
                Assert.Fail(message);
            }
            else
            {
                Console.WriteLine("✓ All validations passed!");
            }
        }

        /// <summary>
                /// Validate FTE Summary section only
                /// </summary>
        public static void ValidateFTESummary(DepartmentData excelData, WftLaborSummaryData dbData)
        {
            Console.WriteLine("=== Validating FTE Summary ===\n");

            var result = CompareFTESummary(excelData.FTESummary, dbData);

            if (result.MismatchCount > 0)
            {
                var message = $"FTE Summary validation failed: {result.MismatchCount} mismatches found out of {result.TotalComparisons} comparisons";
                PrintSectionMismatches(result);
                Assert.Fail(message);
            }

            Console.WriteLine($"✓ FTE Summary validated: {result.TotalComparisons} comparisons passed\n");
        }

        /// <summary>
                /// Validate Labor Expense Summary section only
                /// </summary>
        public static void ValidateLaborExpenseSummary(DepartmentData excelData, WftLaborSummaryData dbData)
        {
            Console.WriteLine("=== Validating Labor Expense Summary ===\n");

            var result = CompareLaborExpenseSummary(excelData.LaborExpenseSummary, dbData);

            if (result.MismatchCount > 0)
            {
                var message = $"Labor Expense Summary validation failed: {result.MismatchCount} mismatches found out of {result.TotalComparisons} comparisons";
                PrintSectionMismatches(result);
                Assert.Fail(message);
            }

            Console.WriteLine($"✓ Labor Expense Summary validated: {result.TotalComparisons} comparisons passed\n");
        }

        /// <summary>
                /// Validate Volume Summary section only
                /// </summary>
        public static void ValidateVolumeSummary(DepartmentData excelData, WftLaborSummaryData dbData)
        {
            Console.WriteLine("=== Validating Volume Summary ===\n");

            var result = CompareVolumeSummary(excelData.VolumeSummary, dbData);

            if (result.MismatchCount > 0)
            {
                var message = $"Volume Summary validation failed: {result.MismatchCount} mismatches found out of {result.TotalComparisons} comparisons";
                PrintSectionMismatches(result);
                Assert.Fail(message);
            }

            Console.WriteLine($"✓ Volume Summary validated: {result.TotalComparisons} comparisons passed\n");
        }

        /// <summary>
                /// Assert that a specific metric matches between Excel and Database
                /// </summary>
        public static void AssertMetricEquals(string metricName, MonthlyData excelData, MonthlyData dbData)
        {
            var comparisons = CompareMonthlyData(metricName, excelData, dbData);
            var mismatches = comparisons.Where(c => !c.IsMatch).ToList();

            if (mismatches.Any())
            {
                var sb = new StringBuilder();
                sb.AppendLine($"{metricName} validation failed:");
                foreach (var mismatch in mismatches)
                {
                    sb.AppendLine($"  {mismatch.Month}: Excel={mismatch.ExcelValue:N2}, DB={mismatch.DbValue:N2}");
                }
                Assert.Fail(sb.ToString());
            }
        }

        #region Private Comparison Methods

        private static List<ComparisonSummary> CompareAllSections(
      DepartmentData excelData,
      WftLaborSummaryData dbData)
        {
            var results = new List<ComparisonSummary>();

            results.Add(CompareFTESummary(excelData.FTESummary, dbData));
            results.Add(CompareLaborExpenseSummary(excelData.LaborExpenseSummary, dbData));
            results.Add(CompareVolumeSummary(excelData.VolumeSummary, dbData));

            return results;
        }

        private static ComparisonSummary CompareFTESummary(
          DepartmentFTESummary excelFte,
          WftLaborSummaryData dbData)
        {
            var summary = new ComparisonSummary("FTE Summary");
            var comparisons = new List<MetricComparison>();

            comparisons.AddRange(CompareMonthlyData("Employed Productive FTEs",
              excelFte.EmployedProductiveFTEs, dbData.EmployedProductiveFtes));
            comparisons.AddRange(CompareMonthlyData("Contract Labor %",
              excelFte.ContractLaborPercent, dbData.ContractLaborPercent));
            comparisons.AddRange(CompareMonthlyData("Contract FTEs",
              excelFte.ContractFTEs, dbData.ContractFtes));
            comparisons.AddRange(CompareMonthlyData("Total Productive FTEs",
              excelFte.TotalProductiveFTEs, dbData.TotalProductiveFtes));
            comparisons.AddRange(CompareMonthlyData("Non-Producing %",
              excelFte.NonProducingPercent, dbData.NonProductivePercent));
            comparisons.AddRange(CompareMonthlyData("Non-Productive FTEs",
              excelFte.NonProductiveFTEs, dbData.NonProductiveFtes));
            comparisons.AddRange(CompareMonthlyData("Employed Paid FTEs",
              excelFte.EmployedPaidFTEs, dbData.EmployedPaidFtes));
            comparisons.AddRange(CompareMonthlyData("Total FTEs (Paid and Contract)",
              excelFte.TotalFTEsPaidAndContract, dbData.TotalFtes));

            summary.TotalComparisons = comparisons.Count;
            summary.MatchCount = comparisons.Count(c => c.IsMatch);
            summary.MismatchCount = comparisons.Count(c => !c.IsMatch);
            summary.Mismatches = comparisons.Where(c => !c.IsMatch).ToList();

            return summary;
        }

        private static ComparisonSummary CompareLaborExpenseSummary(
          DepartmentLaborExpenseSummary excelLabor,
          WftLaborSummaryData dbData)
        {
            var summary = new ComparisonSummary("Labor Expense Summary");
            var comparisons = new List<MetricComparison>();

            comparisons.AddRange(CompareMonthlyData("Total Salaries and Wages",
              excelLabor.TotalSalariesAndWages, dbData.TotalSalariesAndWages));
            comparisons.AddRange(CompareMonthlyData("Total Contract Labor",
              excelLabor.TotalContractLabor, dbData.TotalContractLaborDollars));
            comparisons.AddRange(CompareMonthlyData("Total Labor Cost",
              excelLabor.TotalLaborCost, dbData.TotalLaborExpense));
            comparisons.AddRange(CompareMonthlyData("Employed Labor Rate",
              excelLabor.EmployedLaborRate, dbData.EmployedLaborRate));
            comparisons.AddRange(CompareMonthlyData("Contract Labor Rate",
              excelLabor.ContractLaborRate, dbData.ContactLaborRate));
            comparisons.AddRange(CompareMonthlyData("Overtime Premium Dollars",
              excelLabor.OvertimePremiumDollars, dbData.OverTimePremiumDollars));
            comparisons.AddRange(CompareMonthlyData("Overtime %",
              excelLabor.OvertimePercent, dbData.OtPercent));
            comparisons.AddRange(CompareMonthlyData("Overtime FTEs",
              excelLabor.OvertimeFTEs, dbData.OtFte));

            summary.TotalComparisons = comparisons.Count;
            summary.MatchCount = comparisons.Count(c => c.IsMatch);
            summary.MismatchCount = comparisons.Count(c => !c.IsMatch);
            summary.Mismatches = comparisons.Where(c => !c.IsMatch).ToList();

            return summary;
        }

        private static ComparisonSummary CompareVolumeSummary(
          DepartmentVolumeSummary excelVolume,
          WftLaborSummaryData dbData)
        {
            var summary = new ComparisonSummary("Volume Summary");
            var comparisons = new List<MetricComparison>();

            comparisons.AddRange(CompareMonthlyData("Department UOS",
              excelVolume.DepartmentUOS, dbData.DeptUOS));
            comparisons.AddRange(CompareMonthlyData("Semi-Variable FTEs",
              excelVolume.SemiVariableFTEs, dbData.SemiVariableFtes));
            comparisons.AddRange(CompareMonthlyData("Variable Productive Hrs/UOS",
              excelVolume.VariableProductiveHrsPerUOS, dbData.VariableProdHrsPerUOS));
            comparisons.AddRange(CompareMonthlyData("Min FTEs",
              excelVolume.MinFTEs, dbData.ProductiveMinFtes));
            comparisons.AddRange(CompareMonthlyData("Total Productive Hrs/UOS",
              excelVolume.TotalProductiveHrsPerUOS, dbData.TotalProdHrsPerUOS));

            summary.TotalComparisons = comparisons.Count;
            summary.MatchCount = comparisons.Count(c => c.IsMatch);
            summary.MismatchCount = comparisons.Count(c => !c.IsMatch);
            summary.Mismatches = comparisons.Where(c => !c.IsMatch).ToList();

            return summary;
        }

        private static List<MetricComparison> CompareMonthlyData(
          string metricName,
          MonthlyData excelData,
          MonthlyData dbData)
        {
            var comparisons = new List<MetricComparison>
      {
        new MetricComparison(metricName, "Jan", excelData.Jan, dbData.Jan, TOLERANCE),
        new MetricComparison(metricName, "Feb", excelData.Feb, dbData.Feb, TOLERANCE),
        new MetricComparison(metricName, "Mar", excelData.Mar, dbData.Mar, TOLERANCE),
        new MetricComparison(metricName, "Apr", excelData.Apr, dbData.Apr, TOLERANCE),
        new MetricComparison(metricName, "May", excelData.May, dbData.May, TOLERANCE),
        new MetricComparison(metricName, "Jun", excelData.Jun, dbData.Jun, TOLERANCE),
        new MetricComparison(metricName, "Jul", excelData.Jul, dbData.Jul, TOLERANCE),
        new MetricComparison(metricName, "Aug", excelData.Aug, dbData.Aug, TOLERANCE),
        new MetricComparison(metricName, "Sep", excelData.Sep, dbData.Sep, TOLERANCE),
        new MetricComparison(metricName, "Oct", excelData.Oct, dbData.Oct, TOLERANCE),
        new MetricComparison(metricName, "Nov", excelData.Nov, dbData.Nov, TOLERANCE),
        new MetricComparison(metricName, "Dec", excelData.Dec, dbData.Dec, TOLERANCE),
        new MetricComparison(metricName, "Total", excelData.Total, dbData.Total, TOLERANCE)
      };

            return comparisons;
        }

        #endregion

        #region Helper Classes

        public class MetricComparison
        {
            public string MetricName { get; set; }
            public string Month { get; set; }
            public double ExcelValue { get; set; }
            public double DbValue { get; set; }
            public bool IsMatch { get; set; }

            public MetricComparison(string metricName, string month, double excelValue, double dbValue, double tolerance)
            {
                MetricName = metricName;
                Month = month;
                ExcelValue = excelValue;
                DbValue = dbValue;
                IsMatch = Math.Abs(excelValue - dbValue) <= tolerance;
            }
        }

        public class ComparisonSummary
        {
            public string SectionName { get; set; }
            public int TotalComparisons { get; set; }
            public int MatchCount { get; set; }
            public int MismatchCount { get; set; }
            public List<MetricComparison> Mismatches { get; set; }

            public double MatchPercentage => TotalComparisons > 0 ? (MatchCount * 100.0 / TotalComparisons) : 0;

            public ComparisonSummary(string sectionName)
            {
                SectionName = sectionName;
                Mismatches = new List<MetricComparison>();
            }
        }

        #endregion

        #region Output Methods

        private static List<MetricComparison> GetAllMismatches(List<ComparisonSummary> summaries)
        {
            return summaries.SelectMany(s => s.Mismatches).ToList();
        }

        private static string BuildFailureMessage(List<ComparisonSummary> summaries, List<MetricComparison> mismatches)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Labor Summary Validation Failed");
            sb.AppendLine();

            int totalComparisons = summaries.Sum(s => s.TotalComparisons);
            int totalMismatches = summaries.Sum(s => s.MismatchCount);

            sb.AppendLine($"Total Comparisons: {totalComparisons}");
            sb.AppendLine($"Failed: {totalMismatches}");
            sb.AppendLine($"Success Rate: {((totalComparisons - totalMismatches) * 100.0 / totalComparisons):N1}%");
            sb.AppendLine();

            foreach (var summary in summaries.Where(s => s.MismatchCount > 0))
            {
                sb.AppendLine($"{summary.SectionName}: {summary.MismatchCount} mismatches");
            }

            return sb.ToString();
        }

        private static void PrintValidationSummary(List<ComparisonSummary> summaries)
        {
            Console.WriteLine("=== Validation Summary ===\n");

            foreach (var summary in summaries)
            {
                var status = summary.MismatchCount == 0 ? "✓ PASS" : "✗ FAIL";
                Console.WriteLine($"{status} | {summary.SectionName}");
                Console.WriteLine($"      Comparisons: {summary.TotalComparisons}");
                Console.WriteLine($"      Matches: {summary.MatchCount} ({summary.MatchPercentage:N1}%)");
                if (summary.MismatchCount > 0)
                {
                    Console.WriteLine($"      Mismatches: {summary.MismatchCount}");
                }
                Console.WriteLine();
            }
        }

        private static void PrintDetailedMismatches(List<ComparisonSummary> summaries)
        {
            Console.WriteLine("=== Validation Failures ===\n");

            foreach (var summary in summaries.Where(s => s.MismatchCount > 0))
            {
                Console.WriteLine($"--- {summary.SectionName} ({summary.MismatchCount} mismatches) ---");
                Console.WriteLine($"{"Metric",-35} {"Month",-8} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 70));

                foreach (var mismatch in summary.Mismatches)
                {
                    Console.WriteLine($"{mismatch.MetricName,-35} {mismatch.Month,-8} " +
                            $"{mismatch.ExcelValue,12:N2} {mismatch.DbValue,12:N2}");
                }

                Console.WriteLine();
            }
        }

        private static void PrintSectionMismatches(ComparisonSummary summary)
        {
            Console.WriteLine($"\n{"Metric",-35} {"Month",-8} {"Excel",12} {"DB",12}");
            Console.WriteLine(new string('-', 70));

            foreach (var mismatch in summary.Mismatches)
            {
                Console.WriteLine($"{mismatch.MetricName,-35} {mismatch.Month,-8} " +
                        $"{mismatch.ExcelValue,12:N2} {mismatch.DbValue,12:N2}");
            }
            Console.WriteLine();
        }

        #endregion
    }
}