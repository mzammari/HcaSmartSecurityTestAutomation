﻿using System;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Represents departmental labor summary data from WFT database
    /// Each property contains monthly values (Jan-Dec) plus Total
    /// </summary>
    public class WftLaborSummaryData
    {
        // Basic Identifiers
        public int WftDepartment_ID { get; set; }
        public int Year { get; set; }
        public string DeptNumber { get; set; }
        public string DeptName { get; set; }
        public string FactilityDesc { get; set; }
        public string StatDescription { get; set; }
        public string DeptType { get; set; }

        // FTE Summary - Actual Values (each contains Jan-Dec + Total)
        public WftEmployedProductiveFtes EmployedProductiveFtes { get; set; }
        public WftContractLaborPercent ContractLaborPercent { get; set; }
        public WftContractFtes ContractFtes { get; set; }
        public WftTotalProductiveFtes TotalProductiveFtes { get; set; }
        public WftNonProductivePercent NonProductivePercent { get; set; }
        public WftNonProductiveFtes NonProductiveFtes { get; set; }
        public WftEmployedPaidFtes EmployedPaidFtes { get; set; }
        public WftTotalFtes TotalFtes { get; set; }

        // Labor Expense Summary - Actual Values
        public WftTotalSalariesAndWages TotalSalariesAndWages { get; set; }
        public WftTotalContractLaborDollars TotalContractLaborDollars { get; set; }
        public WftTotalLaborExpense TotalLaborExpense { get; set; }
        public WftEmployedLaborRate EmployedLaborRate { get; set; }
        public WftContactLaborRate ContactLaborRate { get; set; }
        public WftOverTimePremiumDollars OverTimePremiumDollars { get; set; }
        public WftOtPercent OtPercent { get; set; }
        public WftOtFte OtFte { get; set; }

        // Volume Summary - Actual Values
        public WftDeptUOS DeptUOS { get; set; }
        public WftSemiVariableFtes SemiVariableFtes { get; set; }
        public WftVariableProdHrsPerUOS VariableProdHrsPerUOS { get; set; }
        public WftTotalProdHrsPerUOS TotalProdHrsPerUOS { get; set; }
        public WftTotalPaidHrsPerUOS TotalPaidHrsPerUOS { get; set; }
        public WftProductiveMinFtes ProductiveMinFtes { get; set; }

        // Maximum (Budget/Target) Values - FTE Summary
        public WftMaxEmployedProductiveFtes MaxEmployedProductiveFtes { get; set; }
        public WftMaxContractLaborPercent MaxContractLaborPercent { get; set; }
        public WftMaxContractFtes MaxContractFtes { get; set; }
        public WftMaxTotalProductiveFtes MaxTotalProductiveFtes { get; set; }
        public WftMaxNonProductivePercent MaxNonProductivePercent { get; set; }
        public WftMaxNonProductiveFtes MaxNonProductiveFtes { get; set; }
        public WftMaxEmployedPaidFtes MaxEmployedPaidFtes { get; set; }
        public WftMaxTotalFtes MaxTotalFtes { get; set; }

        // Maximum (Budget/Target) Values - Labor Expense
        public WftMaxTotalSalariesAndWages MaxTotalSalariesAndWages { get; set; }
        public WftMaxTotalContractLaborDollars MaxTotalContractLaborDollars { get; set; }
        public WftMaxTotalLaborExpense MaxTotalLaborExpense { get; set; }
        public WftMaxEmployedLaborRate MaxEmployedLaborRate { get; set; }
        public WftMaxContactLaborRate MaxContactLaborRate { get; set; }
        public WftMaxOverTimePremiumDollars MaxOverTimePremiumDollars { get; set; }
        public WftMaxOtPercent MaxOtPercent { get; set; }
        public WftMaxOtFte MaxOtFte { get; set; }

        // Maximum (Budget/Target) Values - Volume
        public WftMaxDeptUOS MaxDeptUOS { get; set; }
        public WftMaxSemiVariableFtes MaxSemiVariableFtes { get; set; }
        public WftMaxVariableProdHrsPerUOS MaxVariableProdHrsPerUOS { get; set; }
        public WftMaxTotalProdHrsPerUOS MaxTotalProdHrsPerUOS { get; set; }
        public WftMaxTotalPaidHrsPerUOS MaxTotalPaidHrsPerUOS { get; set; }
        public WftMaxProductiveMinFtes MaxProductiveMinFtes { get; set; }

        // Minimum Values - FTE Summary
        public WftMinEmployedProductiveFtes MinEmployedProductiveFtes { get; set; }
        public WftMinContractLaborPercent MinContractLaborPercent { get; set; }
        public WftMinContractFtes MinContractFtes { get; set; }
        public WftMinTotalProductiveFtes MinTotalProductiveFtes { get; set; }
        public WftMinNonProductivePercent MinNonProductivePercent { get; set; }
        public WftMinNonProductiveFtes MinNonProductiveFtes { get; set; }
        public WftMinEmployedPaidFtes MinEmployedPaidFtes { get; set; }
        public WftMinTotalFtes MinTotalFtes { get; set; }

        // Minimum Values - Labor Expense
        public WftMinTotalSalariesAndWages MinTotalSalariesAndWages { get; set; }
        public WftMinTotalContractLaborDollars MinTotalContractLaborDollars { get; set; }
        public WftMinTotalLaborExpense MinTotalLaborExpense { get; set; }
        public WftMinEmployedLaborRate MinEmployedLaborRate { get; set; }
        public WftMinContactLaborRate MinContactLaborRate { get; set; }
        public WftMinOverTimePremiumDollars MinOverTimePremiumDollars { get; set; }
        public WftMinOtPercent MinOtPercent { get; set; }
        public WftMinOtFte MinOtFte { get; set; }

        // Minimum Values - Volume
        public WftMinDeptUOS MinDeptUOS { get; set; }
        public WftMinSemiVariableFtes MinSemiVariableFtes { get; set; }
        public WftMinVariableProdHrsPerUOS MinVariableProdHrsPerUOS { get; set; }
        public WftMinTotalProdHrsPerUOS MinTotalProdHrsPerUOS { get; set; }
        public WftMinTotalPaidHrsPerUOS MinTotalPaidHrsPerUOS { get; set; }
        public WftMinProductiveMinFtes MinProductiveMinFtes { get; set; }

        public WftLaborSummaryData()
        {
            // Initialize all monthly data objects
            EmployedProductiveFtes = new WftEmployedProductiveFtes();
            ContractLaborPercent = new WftContractLaborPercent();
            ContractFtes = new WftContractFtes();
            TotalProductiveFtes = new WftTotalProductiveFtes();
            NonProductivePercent = new WftNonProductivePercent();
            NonProductiveFtes = new WftNonProductiveFtes();
            EmployedPaidFtes = new WftEmployedPaidFtes();
            TotalFtes = new WftTotalFtes();

            TotalSalariesAndWages = new WftTotalSalariesAndWages();
            TotalContractLaborDollars = new WftTotalContractLaborDollars();
            TotalLaborExpense = new WftTotalLaborExpense();
            EmployedLaborRate = new WftEmployedLaborRate();
            ContactLaborRate = new WftContactLaborRate();
            OverTimePremiumDollars = new WftOverTimePremiumDollars();
            OtPercent = new WftOtPercent();
            OtFte = new WftOtFte();

            DeptUOS = new WftDeptUOS();
            SemiVariableFtes = new WftSemiVariableFtes();
            VariableProdHrsPerUOS = new WftVariableProdHrsPerUOS();
            TotalProdHrsPerUOS = new WftTotalProdHrsPerUOS();
            TotalPaidHrsPerUOS = new WftTotalPaidHrsPerUOS();
            ProductiveMinFtes = new WftProductiveMinFtes();

            MaxEmployedProductiveFtes = new WftMaxEmployedProductiveFtes();
            MaxContractLaborPercent = new WftMaxContractLaborPercent();
            MaxContractFtes = new WftMaxContractFtes();
            MaxTotalProductiveFtes = new WftMaxTotalProductiveFtes();
            MaxNonProductivePercent = new WftMaxNonProductivePercent();
            MaxNonProductiveFtes = new WftMaxNonProductiveFtes();
            MaxEmployedPaidFtes = new WftMaxEmployedPaidFtes();
            MaxTotalFtes = new WftMaxTotalFtes();

            MaxTotalSalariesAndWages = new WftMaxTotalSalariesAndWages();
            MaxTotalContractLaborDollars = new WftMaxTotalContractLaborDollars();
            MaxTotalLaborExpense = new WftMaxTotalLaborExpense();
            MaxEmployedLaborRate = new WftMaxEmployedLaborRate();
            MaxContactLaborRate = new WftMaxContactLaborRate();
            MaxOverTimePremiumDollars = new WftMaxOverTimePremiumDollars();
            MaxOtPercent = new WftMaxOtPercent();
            MaxOtFte = new WftMaxOtFte();

            MaxDeptUOS = new WftMaxDeptUOS();
            MaxSemiVariableFtes = new WftMaxSemiVariableFtes();
            MaxVariableProdHrsPerUOS = new WftMaxVariableProdHrsPerUOS();
            MaxTotalProdHrsPerUOS = new WftMaxTotalProdHrsPerUOS();
            MaxTotalPaidHrsPerUOS = new WftMaxTotalPaidHrsPerUOS();
            MaxProductiveMinFtes = new WftMaxProductiveMinFtes();

            MinEmployedProductiveFtes = new WftMinEmployedProductiveFtes();
            MinContractLaborPercent = new WftMinContractLaborPercent();
            MinContractFtes = new WftMinContractFtes();
            MinTotalProductiveFtes = new WftMinTotalProductiveFtes();
            MinNonProductivePercent = new WftMinNonProductivePercent();
            MinNonProductiveFtes = new WftMinNonProductiveFtes();
            MinEmployedPaidFtes = new WftMinEmployedPaidFtes();
            MinTotalFtes = new WftMinTotalFtes();

            MinTotalSalariesAndWages = new WftMinTotalSalariesAndWages();
            MinTotalContractLaborDollars = new WftMinTotalContractLaborDollars();
            MinTotalLaborExpense = new WftMinTotalLaborExpense();
            MinEmployedLaborRate = new WftMinEmployedLaborRate();
            MinContactLaborRate = new WftMinContactLaborRate();
            MinOverTimePremiumDollars = new WftMinOverTimePremiumDollars();
            MinOtPercent = new WftMinOtPercent();
            MinOtFte = new WftMinOtFte();

            MinDeptUOS = new WftMinDeptUOS();
            MinSemiVariableFtes = new WftMinSemiVariableFtes();
            MinVariableProdHrsPerUOS = new WftMinVariableProdHrsPerUOS();
            MinTotalProdHrsPerUOS = new WftMinTotalProdHrsPerUOS();
            MinTotalPaidHrsPerUOS = new WftMinTotalPaidHrsPerUOS();
            MinProductiveMinFtes = new WftMinProductiveMinFtes();
        }
    }

    // ===== FTE Summary Classes =====
    public class WftEmployedProductiveFtes : MonthlyData { }
    public class WftContractLaborPercent : MonthlyData { }
    public class WftContractFtes : MonthlyData { }
    public class WftTotalProductiveFtes : MonthlyData { }
    public class WftNonProductivePercent : MonthlyData { }
    public class WftNonProductiveFtes : MonthlyData { }
    public class WftEmployedPaidFtes : MonthlyData { }
    public class WftTotalFtes : MonthlyData { }

    // ===== Labor Expense Summary Classes =====
    public class WftTotalSalariesAndWages : MonthlyData { }
    public class WftTotalContractLaborDollars : MonthlyData { }
    public class WftTotalLaborExpense : MonthlyData { }
    public class WftEmployedLaborRate : MonthlyData { }
    public class WftContactLaborRate : MonthlyData { }
    public class WftOverTimePremiumDollars : MonthlyData { }
    public class WftOtPercent : MonthlyData { }
    public class WftOtFte : MonthlyData { }

    // ===== Volume Summary Classes =====
    public class WftDeptUOS : MonthlyData { }
    public class WftSemiVariableFtes : MonthlyData { }
    public class WftVariableProdHrsPerUOS : MonthlyData { }
    public class WftTotalProdHrsPerUOS : MonthlyData { }
    public class WftTotalPaidHrsPerUOS : MonthlyData { }
    public class WftProductiveMinFtes : MonthlyData { }

    // ===== Maximum (Budget) Values Classes =====
    public class WftMaxEmployedProductiveFtes : MonthlyData { }
    public class WftMaxContractLaborPercent : MonthlyData { }
    public class WftMaxContractFtes : MonthlyData { }
    public class WftMaxTotalProductiveFtes : MonthlyData { }
    public class WftMaxNonProductivePercent : MonthlyData { }
    public class WftMaxNonProductiveFtes : MonthlyData { }
    public class WftMaxEmployedPaidFtes : MonthlyData { }
    public class WftMaxTotalFtes : MonthlyData { }
    public class WftMaxTotalSalariesAndWages : MonthlyData { }
    public class WftMaxTotalContractLaborDollars : MonthlyData { }
    public class WftMaxTotalLaborExpense : MonthlyData { }
    public class WftMaxEmployedLaborRate : MonthlyData { }
    public class WftMaxContactLaborRate : MonthlyData { }
    public class WftMaxOverTimePremiumDollars : MonthlyData { }
    public class WftMaxOtPercent : MonthlyData { }
    public class WftMaxOtFte : MonthlyData { }
    public class WftMaxDeptUOS : MonthlyData { }
    public class WftMaxSemiVariableFtes : MonthlyData { }
    public class WftMaxVariableProdHrsPerUOS : MonthlyData { }
    public class WftMaxTotalProdHrsPerUOS : MonthlyData { }
    public class WftMaxTotalPaidHrsPerUOS : MonthlyData { }
    public class WftMaxProductiveMinFtes : MonthlyData { }

    // ===== Minimum Values Classes =====
    public class WftMinEmployedProductiveFtes : MonthlyData { }
    public class WftMinContractLaborPercent : MonthlyData { }
    public class WftMinContractFtes : MonthlyData { }
    public class WftMinTotalProductiveFtes : MonthlyData { }
    public class WftMinNonProductivePercent : MonthlyData { }
    public class WftMinNonProductiveFtes : MonthlyData { }
    public class WftMinEmployedPaidFtes : MonthlyData { }
    public class WftMinTotalFtes : MonthlyData { }
    public class WftMinTotalSalariesAndWages : MonthlyData { }
    public class WftMinTotalContractLaborDollars : MonthlyData { }
    public class WftMinTotalLaborExpense : MonthlyData { }
    public class WftMinEmployedLaborRate : MonthlyData { }
    public class WftMinContactLaborRate : MonthlyData { }
    public class WftMinOverTimePremiumDollars : MonthlyData { }
    public class WftMinOtPercent : MonthlyData { }
    public class WftMinOtFte : MonthlyData { }
    public class WftMinDeptUOS : MonthlyData { }
    public class WftMinSemiVariableFtes : MonthlyData { }
    public class WftMinVariableProdHrsPerUOS : MonthlyData { }
    public class WftMinTotalProdHrsPerUOS : MonthlyData { }
    public class WftMinTotalPaidHrsPerUOS : MonthlyData { }
    public class WftMinProductiveMinFtes : MonthlyData { }
}