﻿using System;
using System.Collections.Generic;

namespace ISAS_Regression_Automation
{
    // Base class for monthly data
    public class MonthlyData
    {
        public double Jan { get; set; }
        public double Feb { get; set; }
        public double Mar { get; set; }
        public double Apr { get; set; }
        public double May { get; set; }
        public double Jun { get; set; }
        public double Jul { get; set; }
        public double Aug { get; set; }
        public double Sep { get; set; }
        public double Oct { get; set; }
        public double Nov { get; set; }
        public double Dec { get; set; }
        public double Total { get; set; }
    }

    // Department header information
    public class DepartmentInfo
    {
        public string DeptNumber { get; set; }
        public string DeptName { get; set; }
        public string Type { get; set; }
    }

    // ===== FTE Summary Classes (Lines 12-19) =====

    public class EmployedProductiveFTEs : MonthlyData { }

    public class ContractLaborPercent : MonthlyData { }

    public class ContractFTEs : MonthlyData { }

    public class TotalProductiveFTEs : MonthlyData { }

    public class NonProducingPercent : MonthlyData { }

    public class NonProductiveFTEs : MonthlyData { }

    public class EmployedPaidFTEs : MonthlyData { }

    public class TotalFTEsPaidAndContract : MonthlyData { }

    public class DepartmentFTESummary
    {
        public EmployedProductiveFTEs EmployedProductiveFTEs { get; set; }
        public ContractLaborPercent ContractLaborPercent { get; set; }
        public ContractFTEs ContractFTEs { get; set; }
        public TotalProductiveFTEs TotalProductiveFTEs { get; set; }
        public NonProducingPercent NonProducingPercent { get; set; }
        public NonProductiveFTEs NonProductiveFTEs { get; set; }
        public EmployedPaidFTEs EmployedPaidFTEs { get; set; }
        public TotalFTEsPaidAndContract TotalFTEsPaidAndContract { get; set; }
    }

    // ===== Labor Expense Summary Classes (Lines 23-30) =====

    public class TotalSalariesAndWages : MonthlyData { }

    public class TotalContractLabor : MonthlyData { }

    public class TotalLaborCost : MonthlyData { }

    public class EmployedLaborRate : MonthlyData { }

    public class ContractLaborRate : MonthlyData { }

    public class OvertimePremiumDollars : MonthlyData { }

    public class OvertimePercent : MonthlyData { }

    public class OvertimeFTEs : MonthlyData { }

    public class DepartmentLaborExpenseSummary
    {
        public TotalSalariesAndWages TotalSalariesAndWages { get; set; }
        public TotalContractLabor TotalContractLabor { get; set; }
        public TotalLaborCost TotalLaborCost { get; set; }
        public EmployedLaborRate EmployedLaborRate { get; set; }
        public ContractLaborRate ContractLaborRate { get; set; }
        public OvertimePremiumDollars OvertimePremiumDollars { get; set; }
        public OvertimePercent OvertimePercent { get; set; }
        public OvertimeFTEs OvertimeFTEs { get; set; }
    }

    // ===== Volume Summary Classes (Lines 34-38) =====

    public class DepartmentUOS : MonthlyData { }

    public class SemiVariableFTEs : MonthlyData { }

    public class VariableProductiveHrsPerUOS : MonthlyData { }

    public class MinFTEs : MonthlyData { }

    public class TotalProductiveHrsPerUOS : MonthlyData { }

    public class DepartmentVolumeSummary
    {
        public DepartmentUOS DepartmentUOS { get; set; }
        public SemiVariableFTEs SemiVariableFTEs { get; set; }
        public VariableProductiveHrsPerUOS VariableProductiveHrsPerUOS { get; set; }
        public MinFTEs MinFTEs { get; set; }
        public TotalProductiveHrsPerUOS TotalProductiveHrsPerUOS { get; set; }
    }

    // ===== Complete Department Data =====

    public class DepartmentData
    {
        public DepartmentInfo Info { get; set; }
        public DepartmentFTESummary FTESummary { get; set; }
        public DepartmentLaborExpenseSummary LaborExpenseSummary { get; set; }
        public DepartmentVolumeSummary VolumeSummary { get; set; }
    }

    // ===== Collection of all departments =====

    public class DepartmentReport
    {
        public List<DepartmentData> Departments { get; set; }

        public DepartmentReport()
        {
            Departments = new List<DepartmentData>();
        }
    }
}