﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class EmployedAndContractfteCost
    {
        public string Dept { get; set; }
        public string DeptDescription { get; set; }
        public double EmployedPaidFtesForecast { get; set; }
        public double EmployedPaidFtesPriorYear { get; set; }
        public double EmployedPaidFtesVarPercent { get; set; }
        public double ContractFtesForecast { get; set; }
        public double ContractFtesPriorYear { get; set; }
        public double ContractFtesVarPercent { get; set; }
        public double EmployedSalariesForecast { get; set; }
        public double EmployedSalariesPriorYear { get; set; }
        public double EmployedSalariesVarPercent { get; set; }
        public double ContractLaborDollarsForecast { get; set; }
        public double ContractLaborDollarsPriorYear { get; set; }
        public double ContractLaborDollarsVarPercent { get; set; }
        public double TotalSalariesForecast { get; set; }
        public double TotalSalariesPriorYear { get; set; }
        public double TotalSalariesVarPercent { get; set; }
        public double OtPercentForecast { get; set; }
        public double OtPercentPriorYear { get; set; }
        public double OtPercentVarPercent { get; set; }
    }

    public class EmployedAndContractFteCostExcelReport
    {
        public static List<EmployedAndContractfteCost> ParseEmployedAndContractFteCostExcelReport(string filePath)
        {
            var result = new List<EmployedAndContractfteCost>();
            
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var allRows = new List<object[]>();

                    // Read all rows into memory
                    do
                    {
                        while (reader.Read())
                        {
                            var row = new object[reader.FieldCount];
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row[i] = reader.GetValue(i);
                            }
                            allRows.Add(row);
                        }
                    } while (reader.NextResult());

                    // Find the row that contains "Dept" in the first column
                    int startRowIndex = CommonFunctions.FindDeptRow("Dept", allRows);

                    if (startRowIndex == -1)
                    {
                        throw new InvalidOperationException("Could not find 'Dept' in the first column");
                    }

                    // Process rows starting after the "Dept" header row
                    for (int i = startRowIndex + 1; i < allRows.Count; i++)
                    {
                        var row = allRows[i];

                        // Skip empty rows
                        if (CommonFunctions.IsEmptyRow(row))
                            continue;

                        var lstRows = new EmployedAndContractfteCost()
                        {
                            Dept = CommonFunctions.GetStringValue(row, 0),
                            DeptDescription = CommonFunctions.GetStringValue(row, 1),
                            EmployedPaidFtesForecast = CommonFunctions.GetdoubleValue(row, 2),
                            EmployedPaidFtesPriorYear = CommonFunctions.GetdoubleValue(row, 3),
                            EmployedPaidFtesVarPercent = CommonFunctions.GetdoubleValue(row, 4),
                            ContractFtesForecast = CommonFunctions.GetdoubleValue(row, 5),
                            ContractFtesPriorYear = CommonFunctions.GetdoubleValue(row, 6),
                            ContractFtesVarPercent = CommonFunctions.GetdoubleValue(row, 7),
                            EmployedSalariesForecast = CommonFunctions.GetdoubleValue(row, 8),
                            EmployedSalariesPriorYear = CommonFunctions.GetdoubleValue(row, 9),
                            EmployedSalariesVarPercent = CommonFunctions.GetdoubleValue(row, 10),
                            ContractLaborDollarsForecast = CommonFunctions.GetdoubleValue(row, 11),
                            ContractLaborDollarsPriorYear = CommonFunctions.GetdoubleValue(row, 12),
                            ContractLaborDollarsVarPercent = CommonFunctions.GetdoubleValue(row, 13),
                            TotalSalariesForecast = CommonFunctions.GetdoubleValue(row, 14),
                            TotalSalariesPriorYear = CommonFunctions.GetdoubleValue(row, 15),
                            TotalSalariesVarPercent = CommonFunctions.GetdoubleValue(row, 16),
                            OtPercentForecast = CommonFunctions.GetdoubleValue(row, 17),
                            OtPercentPriorYear = CommonFunctions.GetdoubleValue(row, 18),
                            OtPercentVarPercent = CommonFunctions.GetdoubleValue(row, 19),
                        };
                        result.Add(lstRows);
                    }
                }
            }
            return result;
        }

        public static bool VerifyEmployedContractCostReportDataAgainstDB(List<EmployedAndContractfteCost> DeptEmployedAndContractFTECostExcelReportData, List<LaborForecastData> DBDeptData)
        {
            return (
                DeptEmployedAndContractFTECostExcelReportData[0].Dept == DBDeptData[0].DeptNumber &&
                DeptEmployedAndContractFTECostExcelReportData[0].DeptDescription == DBDeptData[0].DeptName &&
                DeptEmployedAndContractFTECostExcelReportData[0].EmployedPaidFtesForecast == DBDeptData[0].FTEsPaidForecast &&
                DeptEmployedAndContractFTECostExcelReportData[0].EmployedPaidFtesPriorYear == DBDeptData[0].FTEsPaidPrior &&
                DeptEmployedAndContractFTECostExcelReportData[0].EmployedPaidFtesVarPercent == DBDeptData[0].FTEsPaidVar &&
                DeptEmployedAndContractFTECostExcelReportData[0].ContractFtesForecast == DBDeptData[0].FTEsContractForecast &&
                DeptEmployedAndContractFTECostExcelReportData[0].ContractFtesPriorYear == DBDeptData[0].FTEsContractPrior &&
                DeptEmployedAndContractFTECostExcelReportData[0].ContractFtesVarPercent == DBDeptData[0].FTEsContractVar &&
                DeptEmployedAndContractFTECostExcelReportData[0].EmployedSalariesForecast == DBDeptData[0].SalaryForecast &&
                DeptEmployedAndContractFTECostExcelReportData[0].EmployedSalariesPriorYear == DBDeptData[0].SalaryPrior &&
                DeptEmployedAndContractFTECostExcelReportData[0].EmployedSalariesVarPercent == DBDeptData[0].SalaryVar &&
                DeptEmployedAndContractFTECostExcelReportData[0].OtPercentForecast == DBDeptData[0].OTPercentForecast &&
                DeptEmployedAndContractFTECostExcelReportData[0].OtPercentPriorYear == DBDeptData[0].OTPercentPrior &&
                DeptEmployedAndContractFTECostExcelReportData[0].OtPercentVarPercent == DBDeptData[0].OTPercentVar
                );
        }
    }
}
