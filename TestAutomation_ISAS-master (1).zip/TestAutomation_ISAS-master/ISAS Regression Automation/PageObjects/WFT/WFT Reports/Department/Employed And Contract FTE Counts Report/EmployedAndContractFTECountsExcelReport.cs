﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{

    public class EmployedAndContractedFTECounts
    {
        public string Dept { get; set; }
        public string DeptDescription { get; set; }
        public double EmployedProductiveFtesForecast { get; set; }
        public double EmployedProductiveFtesPriorYear { get; set; }
        public double EmployedProductiveFtesVarPercent { get; set; }
        public double EmployedPaidFtesForecast { get; set; }
        public double EmployedPaidFtesPriorYear { get; set; }
        public double EmployedPaidFtesVarPercent { get; set; }
        public double ContractFtesForecast { get; set; }
        public double ContractFtesPriorYear { get; set; }
        public double ContractFtesVarPercent { get; set; }
        public double ContractFtesPercenttotalFtes { get; set; }
        public double EmployedLaborRateForecast { get; set; }
        public double EmployedLaborRatePriorYear { get; set; }
        public double EmployedLaborRateVarPercent { get; set; }
        public double ContractLaborRateForecast { get; set; }
        public double ContractLaborRatePriorYear { get; set; }
        public double ContractLaborRateVarPercent { get; set; }
    }

    public class EmployedAndContractFTECountsExcelReport
    {
        public static List<EmployedAndContractedFTECounts> ParseEmployedAndContractFTECountsExcelReport(string filePath)
        {
            var result = new List<EmployedAndContractedFTECounts>();

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var allRows = new List<object[]>();

                    // Read all rows into memory
                    do
                    {
                        while (reader.Read())
                        {
                            var row = new object[reader.FieldCount];
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row[i] = reader.GetValue(i);
                            }
                            allRows.Add(row);
                        }
                    } while (reader.NextResult());

                    // Find the row that contains "Dept" in the first column
                    int startRowIndex = CommonFunctions.FindDeptRow("Dept", allRows);

                    if (startRowIndex == -1)
                    {
                        throw new InvalidOperationException("Could not find 'Dept' in the first column");
                    }

                    // Process rows starting after the "Dept" header row
                    for (int i = startRowIndex + 1; i < allRows.Count; i++)
                    {
                        var row = allRows[i];

                        // Skip empty rows
                        if (CommonFunctions.IsEmptyRow(row))
                            continue;

                        var lstRows = new EmployedAndContractedFTECounts()
                        {
                            Dept = CommonFunctions.GetStringValue(row, 0),
                            DeptDescription = CommonFunctions.GetStringValue(row, 1),
                            EmployedProductiveFtesForecast = CommonFunctions.GetdoubleValue(row, 2),
                            EmployedProductiveFtesPriorYear = CommonFunctions.GetdoubleValue(row, 3),
                            EmployedProductiveFtesVarPercent = CommonFunctions.GetdoubleValue(row, 4),
                            EmployedPaidFtesForecast = CommonFunctions.GetdoubleValue(row, 5),
                            EmployedPaidFtesPriorYear = CommonFunctions.GetdoubleValue(row, 6),
                            EmployedPaidFtesVarPercent = CommonFunctions.GetdoubleValue(row, 7),
                            ContractFtesForecast = CommonFunctions.GetdoubleValue(row, 8),
                            ContractFtesPriorYear = CommonFunctions.GetdoubleValue(row, 9),
                            ContractFtesVarPercent = CommonFunctions.GetdoubleValue(row, 10),
                            ContractFtesPercenttotalFtes = CommonFunctions.GetdoubleValue(row, 11),
                            EmployedLaborRateForecast = CommonFunctions.GetdoubleValue(row, 12),
                            EmployedLaborRatePriorYear = CommonFunctions.GetdoubleValue(row, 13),
                            EmployedLaborRateVarPercent = CommonFunctions.GetdoubleValue(row, 14),
                            ContractLaborRateForecast = CommonFunctions.GetdoubleValue(row, 15),
                            ContractLaborRatePriorYear = CommonFunctions.GetdoubleValue(row, 16),
                            ContractLaborRateVarPercent = CommonFunctions.GetdoubleValue(row, 17),
                        };
                        result.Add(lstRows);
                    }
                }
            }
            return result;
        }

        public static bool VerifyEmployedContractCountsReportDataAgainstDB(List<EmployedAndContractedFTECounts> DeptEmployedAndContractFTECountsExcelReportData, List<LaborForecastData> objPreviousDeptData)
        {
            return (
            DeptEmployedAndContractFTECountsExcelReportData[0].Dept == objPreviousDeptData[0].DeptNumber &&
            DeptEmployedAndContractFTECountsExcelReportData[0].DeptDescription == objPreviousDeptData[0].DeptName &&
            DeptEmployedAndContractFTECountsExcelReportData[0].EmployedProductiveFtesForecast == objPreviousDeptData[0].FTEsProdForecast &&
            DeptEmployedAndContractFTECountsExcelReportData[0].EmployedProductiveFtesPriorYear == objPreviousDeptData[0].FTEsProdPrior &&
            DeptEmployedAndContractFTECountsExcelReportData[0].EmployedProductiveFtesVarPercent == objPreviousDeptData[0].FTEsProdVar &&
            DeptEmployedAndContractFTECountsExcelReportData[0].EmployedPaidFtesForecast == objPreviousDeptData[0].FTEsPaidForecast &&
            DeptEmployedAndContractFTECountsExcelReportData[0].EmployedPaidFtesPriorYear == objPreviousDeptData[0].FTEsPaidPrior &&
            DeptEmployedAndContractFTECountsExcelReportData[0].EmployedPaidFtesVarPercent == objPreviousDeptData[0].FTEsPaidVar &&
            DeptEmployedAndContractFTECountsExcelReportData[0].ContractFtesForecast == objPreviousDeptData[0].FTEsContractForecast &&
            DeptEmployedAndContractFTECountsExcelReportData[0].ContractFtesPriorYear == objPreviousDeptData[0].FTEsContractPrior &&
            DeptEmployedAndContractFTECountsExcelReportData[0].ContractFtesVarPercent == objPreviousDeptData[0].FTEsContractVar &&
            //DeptEmployedAndContractFTECountsExcelReportData[0].ContractFtesPercenttotalFtes == objPreviousDeptData[0].DeptNumber &&
            DeptEmployedAndContractFTECountsExcelReportData[0].EmployedLaborRateForecast == objPreviousDeptData[0].EmployedLaborRateForecast &&
            DeptEmployedAndContractFTECountsExcelReportData[0].EmployedLaborRatePriorYear == objPreviousDeptData[0].EmployedLaborRatePrior &&
            //DeptEmployedAndContractFTECountsExcelReportData[0].EmployedLaborRateVarPercent == objPreviousDeptData[0].EmployedLaborRateVar &&
            DeptEmployedAndContractFTECountsExcelReportData[0].ContractLaborRateForecast == objPreviousDeptData[0].ContractLaborRateForecast &&
            DeptEmployedAndContractFTECountsExcelReportData[0].ContractLaborRatePriorYear == objPreviousDeptData[0].ContractLaborRatePrior &&
            DeptEmployedAndContractFTECountsExcelReportData[0].ContractLaborRateVarPercent == objPreviousDeptData[0].ContractLaborRateVar);

        }
    }
}
