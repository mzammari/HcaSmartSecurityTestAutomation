﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ISAS_Regression_Automation.Utilities;
using NUnit.Framework.Constraints;
using System.Threading;

namespace ISAS_Regression_Automation
{
    public class EmployedAndContractFteCountsSP
    {
        private static string GetEmployedAndContractFteCountsSpQuery(int GroupOnly)
        {
            RunData.PlanID = AdminPlanDetail.getPlanID();

            var EmployedAndContractFteCountsSp = $"declare @PlanID BIGINT={RunData.PlanID}" + Environment.NewLine +
                    $"declare @GroupOnly int ={GroupOnly}" + Environment.NewLine +
                    "DECLARE @daysInYear INT" + Environment.NewLine +
                    "DECLARE @daysInPriorYear INT" + Environment.NewLine +
                    "DECLARE @extarday INT" + Environment.NewLine +
                    "DECLARE @PlanYear INT" + Environment.NewLine +
                    "DECLARE @FortyBySeven float" + Environment.NewLine +
                    "SELECT @PlanYear = Year from WftPlan WHERE Id = @PlanID" + Environment.NewLine +
                    "SET @extarday = dbo.fn_IsLeapYear(@PlanYear)" + Environment.NewLine +
                    "SET @daysInYear = 365 + @extarday" + Environment.NewLine +
                    "SET @extarday = dbo.fn_IsLeapYear(@PlanYear - 1)" + Environment.NewLine +
                    "SET @daysInPriorYear = 365 + @extarday" + Environment.NewLine +
                    "SET @FortyBySeven = dbo.f_GetFortyBySeven();" + Environment.NewLine +
                    "DECLARE @SubmissionID BIGINT" + Environment.NewLine +
                    "EXEC [rpt_GetSubmittedId]  @PlanID,  @SubmissionID=@SubmissionID  OUTPUT" + Environment.NewLine +
                    "IF (@SubmissionID is null)" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "IF @GroupOnly = 0" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "SELECT ltrim(STR(D.Number)) as 'DeptNumber'" + Environment.NewLine +
                    ", LEFT(D.Name,15) as 'DeptName'" + Environment.NewLine +
                    ",( Sum(w.EmployeePaidManHours) )/@FortyBySeven  / @daysInYear as 'FTEsPaidForecast'" + Environment.NewLine +
                    ", (Sum(R.HistoricalPaidHours) )/@FortyBySeven  / @daysInPriorYear as 'FTEsPaidPrior'" + Environment.NewLine +
                    ", case  when (Sum(R.HistoricalPaidHours) )= 0  then 0 else" + Environment.NewLine +
                    "(( Sum(w.EmployeePaidManHours) ) /@FortyBySeven  / @daysInYear /" + Environment.NewLine +
                    "((Sum(NULLIF(R.HistoricalPaidHours,0)))/@FortyBySeven  / @daysInPriorYear) - 1 ) *  100  end as 'FTEsPaidVar'" + Environment.NewLine +
                    ",(Sum(W.EmployeeProductiveHours)  )/@FortyBySeven / @daysInYear as 'FTEsProdForecast'" + Environment.NewLine +
                    ",( SUM(R.HistoricalProductiveHours))/@FortyBySeven  / @daysInPriorYear as 'FTEsProdPrior'" + Environment.NewLine +
                    ",case when ( SUM(R.HistoricalProductiveHours))=0 then 0 else" + Environment.NewLine +
                    "(Sum(w.EmployeeProductiveHours) /@FortyBySeven  / @daysInYear /" + Environment.NewLine +
                    "((Sum(NULLIF(R.HistoricalProductiveHours,0)))/@FortyBySeven  / @daysInPriorYear) - 1 ) *  100  end as 'FTEsProdVar'" + Environment.NewLine +
                    ", Sum(W.ContractLaborHours)/@FortyBySeven / @daysInYear  as 'FTEsContractForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalContractHours)/@FortyBySeven  / @daysInPriorYear  as 'FTEsContractPrior'" + Environment.NewLine +
                    ", case when Sum(isnull(R.HistoricalContractHours,0))= 0 then 0 else" + Environment.NewLine +
                    "(  ( (Sum(W.ContractLaborHours)/@FortyBySeven / @daysInYear) /" + Environment.NewLine +
                    "(Sum(isnull(R.HistoricalContractHours,0)) / @FortyBySeven  / @daysInPriorYear)" + Environment.NewLine +
                    ")     -1) * 100" + Environment.NewLine +
                    "end as 'FTEsContractVar'" + Environment.NewLine +
                    ", Sum(W.EmployedSalaries) as 'SalaryForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalHospitalDollarsFromGl) as 'SalaryPrior'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalHospitalDollarsFromGl)=0 then 0 else" + Environment.NewLine +
                    "(Sum(W.EmployedSalaries) / NULLIF(Sum(R.HistoricalHospitalDollarsFromGl), 0)) * 100  end as 'SalaryVar'" + Environment.NewLine +
                    ", Sum(W.ContractAmount) as 'LaborSalaryForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalContractDollarsFromGl) as 'LaborSalaryPrior'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalHospitalDollarsFromGl)=0 then 0 else" + Environment.NewLine +
                    "(Sum(W.ContractAmount) / NULLIF(Sum(R.HistoricalContractDollarsFromGl), 0))  end as 'LaborSalaryVar'" + Environment.NewLine +
                    ",case when (Sum(R.HistoricalContractDollarsFromGl) + Sum(R.HistoricalHospitalDollarsFromGl))= 0 then 0 else (((Sum(W.ContractAmount) + Sum(W.EmployedSalaries)) / NULLIF(Sum(R.HistoricalContractDollarsFromGl) + Sum(R.HistoricalHospitalDollarsFromGl), 0)" + Environment.NewLine +
                    ")) * 100 end  as 'TotalSalaryVar'" + Environment.NewLine +
                    "-- employed labor rate" + Environment.NewLine +
                    ",case when SUM(W.EmployeePaidManHours) = 0  then 0 else Sum(W.EmployedSalaries) / SUM(W.EmployeePaidManHours)  end  as 'EmployedLaborRateForecast'" + Environment.NewLine +
                    ",case when NULLIF(Sum(R.HistoricalPaidHours),0) = 0 then 0 else Sum(R.HistoricalHospitalDollarsFromGl)/NULLIF(Sum(R.HistoricalPaidHours),0) end as 'EmployedLaborRatePrior'" + Environment.NewLine +
                    ",case when (SUM(W.EmployeePaidManHours) =0) or (Sum(R.HistoricalHospitalDollarsFromGl)= 0) or (Sum(R.HistoricalPaidHours) =0 )  then 0 else" + Environment.NewLine +
                    "((Sum(W.EmployedSalaries) / SUM(W.EmployeePaidManHours)) /NULLIF((Sum(R.HistoricalHospitalDollarsFromGl)/NULLIF(Sum(R.HistoricalPaidHours),0)),0)) - 1 end as 'EmployedLaborRateVar'" + Environment.NewLine +
                    "-- contract labor rate" + Environment.NewLine +
                    ",case when SUM(W.ContractLaborHours) = 0 then 0 else  Sum(W.ContractAmount) / SUM(W.ContractLaborHours)  end as 'ContractLaborRateForecast'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalContractHours) = 0 then 0 else Sum(R.HistoricalContractDollarsFromGl)/NULLIF(Sum(R.HistoricalContractHours),0) end as 'ContractLaborRatePrior'" + Environment.NewLine +
                    ",case when (SUM(W.ContractLaborHours) = 0 ) or  (Sum(R.HistoricalContractDollarsFromGl) = 0 ) or (Sum(R.HistoricalContractHours) = 0 ) then 0 else" + Environment.NewLine +
                    "((  Sum(W.ContractAmount) / SUM(W.ContractLaborHours) ) / NULLIF((Sum(R.HistoricalContractDollarsFromGl)/NULLIF(Sum(R.HistoricalContractHours),0)),0) -1) * 100 end as 'ContractLaborRateVar'" + Environment.NewLine +
                    "-- OT Hours" + Environment.NewLine +
                    ",case when SUM(W.EmployeeProductiveHours)=0 then 0 else  (Sum(W.OtHours) / SUM(W.EmployeeProductiveHours) ) * 100  end  as 'OTPercentForecast'" + Environment.NewLine +
                    ", case when ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) = 0 then 0 else  (SUM(R.HistoricalContractHours) /  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) ) * 100   end  as 'OTPercentPrior'" + Environment.NewLine +
                    ", case when  (SUM(W.EmployeeProductiveHours)=0 ) or (SUM(R.HistoricalContractHours) = 0)  or ( ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours))= 0 )then 0 else" + Environment.NewLine +
                    "(((Sum(W.OtHours) / SUM(W.EmployeeProductiveHours) )  /" + Environment.NewLine +
                    "(SUM(R.HistoricalContractHours) /  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) )   )  - 1) end  as 'OTPercentVar'" + Environment.NewLine +
                    "FROM WftMonthlyValue W" + Environment.NewLine +
                    "JOIN [WftDepartment] WD ON WD.Id = W.WftDepartment_ID" + Environment.NewLine +
                    "JOIN [Department] D ON D.Id = WD.Department_ID" + Environment.NewLine +
                    "JOIN [ReferenceMonthlyValue] R ON D.Id = R.Department_ID and W.Month = R.Month" + Environment.NewLine +
                    "WHERE WD.WftPlan_ID = @PlanId AND D.IsInactiveInWFT=0" + Environment.NewLine +
                    "GROUP BY D.Number, D.Name" + Environment.NewLine +
                    "ORDER BY D.Number" + Environment.NewLine +
                    "END" + Environment.NewLine +
                    "ELSE" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "SELECT '(G) ' + ltrim(STR(DG.Number)) as 'DeptNumber'" + Environment.NewLine +
                    ", LEFT(DG.Description,15) as 'DeptName'" + Environment.NewLine +
                    ",( Sum(w.EmployeePaidManHours) + SUM (w.ContractLaborHours))/@FortyBySeven  / @daysInYear as 'FTEsPaidForecast'" + Environment.NewLine +
                    ", (Sum(R.HistoricalPaidHours) + SUM(R.HistoricalContractHours))/@FortyBySeven  / @daysInPriorYear as 'FTEsPaidPrior'" + Environment.NewLine +
                    ", case  when (Sum(R.HistoricalPaidHours) + SUM(R.HistoricalContractHours))= 0  then 0 else" + Environment.NewLine +
                    "(( Sum(w.EmployeePaidManHours) + SUM (w.ContractLaborHours)) /@FortyBySeven  / @daysInYear /" + Environment.NewLine +
                    "((Sum(NULLIF(R.HistoricalPaidHours,0)) +  SUM(NULLIF(R.HistoricalContractHours,0)))/@FortyBySeven  / @daysInPriorYear) - 1 ) *  100  end as 'FTEsPaidVar'" + Environment.NewLine +
                    ",(Sum(W.EmployeeProductiveHours)  )/@FortyBySeven / @daysInYear as 'FTEsProdForecast'" + Environment.NewLine +
                    ",( SUM(R.HistoricalProductiveHours))/@FortyBySeven  / @daysInPriorYear as 'FTEsProdPrior'" + Environment.NewLine +
                    ",case when ( SUM(R.HistoricalProductiveHours))=0 then 0 else" + Environment.NewLine +
                    "(Sum(w.EmployeeProductiveHours) /@FortyBySeven  / @daysInYear /" + Environment.NewLine +
                    "((Sum(NULLIF(R.HistoricalProductiveHours,0)))/@FortyBySeven  / @daysInPriorYear) - 1 ) *  100  end as 'FTEsProdVar'" + Environment.NewLine +
                    ", Sum(W.ContractLaborHours)/@FortyBySeven / @daysInYear  as 'FTEsContractForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalContractHours)/@FortyBySeven  / @daysInPriorYear  as 'FTEsContractPrior'" + Environment.NewLine +
                    ", case when Sum(isnull(R.HistoricalContractHours,0))= 0 then 0" + Environment.NewLine +
                    "else  ((" + Environment.NewLine +
                    "(Sum(W.ContractLaborHours)/@FortyBySeven / @daysInYear) /" + Environment.NewLine +
                    "( Sum(isnull(R.HistoricalContractHours,0)) / @FortyBySeven  / @daysInPriorYear)" + Environment.NewLine +
                    ") -1) * 100" + Environment.NewLine +
                    "end as 'FTEsContractVar'" + Environment.NewLine +
                    ", Sum(W.EmployedSalaries) as 'SalaryForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalHospitalDollarsFromGl) as 'SalaryPrior'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalHospitalDollarsFromGl)=0 then 0 else" + Environment.NewLine +
                    "(Sum(W.EmployedSalaries) / NULLIF(Sum(R.HistoricalHospitalDollarsFromGl), 0)) * 100  end as 'SalaryVar'" + Environment.NewLine +
                    ", Sum(W.ContractAmount) as 'LaborSalaryForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalContractDollarsFromGl) as 'LaborSalaryPrior'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalHospitalDollarsFromGl)=0 then 0 else" + Environment.NewLine +
                    "(Sum(W.ContractAmount) / NULLIF(Sum(R.HistoricalContractDollarsFromGl), 0))  end as 'LaborSalaryVar'" + Environment.NewLine +
                    ",case when (Sum(R.HistoricalContractDollarsFromGl) + Sum(R.HistoricalHospitalDollarsFromGl))= 0 then 0 else" + Environment.NewLine +
                    "(((Sum(W.ContractAmount) + Sum(W.EmployedSalaries)) / NULLIF(Sum(R.HistoricalContractDollarsFromGl) + Sum(R.HistoricalHospitalDollarsFromGl), 0))) * 100 end  as 'TotalSalaryVar'" + Environment.NewLine +
                    "-- employed labor rate" + Environment.NewLine +
                    ",case when SUM(W.EmployeePaidManHours) = 0  then 0 else Sum(W.EmployedSalaries) / SUM(W.EmployeePaidManHours)  end  as 'EmployedLaborRateForecast'" + Environment.NewLine +
                    ",case when NULLIF(Sum(R.HistoricalPaidHours),0) = 0 then 0 else Sum(R.HistoricalHospitalDollarsFromGl)/NULLIF(Sum(R.HistoricalPaidHours),0) end as 'EmployedLaborRatePrior'" + Environment.NewLine +
                    ",case when (SUM(W.EmployeePaidManHours) =0) or (Sum(R.HistoricalHospitalDollarsFromGl)= 0) or (Sum(R.HistoricalPaidHours) =0 )  then 0 else" + Environment.NewLine +
                    "((Sum(W.EmployedSalaries) / SUM(W.EmployeePaidManHours)) /" + Environment.NewLine +
                    "NULLIF((Sum(R.HistoricalHospitalDollarsFromGl)/" + Environment.NewLine +
                    "NULLIF(Sum(R.HistoricalPaidHours),0)),0)) - 1 end as 'EmployedLaborRateVar'" + Environment.NewLine +
                    "-- contract labor rate" + Environment.NewLine +
                    ",case when SUM(W.ContractLaborHours) = 0 then 0 else" + Environment.NewLine +
                    "Sum(W.ContractAmount) / SUM(W.ContractLaborHours)  end as 'ContractLaborRateForecast'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalContractHours) = 0 then 0 else" + Environment.NewLine +
                    "Sum(R.HistoricalContractDollarsFromGl)/NULLIF(Sum(R.HistoricalContractHours),0) end as 'ContractLaborRatePrior'" + Environment.NewLine +
                    ",case when (SUM(W.ContractLaborHours) = 0 ) or  (Sum(R.HistoricalContractDollarsFromGl) = 0 ) or (Sum(R.HistoricalContractHours) = 0 ) then 0 else" + Environment.NewLine +
                    "((  Sum(W.ContractAmount) / SUM(W.ContractLaborHours) ) /" + Environment.NewLine +
                    "NULLIF((Sum(R.HistoricalContractDollarsFromGl)/" + Environment.NewLine +
                    "NULLIF(Sum(R.HistoricalContractHours),0)),0) -1) * 100 end as 'ContractLaborRateVar'" + Environment.NewLine +
                    "-- OT Hours" + Environment.NewLine +
                    ",case when SUM(W.EmployeeProductiveHours)=0 then 0 else" + Environment.NewLine +
                    "(Sum(W.OtHours) / SUM(W.EmployeeProductiveHours) ) * 100  end  as 'OTPercentForecast'" + Environment.NewLine +
                    ", case when ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) = 0 then 0 else" + Environment.NewLine +
                    "(SUM(R.HistoricalContractHours) /  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) ) * 100   end  as 'OTPercentPrior'" + Environment.NewLine +
                    ", case when  (SUM(W.EmployeeProductiveHours)=0 ) or" + Environment.NewLine +
                    "(SUM(R.HistoricalContractHours) = 0)  or" + Environment.NewLine +
                    "( ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours))= 0 ) then 0 else" + Environment.NewLine +
                    "(((Sum(W.OtHours) / SUM(W.EmployeeProductiveHours) )  /" + Environment.NewLine +
                    "(SUM(R.HistoricalContractHours) /" + Environment.NewLine +
                    "( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) )   )  - 1)end  as 'OTPercentVar'" + Environment.NewLine +
                    "FROM WftMonthlyValue W" + Environment.NewLine +
                    "JOIN WftDepartment WD ON WD.Id = W.WftDepartment_ID" + Environment.NewLine +
                    "JOIN Department D ON D.Id = WD.Department_ID" + Environment.NewLine +
                    "JOIN ReferenceMonthlyValue R ON D.Id = R.Department_ID and W.Month = R.Month" + Environment.NewLine +
                    "JOIN DepartmentGroup DG ON D.DepartmentGroup_ID = DG.Id" + Environment.NewLine +
                    "WHERE WD.WftPlan_ID = @PlanId   AND D.IsInactiveInWFT=0" + Environment.NewLine +
                    "GROUP BY DG.Number, DG.Description" + Environment.NewLine +
                    "END" + Environment.NewLine +
                    "END" + Environment.NewLine +
                    "ELSE" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "IF @GroupOnly = 0" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "SELECT ltrim(STR(D.Number)) as 'DeptNumber'" + Environment.NewLine +
                    ", LEFT(D.Name,15) as 'DeptName'" + Environment.NewLine +
                    ",( Sum(w.EmployeePaidManHours) )/@FortyBySeven  / @daysInYear as 'FTEsPaidForecast'" + Environment.NewLine +
                    ", (Sum(R.HistoricalPaidHours) )/@FortyBySeven  / @daysInPriorYear as 'FTEsPaidPrior'" + Environment.NewLine +
                    ", case  when (Sum(R.HistoricalPaidHours) )= 0  then 0 else" + Environment.NewLine +
                    "(( Sum(w.EmployeePaidManHours) ) /@FortyBySeven  / @daysInYear / ((Sum(NULLIF(R.HistoricalPaidHours,0)))/@FortyBySeven  / @daysInPriorYear) - 1 ) *  100  end as 'FTEsPaidVar'" + Environment.NewLine +
                    ",(Sum(W.EmployeeProductiveHours)  )/@FortyBySeven / @daysInYear as 'FTEsProdForecast'" + Environment.NewLine +
                    ",( SUM(R.HistoricalProductiveHours))/@FortyBySeven  / @daysInPriorYear as 'FTEsProdPrior'" + Environment.NewLine +
                    ",case when ( SUM(R.HistoricalProductiveHours))=0 then 0 else" + Environment.NewLine +
                    "(Sum(w.EmployeeProductiveHours) /@FortyBySeven  / @daysInYear" + Environment.NewLine +
                    "/ ((Sum(NULLIF(R.HistoricalProductiveHours,0)))/@FortyBySeven  / @daysInPriorYear) - 1 ) *  100  end as 'FTEsProdVar'" + Environment.NewLine +
                    ", Sum(W.ContractLaborHours)/@FortyBySeven / @daysInYear  as 'FTEsContractForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalContractHours)/@FortyBySeven  / @daysInPriorYear  as 'FTEsContractPrior'" + Environment.NewLine +
                    ",case when Sum(isnull(R.HistoricalContractHours,0)) = 0 then 0" + Environment.NewLine +
                    "else  ((" + Environment.NewLine +
                    "(Sum(W.ContractLaborHours)/@FortyBySeven / @daysInYear) /" + Environment.NewLine +
                    "(Sum(isnull(R.HistoricalContractHours,0)) /@FortyBySeven  / @daysInPriorYear)" + Environment.NewLine +
                    ") -1) * 100 end as 'FTEsContractVar'" + Environment.NewLine +
                    ", Sum(W.EmployedSalaries) as 'SalaryForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalHospitalDollarsFromGl)  as 'SalaryPrior'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalHospitalDollarsFromGl)  = 0 then 0 else ((Sum(W.EmployedSalaries) / NULLIF(Sum(R.HistoricalHospitalDollarsFromGl),0))) * 100 end as 'SalaryVar'" + Environment.NewLine +
                    ", Sum(W.ContractAmount) as 'LaborSalaryForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalContractDollarsFromGl) as 'LaborSalaryPrior'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalContractDollarsFromGl) = 0 then 0 else (Sum(W.ContractAmount) / NULLIF(Sum(R.HistoricalContractDollarsFromGl), 0)) * 100 end as 'LaborSalaryVar'" + Environment.NewLine +
                    ",case when NULLIF(Sum(R.HistoricalContractDollarsFromGl) + Sum(R.HistoricalHospitalDollarsFromGl), 0) = 0 then 0 else ((Sum(W.ContractAmount) + Sum(W.EmployedSalaries)) / NULLIF(Sum(R.HistoricalContractDollarsFromGl) + Sum(R.HistoricalHospitalDollarsFromGl), 0)) * 100 end as 'TotalSalaryVar'" + Environment.NewLine +
                    "-- employed labor rate" + Environment.NewLine +
                    ",case when SUM(W.EmployeePaidManHours) = 0 then 0 else Sum(W.EmployedSalaries) / SUM(W.EmployeePaidManHours) end    as 'EmployedLaborRateForecast'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalPaidHours) = 0 then 0 else Sum(R.HistoricalHospitalDollarsFromGl)/NULLIF(Sum(R.HistoricalPaidHours),0) end as 'EmployedLaborRatePrior'" + Environment.NewLine +
                    ",case when  (SUM(W.EmployeePaidManHours) = 0 ) or (Sum(R.HistoricalHospitalDollarsFromGl) = 0) or (Sum(R.HistoricalPaidHours) = 0) then 0 else  ( (Sum(W.EmployedSalaries) / SUM(W.EmployeePaidManHours)) )/NULLIF(Sum(W.TotalPaidFtes),0)/NULLIF((Sum(R.HistoricalHospitalDollarsFromGl)/NULLIF(Sum(R.HistoricalPaidHours),0)),0) - 1  end as 'EmployedLaborRateVar'" + Environment.NewLine +
                    "-- contract labor rate" + Environment.NewLine +
                    ",case when SUM(W.ContractLaborHours) = 0 then 0 else  Sum(W.ContractAmount) / SUM(W.ContractLaborHours) end  as 'ContractLaborRateForecast'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalContractHours) = 0 then 0 else Sum(R.HistoricalContractDollarsFromGl)/NULLIF(Sum(R.HistoricalContractHours),0) end  as 'ContractLaborRatePrior'" + Environment.NewLine +
                    ",case when (SUM(W.ContractLaborHours) =0) or (Sum(R.HistoricalContractDollarsFromGl) =0 ) or (Sum(R.HistoricalContractHours) = 0) then 0 else  (( (Sum(W.ContractAmount) / SUM(W.ContractLaborHours))/NULLIF((Sum(R.HistoricalContractDollarsFromGl)/NULLIF(" + Environment.NewLine +
                    "Sum(R.HistoricalContractHours),0)),0)) -1) * 100 end as 'ContractLaborRateVar'" + Environment.NewLine +
                    "-- OT Hours" + Environment.NewLine +
                    ",case when SUM(W.EmployeeProductiveHours) = 0 then 0 else  (Sum(W.OtHours) / SUM(W.EmployeeProductiveHours) ) * 100 end   as 'OTPercentForecast'" + Environment.NewLine +
                    ",case when  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) =0 then 0 else  (SUM(R.HistoricalContractHours) /  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) ) * 100  end   as 'OTPercentPrior'" + Environment.NewLine +
                    ", case when  (SUM(W.EmployeeProductiveHours) = 0) or (SUM(R.HistoricalContractHours)= 0) or  (Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours) = 0) then 0 else  (((Sum(W.OtHours) / SUM(W.EmployeeProductiveHours) )  /" + Environment.NewLine +
                    "(SUM(R.HistoricalContractHours) /  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) )   )  - 1) end  as 'OTPercentVar'" + Environment.NewLine +
                    "FROM WftMonthlyValue W" + Environment.NewLine +
                    "JOIN [WftDepartment] WD ON WD.Id = W.WftDepartment_ID" + Environment.NewLine +
                    "JOIN [Department] D ON D.Id = WD.Department_ID" + Environment.NewLine +
                    "-- JOIN [Facility] F ON F.Id = D.Facility_ID" + Environment.NewLine +
                    "JOIN SubmissionDepartment SD ON D.Id = SD.DepartmentId" + Environment.NewLine +
                    "JOIN SubmissionDepartmentReferenceValue R ON SD.Id = R.SubmissionDepartment_ID and W.Month = R.Month" + Environment.NewLine +
                    "JOIN Submission S ON SD.Submission_ID = S.Id" + Environment.NewLine +
                    "WHERE S.WftPlan_ID = @PlanId and WD.WftPlan_ID = @PlanID and S.Id = @SubmissionID and D.IsInactiveInWFT=0" + Environment.NewLine +
                    "GROUP BY D.Number, D.Name" + Environment.NewLine +
                    "ORDER BY D.Number" + Environment.NewLine +
                    "END" + Environment.NewLine +
                    "ELSE" + Environment.NewLine +
                    "BEGIN" + Environment.NewLine +
                    "SELECT '(G) ' + ltrim(STR(DG.Number)) as 'DeptNumber'" + Environment.NewLine +
                    ", LEFT(DG.Description,15) as 'DeptName'" + Environment.NewLine +
                    ",( Sum(w.EmployeePaidManHours) )/@FortyBySeven  / @daysInYear as 'FTEsPaidForecast'" + Environment.NewLine +
                    ", (Sum(R.HistoricalPaidHours) )/@FortyBySeven  / @daysInPriorYear as 'FTEsPaidPrior'" + Environment.NewLine +
                    ", case  when (Sum(R.HistoricalPaidHours) )= 0  then 0 else (( Sum(w.EmployeePaidManHours) ) /@FortyBySeven  / @daysInYear / ((Sum(NULLIF(R.HistoricalPaidHours,0)))/@FortyBySeven  / @daysInPriorYear) - 1 ) *  100  end as 'FTEsPaidVar'" + Environment.NewLine +
                    ",(Sum(W.EmployeeProductiveHours)  )/@FortyBySeven / @daysInYear as 'FTEsProdForecast'" + Environment.NewLine +
                    ",( SUM(R.HistoricalProductiveHours))/@FortyBySeven  / @daysInPriorYear as 'FTEsProdPrior'" + Environment.NewLine +
                    ",case when ( SUM(R.HistoricalProductiveHours))=0 then 0 else" + Environment.NewLine +
                    "(( Sum(w.EmployeeProductiveHours)) /@FortyBySeven  / @daysInYear" + Environment.NewLine +
                    "/ ((Sum(NULLIF(R.HistoricalProductiveHours,0)))/@FortyBySeven  / @daysInPriorYear) - 1 ) *  100  end as 'FTEsProdVar'" + Environment.NewLine +
                    ", Sum(W.ContractLaborHours)/@FortyBySeven / @daysInYear  as 'FTEsContractForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalContractHours)/@FortyBySeven  / @daysInPriorYear  as 'FTEsContractPrior'" + Environment.NewLine +
                    ",case when Sum(isnull(R.HistoricalContractHours,0)) = 0 then 0" + Environment.NewLine +
                    "else  ((" + Environment.NewLine +
                    "(Sum(W.ContractLaborHours)/@FortyBySeven / @daysInYear) /" + Environment.NewLine +
                    "(Sum(isnull(R.HistoricalContractHours,0)) /@FortyBySeven  / @daysInPriorYear)" + Environment.NewLine +
                    ") -1) * 100 end as 'FTEsContractVar'" + Environment.NewLine +
                    ", Sum(W.EmployedSalaries) as 'SalaryForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalHospitalDollarsFromGl) as 'SalaryPrior'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalHospitalDollarsFromGl)  = 0 then 0 else ((Sum(W.EmployedSalaries) / NULLIF(Sum(R.HistoricalHospitalDollarsFromGl) ,0))) * 100 end as 'SalaryVar'" + Environment.NewLine +
                    ", Sum(W.ContractAmount) as 'LaborSalaryForecast'" + Environment.NewLine +
                    ", Sum(R.HistoricalContractDollarsFromGl) as 'LaborSalaryPrior'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalContractDollarsFromGl) = 0 then 0 else (Sum(W.ContractAmount) / NULLIF(Sum(R.HistoricalContractDollarsFromGl), 0)) * 100 end as 'LaborSalaryVar'" + Environment.NewLine +
                    ",case when NULLIF(Sum(R.HistoricalContractDollarsFromGl) + Sum(R.HistoricalHospitalDollarsFromGl), 0) = 0 then 0 else ((Sum(W.ContractAmount) + Sum(W.EmployedSalaries)) / NULLIF(Sum(R.HistoricalContractDollarsFromGl) + Sum(R.HistoricalHospitalDollarsFromGl), 0)) * 100 end as 'TotalSalaryVar'" + Environment.NewLine +
                    "-- employed labor rate" + Environment.NewLine +
                    ",case when SUM(W.EmployeePaidManHours) = 0 then 0 else Sum(W.EmployedSalaries) / SUM(W.EmployeePaidManHours) end    as 'EmployedLaborRateForecast'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalPaidHours) = 0 then 0 else Sum(R.HistoricalHospitalDollarsFromGl)/NULLIF(Sum(R.HistoricalPaidHours),0) end as 'EmployedLaborRatePrior'" + Environment.NewLine +
                    ",case when  (SUM(W.EmployeePaidManHours) = 0 ) or (Sum(R.HistoricalHospitalDollarsFromGl) = 0) or (Sum(R.HistoricalPaidHours) = 0) then 0 else  ( (Sum(W.EmployedSalaries) / SUM(W.EmployeePaidManHours)) )/NULLIF(Sum(W.TotalPaidFtes),0)/NULLIF((Sum(R.HistoricalHospitalDollarsFromGl)/NULLIF(Sum(R.HistoricalPaidHours),0)),0) - 1  end as 'EmployedLaborRateVar'" + Environment.NewLine +
                    "-- contract labor rate" + Environment.NewLine +
                    ",case when SUM(W.ContractLaborHours) = 0 then 0 else  Sum(W.ContractAmount) / SUM(W.ContractLaborHours) end  as 'ContractLaborRateForecast'" + Environment.NewLine +
                    ",case when Sum(R.HistoricalContractHours) = 0 then 0 else Sum(R.HistoricalContractDollarsFromGl)/NULLIF(Sum(R.HistoricalContractHours),0) end  as 'ContractLaborRatePrior'" + Environment.NewLine +
                    ",case when (SUM(W.ContractLaborHours) =0) or (Sum(R.HistoricalContractDollarsFromGl) =0 ) or (Sum(R.HistoricalContractHours) = 0) then 0 else  (( (Sum(W.ContractAmount) / SUM(W.ContractLaborHours))/NULLIF((Sum(R.HistoricalContractDollarsFromGl)/NULLIF(" + Environment.NewLine +
                    "Sum(R.HistoricalContractHours),0)),0)) -1) * 100 end as 'ContractLaborRateVar'" + Environment.NewLine +
                    "-- OT Hours" + Environment.NewLine +
                    ",case when SUM(W.EmployeeProductiveHours) = 0 then 0 else  (Sum(W.OtHours) / SUM(W.EmployeeProductiveHours) ) * 100 end   as 'OTPercentForecast'" + Environment.NewLine +
                    ",case when  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) =0 then 0 else  (SUM(R.HistoricalContractHours) /  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) ) * 100  end   as 'OTPercentPrior'" + Environment.NewLine +
                    ", case when  (SUM(W.EmployeeProductiveHours) = 0) or (SUM(R.HistoricalContractHours)= 0) or  (Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours) = 0) then 0 else  (((Sum(W.OtHours) / SUM(W.EmployeeProductiveHours) )  /" + Environment.NewLine +
                    "(SUM(R.HistoricalContractHours) /  ( Sum(R.HistoricalContractHours) + SUM (R.HistoricalProductiveHours)) )   )  - 1) end  as 'OTPercentVar'" + Environment.NewLine +
                    "FROM WftMonthlyValue W" + Environment.NewLine +
                    "JOIN [WftDepartment] WD ON WD.Id = W.WftDepartment_ID" + Environment.NewLine +
                    "JOIN [Department] D ON D.Id = WD.Department_ID" + Environment.NewLine +
                    "-- JOIN [Facility] F ON F.Id = D.Facility_ID" + Environment.NewLine +
                    "JOIN SubmissionDepartment SD ON D.Id = SD.DepartmentId" + Environment.NewLine +
                    "JOIN SubmissionDepartmentReferenceValue R ON SD.Id = R.SubmissionDepartment_ID and W.Month = R.Month" + Environment.NewLine +
                    "JOIN DepartmentGroup DG ON D.DepartmentGroup_ID = DG.Id" + Environment.NewLine +
                    "JOIN Submission S ON SD.Submission_ID = S.Id" + Environment.NewLine +
                    "WHERE S.WftPlan_ID = @PlanId and WD.WftPlan_ID = @PlanID and S.Id = @SubmissionID and d.IsInactiveInWFT=0" + Environment.NewLine +
                    "GROUP BY DG.Number, DG.Description" + Environment.NewLine +
                    "END" + Environment.NewLine +
                    "END" + Environment.NewLine;
            return EmployedAndContractFteCountsSp;
        }

        public class LaborForecastRepository
        {
            private readonly string _connectionString;

            public LaborForecastRepository(string connectionString)
            {
                _connectionString = connectionString;
            }

            public static List<LaborForecastData> GetLaborForecastData(int GroupOnly)
            {
                var results = new List<LaborForecastData>();

                string DB = RunData.DatabaseName;
                string sServerName = RunData.ServerName;
                string _connectionString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";

                var query = GetEmployedAndContractFteCountsSpQuery(GroupOnly);

                using (var connection = new SqlConnection(_connectionString))
                {
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.CommandType = CommandType.Text;                      

                        try
                        {
                            connection.Open();
                            using (var reader = command.ExecuteReader())
                            {
                                Thread.Sleep(5000);
                                while (reader.Read())
                                {
                                    results.Add(MapToObject(reader));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            // Log exception or handle as needed
                            throw new Exception($"Error executing query: {ex.Message}", ex);
                        }
                    }
                }

                return results;
            }

            private static LaborForecastData MapToObject(IDataReader reader)
            {
                return new LaborForecastData
                {
                    DeptNumber = GetSafeString(reader, "DeptNumber"),
                    DeptName = GetSafeString(reader, "DeptName"),

                    FTEsPaidForecast = GetSafeDecimal(reader, "FTEsPaidForecast"),
                    FTEsPaidPrior = GetSafeDecimal(reader, "FTEsPaidPrior"),
                    FTEsPaidVar = GetSafeDecimal(reader, "FTEsPaidVar") ,

                    FTEsProdForecast = GetSafeDecimal(reader, "FTEsProdForecast"),
                    FTEsProdPrior = GetSafeDecimal(reader, "FTEsProdPrior"),
                    FTEsProdVar = GetSafeDecimal(reader, "FTEsProdVar"),

                    FTEsContractForecast = GetSafeDecimal(reader, "FTEsContractForecast"),
                    FTEsContractPrior = GetSafeDecimal(reader, "FTEsContractPrior"),
                    FTEsContractVar = GetSafeDecimal(reader, "FTEsContractVar"),

                    SalaryForecast = GetSafeDecimal(reader, "SalaryForecast"),
                    SalaryPrior = GetSafeDecimal(reader, "SalaryPrior"),
                    SalaryVar = GetSafeDecimal(reader, "SalaryVar") ,

                    LaborSalaryForecast = GetSafeDecimal(reader, "LaborSalaryForecast"),
                    LaborSalaryPrior = GetSafeDecimal(reader, "LaborSalaryPrior"),
                    LaborSalaryVar = GetSafeDecimal(reader, "LaborSalaryVar"),

                    TotalSalaryVar = GetSafeDecimal(reader, "TotalSalaryVar"),

                    EmployedLaborRateForecast = GetSafeDecimal(reader, "EmployedLaborRateForecast"),
                    EmployedLaborRatePrior = GetSafeDecimal(reader, "EmployedLaborRatePrior"),
                    EmployedLaborRateVar = GetSafeDecimal(reader, "EmployedLaborRateVar") * 100,

                    ContractLaborRateForecast = GetSafeDecimal(reader, "ContractLaborRateForecast"),
                    ContractLaborRatePrior = GetSafeDecimal(reader, "ContractLaborRatePrior"),
                    ContractLaborRateVar = GetSafeDecimal(reader, "ContractLaborRateVar"),

                    OTPercentForecast = GetSafeDecimal(reader, "OTPercentForecast"),
                    OTPercentPrior = GetSafeDecimal(reader, "OTPercentPrior"),
                    OTPercentVar = GetSafeDecimal(reader, "OTPercentVar") 
                };
            }

            // Helper methods for safe data reading
            private static string GetSafeString(IDataReader reader, string columnName)
            {
                var ordinal = reader.GetOrdinal(columnName);
                return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
            }

            private static double GetSafeDecimal(IDataReader reader, string columnName)
            {
                var ordinal = reader.GetOrdinal(columnName);
                if (reader.IsDBNull(ordinal))
                    return 0.00;                
                
                var value  = reader.GetValue(ordinal);
                return Math.Round(Convert.ToDouble(value),2);
            }
        }


    }
}
