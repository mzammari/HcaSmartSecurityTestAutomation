﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class LaborForecastData
    {
        public string DeptNumber { get; set; }
        public string DeptName { get; set; }

        // FTEs Paid
        public double FTEsPaidForecast { get; set; }
        public double FTEsPaidPrior { get; set; }
        public double FTEsPaidVar { get; set; }

        // FTEs Prod
        public double FTEsProdForecast { get; set; }
        public double FTEsProdPrior { get; set; }
        public double FTEsProdVar { get; set; }

        // FTEs Contract
        public double FTEsContractForecast { get; set; }
        public double FTEsContractPrior { get; set; }
        public double FTEsContractVar { get; set; }

        // Salary
        public double SalaryForecast { get; set; }
        public double SalaryPrior { get; set; }
        public double SalaryVar { get; set; }     


        // Labor Salary
        public double LaborSalaryForecast { get; set; }
        public double LaborSalaryPrior { get; set; }
        public double LaborSalaryVar { get; set; }

        // Total
        public double TotalSalaryVar { get; set; }

        // Employed Labor Rate
        public double EmployedLaborRateForecast { get; set; }
        public double EmployedLaborRatePrior { get; set; }
        public double EmployedLaborRateVar { get; set; }

        // Contract Labor Rate
        public double ContractLaborRateForecast { get; set; }
        public double ContractLaborRatePrior { get; set; }
        public double ContractLaborRateVar { get; set; }

        // OT Percent
        public double OTPercentForecast { get; set; }
        public double OTPercentPrior { get; set; }
        public double OTPercentVar { get; set; }
    }

    public class LaborForecastCalculatedData
    {
        public string DeptNumber { get; set; }
        public string DeptName { get; set; }

        // FTEs Paid
        public double FTEsPaidForecast { get; set; }
        public double FTEsPaidPrior { get; set; }
        public double FTEsPaidVar { get; set; }
        public double FTEsPaidVarPercent { get; set; }

        // FTEs Prod
        public double FTEsProdForecast { get; set; }
        public double FTEsProdPrior { get; set; }
        public double FTEsProdVar { get; set; }
        public double FTEsProdVarPercent { get; set; }


        // FTEs Contract
        public double FTEsContractForecast { get; set; }
        public double FTEsContractPrior { get; set; }
        public double FTEsContractVar { get; set; }
        public double FTEsContractVarPercent { get; set; }

        // Salary
        public double SalaryForecast { get; set; }
        public double SalaryPrior { get; set; }
        public double SalaryVar { get; set; }
        public double SalaryVarPercent { get; set; }

        // Labor Salary
        public double LaborSalaryForecast { get; set; }
        public double LaborSalaryPrior { get; set; }
        public double LaborSalaryVar { get; set; }
        public double LaborSalaryVarPercent { get; set; }
        // Total
        public double TotalSalaryVar { get; set; }

        // Employed Labor Rate
        public double EmployedLaborRateForecast { get; set; }
        public double EmployedLaborRatePrior { get; set; }
        public double EmployedLaborRateVar { get; set; }
        public double EmployedLaborRateVarPercent { get; set; }

        // Contract Labor Rate
        public double ContractLaborRateForecast { get; set; }
        public double ContractLaborRatePrior { get; set; }
        public double ContractLaborRateVar { get; set; }
        public double ContractLaborRateVarPercent { get; set; }

        // OT Percent
        public double OTPercentForecast { get; set; }
        public double OTPercentPrior { get; set; }
        public double OTPercentVar { get; set; }
        public double OTPercentVarPercent { get; set; }
    }
}
