﻿using System;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Forecast Labor Summary - Monthly Department Detail Comparison Report
    /// Contains Plan 1 and Plan 2 department-level data
    /// </summary>
    public class MonthlyDepartmentDetailComparison
    {
        public DepartmentPlanData Plan1 { get; set; }
        public DepartmentPlanData Plan2 { get; set; }

        public MonthlyDepartmentDetailComparison()
        {
            Plan1 = new DepartmentPlanData();
            Plan2 = new DepartmentPlanData();
        }
    }

    /// <summary>
    /// Department Plan Data - contains all metrics for a single plan
    /// </summary>
    public class DepartmentPlanData
    {
        // Identifiers
        public int IndexId { get; set; }
        public long PlanId { get; set; }
        public long WftDepartment_ID { get; set; }
        public int DepartmentNumber { get; set; }
        public int Year { get; set; }

        // Department Details
        public string DeptType { get; set; }
        public int DeptNumber { get; set; }
        public string DeptName { get; set; }
        public string FacilityDesc { get; set; }
        public string StatDescription { get; set; }

        // Compare To Details (for Plan 2 comparison)
        public string DeptTypeCompareTo { get; set; }
        public int DeptNumberCompareTo { get; set; }
        public string DeptNameCompareTo { get; set; }
        public string FacilityDescCompareTo { get; set; }
        public string StatDescriptionCompareTo { get; set; }

        // FTE Metrics (8 metrics with monthly data)
        public DeptEmployedProductiveFtes EmployedProductiveFtes { get; set; } = new DeptEmployedProductiveFtes();
        public DeptContractLaborPercent ContractLaborPercent { get; set; } = new DeptContractLaborPercent();
        public DeptContractFtes ContractFtes { get; set; } = new DeptContractFtes();
        public DeptTotalProductiveFtes TotalProductiveFtes { get; set; } = new DeptTotalProductiveFtes();
        public DeptNonProductivePercent NonProductivePercent { get; set; } = new DeptNonProductivePercent();
        public DeptNonProductiveFtes NonProductiveFtes { get; set; } = new DeptNonProductiveFtes();
        public DeptEmployedPaidFtes EmployedPaidFtes { get; set; } = new DeptEmployedPaidFtes();
        public DeptTotalFtes TotalFtes { get; set; } = new DeptTotalFtes();

        // Labor Expense Metrics (8 metrics)
        public DeptTotalSalariesAndWages TotalSalariesAndWages { get; set; } = new DeptTotalSalariesAndWages();
        public DeptTotalContractLaborDollars TotalContractLaborDollars { get; set; } = new DeptTotalContractLaborDollars();
        public DeptTotalLaborExpense TotalLaborExpense { get; set; } = new DeptTotalLaborExpense();
        public DeptEmployedLaborRate EmployedLaborRate { get; set; } = new DeptEmployedLaborRate();
        public DeptContactLaborRate ContactLaborRate { get; set; } = new DeptContactLaborRate();
        public DeptOverTimePremiumDollars OverTimePremiumDollars { get; set; } = new DeptOverTimePremiumDollars();
        public DeptOtPercent OtPercent { get; set; } = new DeptOtPercent();
        public DeptOtFte OtFte { get; set; } = new DeptOtFte();

        // Volume/Productivity Metrics (6 metrics)
        public DeptUOS DeptUOS { get; set; } = new DeptUOS();
        public DeptSemiVariableFtes SemiVariableFtes { get; set; } = new DeptSemiVariableFtes();
        public DeptVariableProdHrsPerUOS VariableProdHrsPerUOS { get; set; } = new DeptVariableProdHrsPerUOS();
        public DeptTotalProdHrsPerUOS TotalProdHrsPerUOS { get; set; } = new DeptTotalProdHrsPerUOS();
        public DeptTotalPaidHrsPerUOS TotalPaidHrsPerUOS { get; set; } = new DeptTotalPaidHrsPerUOS();
        public DeptMinFTE MinFTE { get; set; } = new DeptMinFTE();

        // Max Values (26 metrics)
        public DeptMaxEmployedProductiveFtes Max_EmployedProductiveFtes { get; set; } = new DeptMaxEmployedProductiveFtes();
        public DeptMaxContractLaborPercent Max_ContractLaborPercent { get; set; } = new DeptMaxContractLaborPercent();
        public DeptMaxContractFtes Max_ContractFtes { get; set; } = new DeptMaxContractFtes();
        public DeptMaxTotalProductiveFtes Max_TotalProductiveFtes { get; set; } = new DeptMaxTotalProductiveFtes();
        public DeptMaxNonProductivePercent Max_NonProductivePercent { get; set; } = new DeptMaxNonProductivePercent();
        public DeptMaxNonProductiveFtes Max_NonProductiveFtes { get; set; } = new DeptMaxNonProductiveFtes();
        public DeptMaxEmployedPaidFtes Max_EmployedPaidFtes { get; set; } = new DeptMaxEmployedPaidFtes();
        public DeptMaxTotalFtes Max_TotalFtes { get; set; } = new DeptMaxTotalFtes();
        public DeptMaxTotalSalariesAndWages Max_TotalSalariesAndWages { get; set; } = new DeptMaxTotalSalariesAndWages();
        public DeptMaxTotalContractLaborDollars Max_TotalContractLaborDollars { get; set; } = new DeptMaxTotalContractLaborDollars();
        public DeptMaxTotalLaborExpense Max_TotalLaborExpense { get; set; } = new DeptMaxTotalLaborExpense();
        public DeptMaxEmployedLaborRate Max_EmployedLaborRate { get; set; } = new DeptMaxEmployedLaborRate();
        public DeptMaxContactLaborRate Max_ContactLaborRate { get; set; } = new DeptMaxContactLaborRate();
        public DeptMaxOverTimePremiumDollars Max_OverTimePremiumDollars { get; set; } = new DeptMaxOverTimePremiumDollars();
        public DeptMaxOtPercent Max_OtPercent { get; set; } = new DeptMaxOtPercent();
        public DeptMaxOtFte Max_OtFte { get; set; } = new DeptMaxOtFte();
        public DeptMaxDeptUOS Max_DeptUOS { get; set; } = new DeptMaxDeptUOS();
        public DeptMaxSemiVariableFtes Max_SemiVariableFtes { get; set; } = new DeptMaxSemiVariableFtes();
        public DeptMaxVariableProdHrsPerUOS Max_VariableProdHrsPerUOS { get; set; } = new DeptMaxVariableProdHrsPerUOS();
        public DeptMaxTotalProdHrsPerUOS Max_TotalProdHrsPerUOS { get; set; } = new DeptMaxTotalProdHrsPerUOS();
        public DeptMaxTotalPaidHrsPerUOS Max_TotalPaidHrsPerUOS { get; set; } = new DeptMaxTotalPaidHrsPerUOS();
        public DeptMaxMinFTE Max_MinFTE { get; set; } = new DeptMaxMinFTE();

        // Min Values (26 metrics)
        public DeptMinEmployedProductiveFtes Min_EmployedProductiveFtes { get; set; } = new DeptMinEmployedProductiveFtes();
        public DeptMinContractLaborPercent Min_ContractLaborPercent { get; set; } = new DeptMinContractLaborPercent();
        public DeptMinContractFtes Min_ContractFtes { get; set; } = new DeptMinContractFtes();
        public DeptMinTotalProductiveFtes Min_TotalProductiveFtes { get; set; } = new DeptMinTotalProductiveFtes();
        public DeptMinNonProductivePercent Min_NonProductivePercent { get; set; } = new DeptMinNonProductivePercent();
        public DeptMinNonProductiveFtes Min_NonProductiveFtes { get; set; } = new DeptMinNonProductiveFtes();
        public DeptMinEmployedPaidFtes Min_EmployedPaidFtes { get; set; } = new DeptMinEmployedPaidFtes();
        public DeptMinTotalFtes Min_TotalFtes { get; set; } = new DeptMinTotalFtes();
        public DeptMinTotalSalariesAndWages Min_TotalSalariesAndWages { get; set; } = new DeptMinTotalSalariesAndWages();
        public DeptMinTotalContractLaborDollars Min_TotalContractLaborDollars { get; set; } = new DeptMinTotalContractLaborDollars();
        public DeptMinTotalLaborExpense Min_TotalLaborExpense { get; set; } = new DeptMinTotalLaborExpense();
        public DeptMinEmployedLaborRate Min_EmployedLaborRate { get; set; } = new DeptMinEmployedLaborRate();
        public DeptMinContactLaborRate Min_ContactLaborRate { get; set; } = new DeptMinContactLaborRate();
        public DeptMinOverTimePremiumDollars Min_OverTimePremiumDollars { get; set; } = new DeptMinOverTimePremiumDollars();
        public DeptMinOtPercent Min_OtPercent { get; set; } = new DeptMinOtPercent();
        public DeptMinOtFte Min_OtFte { get; set; } = new DeptMinOtFte();
        public DeptMinDeptUOS Min_DeptUOS { get; set; } = new DeptMinDeptUOS();
        public DeptMinSemiVariableFtes Min_SemiVariableFtes { get; set; } = new DeptMinSemiVariableFtes();
        public DeptMinVariableProdHrsPerUOS Min_VariableProdHrsPerUOS { get; set; } = new DeptMinVariableProdHrsPerUOS();
        public DeptMinTotalProdHrsPerUOS Min_TotalProdHrsPerUOS { get; set; } = new DeptMinTotalProdHrsPerUOS();
        public DeptMinTotalPaidHrsPerUOS Min_TotalPaidHrsPerUOS { get; set; } = new DeptMinTotalPaidHrsPerUOS();
        public DeptMinMinFTE Min_MinFTE { get; set; } = new DeptMinMinFTE();
    }

    

    // FTE Metrics
    public class DeptEmployedProductiveFtes : MonthlyData { }
    public class DeptContractLaborPercent : MonthlyData { }
    public class DeptContractFtes : MonthlyData { }
    public class DeptTotalProductiveFtes : MonthlyData { }
    public class DeptNonProductivePercent : MonthlyData { }
    public class DeptNonProductiveFtes : MonthlyData { }
    public class DeptEmployedPaidFtes : MonthlyData { }
    public class DeptTotalFtes : MonthlyData { }

    // Labor Expense Metrics
    public class DeptTotalSalariesAndWages : MonthlyData { }
    public class DeptTotalContractLaborDollars : MonthlyData { }
    public class DeptTotalLaborExpense : MonthlyData { }
    public class DeptEmployedLaborRate : MonthlyData { }
    public class DeptContactLaborRate : MonthlyData { }
    public class DeptOverTimePremiumDollars : MonthlyData { }
    public class DeptOtPercent : MonthlyData { }
    public class DeptOtFte : MonthlyData { }

    // Volume/Productivity Metrics
    public class DeptUOS : MonthlyData { }
    public class DeptSemiVariableFtes : MonthlyData { }
    public class DeptVariableProdHrsPerUOS : MonthlyData { }
    public class DeptTotalProdHrsPerUOS : MonthlyData { }
    public class DeptTotalPaidHrsPerUOS : MonthlyData { }
    public class DeptMinFTE : MonthlyData { }

    // Max Metrics
    public class DeptMaxEmployedProductiveFtes : MonthlyData { }
    public class DeptMaxContractLaborPercent : MonthlyData { }
    public class DeptMaxContractFtes : MonthlyData { }
    public class DeptMaxTotalProductiveFtes : MonthlyData { }
    public class DeptMaxNonProductivePercent : MonthlyData { }
    public class DeptMaxNonProductiveFtes : MonthlyData { }
    public class DeptMaxEmployedPaidFtes : MonthlyData { }
    public class DeptMaxTotalFtes : MonthlyData { }
    public class DeptMaxTotalSalariesAndWages : MonthlyData { }
    public class DeptMaxTotalContractLaborDollars : MonthlyData { }
    public class DeptMaxTotalLaborExpense : MonthlyData { }
    public class DeptMaxEmployedLaborRate : MonthlyData { }
    public class DeptMaxContactLaborRate : MonthlyData { }
    public class DeptMaxOverTimePremiumDollars : MonthlyData { }
    public class DeptMaxOtPercent : MonthlyData { }
    public class DeptMaxOtFte : MonthlyData { }
    public class DeptMaxDeptUOS : MonthlyData { }
    public class DeptMaxSemiVariableFtes : MonthlyData { }
    public class DeptMaxVariableProdHrsPerUOS : MonthlyData { }
    public class DeptMaxTotalProdHrsPerUOS : MonthlyData { }
    public class DeptMaxTotalPaidHrsPerUOS : MonthlyData { }
    public class DeptMaxMinFTE : MonthlyData { }

    // Min Metrics
    public class DeptMinEmployedProductiveFtes : MonthlyData { }
    public class DeptMinContractLaborPercent : MonthlyData { }
    public class DeptMinContractFtes : MonthlyData { }
    public class DeptMinTotalProductiveFtes : MonthlyData { }
    public class DeptMinNonProductivePercent : MonthlyData { }
    public class DeptMinNonProductiveFtes : MonthlyData { }
    public class DeptMinEmployedPaidFtes : MonthlyData { }
    public class DeptMinTotalFtes : MonthlyData { }
    public class DeptMinTotalSalariesAndWages : MonthlyData { }
    public class DeptMinTotalContractLaborDollars : MonthlyData { }
    public class DeptMinTotalLaborExpense : MonthlyData { }
    public class DeptMinEmployedLaborRate : MonthlyData { }
    public class DeptMinContactLaborRate : MonthlyData { }
    public class DeptMinOverTimePremiumDollars : MonthlyData { }
    public class DeptMinOtPercent : MonthlyData { }
    public class DeptMinOtFte : MonthlyData { }
    public class DeptMinDeptUOS : MonthlyData { }
    public class DeptMinSemiVariableFtes : MonthlyData { }
    public class DeptMinVariableProdHrsPerUOS : MonthlyData { }
    public class DeptMinTotalProdHrsPerUOS : MonthlyData { }
    public class DeptMinTotalPaidHrsPerUOS : MonthlyData { }
    public class DeptMinMinFTE : MonthlyData { }
}