﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Validates Monthly Department Detail data between SQL Database and Excel
    /// Compares Plan 1 (Index 1) from DB vs P1 from Excel
    /// Compares Plan 2 (Index 2) from DB vs P2 from Excel
    /// </summary>
    public class MonthlyDepartmentDetailValidator
    {
        private const double TOLERANCE = 0.02;

        /// <summary>
                /// Validate both Plan 1 and Plan 2 between DB and Excel
                /// </summary>
                /// <param name="dbData">Data from SQL database</param>
                /// <param name="excelData">Data from Excel file</param>
        public static void Validate(MonthlyDepartmentDetailComparison dbData, MonthlyDepartmentDetailComparison excelData)
        {
            Console.WriteLine("=== Monthly Department Detail Validation ===\n");

            // Validate Plan 1 (Index 1 -> P1)
            Console.WriteLine("--- Validating Plan 1 (DB Index 1 vs Excel P1) ---");
            ValidatePlan(dbData.Plan1, excelData.Plan1, "Plan 1");

            // Validate Plan 2 (Index 2 -> P2)
            Console.WriteLine("\n--- Validating Plan 2 (DB Index 2 vs Excel P2) ---");
            ValidatePlan(dbData.Plan2, excelData.Plan2, "Plan 2");
        }

        /// <summary>
                /// Validate Plan 1 only
                /// </summary>
        public static void ValidatePlan1(MonthlyDepartmentDetailComparison dbData, MonthlyDepartmentDetailComparison excelData)
        {
            Console.WriteLine("=== Validating Plan 1 (DB Index 1 vs Excel P1) ===\n");
            ValidatePlan(dbData.Plan1, excelData.Plan1, "Plan 1");
        }

        /// <summary>
                /// Validate Plan 2 only
                /// </summary>
        public static void ValidatePlan2(MonthlyDepartmentDetailComparison dbData, MonthlyDepartmentDetailComparison excelData)
        {
            Console.WriteLine("=== Validating Plan 2 (DB Index 2 vs Excel P2) ===\n");
            ValidatePlan(dbData.Plan2, excelData.Plan2, "Plan 2");
        }

        private static void ValidatePlan(DepartmentPlanData dbPlan, DepartmentPlanData excelPlan, string planName)
        {
            var mismatches = new List<MetricMismatch>();

            // FTE Summary (8 metrics × 13 values = 104 comparisons)
            CompareMetric(mismatches, "Employed Productive FTEs", dbPlan.EmployedProductiveFtes, excelPlan.EmployedProductiveFtes);
            CompareMetric(mismatches, "Contract Labor Percent", dbPlan.ContractLaborPercent, excelPlan.ContractLaborPercent);
            CompareMetric(mismatches, "Contract FTEs", dbPlan.ContractFtes, excelPlan.ContractFtes);
            CompareMetric(mismatches, "Total Productive FTEs", dbPlan.TotalProductiveFtes, excelPlan.TotalProductiveFtes);
            CompareMetric(mismatches, "Non-Productive Percent", dbPlan.NonProductivePercent, excelPlan.NonProductivePercent);
            CompareMetric(mismatches, "Non-Productive FTEs", dbPlan.NonProductiveFtes, excelPlan.NonProductiveFtes);
            CompareMetric(mismatches, "Employed Paid FTEs", dbPlan.EmployedPaidFtes, excelPlan.EmployedPaidFtes);
            CompareMetric(mismatches, "Total FTEs", dbPlan.TotalFtes, excelPlan.TotalFtes);

            // Labor Expense Summary (8 metrics × 13 values = 104 comparisons)
            CompareMetric(mismatches, "Total Salaries And Wages", dbPlan.TotalSalariesAndWages, excelPlan.TotalSalariesAndWages);
            CompareMetric(mismatches, "Total Contract Labor Dollars", dbPlan.TotalContractLaborDollars, excelPlan.TotalContractLaborDollars);
            CompareMetric(mismatches, "Total Labor Expense", dbPlan.TotalLaborExpense, excelPlan.TotalLaborExpense);
            CompareMetric(mismatches, "Employed Labor Rate", dbPlan.EmployedLaborRate, excelPlan.EmployedLaborRate);
            CompareMetric(mismatches, "Contact Labor Rate", dbPlan.ContactLaborRate, excelPlan.ContactLaborRate);
            CompareMetric(mismatches, "Overtime Premium Dollars", dbPlan.OverTimePremiumDollars, excelPlan.OverTimePremiumDollars);
            CompareMetric(mismatches, "Overtime Percent", dbPlan.OtPercent, excelPlan.OtPercent);
            CompareMetric(mismatches, "Overtime FTE", dbPlan.OtFte, excelPlan.OtFte);

            // Volume Summary (6 metrics × 13 values = 78 comparisons)
            CompareMetric(mismatches, "Department UOS", dbPlan.DeptUOS, excelPlan.DeptUOS);
            CompareMetric(mismatches, "Semi-Variable FTEs", dbPlan.SemiVariableFtes, excelPlan.SemiVariableFtes);
            CompareMetric(mismatches, "Variable Prod Hrs/UOS", dbPlan.VariableProdHrsPerUOS, excelPlan.VariableProdHrsPerUOS);
            CompareMetric(mismatches, "Total Prod Hrs/UOS", dbPlan.TotalProdHrsPerUOS, excelPlan.TotalProdHrsPerUOS);
            CompareMetric(mismatches, "Total Paid Hrs/UOS", dbPlan.TotalPaidHrsPerUOS, excelPlan.TotalPaidHrsPerUOS);
            CompareMetric(mismatches, "Min FTE", dbPlan.MinFTE, excelPlan.MinFTE);

            // Total comparisons: 22 metrics × 13 values = 286 comparisons
            int totalComparisons = 22 * 13;
            int matchCount = totalComparisons - mismatches.Count;
            double matchPercentage = (matchCount * 100.0) / totalComparisons;

            // Print summary
            Console.WriteLine($"{planName} Validation Summary:");
            Console.WriteLine($"  Department: {dbPlan.DeptName} (Dept #{dbPlan.DeptNumber})");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");

            // Print mismatches if any
            if (mismatches.Count > 0)
            {
                Console.WriteLine($"\n{planName} Mismatches:");
                Console.WriteLine($"{"Metric",-40} {"Month",-8} {"DB",12} {"Excel",12} {"Diff",10}");
                Console.WriteLine(new string('-', 85));

                foreach (var mismatch in mismatches)
                {
                    double diff = mismatch.DbValue - mismatch.ExcelValue;
                    Console.WriteLine($"{mismatch.MetricName,-40} {mismatch.Month,-8} " +
                            $"{mismatch.DbValue,12:N2} {mismatch.ExcelValue,12:N2} {diff,10:N2}");
                }

                // Fail the test
                var message = $"{planName} validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons";
                Assert.Fail(message);
            }
            else
            {
                Console.WriteLine($"✓ {planName} validated successfully - all values match!\n");
            }
        }

        private static void CompareMetric(List<MetricMismatch> mismatches, string metricName, MonthlyData dbData, MonthlyData excelData)
        {
            CompareValue(mismatches, metricName, "Jan", dbData.Jan, excelData.Jan);
            CompareValue(mismatches, metricName, "Feb", dbData.Feb, excelData.Feb);
            CompareValue(mismatches, metricName, "Mar", dbData.Mar, excelData.Mar);
            CompareValue(mismatches, metricName, "Apr", dbData.Apr, excelData.Apr);
            CompareValue(mismatches, metricName, "May", dbData.May, excelData.May);
            CompareValue(mismatches, metricName, "Jun", dbData.Jun, excelData.Jun);
            CompareValue(mismatches, metricName, "Jul", dbData.Jul, excelData.Jul);
            CompareValue(mismatches, metricName, "Aug", dbData.Aug, excelData.Aug);
            CompareValue(mismatches, metricName, "Sep", dbData.Sep, excelData.Sep);
            CompareValue(mismatches, metricName, "Oct", dbData.Oct, excelData.Oct);
            CompareValue(mismatches, metricName, "Nov", dbData.Nov, excelData.Nov);
            CompareValue(mismatches, metricName, "Dec", dbData.Dec, excelData.Dec);
            CompareValue(mismatches, metricName, "Total", dbData.Total, excelData.Total);
        }

        private static void CompareValue(List<MetricMismatch> mismatches, string metricName, string month, double dbValue, double excelValue)
        {
            bool isMatch = Math.Abs(dbValue - excelValue) <= TOLERANCE;

            if (!isMatch)
            {
                mismatches.Add(new MetricMismatch
                {
                    MetricName = metricName,
                    Month = month,
                    DbValue = dbValue,
                    ExcelValue = excelValue
                });
            }
        }

        private class MetricMismatch
        {
            public string MetricName { get; set; }
            public string Month { get; set; }
            public double DbValue { get; set; }
            public double ExcelValue { get; set; }
        }
    }
}