﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class LaborSummaryMonthlyComparisonReport
    {
        public static void GoTo()
        {
            WFTMainMenu.WFTReports.Department.SelectLaborSummaryMonthlyComparison();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to Labor Summary Monthly Comparison report", "Labor Summary Monthly Comparison report page is displayed.");
        }
        public static bool IsAt
        {
            get
            {
                By byPlan1Dept = By.XPath("//select[@id='ddlDepartment']");
                return CommonFunctions.IsElementDisplayed(byPlan1Dept, 20);
            }
        }

        public static LaborSummaryMonthlyComparisonReportCommands Report()
        {
            return new LaborSummaryMonthlyComparisonReportCommands();
        }

    }
    #region: LaborSummaryMonthlyComparisonReportCommands
    public class LaborSummaryMonthlyComparisonReportCommands
    {
        private string plan1Year;
        private string plan1Status;
        private string plan1Name;
        private string plan1Dept;
        private string plan2Year;
        private string plan2Status;
        private string plan2Name;
        private string plan2Dept;

        public LaborSummaryMonthlyComparisonReportCommands withPlan1Year(string Plan1Year)
        {
            this.plan1Year = Plan1Year;
            return this;
        }

        public LaborSummaryMonthlyComparisonReportCommands withPlan1Status(string Plan1Status)
        {
            this.plan1Status = Plan1Status;
            return this;
        }

        public LaborSummaryMonthlyComparisonReportCommands withPlan1Name(string Plan1Name)
        {
            this.plan1Name = Plan1Name;
            return this;
        }

        public LaborSummaryMonthlyComparisonReportCommands withPlan1Dept(string Plan1Dept)
        {
            this.plan1Dept = Plan1Dept;
            return this;
        }

        public LaborSummaryMonthlyComparisonReportCommands withPlan2Year(string Plan2Year)
        {
            this.plan2Year = Plan2Year;
            return this;
        }

        public LaborSummaryMonthlyComparisonReportCommands withPlan2Status(string Plan2Status)
        {
            this.plan2Status = Plan2Status;
            return this;
        }

        public LaborSummaryMonthlyComparisonReportCommands withPlan2Name(string Plan2Name)
        {
            this.plan2Name = Plan2Name;
            return this;
        }

        public LaborSummaryMonthlyComparisonReportCommands withPlan2Dept(string Plan2Dept)
        {
            this.plan2Dept = Plan2Dept;
            return this;
        }

        private void setPlan1Year()
        {
            By byPlan1Year = By.XPath("//select[@id='ddlReportYear']");
            IWebElement mnuPlan1Year = CommonFunctions.getElement(byPlan1Year);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlan1Year, plan1Year);
            CommonFunctions.AddTestStep($"Verify a user can select {plan1Year} from Plan 1 year dropdown", $"The {plan1Year} is selected correctly");
        }

        private void setPlan1Status()
        {
            By byPlan1Status = By.XPath("//select[@id='ddlPlanStatuses']");
            IWebElement mnuPlan1Status = CommonFunctions.getElement(byPlan1Status);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlan1Status, plan1Status);
            CommonFunctions.AddTestStep($"Verify a user can select {plan1Status} from Plan 1 Status dropdown", $"The {plan1Status} is selected correctly");
        }

        private void setPlan1Name()
        {
            By byPlan1Name = By.XPath("//select[@id='ddlPlans']");
            IWebElement mnuPlan1Name = CommonFunctions.getElement(byPlan1Name);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlan1Name, plan1Name);
            CommonFunctions.AddTestStep($"Verify a user can select {plan1Name} from Plan 1 name dropdown", $"The {plan1Name} is selected correctly");
        }

        private void setPlan1Dept()
        {
            By byPlan1Dept = By.XPath("//select[@id='ddlDepartment']");
            IWebElement mnuPlan1Dept = CommonFunctions.getElement(byPlan1Dept);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlan1Dept, plan1Dept);
            CommonFunctions.AddTestStep($"Verify a user can select {plan1Dept} from Plan 1 Dept dropdown", $"The {plan1Dept} is selected correctly");
        }

        private void setPlan2Year()
        {
            By byPlan2Year = By.XPath("//select[@id='ddlYearsCompareTo']");
            IWebElement mnuPlan2Year = CommonFunctions.getElement(byPlan2Year);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlan2Year, plan2Year);
            CommonFunctions.AddTestStep($"Verify a user can select {plan2Year} from Plan 2 year dropdown", $"The {plan2Year} is selected correctly");
        }

        private void setPlan2Status()
        {
            By byPlan2Status = By.XPath("//select[@id='ddlPlanStatusesCompareTo']");
            IWebElement mnuPlan2Status = CommonFunctions.getElement(byPlan2Status);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlan2Status, plan2Status);
            CommonFunctions.AddTestStep($"Verify a user can select {plan2Status} from Plan 2 Status dropdown", $"The {plan2Status} is selected correctly");
        }

        private void setPlan2Name()
        {
            By byPlan2Name = By.XPath("//select[@id='ddlPlansCompareTo']");
            IWebElement mnuPlan2Name = CommonFunctions.getElement(byPlan2Name);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlan2Name, plan2Name);
            CommonFunctions.AddTestStep($"Verify a user can select {plan2Name} from Plan 2 name dropdown", $"The {plan2Name} is selected correctly");
        }

        private void setPlan2Dept()
        {
            By byPlan2Dept = By.XPath("//select[@id='ddlDepartmentCompareTo']");
            IWebElement mnuPlan2Dept = CommonFunctions.getElement(byPlan2Dept);
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlan2Dept, plan2Dept);
            CommonFunctions.AddTestStep($"Verify a user can select {plan2Dept} from Plan 2 Dept dropdown", $"The {plan2Dept} is selected correctly");
        }

        private void clickExcelFormat()
        {
            By byExcelFormat = By.XPath("//img[@title='Excel Format']");
            IWebElement cmdExcelFormat = CommonFunctions.getElement(byExcelFormat);
            CommonFunctions.ClickByJE(cmdExcelFormat);
            CommonFunctions.AddTestStep($"Verify a user can click the Excel Format button", $"The Excel Format button is enabled and clickable");
        }

        public void SelectExcelFormat()
        {
            setPlan1Year();
            setPlan1Status();
            setPlan1Name();
            setPlan1Dept();
            setPlan2Year();
            setPlan2Status();
            setPlan2Name();
            setPlan2Dept();
            clickExcelFormat();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the Excel button", "Verify the Excel report is downloaded");
        }
    }
    #endregion

}
