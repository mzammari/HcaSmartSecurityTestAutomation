﻿using System;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Container for both Plan 1 and Plan 2 data from Monthly Facility Total Comparison
    /// </summary>
    public class MonthlyFacilityTotalComparison
    {
        public PlanData Plan1 { get; set; }
        public PlanData Plan2 { get; set; }

        public MonthlyFacilityTotalComparison()
        {
            Plan1 = new PlanData();
            Plan2 = new PlanData();
        }
    }

    /// <summary>
        /// Represents data for a single plan (P1 or P2)
        /// Contains 12 months of data with monthly properties
        /// </summary>
    public class PlanData
    {
        // Identifiers
        public int IndexId { get; set; }
        public long WftPlan_ID { get; set; }
        public int Year { get; set; }
        public int CoId { get; set; }
        public string FacilityDescription { get; set; }

        // FTE Metrics (monthly values)
        public PlanEmployedProductiveFtes EmployedProductiveFtes { get; set; }
        public PlanContractPercent ContractPercent { get; set; }
        public PlanContractFTEs ContractFTEs { get; set; }
        public PlanTotalProductiveFtes TotalProductiveFtes { get; set; }
        public PlanNonProductivePercent NonProductivePercent { get; set; }
        public PlanNonProductiveFtes NonProductiveFtes { get; set; }
        public PlanEmployedPaidFtes EmployedPaidFtes { get; set; }
        public PlanTotalFtes TotalFtes { get; set; }

        // Labor Expense Metrics (monthly values)
        public PlanTotalSalariesAndWages TotalSalariesAndWages { get; set; }
        public PlanTotalContractLaborDollars TotalContractLaborDollars { get; set; }
        public PlanTotalLaborExpense TotalLaborExpense { get; set; }
        public PlanEmployedLaborRate EmployedLaborRate { get; set; }
        public PlanContractLaborRate ContractLaborRate { get; set; }
        public PlanOverTimePremiumDollars OverTimePremiumDollars { get; set; }
        public PlanOtPercent OtPercent { get; set; }
        public PlanOTFTEs OTFTEs { get; set; }

        // Volume/Statistics Metrics (monthly values)
        public PlanEeob Eeob { get; set; }
        public PlanMhAa MhAa { get; set; }
        public PlanAdmissions Admissions { get; set; }
        public PlanAAdmissions AAdmissions { get; set; }
        public PlanPatientDays PatientDays { get; set; }
        public PlanAPatientDays APatientDays { get; set; }
        public PlanERVisits ERVisits { get; set; }
        public PlanOutpatient Outpatient { get; set; }
        public PlanDeptUOS DeptUOS { get; set; }
        public PlanSemiVariableProductiveFtes SemiVariableProductiveFtes { get; set; }
        public PlanTotalProdHrsUOS TotalProdHrsUOS { get; set; }
        public PlanVariableProdHrsUOS VariableProdHrsUOS { get; set; }
        public PlanProductiveMinFtes ProductiveMinFtes { get; set; }
        public PlanDaysInMonth DaysInMonth { get; set; }

        // Max (Budget) Values
        public PlanMaxEmployedProductiveFtes Max_EmployedProductiveFtes { get; set; }
        public PlanMaxContractLaborPercent Max_ContractLaborPercent { get; set; }
        public PlanMaxContractFtes Max_ContractFtes { get; set; }
        public PlanMaxTotalProductiveFtes Max_TotalProductiveFtes { get; set; }
        public PlanMaxNonProductivePercent Max_NonProductivePercent { get; set; }
        public PlanMaxNonProductiveFtes Max_NonProductiveFtes { get; set; }
        public PlanMaxEmployedPaidFtes Max_EmployedPaidFtes { get; set; }
        public PlanMaxTotalFtes Max_TotalFtes { get; set; }
        public PlanMaxTotalSalariesAndWages Max_TotalSalariesAndWages { get; set; }
        public PlanMaxTotalContractLaborDollars Max_TotalContractLaborDollars { get; set; }
        public PlanMaxTotalLaborExpense Max_TotalLaborExpense { get; set; }
        public PlanMaxEmployedLaborRate Max_EmployedLaborRate { get; set; }
        public PlanMaxContractLaborRate Max_ContractLaborRate { get; set; }
        public PlanMaxOverTimePremiumDollars Max_OverTimePremiumDollars { get; set; }
        public PlanMaxOtPercent Max_OtPercent { get; set; }
        public PlanMaxOtFte Max_OtFte { get; set; }
        public PlanMaxEeob Max_Eeob { get; set; }
        public PlanMaxMhAa Max_MhAa { get; set; }
        public PlanMaxSemiVariableFtes Max_SemiVariableFtes { get; set; }
        public PlanMaxVariableProdHrsPerUOS Max_VariableProdHrsPerUOS { get; set; }
        public PlanMaxTotalProdHrsPerUOS Max_TotalProdHrsPerUOS { get; set; }
        public PlanMaxMinFTE Max_MinFTE { get; set; }
        public PlanMaxAdmissions Max_Admissions { get; set; }
        public PlanMaxAAdmissions Max_AAdmissions { get; set; }
        public PlanMaxPatientDays Max_PatientDays { get; set; }
        public PlanMaxAPatientDays Max_APatientDays { get; set; }
        public PlanMaxERVisits Max_ERVisits { get; set; }
        public PlanMaxOutpatient Max_Outpatient { get; set; }

        // Min Values
        public PlanMinEmployedProductiveFtes Min_EmployedProductiveFtes { get; set; }
        public PlanMinContractLaborPercent Min_ContractLaborPercent { get; set; }
        public PlanMinContractFtes Min_ContractFtes { get; set; }
        public PlanMinTotalProductiveFtes Min_TotalProductiveFtes { get; set; }
        public PlanMinNonProductivePercent Min_NonProductivePercent { get; set; }
        public PlanMinNonProductiveFtes Min_NonProductiveFtes { get; set; }
        public PlanMinEmployedPaidFtes Min_EmployedPaidFtes { get; set; }
        public PlanMinTotalFtes Min_TotalFtes { get; set; }
        public PlanMinTotalSalariesAndWages Min_TotalSalariesAndWages { get; set; }
        public PlanMinTotalContractLaborDollars Min_TotalContractLaborDollars { get; set; }
        public PlanMinTotalLaborExpense Min_TotalLaborExpense { get; set; }
        public PlanMinEmployedLaborRate Min_EmployedLaborRate { get; set; }
        public PlanMinContractLaborRate Min_ContractLaborRate { get; set; }
        public PlanMinOverTimePremiumDollars Min_OverTimePremiumDollars { get; set; }
        public PlanMinOtPercent Min_OtPercent { get; set; }
        public PlanMinOtFte Min_OtFte { get; set; }
        public PlanMinAdmissions Min_Admissions { get; set; }
        public PlanMinAAdmissions Min_AAdmissions { get; set; }
        public PlanMinPatientDays Min_PatientDays { get; set; }
        public PlanMinAPatientDays Min_APatientDays { get; set; }
        public PlanMinERVisits Min_ERVisits { get; set; }
        public PlanMinOutpatient Min_Outpatient { get; set; }
        public PlanMinEeob Min_Eeob { get; set; }
        public PlanMinMhAa Min_MhAa { get; set; }
        public PlanMinSemiVariableFtes Min_SemiVariableFtes { get; set; }
        public PlanMinVariableProdHrsPerUOS Min_VariableProdHrsPerUOS { get; set; }
        public PlanMinTotalProdHrsPerUOS Min_TotalProdHrsPerUOS { get; set; }
        public PlanMinMinFTE Min_MinFTE { get; set; }

        public PlanData()
        {
            // Initialize all monthly data objects
            EmployedProductiveFtes = new PlanEmployedProductiveFtes();
            ContractPercent = new PlanContractPercent();
            ContractFTEs = new PlanContractFTEs();
            TotalProductiveFtes = new PlanTotalProductiveFtes();
            NonProductivePercent = new PlanNonProductivePercent();
            NonProductiveFtes = new PlanNonProductiveFtes();
            EmployedPaidFtes = new PlanEmployedPaidFtes();
            TotalFtes = new PlanTotalFtes();

            TotalSalariesAndWages = new PlanTotalSalariesAndWages();
            TotalContractLaborDollars = new PlanTotalContractLaborDollars();
            TotalLaborExpense = new PlanTotalLaborExpense();
            EmployedLaborRate = new PlanEmployedLaborRate();
            ContractLaborRate = new PlanContractLaborRate();
            OverTimePremiumDollars = new PlanOverTimePremiumDollars();
            OtPercent = new PlanOtPercent();
            OTFTEs = new PlanOTFTEs();

            Eeob = new PlanEeob();
            MhAa = new PlanMhAa();
            Admissions = new PlanAdmissions();
            AAdmissions = new PlanAAdmissions();
            PatientDays = new PlanPatientDays();
            APatientDays = new PlanAPatientDays();
            ERVisits = new PlanERVisits();
            Outpatient = new PlanOutpatient();
            DeptUOS = new PlanDeptUOS();
            SemiVariableProductiveFtes = new PlanSemiVariableProductiveFtes();
            TotalProdHrsUOS = new PlanTotalProdHrsUOS();
            VariableProdHrsUOS = new PlanVariableProdHrsUOS();
            ProductiveMinFtes = new PlanProductiveMinFtes();
            DaysInMonth = new PlanDaysInMonth();

            // Max values
            Max_EmployedProductiveFtes = new PlanMaxEmployedProductiveFtes();
            Max_ContractLaborPercent = new PlanMaxContractLaborPercent();
            Max_ContractFtes = new PlanMaxContractFtes();
            Max_TotalProductiveFtes = new PlanMaxTotalProductiveFtes();
            Max_NonProductivePercent = new PlanMaxNonProductivePercent();
            Max_NonProductiveFtes = new PlanMaxNonProductiveFtes();
            Max_EmployedPaidFtes = new PlanMaxEmployedPaidFtes();
            Max_TotalFtes = new PlanMaxTotalFtes();
            Max_TotalSalariesAndWages = new PlanMaxTotalSalariesAndWages();
            Max_TotalContractLaborDollars = new PlanMaxTotalContractLaborDollars();
            Max_TotalLaborExpense = new PlanMaxTotalLaborExpense();
            Max_EmployedLaborRate = new PlanMaxEmployedLaborRate();
            Max_ContractLaborRate = new PlanMaxContractLaborRate();
            Max_OverTimePremiumDollars = new PlanMaxOverTimePremiumDollars();
            Max_OtPercent = new PlanMaxOtPercent();
            Max_OtFte = new PlanMaxOtFte();
            Max_Eeob = new PlanMaxEeob();
            Max_MhAa = new PlanMaxMhAa();
            Max_SemiVariableFtes = new PlanMaxSemiVariableFtes();
            Max_VariableProdHrsPerUOS = new PlanMaxVariableProdHrsPerUOS();
            Max_TotalProdHrsPerUOS = new PlanMaxTotalProdHrsPerUOS();
            Max_MinFTE = new PlanMaxMinFTE();
            Max_Admissions = new PlanMaxAdmissions();
            Max_AAdmissions = new PlanMaxAAdmissions();
            Max_PatientDays = new PlanMaxPatientDays();
            Max_APatientDays = new PlanMaxAPatientDays();
            Max_ERVisits = new PlanMaxERVisits();
            Max_Outpatient = new PlanMaxOutpatient();

            // Min values
            Min_EmployedProductiveFtes = new PlanMinEmployedProductiveFtes();
            Min_ContractLaborPercent = new PlanMinContractLaborPercent();
            Min_ContractFtes = new PlanMinContractFtes();
            Min_TotalProductiveFtes = new PlanMinTotalProductiveFtes();
            Min_NonProductivePercent = new PlanMinNonProductivePercent();
            Min_NonProductiveFtes = new PlanMinNonProductiveFtes();
            Min_EmployedPaidFtes = new PlanMinEmployedPaidFtes();
            Min_TotalFtes = new PlanMinTotalFtes();
            Min_TotalSalariesAndWages = new PlanMinTotalSalariesAndWages();
            Min_TotalContractLaborDollars = new PlanMinTotalContractLaborDollars();
            Min_TotalLaborExpense = new PlanMinTotalLaborExpense();
            Min_EmployedLaborRate = new PlanMinEmployedLaborRate();
            Min_ContractLaborRate = new PlanMinContractLaborRate();
            Min_OverTimePremiumDollars = new PlanMinOverTimePremiumDollars();
            Min_OtPercent = new PlanMinOtPercent();
            Min_OtFte = new PlanMinOtFte();
            Min_Admissions = new PlanMinAdmissions();
            Min_AAdmissions = new PlanMinAAdmissions();
            Min_PatientDays = new PlanMinPatientDays();
            Min_APatientDays = new PlanMinAPatientDays();
            Min_ERVisits = new PlanMinERVisits();
            Min_Outpatient = new PlanMinOutpatient();
            Min_Eeob = new PlanMinEeob();
            Min_MhAa = new PlanMinMhAa();
            Min_SemiVariableFtes = new PlanMinSemiVariableFtes();
            Min_VariableProdHrsPerUOS = new PlanMinVariableProdHrsPerUOS();
            Min_TotalProdHrsPerUOS = new PlanMinTotalProdHrsPerUOS();
            Min_MinFTE = new PlanMinMinFTE();
        }
    }

    // ===== FTE Metric Classes =====
    public class PlanEmployedProductiveFtes : MonthlyData { }
    public class PlanContractPercent : MonthlyData { }
    public class PlanContractFTEs : MonthlyData { }
    public class PlanTotalProductiveFtes : MonthlyData { }
    public class PlanNonProductivePercent : MonthlyData { }
    public class PlanNonProductiveFtes : MonthlyData { }
    public class PlanEmployedPaidFtes : MonthlyData { }
    public class PlanTotalFtes : MonthlyData { }

    // ===== Labor Expense Metric Classes =====
    public class PlanTotalSalariesAndWages : MonthlyData { }
    public class PlanTotalContractLaborDollars : MonthlyData { }
    public class PlanTotalLaborExpense : MonthlyData { }
    public class PlanEmployedLaborRate : MonthlyData { }
    public class PlanContractLaborRate : MonthlyData { }
    public class PlanOverTimePremiumDollars : MonthlyData { }
    public class PlanOtPercent : MonthlyData { }
    public class PlanOTFTEs : MonthlyData { }

    // ===== Volume/Statistics Metric Classes =====
    public class PlanEeob : MonthlyData { }
    public class PlanMhAa : MonthlyData { }
    public class PlanAdmissions : MonthlyData { }
    public class PlanAAdmissions : MonthlyData { }
    public class PlanPatientDays : MonthlyData { }
    public class PlanAPatientDays : MonthlyData { }
    public class PlanERVisits : MonthlyData { }
    public class PlanOutpatient : MonthlyData { }
    public class PlanDeptUOS : MonthlyData { }
    public class PlanSemiVariableProductiveFtes : MonthlyData { }
    public class PlanTotalProdHrsUOS : MonthlyData { }
    public class PlanVariableProdHrsUOS : MonthlyData { }
    public class PlanProductiveMinFtes : MonthlyData { }
    public class PlanDaysInMonth : MonthlyData { }

    // ===== Max (Budget) Classes =====
    public class PlanMaxEmployedProductiveFtes : MonthlyData { }
    public class PlanMaxContractLaborPercent : MonthlyData { }
    public class PlanMaxContractFtes : MonthlyData { }
    public class PlanMaxTotalProductiveFtes : MonthlyData { }
    public class PlanMaxNonProductivePercent : MonthlyData { }
    public class PlanMaxNonProductiveFtes : MonthlyData { }
    public class PlanMaxEmployedPaidFtes : MonthlyData { }
    public class PlanMaxTotalFtes : MonthlyData { }
    public class PlanMaxTotalSalariesAndWages : MonthlyData { }
    public class PlanMaxTotalContractLaborDollars : MonthlyData { }
    public class PlanMaxTotalLaborExpense : MonthlyData { }
    public class PlanMaxEmployedLaborRate : MonthlyData { }
    public class PlanMaxContractLaborRate : MonthlyData { }
    public class PlanMaxOverTimePremiumDollars : MonthlyData { }
    public class PlanMaxOtPercent : MonthlyData { }
    public class PlanMaxOtFte : MonthlyData { }
    public class PlanMaxEeob : MonthlyData { }
    public class PlanMaxMhAa : MonthlyData { }
    public class PlanMaxSemiVariableFtes : MonthlyData { }
    public class PlanMaxVariableProdHrsPerUOS : MonthlyData { }
    public class PlanMaxTotalProdHrsPerUOS : MonthlyData { }
    public class PlanMaxMinFTE : MonthlyData { }
    public class PlanMaxAdmissions : MonthlyData { }
    public class PlanMaxAAdmissions : MonthlyData { }
    public class PlanMaxPatientDays : MonthlyData { }
    public class PlanMaxAPatientDays : MonthlyData { }
    public class PlanMaxERVisits : MonthlyData { }
    public class PlanMaxOutpatient : MonthlyData { }

    // ===== Min Classes =====
    public class PlanMinEmployedProductiveFtes : MonthlyData { }
    public class PlanMinContractLaborPercent : MonthlyData { }
    public class PlanMinContractFtes : MonthlyData { }
    public class PlanMinTotalProductiveFtes : MonthlyData { }
    public class PlanMinNonProductivePercent : MonthlyData { }
    public class PlanMinNonProductiveFtes : MonthlyData { }
    public class PlanMinEmployedPaidFtes : MonthlyData { }
    public class PlanMinTotalFtes : MonthlyData { }
    public class PlanMinTotalSalariesAndWages : MonthlyData { }
    public class PlanMinTotalContractLaborDollars : MonthlyData { }
    public class PlanMinTotalLaborExpense : MonthlyData { }
    public class PlanMinEmployedLaborRate : MonthlyData { }
    public class PlanMinContractLaborRate : MonthlyData { }
    public class PlanMinOverTimePremiumDollars : MonthlyData { }
    public class PlanMinOtPercent : MonthlyData { }
    public class PlanMinOtFte : MonthlyData { }
    public class PlanMinAdmissions : MonthlyData { }
    public class PlanMinAAdmissions : MonthlyData { }
    public class PlanMinPatientDays : MonthlyData { }
    public class PlanMinAPatientDays : MonthlyData { }
    public class PlanMinERVisits : MonthlyData { }
    public class PlanMinOutpatient : MonthlyData { }
    public class PlanMinEeob : MonthlyData { }
    public class PlanMinMhAa : MonthlyData { }
    public class PlanMinSemiVariableFtes : MonthlyData { }
    public class PlanMinVariableProdHrsPerUOS : MonthlyData { }
    public class PlanMinTotalProdHrsPerUOS : MonthlyData { }
    public class PlanMinMinFTE : MonthlyData { }
}