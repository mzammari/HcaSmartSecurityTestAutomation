﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using ExcelDataReader;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Parses the Excel Data sheet from Monthly Facility Total Comparison Excel file
    /// This sheet has a report format with P1/P2 metrics in rows and months in columns
    /// </summary>
    public class MonthlyFacilityTotalExcelParser
    {
        /// <summary>
        /// Parse Excel Data sheet and return both Plan 1 and Plan 2
        /// </summary>
        /// <param name="filePath">Path to Excel file</param>
        /// <returns>MonthlyFacilityTotalComparison with both plans</returns>
        public static MonthlyFacilityTotalComparison ParseExcelData(string filePath)
        {
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = false  // Raw read, no headers
                        }
                    });

                    // Get first sheet (Excel Data) - index 0
                    var excelDataTable = result.Tables[0];

                    return ParseExcelDataTable(excelDataTable);
                }
            }
        }

        private static MonthlyFacilityTotalComparison ParseExcelDataTable(DataTable table)
        {
            var comparison = new MonthlyFacilityTotalComparison();
            comparison.Plan1 = new PlanData();
            comparison.Plan2 = new PlanData();

            // Section 1: FTE Summary (Rows 14-29) - Metric in Col C, Months start at Col F
            var fteSectionColumns = new Dictionary<string, int>
      {
        {"Metric", 2},  // Column C
                {"Jan", 5}, {"Feb", 8}, {"Mar", 10}, {"Apr", 14},
        {"May", 16}, {"Jun", 18}, {"Jul", 20}, {"Aug", 22},
        {"Sep", 24}, {"Oct", 26}, {"Nov", 28}, {"Dec", 30}, {"Total", 35}
      };
            ParseSection(table, 13, 28, fteSectionColumns, comparison);  // Rows 14-29 (0-based: 13-28)

            // Section 2: Labor Expense (Rows 34-49) - Metric in Col B, Months start at Col E
            var laborSectionColumns = new Dictionary<string, int>
      {
        {"Metric", 1},  // Column B
                {"Jan", 4}, {"Feb", 7}, {"Mar", 9}, {"Apr", 13},
        {"May", 15}, {"Jun", 17}, {"Jul", 19}, {"Aug", 21},
        {"Sep", 23}, {"Oct", 25}, {"Nov", 27}, {"Dec", 29}, {"Total", 34}
      };
            ParseSection(table, 33, 48, laborSectionColumns, comparison);  // Rows 34-49 (0-based: 33-48)

            // Section 3: Volume Summary (Rows 53-76) - Metric in Col B, Months start at Col E
            var volumeSectionColumns = new Dictionary<string, int>
      {
        {"Metric", 1},  // Column B
                {"Jan", 4}, {"Feb", 7}, {"Mar", 9}, {"Apr", 13},
        {"May", 15}, {"Jun", 17}, {"Jul", 19}, {"Aug", 21},
        {"Sep", 23}, {"Oct", 25}, {"Nov", 27}, {"Dec", 29}, {"Total", 34}
      };
            ParseSection(table, 52, 75, volumeSectionColumns, comparison);  // Rows 53-76 (0-based: 52-75)

            return comparison;
        }

        private static void ParseSection(
          DataTable table,
          int startRow,
          int endRow,
          Dictionary<string, int> columnMap,
          MonthlyFacilityTotalComparison comparison)
        {
            int metricCol = columnMap["Metric"];

            for (int rowIndex = startRow; rowIndex <= endRow && rowIndex < table.Rows.Count; rowIndex++)
            {
                var row = table.Rows[rowIndex];
                var metricName = GetString(row, metricCol);

                if (string.IsNullOrEmpty(metricName)) continue;

                // Read monthly values for this metric
                var monthlyValues = new Dictionary<string, double>();
                foreach (var month in new[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Total" })
                {
                    if (columnMap.ContainsKey(month))
                    {
                        monthlyValues[month] = GetDouble(row, columnMap[month]);
                    }
                }

                // Assign to appropriate plan and metric
                AssignMetricToPlan(comparison, metricName, monthlyValues);
            }
        }

        private static void AssignMetricToPlan(
          MonthlyFacilityTotalComparison comparison,
          string metricName,
          Dictionary<string, double> values)
        {
            bool isPlan1 = metricName.StartsWith("P1 - ");
            bool isPlan2 = metricName.StartsWith("P2 - ");

            if (!isPlan1 && !isPlan2) return;

            var plan = isPlan1 ? comparison.Plan1 : comparison.Plan2;

            // Remove "P1 - " or "P2 - " prefix
            var cleanName = metricName.Substring(5);

            // Map to appropriate property
            SetMetricValues(plan, cleanName, values);
        }

        private static void SetMetricValues(PlanData plan, string metricName, Dictionary<string, double> values)
        {
            // Check if this is a percentage metric
            bool isPercentage = metricName.Contains("%");

            // Smart percentage handling: if it's a percentage metric AND the value appears to be 
            // stored as a decimal (< 1), multiply by 100 to get the actual percentage value
            if (isPercentage)
            {
                var convertedValues = new Dictionary<string, double>();
                foreach (var kvp in values)
                {
                    // If the value is less than 1, it's stored as decimal (0.08), multiply by 100
                    // If the value is >= 1, it's already the raw percentage (8.05), keep as-is
                    if (kvp.Value < 1.0 && kvp.Value > 0.0)
                    {
                        convertedValues[kvp.Key] = kvp.Value * 100.0;
                    }
                    else
                    {
                        convertedValues[kvp.Key] = kvp.Value;
                    }
                }
                values = convertedValues;
            }

            // FTE Summary metrics
            if (metricName == "Employed (Productive) FTEs")
                SetMonthlyData(plan.EmployedProductiveFtes, values);
            else if (metricName == "Contract Labor %")
                SetMonthlyData(plan.ContractPercent, values);
            else if (metricName == "Contract FTEs")
                SetMonthlyData(plan.ContractFTEs, values);
            else if (metricName == "Total Productive FTEs")
                SetMonthlyData(plan.TotalProductiveFtes, values);
            else if (metricName == "Non-Productive %")
                SetMonthlyData(plan.NonProductivePercent, values);
            else if (metricName == "Non-Productive FTEs")
                SetMonthlyData(plan.NonProductiveFtes, values);
            else if (metricName == "Employed (paid) FTEs")
                SetMonthlyData(plan.EmployedPaidFtes, values);
            else if (metricName == "Total FTEs (Paid + Contract)")
                SetMonthlyData(plan.TotalFtes, values);

            // Labor Expense metrics
            else if (metricName == "Total Salaries & Wages ($000)")
                SetMonthlyData(plan.TotalSalariesAndWages, values);
            else if (metricName == "Total Contract Labor  ($000)")  // Note: two spaces
                SetMonthlyData(plan.TotalContractLaborDollars, values);
            else if (metricName == "Total Labor Expense  ($000)")  // Note: two spaces
                SetMonthlyData(plan.TotalLaborExpense, values);
            else if (metricName == "Employed Labor Rate")
                SetMonthlyData(plan.EmployedLaborRate, values);
            else if (metricName == "Contract Labor Rate")
                SetMonthlyData(plan.ContractLaborRate, values);
            else if (metricName == "Overtime Premium Dollars")
                SetMonthlyData(plan.OverTimePremiumDollars, values);
            else if (metricName == "Overtime %")
                SetMonthlyData(plan.OtPercent, values);
            else if (metricName == "Overtime FTEs")
                SetMonthlyData(plan.OTFTEs, values);

            // Volume Summary metrics
            else if (metricName == "Admissions")
                SetMonthlyData(plan.Admissions, values);
            else if (metricName == "Patient Days")
                SetMonthlyData(plan.PatientDays, values);
            else if (metricName == "APD")
                SetMonthlyData(plan.APatientDays, values);
            else if (metricName == "ER Visits")
                SetMonthlyData(plan.ERVisits, values);
            else if (metricName == "OutPatient Visits")
                SetMonthlyData(plan.Outpatient, values);
            else if (metricName == "EEEOB")
                SetMonthlyData(plan.Eeob, values);
            else if (metricName == "MH/AA")
                SetMonthlyData(plan.MhAa, values);
            else if (metricName == "Semi-Variable FTEs")
                SetMonthlyData(plan.SemiVariableProductiveFtes, values);
            else if (metricName == "Variable Productive Hrs/UOS")
                SetMonthlyData(plan.VariableProdHrsUOS, values);
            else if (metricName == "Min FTE")
                SetMonthlyData(plan.ProductiveMinFtes, values);
            else if (metricName == "Total Productive Hrs/UOS")
                SetMonthlyData(plan.TotalProdHrsUOS, values);
        }

        private static void SetMonthlyData(MonthlyData monthlyData, Dictionary<string, double> values)
        {
            // Round all values to 2 decimal places when assigning
            if (values.ContainsKey("Jan")) monthlyData.Jan = Math.Round(values["Jan"], 2);
            if (values.ContainsKey("Feb")) monthlyData.Feb = Math.Round(values["Feb"], 2);
            if (values.ContainsKey("Mar")) monthlyData.Mar = Math.Round(values["Mar"], 2);
            if (values.ContainsKey("Apr")) monthlyData.Apr = Math.Round(values["Apr"], 2);
            if (values.ContainsKey("May")) monthlyData.May = Math.Round(values["May"], 2);
            if (values.ContainsKey("Jun")) monthlyData.Jun = Math.Round(values["Jun"], 2);
            if (values.ContainsKey("Jul")) monthlyData.Jul = Math.Round(values["Jul"], 2);
            if (values.ContainsKey("Aug")) monthlyData.Aug = Math.Round(values["Aug"], 2);
            if (values.ContainsKey("Sep")) monthlyData.Sep = Math.Round(values["Sep"], 2);
            if (values.ContainsKey("Oct")) monthlyData.Oct = Math.Round(values["Oct"], 2);
            if (values.ContainsKey("Nov")) monthlyData.Nov = Math.Round(values["Nov"], 2);
            if (values.ContainsKey("Dec")) monthlyData.Dec = Math.Round(values["Dec"], 2);
            if (values.ContainsKey("Total")) monthlyData.Total = Math.Round(values["Total"], 2);
        }

        private static double GetDouble(DataRow row, int columnIndex)
        {
            if (columnIndex >= row.Table.Columns.Count) return 0.0;

            var value = row[columnIndex];
            if (value == null || value == DBNull.Value) return 0.0;

            try
            {
                double result = Convert.ToDouble(value);
                return result; // Return as-is, no rounding
            }
            catch
            {
                return 0.0;
            }
        }

        private static string GetString(DataRow row, int columnIndex)
        {
            if (columnIndex >= row.Table.Columns.Count) return string.Empty;

            var value = row[columnIndex];
            if (value == null || value == DBNull.Value) return string.Empty;

            return value.ToString().Trim();
        }
    }
}