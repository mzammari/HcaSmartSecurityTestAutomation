﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Queries SQL database for Monthly Department Detail Comparison data
    /// Returns both Plan 1 and Plan 2 with 12 months each (24 rows total)
    /// </summary>
    public static class MonthlyDepartmentDetailSqlLoader
    {
        /// <summary>
        /// Load both Plan 1 and Plan 2 data from SQL database
        /// </summary>
        /// <param name="connectionString">Database connection string</param>
        /// <param name="sqlQuery">SQL query that returns 24 rows (12 per plan)</param>
        /// <returns>MonthlyDepartmentDetailComparison with both plans</returns>
        public static MonthlyDepartmentDetailComparison LoadFromSql()
        {
            string DB = RunData.DatabaseName;
            string sServerName = RunData.ServerName;
            string _connectionString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";

            var sqlQuery = MonthlyDepartmentDetailComparisonSP.GetMonthlyDepartmentDetailComparisonQuery();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                using (var command = new SqlCommand(sqlQuery, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        return ParseFromSqlReader(reader);
                    }
                }
            }
        }

        
        private static MonthlyDepartmentDetailComparison ParseFromSqlReader(SqlDataReader reader)
        {
            var comparison = new MonthlyDepartmentDetailComparison();

            // Read all 24 rows (12 for each plan)
            var allRows = new List<SqlMonthlyRow>();

            while (reader.Read())
            {
                allRows.Add(ReadSingleRow(reader));
            }

            // Separate by IndexId
            var plan1Rows = allRows.Where(r => r.IndexId == 1).ToList();
            var plan2Rows = allRows.Where(r => r.IndexId == 2).ToList();

            // Parse each plan
            if (plan1Rows.Count > 0)
            {
                comparison.Plan1 = PivotToDepartmentPlanData(plan1Rows);
            }

            if (plan2Rows.Count > 0)
            {
                comparison.Plan2 = PivotToDepartmentPlanData(plan2Rows);
            }

            return comparison;
        }

        // Helper class to hold a single row's data
        private class SqlMonthlyRow
        {
            // Identifiers
            public int IndexId { get; set; }
            public long PlanId { get; set; }
            public long WftDepartment_ID { get; set; }
            public int DepartmentNumber { get; set; }
            public int Year { get; set; }
            public int MonthNum { get; set; }
            public string MonthName { get; set; }

            // Department Details
            public string DeptType { get; set; }
            public int DeptNumber { get; set; }
            public string DeptName { get; set; }
            public string FacilityDesc { get; set; }
            public string StatDescription { get; set; }
            public string DeptTypeCompareTo { get; set; }
            public int DeptNumberCompareTo { get; set; }
            public string DeptNameCompareTo { get; set; }
            public string FacilityDescCompareTo { get; set; }
            public string StatDescriptionCompareTo { get; set; }

            // FTE Metrics
            public double EmployedProductiveFtes { get; set; }
            public double ContractLaborPercent { get; set; }
            public double ContractFtes { get; set; }
            public double TotalProductiveFtes { get; set; }
            public double NonProductivePercent { get; set; }
            public double NonProductiveFtes { get; set; }
            public double EmployedPaidFtes { get; set; }
            public double TotalFtes { get; set; }

            // Labor Expense Metrics
            public double TotalSalariesAndWages { get; set; }
            public double TotalContractLaborDollars { get; set; }
            public double TotalLaborExpense { get; set; }
            public double EmployedLaborRate { get; set; }
            public double ContactLaborRate { get; set; }
            public double OverTimePremiumDollars { get; set; }
            public double OtPercent { get; set; }
            public double OtFte { get; set; }

            // Volume Metrics
            public double DeptUOS { get; set; }
            public double SemiVariableFtes { get; set; }
            public double VariableProdHrsPerUOS { get; set; }
            public double TotalProdHrsPerUOS { get; set; }
            public double TotalPaidHrsPerUOS { get; set; }
            public double MinFTE { get; set; }

            // Total Columns
            public double EmployedProductiveFtesTotal { get; set; }
            public double ContractLaborPercentTotal { get; set; }
            public double ContractFTEsTotal { get; set; }
            public double TotalProductiveFtesTotal { get; set; }
            public double NonProductivePercentTotal { get; set; }
            public double NonProductiveFtesTotal { get; set; }
            public double EmployedPaidFtesTotal { get; set; }
            public double TotalFtesTotal { get; set; }
            public double TotalSalariesAndWagesTotal { get; set; }
            public double TotalContractLaborDollarsTotal { get; set; }
            public double TotalLaborExpenseTotal { get; set; }
            public double EmployedLaborRateTotal { get; set; }
            public double ContractLaborRateTotal { get; set; }
            public double OTPremiumTotal { get; set; }
            public double OtPercentTotal { get; set; }
            public double OtFtesTotal { get; set; }
            public double DeptUOSTotal { get; set; }
            public double SemiVariableProductiveFtesTotal { get; set; }
            public double VariableProdHrsUOSTotal { get; set; }
            public double TotalProdHrsUOSTotal { get; set; }
            public double TotalPaidHrsUOSTotal { get; set; }
            public double TotalMinFTE { get; set; }

            // Max Columns
            public double MaxEmployedProductiveFtes { get; set; }
            public double MaxContractLaborPercent { get; set; }
            public double MaxContractFtes { get; set; }
            public double MaxTotalProductiveFtes { get; set; }
            public double MaxNonProductivePercent { get; set; }
            public double MaxNonProductiveFtes { get; set; }
            public double MaxEmployedPaidFtes { get; set; }
            public double MaxTotalFtes { get; set; }
            public double MaxTotalSalariesAndWages { get; set; }
            public double MaxTotalContractLaborDollars { get; set; }
            public double MaxTotalLaborExpense { get; set; }
            public double MaxEmployedLaborRate { get; set; }
            public double MaxContactLaborRate { get; set; }
            public double MaxOverTimePremiumDollars { get; set; }
            public double MaxOtPercent { get; set; }
            public double MaxOtFte { get; set; }
            public double MaxDeptUOS { get; set; }
            public double MaxSemiVariableFtes { get; set; }
            public double MaxVariableProdHrsPerUOS { get; set; }
            public double MaxTotalProdHrsPerUOS { get; set; }
            public double MaxTotalPaidHrsPerUOS { get; set; }
            public double MaxMinFTE { get; set; }

            // Min Columns
            public double MinEmployedProductiveFtes { get; set; }
            public double MinContractLaborPercent { get; set; }
            public double MinContractFtes { get; set; }
            public double MinTotalProductiveFtes { get; set; }
            public double MinNonProductivePercent { get; set; }
            public double MinNonProductiveFtes { get; set; }
            public double MinEmployedPaidFtes { get; set; }
            public double MinTotalFtes { get; set; }
            public double MinTotalSalariesAndWages { get; set; }
            public double MinTotalContractLaborDollars { get; set; }
            public double MinTotalLaborExpense { get; set; }
            public double MinEmployedLaborRate { get; set; }
            public double MinContactLaborRate { get; set; }
            public double MinOverTimePremiumDollars { get; set; }
            public double MinOtPercent { get; set; }
            public double MinOtFte { get; set; }
            public double MinDeptUOS { get; set; }
            public double MinSemiVariableFtes { get; set; }
            public double MinVariableProdHrsPerUOS { get; set; }
            public double MinTotalProdHrsPerUOS { get; set; }
            public double MinTotalPaidHrsPerUOS { get; set; }
            public double MinMinFTE { get; set; }
        }

        private static SqlMonthlyRow ReadSingleRow(SqlDataReader reader)
        {
            return new SqlMonthlyRow
            {
                // Identifiers
                IndexId = GetInt(reader, "IndexId"),
                PlanId = GetLong(reader, "PlanId"),
                WftDepartment_ID = GetLong(reader, "WftDepartment_ID"),
                DepartmentNumber = GetInt(reader, "DepartmentNumber"),
                Year = GetInt(reader, "Year"),
                MonthNum = GetInt(reader, "MonthNum"),
                MonthName = GetString(reader, "MonthName"),

                // Department Details
                DeptType = GetString(reader, "DeptType"),
                DeptNumber = GetInt(reader, "DeptNumber"),
                DeptName = GetString(reader, "DeptName"),
                FacilityDesc = GetString(reader, "FacilityDesc"),
                StatDescription = GetString(reader, "StatDescription"),
                DeptTypeCompareTo = GetString(reader, "DeptTypeCompareTo"),
                DeptNumberCompareTo = GetInt(reader, "DeptNumberCompareTo"),
                DeptNameCompareTo = GetString(reader, "DeptNameCompareTo"),
                FacilityDescCompareTo = GetString(reader, "FacilityDescCompareTo"),
                StatDescriptionCompareTo = GetString(reader, "StatDescriptionCompareTo"),

                // FTE Metrics
                EmployedProductiveFtes = GetDouble(reader, "EmployedProductiveFtes"),
                ContractLaborPercent = GetDouble(reader, "ContractLaborPercent"),
                ContractFtes = GetDouble(reader, "ContractFtes"),
                TotalProductiveFtes = GetDouble(reader, "TotalProductiveFtes"),
                NonProductivePercent = GetDouble(reader, "NonProductivePercent"),
                NonProductiveFtes = GetDouble(reader, "NonProductiveFtes"),
                EmployedPaidFtes = GetDouble(reader, "EmployedPaidFtes"),
                TotalFtes = GetDouble(reader, "TotalFtes"),

                // Labor Expense Metrics
                TotalSalariesAndWages = GetDouble(reader, "TotalSalariesAndWages"),
                TotalContractLaborDollars = GetDouble(reader, "TotalContractLaborDollars"),
                TotalLaborExpense = GetDouble(reader, "TotalLaborExpense"),
                EmployedLaborRate = GetDouble(reader, "EmployedLaborRate"),
                ContactLaborRate = GetDouble(reader, "ContactLaborRate"),
                OverTimePremiumDollars = GetDouble(reader, "OverTimePremiumDollars"),
                OtPercent = GetDouble(reader, "OtPercent"),
                OtFte = GetDouble(reader, "OtFte"),

                // Volume Metrics
                DeptUOS = GetDouble(reader, "DeptUOS"),
                SemiVariableFtes = GetDouble(reader, "SemiVariableFtes"),
                VariableProdHrsPerUOS = GetDouble(reader, "VariableProdHrsPerUOS"),
                TotalProdHrsPerUOS = GetDouble(reader, "TotalProdHrsPerUOS"),
                TotalPaidHrsPerUOS = GetDouble(reader, "TotalPaidHrsPerUOS"),
                MinFTE = GetDouble(reader, "MinFTE"),

                // Total Columns
                EmployedProductiveFtesTotal = GetDouble(reader, "EmployedProductiveFtesTotal"),
                ContractLaborPercentTotal = GetDouble(reader, "ContractLaborPercentTotal"),
                ContractFTEsTotal = GetDouble(reader, "ContractFTEsTotal"),
                TotalProductiveFtesTotal = GetDouble(reader, "TotalProductiveFtesTotal"),
                NonProductivePercentTotal = GetDouble(reader, "NonProductivePercentTotal"),
                NonProductiveFtesTotal = GetDouble(reader, "NonProductiveFtesTotal"),
                EmployedPaidFtesTotal = GetDouble(reader, "EmployedPaidFtesTotal"),
                TotalFtesTotal = GetDouble(reader, "TotalFtesTotal"),
                TotalSalariesAndWagesTotal = GetDouble(reader, "TotalSalariesAndWagesTotal"),
                TotalContractLaborDollarsTotal = GetDouble(reader, "TotalContractLaborDollarsTotal"),
                TotalLaborExpenseTotal = GetDouble(reader, "TotalLaborExpenseTotal"),
                EmployedLaborRateTotal = GetDouble(reader, "EmployedLaborRateTotal"),
                ContractLaborRateTotal = GetDouble(reader, "ContractLaborRateTotal"),
                OTPremiumTotal = GetDouble(reader, "OTPremiumTotal"),
                OtPercentTotal = GetDouble(reader, "OtPercentTotal"),
                OtFtesTotal = GetDouble(reader, "OtFtesTotal"),
                DeptUOSTotal = GetDouble(reader, "DeptUOSTotal"),
                SemiVariableProductiveFtesTotal = GetDouble(reader, "SemiVariableProductiveFtesTotal"),
                VariableProdHrsUOSTotal = GetDouble(reader, "VariableProdHrsUOSTotal"),
                TotalProdHrsUOSTotal = GetDouble(reader, "TotalProdHrsUOSTotal"),
                TotalPaidHrsUOSTotal = GetDouble(reader, "TotalPaidHrsUOSTotal"),
                TotalMinFTE = GetDouble(reader, "TotalMinFTE"),

                // Max Columns
                MaxEmployedProductiveFtes = GetDouble(reader, "MaxEmployedProductiveFtes"),
                MaxContractLaborPercent = GetDouble(reader, "MaxContractLaborPercent"),
                MaxContractFtes = GetDouble(reader, "MaxContractFtes"),
                MaxTotalProductiveFtes = GetDouble(reader, "MaxTotalProductiveFtes"),
                MaxNonProductivePercent = GetDouble(reader, "MaxNonProductivePercent"),
                MaxNonProductiveFtes = GetDouble(reader, "MaxNonProductiveFtes"),
                MaxEmployedPaidFtes = GetDouble(reader, "MaxEmployedPaidFtes"),
                MaxTotalFtes = GetDouble(reader, "MaxTotalFtes"),
                MaxTotalSalariesAndWages = GetDouble(reader, "MaxTotalSalariesAndWages"),
                MaxTotalContractLaborDollars = GetDouble(reader, "MaxTotalContractLaborDollars"),
                MaxTotalLaborExpense = GetDouble(reader, "MaxTotalLaborExpense"),
                MaxEmployedLaborRate = GetDouble(reader, "MaxEmployedLaborRate"),
                MaxContactLaborRate = GetDouble(reader, "MaxContactLaborRate"),
                MaxOverTimePremiumDollars = GetDouble(reader, "MaxOverTimePremiumDollars"),
                MaxOtPercent = GetDouble(reader, "MaxOtPercent"),
                MaxOtFte = GetDouble(reader, "MaxOtFte"),
                MaxDeptUOS = GetDouble(reader, "MaxDeptUOS"),
                MaxSemiVariableFtes = GetDouble(reader, "MaxSemiVariableFtes"),
                MaxVariableProdHrsPerUOS = GetDouble(reader, "MaxVariableProdHrsPerUOS"),
                MaxTotalProdHrsPerUOS = GetDouble(reader, "MaxTotalProdHrsPerUOS"),
                MaxTotalPaidHrsPerUOS = GetDouble(reader, "MaxTotalPaidHrsPerUOS"),
                MaxMinFTE = GetDouble(reader, "MaxMinFTE"),

                // Min Columns
                MinEmployedProductiveFtes = GetDouble(reader, "MinEmployedProductiveFtes"),
                MinContractLaborPercent = GetDouble(reader, "MinContractLaborPercent"),
                MinContractFtes = GetDouble(reader, "MinContractFtes"),
                MinTotalProductiveFtes = GetDouble(reader, "MinTotalProductiveFtes"),
                MinNonProductivePercent = GetDouble(reader, "MinNonProductivePercent"),
                MinNonProductiveFtes = GetDouble(reader, "MinNonProductiveFtes"),
                MinEmployedPaidFtes = GetDouble(reader, "MinEmployedPaidFtes"),
                MinTotalFtes = GetDouble(reader, "MinTotalFtes"),
                MinTotalSalariesAndWages = GetDouble(reader, "MinTotalSalariesAndWages"),
                MinTotalContractLaborDollars = GetDouble(reader, "MinTotalContractLaborDollars"),
                MinTotalLaborExpense = GetDouble(reader, "MinTotalLaborExpense"),
                MinEmployedLaborRate = GetDouble(reader, "MinEmployedLaborRate"),
                MinContactLaborRate = GetDouble(reader, "MinContactLaborRate"),
                MinOverTimePremiumDollars = GetDouble(reader, "MinOverTimePremiumDollars"),
                MinOtPercent = GetDouble(reader, "MinOtPercent"),
                MinOtFte = GetDouble(reader, "MinOtFte"),
                MinDeptUOS = GetDouble(reader, "MinDeptUOS"),
                MinSemiVariableFtes = GetDouble(reader, "MinSemiVariableFtes"),
                MinVariableProdHrsPerUOS = GetDouble(reader, "MinVariableProdHrsPerUOS"),
                MinTotalProdHrsPerUOS = GetDouble(reader, "MinTotalProdHrsPerUOS"),
                MinTotalPaidHrsPerUOS = GetDouble(reader, "MinTotalPaidHrsPerUOS"),
                MinMinFTE = GetDouble(reader, "MinMinFTE")
            };
        }

        private static DepartmentPlanData PivotToDepartmentPlanData(List<SqlMonthlyRow> rows)
        {
            if (rows.Count == 0) return null;

            var plan = new DepartmentPlanData();
            var firstRow = rows.First();

            // Set identifiers and department details
            plan.IndexId = firstRow.IndexId;
            plan.PlanId = firstRow.PlanId;
            plan.WftDepartment_ID = firstRow.WftDepartment_ID;
            plan.DepartmentNumber = firstRow.DepartmentNumber;
            plan.Year = firstRow.Year;
            plan.DeptType = firstRow.DeptType;
            plan.DeptNumber = firstRow.DeptNumber;
            plan.DeptName = firstRow.DeptName;
            plan.FacilityDesc = firstRow.FacilityDesc;
            plan.StatDescription = firstRow.StatDescription;
            plan.DeptTypeCompareTo = firstRow.DeptTypeCompareTo;
            plan.DeptNumberCompareTo = firstRow.DeptNumberCompareTo;
            plan.DeptNameCompareTo = firstRow.DeptNameCompareTo;
            plan.FacilityDescCompareTo = firstRow.FacilityDescCompareTo;
            plan.StatDescriptionCompareTo = firstRow.StatDescriptionCompareTo;

            // Pivot monthly data for each metric
            foreach (var row in rows)
            {
                // FTE Metrics
                SetMonthValue(plan.EmployedProductiveFtes, row.MonthNum, row.EmployedProductiveFtes);
                SetMonthValue(plan.ContractLaborPercent, row.MonthNum, row.ContractLaborPercent);
                SetMonthValue(plan.ContractFtes, row.MonthNum, row.ContractFtes);
                SetMonthValue(plan.TotalProductiveFtes, row.MonthNum, row.TotalProductiveFtes);
                SetMonthValue(plan.NonProductivePercent, row.MonthNum, row.NonProductivePercent);
                SetMonthValue(plan.NonProductiveFtes, row.MonthNum, row.NonProductiveFtes);
                SetMonthValue(plan.EmployedPaidFtes, row.MonthNum, row.EmployedPaidFtes);
                SetMonthValue(plan.TotalFtes, row.MonthNum, row.TotalFtes);

                // Labor Expense Metrics
                SetMonthValue(plan.TotalSalariesAndWages, row.MonthNum, row.TotalSalariesAndWages);
                SetMonthValue(plan.TotalContractLaborDollars, row.MonthNum, row.TotalContractLaborDollars);
                SetMonthValue(plan.TotalLaborExpense, row.MonthNum, row.TotalLaborExpense);
                SetMonthValue(plan.EmployedLaborRate, row.MonthNum, row.EmployedLaborRate);
                SetMonthValue(plan.ContactLaborRate, row.MonthNum, row.ContactLaborRate);
                SetMonthValue(plan.OverTimePremiumDollars, row.MonthNum, row.OverTimePremiumDollars);
                SetMonthValue(plan.OtPercent, row.MonthNum, row.OtPercent);
                SetMonthValue(plan.OtFte, row.MonthNum, row.OtFte);

                // Volume Metrics
                SetMonthValue(plan.DeptUOS, row.MonthNum, row.DeptUOS);
                SetMonthValue(plan.SemiVariableFtes, row.MonthNum, row.SemiVariableFtes);
                SetMonthValue(plan.VariableProdHrsPerUOS, row.MonthNum, row.VariableProdHrsPerUOS);
                SetMonthValue(plan.TotalProdHrsPerUOS, row.MonthNum, row.TotalProdHrsPerUOS);
                SetMonthValue(plan.TotalPaidHrsPerUOS, row.MonthNum, row.TotalPaidHrsPerUOS);
                SetMonthValue(plan.MinFTE, row.MonthNum, row.MinFTE);

                // Max Values
                SetMonthValue(plan.Max_EmployedProductiveFtes, row.MonthNum, row.MaxEmployedProductiveFtes);
                SetMonthValue(plan.Max_ContractLaborPercent, row.MonthNum, row.MaxContractLaborPercent);
                SetMonthValue(plan.Max_ContractFtes, row.MonthNum, row.MaxContractFtes);
                SetMonthValue(plan.Max_TotalProductiveFtes, row.MonthNum, row.MaxTotalProductiveFtes);
                SetMonthValue(plan.Max_NonProductivePercent, row.MonthNum, row.MaxNonProductivePercent);
                SetMonthValue(plan.Max_NonProductiveFtes, row.MonthNum, row.MaxNonProductiveFtes);
                SetMonthValue(plan.Max_EmployedPaidFtes, row.MonthNum, row.MaxEmployedPaidFtes);
                SetMonthValue(plan.Max_TotalFtes, row.MonthNum, row.MaxTotalFtes);
                SetMonthValue(plan.Max_TotalSalariesAndWages, row.MonthNum, row.MaxTotalSalariesAndWages);
                SetMonthValue(plan.Max_TotalContractLaborDollars, row.MonthNum, row.MaxTotalContractLaborDollars);
                SetMonthValue(plan.Max_TotalLaborExpense, row.MonthNum, row.MaxTotalLaborExpense);
                SetMonthValue(plan.Max_EmployedLaborRate, row.MonthNum, row.MaxEmployedLaborRate);
                SetMonthValue(plan.Max_ContactLaborRate, row.MonthNum, row.MaxContactLaborRate);
                SetMonthValue(plan.Max_OverTimePremiumDollars, row.MonthNum, row.MaxOverTimePremiumDollars);
                SetMonthValue(plan.Max_OtPercent, row.MonthNum, row.MaxOtPercent);
                SetMonthValue(plan.Max_OtFte, row.MonthNum, row.MaxOtFte);
                SetMonthValue(plan.Max_DeptUOS, row.MonthNum, row.MaxDeptUOS);
                SetMonthValue(plan.Max_SemiVariableFtes, row.MonthNum, row.MaxSemiVariableFtes);
                SetMonthValue(plan.Max_VariableProdHrsPerUOS, row.MonthNum, row.MaxVariableProdHrsPerUOS);
                SetMonthValue(plan.Max_TotalProdHrsPerUOS, row.MonthNum, row.MaxTotalProdHrsPerUOS);
                SetMonthValue(plan.Max_TotalPaidHrsPerUOS, row.MonthNum, row.MaxTotalPaidHrsPerUOS);
                SetMonthValue(plan.Max_MinFTE, row.MonthNum, row.MaxMinFTE);

                // Min Values
                SetMonthValue(plan.Min_EmployedProductiveFtes, row.MonthNum, row.MinEmployedProductiveFtes);
                SetMonthValue(plan.Min_ContractLaborPercent, row.MonthNum, row.MinContractLaborPercent);
                SetMonthValue(plan.Min_ContractFtes, row.MonthNum, row.MinContractFtes);
                SetMonthValue(plan.Min_TotalProductiveFtes, row.MonthNum, row.MinTotalProductiveFtes);
                SetMonthValue(plan.Min_NonProductivePercent, row.MonthNum, row.MinNonProductivePercent);
                SetMonthValue(plan.Min_NonProductiveFtes, row.MonthNum, row.MinNonProductiveFtes);
                SetMonthValue(plan.Min_EmployedPaidFtes, row.MonthNum, row.MinEmployedPaidFtes);
                SetMonthValue(plan.Min_TotalFtes, row.MonthNum, row.MinTotalFtes);
                SetMonthValue(plan.Min_TotalSalariesAndWages, row.MonthNum, row.MinTotalSalariesAndWages);
                SetMonthValue(plan.Min_TotalContractLaborDollars, row.MonthNum, row.MinTotalContractLaborDollars);
                SetMonthValue(plan.Min_TotalLaborExpense, row.MonthNum, row.MinTotalLaborExpense);
                SetMonthValue(plan.Min_EmployedLaborRate, row.MonthNum, row.MinEmployedLaborRate);
                SetMonthValue(plan.Min_ContactLaborRate, row.MonthNum, row.MinContactLaborRate);
                SetMonthValue(plan.Min_OverTimePremiumDollars, row.MonthNum, row.MinOverTimePremiumDollars);
                SetMonthValue(plan.Min_OtPercent, row.MonthNum, row.MinOtPercent);
                SetMonthValue(plan.Min_OtFte, row.MonthNum, row.MinOtFte);
                SetMonthValue(plan.Min_DeptUOS, row.MonthNum, row.MinDeptUOS);
                SetMonthValue(plan.Min_SemiVariableFtes, row.MonthNum, row.MinSemiVariableFtes);
                SetMonthValue(plan.Min_VariableProdHrsPerUOS, row.MonthNum, row.MinVariableProdHrsPerUOS);
                SetMonthValue(plan.Min_TotalProdHrsPerUOS, row.MonthNum, row.MinTotalProdHrsPerUOS);
                SetMonthValue(plan.Min_TotalPaidHrsPerUOS, row.MonthNum, row.MinTotalPaidHrsPerUOS);
                SetMonthValue(plan.Min_MinFTE, row.MonthNum, row.MinMinFTE);
            }

            // Set Total values from last row
            var lastRow = rows.Last();
            plan.EmployedProductiveFtes.Total = lastRow.EmployedProductiveFtesTotal;
            plan.ContractLaborPercent.Total = lastRow.ContractLaborPercentTotal;
            plan.ContractFtes.Total = lastRow.ContractFTEsTotal;
            plan.TotalProductiveFtes.Total = lastRow.TotalProductiveFtesTotal;
            plan.NonProductivePercent.Total = lastRow.NonProductivePercentTotal;
            plan.NonProductiveFtes.Total = lastRow.NonProductiveFtesTotal;
            plan.EmployedPaidFtes.Total = lastRow.EmployedPaidFtesTotal;
            plan.TotalFtes.Total = lastRow.TotalFtesTotal;
            plan.TotalSalariesAndWages.Total = lastRow.TotalSalariesAndWagesTotal;
            plan.TotalContractLaborDollars.Total = lastRow.TotalContractLaborDollarsTotal;
            plan.TotalLaborExpense.Total = lastRow.TotalLaborExpenseTotal;
            plan.EmployedLaborRate.Total = lastRow.EmployedLaborRateTotal;
            plan.ContactLaborRate.Total = lastRow.ContractLaborRateTotal;
            plan.OverTimePremiumDollars.Total = lastRow.OTPremiumTotal;
            plan.OtPercent.Total = lastRow.OtPercentTotal;
            plan.OtFte.Total = lastRow.OtFtesTotal;
            plan.DeptUOS.Total = lastRow.DeptUOSTotal;
            plan.SemiVariableFtes.Total = lastRow.SemiVariableProductiveFtesTotal;
            plan.VariableProdHrsPerUOS.Total = lastRow.VariableProdHrsUOSTotal;
            plan.TotalProdHrsPerUOS.Total = lastRow.TotalProdHrsUOSTotal;
            plan.TotalPaidHrsPerUOS.Total = lastRow.TotalPaidHrsUOSTotal;
            plan.MinFTE.Total = lastRow.TotalMinFTE;

            return plan;
        }

        private static void SetMonthValue(MonthlyData monthlyData, int monthNum, double value)
        {
            switch (monthNum)
            {
                case 1: monthlyData.Jan = value; break;
                case 2: monthlyData.Feb = value; break;
                case 3: monthlyData.Mar = value; break;
                case 4: monthlyData.Apr = value; break;
                case 5: monthlyData.May = value; break;
                case 6: monthlyData.Jun = value; break;
                case 7: monthlyData.Jul = value; break;
                case 8: monthlyData.Aug = value; break;
                case 9: monthlyData.Sep = value; break;
                case 10: monthlyData.Oct = value; break;
                case 11: monthlyData.Nov = value; break;
                case 12: monthlyData.Dec = value; break;
            }
        }

        private static int GetInt(SqlDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                return reader.IsDBNull(ordinal) ? 0 : reader.GetInt32(ordinal);
            }
            catch
            {
                return 0;
            }
        }

        private static long GetLong(SqlDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                return reader.IsDBNull(ordinal) ? 0 : reader.GetInt64(ordinal);
            }
            catch
            {
                return 0;
            }
        }

        private static double GetDouble(SqlDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                if (reader.IsDBNull(ordinal)) return 0.0;

                var value = reader.GetValue(ordinal);
                double result = 0.0;

                if (value is double d)
                    result = d;
                else if (value is decimal dec)
                    result = (double)dec;
                else if (value is float f)
                    result = (double)f;
                else if (value is int i)
                    result = (double)i;
                else
                    result = Convert.ToDouble(value);

                return Math.Round(result, 2); // Round to 2 decimal places
            }
            catch
            {
                return 0.0;
            }
        }

        private static string GetString(SqlDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                return reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}