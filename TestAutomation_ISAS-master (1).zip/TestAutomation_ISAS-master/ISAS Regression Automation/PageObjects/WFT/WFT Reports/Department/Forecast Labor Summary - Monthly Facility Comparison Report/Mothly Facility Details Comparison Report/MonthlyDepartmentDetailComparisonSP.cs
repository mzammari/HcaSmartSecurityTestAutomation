﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class MonthlyDepartmentDetailComparisonSP
    {
        public static string GetMonthlyDepartmentDetailComparisonQuery()
        {
            string sp = $"declare @PlanID BIGINT ={RunData.PlanID}" + Environment.NewLine +
                $"declare @PlanIDCompareTo BIGINT={RunData.PlanTwoID}" + Environment.NewLine +
                $"declare @DeptNumber INT={RunData.Deptartment}" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "--Declare @PlanID BIGINT=128481356, @PlanIDCompareTo BIGINT = 117984877,@DeptNumber INT = 0" + Environment.NewLine +
                "Declare @StDept INT" + Environment.NewLine +
                "DECLARE @EndDept INT" + Environment.NewLine +
                "--DECLARE @CoId BIGINT" + Environment.NewLine +
                "IF (@DeptNumber is null OR @DeptNumber <= 0)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "SET @StDept=1" + Environment.NewLine +
                "SET @EndDept=999" + Environment.NewLine +
                "END" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "SET @StDept=@DeptNumber" + Environment.NewLine +
                "SET @EndDept=@DeptNumber" + Environment.NewLine +
                "END" + Environment.NewLine +
                "--SELECT TOP 1 @CoId=CoId" + Environment.NewLine +
                "--FROM Facility F" + Environment.NewLine +
                "--JOIN Department D ON D.Facility_ID = F.Id" + Environment.NewLine +
                "--JOIN WftDepartment WD ON WD.Department_ID = D.Id" + Environment.NewLine +
                "--WHERE WD.WftPlan_ID = @PlanID --AND D.Number = @DeptNumber" + Environment.NewLine +
                "--AND D.Number BETWEEN @StDept AND @EndDept" + Environment.NewLine +
                "IF EXISTS( SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                "WHERE ID = OBJECT_ID(N'tempdb..#TempMonthlyValue')  )" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "DROP TABLE #TempMonthlyValue;" + Environment.NewLine +
                "END;" + Environment.NewLine +
                "IF EXISTS( SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                "WHERE ID = OBJECT_ID(N'tempdb..#TempAllValue')  )" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "DROP TABLE #TempAllValue;" + Environment.NewLine +
                "END;" + Environment.NewLine +
                "IF EXISTS( SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                "WHERE ID = OBJECT_ID(N'tempdb..#TempFacStatValue')  )" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "DROP TABLE #TempFacStatValue;" + Environment.NewLine +
                "END;" + Environment.NewLine +
                "-- to get second highest and second lowest value keep result set in temp table" + Environment.NewLine +
                "CREATE TABLE #TempMonthlyValue(" + Environment.NewLine +
                "IndexID INT," + Environment.NewLine +
                "PlanID INT," + Environment.NewLine +
                "WftDepartment_ID BIGINT NOT NULL," + Environment.NewLine +
                "DepartmentNumber INT," + Environment.NewLine +
                "[Year] INT," + Environment.NewLine +
                "MonthNum INT ," + Environment.NewLine +
                "[MonthName] VARCHAR(25)," + Environment.NewLine +
                "EmployedProductiveFtes decimal(19,5)," + Environment.NewLine +
                "ContractLaborPercent decimal(19,5)," + Environment.NewLine +
                "ContractFtes decimal(19,5)," + Environment.NewLine +
                "TotalProductiveFtes decimal(19,5)," + Environment.NewLine +
                "NonProductivePercent decimal(19,5)," + Environment.NewLine +
                "NonProductiveFtes decimal(19,5)," + Environment.NewLine +
                "EmployedPaidFtes decimal(19,5)," + Environment.NewLine +
                "TotalFtes decimal(19,5)," + Environment.NewLine +
                "TotalSalariesAndWages decimal(19,5)," + Environment.NewLine +
                "TotalContractLaborDollars decimal(19,5)," + Environment.NewLine +
                "TotalLaborExpense decimal(19,5)," + Environment.NewLine +
                "EmployedLaborRate decimal(19,5)," + Environment.NewLine +
                "ContactLaborRate decimal(19,5)," + Environment.NewLine +
                "OverTimePremiumDollars decimal(19,5)," + Environment.NewLine +
                "OtPercent decimal(19,5)," + Environment.NewLine +
                "OtFte decimal(19,5)," + Environment.NewLine +
                "DeptUOS decimal(19,5)," + Environment.NewLine +
                "SemiVariableFtes  decimal(19,5)," + Environment.NewLine +
                "VariableProdHrsPerUOS  decimal(19,5)," + Environment.NewLine +
                "TotalProdHrsPerUOS  decimal(19,5)," + Environment.NewLine +
                "TotalPaidHrsPerUOS  decimal(19,5)," + Environment.NewLine +
                "MinFTE decimal(19,5)" + Environment.NewLine +
                ")" + Environment.NewLine +
                "-- Final table to store data" + Environment.NewLine +
                "CREATE TABLE #FinalOutput(" + Environment.NewLine +
                "IndexID INT," + Environment.NewLine +
                "PlanID INT," + Environment.NewLine +
                "WftDepartment_ID BIGINT," + Environment.NewLine +
                "DepartmentNumber INT," + Environment.NewLine +
                "Year INT," + Environment.NewLine +
                "MonthNum INT," + Environment.NewLine +
                "MonthName VARCHAR(25)," + Environment.NewLine +
                "EmployedProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "ContractLaborPercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "ContractFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "NonProductivePercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "NonProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "EmployedPaidFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalSalariesAndWages DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalContractLaborDollars DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalLaborExpense DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "EmployedLaborRate DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "ContactLaborRate DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "OverTimePremiumDollars DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "OtPercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "OtFte DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "DeptUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "SemiVariableFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "VariableProdHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalProdHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalPaidHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinFTE DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "EmployedProductiveFtesTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "ContractLaborPercentTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "ContractFTEsTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalProductiveFtesTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "NonProductivePercentTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "NonProductiveFtesTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "EmployedPaidFtesTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalFtesTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalSalariesAndWagesTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalContractLaborDollarsTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalLaborExpenseTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "EmployedLaborRateTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "ContractLaborRateTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "OTPremiumTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "OtPercentTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "OtFtesTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "DeptUOSTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "SemiVariableProductiveFtesTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "VariableProdHrsUOSTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalProdHrsUOSTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalPaidHrsUOSTotal DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "TotalMinFTE DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxEmployedProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxContractLaborPercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxContractFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxTotalProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxNonProductivePercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxNonProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxEmployedPaidFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxTotalFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxTotalSalariesAndWages DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxTotalContractLaborDollars DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxTotalLaborExpense DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxEmployedLaborRate DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxContactLaborRate DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxOverTimePremiumDollars DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxOtPercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxOtFte DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxDeptUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxSemiVariableFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxVariableProdHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxTotalProdHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxTotalPaidHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MaxMinFTE DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinEmployedProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinContractLaborPercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinContractFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinTotalProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinNonProductivePercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinNonProductiveFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinEmployedPaidFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinTotalFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinTotalSalariesAndWages DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinTotalContractLaborDollars DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinTotalLaborExpense DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinEmployedLaborRate DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinContactLaborRate DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinOverTimePremiumDollars DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinOtPercent DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinOtFte DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinDeptUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinSemiVariableFtes DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinVariableProdHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinTotalProdHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinTotalPaidHrsPerUOS DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "MinMinFTE DECIMAL(19,5) DEFAULT 0," + Environment.NewLine +
                "DeptType Varchar(100)," + Environment.NewLine +
                "DeptNumber INT," + Environment.NewLine +
                "DeptName Varchar(100)," + Environment.NewLine +
                "FacilityDesc Varchar(500)," + Environment.NewLine +
                "StatDescription Varchar(100)," + Environment.NewLine +
                "DeptTypeCompareTo Varchar(100)," + Environment.NewLine +
                "DeptNumberCompareTo INT," + Environment.NewLine +
                "DeptNameCompareTo Varchar(100)," + Environment.NewLine +
                "FacilityDescCompareTo Varchar(500)," + Environment.NewLine +
                "StatDescriptionCompareTo  Varchar(100)" + Environment.NewLine +
                ")" + Environment.NewLine +
                "INSERT INTO #TempMonthlyValue(" + Environment.NewLine +
                "IndexID," + Environment.NewLine +
                "PlanID," + Environment.NewLine +
                "WftDepartment_ID," + Environment.NewLine +
                "DepartmentNumber," + Environment.NewLine +
                "[Year]," + Environment.NewLine +
                "MonthNum ," + Environment.NewLine +
                "[MonthName] ," + Environment.NewLine +
                "EmployedProductiveFtes," + Environment.NewLine +
                "ContractLaborPercent," + Environment.NewLine +
                "ContractFtes," + Environment.NewLine +
                "TotalProductiveFtes," + Environment.NewLine +
                "NonProductivePercent," + Environment.NewLine +
                "NonProductiveFtes," + Environment.NewLine +
                "EmployedPaidFtes," + Environment.NewLine +
                "TotalFtes," + Environment.NewLine +
                "TotalSalariesAndWages," + Environment.NewLine +
                "TotalContractLaborDollars," + Environment.NewLine +
                "TotalLaborExpense," + Environment.NewLine +
                "EmployedLaborRate," + Environment.NewLine +
                "ContactLaborRate," + Environment.NewLine +
                "OverTimePremiumDollars," + Environment.NewLine +
                "OtPercent," + Environment.NewLine +
                "OtFte," + Environment.NewLine +
                "DeptUOS," + Environment.NewLine +
                "SemiVariableFtes ," + Environment.NewLine +
                "VariableProdHrsPerUOS ," + Environment.NewLine +
                "TotalProdHrsPerUOS ," + Environment.NewLine +
                "TotalPaidHrsPerUOS," + Environment.NewLine +
                "MinFTE" + Environment.NewLine +
                ")" + Environment.NewLine +
                "SELECT" + Environment.NewLine +
                "case WftPlan_ID when @PlanID then 1 When @PlanIDCompareTo Then 2 END," + Environment.NewLine +
                "D.WftPlan_ID," + Environment.NewLine +
                "V.WftDepartment_ID," + Environment.NewLine +
                "DT.Number," + Environment.NewLine +
                "P.[Year]," + Environment.NewLine +
                "v.[Month] as MonthNum," + Environment.NewLine +
                "CONVERT(VARCHAR(3),DateName( month , DateAdd( Month ,V.[Month] , 0 ) - 1))  as 'MonthName'" + Environment.NewLine +
                ",V.EmployeeProductiveHours/dbo.fn_GetFortyBySevenDaysInMonth(P.[Year],v.[Month]) as 'EmployedProductiveFtes'" + Environment.NewLine +
                ",ContractLaborPercent" + Environment.NewLine +
                ",V.ContractLaborFtes as 'ContractFTEs'," + Environment.NewLine +
                "TotalProductiveFtes AS  TotalProductiveFtes," + Environment.NewLine +
                "NonProductivePercent," + Environment.NewLine +
                "NonProductiveHours /dbo.fn_GetFortyBySevenDaysInMonth(P.[Year],v.[Month])  as NonProductiveFtes," + Environment.NewLine +
                "EmployeePaidManHours/dbo.fn_GetFortyBySevenDaysInMonth(P.[Year],v.[Month]) as EmployedPaidFtes," + Environment.NewLine +
                "V.TotalPaidFtes  as TotalFtes," + Environment.NewLine +
                "EmployedSalaries as TotalSalariesAndWages," + Environment.NewLine +
                "ContractAmount as TotalContractLaborDollars," + Environment.NewLine +
                "[EmployedSalaries] + ContractAmount as TotalLaborExpense," + Environment.NewLine +
                "EmployedLaborRate," + Environment.NewLine +
                "ContractRate as 'ContractLaborRate'," + Environment.NewLine +
                "(OtPercent/100 * EmployeePaidManHours * EmployedLaborRate * 0.5) as 'OTPremium'," + Environment.NewLine +
                "OtPercent," + Environment.NewLine +
                "OtFte," + Environment.NewLine +
                "DeptVolume  as 'DeptUOS'" + Environment.NewLine +
                ",V.SemiVariableProductiveFtes" + Environment.NewLine +
                ",PlusHoursPerUos as 'VariableProdHrsUOS'" + Environment.NewLine +
                ",CASE WHEN ISNULL(DeptVolume,0)= 0 THEN 0 ELSE  [TotalProductiveHours]/DeptVolume end  as 'TotalProdHrsUOS'" + Environment.NewLine +
                ",CASE WHEN ISNULL(DeptVolume,0)= 0 THEN 0 ELSE  TotalPaidHours/DeptVolume end as 'TotalPaidHrsUOS'" + Environment.NewLine +
                ", ProductiveMinFtes" + Environment.NewLine +
                "FROM WftMonthlyValue V" + Environment.NewLine +
                "JOIN WftDepartment D ON D.Id = V.WftDepartment_ID" + Environment.NewLine +
                "JOIN Department DT ON D.Department_ID = DT.Id" + Environment.NewLine +
                "JOIN Facility F ON DT.Facility_ID = F.Id" + Environment.NewLine +
                "JOIN ReferenceSourceYear RY ON RY.Month = V.Month" + Environment.NewLine +
                "JOIN WFTPLAN P ON P.Id = D.WftPlan_ID" + Environment.NewLine +
                "WHERE D.WftPlan_ID IN (@PlanID,@PlanIDCompareTo) AND DT.Number BETWEEN @StDept AND @EndDept AND RY.CoId = F.CoId and  RY.SourceType = 1" + Environment.NewLine +
                "AND DT.IsInactiveInWFT=0" + Environment.NewLine +
                "INSERT INTO #FinalOutput (IndexID," + Environment.NewLine +
                "PlanID," + Environment.NewLine +
                "WftDepartment_ID," + Environment.NewLine +
                "DepartmentNumber," + Environment.NewLine +
                "Year," + Environment.NewLine +
                "MonthNum," + Environment.NewLine +
                "MonthName," + Environment.NewLine +
                "EmployedProductiveFtes," + Environment.NewLine +
                "ContractLaborPercent," + Environment.NewLine +
                "ContractFtes," + Environment.NewLine +
                "TotalProductiveFtes," + Environment.NewLine +
                "NonProductivePercent," + Environment.NewLine +
                "NonProductiveFtes," + Environment.NewLine +
                "EmployedPaidFtes," + Environment.NewLine +
                "TotalFtes," + Environment.NewLine +
                "TotalSalariesAndWages," + Environment.NewLine +
                "TotalContractLaborDollars," + Environment.NewLine +
                "TotalLaborExpense," + Environment.NewLine +
                "EmployedLaborRate," + Environment.NewLine +
                "ContactLaborRate," + Environment.NewLine +
                "OverTimePremiumDollars," + Environment.NewLine +
                "OtPercent," + Environment.NewLine +
                "OtFte," + Environment.NewLine +
                "DeptUOS," + Environment.NewLine +
                "SemiVariableFtes," + Environment.NewLine +
                "VariableProdHrsPerUOS," + Environment.NewLine +
                "TotalProdHrsPerUOS," + Environment.NewLine +
                "TotalPaidHrsPerUOS," + Environment.NewLine +
                "MinFTE," + Environment.NewLine +
                "EmployedProductiveFtesTotal," + Environment.NewLine +
                "ContractLaborPercentTotal," + Environment.NewLine +
                "ContractFTEsTotal," + Environment.NewLine +
                "TotalProductiveFtesTotal," + Environment.NewLine +
                "NonProductivePercentTotal," + Environment.NewLine +
                "NonProductiveFtesTotal," + Environment.NewLine +
                "EmployedPaidFtesTotal," + Environment.NewLine +
                "TotalFtesTotal," + Environment.NewLine +
                "TotalSalariesAndWagesTotal," + Environment.NewLine +
                "TotalContractLaborDollarsTotal," + Environment.NewLine +
                "TotalLaborExpenseTotal," + Environment.NewLine +
                "EmployedLaborRateTotal," + Environment.NewLine +
                "ContractLaborRateTotal," + Environment.NewLine +
                "OTPremiumTotal," + Environment.NewLine +
                "OtPercentTotal," + Environment.NewLine +
                "OtFtesTotal," + Environment.NewLine +
                "DeptUOSTotal," + Environment.NewLine +
                "SemiVariableProductiveFtesTotal," + Environment.NewLine +
                "VariableProdHrsUOSTotal," + Environment.NewLine +
                "TotalProdHrsUOSTotal," + Environment.NewLine +
                "TotalPaidHrsUOSTotal," + Environment.NewLine +
                "TotalMinFTE" + Environment.NewLine +
                ",DeptType," + Environment.NewLine +
                "DeptNumber," + Environment.NewLine +
                "DeptName," + Environment.NewLine +
                "FacilityDesc," + Environment.NewLine +
                "StatDescription," + Environment.NewLine +
                "DeptTypeCompareTo," + Environment.NewLine +
                "DeptNumberCompareTo," + Environment.NewLine +
                "DeptNameCompareTo," + Environment.NewLine +
                "FacilityDescCompareTo," + Environment.NewLine +
                "StatDescriptionCompareTo" + Environment.NewLine +
                ")" + Environment.NewLine +
                "SELECT  V.*," + Environment.NewLine +
                "EmployeeProductiveHoursTotal/ dbo.fn_GetFortyBySevenDaysInYear(P.[Year]) as 'EmployedProductiveFtesTotal'" + Environment.NewLine +
                ",D.ContractLaborPercentTotal" + Environment.NewLine +
                ",ContractLaborFtesTotal as 'ContractFTEsTotal'," + Environment.NewLine +
                "D.TotalProductiveFtesTotal AS  TotalProductiveFtesTotal," + Environment.NewLine +
                "D.NonProductivePercentTotal," + Environment.NewLine +
                "NonProductiveHoursTotal / dbo.fn_GetFortyBySevenDaysInYear(P.[Year]) as NonProductiveFtesTotal," + Environment.NewLine +
                "EmployeePaidManHoursTotal/dbo.fn_GetFortyBySevenDaysInYear(P.[Year]) as EmployedPaidFtesTotal," + Environment.NewLine +
                "TotalPaidFtesTotal  as TotalFtesTotal," + Environment.NewLine +
                "EmployedSalariesTotal as TotalSalariesAndWagesTotal," + Environment.NewLine +
                "ContractLaborDollarsTotal as TotalContractLaborDollarsTotal," + Environment.NewLine +
                "[EmployedSalariesTotal] + ContractLaborDollarsTotal as TotalLaborExpenseTotal," + Environment.NewLine +
                "D.EmployedLaborRateTotal," + Environment.NewLine +
                "ContractRateTotal as 'ContractLaborRateTotal'," + Environment.NewLine +
                "V1.SumOfOTPremium AS OTPremiumTotal," + Environment.NewLine +
                "D.OtPercentTotal," + Environment.NewLine +
                "D.OtFtesTotal," + Environment.NewLine +
                "DeptVolumeTotal   as 'DeptUOSTotal'" + Environment.NewLine +
                ", SemiVariableProductiveFtesTotal" + Environment.NewLine +
                ",VariableHoursPerUosTotal as 'VariableProdHrsUOSTotal'" + Environment.NewLine +
                ",CASE WHEN ISNULL(DeptVolumeTotal,0)= 0 THEN 0 ELSE  [TotalProductiveHoursTotal]/DeptVolumeTotal END as 'TotalProdHrsUOSTotal'" + Environment.NewLine +
                ",CASE WHEN ISNULL(DeptVolumeTotal,0)= 0 THEN 0 ELSE  [TotalPaidHoursTotal]/DeptVolumeTotal END as 'TotalPaidHrsUOSTotal'" + Environment.NewLine +
                ",ProductiveMinFtesTotal as TotalMinFTE" + Environment.NewLine +
                ",HD.DeptType," + Environment.NewLine +
                "HD.DeptNumber," + Environment.NewLine +
                "HD.DeptName," + Environment.NewLine +
                "HD.FactilityDesc," + Environment.NewLine +
                "HD.StatDescription," + Environment.NewLine +
                "HDCompareTo.DeptType DeptTypeCompareTo," + Environment.NewLine +
                "HDCompareTo.DeptNumber DeptNumberCompareTo," + Environment.NewLine +
                "HDCompareTo.DeptName DeptNameCompareTo," + Environment.NewLine +
                "HDCompareTo.FactilityDesc FacilityDescCompareTo," + Environment.NewLine +
                "HDCompareTo.StatDescription StatDescriptionCompareTo" + Environment.NewLine +
                "FROM #TempMonthlyValue V INNER JOIN  WftDepartment D ON V.WftDepartment_id=d.Id" + Environment.NewLine +
                "inner join (SELECT   D.WftPlan_ID," + Environment.NewLine +
                "MV.WftDepartment_ID," + Environment.NewLine +
                "sum(OtPercent/100 * EmployeePaidManHours * EmployedLaborRate * 0.5) as SumOfOTPremium" + Environment.NewLine +
                "FROM WftMonthlyValue MV" + Environment.NewLine +
                "JOIN WftDepartment D ON D.Id = MV.WftDepartment_ID" + Environment.NewLine +
                "JOIN ReferenceSourceYear RY ON RY.Month = MV.Month" + Environment.NewLine +
                "JOIN Department DT ON D.Department_ID = DT.Id" + Environment.NewLine +
                "JOIN Facility F ON DT.Facility_ID = F.Id" + Environment.NewLine +
                "WHERE D.WftPlan_ID IN (@PlanID,@PlanIDCompareTo) AND DT.Number BETWEEN @StDept AND @EndDept AND RY.CoId = F.CoId and  RY.SourceType = 1   AND DT.IsInactiveInWFT=0" + Environment.NewLine +
                "GROUP BY D.WftPlan_ID,MV.WftDepartment_ID" + Environment.NewLine +
                ") V1 on V.WftDepartment_id=V1.WftDepartment_ID  AND V1.WftPlan_ID = D.WftPlan_ID" + Environment.NewLine +
                "JOIN WFTPLAN P ON P.Id = D.WftPlan_ID" + Environment.NewLine +
                "JOIN Department DT ON D.Department_ID = DT.Id" + Environment.NewLine +
                "AND DT.IsInactiveInWFT=0" + Environment.NewLine +
                "LEFT JOIN (" + Environment.NewLine +
                "SELECT D.Number as DeptNumber, F.[Description] as FactilityDesc,D.Name DeptName,[StatDescription],F.CoId," + Environment.NewLine +
                "CASE WHEN d.IsUserDefined=1 then 'User Defined' ELSE T.Description END AS DeptType" + Environment.NewLine +
                "FROM [Department] D" + Environment.NewLine +
                "JOIN [Facility] F ON F.Id = D.Facility_ID" + Environment.NewLine +
                "JOIN [DepartmentType] T ON T.Id = D.DepartmentType_ID" + Environment.NewLine +
                "JOIN [Wftplan] wp ON wp.Facility_ID=F.Id" + Environment.NewLine +
                "WHERE wp.Id = @PlanID AND D.IsInactiveInWFT=0" + Environment.NewLine +
                ") HD  ON HD.DeptNumber = V.DepartmentNumber" + Environment.NewLine +
                "LEFT JOIN (" + Environment.NewLine +
                "SELECT D.Number as DeptNumber, F.[Description] as FactilityDesc,D.Name DeptName,[StatDescription],F.CoId," + Environment.NewLine +
                "CASE WHEN d.IsUserDefined=1 then 'User Defined' ELSE T.Description END AS DeptType" + Environment.NewLine +
                "FROM [Department] D" + Environment.NewLine +
                "JOIN [Facility] F ON F.Id = D.Facility_ID" + Environment.NewLine +
                "JOIN [DepartmentType] T ON T.Id = D.DepartmentType_ID" + Environment.NewLine +
                "JOIN [Wftplan] wp ON wp.Facility_ID=F.Id" + Environment.NewLine +
                "WHERE wp.Id = @PlanIDCompareTo AND D.IsInactiveInWFT=0" + Environment.NewLine +
                ") HDCompareTo  ON HDCompareTo.DeptNumber = V.DepartmentNumber" + Environment.NewLine +
                "WHERE D.WftPlan_ID IN (@PlanID,@PlanIDCompareTo) AND DT.Number BETWEEN @StDept AND @EndDept" + Environment.NewLine +
                "--- Update Second Highest and Second Lowest Value to do color coding for Top 2 and bottom 2 values" + Environment.NewLine +
                "UPDATE #FinalOutput" + Environment.NewLine +
                "SET MaxEmployedProductiveFtes    = t2.MaxEmployedProductiveFtes," + Environment.NewLine +
                "MaxContractLaborPercent   = t2.MaxContractLaborPercent," + Environment.NewLine +
                "MaxContractFtes     = t2.MaxContractFtes," + Environment.NewLine +
                "MaxTotalProductiveFtes   = t2.MaxTotalProductiveFtes," + Environment.NewLine +
                "MaxNonProductivePercent   = t2.MaxNonProductivePercent," + Environment.NewLine +
                "MaxNonProductiveFtes   = t2.MaxNonProductiveFtes," + Environment.NewLine +
                "MaxEmployedPaidFtes    = t2.MaxEmployedPaidFtes," + Environment.NewLine +
                "MaxTotalFtes     = t2.MaxTotalFtes," + Environment.NewLine +
                "MaxTotalSalariesAndWages  = t2.MaxTotalSalariesAndWages," + Environment.NewLine +
                "MaxTotalContractLaborDollars = t2.MaxTotalContractLaborDollars," + Environment.NewLine +
                "MaxTotalLaborExpense   = t2.MaxTotalLaborExpense," + Environment.NewLine +
                "MaxEmployedLaborRate   = t2.MaxEmployedLaborRate," + Environment.NewLine +
                "MaxContactLaborRate    = t2.MaxContactLaborRate," + Environment.NewLine +
                "MaxOverTimePremiumDollars  = t2.MaxOverTimePremiumDollars," + Environment.NewLine +
                "MaxOtPercent     = t2.MaxOtPercent," + Environment.NewLine +
                "MaxOTFTE      = t2.MaxOTFTE," + Environment.NewLine +
                "MaxDeptUOS      = t2.MaxDeptUOS," + Environment.NewLine +
                "MaxSemiVariableFtes    = t2.MaxSemiVariableFtes," + Environment.NewLine +
                "MaxVariableProdHrsPerUOS  = t2.MaxVariableProdHrsPerUOS," + Environment.NewLine +
                "MaxTotalProdHrsPerUOS   = t2.MaxTotalProdHrsPerUOS," + Environment.NewLine +
                "MaxTotalPaidHrsPerUOS   = t2.MaxTotalPaidHrsPerUOS," + Environment.NewLine +
                "MaxMinFTE      = t2.MaxMinFTE" + Environment.NewLine +
                "FROM #FinalOutput FO" + Environment.NewLine +
                "INNER JOIN" + Environment.NewLine +
                "(" + Environment.NewLine +
                "Select PlanID, WftDepartment_ID," + Environment.NewLine +
                "Min(EmployedProductiveFtes)  MaxEmployedProductiveFtes," + Environment.NewLine +
                "Min(ContractLaborPercent)   MaxContractLaborPercent," + Environment.NewLine +
                "Min(ContractFtes)     MaxContractFtes," + Environment.NewLine +
                "Min(TotalProductiveFtes)   MaxTotalProductiveFtes," + Environment.NewLine +
                "Min(NonProductivePercent)   MaxNonProductivePercent," + Environment.NewLine +
                "Min(NonProductiveFtes)   MaxNonProductiveFtes," + Environment.NewLine +
                "Min(EmployedPaidFtes)    MaxEmployedPaidFtes," + Environment.NewLine +
                "Min(TotalFtes)     MaxTotalFtes," + Environment.NewLine +
                "Min(TotalSalariesAndWages)  MaxTotalSalariesAndWages," + Environment.NewLine +
                "Min(TotalContractLaborDollars) MaxTotalContractLaborDollars," + Environment.NewLine +
                "Min(TotalLaborExpense)   MaxTotalLaborExpense," + Environment.NewLine +
                "Min(EmployedLaborRate)   MaxEmployedLaborRate," + Environment.NewLine +
                "Min(ContactLaborRate)    MaxContactLaborRate," + Environment.NewLine +
                "Min(OverTimePremiumDollars)  MaxOverTimePremiumDollars," + Environment.NewLine +
                "Min(OtPercent)     MaxOtPercent," + Environment.NewLine +
                "Min(OTFTE)      MaxOTFTE," + Environment.NewLine +
                "Min(DeptUOS)      MaxDeptUOS," + Environment.NewLine +
                "Min(SemiVariableFtes)    MaxSemiVariableFtes," + Environment.NewLine +
                "Min(VariableProdHrsPerUOS)  MaxVariableProdHrsPerUOS," + Environment.NewLine +
                "Min(TotalProdHrsPerUOS)   MaxTotalProdHrsPerUOS," + Environment.NewLine +
                "Min(TotalPaidHrsPerUOS)   MaxTotalPaidHrsPerUOS," + Environment.NewLine +
                "Min(MinFTE)      MaxMinFTE" + Environment.NewLine +
                "FROM (" + Environment.NewLine +
                "SELECT PlanID, WftDepartment_ID," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(EmployedProductiveFtes, 2) DESC)  <=2 THEN ROUND(EmployedProductiveFtes, 2)  Else NULL END EmployedProductiveFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(ContractLaborPercent, 2) DESC)   <=2 THEN ROUND(ContractLaborPercent, 2)   ELSE NULL END ContractLaborPercent," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(ContractFtes, 2) DESC)     <=2 THEN ROUND(ContractFtes, 2)     ELSE NULL END ContractFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalProductiveFtes, 2) DESC)   <=2 THEN ROUND(TotalProductiveFtes, 2)   ELSE NULL END TotalProductiveFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(NonProductivePercent, 2) DESC)   <=2 THEN ROUND(NonProductivePercent, 2)   ELSE NULL END NonProductivePercent," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(NonProductiveFtes, 2) DESC)   <=2 THEN ROUND(NonProductiveFtes, 2)   ELSE NULL END NonProductiveFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(EmployedPaidFtes, 2) DESC)    <=2 THEN ROUND(EmployedPaidFtes, 2)    ELSE NULL END EmployedPaidFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalFtes, 2) DESC)     <=2 THEN ROUND(TotalFtes, 2)     ELSE NULL END TotalFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalSalariesAndWages, 2) DESC)  <=2 THEN ROUND(TotalSalariesAndWages, 2)  ELSE NULL END TotalSalariesAndWages," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalContractLaborDollars, 2) DESC) <=2 THEN ROUND(TotalContractLaborDollars, 2) ELSE NULL END TotalContractLaborDollars," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalLaborExpense, 2) DESC)   <=2 THEN ROUND(TotalLaborExpense, 2)   ELSE NULL END TotalLaborExpense," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(EmployedLaborRate, 2) DESC)   <=2 THEN ROUND(EmployedLaborRate, 2)   ELSE NULL END EmployedLaborRate," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(ContactLaborRate, 2) DESC)    <=2 THEN ROUND(ContactLaborRate, 2)    ELSE NULL END ContactLaborRate," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(OverTimePremiumDollars, 0) DESC)  <=2 THEN ROUND(OverTimePremiumDollars, 0)  ELSE NULL END OverTimePremiumDollars," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(OtPercent, 2) DESC)     <=2 THEN ROUND(OtPercent, 2)     ELSE NULL END OtPercent," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(OTFTE, 2) DESC)      <=2 THEN ROUND(OTFTE, 2)      ELSE NULL END OTFTE," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(DeptUOS, 0) DESC)      <=2 THEN ROUND(DeptUOS, 0)      ELSE NULL END DeptUOS," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(SemiVariableFtes, 2) DESC)    <=2 THEN ROUND(SemiVariableFtes, 2)    ELSE NULL END SemiVariableFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(VariableProdHrsPerUOS, 3) DESC)  <=2 THEN ROUND(VariableProdHrsPerUOS, 3)  ELSE NULL END VariableProdHrsPerUOS," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalProdHrsPerUOS, 3) DESC)   <=2 THEN ROUND(TotalProdHrsPerUOS, 3)   ELSE NULL END TotalProdHrsPerUOS," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalPaidHrsPerUOS, 3) DESC)   <=2 THEN ROUND(TotalPaidHrsPerUOS, 3)   ELSE NULL END TotalPaidHrsPerUOS," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(MinFTE, 3) DESC)      <=2 THEN ROUND(MinFTE, 3)      ELSE NULL END MinFTE" + Environment.NewLine +
                "from #TempMonthlyValue" + Environment.NewLine +
                ")  t1" + Environment.NewLine +
                "GROUP BY PlanID, WftDepartment_ID" + Environment.NewLine +
                ")t2 ON FO.PlanID=t2.PlanID AND FO.WftDepartment_ID=t2.WftDepartment_ID" + Environment.NewLine +
                "--Update Min value with second lowest values" + Environment.NewLine +
                "UPDATE #FinalOutput" + Environment.NewLine +
                "SET MinEmployedProductiveFtes    = t2.MinEmployedProductiveFtes," + Environment.NewLine +
                "MinContractLaborPercent   = t2.MinContractLaborPercent," + Environment.NewLine +
                "MinContractFtes     = t2.MinContractFtes," + Environment.NewLine +
                "MinTotalProductiveFtes   = t2.MinTotalProductiveFtes," + Environment.NewLine +
                "MinNonProductivePercent   = t2.MinNonProductivePercent," + Environment.NewLine +
                "MinNonProductiveFtes   = t2.MinNonProductiveFtes," + Environment.NewLine +
                "MinEmployedPaidFtes    = t2.MinEmployedPaidFtes," + Environment.NewLine +
                "MinTotalFtes     = t2.MinTotalFtes," + Environment.NewLine +
                "MinTotalSalariesAndWages  = t2.MinTotalSalariesAndWages," + Environment.NewLine +
                "MinTotalContractLaborDollars = t2.MinTotalContractLaborDollars," + Environment.NewLine +
                "MinTotalLaborExpense   = t2.MinTotalLaborExpense," + Environment.NewLine +
                "MinEmployedLaborRate   = t2.MinEmployedLaborRate," + Environment.NewLine +
                "MinContactLaborRate    = t2.MinContactLaborRate," + Environment.NewLine +
                "MinOverTimePremiumDollars  = t2.MinOverTimePremiumDollars," + Environment.NewLine +
                "MinOtPercent     = t2.MinOtPercent," + Environment.NewLine +
                "MinOTFTE      = t2.MinOTFTE," + Environment.NewLine +
                "MinDeptUOS      = t2.MinDeptUOS," + Environment.NewLine +
                "MinSemiVariableFtes    = t2.MinSemiVariableFtes," + Environment.NewLine +
                "MinVariableProdHrsPerUOS  = t2.MinVariableProdHrsPerUOS," + Environment.NewLine +
                "MinTotalProdHrsPerUOS   = t2.MinTotalProdHrsPerUOS," + Environment.NewLine +
                "MinTotalPaidHrsPerUOS   = t2.MinTotalPaidHrsPerUOS," + Environment.NewLine +
                "MinMinFTE      = t2.MinMinFTE" + Environment.NewLine +
                "FROM #FinalOutput FO" + Environment.NewLine +
                "INNER JOIN" + Environment.NewLine +
                "(" + Environment.NewLine +
                "Select PlanID, WftDepartment_ID," + Environment.NewLine +
                "Max(EmployedProductiveFtes)  MinEmployedProductiveFtes," + Environment.NewLine +
                "Max(ContractLaborPercent)   MinContractLaborPercent," + Environment.NewLine +
                "Max(ContractFtes)     MinContractFtes," + Environment.NewLine +
                "Max(TotalProductiveFtes)   MinTotalProductiveFtes," + Environment.NewLine +
                "Max(NonProductivePercent)   MinNonProductivePercent," + Environment.NewLine +
                "Max(NonProductiveFtes)   MinNonProductiveFtes," + Environment.NewLine +
                "Max(EmployedPaidFtes)    MinEmployedPaidFtes," + Environment.NewLine +
                "Max(TotalFtes)     MinTotalFtes," + Environment.NewLine +
                "Max(TotalSalariesAndWages)  MinTotalSalariesAndWages," + Environment.NewLine +
                "Max(TotalContractLaborDollars) MinTotalContractLaborDollars," + Environment.NewLine +
                "Max(TotalLaborExpense)   MinTotalLaborExpense," + Environment.NewLine +
                "Max(EmployedLaborRate)   MinEmployedLaborRate," + Environment.NewLine +
                "Max(ContactLaborRate)    MinContactLaborRate," + Environment.NewLine +
                "Max(OverTimePremiumDollars)  MinOverTimePremiumDollars," + Environment.NewLine +
                "Max(OtPercent)     MinOtPercent," + Environment.NewLine +
                "Max(OTFTE)      MinOTFTE," + Environment.NewLine +
                "Max(DeptUOS)      MinDeptUOS," + Environment.NewLine +
                "Max(SemiVariableFtes)    MinSemiVariableFtes," + Environment.NewLine +
                "Max(VariableProdHrsPerUOS)  MinVariableProdHrsPerUOS," + Environment.NewLine +
                "Max(TotalProdHrsPerUOS)   MinTotalProdHrsPerUOS," + Environment.NewLine +
                "Max(TotalPaidHrsPerUOS)   MinTotalPaidHrsPerUOS," + Environment.NewLine +
                "Max(MinFTE)      MinMinFTE" + Environment.NewLine +
                "FROM (" + Environment.NewLine +
                "SELECT PlanID, WftDepartment_ID," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(EmployedProductiveFtes, 2) ASC)  <=2 THEN ROUND(EmployedProductiveFtes, 2)  Else NULL END EmployedProductiveFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(ContractLaborPercent, 2) ASC)   <=2 THEN ROUND(ContractLaborPercent, 2)   ELSE NULL END ContractLaborPercent," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(ContractFtes, 2) ASC)     <=2 THEN ROUND(ContractFtes, 2)     ELSE NULL END ContractFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalProductiveFtes, 2) ASC)   <=2 THEN ROUND(TotalProductiveFtes, 2)   ELSE NULL END TotalProductiveFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(NonProductivePercent, 2) ASC)   <=2 THEN ROUND(NonProductivePercent, 2)   ELSE NULL END NonProductivePercent," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(NonProductiveFtes, 2) ASC)    <=2 THEN ROUND(NonProductiveFtes, 2)   ELSE NULL END NonProductiveFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(EmployedPaidFtes, 2) ASC)    <=2 THEN ROUND(EmployedPaidFtes, 2)    ELSE NULL END EmployedPaidFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalFtes, 2) ASC)      <=2 THEN ROUND(TotalFtes, 2)     ELSE NULL END TotalFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalSalariesAndWages, 2) ASC)   <=2 THEN ROUND(TotalSalariesAndWages, 2)  ELSE NULL END TotalSalariesAndWages," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalContractLaborDollars, 2) ASC)  <=2 THEN ROUND(TotalContractLaborDollars, 2) ELSE NULL END TotalContractLaborDollars," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalLaborExpense, 2) ASC)    <=2 THEN ROUND(TotalLaborExpense, 2)   ELSE NULL END TotalLaborExpense," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(EmployedLaborRate, 2) ASC)    <=2 THEN ROUND(EmployedLaborRate, 2)   ELSE NULL END EmployedLaborRate," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(ContactLaborRate, 2) ASC)    <=2 THEN ROUND(ContactLaborRate, 2)    ELSE NULL END ContactLaborRate," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(OverTimePremiumDollars, 0) ASC)  <=2 THEN ROUND(OverTimePremiumDollars, 0)  ELSE NULL END OverTimePremiumDollars," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(OtPercent, 2) ASC)      <=2 THEN ROUND(OtPercent, 2)     ELSE NULL END OtPercent," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(OTFTE, 2) ASC)       <=2 THEN ROUND(OTFTE, 2)      ELSE NULL END OTFTE," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(DeptUOS, 0) ASC)      <=2 THEN ROUND(DeptUOS, 0)      ELSE NULL END DeptUOS," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(SemiVariableFtes, 2) ASC)    <=2 THEN ROUND(SemiVariableFtes, 2)    ELSE NULL END SemiVariableFtes," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(VariableProdHrsPerUOS, 3) ASC)   <=2 THEN ROUND(VariableProdHrsPerUOS, 3)  ELSE NULL END VariableProdHrsPerUOS," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalProdHrsPerUOS, 3) ASC)   <=2 THEN ROUND(TotalProdHrsPerUOS, 3)   ELSE NULL END TotalProdHrsPerUOS," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(TotalPaidHrsPerUOS, 3) ASC)   <=2 THEN ROUND(TotalPaidHrsPerUOS, 3)   ELSE NULL END TotalPaidHrsPerUOS," + Environment.NewLine +
                "CASE WHEN DENSE_RANK() OVER( PARTITION BY PlanID, WftDepartment_ID ORDER BY ROUND(MinFTE, 3) ASC)      <=2 THEN ROUND(MinFTE, 3)      ELSE NULL END MinFTE" + Environment.NewLine +
                "from #TempMonthlyValue" + Environment.NewLine +
                ")  t1" + Environment.NewLine +
                "GROUP BY PlanID, WftDepartment_ID" + Environment.NewLine +
                ")t2 ON FO.PlanID=t2.PlanID AND FO.WftDepartment_ID=t2.WftDepartment_ID" + Environment.NewLine +
                "UPDATE FO" + Environment.NewLine +
                "SET DeptName = HD.DeptName," + Environment.NewLine +
                "DeptNumber = HD.DeptNumber," + Environment.NewLine +
                "DeptType=HD.DeptType," + Environment.NewLine +
                "StatDescription=HD.StatDescription," + Environment.NewLine +
                "FacilityDesc=HD.FactilityDesc" + Environment.NewLine +
                "FROM #FinalOutput FO INNER JOIN (" + Environment.NewLine +
                "SELECT D.Number as DeptNumber, F.[Description] as FactilityDesc,D.Name DeptName,[StatDescription],F.CoId," + Environment.NewLine +
                "CASE WHEN d.IsUserDefined=1 then 'User Defined' ELSE T.Description END AS DeptType" + Environment.NewLine +
                "FROM [Department] D" + Environment.NewLine +
                "JOIN [Facility] F ON F.Id = D.Facility_ID" + Environment.NewLine +
                "JOIN [DepartmentType] T ON T.Id = D.DepartmentType_ID" + Environment.NewLine +
                "JOIN [Wftplan] wp ON wp.Facility_ID=F.Id" + Environment.NewLine +
                "WHERE wp.Id = @PlanID AND D.IsInactiveInWFT=0" + Environment.NewLine +
                ") HD ON FO.DeptNumber=HD.DeptNumber" + Environment.NewLine +
                "UPDATE FO" + Environment.NewLine +
                "SET DeptNameCompareTo = HD.DeptName," + Environment.NewLine +
                "DeptNumberCompareTo = HD.DeptNumber," + Environment.NewLine +
                "DeptTypeCompareTo=HD.DeptType," + Environment.NewLine +
                "StatDescriptionCompareTo=HD.StatDescription," + Environment.NewLine +
                "FacilityDescCompareTo=HD.FactilityDesc" + Environment.NewLine +
                "FROM #FinalOutput FO INNER JOIN (" + Environment.NewLine +
                "SELECT D.Number as DeptNumber, F.[Description] as FactilityDesc,D.Name DeptName,[StatDescription],F.CoId," + Environment.NewLine +
                "CASE WHEN d.IsUserDefined=1 then 'User Defined' ELSE T.Description END AS DeptType" + Environment.NewLine +
                "FROM [Department] D" + Environment.NewLine +
                "JOIN [Facility] F ON F.Id = D.Facility_ID" + Environment.NewLine +
                "JOIN [DepartmentType] T ON T.Id = D.DepartmentType_ID" + Environment.NewLine +
                "JOIN [Wftplan] wp ON wp.Facility_ID=F.Id" + Environment.NewLine +
                "WHERE wp.Id = @PlanIDCompareTo AND D.IsInactiveInWFT=0" + Environment.NewLine +
                ") HD ON FO.DeptNumber=HD.DeptNumber" + Environment.NewLine +
                "IF(@PlanID = @PlanIDCompareTo)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "Select * Into #FinalOutput_Temp From #FinalOutput" + Environment.NewLine +
                "Update #FinalOutput_Temp Set IndexID=2" + Environment.NewLine +
                "Insert into #FinalOutput" + Environment.NewLine +
                "Select * from #FinalOutput_Temp" + Environment.NewLine +
                "END" + Environment.NewLine +
                "Select * from #FinalOutput Order by DepartmentNumber,IndexID,MonthNum" + Environment.NewLine +
                "DROP TABLE #FinalOutput   DROP TABLE #TempMonthlyValue" + Environment.NewLine +
                "END";
            return sp;

        }
    }
}
