﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Queries SQL database for Monthly Facility Total data
    /// Returns both Plan 1 and Plan 2 with 12 months each
    /// </summary>
    public static class MonthlyFacilityTotalSqlLoader
    {
        /// <summary>
        /// Load both Plan 1 and Plan 2 data from SQL database
        /// </summary>
        /// <param name="connectionString">Database connection string</param>
        /// <param name="sqlQuery">SQL query that returns 24 rows (12 per plan)</param>
        /// <returns>MonthlyFacilityTotalComparison with both plans</returns>
        public static MonthlyFacilityTotalComparison LoadFromSql()
        {
            string DB = RunData.DatabaseName;
            string sServerName = RunData.ServerName;
            string _connectionString = $"Data Source={sServerName};Initial Catalog={DB};Integrated Security=SSPI;";

            var sqlQuery = MonthlyFacilityTotalComarisonReportSP.getMonthlyFacilityTotalComparisonReportSP();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                using (var command = new SqlCommand(sqlQuery, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        return ParseFromSqlReader(reader);
                    }
                }
            }
        }

       

        private static MonthlyFacilityTotalComparison ParseFromSqlReader(SqlDataReader reader)
        {
            var comparison = new MonthlyFacilityTotalComparison();

            // Read all 24 rows (12 for each plan)
            var allRows = new List<SqlMonthlyRow>();

            while (reader.Read())
            {
                allRows.Add(ReadSingleRow(reader));
            }

            // Separate by IndexId
            var plan1Rows = allRows.Where(r => r.IndexId == 1).ToList();
            var plan2Rows = allRows.Where(r => r.IndexId == 2).ToList();

            // Parse each plan
            if (plan1Rows.Count > 0)
            {
                comparison.Plan1 = PivotToPlanData(plan1Rows);
            }

            if (plan2Rows.Count > 0)
            {
                comparison.Plan2 = PivotToPlanData(plan2Rows);
            }

            return comparison;
        }

        // Helper class to hold a single row's data
        private class SqlMonthlyRow
        {
            public int IndexId { get; set; }
            public long WftPlan_ID { get; set; }
            public int Year { get; set; }
            public int MonthNum { get; set; }
            public string MonthName { get; set; }
            public int CoId { get; set; }
            public string FacilityDescription { get; set; }

            // All numeric columns (116 columns total)
            public double DaysInMonth { get; set; }
            public double EmployedProductiveFtes { get; set; }
            public double ContractPercent { get; set; }
            public double ContractFTEs { get; set; }
            public double TotalProductiveFtes { get; set; }
            public double NonProductivePercent { get; set; }
            public double NonProductiveFtes { get; set; }
            public double EmployedPaidFtes { get; set; }
            public double TotalFtes { get; set; }
            public double TotalSalariesAndWages { get; set; }
            public double TotalContractLaborDollars { get; set; }
            public double TotalLaborExpense { get; set; }
            public double EmployedLaborRate { get; set; }
            public double ContractLaborRate { get; set; }
            public double OverTimePremiumDollars { get; set; }
            public double OtPercent { get; set; }
            public double OTFTEs { get; set; }
            public double Eeob { get; set; }
            public double MhAa { get; set; }
            public double Admissions { get; set; }
            public double AAdmissions { get; set; }
            public double PatientDays { get; set; }
            public double APatientDays { get; set; }
            public double ERVisits { get; set; }
            public double Outpatient { get; set; }
            public double DeptUOS { get; set; }
            public double SemiVariableProductiveFtes { get; set; }
            public double TotalProdHrsUOS { get; set; }
            public double VariableProdHrsUOS { get; set; }
            public double ProductiveMinFtes { get; set; }

            // Max values (30+ columns)
            public double Max_EmployedProductiveFtes { get; set; }
            public double Max_ContractLaborPercent { get; set; }
            public double Max_ContractFtes { get; set; }
            public double Max_TotalProductiveFtes { get; set; }
            public double Max_NonProductivePercent { get; set; }
            public double Max_NonProductiveFtes { get; set; }
            public double Max_EmployedPaidFtes { get; set; }
            public double Max_TotalFtes { get; set; }
            public double Max_TotalSalariesAndWages { get; set; }
            public double Max_TotalContractLaborDollars { get; set; }
            public double Max_TotalLaborExpense { get; set; }
            public double Max_EmployedLaborRate { get; set; }
            public double Max_ContractLaborRate { get; set; }
            public double Max_OverTimePremiumDollars { get; set; }
            public double Max_OtPercent { get; set; }
            public double Max_OtFte { get; set; }
            public double Max_Eeob { get; set; }
            public double Max_MhAa { get; set; }
            public double Max_SemiVariableFtes { get; set; }
            public double Max_VariableProdHrsPerUOS { get; set; }
            public double Max_TotalProdHrsPerUOS { get; set; }
            public double Max_MinFTE { get; set; }
            public double Max_Admissions { get; set; }
            public double Max_AAdmissions { get; set; }
            public double Max_PatientDays { get; set; }
            public double Max_APatientDays { get; set; }
            public double Max_ERVisits { get; set; }
            public double Max_Outpatient { get; set; }

            // Min values (30+ columns)
            public double Min_EmployedProductiveFtes { get; set; }
            public double Min_ContractLaborPercent { get; set; }
            public double Min_ContractFtes { get; set; }
            public double Min_TotalProductiveFtes { get; set; }
            public double Min_NonProductivePercent { get; set; }
            public double Min_NonProductiveFtes { get; set; }
            public double Min_EmployedPaidFtes { get; set; }
            public double Min_TotalFtes { get; set; }
            public double Min_TotalSalariesAndWages { get; set; }
            public double Min_TotalContractLaborDollars { get; set; }
            public double Min_TotalLaborExpense { get; set; }
            public double Min_EmployedLaborRate { get; set; }
            public double Min_ContractLaborRate { get; set; }
            public double Min_OverTimePremiumDollars { get; set; }
            public double Min_OtPercent { get; set; }
            public double Min_OtFte { get; set; }
            public double Min_Admissions { get; set; }
            public double Min_AAdmissions { get; set; }
            public double Min_PatientDays { get; set; }
            public double Min_APatientDays { get; set; }
            public double Min_ERVisits { get; set; }
            public double Min_Outpatient { get; set; }
            public double Min_Eeob { get; set; }
            public double Min_MhAa { get; set; }
            public double Min_SemiVariableFtes { get; set; }
            public double Min_VariableProdHrsPerUOS { get; set; }
            public double Min_TotalProdHrsPerUOS { get; set; }
            public double Min_MinFTE { get; set; }

            // Total columns
            public double EmployedProductiveFtesTotal { get; set; }
            public double ContractPercentTotal { get; set; }
            public double ContractFtesTotal { get; set; }
            public double TotalProductiveFtesTotal { get; set; }
            public double NonProductivePercentTotal { get; set; }
            public double NonProductiveFtesTotal { get; set; }
            public double EmployedPaidFtesTotal { get; set; }
            public double TotalFtesTotal { get; set; }
            public double TotalSalariesAndWagesTotal { get; set; }
            public double TotalContractLaborDollarsTotal { get; set; }
            public double TotalLaborExpenseTotal { get; set; }
            public double EmployedLaborRateTotal { get; set; }
            public double ContractLaborRateTotal { get; set; }
            public double OverTimePremiumDollarsTotal { get; set; }
            public double OtPercentTotal { get; set; }
            public double OTFTEsTotal { get; set; }
            public double EeobTotal { get; set; }
            public double MhAaTotal { get; set; }
            public double DeptUOSTotal { get; set; }
            public double SemiVariableProductiveFtesTotal { get; set; }
            public double VariableHoursPerUosTotal { get; set; }
            public double TotalProdHrsUOSTotal { get; set; }
            public double MinFtesTotal { get; set; }
        }

        private static SqlMonthlyRow ReadSingleRow(SqlDataReader reader)
        {
            return new SqlMonthlyRow
            {
                IndexId = GetInt(reader, "IndexId"),
                WftPlan_ID = GetLong(reader, "WftPlan_ID"),
                Year = GetInt(reader, "Year"),
                MonthNum = GetInt(reader, "MonthNum"),
                MonthName = GetString(reader, "MonthName"),
                CoId = GetInt(reader, "CoId"),
                FacilityDescription = GetString(reader, "FacilityDescription"),

                DaysInMonth = GetDouble(reader, "DaysInMonth"),
                EmployedProductiveFtes = GetDouble(reader, "EmployedProductiveFtes"),
                ContractPercent = GetDouble(reader, "ContractPercent"),
                ContractFTEs = GetDouble(reader, "ContractFTEs"),
                TotalProductiveFtes = GetDouble(reader, "TotalProductiveFtes"),
                NonProductivePercent = GetDouble(reader, "NonProductivePercent"),
                NonProductiveFtes = GetDouble(reader, "NonProductiveFtes"),
                EmployedPaidFtes = GetDouble(reader, "EmployedPaidFtes"),
                TotalFtes = GetDouble(reader, "TotalFtes"),
                TotalSalariesAndWages = GetDouble(reader, "TotalSalariesAndWages"),
                TotalContractLaborDollars = GetDouble(reader, "TotalContractLaborDollars"),
                TotalLaborExpense = GetDouble(reader, "TotalLaborExpense"),
                EmployedLaborRate = GetDouble(reader, "EmployedLaborRate"),
                ContractLaborRate = GetDouble(reader, "ContractLaborRate"),
                OverTimePremiumDollars = GetDouble(reader, "OverTimePremiumDollars"),
                OtPercent = GetDouble(reader, "OtPercent"),
                OTFTEs = GetDouble(reader, "OTFTEs"),
                Eeob = GetDouble(reader, "Eeob"),
                MhAa = GetDouble(reader, "MhAa"),
                Admissions = GetDouble(reader, "Admissions"),
                AAdmissions = GetDouble(reader, "AAdmissions"),
                PatientDays = GetDouble(reader, "PatientDays"),
                APatientDays = GetDouble(reader, "APatientDays"),
                ERVisits = GetDouble(reader, "ERVisits"),
                Outpatient = GetDouble(reader, "Outpatient"),
                DeptUOS = GetDouble(reader, "DeptUOS"),
                SemiVariableProductiveFtes = GetDouble(reader, "SemiVariableProductiveFtes"),
                TotalProdHrsUOS = GetDouble(reader, "TotalProdHrsUOS"),
                VariableProdHrsUOS = GetDouble(reader, "VariableProdHrsUOS"),
                ProductiveMinFtes = GetDouble(reader, "ProductiveMinFtes"),

                Max_EmployedProductiveFtes = GetDouble(reader, "Max_EmployedProductiveFtes"),
                Max_ContractLaborPercent = GetDouble(reader, "Max_ContractLaborPercent"),
                Max_ContractFtes = GetDouble(reader, "Max_ContractFtes"),
                Max_TotalProductiveFtes = GetDouble(reader, "Max_TotalProductiveFtes"),
                Max_NonProductivePercent = GetDouble(reader, "Max_NonProductivePercent"),
                Max_NonProductiveFtes = GetDouble(reader, "Max_NonProductiveFtes"),
                Max_EmployedPaidFtes = GetDouble(reader, "Max_EmployedPaidFtes"),
                Max_TotalFtes = GetDouble(reader, "Max_TotalFtes"),
                Max_TotalSalariesAndWages = GetDouble(reader, "Max_TotalSalariesAndWages"),
                Max_TotalContractLaborDollars = GetDouble(reader, "Max_TotalContractLaborDollars"),
                Max_TotalLaborExpense = GetDouble(reader, "Max_TotalLaborExpense"),
                Max_EmployedLaborRate = GetDouble(reader, "Max_EmployedLaborRate"),
                Max_ContractLaborRate = GetDouble(reader, "Max_ContractLaborRate"),
                Max_OverTimePremiumDollars = GetDouble(reader, "Max_OverTimePremiumDollars"),
                Max_OtPercent = GetDouble(reader, "Max_OtPercent"),
                Max_OtFte = GetDouble(reader, "Max_OtFte"),
                Max_Eeob = GetDouble(reader, "Max_Eeob"),
                Max_MhAa = GetDouble(reader, "Max_MhAa"),
                Max_SemiVariableFtes = GetDouble(reader, "Max_SemiVariableFtes"),
                Max_VariableProdHrsPerUOS = GetDouble(reader, "Max_VariableProdHrsPerUOS"),
                Max_TotalProdHrsPerUOS = GetDouble(reader, "Max_TotalProdHrsPerUOS"),
                Max_MinFTE = GetDouble(reader, "Max_MinFTE"),
                Max_Admissions = GetDouble(reader, "Max_Admissions"),
                Max_AAdmissions = GetDouble(reader, "Max_AAdmissions"),
                Max_PatientDays = GetDouble(reader, "Max_PatientDays"),
                Max_APatientDays = GetDouble(reader, "Max_APatientDays"),
                Max_ERVisits = GetDouble(reader, "Max_ERVisits"),
                Max_Outpatient = GetDouble(reader, "Max_Outpatient"),

                Min_EmployedProductiveFtes = GetDouble(reader, "Min_EmployedProductiveFtes"),
                Min_ContractLaborPercent = GetDouble(reader, "Min_ContractLaborPercent"),
                Min_ContractFtes = GetDouble(reader, "Min_ContractFtes"),
                Min_TotalProductiveFtes = GetDouble(reader, "Min_TotalProductiveFtes"),
                Min_NonProductivePercent = GetDouble(reader, "Min_NonProductivePercent"),
                Min_NonProductiveFtes = GetDouble(reader, "Min_NonProductiveFtes"),
                Min_EmployedPaidFtes = GetDouble(reader, "Min_EmployedPaidFtes"),
                Min_TotalFtes = GetDouble(reader, "Min_TotalFtes"),
                Min_TotalSalariesAndWages = GetDouble(reader, "Min_TotalSalariesAndWages"),
                Min_TotalContractLaborDollars = GetDouble(reader, "Min_TotalContractLaborDollars"),
                Min_TotalLaborExpense = GetDouble(reader, "Min_TotalLaborExpense"),
                Min_EmployedLaborRate = GetDouble(reader, "Min_EmployedLaborRate"),
                Min_ContractLaborRate = GetDouble(reader, "Min_ContractLaborRate"),
                Min_OverTimePremiumDollars = GetDouble(reader, "Min_OverTimePremiumDollars"),
                Min_OtPercent = GetDouble(reader, "Min_OtPercent"),
                Min_OtFte = GetDouble(reader, "Min_OtFte"),
                Min_Admissions = GetDouble(reader, "Min_Admissions"),
                Min_AAdmissions = GetDouble(reader, "Min_AAdmissions"),
                Min_PatientDays = GetDouble(reader, "Min_PatientDays"),
                Min_APatientDays = GetDouble(reader, "Min_APatientDays"),
                Min_ERVisits = GetDouble(reader, "Min_ERVisits"),
                Min_Outpatient = GetDouble(reader, "Min_Outpatient"),
                Min_Eeob = GetDouble(reader, "Min_Eeob"),
                Min_MhAa = GetDouble(reader, "Min_MhAa"),
                Min_SemiVariableFtes = GetDouble(reader, "Min_SemiVariableFtes"),
                Min_VariableProdHrsPerUOS = GetDouble(reader, "Min_VariableProdHrsPerUOS"),
                Min_TotalProdHrsPerUOS = GetDouble(reader, "Min_TotalProdHrsPerUOS"),
                Min_MinFTE = GetDouble(reader, "Min_MinFTE"),

                EmployedProductiveFtesTotal = GetDouble(reader, "EmployedProductiveFtesTotal"),
                ContractPercentTotal = GetDouble(reader, "ContractPercentTotal"),
                ContractFtesTotal = GetDouble(reader, "ContractFtesTotal"),
                TotalProductiveFtesTotal = GetDouble(reader, "TotalProductiveFtesTotal"),
                NonProductivePercentTotal = GetDouble(reader, "NonProductivePercentTotal"),
                NonProductiveFtesTotal = GetDouble(reader, "NonProductiveFtesTotal"),
                EmployedPaidFtesTotal = GetDouble(reader, "EmployedPaidFtesTotal"),
                TotalFtesTotal = GetDouble(reader, "TotalFtesTotal"),
                TotalSalariesAndWagesTotal = GetDouble(reader, "TotalSalariesAndWagesTotal"),
                TotalContractLaborDollarsTotal = GetDouble(reader, "TotalContractLaborDollarsTotal"),
                TotalLaborExpenseTotal = GetDouble(reader, "TotalLaborExpenseTotal"),
                EmployedLaborRateTotal = GetDouble(reader, "EmployedLaborRateTotal"),
                ContractLaborRateTotal = GetDouble(reader, "ContractLaborRateTotal"),
                OverTimePremiumDollarsTotal = GetDouble(reader, "OverTimePremiumDollarsTotal"),
                OtPercentTotal = GetDouble(reader, "OtPercentTotal"),
                OTFTEsTotal = GetDouble(reader, "OTFTEsTotal"),
                EeobTotal = GetDouble(reader, "EeobTotal"),
                MhAaTotal = GetDouble(reader, "MhAaTotal"),
                DeptUOSTotal = GetDouble(reader, "DeptUOSTotal"),
                SemiVariableProductiveFtesTotal = GetDouble(reader, "SemiVariableProductiveFtesTotal"),
                VariableHoursPerUosTotal = GetDouble(reader, "VariableHoursPerUosTotal"),
                TotalProdHrsUOSTotal = GetDouble(reader, "TotalProdHrsUOSTotal"),
                MinFtesTotal = GetDouble(reader, "MinFtesTotal")
            };
        }

        private static PlanData PivotToPlanData(List<SqlMonthlyRow> rows)
        {
            if (rows.Count == 0) return null;

            var plan = new PlanData();
            var firstRow = rows.First();

            // Set identifiers
            plan.IndexId = firstRow.IndexId;
            plan.WftPlan_ID = firstRow.WftPlan_ID;
            plan.Year = firstRow.Year;
            plan.CoId = firstRow.CoId;
            plan.FacilityDescription = firstRow.FacilityDescription;

            // Pivot monthly data
            foreach (var row in rows)
            {
                SetMonthValue(plan.DaysInMonth, row.MonthNum, row.DaysInMonth);
                SetMonthValue(plan.EmployedProductiveFtes, row.MonthNum, row.EmployedProductiveFtes);
                SetMonthValue(plan.ContractPercent, row.MonthNum, row.ContractPercent);
                SetMonthValue(plan.ContractFTEs, row.MonthNum, row.ContractFTEs);
                SetMonthValue(plan.TotalProductiveFtes, row.MonthNum, row.TotalProductiveFtes);
                SetMonthValue(plan.NonProductivePercent, row.MonthNum, row.NonProductivePercent);
                SetMonthValue(plan.NonProductiveFtes, row.MonthNum, row.NonProductiveFtes);
                SetMonthValue(plan.EmployedPaidFtes, row.MonthNum, row.EmployedPaidFtes);
                SetMonthValue(plan.TotalFtes, row.MonthNum, row.TotalFtes);
                SetMonthValue(plan.TotalSalariesAndWages, row.MonthNum, row.TotalSalariesAndWages);
                SetMonthValue(plan.TotalContractLaborDollars, row.MonthNum, row.TotalContractLaborDollars);
                SetMonthValue(plan.TotalLaborExpense, row.MonthNum, row.TotalLaborExpense);
                SetMonthValue(plan.EmployedLaborRate, row.MonthNum, row.EmployedLaborRate);
                SetMonthValue(plan.ContractLaborRate, row.MonthNum, row.ContractLaborRate);
                SetMonthValue(plan.OverTimePremiumDollars, row.MonthNum, row.OverTimePremiumDollars);
                SetMonthValue(plan.OtPercent, row.MonthNum, row.OtPercent);
                SetMonthValue(plan.OTFTEs, row.MonthNum, row.OTFTEs);
                SetMonthValue(plan.Eeob, row.MonthNum, row.Eeob);
                SetMonthValue(plan.MhAa, row.MonthNum, row.MhAa);
                SetMonthValue(plan.Admissions, row.MonthNum, row.Admissions);
                SetMonthValue(plan.AAdmissions, row.MonthNum, row.AAdmissions);
                SetMonthValue(plan.PatientDays, row.MonthNum, row.PatientDays);
                SetMonthValue(plan.APatientDays, row.MonthNum, row.APatientDays);
                SetMonthValue(plan.ERVisits, row.MonthNum, row.ERVisits);
                SetMonthValue(plan.Outpatient, row.MonthNum, row.Outpatient);
                SetMonthValue(plan.DeptUOS, row.MonthNum, row.DeptUOS);
                SetMonthValue(plan.SemiVariableProductiveFtes, row.MonthNum, row.SemiVariableProductiveFtes);
                SetMonthValue(plan.TotalProdHrsUOS, row.MonthNum, row.TotalProdHrsUOS);
                SetMonthValue(plan.VariableProdHrsUOS, row.MonthNum, row.VariableProdHrsUOS);
                SetMonthValue(plan.ProductiveMinFtes, row.MonthNum, row.ProductiveMinFtes);

                // Max values (abbreviated for space - add all 30+)
                SetMonthValue(plan.Max_EmployedProductiveFtes, row.MonthNum, row.Max_EmployedProductiveFtes);
                SetMonthValue(plan.Max_ContractLaborPercent, row.MonthNum, row.Max_ContractLaborPercent);
                SetMonthValue(plan.Max_TotalProductiveFtes, row.MonthNum, row.Max_TotalProductiveFtes);
                SetMonthValue(plan.Max_TotalLaborExpense, row.MonthNum, row.Max_TotalLaborExpense);
                // ... (add remaining Max_ columns)

                // Min values (abbreviated for space - add all 30+)
                SetMonthValue(plan.Min_EmployedProductiveFtes, row.MonthNum, row.Min_EmployedProductiveFtes);
                SetMonthValue(plan.Min_ContractLaborPercent, row.MonthNum, row.Min_ContractLaborPercent);
                SetMonthValue(plan.Min_TotalProductiveFtes, row.MonthNum, row.Min_TotalProductiveFtes);
                SetMonthValue(plan.Min_TotalLaborExpense, row.MonthNum, row.Min_TotalLaborExpense);
                // ... (add remaining Min_ columns)
            }

            // Set Total values from last row
            var lastRow = rows.Last();
            plan.EmployedProductiveFtes.Total = lastRow.EmployedProductiveFtesTotal;
            plan.ContractPercent.Total = lastRow.ContractPercentTotal;
            plan.ContractFTEs.Total = lastRow.ContractFtesTotal;
            plan.TotalProductiveFtes.Total = lastRow.TotalProductiveFtesTotal;
            plan.TotalLaborExpense.Total = lastRow.TotalLaborExpenseTotal;
            plan.DeptUOS.Total = lastRow.DeptUOSTotal;
            // ... (add remaining totals)

            return plan;
        }

        private static void SetMonthValue(MonthlyData monthlyData, int monthNum, double value)
        {
            switch (monthNum)
            {
                case 1: monthlyData.Jan = value; break;
                case 2: monthlyData.Feb = value; break;
                case 3: monthlyData.Mar = value; break;
                case 4: monthlyData.Apr = value; break;
                case 5: monthlyData.May = value; break;
                case 6: monthlyData.Jun = value; break;
                case 7: monthlyData.Jul = value; break;
                case 8: monthlyData.Aug = value; break;
                case 9: monthlyData.Sep = value; break;
                case 10: monthlyData.Oct = value; break;
                case 11: monthlyData.Nov = value; break;
                case 12: monthlyData.Dec = value; break;
            }
        }

        private static int GetInt(SqlDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                return reader.IsDBNull(ordinal) ? 0 : reader.GetInt32(ordinal);
            }
            catch
            {
                return 0;
            }
        }

        private static long GetLong(SqlDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                return reader.IsDBNull(ordinal) ? 0 : reader.GetInt64(ordinal);
            }
            catch
            {
                return 0;
            }
        }

        private static double GetDouble(SqlDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                if (reader.IsDBNull(ordinal)) return 0.0;

                var value = reader.GetValue(ordinal);
                double result = 0.0;

                if (value is double d)
                    result = d;
                else if (value is decimal dec)
                    result = (double)dec;
                else if (value is float f)
                    result = (double)f;
                else if (value is int i)
                    result = (double)i;
                else
                    result = Convert.ToDouble(value);

                return Math.Round(result, 2); // Round to 2 decimal places
            }
            catch
            {
                return 0.0;
            }
        }

        private static string GetString(SqlDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                return reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}