﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using ExcelDataReader;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Main parser that opens the Excel file once and parses all three sections.
    /// </summary>
    public class MonthlyDeptDetailExcelParser
    {
        /// <summary>
        /// Parses all three sections from the Monthly Department Detail Comparison Report.
        /// Opens the Excel file once and passes the DataTable to each section parser.
        /// </summary>
        public static (MonthlyDepartmentFTESummary FTESummary,
                        MonthlyDepartmentLaborExpenseSummary LaborExpenseSummary,
                        MonthlyDepartmentVolumeSummary VolumeSummary)
            ParseAll(string filePath)
        {
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                var dataSet = reader.AsDataSet();
                var sheet = dataSet.Tables[0];

                var fteSummary = DepartmentFTESummaryParser.Parse(sheet);
                var laborExpenseSummary = DepartmentLaborExpenseSummaryParser.Parse(sheet);
                var volumeSummary = DepartmentVolumeSummaryParser.Parse(sheet);

                return (fteSummary, laborExpenseSummary, volumeSummary);
            }
        }
    }
    /// <summary>
    /// Represents a single metric row with Description + 12 monthly values + Total.
    /// Used for both P1 and P2 plan data across all sections.
    /// </summary>
    public class MonthlyMetricRow
    {
        public string Description { get; set; }
        public double Jan { get; set; }
        public double Feb { get; set; }
        public double Mar { get; set; }
        public double Apr { get; set; }
        public double May { get; set; }
        public double Jun { get; set; }
        public double Jul { get; set; }
        public double Aug { get; set; }
        public double Sep { get; set; }
        public double Oct { get; set; }
        public double Nov { get; set; }
        public double Dec { get; set; }
        public double Total { get; set; }
    }

    #region Shared Parser Helpers

    /// <summary>
    /// Shared helper methods for extracting row data from the Excel sheet.
    /// Because columns are scattered (with hidden columns in between), the parser
    /// iterates through each cell in the row and collects only non-empty values.
    /// Each data row consistently has exactly 14 non-empty cells:
    ///   [0] = Description (e.g., "P1 - Employed (Productive) FTEs")
    ///   [1]-[12] = Jan through Dec values
    ///   [13] = Total
    /// 
    /// Section positions are detected dynamically by searching for section header text,
    /// then scanning forward for consecutive rows starting with "P1 - " or "P2 - ".
    /// This handles Excel files where row positions shift across different facilities.
    /// </summary>
    public class ExcelRowExtractor
    {
        /// <summary>
        /// Iterates through each cell in the given row and collects non-empty values.
        /// Expects exactly 14 non-empty cells: Description + 12 months + Total.
        /// </summary>
        public static MonthlyMetricRow ExtractRowValues(DataTable sheet, int rowIdx)
        {
            var row = sheet.Rows[rowIdx];
            var nonEmptyValues = new List<string>();

            for (int colIdx = 0; colIdx < sheet.Columns.Count; colIdx++)
            {
                var cellValue = row[colIdx];

                if (cellValue == null || cellValue == DBNull.Value)
                    continue;

                string strValue = cellValue.ToString().Trim();

                if (string.IsNullOrEmpty(strValue))
                    continue;

                nonEmptyValues.Add(strValue);
            }

            // We expect exactly 14 non-empty values per row
            if (nonEmptyValues.Count < 14)
                return null;

            return new MonthlyMetricRow
            {
                Description = nonEmptyValues[0],
                Jan = ParseAndRound(nonEmptyValues[1]),
                Feb = ParseAndRound(nonEmptyValues[2]),
                Mar = ParseAndRound(nonEmptyValues[3]),
                Apr = ParseAndRound(nonEmptyValues[4]),
                May = ParseAndRound(nonEmptyValues[5]),
                Jun = ParseAndRound(nonEmptyValues[6]),
                Jul = ParseAndRound(nonEmptyValues[7]),
                Aug = ParseAndRound(nonEmptyValues[8]),
                Sep = ParseAndRound(nonEmptyValues[9]),
                Oct = ParseAndRound(nonEmptyValues[10]),
                Nov = ParseAndRound(nonEmptyValues[11]),
                Dec = ParseAndRound(nonEmptyValues[12]),
                Total = ParseAndRound(nonEmptyValues[13])
            };
        }

        /// <summary>
        /// Finds the section header row by searching for the exact text in any cell.
        /// Returns the 0-indexed row number, or -1 if not found.
        /// </summary>
        public static int FindSectionHeaderRow(DataTable sheet, string sectionHeaderText)
        {
            for (int rowIdx = 0; rowIdx < sheet.Rows.Count; rowIdx++)
            {
                var row = sheet.Rows[rowIdx];
                for (int colIdx = 0; colIdx < sheet.Columns.Count; colIdx++)
                {
                    var cellValue = row[colIdx];
                    if (cellValue == null || cellValue == DBNull.Value)
                        continue;

                    string strValue = cellValue.ToString().Trim();
                    if (strValue.Equals(sectionHeaderText, StringComparison.OrdinalIgnoreCase))
                        return rowIdx;
                }
            }
            return -1;
        }

        /// <summary>
        /// Starting from a section header row, scans forward to find the first row
        /// that starts with "P1 - " or "P2 - ", then collects all consecutive
        /// P1/P2 data rows.
        /// </summary>
        public static List<MonthlyMetricRow> ExtractSectionRows(DataTable sheet, string sectionHeaderText)
        {
            int headerRow = FindSectionHeaderRow(sheet, sectionHeaderText);
            if (headerRow < 0)
                throw new InvalidOperationException(
                    $"Section header '{sectionHeaderText}' not found in the Excel sheet.");

            // Scan forward from the header to find the first P1/P2 data row
            int firstDataRow = -1;
            for (int rowIdx = headerRow + 1; rowIdx < sheet.Rows.Count; rowIdx++)
            {
                if (IsP1OrP2Row(sheet, rowIdx))
                {
                    firstDataRow = rowIdx;
                    break;
                }
            }

            if (firstDataRow < 0)
                throw new InvalidOperationException(
                    $"No P1/P2 data rows found after section header '{sectionHeaderText}'.");

            // Collect all consecutive P1/P2 data rows
            var extractedRows = new List<MonthlyMetricRow>();
            for (int rowIdx = firstDataRow; rowIdx < sheet.Rows.Count; rowIdx++)
            {
                if (!IsP1OrP2Row(sheet, rowIdx))
                    break;

                var metricRow = ExtractRowValues(sheet, rowIdx);
                if (metricRow != null)
                {
                    extractedRows.Add(metricRow);
                }
            }

            return extractedRows;
        }

        /// <summary>
        /// Checks if any cell in the given row starts with "P1 - " or "P2 - ".
        /// </summary>
        private static bool IsP1OrP2Row(DataTable sheet, int rowIdx)
        {
            var row = sheet.Rows[rowIdx];
            for (int colIdx = 0; colIdx < sheet.Columns.Count; colIdx++)
            {
                var cellValue = row[colIdx];
                if (cellValue == null || cellValue == DBNull.Value)
                    continue;

                string strValue = cellValue.ToString().Trim();
                if (strValue.StartsWith("P1 - ") || strValue.StartsWith("P2 - "))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Parses a string value to double and rounds to 2 decimal places.
        /// Returns 0.0 if parsing fails.
        /// </summary>
        public static double ParseAndRound(string value)
        {
            if (double.TryParse(value, out double result))
            {
                return Math.Round(result, 2);
            }
            return 0.0;
        }
    }

    #endregion

    #region Section 1: Department FTE Summary

    /// <summary>
    /// Department FTE Summary section.
    /// Dynamically located by searching for the "Department FTE Summary" header.
    /// Each property has a P1 and P2 row (two separate plans).
    /// 
    /// Properties (8 metrics x P1/P2 = 16 rows):
    ///   Employed (Productive) FTEs
    ///   Contract Labor %
    ///   Contract FTEs
    ///   Total Productive FTEs
    ///   Non-Productive %
    ///   Non-Productive FTEs
    ///   Employed (paid) FTEs
    ///   Total FTEs (Paid + Contract)
    /// </summary>
    public class MonthlyDepartmentFTESummary
    {
        public MonthlyMetricRow P1_EmployedProductiveFTEs { get; set; }
        public MonthlyMetricRow P2_EmployedProductiveFTEs { get; set; }

        public MonthlyMetricRow P1_ContractLaborPercent { get; set; }
        public MonthlyMetricRow P2_ContractLaborPercent { get; set; }

        public MonthlyMetricRow P1_ContractFTEs { get; set; }
        public MonthlyMetricRow P2_ContractFTEs { get; set; }

        public MonthlyMetricRow P1_TotalProductiveFTEs { get; set; }
        public MonthlyMetricRow P2_TotalProductiveFTEs { get; set; }

        public MonthlyMetricRow P1_NonProductivePercent { get; set; }
        public MonthlyMetricRow P2_NonProductivePercent { get; set; }

        public MonthlyMetricRow P1_NonProductiveFTEs { get; set; }
        public MonthlyMetricRow P2_NonProductiveFTEs { get; set; }

        public MonthlyMetricRow P1_EmployedPaidFTEs { get; set; }
        public MonthlyMetricRow P2_EmployedPaidFTEs { get; set; }

        public MonthlyMetricRow P1_TotalFTEsPaidPlusContract { get; set; }
        public MonthlyMetricRow P2_TotalFTEsPaidPlusContract { get; set; }
    }

    /// <summary>
    /// Parses the Department FTE Summary section.
    /// Dynamically finds the section by searching for the "Department FTE Summary" header,
    /// then reads all consecutive P1/P2 data rows.
    /// </summary>
    public class DepartmentFTESummaryParser
    {
        private const string SectionHeader = "Department FTE Summary";

        public static MonthlyDepartmentFTESummary Parse(DataTable sheet)
        {
            var rows = ExcelRowExtractor.ExtractSectionRows(sheet, SectionHeader);
            return MapToModel(rows);
        }

        private static MonthlyDepartmentFTESummary MapToModel(List<MonthlyMetricRow> rows)
        {
            return new MonthlyDepartmentFTESummary
            {
                P1_EmployedProductiveFTEs = rows[0],
                P2_EmployedProductiveFTEs = rows[1],

                P1_ContractLaborPercent = rows[2],
                P2_ContractLaborPercent = rows[3],

                P1_ContractFTEs = rows[4],
                P2_ContractFTEs = rows[5],

                P1_TotalProductiveFTEs = rows[6],
                P2_TotalProductiveFTEs = rows[7],

                P1_NonProductivePercent = rows[8],
                P2_NonProductivePercent = rows[9],

                P1_NonProductiveFTEs = rows[10],
                P2_NonProductiveFTEs = rows[11],

                P1_EmployedPaidFTEs = rows[12],
                P2_EmployedPaidFTEs = rows[13],

                P1_TotalFTEsPaidPlusContract = rows[14],
                P2_TotalFTEsPaidPlusContract = rows[15]
            };
        }
    }

    #endregion

    #region Section 2: Department Labor Expense Summary

    /// <summary>
    /// Department Labor Expense Summary section.
    /// Dynamically located by searching for the "Department Labor Expense Summary" header.
    /// Each property has a P1 and P2 row (two separate plans).
    /// 
    /// Properties (8 metrics x P1/P2 = 16 rows):
    ///   Total Salaries and Wages ($000)
    ///   Total Contract Labor ($000)
    ///   Total Labor Expense ($000)
    ///   Employed Labor Rate
    ///   Contract Labor Rate
    ///   Overtime Premium Dollars
    ///   Overtime %
    ///   Overtime FTEs
    /// </summary>
    public class MonthlyDepartmentLaborExpenseSummary
    {
        public MonthlyMetricRow P1_TotalSalariesAndWages { get; set; }
        public MonthlyMetricRow P2_TotalSalariesAndWages { get; set; }

        public MonthlyMetricRow P1_TotalContractLabor { get; set; }
        public MonthlyMetricRow P2_TotalContractLabor { get; set; }

        public MonthlyMetricRow P1_TotalLaborExpense { get; set; }
        public MonthlyMetricRow P2_TotalLaborExpense { get; set; }

        public MonthlyMetricRow P1_EmployedLaborRate { get; set; }
        public MonthlyMetricRow P2_EmployedLaborRate { get; set; }

        public MonthlyMetricRow P1_ContractLaborRate { get; set; }
        public MonthlyMetricRow P2_ContractLaborRate { get; set; }

        public MonthlyMetricRow P1_OvertimePremiumDollars { get; set; }
        public MonthlyMetricRow P2_OvertimePremiumDollars { get; set; }

        public MonthlyMetricRow P1_OvertimePercent { get; set; }
        public MonthlyMetricRow P2_OvertimePercent { get; set; }

        public MonthlyMetricRow P1_OvertimeFTEs { get; set; }
        public MonthlyMetricRow P2_OvertimeFTEs { get; set; }
    }

    /// <summary>
    /// Parses the Department Labor Expense Summary section.
    /// Dynamically finds the section by searching for the "Department Labor Expense Summary" header,
    /// then reads all consecutive P1/P2 data rows.
    /// </summary>
    public class DepartmentLaborExpenseSummaryParser
    {
        private const string SectionHeader = "Department Labor Expense Summary";

        public static MonthlyDepartmentLaborExpenseSummary Parse(DataTable sheet)
        {
            var rows = ExcelRowExtractor.ExtractSectionRows(sheet, SectionHeader);
            return MapToModel(rows);
        }

        private static MonthlyDepartmentLaborExpenseSummary MapToModel(List<MonthlyMetricRow> rows)
        {
            return new MonthlyDepartmentLaborExpenseSummary
            {
                P1_TotalSalariesAndWages = rows[0],
                P2_TotalSalariesAndWages = rows[1],

                P1_TotalContractLabor = rows[2],
                P2_TotalContractLabor = rows[3],

                P1_TotalLaborExpense = rows[4],
                P2_TotalLaborExpense = rows[5],

                P1_EmployedLaborRate = rows[6],
                P2_EmployedLaborRate = rows[7],

                P1_ContractLaborRate = rows[8],
                P2_ContractLaborRate = rows[9],

                P1_OvertimePremiumDollars = rows[10],
                P2_OvertimePremiumDollars = rows[11],

                P1_OvertimePercent = rows[12],
                P2_OvertimePercent = rows[13],

                P1_OvertimeFTEs = rows[14],
                P2_OvertimeFTEs = rows[15]
            };
        }
    }

    #endregion

    #region Section 3: Department Volume Summary

    /// <summary>
    /// Department Volume Summary section.
    /// Dynamically located by searching for the "Department Volume Summary" header.
    /// Each property has a P1 and P2 row (two separate plans).
    /// 
    /// Properties (5 metrics x P1/P2 = 10 rows):
    ///   Department UOS
    ///   Semi-Variable FTEs
    ///   Variable Productive Hrs/UOS
    ///   Min FTE
    ///   Total Productive Hrs/UOS
    /// </summary>
    public class MonthlyDepartmentVolumeSummary
    {
        public MonthlyMetricRow P1_DepartmentUOS { get; set; }
        public MonthlyMetricRow P2_DepartmentUOS { get; set; }

        public MonthlyMetricRow P1_SemiVariableFTEs { get; set; }
        public MonthlyMetricRow P2_SemiVariableFTEs { get; set; }

        public MonthlyMetricRow P1_VariableProductiveHrsPerUOS { get; set; }
        public MonthlyMetricRow P2_VariableProductiveHrsPerUOS { get; set; }

        public MonthlyMetricRow P1_MinFTE { get; set; }
        public MonthlyMetricRow P2_MinFTE { get; set; }

        public MonthlyMetricRow P1_TotalProductiveHrsPerUOS { get; set; }
        public MonthlyMetricRow P2_TotalProductiveHrsPerUOS { get; set; }
    }

    /// <summary>
    /// Parses the Department Volume Summary section.
    /// Dynamically finds the section by searching for the "Department Volume Summary" header,
    /// then reads all consecutive P1/P2 data rows.
    /// </summary>
    public class DepartmentVolumeSummaryParser
    {
        private const string SectionHeader = "Department Volume Summary";

        public static MonthlyDepartmentVolumeSummary Parse(DataTable sheet)
        {
            var rows = ExcelRowExtractor.ExtractSectionRows(sheet, SectionHeader);
            return MapToModel(rows);
        }

        private static MonthlyDepartmentVolumeSummary MapToModel(List<MonthlyMetricRow> rows)
        {
            return new MonthlyDepartmentVolumeSummary
            {
                P1_DepartmentUOS = rows[0],
                P2_DepartmentUOS = rows[1],

                P1_SemiVariableFTEs = rows[2],
                P2_SemiVariableFTEs = rows[3],

                P1_VariableProductiveHrsPerUOS = rows[4],
                P2_VariableProductiveHrsPerUOS = rows[5],

                P1_MinFTE = rows[6],
                P2_MinFTE = rows[7],

                P1_TotalProductiveHrsPerUOS = rows[8],
                P2_TotalProductiveHrsPerUOS = rows[9]
            };
        }
    }

    #endregion

    
}