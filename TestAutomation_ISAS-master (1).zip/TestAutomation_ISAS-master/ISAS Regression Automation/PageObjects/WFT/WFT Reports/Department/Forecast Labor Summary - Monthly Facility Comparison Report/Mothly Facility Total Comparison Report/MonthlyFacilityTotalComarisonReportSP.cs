﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class MonthlyFacilityTotalComarisonReportSP
    {
        public static string getMonthlyFacilityTotalComparisonReportSP()
        {
            
            var sp = $"declare @PlanID BIGINT ={RunData.PlanID}" + Environment.NewLine +
                $"declare @PlanIDCompareTo BIGINT={RunData.PlanTwoID}" + Environment.NewLine +
                $"declare @DeptNumber INT={RunData.Deptartment}" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "IF EXISTS(	SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                "WHERE ID = OBJECT_ID(N'tempdb..#TempMonthlyValue') 	)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "DROP TABLE #TempMonthlyValue;" + Environment.NewLine +
                "END;" + Environment.NewLine +
                "IF EXISTS(	SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                "WHERE ID = OBJECT_ID(N'tempdb..#TempAllValue') 	)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "DROP TABLE #TempAllValue;" + Environment.NewLine +
                "END;" + Environment.NewLine +
                "IF EXISTS(	SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                "WHERE ID = OBJECT_ID(N'tempdb..#TempFacStatValue') 	)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "DROP TABLE #TempFacStatValue;" + Environment.NewLine +
                "END;" + Environment.NewLine +
                "IF EXISTS(	SELECT * FROM tempdb.dbo.sysobjects" + Environment.NewLine +
                "WHERE ID = OBJECT_ID(N'tempdb..#TempMaxMinValues') 	)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "DROP TABLE #TempMaxMinValues;" + Environment.NewLine +
                "END;" + Environment.NewLine +
                "------------------For department ----------------------------" + Environment.NewLine +
                "Declare @StDept INT" + Environment.NewLine +
                "DECLARE @EndDept INT" + Environment.NewLine +
                "--DECLARE @CoId BIGINT" + Environment.NewLine +
                "IF (@DeptNumber is null OR @DeptNumber <= 0)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "SET @StDept=1" + Environment.NewLine +
                "SET @EndDept=999" + Environment.NewLine +
                "END" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "SET @StDept=@DeptNumber" + Environment.NewLine +
                "SET @EndDept=@DeptNumber" + Environment.NewLine +
                "END" + Environment.NewLine +
                "-------End Department--------" + Environment.NewLine +
                "-- Variable to store Second Hightest and Second Lowest value" + Environment.NewLine +
                "declare @Max_EmployedProductiveFtes decimal(19,5)," + Environment.NewLine +
                "@Max_ContractLaborPercent decimal(19,5)," + Environment.NewLine +
                "@Max_ContractFtes decimal(19,5)," + Environment.NewLine +
                "@Max_TotalProductiveFtes decimal(19,5)," + Environment.NewLine +
                "@Max_NonProductivePercent decimal(19,5)," + Environment.NewLine +
                "@Max_NonProductiveFtes decimal(19,5)," + Environment.NewLine +
                "@Max_EmployedPaidFtes decimal(19,5)," + Environment.NewLine +
                "@Max_TotalFtes decimal(19,5)," + Environment.NewLine +
                "@Max_TotalSalariesAndWages decimal(19,5)," + Environment.NewLine +
                "@Max_TotalContractLaborDollars decimal(19,5)," + Environment.NewLine +
                "@Max_TotalLaborExpense decimal(19,5)," + Environment.NewLine +
                "@Max_EmployedLaborRate decimal(19,5)," + Environment.NewLine +
                "@Max_ContractLaborRate decimal(19,5)," + Environment.NewLine +
                "@Max_OverTimePremiumDollars decimal(19,5)," + Environment.NewLine +
                "@Max_OtPercent decimal(19,5)," + Environment.NewLine +
                "@Max_OtFte decimal(19,5)," + Environment.NewLine +
                "@Max_Eeob  decimal(19,5)," + Environment.NewLine +
                "@Max_MhAa decimal(19,5)" + Environment.NewLine +
                "declare @Max_SemiVariableFtes decimal(19,5)," + Environment.NewLine +
                "@Max_VariableProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                "@Max_TotalProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                "@Max_MinFTE decimal(19,5)" + Environment.NewLine +
                "declare @Min_EmployedProductiveFtes decimal(19,5)," + Environment.NewLine +
                "@Min_ContractLaborPercent decimal(19,5)," + Environment.NewLine +
                "@Min_ContractFtes decimal(19,5)," + Environment.NewLine +
                "@Min_TotalProductiveFtes decimal(19,5)," + Environment.NewLine +
                "@Min_NonProductivePercent decimal(19,5)," + Environment.NewLine +
                "@Min_NonProductiveFtes decimal(19,5)," + Environment.NewLine +
                "@Min_EmployedPaidFtes decimal(19,5)," + Environment.NewLine +
                "@Min_TotalFtes decimal(19,5)," + Environment.NewLine +
                "@Min_TotalSalariesAndWages decimal(19,5)," + Environment.NewLine +
                "@Min_TotalContractLaborDollars decimal(19,5)," + Environment.NewLine +
                "@Min_TotalLaborExpense decimal(19,5)," + Environment.NewLine +
                "@Min_EmployedLaborRate decimal(19,5)," + Environment.NewLine +
                "@Min_ContractLaborRate decimal(19,5)," + Environment.NewLine +
                "@Min_OverTimePremiumDollars decimal(19,5)," + Environment.NewLine +
                "@Min_OtPercent decimal(19,5)," + Environment.NewLine +
                "@Min_OtFte decimal(19,5)," + Environment.NewLine +
                "@Min_Eeob  decimal(19,5)," + Environment.NewLine +
                "@Min_MhAa decimal(19,5)" + Environment.NewLine +
                "declare @Min_SemiVariableFtes decimal(19,5)," + Environment.NewLine +
                "@Min_VariableProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                "@Min_TotalProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                "@Min_MinFTE decimal(19,5)" + Environment.NewLine +
                "declare @Max_Admissions decimal(19,5)," + Environment.NewLine +
                "@Max_AAdmissions decimal(19,5) ," + Environment.NewLine +
                "@Max_PatientDays decimal(19,5) ," + Environment.NewLine +
                "@Max_APatientDays decimal(19,5)," + Environment.NewLine +
                "@Max_ERVisits decimal(19,5) ," + Environment.NewLine +
                "@Max_Outpatient	 decimal(19,5)" + Environment.NewLine +
                "declare @Min_Admissions decimal(19,5)," + Environment.NewLine +
                "@Min_AAdmissions decimal(19,5) ," + Environment.NewLine +
                "@Min_PatientDays decimal(19,5) ," + Environment.NewLine +
                "@Min_APatientDays decimal(19,5)," + Environment.NewLine +
                "@Min_ERVisits decimal(19,5) ," + Environment.NewLine +
                "@Min_Outpatient	 decimal(19,5)" + Environment.NewLine +
                "CREATE TABLE #TempFacStatValue(" + Environment.NewLine +
                "TPlan_id BIGINT," + Environment.NewLine +
                "MonthNum INT NOT NULL," + Environment.NewLine +
                "Admissions decimal(19,5) not null default(0.0)," + Environment.NewLine +
                "AAdmissions decimal(19,5) not null default(0.0)," + Environment.NewLine +
                "PatientDays decimal(19,5) not null default(0.0)," + Environment.NewLine +
                "APatientDays decimal(19,5) not null default(0.0)," + Environment.NewLine +
                "ERVisits decimal(19,5) not null default(0.0)," + Environment.NewLine +
                "Outpatient	 decimal(19,5) not null default(0.0)" + Environment.NewLine +
                ")" + Environment.NewLine +
                "--SELECT * FROM @TempFacStatValue" + Environment.NewLine +
                "SELECT" + Environment.NewLine +
                "case pmv.WftPlan_ID when @PlanID then 1 When @PlanIDCompareTo Then 2 END as IndexId" + Environment.NewLine +
                ",P.[Year]" + Environment.NewLine +
                ",pmv.[Id] as PlanMonthlyValue_ID" + Environment.NewLine +
                ",pmv.[Month] as MonthNum" + Environment.NewLine +
                ",CONVERT(VARCHAR(3),DateName( month , DateAdd( Month , pmv.Month ,0)-1)) as 'MonthName'" + Environment.NewLine +
                ",DAY(dateadd(mm,datediff(mm,-1,(DATEADD(Month, MONTH(GETDATE()) - 12 + pmv.Month, GETDATE()))),-1))   as  'DaysInMonth'" + Environment.NewLine +
                ",pmv.[EmployedProductiveFtes] as [EmployedProductiveFtes]" + Environment.NewLine +
                ",pmv.[ContractLaborPercent] as 'ContractPercent'" + Environment.NewLine +
                ",pmv.[ContractFtes] as 'ContractFTEs'" + Environment.NewLine +
                ",pmv.[TotalProductiveFtes]  as 'TotalProductiveFtes'" + Environment.NewLine +
                ",pmv.[NonProductivePercent] as 'NonProductivePercent'" + Environment.NewLine +
                ",pmv.[NonProductiveFtes] as [NonProductiveFtes]" + Environment.NewLine +
                ",pmv.[EmployedPaidFtes] as [EmployedPaidFtes]" + Environment.NewLine +
                ",pmv.[TotalFtes] as 'TotalFtes'" + Environment.NewLine +
                ",pmv.[TotalSalariesAndWages] as [TotalSalariesAndWages]" + Environment.NewLine +
                ",pmv.[TotalContractLaborDollars] as [TotalContractLaborDollars]" + Environment.NewLine +
                ",pmv.[TotalLaborExpense] as [TotalLaborExpense]" + Environment.NewLine +
                ",pmv.[EmployedLaborRate] as [EmployedLaborRate]" + Environment.NewLine +
                ",pmv.[ContactLaborRate] as [ContactLaborRate]" + Environment.NewLine +
                ",pmv.[OverTimePremiumDollars] as [OverTimePremiumDollars]" + Environment.NewLine +
                ",pmv.[OtPercent] as 'OtPercent'" + Environment.NewLine +
                ",pmv.[OtFte]  as 'OTFTEs'" + Environment.NewLine +
                ",pmv.[WftPlan_ID]" + Environment.NewLine +
                ",pmv.Eeob as Eeob" + Environment.NewLine +
                ",pmv.MhAa as MhAa" + Environment.NewLine +
                ",F.CoId" + Environment.NewLine +
                ",F.Description as FacilityDescription" + Environment.NewLine +
                ",(Select SUM(VD.DeptVolume)  from WftMonthlyValue VD, WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month AND D.WftPlan_ID=pmv.WftPlan_ID  ) as 'DeptUOS'" + Environment.NewLine +
                ",(Select SUM(VD.SemiVariableProductiveFtes) from WftMonthlyValue VD,WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month AND D.WftPlan_ID=pmv.WftPlan_ID   )   as 'SemiVariableProductiveFtes'" + Environment.NewLine +
                ",CASE WHEN ISNULL((Select SUM(VD.DeptVolume)  from WftMonthlyValue VD, WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month AND D.WftPlan_ID=pmv.WftPlan_ID  ),0)= 0 THEN 0" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "(Select SUM(VD.PlusHoursPerUos) from WftMonthlyValue VD,WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month  AND D.WftPlan_ID=pmv.WftPlan_ID  )" + Environment.NewLine +
                "/(Select SUM(VD.DeptVolume)  from WftMonthlyValue VD, WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month AND D.WftPlan_ID=pmv.WftPlan_ID  ) end  as 'VariableProdHrsUOS'" + Environment.NewLine +
                ",CASE WHEN ISNULL((Select SUM(VD.DeptVolume)  from WftMonthlyValue VD, WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month AND D.WftPlan_ID=pmv.WftPlan_ID  ),0)= 0 THEN 0" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "(Select SUM(VD.[TotalProductiveHours]) from WftMonthlyValue VD,WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month  AND D.WftPlan_ID=pmv.WftPlan_ID  )" + Environment.NewLine +
                "/(Select SUM(VD.DeptVolume)  from WftMonthlyValue VD, WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month AND D.WftPlan_ID=pmv.WftPlan_ID  ) end  as 'TotalProdHrsUOS'" + Environment.NewLine +
                ",(Select SUM(VD.ProductiveMinFtes) from WftMonthlyValue VD,WftDepartment D WHERE VD.WftDepartment_ID= D.Id AND  Vd.Month =pmv.Month  AND D.WftPlan_ID=pmv.WftPlan_ID  ) 'ProductiveMinFtes'" + Environment.NewLine +
                ",(Select SUM(D.DeptVolumeTotal ) from WftDepartment D Where D.WftPlan_ID = pmv.WftPlan_ID)as 'DeptUOSTotal'" + Environment.NewLine +
                ",(Select SUM(D.SemiVariableProductiveFtesTotal )from WftDepartment D Where D.WftPlan_ID = pmv.WftPlan_ID) as SemiVariableProductiveFtesTotal" + Environment.NewLine +
                ",CASE WHEN ISNULL((Select SUM(D.DeptVolumeTotal ) from WftDepartment D Where D.WftPlan_ID = pmv.WftPlan_ID),0)= 0 THEN 0" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "(Select SUM(D.VariableHoursPerUosTotal) from WftDepartment D Where D.WftPlan_ID = pmv.WftPlan_ID)" + Environment.NewLine +
                "/(Select SUM(D.DeptVolumeTotal ) from WftDepartment D Where D.WftPlan_ID = pmv.WftPlan_ID) end  as 'VariableHoursPerUosTotal'" + Environment.NewLine +
                ",CASE WHEN ISNULL((Select SUM(D.DeptVolumeTotal ) from WftDepartment D Where D.WftPlan_ID = pmv.WftPlan_ID),0)= 0 THEN 0" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "(Select SUM(D.[TotalProductiveHoursTotal]) from WftDepartment D Where D.WftPlan_ID = pmv.WftPlan_ID)" + Environment.NewLine +
                "/(Select SUM(D.DeptVolumeTotal ) from WftDepartment D Where D.WftPlan_ID = pmv.WftPlan_ID) end  as 'TotalProdHrsUOSTotal'" + Environment.NewLine +
                ",(Select SUM(D.ProductiveMinFtesTotal) from WftDepartment D Where D.WftPlan_ID=pmv.WftPlan_ID) as MinFtesTotal" + Environment.NewLine +
                "INTO #TempMonthlyValue" + Environment.NewLine +
                "FROM [dbo].[WftPlanMonthlyValue] pmv" + Environment.NewLine +
                "JOIN WftPlan p on p.Id =pmv.WftPlan_ID" + Environment.NewLine +
                "JOIN Facility F ON p.Facility_ID = F.Id" + Environment.NewLine +
                "JOIN ReferenceSourceYear RY ON RY.Month = pmv.Month" + Environment.NewLine +
                "WHERE pmv.WftPlan_Id IN (@PlanID,@PlanIDCompareTo)  AND RY.CoId = F.CoId and  RY.SourceType = 1" + Environment.NewLine +
                "------------------------------------------------------------------------------" + Environment.NewLine +
                "DECLARE @SubmissionID BIGINT;" + Environment.NewLine +
                "EXEC [rpt_GetSubmittedId]  @PlanID,  @SubmissionID=@SubmissionID  OUTPUT;" + Environment.NewLine +
                "DECLARE @SubmissionID_1 BIGINT;" + Environment.NewLine +
                "EXEC [rpt_GetSubmittedId]  @PlanIDCompareTo,  @SubmissionID=@SubmissionID_1  OUTPUT;" + Environment.NewLine +
                "---For 1st plan" + Environment.NewLine +
                "IF (@SubmissionID is null )" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "INSERT INTO #TempFacStatValue(" + Environment.NewLine +
                "TPlan_id," + Environment.NewLine +
                "MonthNum," + Environment.NewLine +
                "Admissions," + Environment.NewLine +
                "AAdmissions," + Environment.NewLine +
                "PatientDays," + Environment.NewLine +
                "APatientDays," + Environment.NewLine +
                "ERVisits," + Environment.NewLine +
                "Outpatient" + Environment.NewLine +
                ")" + Environment.NewLine +
                "SELECT" + Environment.NewLine +
                "t2.WftPlan_ID," + Environment.NewLine +
                "t2.[Month]" + Environment.NewLine +
                ",T2.Admissions" + Environment.NewLine +
                ",T3.AAdmissions" + Environment.NewLine +
                ",T4.PatientDays" + Environment.NewLine +
                ",T5.APatientDays" + Environment.NewLine +
                ",T6.ERVisits" + Environment.NewLine +
                ",T7.Outpatient" + Environment.NewLine +
                "FROM" + Environment.NewLine +
                "(SELECT BudgetValue as [Admissions],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '81' AND WF.WftPlan_ID = @PlanID) T2" + Environment.NewLine +
                "--ON T2.[Month] = T2.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [AAdmissions],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '334' AND WF.WftPlan_ID = @PlanID) T3" + Environment.NewLine +
                "ON T2.[Month] = T3.[Month] AND T2.WftPlan_ID=T3.WftPlan_ID" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [PatientDays],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '3' AND WF.WftPlan_ID = @PlanID) T4" + Environment.NewLine +
                "ON T2.[Month] = T4.[Month] AND T2.WftPlan_ID=T4.WftPlan_ID" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [APatientDays],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '1' AND WF.WftPlan_ID = @PlanID) T5" + Environment.NewLine +
                "ON T2.[Month] = T5.[Month] AND T2.WftPlan_ID=T5.WftPlan_ID" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [ERVisits],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '319' AND WF.WftPlan_ID = @PlanID) T6" + Environment.NewLine +
                "ON T2.[Month] = T6.[Month] AND T2.WftPlan_ID=T6.WftPlan_ID" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [Outpatient],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '320' AND WF.WftPlan_ID = @PlanID) T7" + Environment.NewLine +
                "ON T2.[Month] = T7.[Month] AND T2.WftPlan_ID=T6.WftPlan_ID" + Environment.NewLine +
                "END" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "INSERT INTO #TempFacStatValue(" + Environment.NewLine +
                "TPlan_id," + Environment.NewLine +
                "MonthNum," + Environment.NewLine +
                "Admissions," + Environment.NewLine +
                "AAdmissions," + Environment.NewLine +
                "PatientDays," + Environment.NewLine +
                "APatientDays," + Environment.NewLine +
                "ERVisits," + Environment.NewLine +
                "Outpatient" + Environment.NewLine +
                ")" + Environment.NewLine +
                "SELECT" + Environment.NewLine +
                "t2.WftPlan_ID" + Environment.NewLine +
                ",t2.[Month]" + Environment.NewLine +
                ",T2.Admissions" + Environment.NewLine +
                ",T3.AAdmissions" + Environment.NewLine +
                ",T4.PatientDays" + Environment.NewLine +
                ",T5.APatientDays" + Environment.NewLine +
                ",T6.ERVisits" + Environment.NewLine +
                ",T7.Outpatient" + Environment.NewLine +
                "FROM" + Environment.NewLine +
                "--(SELECT HistoricalValue as [Admissions], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '81' and S.Id = @SubmissionID) T2" + Environment.NewLine +
                "--ON T1.MonthNum = T2.[Month]" + Environment.NewLine +
                "(SELECT BudgetValue as [Admissions],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '81' AND WF.WftPlan_ID = @PlanID) T2" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [AAdmissions], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '334' and S.Id = @SubmissionID) T3" + Environment.NewLine +
                "-- ON T2.[Month] = T3.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [AAdmissions],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '334' AND WF.WftPlan_ID = @PlanID) T3" + Environment.NewLine +
                "ON T2.[Month] = T3.[Month]" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [PatientDays], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '3' and S.Id = @SubmissionID) T4" + Environment.NewLine +
                "-- ON T2.[Month] = T4.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [PatientDays],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '3' AND WF.WftPlan_ID = @PlanID) T4" + Environment.NewLine +
                "ON T2.[Month] = T4.[Month]" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [APatientDays], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '1' and S.Id = @SubmissionID) T5" + Environment.NewLine +
                "-- ON T2.[Month] = T5.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [APatientDays],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '1' AND WF.WftPlan_ID = @PlanID) T5" + Environment.NewLine +
                "ON T2.[Month] = T5.[Month]" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [ERVisits], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '319' and S.Id = @SubmissionID) T6" + Environment.NewLine +
                "-- ON T2.[Month] = T6.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [ERVisits],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '319' AND WF.WftPlan_ID = @PlanID) T6" + Environment.NewLine +
                "ON T2.[Month] = T6.[Month]" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [Outpatient], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '320' and S.Id = @SubmissionID) T7" + Environment.NewLine +
                "-- ON T2.[Month] = T7.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [Outpatient],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '320' AND WF.WftPlan_ID = @PlanID) T7" + Environment.NewLine +
                "ON T2.[Month] = T7.[Month]" + Environment.NewLine +
                "END" + Environment.NewLine +
                "--For 2nd Plan" + Environment.NewLine +
                "IF(@PlanID <> @PlanIDCompareTo)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "IF (@SubmissionID_1 is null )" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "INSERT INTO #TempFacStatValue(" + Environment.NewLine +
                "TPlan_id," + Environment.NewLine +
                "MonthNum," + Environment.NewLine +
                "Admissions," + Environment.NewLine +
                "AAdmissions," + Environment.NewLine +
                "PatientDays," + Environment.NewLine +
                "APatientDays," + Environment.NewLine +
                "ERVisits," + Environment.NewLine +
                "Outpatient" + Environment.NewLine +
                ")" + Environment.NewLine +
                "SELECT" + Environment.NewLine +
                "t2.WftPlan_ID," + Environment.NewLine +
                "t2.[Month]" + Environment.NewLine +
                ",T2.Admissions" + Environment.NewLine +
                ",T3.AAdmissions" + Environment.NewLine +
                ",T4.PatientDays" + Environment.NewLine +
                ",T5.APatientDays" + Environment.NewLine +
                ",T6.ERVisits" + Environment.NewLine +
                ",T7.Outpatient" + Environment.NewLine +
                "FROM" + Environment.NewLine +
                "(SELECT BudgetValue as [Admissions],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '81' AND WF.WftPlan_ID = @PlanIDCompareTo) T2" + Environment.NewLine +
                "--ON T2.[Month] = T2.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [AAdmissions],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '334' AND WF.WftPlan_ID = @PlanIDCompareTo) T3" + Environment.NewLine +
                "ON T2.[Month] = T3.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [PatientDays],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '3' AND WF.WftPlan_ID = @PlanIDCompareTo) T4" + Environment.NewLine +
                "ON T2.[Month] = T4.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [APatientDays],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '1' AND WF.WftPlan_ID = @PlanIDCompareTo) T5" + Environment.NewLine +
                "ON T2.[Month] = T5.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [ERVisits],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '319' AND WF.WftPlan_ID = @PlanIDCompareTo) T6" + Environment.NewLine +
                "ON T2.[Month] = T6.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [Outpatient],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '320' AND WF.WftPlan_ID = @PlanIDCompareTo) T7" + Environment.NewLine +
                "ON T2.[Month] = T7.[Month]" + Environment.NewLine +
                "END" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "INSERT INTO #TempFacStatValue(" + Environment.NewLine +
                "TPlan_id," + Environment.NewLine +
                "MonthNum," + Environment.NewLine +
                "Admissions," + Environment.NewLine +
                "AAdmissions," + Environment.NewLine +
                "PatientDays," + Environment.NewLine +
                "APatientDays," + Environment.NewLine +
                "ERVisits," + Environment.NewLine +
                "Outpatient" + Environment.NewLine +
                ")" + Environment.NewLine +
                "SELECT" + Environment.NewLine +
                "t2.WftPlan_ID" + Environment.NewLine +
                ",t2.[Month]" + Environment.NewLine +
                ",T2.Admissions" + Environment.NewLine +
                ",T3.AAdmissions" + Environment.NewLine +
                ",T4.PatientDays" + Environment.NewLine +
                ",T5.APatientDays" + Environment.NewLine +
                ",T6.ERVisits" + Environment.NewLine +
                ",T7.Outpatient" + Environment.NewLine +
                "FROM" + Environment.NewLine +
                "--(SELECT HistoricalValue as [Admissions], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '81' and S.Id = @SubmissionID) T2" + Environment.NewLine +
                "--ON T1.MonthNum = T2.[Month]" + Environment.NewLine +
                "(SELECT BudgetValue as [Admissions],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '81' AND WF.WftPlan_ID = @PlanIDCompareTo) T2" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [AAdmissions], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '334' and S.Id = @SubmissionID) T3" + Environment.NewLine +
                "-- ON T2.[Month] = T3.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [AAdmissions],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '334' AND WF.WftPlan_ID = @PlanIDCompareTo) T3" + Environment.NewLine +
                "ON T2.[Month] = T3.[Month]" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [PatientDays], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '3' and S.Id = @SubmissionID) T4" + Environment.NewLine +
                "-- ON T2.[Month] = T4.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [PatientDays],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '3' AND WF.WftPlan_ID = @PlanIDCompareTo) T4" + Environment.NewLine +
                "ON T2.[Month] = T4.[Month]" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [APatientDays], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '1' and S.Id = @SubmissionID) T5" + Environment.NewLine +
                "-- ON T2.[Month] = T5.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [APatientDays],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '1' AND WF.WftPlan_ID = @PlanIDCompareTo) T5" + Environment.NewLine +
                "ON T2.[Month] = T5.[Month]" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [ERVisits], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '319' and S.Id = @SubmissionID) T6" + Environment.NewLine +
                "-- ON T2.[Month] = T6.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [ERVisits],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '319' AND WF.WftPlan_ID = @PlanIDCompareTo) T6" + Environment.NewLine +
                "ON T2.[Month] = T6.[Month]" + Environment.NewLine +
                "--LEFT OUTER JOIN" + Environment.NewLine +
                "--(SELECT HistoricalValue as [Outpatient], [Month]" + Environment.NewLine +
                "-- FROM SubmissionHistoricalWftFacilityStatValue W" + Environment.NewLine +
                "-- JOIN SubmissionHistoricalWftFacilityStat WF ON WF.Id = W.SubmissionHistoricalWftFacilityStat_ID" + Environment.NewLine +
                "-- JOIN FacilityRelatedFacilityStat FR ON FR.Id = WF.FacilityRelatedFacilityStatId" + Environment.NewLine +
                "-- JOIN FacilityStat FS ON FS.Id = FR.FacilityStat_ID" + Environment.NewLine +
                "-- JOIN Submission S ON S.Id = WF.Submission_ID" + Environment.NewLine +
                "-- WHERE  S.WftPlan_ID = @PlanID and FS.Code = '320' and S.Id = @SubmissionID) T7" + Environment.NewLine +
                "-- ON T2.[Month] = T7.[Month]" + Environment.NewLine +
                "LEFT OUTER JOIN" + Environment.NewLine +
                "(SELECT BudgetValue as [Outpatient],[Month],WftPlan_ID" + Environment.NewLine +
                "FROM WftFacilityStatValue W" + Environment.NewLine +
                "JOIN WftFacilityStat WF ON WF.Id = W.WftFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityRelatedFacilityStat FRFS ON  FRFS.Id = WF.FacilityRelatedFacilityStat_ID" + Environment.NewLine +
                "JOIN FacilityStat FS ON FS.Id = FRFS.FacilityStat_ID" + Environment.NewLine +
                "WHERE FS.Code = '320' AND WF.WftPlan_ID = @PlanIDCompareTo) T7" + Environment.NewLine +
                "ON T2.[Month] = T7.[Month]" + Environment.NewLine +
                "END" + Environment.NewLine +
                "END" + Environment.NewLine +
                "---SELECT * FROM #TempFacStatValue" + Environment.NewLine +
                "---SELECT * FROM #TempMonthlyValue order by EmployedProductiveFtes" + Environment.NewLine +
                "----create table for store Maxand Min values" + Environment.NewLine +
                "Create table #TempMaxMinValues(IndexId int, Max_EmployedProductiveFtes decimal(19,5)," + Environment.NewLine +
                "Max_ContractLaborPercent decimal(19,5)," + Environment.NewLine +
                "Max_ContractFtes decimal(19,5)," + Environment.NewLine +
                "Max_TotalProductiveFtes decimal(19,5)," + Environment.NewLine +
                "Max_NonProductivePercent decimal(19,5)," + Environment.NewLine +
                "Max_NonProductiveFtes decimal(19,5)," + Environment.NewLine +
                "Max_EmployedPaidFtes decimal(19,5)," + Environment.NewLine +
                "Max_TotalFtes decimal(19,5)," + Environment.NewLine +
                "Max_TotalSalariesAndWages decimal(19,5)," + Environment.NewLine +
                "Max_TotalContractLaborDollars decimal(19,5)," + Environment.NewLine +
                "Max_TotalLaborExpense decimal(19,5)," + Environment.NewLine +
                "Max_EmployedLaborRate decimal(19,5)," + Environment.NewLine +
                "Max_ContractLaborRate decimal(19,5)," + Environment.NewLine +
                "Max_OverTimePremiumDollars decimal(19,5)," + Environment.NewLine +
                "Max_OtPercent decimal(19,5)," + Environment.NewLine +
                "Max_OtFte decimal(19,5)," + Environment.NewLine +
                "Max_Eeob  decimal(19,5)," + Environment.NewLine +
                "Max_MhAa decimal(19,5)," + Environment.NewLine +
                "Max_SemiVariableFtes decimal(19,5)," + Environment.NewLine +
                "Max_VariableProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                "Max_TotalProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                "Max_MinFTE decimal(19,5)," + Environment.NewLine +
                "Min_EmployedProductiveFtes decimal(19,5)," + Environment.NewLine +
                "Min_ContractLaborPercent decimal(19,5)," + Environment.NewLine +
                "Min_ContractFtes decimal(19,5)," + Environment.NewLine +
                "Min_TotalProductiveFtes decimal(19,5)," + Environment.NewLine +
                "Min_NonProductivePercent decimal(19,5)," + Environment.NewLine +
                "Min_NonProductiveFtes decimal(19,5)," + Environment.NewLine +
                "Min_EmployedPaidFtes decimal(19,5)," + Environment.NewLine +
                "Min_TotalFtes decimal(19,5)," + Environment.NewLine +
                "Min_TotalSalariesAndWages decimal(19,5)," + Environment.NewLine +
                "Min_TotalContractLaborDollars decimal(19,5)," + Environment.NewLine +
                "Min_TotalLaborExpense decimal(19,5)," + Environment.NewLine +
                "Min_EmployedLaborRate decimal(19,5)," + Environment.NewLine +
                "Min_ContractLaborRate decimal(19,5)," + Environment.NewLine +
                "Min_OverTimePremiumDollars decimal(19,5)," + Environment.NewLine +
                "Min_OtPercent decimal(19,5)," + Environment.NewLine +
                "Min_OtFte decimal(19,5)," + Environment.NewLine +
                "Min_Eeob  decimal(19,5)," + Environment.NewLine +
                "Min_MhAa decimal(19,5)," + Environment.NewLine +
                "Max_Admissions decimal(19,5)," + Environment.NewLine +
                "Max_AAdmissions decimal(19,5) ," + Environment.NewLine +
                "Max_PatientDays decimal(19,5) ," + Environment.NewLine +
                "Max_APatientDays decimal(19,5)," + Environment.NewLine +
                "Max_ERVisits decimal(19,5) ," + Environment.NewLine +
                "Max_Outpatient	 decimal(19,5)," + Environment.NewLine +
                "Min_Admissions decimal(19,5)," + Environment.NewLine +
                "Min_AAdmissions decimal(19,5) ," + Environment.NewLine +
                "Min_PatientDays decimal(19,5) ," + Environment.NewLine +
                "Min_APatientDays decimal(19,5)," + Environment.NewLine +
                "Min_ERVisits decimal(19,5) ," + Environment.NewLine +
                "Min_Outpatient	 decimal(19,5)," + Environment.NewLine +
                "Min_SemiVariableFtes decimal(19,5)," + Environment.NewLine +
                "Min_VariableProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                "Min_TotalProdHrsPerUOS decimal(19,5) ," + Environment.NewLine +
                "Min_MinFTE decimal(19,5))" + Environment.NewLine +
                "--- Get Second Highest and Second Lowest Value to do color coding for Top 2 and bottom 2 values" + Environment.NewLine +
                "DECLARE @Table_TempMonthlyValue VARCHAR(50)" + Environment.NewLine +
                "DECLARE @Table_TempFacStatValue VARCHAR(50)" + Environment.NewLine +
                "DECLARE @Counter INT" + Environment.NewLine +
                "SET @Counter=1;" + Environment.NewLine +
                "WHILE ( @Counter <= 2)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "SET @Table_TempMonthlyValue=  '#TempMonthlyValue WHERE IndexId='+ convert(Varchar,@Counter);" + Environment.NewLine +
                "If (@Counter =1)" + Environment.NewLine +
                "SET @Table_TempFacStatValue='#TempFacStatValue WHERE TPlan_id='+ convert(Varchar,@PlanID);" + Environment.NewLine +
                "else" + Environment.NewLine +
                "SET @Table_TempFacStatValue='#TempFacStatValue WHERE TPlan_id='+ convert(Varchar,@PlanIDCompareTo);" + Environment.NewLine +
                "Print @Table_TempMonthlyValue" + Environment.NewLine +
                "exec [sp_GetTopNValue]  @Table_TempMonthlyValue,'EmployedProductiveFtes',1,2,@Max_EmployedProductiveFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'ContractPercent', 1,2, @Max_ContractLaborPercent out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'ContractFtes', 1 ,2, @Max_ContractFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalProductiveFtes', 1 ,2, @Max_TotalProductiveFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'NonProductivePercent', 1 ,2, @Max_NonProductivePercent out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'NonProductiveFtes', 1 ,2, @Max_NonProductiveFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'EmployedPaidFtes', 1 ,2, @Max_EmployedPaidFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalFtes', 1 ,2, @Max_TotalFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalSalariesAndWages', 1 ,2, @Max_TotalSalariesAndWages out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalContractLaborDollars', 1 ,2, @Max_TotalContractLaborDollars out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalLaborExpense', 1 ,2, @Max_TotalLaborExpense out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'EmployedLaborRate', 1 ,2, @Max_EmployedLaborRate out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'ContactLaborRate', 1 ,2, @Max_ContractLaborRate out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'OverTimePremiumDollars', 1 ,0, @Max_OverTimePremiumDollars out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'OtPercent', 1 ,2, @Max_OtPercent out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'OTFTEs ', 1 ,2, @Max_OtFte out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'Eeob', 1 ,3, @Max_Eeob out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'MhAa', 1 ,3, @Max_MhAa out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'SemiVariableProductiveFtes', 1 ,2, @Max_SemiVariableFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'VariableProdHrsUOS ', 1 ,2, @Max_VariableProdHrsPerUOS out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalProdHrsUOS', 1 ,2, @Max_TotalProdHrsPerUOS out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'ProductiveMinFtes', 1 ,2, @Max_MinFTE out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue,'EmployedProductiveFtes', 0 ,2,@Min_EmployedProductiveFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'ContractPercent', 0 ,2,@Min_ContractLaborPercent out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'ContractFtes', 0 ,2,@Min_ContractFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalProductiveFtes', 0 ,2,@Min_TotalProductiveFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'NonProductivePercent', 0 ,2,@Min_NonProductivePercent out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'NonProductiveFtes', 0 ,2,@Min_NonProductiveFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'EmployedPaidFtes', 0 ,2,@Min_EmployedPaidFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalFtes', 0 ,2,@Min_TotalFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalSalariesAndWages', 0 ,2,@Min_TotalSalariesAndWages out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalContractLaborDollars', 0 ,2,@Min_TotalContractLaborDollars out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalLaborExpense', 0 ,2,@Min_TotalLaborExpense out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'EmployedLaborRate', 0 ,2,@Min_EmployedLaborRate out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'ContactLaborRate', 0 ,2,@Min_ContractLaborRate out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'OverTimePremiumDollars', 0 ,2,@Min_OverTimePremiumDollars out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'OtPercent', 0, 2,@Min_OtPercent out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'OTFTEs ', 0 ,2,@Min_OtFte out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'Eeob', 0 ,3, @Min_Eeob out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'MhAa', 0 ,3, @Min_MhAa out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'SemiVariableProductiveFtes', 0 ,2, @Min_SemiVariableFtes out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'VariableProdHrsUOS ', 0 ,2, @Min_VariableProdHrsPerUOS out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'TotalProdHrsUOS', 0 ,2, @Min_TotalProdHrsPerUOS out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempMonthlyValue, 'ProductiveMinFtes', 0 ,2, @Min_MinFTE out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'Admissions', 1 ,0, @Max_Admissions  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'AAdmissions', 1 ,0, @Max_AAdmissions  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'PatientDays', 1 ,0, @Max_PatientDays  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'APatientDays', 1 ,0, @Max_APatientDays  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'ERVisits', 1 ,0, @Max_ERVisits  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'Outpatient', 1 ,0, @Max_Outpatient	 out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'Admissions', 0 ,0, @MIN_Admissions  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'AAdmissions', 0 ,0, @Min_AAdmissions  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'PatientDays', 0 ,0, @Min_PatientDays  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'APatientDays', 0 ,0, @Min_APatientDays  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'ERVisits', 0 ,0, @Min_ERVisits  out" + Environment.NewLine +
                "exec [sp_GetTopNValue] @Table_TempFacStatValue, 'Outpatient', 0 ,0, @Min_Outpatient	 out" + Environment.NewLine +
                "INSERT INTO #TempMaxMinValues Values (@Counter, @Max_EmployedProductiveFtes," + Environment.NewLine +
                "@Max_ContractLaborPercent ," + Environment.NewLine +
                "@Max_ContractFtes ," + Environment.NewLine +
                "@Max_TotalProductiveFtes ," + Environment.NewLine +
                "@Max_NonProductivePercent ," + Environment.NewLine +
                "@Max_NonProductiveFtes ," + Environment.NewLine +
                "@Max_EmployedPaidFtes ," + Environment.NewLine +
                "@Max_TotalFtes ," + Environment.NewLine +
                "@Max_TotalSalariesAndWages ," + Environment.NewLine +
                "@Max_TotalContractLaborDollars ," + Environment.NewLine +
                "@Max_TotalLaborExpense ," + Environment.NewLine +
                "@Max_EmployedLaborRate ," + Environment.NewLine +
                "@Max_ContractLaborRate ," + Environment.NewLine +
                "@Max_OverTimePremiumDollars ," + Environment.NewLine +
                "@Max_OtPercent ," + Environment.NewLine +
                "@Max_OtFte ," + Environment.NewLine +
                "@Max_Eeob  ," + Environment.NewLine +
                "@Max_MhAa," + Environment.NewLine +
                "@Max_SemiVariableFtes ," + Environment.NewLine +
                "@Max_VariableProdHrsPerUOS ," + Environment.NewLine +
                "@Max_TotalProdHrsPerUOS ," + Environment.NewLine +
                "@Max_MinFTE," + Environment.NewLine +
                "@Min_EmployedProductiveFtes ," + Environment.NewLine +
                "@Min_ContractLaborPercent ," + Environment.NewLine +
                "@Min_ContractFtes ," + Environment.NewLine +
                "@Min_TotalProductiveFtes ," + Environment.NewLine +
                "@Min_NonProductivePercent ," + Environment.NewLine +
                "@Min_NonProductiveFtes ," + Environment.NewLine +
                "@Min_EmployedPaidFtes ," + Environment.NewLine +
                "@Min_TotalFtes ," + Environment.NewLine +
                "@Min_TotalSalariesAndWages ," + Environment.NewLine +
                "@Min_TotalContractLaborDollars ," + Environment.NewLine +
                "@Min_TotalLaborExpense ," + Environment.NewLine +
                "@Min_EmployedLaborRate ," + Environment.NewLine +
                "@Min_ContractLaborRate ," + Environment.NewLine +
                "@Min_OverTimePremiumDollars ," + Environment.NewLine +
                "@Min_OtPercent ," + Environment.NewLine +
                "@Min_OtFte ," + Environment.NewLine +
                "@Min_Eeob  ," + Environment.NewLine +
                "@Min_MhAa," + Environment.NewLine +
                "@Max_Admissions ," + Environment.NewLine +
                "@Max_AAdmissions  ," + Environment.NewLine +
                "@Max_PatientDays  ," + Environment.NewLine +
                "@Max_APatientDays ," + Environment.NewLine +
                "@Max_ERVisits  ," + Environment.NewLine +
                "@Max_Outpatient," + Environment.NewLine +
                "@Min_Admissions ," + Environment.NewLine +
                "@Min_AAdmissions  ," + Environment.NewLine +
                "@Min_PatientDays  ," + Environment.NewLine +
                "@Min_APatientDays ," + Environment.NewLine +
                "@Min_ERVisits  ," + Environment.NewLine +
                "@Min_Outpatient," + Environment.NewLine +
                "@Min_SemiVariableFtes ," + Environment.NewLine +
                "@Min_VariableProdHrsPerUOS ," + Environment.NewLine +
                "@Min_TotalProdHrsPerUOS ," + Environment.NewLine +
                "@Min_MinFTE)" + Environment.NewLine +
                "IF(@PlanID <> @PlanIDCompareTo)" + Environment.NewLine +
                "SET @Counter  = @Counter  + 1;" + Environment.NewLine +
                "ELSE" + Environment.NewLine +
                "SET @Counter  = @Counter  + 2;" + Environment.NewLine +
                "END" + Environment.NewLine +
                "SELECT" + Environment.NewLine +
                "pmv.IndexId" + Environment.NewLine +
                ",pmv.WftPlan_ID" + Environment.NewLine +
                ",PMV.Year" + Environment.NewLine +
                ",pmv.MonthNum" + Environment.NewLine +
                ",pmv.[MonthName]" + Environment.NewLine +
                ",pmv.DaysInMonth" + Environment.NewLine +
                ",pmv.[EmployedProductiveFtes]" + Environment.NewLine +
                ",pmv.ContractPercent" + Environment.NewLine +
                ",pmv.[ContractFtes] AS ContractFTEs" + Environment.NewLine +
                ",pmv.[TotalProductiveFtes]" + Environment.NewLine +
                ",pmv.[NonProductivePercent]" + Environment.NewLine +
                ",pmv.[NonProductiveFtes]" + Environment.NewLine +
                ",pmv.[EmployedPaidFtes]" + Environment.NewLine +
                ",pmv.[TotalFtes]" + Environment.NewLine +
                ",pmv.[TotalSalariesAndWages]" + Environment.NewLine +
                ",pmv.[TotalContractLaborDollars]" + Environment.NewLine +
                ",pmv.[TotalLaborExpense]" + Environment.NewLine +
                ",pmv.[EmployedLaborRate]" + Environment.NewLine +
                ",pmv.[ContactLaborRate] AS ContractLaborRate" + Environment.NewLine +
                ",pmv.[OverTimePremiumDollars]" + Environment.NewLine +
                ",pmv.[OtPercent]" + Environment.NewLine +
                ",pmv.[OTFTEs]" + Environment.NewLine +
                ",pmv.Eeob" + Environment.NewLine +
                ",pmv.MhAa," + Environment.NewLine +
                "SV.Admissions," + Environment.NewLine +
                "SV.AAdmissions ," + Environment.NewLine +
                "sv.PatientDays ," + Environment.NewLine +
                "sv.APatientDays," + Environment.NewLine +
                "sv.ERVisits ," + Environment.NewLine +
                "sv.Outpatient," + Environment.NewLine +
                "(SELECT Max_EmployedProductiveFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_EmployedProductiveFtes ," + Environment.NewLine +
                "(SELECT Max_ContractLaborPercent FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_ContractLaborPercent ," + Environment.NewLine +
                "(SELECT Max_ContractFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_ContractFtes ," + Environment.NewLine +
                "(SELECT Max_TotalProductiveFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_TotalProductiveFtes ," + Environment.NewLine +
                "(SELECT Max_NonProductivePercent FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_NonProductivePercent ," + Environment.NewLine +
                "(SELECT Max_NonProductiveFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_NonProductiveFtes ," + Environment.NewLine +
                "(SELECT Max_EmployedPaidFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_EmployedPaidFtes ," + Environment.NewLine +
                "(SELECT Max_TotalFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_TotalFtes ," + Environment.NewLine +
                "(SELECT Max_TotalSalariesAndWages FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_TotalSalariesAndWages ," + Environment.NewLine +
                "(SELECT Max_TotalContractLaborDollars FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_TotalContractLaborDollars ," + Environment.NewLine +
                "(SELECT Max_TotalLaborExpense FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_TotalLaborExpense ," + Environment.NewLine +
                "(SELECT Max_EmployedLaborRate FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_EmployedLaborRate ," + Environment.NewLine +
                "(SELECT Max_ContractLaborRate FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_ContractLaborRate ," + Environment.NewLine +
                "(SELECT Max_OverTimePremiumDollars FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_OverTimePremiumDollars ," + Environment.NewLine +
                "(SELECT Max_OtPercent FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_OtPercent ," + Environment.NewLine +
                "(SELECT Max_OtFte FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_OtFte," + Environment.NewLine +
                "(SELECT Max_Eeob FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_Eeob," + Environment.NewLine +
                "(SELECT Max_MhAa FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_MhAa," + Environment.NewLine +
                "(SELECT Max_SemiVariableFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_SemiVariableFtes," + Environment.NewLine +
                "(SELECT Max_VariableProdHrsPerUOS FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_VariableProdHrsPerUOS," + Environment.NewLine +
                "(SELECT Max_TotalProdHrsPerUOS FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_TotalProdHrsPerUOS," + Environment.NewLine +
                "(SELECT Max_MinFTE FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_MinFTE," + Environment.NewLine +
                "(SELECT Min_EmployedProductiveFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_EmployedProductiveFtes ," + Environment.NewLine +
                "(SELECT Min_ContractLaborPercent FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_ContractLaborPercent ," + Environment.NewLine +
                "(SELECT Min_ContractFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_ContractFtes ," + Environment.NewLine +
                "(SELECT Min_TotalProductiveFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_TotalProductiveFtes ," + Environment.NewLine +
                "(SELECT Min_NonProductivePercent FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_NonProductivePercent ," + Environment.NewLine +
                "(SELECT Min_NonProductiveFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_NonProductiveFtes ," + Environment.NewLine +
                "(SELECT Min_EmployedPaidFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_EmployedPaidFtes ," + Environment.NewLine +
                "(SELECT Min_TotalFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_TotalFtes ," + Environment.NewLine +
                "(SELECT Min_TotalSalariesAndWages FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_TotalSalariesAndWages ," + Environment.NewLine +
                "(SELECT Min_TotalContractLaborDollars FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_TotalContractLaborDollars ," + Environment.NewLine +
                "(SELECT Min_TotalLaborExpense FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_TotalLaborExpense ," + Environment.NewLine +
                "(SELECT Min_EmployedLaborRate FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_EmployedLaborRate ," + Environment.NewLine +
                "(SELECT Min_ContractLaborRate FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_ContractLaborRate ," + Environment.NewLine +
                "(SELECT Min_OverTimePremiumDollars FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_OverTimePremiumDollars ," + Environment.NewLine +
                "(SELECT Min_OtPercent FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_OtPercent ," + Environment.NewLine +
                "(SELECT Min_OtFte FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Min_OtFte," + Environment.NewLine +
                "(SELECT Max_Admissions FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_Admissions ," + Environment.NewLine +
                "(SELECT Max_AAdmissions FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_AAdmissions," + Environment.NewLine +
                "(SELECT Max_PatientDays FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_PatientDays," + Environment.NewLine +
                "(SELECT Max_APatientDays FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Max_APatientDays ," + Environment.NewLine +
                "(SELECT Max_ERVisits FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_ERVisits," + Environment.NewLine +
                "(SELECT Max_Outpatient FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Max_Outpatient," + Environment.NewLine +
                "(SELECT Min_Admissions FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_Admissions ," + Environment.NewLine +
                "(SELECT Min_AAdmissions FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_AAdmissions ," + Environment.NewLine +
                "(SELECT Min_PatientDays FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_PatientDays ," + Environment.NewLine +
                "(SELECT Min_APatientDays FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_APatientDays ," + Environment.NewLine +
                "(SELECT Min_ERVisits FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId)  as Min_ERVisits ," + Environment.NewLine +
                "(SELECT Min_Outpatient FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Min_Outpatient," + Environment.NewLine +
                "(SELECT Min_Eeob FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Min_Eeob," + Environment.NewLine +
                "(SELECT Min_MhAa FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Min_MhAa," + Environment.NewLine +
                "(SELECT Min_SemiVariableFtes FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Min_SemiVariableFtes," + Environment.NewLine +
                "(SELECT Min_VariableProdHrsPerUOS FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Min_VariableProdHrsPerUOS," + Environment.NewLine +
                "(SELECT Min_TotalProdHrsPerUOS FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Min_TotalProdHrsPerUOS," + Environment.NewLine +
                "(SELECT Min_MinFTE FROM #TempMaxMinValues WHERE IndexId=pmv.IndexId) as Min_MinFTE" + Environment.NewLine +
                ",p.EmployedProductiveFtesTotal" + Environment.NewLine +
                ",p.ContractLaborPercentTotal as ContractPercentTotal" + Environment.NewLine +
                ",p.ContractFtesTotal" + Environment.NewLine +
                ",p.TotalProductiveFtesTotal" + Environment.NewLine +
                ",p.NonProductivePercentTotal" + Environment.NewLine +
                ",p.NonProductiveFtesTotal" + Environment.NewLine +
                ",p.EmployedPaidFtesTotal" + Environment.NewLine +
                ",p.TotalFtesTotal" + Environment.NewLine +
                ",p.TotalSalariesAndWagesTotal" + Environment.NewLine +
                ",p.TotalContractLaborDollarsTotal" + Environment.NewLine +
                ",p.TotalLaborExpenseTotal" + Environment.NewLine +
                ",p.EmployedLaborRateTotal" + Environment.NewLine +
                ",p.ContactLaborRateTotal AS ContractLaborRateTotal" + Environment.NewLine +
                ",p.OverTimePremiumDollarsTotal" + Environment.NewLine +
                ",p.OtPercentTotal" + Environment.NewLine +
                ",p.OTFTEsTotal" + Environment.NewLine +
                ",p.EeobTotal" + Environment.NewLine +
                ",p.MhAaTotal" + Environment.NewLine +
                ",pmv.CoId" + Environment.NewLine +
                ",pmv.FacilityDescription" + Environment.NewLine +
                ",pmv.DeptUOS" + Environment.NewLine +
                ",pmv.SemiVariableProductiveFtes" + Environment.NewLine +
                ",pmv.TotalProdHrsUOS" + Environment.NewLine +
                ",pmv.VariableProdHrsUOS" + Environment.NewLine +
                ",pmv.ProductiveMinFtes" + Environment.NewLine +
                ",pmv.DeptUOSTotal" + Environment.NewLine +
                ",pmv.SemiVariableProductiveFtesTotal" + Environment.NewLine +
                ",pmv.VariableHoursPerUosTotal" + Environment.NewLine +
                ",pmv.TotalProdHrsUOSTotal" + Environment.NewLine +
                ",pmv.MinFtesTotal" + Environment.NewLine +
                "INTO #FinalOutput" + Environment.NewLine +
                "FROM #TempMonthlyValue pmv" + Environment.NewLine +
                "INNER JOIN #TempFacStatValue SV ON PMV.MonthNum = SV.MonthNum AND PMV.WftPlan_ID = SV.TPlan_id" + Environment.NewLine +
                "INNER JOIN WftPlan p on PMV.WftPlan_ID=p.Id" + Environment.NewLine +
                "Order By pmv.IndexId,pmv.MonthNum" + Environment.NewLine +
                "IF(@PlanID = @PlanIDCompareTo)" + Environment.NewLine +
                "BEGIN" + Environment.NewLine +
                "Select * Into #FinalOutput_Temp From #FinalOutput" + Environment.NewLine +
                "Update #FinalOutput_Temp Set IndexID=2" + Environment.NewLine +
                "Insert into #FinalOutput Select * from #FinalOutput_Temp" + Environment.NewLine +
                "END" + Environment.NewLine +
                "Select * from #FinalOutput Order by IndexID,MonthNum" + Environment.NewLine +
                "DROP TABLE #FinalOutput   DROP TABLE #TempMonthlyValue" + Environment.NewLine +
                "END" + Environment.NewLine +
                "--WFT - HostBudgetUpdateFromStgStat" + Environment.NewLine +
                "-- =============================================" + Environment.NewLine +
                "-- Author:  Paarthibhan M. R." + Environment.NewLine +
                "-- Create date: 2/24/2021" + Environment.NewLine +
                "-- Description: Update Host Budget Value from StgStat to Facility Stat related tables." + Environment.NewLine +
                "-- =============================================" + Environment.NewLine +
                "SET ANSI_NULLS ON";
            return sp;

        }
    }
}
