﻿using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class ApprovedAndReleasedReport
    {
        public static void GoTo()
        {
            WFTMainMenu.WFTReports.Division.SelectApprovedReleased();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to Approved Released report", "Approved Released report page is displayed.");
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlReportYear']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        public static ApprovedAndReleasedReportCommand Report()
        {
            return new ApprovedAndReleasedReportCommand();
        }
    }
    #region: ApprovedAndReleasedReportCommand
    public class ApprovedAndReleasedReportCommand
    {
        private string year;
        private string division;
       
        public ApprovedAndReleasedReportCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public ApprovedAndReleasedReportCommand withDivision(string Division)
        {
            this.division = Division;
            return this;
        }

        private void setYear()
        {
            if (!string.IsNullOrEmpty(year))
            {
                IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//select[@id='ddlReportYear']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
            }
        }

        private void setDivision()
        {
            if (!string.IsNullOrEmpty(division))
            {
                IWebElement mnuDivisions = CommonFunctions.getElement(By.XPath("//select[@id='ddlDivision']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuDivisions, division);
            }
        }

        private void clickPDF()
        {
            IWebElement cmdPDF = CommonFunctions.getElement(By.XPath("//img[@title='PDF Format']"));
            CommonFunctions.ClickByJE(cmdPDF);
        }
        private void clickExcel()
        {
            IWebElement cmdExcel = CommonFunctions.getElement(By.XPath("//img[@title='Excel Format']"));
            CommonFunctions.ClickByJE(cmdExcel);
        }



        public void SelectPDF()
        {
            setYear();
            setDivision();
            clickPDF();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the PDF button", "Verify the PDF report is downloaded");
        }

        public void SelectExcel()
        {
            setYear();
            setDivision();
            clickExcel();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the Excel button", "Verify the Excel report is downloaded");
        }
    }
    #endregion
}




