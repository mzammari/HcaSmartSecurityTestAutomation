﻿using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class DepartmentGroupLaborSummaryYearlyReport
    {
        public static void GoTo()
        {
            WFTMainMenu.WFTReports.DepartmentGroup.SelectLaborSummaryYearly();
            CommonFunctions.WaitUntilPageIsAcive();
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlReportYear']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        public static DepartmentGroupLaborSummaryYearlyReportCommand Report()
        {
            return new DepartmentGroupLaborSummaryYearlyReportCommand();
        }
    }
    #region: DepartmentGroupLaborSummaryYearlyReportCommand
    public class DepartmentGroupLaborSummaryYearlyReportCommand
    {
        private string year;
        private string planStatus;
        private string plan;
        private string department;

        public DepartmentGroupLaborSummaryYearlyReportCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public DepartmentGroupLaborSummaryYearlyReportCommand withPlanStatus(string PlanStatus)
        {
            this.planStatus = PlanStatus;
            return this;
        }

        public DepartmentGroupLaborSummaryYearlyReportCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }

        public DepartmentGroupLaborSummaryYearlyReportCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        private void setYear()
        {
            if (!string.IsNullOrEmpty(year))
            {
                IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//select[@id='ddlReportYear']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
            }
        }

        private void setPlanStatus()
        {
            if (!string.IsNullOrEmpty(planStatus))
            {
                IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlanStatuses']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, planStatus);
            }
        }

        private void setDepartment()
        {
            if (!string.IsNullOrEmpty(department))
            {
                IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='ddlDepartment']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
            }
        }

        private void setPlan()
        {
            if (!string.IsNullOrEmpty(plan))
            {
                IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlans']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
            }
        }

        private void clickPDF()
        {
            IWebElement cmdPDF = CommonFunctions.getElement(By.XPath("//img[@title='PDF Format']"));
            CommonFunctions.ClickByJE(cmdPDF);
        }
        private void clickExcel()
        {
            IWebElement cmdExcel = CommonFunctions.getElement(By.XPath("//img[@title='Excel Format']"));
            CommonFunctions.ClickByJE(cmdExcel);
        }



        public void SelectPDF()
        {
            setYear();
            setPlanStatus();
            setPlan();
            setDepartment();
            clickPDF();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public void SelectExcel()
        {
            setYear();
            setPlanStatus();
            setPlan();
            setDepartment();
            clickExcel();
            CommonFunctions.WaitUntilPageIsAcive();
        }
    }
    #endregion
}



