﻿using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class ContractFTESummaryReport
    {
        public static void GoTo()
        {
            WFTMainMenu.WFTReports.FullTimeEmployees.SelectContractFTESummary();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to Contract FTE Summary report", "Contract FTE Summary report page is displayed.");
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlReportYear']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        public static ContractFTESummaryReportCommand Report()
        {
            return new ContractFTESummaryReportCommand();
        }
    }
    #region: ContractFTESummaryReportCommand
    public class ContractFTESummaryReportCommand
    {
        private string year;
        private string planStatus;
        private string plan;
        public ContractFTESummaryReportCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public ContractFTESummaryReportCommand withPlanStatus(string PlanStatus)
        {
            this.planStatus = PlanStatus;
            return this;
        }

        public ContractFTESummaryReportCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }

        private void setYear()
        {
            if (!string.IsNullOrEmpty(year))
            {
                IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//select[@id='ddlReportYear']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
            }
        }

        private void setPlanStatus()
        {
            if (!string.IsNullOrEmpty(planStatus))
            {
                IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlanStatuses']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, planStatus);
            }
        }

        private void setPlan()
        {
            if (!string.IsNullOrEmpty(plan))
            {
                IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlans']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
            }
        }

        private void clickPDF()
        {
            IWebElement cmdPDF = CommonFunctions.getElement(By.XPath("//img[@title='PDF Format']"));
            CommonFunctions.ClickByJE(cmdPDF);
        }
        private void clickExcel()
        {
            IWebElement cmdExcel = CommonFunctions.getElement(By.XPath("//img[@title='Excel Format']"));
            CommonFunctions.ClickByJE(cmdExcel);
        }



        public void SelectPDF()
        {
            setYear();
            setPlanStatus();
            setPlan();
            clickPDF();
            CommonFunctions.WaitUntilPageIsAcive(); 
            CommonFunctions.AddTestStep("Click on the PDF button", "Verify the PDF report is downloaded");
        }

        public void SelectExcel()
        {
            setYear();
            setPlanStatus();
            setPlan();
            clickExcel();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the Excel button", "Verify the Excel report is downloaded");
        }
    }
    #endregion
}


