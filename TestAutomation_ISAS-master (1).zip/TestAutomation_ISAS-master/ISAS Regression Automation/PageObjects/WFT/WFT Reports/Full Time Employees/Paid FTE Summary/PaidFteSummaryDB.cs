﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    // Alternative async version
    public class PaidFteSummaryDB
    {
        public class DepartmentFTE
        {
            public string DeptNumber { get; set; }
            public string DeptName { get; set; }
            public string DeptID { get; set; }
            public decimal MaxFTE { get; set; }
            public decimal MinFTE { get; set; }
            public decimal Month1 { get; set; }
            public decimal Month2 { get; set; }
            public decimal Month3 { get; set; }
            public decimal Month4 { get; set; }
            public decimal Month5 { get; set; }
            public decimal Month6 { get; set; }
            public decimal Month7 { get; set; }
            public decimal Month8 { get; set; }
            public decimal Month9 { get; set; }
            public decimal Month10 { get; set; }
            public decimal Month11 { get; set; }
            public decimal Month12 { get; set; }
        }

        public async Task<List<DepartmentFTE>> GetDepartmentFTEDataAsync()
        {
            var departmentFTEList = new List<DepartmentFTE>();

            using (var connection = new SqlConnection("_connectionString"))
            {
                using (var command = new SqlCommand("rpt_GetDeptFTE", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    try
                    {
                        await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var departmentFTE = new DepartmentFTE
                                {
                                    DeptNumber = reader["DeptNumber"]?.ToString() ?? string.Empty,
                                    DeptName = reader["DeptName"]?.ToString() ?? string.Empty,
                                    DeptID = reader["DeptID"]?.ToString() ?? string.Empty,
                                    MaxFTE = reader["maxFTE"] != DBNull.Value ? Convert.ToDecimal(reader["maxFTE"]) : 0m,
                                    MinFTE = reader["minFTE"] != DBNull.Value ? Convert.ToDecimal(reader["minFTE"]) : 0m,
                                    Month1 = reader["month1"] != DBNull.Value ? Convert.ToDecimal(reader["month1"]) : 0m,
                                    Month2 = reader["month2"] != DBNull.Value ? Convert.ToDecimal(reader["month2"]) : 0m,
                                    Month3 = reader["month3"] != DBNull.Value ? Convert.ToDecimal(reader["month3"]) : 0m,
                                    Month4 = reader["month4"] != DBNull.Value ? Convert.ToDecimal(reader["month4"]) : 0m,
                                    Month5 = reader["month5"] != DBNull.Value ? Convert.ToDecimal(reader["month5"]) : 0m,
                                    Month6 = reader["month6"] != DBNull.Value ? Convert.ToDecimal(reader["month6"]) : 0m,
                                    Month7 = reader["month7"] != DBNull.Value ? Convert.ToDecimal(reader["month7"]) : 0m,
                                    Month8 = reader["month8"] != DBNull.Value ? Convert.ToDecimal(reader["month8"]) : 0m,
                                    Month9 = reader["month9"] != DBNull.Value ? Convert.ToDecimal(reader["month9"]) : 0m,
                                    Month10 = reader["month10"] != DBNull.Value ? Convert.ToDecimal(reader["month10"]) : 0m,
                                    Month11 = reader["month11"] != DBNull.Value ? Convert.ToDecimal(reader["month11"]) : 0m,
                                    Month12 = reader["month12"] != DBNull.Value ? Convert.ToDecimal(reader["month12"]) : 0m
                                };

                                departmentFTEList.Add(departmentFTE);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception($"Error executing stored procedure rpt_GetDeptFTE: {ex.Message}", ex);
                    }
                }
            }

            return departmentFTEList;
        }
    }
}
