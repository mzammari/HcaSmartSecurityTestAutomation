﻿using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class PLUSSystemTargetsReport
    {
        public static void GoTo()
        {
            WFTMainMenu.WFTReports.Targets.SelectPLUSSystemTargets();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to PLUS System Targets report", "PLUS System Targets report page is displayed.");
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='ddlReportYear']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        public static PLUSSystemTargetsReportCommand Report()
        {
            return new PLUSSystemTargetsReportCommand();
        }
    }
    #region: PLUSSystemTargetsReportCommand
    public class PLUSSystemTargetsReportCommand
    {
        private string year;
        private string planStatus;
        private string plan;
        private string department;

        public PLUSSystemTargetsReportCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public PLUSSystemTargetsReportCommand withPlanStatus(string PlanStatus)
        {
            this.planStatus = PlanStatus;
            return this;
        }

        public PLUSSystemTargetsReportCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }

        public PLUSSystemTargetsReportCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        private void setYear()
        {
            if (!string.IsNullOrEmpty(year))
            {
                IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//select[@id='ddlReportYear']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
            }
        }

        private void setPlanStatus()
        {
            if (!string.IsNullOrEmpty(planStatus))
            {
                IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlanStatuses']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, planStatus);
            }
        }

        private void setDepartment()
        {
            if (!string.IsNullOrEmpty(department))
            {
                IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='ddlDepartment']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
            }
        }

        private void setPlan()
        {
            if (!string.IsNullOrEmpty(plan))
            {
                IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//select[@id='ddlPlans']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
            }
        }

        private void clickPDF()
        {
            IWebElement cmdPDF = CommonFunctions.getElement(By.XPath("//img[@title='PDF Format']"));
            CommonFunctions.ClickByJE(cmdPDF);
        }
        private void clickExcel()
        {
            IWebElement cmdExcel = CommonFunctions.getElement(By.XPath("//img[@title='Excel Format']"));
            CommonFunctions.ClickByJE(cmdExcel);
        }



        public void SelectPDF()
        {
            setYear();
            setPlanStatus();
            setPlan();
            setDepartment();
            clickPDF();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the PDF button", "Verify the PDF report is downloaded");
        }

        public void SelectExcel()
        {
            setYear();
            setPlanStatus();
            setPlan();
            setDepartment();
            clickExcel();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the Excel button", "Verify the Excel report is downloaded");
        }
    }
    #endregion
}



