﻿using AutomationCoreLite.Reporting;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class BudgetExportFromWFTtoHost
    {
        public static List<BudgetExportHost> GetHostFileData(string Forecast)
        {
            CommonFunctions.AddTestStep($"Get {Forecast} data from the Host File ", $"the {Forecast} data was fetched.");
            string ForecastCode;
            switch (Forecast)
            {
                case "VolumefcastStat6100":
                    ForecastCode = "6100";
                    List<BudgetExportHost> Host_VolumeFcastStat6100 = getData(ForecastCode);
                    return Host_VolumeFcastStat6100;
                case "VolumefcastStat6150":
                    ForecastCode = "6150";
                    List<BudgetExportHost> Host_VolumeFcastStat6150 = getData(ForecastCode);
                    return Host_VolumeFcastStat6150;
                case "VolumefcastStat6160":
                    ForecastCode = "6160";
                    List<BudgetExportHost> Host_VolumeFcastStat6160 = getData(ForecastCode);
                    return Host_VolumeFcastStat6160;
                case "FcastEmplPaidHrs":
                    ForecastCode = "9000";
                    List<BudgetExportHost> Host_FcastEmplPaidHrs = getData(ForecastCode);
                    return Host_FcastEmplPaidHrs;
                case "CLHrsFcast":
                    ForecastCode = "9010";
                    List<BudgetExportHost> Host_CLHrsFcast = getData(ForecastCode);
                    return Host_CLHrsFcast;
                case "FcastEmplProdHrs":
                    ForecastCode = "9020";
                    List<BudgetExportHost> Host_FcastEmplProdHrs = getData(ForecastCode);
                    return Host_FcastEmplProdHrs;
                case "OTHrsFcast":
                    ForecastCode = "9110";
                    List<BudgetExportHost> Host_OTHrsFcast = getData(ForecastCode);
                    return Host_OTHrsFcast;
                case "TotalOTHrsFcast":
                    ForecastCode = "12";
                    List<BudgetExportHost> Host_TotalOTHrsFcast = getData(ForecastCode);
                    return Host_TotalOTHrsFcast;
                case "TotalPaidHoursofAllDepts":
                    ForecastCode = "50";
                    List<BudgetExportHost> Host_TotalPaidHoursofAllDepts = getData(ForecastCode);
                    return Host_TotalPaidHoursofAllDepts;

            }
            return null;
        }

        private static List<BudgetExportHost> getData(string ForecastCode)
        {
            // Wait up to 90 seconds for the export file to be downloaded before reading it
            string FilePath = CommonFunctions.GetDownloadedFile("budftp.txt", 90);
            List<BudgetExportHost> lstData = new List<BudgetExportHost>();
            using (StreamReader reader = new StreamReader(FilePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] arrCurrentLine = line.Split(';');
                    if (arrCurrentLine[0].Trim() == "12" || arrCurrentLine[0].Trim() == "50")
                    {
                        lstData.Add(new BudgetExportHost()
                        {
                            DeptCode = string.Empty,
                            Jan = Convert.ToDouble(arrCurrentLine[1]),
                            Feb = Convert.ToDouble(arrCurrentLine[2]),
                            Mar = Convert.ToDouble(arrCurrentLine[3]),
                            Apr = Convert.ToDouble(arrCurrentLine[4]),
                            May = Convert.ToDouble(arrCurrentLine[5]),
                            Jun = Convert.ToDouble(arrCurrentLine[6]),
                            Jul = Convert.ToDouble(arrCurrentLine[7]),
                            Aug = Convert.ToDouble(arrCurrentLine[8]),
                            Sep = Convert.ToDouble(arrCurrentLine[9]),
                            Oct = Convert.ToDouble(arrCurrentLine[10]),
                            Nov = Convert.ToDouble(arrCurrentLine[11]),
                            Dec = Convert.ToDouble(arrCurrentLine[12])
                        });

                    }
                    else if (arrCurrentLine[0].Equals(ForecastCode))
                    {
                        //make sure dept is not null
                        if (!string.IsNullOrEmpty(arrCurrentLine[1]))
                        {
                            lstData.Add(new BudgetExportHost()
                            {
                                DeptCode = arrCurrentLine[1],
                                Jan = Convert.ToDouble(arrCurrentLine[2]),
                                Feb = Convert.ToDouble(arrCurrentLine[3]),
                                Mar = Convert.ToDouble(arrCurrentLine[4]),
                                Apr = Convert.ToDouble(arrCurrentLine[5]),
                                May = Convert.ToDouble(arrCurrentLine[6]),
                                Jun = Convert.ToDouble(arrCurrentLine[7]),
                                Jul = Convert.ToDouble(arrCurrentLine[8]),
                                Aug = Convert.ToDouble(arrCurrentLine[9]),
                                Sep = Convert.ToDouble(arrCurrentLine[10]),
                                Oct = Convert.ToDouble(arrCurrentLine[11]),
                                Nov = Convert.ToDouble(arrCurrentLine[12]),
                                Dec = Convert.ToDouble(arrCurrentLine[13])
                            });
                        }
                    }
                }
            }
            return lstData;
        }
    }
}
