﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using static System.Net.WebRequestMethods;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;

namespace ISAS_Regression_Automation
{
    public class WFTMainMenu
    {
        public class Home
        {
            public static void SelectHome()
            {
                MenuSelectorByLink.SelectTop("Home");
                By byWFTHome = By.XPath("//*/td[normalize-space()='Welcome to Workload Forecast Tool (WFT).']");
                WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.ElementIsVisible(byWFTHome));
            }
        }

        public class WorkloadForecast
        {
            public class Administration
            {
                public static void SelectPlan()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Workload Forecast')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Administration')]");
                    By link = By.XPath("//*/a[contains(text(),'Plan')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectFacility()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Workload Forecast')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Administration')]");
                    By link = By.XPath("//*/a[contains(text(),'Facility')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectPLUSInterface()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Workload Forecast')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Administration')]");
                    By link = By.XPath("//*/a[contains(text(),'PLUS Interface')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
            }

            public class DepartmentForecast
            {
                public static void SelectDepartmentForecast()
                {
                    CommonFunctions.WaitUntilPageIsAcive();
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Workload Forecast')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Department Forecast')]");
                    MenuSelector.SelectBy(TopMenuLevel, SecondMunuLevel);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.AddTestStep("Navigate to the dept forecast page", "the dept forecast page is displayed");
                    Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                }
            }
        }

        public class WFTReports
        {
            public class FullTimeEmployees
            {
                public static void SelectPaidFTESummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Full Time Employees')]");
                    By link = By.XPath("//*/a[contains(text(),'Paid FTE Summary')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectProductiveFTESummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Full Time Employees')]");
                    By link = By.XPath("//*/a[contains(text(),'Productive FTE Summary')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectContractFTESummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Full Time Employees')]");
                    By link = By.XPath("//*/a[contains(text(),'Contract FTE Summary')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
            }

            public class Department
            {
                public static void SelectAnnualBudgetSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Department']");
                    By link = By.XPath("//*/a[contains(text(),'Annual Budget Summary')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectEmployedandContractFTECounts()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Department']");
                    By link = By.XPath("//*/a[contains(text(),'Employed and Contract FTE Counts')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectEmployedAndContractFTECost()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Department']");
                    By link = By.XPath("//*/a[contains(text(),'Employed and Contract FTE Cost')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectLaborSummaryMonthly()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Department']");
                    By link = By.XPath("//*/a[contains(text(),'Labor Summary - Monthly')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectLaborSummaryYearly()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Department']");
                    By link = By.XPath("//*/a[contains(text(),'Labor Summary - Yearly')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectLaborSummaryMonthlyComparison()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Department']");
                    By link = By.XPath("//*/a[contains(text(),'Labor Summary - Monthly Comparison')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }


            }

            public class DepartmentGroup
            {
                public static void SelectLaborSummaryMonthly()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Department Group']");
                    By link = By.XPath("//*/a[contains(@href,'LaborSummaryMonthlyDeptGroupReport')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectLaborSummaryYearly()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Department Group']");
                    By link = By.XPath("//*/a[contains(@href,'LaborSumDeptGroupReport')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
            }

            public class Facility
            {
                public static void SelectDeptFacilityRatioImpactAnalysis()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/ul//a[text()='Facility' and @class='sf-with-ul']");
                    By link = By.XPath("//*/a[contains(text(),'Dept/Facility Ratio - Impact Analysis')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectFacilityStatMapping()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/ul//a[text()='Facility' and @class='sf-with-ul']");
                    By link = By.XPath("//*/a[contains(text(),'Facility Stat Mapping')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectLaborSummaryMonthly()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/ul//a[text()='Facility' and @class='sf-with-ul']");
                    By link = By.XPath("//*/a[contains(@href,'LaborSummaryMonthlyFacilityReport')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectLaborSummaryYearly()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/ul//a[text()='Facility' and @class='sf-with-ul']");
                    By link = By.XPath("//*/a[contains(@href,'LaborSumFacilityReport')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectNonProdPercentImpactAnalysis()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/ul//a[text()='Facility' and @class='sf-with-ul']");
                    By link = By.XPath("//*/a[contains(text(),'Impact')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
            }

            public class Division
            {
                public static void SelectApprovedReleased()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Division']");
                    By link = By.XPath("//*/a[contains(text(),'Released')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

            }

            public class Targets
            {
                public static void SelectPLUSSystemTargets()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Targets']");
                    By link = By.XPath("//*/a[contains(text(),'PLUS System Targets')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
                public static void SelectSVComparison()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Targets']");
                    By link = By.XPath("//*/a[contains(text(),'SV Comparison')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
            }

            public class UserList
            {
                public static void SelectUserList()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By link = By.XPath("//*/a[contains(text(),'User List')]");
                    MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
                }
            }
            public class Exports
            {
                public static void SelectExports()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports/Data')]");
                    By link = By.XPath("//*/a[contains(text(),'Exports')]");
                    MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
                }
            }
        }

        public class Help
        {
            public static void SelectContent()
            {
                By TopMenuLevel = By.XPath("//*/a[contains(text(),'Help')]");
                By link = By.XPath("//*/a[contains(text(),'Online Help')]");
                MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
            }
        }
    }
}
