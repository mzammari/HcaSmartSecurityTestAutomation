﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class ForecastView
    {
        public static void GoTo()
        {
            By byGoToForecast = By.XPath("//a[@id='forecastTabLink']");
            var bExist = CommonFunctions.IsElementDisplayed(byGoToForecast, 2);
            if (bExist)
            {
                IWebElement tbForecastView = CommonFunctions.getElement(byGoToForecast);
                tbForecastView.Click();
                CommonFunctions.AddTestStep("Verify Forecast View", "Forecast View");
            }
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='1']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
    }
}
