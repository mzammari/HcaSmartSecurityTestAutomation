﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;

namespace ISAS_Regression_Automation
{
    public class ForecastView_OTPercent
    {
        public static void ClickFill()
        {
            IWebElement cmdFill = CommonFunctions.getElement(By.XPath("//*/input[@id='otPercentFillBtn']"));
            CommonFunctions.ClickByJE(cmdFill);
        }

        public class OTPercentQMIRS
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistOtPercent']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getOTPercentQMIRSData()
            {
                CommonFunctions.AddTestStep("Get OT Percent QMIRS Data", "OT Percent QMIRS Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistOtPercent']//input[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class OTPercentFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='txtOTPercent-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getOTPercentFcastData()
            {
                return CommonFunctions.getMonthlyData("//*/div[@id='divOtPct']", 2);                
            }
        }

        public class OTHrsFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='otHrs-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getOTHrsFcastData()
            {
                CommonFunctions.AddTestStep("Get OT Hrs Fcast Data", "OT Hrs Fcast Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrs-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='otHrsTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class OTFTEsFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='otFte-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getOTFTEsFcastData()
            {
                CommonFunctions.AddTestStep("Get OT FTEs Fcast Data", "OT FTEs Fcast Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='otFte-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='otFtesTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }
    }
}
