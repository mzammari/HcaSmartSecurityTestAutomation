﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System.Threading;

namespace ISAS_Regression_Automation
{

    public class ForecastView_Volume
    {
        private static void DoubleClickMonth(By ByValue)
        {
            IWebElement Mar = CommonFunctions.getElement(ByValue);
            CommonFunctions.DoubleClickUsingWebElement(Mar);
            Thread.Sleep(2000);
            CommonFunctions.WaitUntilPageIsAcive();
            DeptForecastMenu.clickSaveAndRecalc();
        }

        public class FacilityStat
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='txtFacilityStat-3']");
                DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getFacilityStatsData()
            {
                CommonFunctions.AddTestStep("Get Facility Stats Data", "Facility Stats Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStat-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='txtFacilityStatTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };                    
                return data;
            }

        }

        public class DeptFacilityRatio
        {
            public static void DoubleClickMar()
            {
                CommonFunctions.AddTestStep("Double-Click the March cell", "The March cell is enabled");
                By Mar = By.XPath("//*/input[@id='txtDeptFacilityRatio-3']");
                DoubleClickMonth(Mar);
            }

            public static void ClickHist()
            {
                IWebElement cmdHit = CommonFunctions.getElement(By.XPath("//*/input[@id='resetQMIRSHistoricalValueBtn']"));
                cmdHit.Click();

            }

            public static void ClickFill()
            {
                IWebElement cmdFill = CommonFunctions.getElement(By.XPath("//*/input[@id='deptFacilityRatioFillBtn']"));
                cmdFill.Click();

            }

            public static IWebElement getFirstCurrentElement()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptFacilityRatio-1']"));
                return Jan;
            }

            public static MonthlyForcastView getDeptFacilityRatioData()
            {
                CommonFunctions.AddTestStep("Get Dept Facility Ratio Data", "Dept Facility Ratio Data");
                return CommonFunctions.getMonthlyData("//*/div[@id='divDeptFacilityRatio']", 3);
            }

        }

        public class HistDeptFacilityRatio
        {
            public static void DoubleClickMar()
            {
                CommonFunctions.AddTestStep("Double-Click the March cell", "The March cell is enabled");
                By Mar = By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='3']");
                DoubleClickMonth(Mar);
            }

            public static string GetColor()
            {
                
                string color;
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='12']"));
                color = Dec.GetCssValue("background-color");
                CommonFunctions.AddTestStep("Get background cell's background color", $"The {color} is captured");
                return color;
            }

            public static IWebElement getFirstHistoricalElement()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='1']"));
                return Jan;
            }

            public static MonthElements HistDeptFacilityRatioRow()
            {
                return new MonthElements()
                {
                    Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='1']")),
                    Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='2']")),
                    Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='3']")),
                    Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='4']")),
                    May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='5']")),
                    Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='6']")),
                    Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='7']")),
                    Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='8']")),
                    Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='9']")),
                    Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='10']")),
                    Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='11']")),
                    Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='12']")),
                    Total = CommonFunctions.getElement(By.XPath("//input[@id='txtHistDeptFacilityRatioTotal']"))
                };
            }

            public static MonthlyForcastView getHistDeptFacilityRatioData()
            {
                CommonFunctions.AddTestStep("Get Hist Dept Facility Ratio Data", "Hist Dept Facility Ratio Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistDeptFacilityRatio']//input[@month='12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//input[@id='txtHistDeptFacilityRatioTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value"), 3),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value"), 3),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value"), 3),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value"), 3),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value"), 3),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value"), 3),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value"), 3),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value"), 3),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value"), 3),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value"), 3),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value"), 3),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value"), 3),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"), 3)
                };
                return data;
            }

        }        

        public class QMIRS_Stat6100
        {
            public static void DoubleClickMar()
            {
                CommonFunctions.AddTestStep("Double-Click the March cell", "The March cell is enabled");
                By Mar = By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='5']");
                DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getQMIRSStat6100Data()
            {
                CommonFunctions.AddTestStep("Get QMIRS Stat 6100 Data", "QMIRS Stat 6100 Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistoricalDepartmentTotalUos']//input[@month='12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptVolumeTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

        }

        public class PLUSVolume
        {
            public static void DoubleClickMar()
            {
                CommonFunctions.AddTestStep("Double-Click the March cell", "The March cell is enabled");
                By Mar = By.XPath("//*/div[@id='divPlusHistory']//input[@month='3']");
                DoubleClickMonth(Mar);
            }

            public static void ClickPLUS()
            {
                IWebElement cmdPLUS = CommonFunctions.getElement(By.XPath("//a[@id='resetDFRationtoPlusFillBtn']"));
                cmdPLUS.Click();
            }

            public static MonthlyForcastView getPLUSVolumeData()
            {
                CommonFunctions.AddTestStep("Get PLUS Volume Data", "PLUS Volume Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divPlusHistory']//input[@month='12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//input[@id='plusVolumeTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

        }

        public class HostBudget
        {
            public static MonthlyForcastView getHostBudgetData()
            {
                CommonFunctions.AddTestStep("Get Host Budget Data", "Host Budget Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHostHistory']//input[@month='12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//input[@id='hostBudgetTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

        }

        public class VolumefcastStat6100
        {
            public static void DoubleClickMar()
            {
                CommonFunctions.AddTestStep("Double-Click the March cell", "The March cell is enabled");
                By Mar = By.XPath("//*/div[@id='divDeptVolume']//input[@month='3']");
                DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getVolumefcastStat6100Data()
            {
                CommonFunctions.AddTestStep("Get Volume fcast Stat 6100 Data", "Volume fcast Stat 6100 Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptVolumeTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

            public static MonthElements getVolumefcastStat6100Elements()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divDeptVolume']//input[@month='12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptVolumeTotal']"));
                var data = new MonthElements()
                {
                    Jan = Jan,
                    Feb = Feb,
                    Mar = Mar,
                    Apr = Apr,
                    May = May,
                    Jun = Jun,
                    Jul = Jul,
                    Aug = Aug,
                    Sep = Sep,
                    Oct = Oct,
                    Nov = Nov,
                    Dec = Dec,
                    Total = Total
                };
                return data;
            }
        }

        public class VolumefcastStat6150
        {
            public static void DoubleClickMar()
            {
                CommonFunctions.AddTestStep("Double-Click the March cell", "The March cell is enabled");
                By Mar = By.XPath("//*/input[@id='txtDeptOutStatVolume-3']");
                DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getVolumefcastStat6150Data()
            {
                CommonFunctions.AddTestStep("Get Volume fcast Stat 6150 Data", "Volume fcast Stat 6150 Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptInStatVolumeTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

        }

        public class VolumefcastStat6160
        {
            public static void DoubleClickMar()
            {
                CommonFunctions.AddTestStep("Double-Click the March cell", "The March cell is enabled");
                By Mar = By.XPath("//*/input[@id='txtDeptOutStatVolume-3']");
                DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getVolumefcastStat6160Data()
            {
                CommonFunctions.AddTestStep("Get Volume fcast Stat 6160 Data", "Volume fcast Stat 6160 Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptOutStatVolume-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptoutStatVolumeTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

        }

        public class VolumeDailyAverageVolume
        {
            public static void DoubleClickMar()
            {
                CommonFunctions.AddTestStep("Double-Click the March cell", "The March cell is enabled");
                By Mar = By.XPath("//*/input[@id='3']");
                DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getVolumeDailyAverageVolumeData()
            {
                CommonFunctions.AddTestStep("Get Volume Daily Average Volume Data", "Volume Daily Average Volume Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divAvgDeptVolume']//input[13]"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

            public static MonthElements getVolumeDailyAverageVolumeElements()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divAvgDeptVolume']//input[13]"));
                var data = new MonthElements()
                {
                    Jan = Jan,
                    Feb = Feb,
                    Mar = Mar,
                    Apr = Apr,
                    May = May,
                    Jun = Jun,
                    Jul = Jul,
                    Aug = Aug,
                    Sep = Sep,
                    Oct = Oct,
                    Nov = Nov,
                    Dec = Dec,
                    Total = Total
                };
                return data;
            }
        }

    }
}
