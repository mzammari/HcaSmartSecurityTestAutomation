﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DeptForecastMenu
    {
        public static void clickSaveAndRecalc()
        {
           // string saveCalcXpath = "//*/a[@id='btnSaveBugdegetForecast']"; // plan save & calc
            string saveCalcXpath = "//a[@id='btnDeptSave']"; // dept save & calc
            bool bExist;
            bExist = CommonFunctions.IsElementDisplayed(saveCalcXpath, 1);
            if (bExist)
            {
                IWebElement cmdSaveRecalc = CommonFunctions.getElement(By.XPath(saveCalcXpath));
                CommonFunctions.ClickByJE(cmdSaveRecalc);
                clickConfirmRecalc();
                CommonFunctions.WaitUntilPageIsAcive();
            }
            CommonFunctions.AddTestStep("Verify click Save And Recalc button", "click Save And Recalc button");
        }

        private static void clickConfirmRecalc()
        {
            string yesXpath = "//*/div[@aria-labelledby='ui-dialog-title-save-confirm']//button/span[text()='Yes']";
            bool bExist = CommonFunctions.IsElementDisplayed(yesXpath, 1);
            if (bExist)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(yesXpath));
                CommonFunctions.ClickByJE(cmdYes);
            }
        }
    }
}
