﻿using AutomationCoreLite.Reporting;
using Microsoft.AspNetCore.Razor.Language.Extensions;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class ForecastView_LaborRates
    {
        public static void ClickEmplLaborRateFcastFill()
        {
            IWebElement cmdFill = CommonFunctions.getElement(By.XPath("//*/a[@id='employedLaborRateFillBtn']"));
            CommonFunctions.ClickByJE(cmdFill);
        }

        public static void ClickContractRateFcastFill()
        {
            IWebElement cmdFill = CommonFunctions.getElement(By.XPath("//*/a[@id='contractRateFillBtn']"));
            CommonFunctions.ClickByJE(cmdFill);
        }

        public class QMIRSEmplLbrRate
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistEmplLaborRate']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getQMIRSEmplLbrRateData()
            {
                CommonFunctions.AddTestStep("Get QMIRS Empl Lbr Rate Data", "QMIRS Empl Lbr Rate Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistEmplLaborRate']//input[13]"));
                var data = new MonthlyForcastView()
                {
                    Jan = (CommonFunctions.ToDouble(Jan.GetAttribute("value"))),
                    Feb = (CommonFunctions.ToDouble(Feb.GetAttribute("value"))),
                    Mar = (CommonFunctions.ToDouble(Mar.GetAttribute("value"))),
                    Apr = (CommonFunctions.ToDouble(Apr.GetAttribute("value"))),
                    May = (CommonFunctions.ToDouble(May.GetAttribute("value"))),
                    Jun = (CommonFunctions.ToDouble(Jun.GetAttribute("value"))),
                    Jul = (CommonFunctions.ToDouble(Jul.GetAttribute("value"))),
                    Aug = (CommonFunctions.ToDouble(Aug.GetAttribute("value"))),
                    Sep = (CommonFunctions.ToDouble(Sep.GetAttribute("value"))),
                    Oct = (CommonFunctions.ToDouble(Oct.GetAttribute("value"))),
                    Nov = (CommonFunctions.ToDouble(Nov.GetAttribute("value"))),
                    Dec = (CommonFunctions.ToDouble(Dec.GetAttribute("value"))),
                    Total = (CommonFunctions.ToDouble(Total.GetAttribute("value")))
                };
                return data;
            }

        }

        public class EmplLaborRateFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='employedLaborRate-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getEmplLaborRateFcastData()
            {
                CommonFunctions.AddTestStep("Get Empl Labor Rate Fcast Data", "Empl Labor Rate Fcast Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                return CommonFunctions.getMonthlyData("//*/div[@id='divEmployedLaborRate']", 2);                
            }

        }

        public class EmplSalariesFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='emplSalaries-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getEmplSalariesFcastData()
            {
                CommonFunctions.AddTestStep("Get Empl Salaries Fcast Data", "Empl Salaries Fcast Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalaries-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='emplSalariesTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = (CommonFunctions.ToDouble(Jan.GetAttribute("value"))),
                    Feb = (CommonFunctions.ToDouble(Feb.GetAttribute("value"))),
                    Mar = (CommonFunctions.ToDouble(Mar.GetAttribute("value"))),
                    Apr = (CommonFunctions.ToDouble(Apr.GetAttribute("value"))),
                    May = (CommonFunctions.ToDouble(May.GetAttribute("value"))),
                    Jun = (CommonFunctions.ToDouble(Jun.GetAttribute("value"))),
                    Jul = (CommonFunctions.ToDouble(Jul.GetAttribute("value"))),
                    Aug = (CommonFunctions.ToDouble(Aug.GetAttribute("value"))),
                    Sep = (CommonFunctions.ToDouble(Sep.GetAttribute("value"))),
                    Oct = (CommonFunctions.ToDouble(Oct.GetAttribute("value"))),
                    Nov = (CommonFunctions.ToDouble(Nov.GetAttribute("value"))),
                    Dec = (CommonFunctions.ToDouble(Dec.GetAttribute("value"))),
                    Total = (CommonFunctions.ToDouble(Total.GetAttribute("value")))
                };
                return data;
            }

        }

        public class QMIRSContractRate
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistContractRate']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getQMIRSContractRateData()
            {
                CommonFunctions.AddTestStep("Get QMIRS Contract Rate Data", "QMIRS Contract Rate Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractRate']//input[13]"));
                var data = new MonthlyForcastView()
                {
                    Jan = (CommonFunctions.ToDouble(Jan.GetAttribute("value"))),
                    Feb = (CommonFunctions.ToDouble(Feb.GetAttribute("value"))),
                    Mar = (CommonFunctions.ToDouble(Mar.GetAttribute("value"))),
                    Apr = (CommonFunctions.ToDouble(Apr.GetAttribute("value"))),
                    May = (CommonFunctions.ToDouble(May.GetAttribute("value"))),
                    Jun = (CommonFunctions.ToDouble(Jun.GetAttribute("value"))),
                    Jul = (CommonFunctions.ToDouble(Jul.GetAttribute("value"))),
                    Aug = (CommonFunctions.ToDouble(Aug.GetAttribute("value"))),
                    Sep = (CommonFunctions.ToDouble(Sep.GetAttribute("value"))),
                    Oct = (CommonFunctions.ToDouble(Oct.GetAttribute("value"))),
                    Nov = (CommonFunctions.ToDouble(Nov.GetAttribute("value"))),
                    Dec = (CommonFunctions.ToDouble(Dec.GetAttribute("value"))),
                    Total = (CommonFunctions.ToDouble(Total.GetAttribute("value")))
                };
                return data;
            }

        }

        public class ContractRateFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='contractRateForecast-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getContractRateFcastData()
            { 
                CommonFunctions.AddTestStep("Get Contract Rate Fcast Data", "Contract Rate Fcast Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                return CommonFunctions.getMonthlyData("//*/div[@id='divContractRate']", 2);
            }

        }

        public class CLDollarsFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='contractAmt-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getCLDollarsFcastData()
            {
                CommonFunctions.AddTestStep("Get CL Dollars Fcast Data", "CL Dollars Fcast Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='contractAmt-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='contractLaborDollarsTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = (CommonFunctions.ToDouble(Jan.GetAttribute("value"))),
                    Feb = (CommonFunctions.ToDouble(Feb.GetAttribute("value"))),
                    Mar = (CommonFunctions.ToDouble(Mar.GetAttribute("value"))),
                    Apr = (CommonFunctions.ToDouble(Apr.GetAttribute("value"))),
                    May = (CommonFunctions.ToDouble(May.GetAttribute("value"))),
                    Jun = (CommonFunctions.ToDouble(Jun.GetAttribute("value"))),
                    Jul = (CommonFunctions.ToDouble(Jul.GetAttribute("value"))),
                    Aug = (CommonFunctions.ToDouble(Aug.GetAttribute("value"))),
                    Sep = (CommonFunctions.ToDouble(Sep.GetAttribute("value"))),
                    Oct = (CommonFunctions.ToDouble(Oct.GetAttribute("value"))),
                    Nov = (CommonFunctions.ToDouble(Nov.GetAttribute("value"))),
                    Dec = (CommonFunctions.ToDouble(Dec.GetAttribute("value"))),
                    Total = (CommonFunctions.ToDouble(Total.GetAttribute("value")))
                };
                return data;
            }

        }

        public class QMIRSAvgRate
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistAvgRate']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getQMIRSAvgRateData()
            {
                CommonFunctions.AddTestStep("Get QMIRS Avg Rate Data", "QMIRS Avg Rate Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistAvgRate']//input[13]"));
                var data = new MonthlyForcastView()
                {
                    Jan = (CommonFunctions.ToDouble(Jan.GetAttribute("value"))),
                    Feb = (CommonFunctions.ToDouble(Feb.GetAttribute("value"))),
                    Mar = (CommonFunctions.ToDouble(Mar.GetAttribute("value"))),
                    Apr = (CommonFunctions.ToDouble(Apr.GetAttribute("value"))),
                    May = (CommonFunctions.ToDouble(May.GetAttribute("value"))),
                    Jun = (CommonFunctions.ToDouble(Jun.GetAttribute("value"))),
                    Jul = (CommonFunctions.ToDouble(Jul.GetAttribute("value"))),
                    Aug = (CommonFunctions.ToDouble(Aug.GetAttribute("value"))),
                    Sep = (CommonFunctions.ToDouble(Sep.GetAttribute("value"))),
                    Oct = (CommonFunctions.ToDouble(Oct.GetAttribute("value"))),
                    Nov = (CommonFunctions.ToDouble(Nov.GetAttribute("value"))),
                    Dec = (CommonFunctions.ToDouble(Dec.GetAttribute("value"))),
                    Total = (CommonFunctions.ToDouble(Total.GetAttribute("value")))
                };
                return data;
            }

        }

        public class AvgEE_ClRateFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='avgRate-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getAvgEE_ClRateFcastData()
            {
                CommonFunctions.AddTestStep("Get Avg (EE Cl) Rate Fcast Data", "Avg (EE Cl) Rate Fcast Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRate-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='avgRateTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = (CommonFunctions.ToDouble(Jan.GetAttribute("value"))),
                    Feb = (CommonFunctions.ToDouble(Feb.GetAttribute("value"))),
                    Mar = (CommonFunctions.ToDouble(Mar.GetAttribute("value"))),
                    Apr = (CommonFunctions.ToDouble(Apr.GetAttribute("value"))),
                    May = (CommonFunctions.ToDouble(May.GetAttribute("value"))),
                    Jun = (CommonFunctions.ToDouble(Jun.GetAttribute("value"))),
                    Jul = (CommonFunctions.ToDouble(Jul.GetAttribute("value"))),
                    Aug = (CommonFunctions.ToDouble(Aug.GetAttribute("value"))),
                    Sep = (CommonFunctions.ToDouble(Sep.GetAttribute("value"))),
                    Oct = (CommonFunctions.ToDouble(Oct.GetAttribute("value"))),
                    Nov = (CommonFunctions.ToDouble(Nov.GetAttribute("value"))),
                    Dec = (CommonFunctions.ToDouble(Dec.GetAttribute("value"))),
                    Total = (CommonFunctions.ToDouble(Total.GetAttribute("value")))
                };
                return data;
            }

        }

        public class TotalLaborDollarsFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='totalLaborDollars-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getTotalLaborDollarsFcastData()
            {
                CommonFunctions.AddTestStep("Get Total Labor Dollars Fcast Data", "Total Labor Dollars Fcast Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollars-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='totalLaborDollarsTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = (CommonFunctions.ToDouble(Jan.GetAttribute("value"))),
                    Feb = (CommonFunctions.ToDouble(Feb.GetAttribute("value"))),
                    Mar = (CommonFunctions.ToDouble(Mar.GetAttribute("value"))),
                    Apr = (CommonFunctions.ToDouble(Apr.GetAttribute("value"))),
                    May = (CommonFunctions.ToDouble(May.GetAttribute("value"))),
                    Jun = (CommonFunctions.ToDouble(Jun.GetAttribute("value"))),
                    Jul = (CommonFunctions.ToDouble(Jul.GetAttribute("value"))),
                    Aug = (CommonFunctions.ToDouble(Aug.GetAttribute("value"))),
                    Sep = (CommonFunctions.ToDouble(Sep.GetAttribute("value"))),
                    Oct = (CommonFunctions.ToDouble(Oct.GetAttribute("value"))),
                    Nov = (CommonFunctions.ToDouble(Nov.GetAttribute("value"))),
                    Dec = (CommonFunctions.ToDouble(Dec.GetAttribute("value"))),
                    Total = (CommonFunctions.ToDouble(Total.GetAttribute("value")))
                };
                return data;
            }

        }
    }
}
