﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;

namespace ISAS_Regression_Automation
{
    public class ForecastView_NonProductivePercent
    {

        public static void ClickFill()
        {
            By byFill = By.XPath("//*/input[@id='npPercentFillBtn']");
            CommonFunctions.ClickByJE(CommonFunctions.getElement(byFill));
        }

        public static void ClickQMIRS()
        {
            By byQMIRS = By.XPath("//*/input[@id='npQmirsBtn']");
            CommonFunctions.ClickByJE(CommonFunctions.getElement(byQMIRS));
        }

        public static void ClickPLUS()
        {
            By byPlus = By.XPath("//*/input[@id='npPlusBtn']");
            CommonFunctions.ClickByJE(CommonFunctions.getElement(byPlus));
        }

        public class QMIRS_NP_Percent
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistNpPct']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getQMIRS_NP_PercentData()
            {
                CommonFunctions.AddTestStep("Get QMIRS NP% Data", "QMIRS NP% Data");
                return CommonFunctions.getMonthlyData("//*/div[@id='divHistNpPct']", 2);
            }
        }

        public class PLUSAvgNP_Percent
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistPlusNpPct']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getPLUSAvgNP_PercentData()
            {
                CommonFunctions.AddTestStep("Get PLUS Avg NP% Data", "PLUS Avg NP% Data");
                return CommonFunctions.getMonthlyData("//*/div[@id='divHistPlusNpPct']", 2);
            }
        }

        public class NPPercentFcastExcludesCL
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='txtNonProductivePercent-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static void ModifyNPPercentFcastExcludesCLData(string data)
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='txtNonProductivePercent-1']"));
                CommonFunctions.SetText(Jan, data);
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='txtNonProductivePercent-2']"));
                CommonFunctions.SetText(Feb, data);
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='txtNonProductivePercent-3']"));
                CommonFunctions.SetText(Feb, data);
                DeptForecastMenu.clickSaveAndRecalc();
                CommonFunctions.WaitUntilPageIsAcive();
            }

            public static MonthlyForcastView getNPPercentFcastExcludesCLData()
            {
                CommonFunctions.AddTestStep("Get NP% Fcast Excludes CL Data", "NP% Fcast Excludes CL Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                return CommonFunctions.getMonthlyData("//*/div[@id='divNpPct']", 2);                
            }
        }

        public class NPHrsFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='npHrs-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getNPHrsFcastData()
            {
                CommonFunctions.AddTestStep("Get NP Hrs Fcast Data", "NP Hrs Fcast Data");
                return CommonFunctions.getMonthlyData("//*/div[@id='divNpHours']", 2);
            }
        }
    
    }
}
