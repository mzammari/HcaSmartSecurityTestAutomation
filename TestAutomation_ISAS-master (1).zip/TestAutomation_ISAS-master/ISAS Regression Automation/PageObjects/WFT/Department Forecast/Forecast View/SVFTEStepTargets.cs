﻿using DocumentFormat.OpenXml.Office2013.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using OpenQA.Selenium;
using RazorEngine.Compilation.ImpromptuInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ISAS_Regression_Automation
{
    public class SVFTEStepTargets
    {
        public static bool CompareMonthlyStepTargetsObjects(StepTargets objFirst, StepTargets objSecond)
        {
            bool result;
            return result =
                CommonFunctions.ToDouble(objFirst.Sun.GetAttribute("value")) == CommonFunctions.ToDouble(objSecond.Sun.GetAttribute("value")) &&
                CommonFunctions.ToDouble(objFirst.Mon.GetAttribute("value")) == CommonFunctions.ToDouble(objSecond.Mon.GetAttribute("value")) &&
                CommonFunctions.ToDouble(objFirst.Tue.GetAttribute("value")) == CommonFunctions.ToDouble(objSecond.Tue.GetAttribute("value")) &&
                CommonFunctions.ToDouble(objFirst.Wed.GetAttribute("value")) == CommonFunctions.ToDouble(objSecond.Wed.GetAttribute("value")) &&
                CommonFunctions.ToDouble(objFirst.Thur.GetAttribute("value")) == CommonFunctions.ToDouble(objSecond.Thur.GetAttribute("value")) &&
                CommonFunctions.ToDouble(objFirst.Fri.GetAttribute("value")) == CommonFunctions.ToDouble(objSecond.Fri.GetAttribute("value")) &&
                CommonFunctions.ToDouble(objFirst.Sat.GetAttribute("value")) == CommonFunctions.ToDouble(objSecond.Sat.GetAttribute("value"));
        }

        public static List<string> GetMonthlyStepTargetsDifferences(SvStepTargets objFirst, SvStepTargets objSecond)
        {
            CommonFunctions.AddTestStep("Get Monthly Step Targets Differences", "Monthly Step Targets Differences");
            var diff = new List<string>();

            void Check(string propertyName, string value1, string value2)
            {
                if (CommonFunctions.ToDouble(value1) != CommonFunctions.ToDouble(value2))
                {
                    diff.Add($"{propertyName}: {value1} != {value2}");
                }
            }

            Check("Sun", objFirst.Sun , objSecond.Sun);
            Check("Mon", objFirst.Mon , objSecond.Mon) ;
            Check("Tue", objFirst.Tue , objSecond.Tue) ;
            Check("Wed", objFirst.Wed , objSecond.Wed) ;
            Check("Thur", objFirst.Thur , objSecond.Thur) ;
            Check("Fri", objFirst.Fri , objSecond.Fri) ;
            Check("Sat", objFirst.Sat , objSecond.Sat) ;
            Check("From", objFirst.From , objSecond.From) ;
            Check("To", objFirst.To, objSecond.To) ;
            Check("Total", objFirst.Total , objSecond.Total) ;
            //Check("ProdFTEs", objFirst.ProdFTEs , objSecond.ProdFTEs) ;
            //Check("DayMix", objFirst.DayMix , objSecond.DayMix);
            return diff;
        }

        public static bool CompareMonthlyStepTargetsWithSpecificInput(StepTargets objFirst, string input)
        {
            bool result;
            return result =
                CommonFunctions.ToDouble(objFirst.Sun.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Mon.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Tue.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Wed.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Thur.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Fri.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Sat.GetAttribute("value")) == CommonFunctions.ToDouble(input);
        }

        public static bool CompareStepTargetsMondayToFridayWithSpecificInput(StepTargets objFirst, string input)
        {
            bool result;
            return result =
                CommonFunctions.ToDouble(objFirst.Mon.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Tue.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Wed.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Thur.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(objFirst.Fri.GetAttribute("value")) == CommonFunctions.ToDouble(input);
        }

        public static bool CompareStepTargetsWeekendWithSpecificInput(StepTargets objFirst, string input)
        {
            bool result;
            return result =
                CommonFunctions.ToDouble(objFirst.Sun.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&                
                CommonFunctions.ToDouble(objFirst.Sat.GetAttribute("value")) == CommonFunctions.ToDouble(input);
        }

        public static Dictionary<string, List<SvStepTargets>> GetAllMonthlyStepTargetsValues()
        {
            CommonFunctions.AddTestStep("Get All Monthly Step Targets Values", "All Monthly Step Targets Values");
            CommonFunctions.WaitUntilPageIsAcive();
            string[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
            var result = new Dictionary<string, List<SvStepTargets>>();
            foreach (var month in months)
            {
                result[month] = GetMonthlyStepTargetsValues(month);
            }
            return result;
        }

        public static Dictionary<string, List<StepTargets>> GetAllMonthlyStepTargetsElements()
        {
            CommonFunctions.AddTestStep("Get All Monthly Step Targets Elements", "All Monthly Step Targets Elements");
            CommonFunctions.WaitUntilPageIsAcive();
            string[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
            var result = new Dictionary<string, List<StepTargets>>();
            foreach (var month in months)
            {
                result[month] = GetMonthlyStepTargetsElements(month);
            }
            return result;
        }

        //private static SvStepTargets GetMonthlyStepTargets(string month)
        //{
        //    var monthNumber = GetMonthNumber(month); // Validate month and get month number
        //    var targetRow = CommonFunctions.getElement(By.XPath($"//*/tr[contains(@id,'target-{monthNumber}-')]"));            
        //    return new SvStepTargets
        //    {
        //        Add = targetRow.FindElement(By.XPath("td[1]/a")),
        //        Del = targetRow.FindElement(By.XPath("td[2]/a")),
        //        Copy = targetRow.FindElement(By.XPath("td[3]/a")),
        //        From = targetRow.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
        //        To = targetRow.FindElement(By.XPath("td[8]/input")).GetAttribute("value"),
        //        Sun = targetRow.FindElement(By.XPath("td[9]/input")).GetAttribute("value"),
        //        Mon = targetRow.FindElement(By.XPath("td[10]/input")).GetAttribute("value"),
        //        Tue = targetRow.FindElement(By.XPath("td[11]/input")).GetAttribute("value"),
        //        Wed = targetRow.FindElement(By.XPath("td[12]/input")).GetAttribute("value"),
        //        Thur = targetRow.FindElement(By.XPath("td[13]/input")).GetAttribute("value"),
        //        Fri = targetRow.FindElement(By.XPath("td[14]/input")).GetAttribute("value"),
        //        Sat = targetRow.FindElement(By.XPath("td[15]/input")).GetAttribute("value"),
        //        Total = targetRow.FindElement(By.XPath("td[16]/input")).GetAttribute("value"),
        //        ProdFTEs = targetRow.FindElement(By.XPath("td[18]/input")).GetAttribute("value"),
        //        DayMix = targetRow.FindElement(By.XPath("td[19]/input")).GetAttribute("value")
        //    };
        //}

        public static List<SvStepTargets> GetMonthlyStepTargetsValues(string month)
        {
            CommonFunctions.AddTestStep($"Get Monthly Step Targets Values for {month}", $"Monthly Step Targets Values for {month}");
            var result = new List<SvStepTargets>();
            var monthNumber = GetMonthNumber(month); // Validate month and get month number
            var targetRows = CommonFunctions.getElements(By.XPath($"//*/tr[contains(@id,'target-{monthNumber}-')]"));
            foreach (var targetRow in targetRows)
            {
                result.Add(new SvStepTargets
                { 
                    Add = targetRow.FindElement(By.XPath("td[1]/a")),
                    Del = targetRow.FindElement(By.XPath("td[2]/a")),
                    Copy = targetRow.FindElement(By.XPath("td[3]/a")),
                    From = targetRow.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
                    To = targetRow.FindElement(By.XPath("td[8]/input")).GetAttribute("value"),
                    Sun = targetRow.FindElement(By.XPath("td[9]/input")).GetAttribute("value"),
                    Mon = targetRow.FindElement(By.XPath("td[10]/input")).GetAttribute("value"),
                    Tue = targetRow.FindElement(By.XPath("td[11]/input")).GetAttribute("value"),
                    Wed = targetRow.FindElement(By.XPath("td[12]/input")).GetAttribute("value"),
                    Thur = targetRow.FindElement(By.XPath("td[13]/input")).GetAttribute("value"),
                    Fri = targetRow.FindElement(By.XPath("td[14]/input")).GetAttribute("value"),
                    Sat = targetRow.FindElement(By.XPath("td[15]/input")).GetAttribute("value"),
                    Total = targetRow.FindElement(By.XPath("td[16]/input")).GetAttribute("value"),
                    ProdFTEs = targetRow.FindElement(By.XPath("td[18]/input")).GetAttribute("value"),
                    DayMix = targetRow.FindElement(By.XPath("td[19]/input")).GetAttribute("value")
                });
            };
            return result;
        }

        public static List<StepTargets> GetMonthlyStepTargetsElements(string month)
        {
            CommonFunctions.AddTestStep($"Get Monthly Step Targets Elements for {month}", $"Monthly Step Targets Elements for {month}");
            var result = new List<StepTargets>();
            var monthNumber = GetMonthNumber(month); // Validate month and get month number
            var targetRows = CommonFunctions.getElements(By.XPath($"//*/tr[contains(@id,'target-{monthNumber}-')]"));
            foreach (var targetRow in targetRows)
            {
                result.Add(new StepTargets
                {
                    Add = targetRow.FindElement(By.XPath("td[1]/a")),
                    Del = targetRow.FindElement(By.XPath("td[2]/a")),
                    Copy = targetRow.FindElement(By.XPath("td[3]/a")),
                    From = targetRow.FindElement(By.XPath("td[7]/input")),
                    To = targetRow.FindElement(By.XPath("td[8]/input")),
                    Sun = targetRow.FindElement(By.XPath("td[9]/input")),
                    Mon = targetRow.FindElement(By.XPath("td[10]/input")),
                    Tue = targetRow.FindElement(By.XPath("td[11]/input")),
                    Wed = targetRow.FindElement(By.XPath("td[12]/input")),
                    Thur = targetRow.FindElement(By.XPath("td[13]/input")),
                    Fri = targetRow.FindElement(By.XPath("td[14]/input")),
                    Sat = targetRow.FindElement(By.XPath("td[15]/input")),
                    Total = targetRow.FindElement(By.XPath("td[16]/input")),
                    ProdFTEs = targetRow.FindElement(By.XPath("td[18]/input")),
                    DayMix = targetRow.FindElement(By.XPath("td[19]/input"))
                });
            }
            ;
            return result;
        }

        private static readonly Dictionary<string, int> monthMapping = new Dictionary<string, int>
        {
            { "Jan", 1 },
            { "Feb", 2 },
            { "Mar", 3 },
            { "Apr", 4 },
            { "May", 5 },
            { "Jun", 6 },
            { "Jul", 7 },
            { "Aug", 8 },
            { "Sep", 9 },
            { "Oct", 10 },
            { "Nov", 11 },
            { "Dec", 12 }
        };

        private static int GetMonthNumber(string month) => monthMapping.TryGetValue(month, out int monthNumber) ? monthNumber : throw new ArgumentException($"Invalid month: {month}");

        public static List<StepTargets> GetMonthlyStepTargets()
        {
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            List<StepTargets> stepTargets = new List<StepTargets>();
            IList<IWebElement> targetsRows = CommonFunctions.getElements(By.XPath("//*/tr[contains(@id,'target-')]"));
            foreach (IWebElement targetRow in targetsRows)
            {
                stepTargets.Add(new StepTargets
                {
                    Add = targetRow.FindElement(By.XPath("td[1]/a")),
                    Del = targetRow.FindElement(By.XPath("td[2]/a")),
                    Copy = targetRow.FindElement(By.XPath("td[3]/a")),
                    From = targetRow.FindElement(By.XPath("td[7]/input")),
                    To = targetRow.FindElement(By.XPath("td[8]/input")),
                    Sun = targetRow.FindElement(By.XPath("td[9]/input")),
                    Mon = targetRow.FindElement(By.XPath("td[10]/input")),
                    Tue = targetRow.FindElement(By.XPath("td[11]/input")),
                    Wed = targetRow.FindElement(By.XPath("td[12]/input")),
                    Thur = targetRow.FindElement(By.XPath("td[13]/input")),
                    Fri = targetRow.FindElement(By.XPath("td[14]/input")),
                    Sat = targetRow.FindElement(By.XPath("td[15]/input")),
                    Total = targetRow.FindElement(By.XPath("td[16]/input")),
                    ProdFTEs = targetRow.FindElement(By.XPath("td[18]/input")),
                    DayMix = targetRow.FindElement(By.XPath("td[19]/input"))
                });
            }
            return stepTargets;
        }

        public static List<StepTargetsWeekDays> GetStepTargetsWeekDays()
        {
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            List<StepTargetsWeekDays> stepTargetsWeekDays = new List<StepTargetsWeekDays>();
            IList<IWebElement> targetsRows = CommonFunctions.getElements(By.XPath("//*/tr[contains(@id,'target-')]"));
            foreach (IWebElement targetRow in targetsRows)
            {
                stepTargetsWeekDays.Add(new StepTargetsWeekDays()
                {
                    Sun = targetRow.FindElement(By.XPath("td[9]/input")),
                    Mon = targetRow.FindElement(By.XPath("td[10]/input")),
                    Tue = targetRow.FindElement(By.XPath("td[11]/input")),
                    Wed = targetRow.FindElement(By.XPath("td[12]/input")),
                    Thu = targetRow.FindElement(By.XPath("td[13]/input")),
                    Fri = targetRow.FindElement(By.XPath("td[14]/input")),
                    Sat = targetRow.FindElement(By.XPath("td[15]/input"))
                });
            }
            return stepTargetsWeekDays;
        }

        public static bool IsAt
        {
            get
            {
                Thread.Sleep(3000);
                string xpath = "//input[@id='txtTarget-1-1-from']";
                return CommonFunctions.IsElementDisplayed(xpath, 15);
            }
        }

        public static MonthlyForcastView getProdFtes()
        {
            bool bDisplayed;
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            IWebElement cmdProdFtex = CommonFunctions.getElement(By.XPath("//td[@id='ProdFtes']"));
            CommonFunctions.ClickByJE(cmdProdFtex);
            string selectedXpath = "//*/input[@id='txtFTE-1-1']";
            bDisplayed = CommonFunctions.IsElementDisplayed(selectedXpath, 5);
            if (bDisplayed)
            {
                var ProdFtesMix = CommonFunctions.getElement(By.XPath("//*/td[@id='ProdFtes']"));
                CommonFunctions.ClickByJE(ProdFtesMix);
                Thread.Sleep(2000);
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-1-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-2-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-3-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-4-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-5-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-6-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-7-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-8-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-9-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-10-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-11-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtFTE-12-') and contains(@class,'forecast-step-selected-indicator')]"));
                IWebElement Header = CommonFunctions.getElement(By.XPath("//*/td[@class='forecast-target-header' and contains(text(),'#')]"));

                Header.Click();
                Thread.Sleep(2000);
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    //Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                SaveStepTargets();
                return data;
            }
            else
            {
                SaveStepTargets();
                Console.WriteLine("Prod FTEs was not selected");
                return null;
            }
        }

        public static MonthlyForcastView getDayMix()
        {
            bool bDisplayed;
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            IWebElement cmdProdFtex = CommonFunctions.getElement(By.XPath("//td[@id='DayMix']"));
            CommonFunctions.ClickByJE(cmdProdFtex);
            string selectedXpath = "//*/input[@id='txtBusinessDayMix-1-1']";
            bDisplayed = CommonFunctions.IsElementDisplayed(selectedXpath, 5);
            if (bDisplayed)
            {
                var DayMix = CommonFunctions.getElement(By.XPath("//*/td[@id=\"DayMix\"]"));
                CommonFunctions.ClickByJE(DayMix);
                Thread.Sleep(2000);
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-1-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-2-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-3-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-4-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-5-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-6-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-7-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-8-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-9-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-10-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-11-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//input[contains(@id,'txtBusinessDayMix-12-') and contains(@class, 'forecast-step-selected-indicator')]"));
                IWebElement Header = CommonFunctions.getElement(By.XPath("//*/td[@class='forecast-target-header' and contains(text(),'#')]"));

                Header.Click();
                Thread.Sleep(2000);
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value"), 2),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value"), 2),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value"), 2),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value"), 2),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value"), 2),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value"), 2),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value"), 2),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value"), 2),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value"), 2),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value"), 2),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value"), 2),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value"), 2),
                    //Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                SaveStepTargets();
                return data;
            }
            else
            {
                SaveStepTargets();
                Console.WriteLine("Prod FTEs was not selected");
                return null;
            }
        }


        public static MonthlyForcastView getSVFTEStepTargetsData(string DailyValue)
        {
            IWebElement JanMon = CommonFunctions.getElement(By.XPath("//*/input[@id='txtTarget-1-1-0']"));
            CommonFunctions.ReplaceAndSetText(JanMon, DailyValue);
            IWebElement FebMon = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-2-1-1']"));
            CommonFunctions.ReplaceAndSetText(FebMon, "17");
            IWebElement MarMon = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-3-1-1']"));
            CommonFunctions.ReplaceAndSetText(MarMon, "5");
            //Fill values.
            IWebElement JanFill = CommonFunctions.getElement(By.XPath("//a[@id='stepTargetFillBtn-1-1']"));
            CommonFunctions.ClickByJE(JanFill);
            IWebElement FebFill = CommonFunctions.getElement(By.XPath("//a[@id='stepTargetFillBtn-2-1']"));
            CommonFunctions.ClickByJE(FebFill);
            IWebElement MarFill = CommonFunctions.getElement(By.XPath("//a[@id='stepTargetFillBtn-3-1']"));
            CommonFunctions.ClickByJE(MarFill);

            IWebElement Jan = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-1-1']"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-2-1']"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-3-1']"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-4-1']"));
            IWebElement May = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-5-1']"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-6-1']"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-7-1']"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-8-1']"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-9-1']"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-10-1']"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-11-1']"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-12-1']"));
            IWebElement Header = CommonFunctions.getElement(By.XPath("//*/td[@class='forecast-target-header' and contains(text(),'#')]"));

            Header.Click();
            Thread.Sleep(2000);
            var data = new MonthlyForcastView()
            {
                Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                //Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
            };
            SaveStepTargets();
            return data;
        }

        public static void SaveStepTargets()
        {
            bool bExists;
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//*/div[contains(@aria-describedby,\"steps-dialog\")]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Save']"));
            CommonFunctions.ClickByJE(cmdSave);
            string confirmSave = "//*/div[@aria-describedby=\"save-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            bExists = CommonFunctions.IsElementDisplayed(confirmSave, 5);
            if (bExists)
            {
                IWebElement cmdConfirmSave = CommonFunctions.getElement(By.XPath(confirmSave));
                CommonFunctions.ClickByJE(cmdConfirmSave);
            }
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static void CancelStepTargets()
        {
            bool bExists;
            IWebElement cmdCancel = CommonFunctions.getElement(By.XPath("//*/div[contains(@aria-describedby,\"steps-dialog\")]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Cancel']"));
            CommonFunctions.ClickByJE(cmdCancel);
            string confirmSave = "//*/div[@aria-describedby=\"action-confirm\"]//button[text()='Yes']";
            bExists = CommonFunctions.IsElementDisplayed(confirmSave, 5);
            if (bExists)
            {
                IWebElement cmdConfirmSave = CommonFunctions.getElement(By.XPath(confirmSave));
                CommonFunctions.ClickByJE(cmdConfirmSave);
            }
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool VerifyAddRow()
        {
            int iCountBefor = 0;
            int iCountAfter = 0;
            bool isMatched, bExists;
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            IList<IWebElement> lstAddBefore = CommonFunctions.getElements(By.XPath("//*/div[@class='targetContent']//tr[contains(@id,'target')]//a[contains(@id,'lnkAddStep')]"));
            iCountBefor = lstAddBefore.Count;
            lstAddBefore[0].Click();
            IList<IWebElement> lstAddAfter = CommonFunctions.getElements(By.XPath("//*/div[@class='targetContent']//tr[contains(@id,'target')]//a[contains(@id,'lnkAddStep')]"));
            iCountAfter = lstAddAfter.Count;
            isMatched = iCountAfter != iCountBefor? true: false;
            CancelStepTargets();

            return isMatched;
        }

        public static bool VerifyDeleteRow()
        {
            int iCountBefor = 0;
            int iCountAfter = 0;
            bool isMatched, bExists;
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            //Add a row
            IList<IWebElement> lstAddBefore = CommonFunctions.getElements(By.XPath("//*/div[@class='targetContent']//tr[contains(@id,'target') and not(@style='display: none;')]//a[contains(@id,'lnkAddStep')]"));
            iCountBefor = lstAddBefore.Count;
            lstAddBefore[0].Click();
            //Delete a row
            IList<IWebElement> lstDeletebtn = CommonFunctions.getElements(By.XPath("//*/div[@class='targetContent']//tr[contains(@id,'target')]//a[contains(@id,'lnkDeleteStep')]"));
            lstDeletebtn[0].Click();
            

            string confirmDeleteXpath = "//*/div[@aria-describedby=\"delete-step-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            bExists = CommonFunctions.IsElementDisplayed(confirmDeleteXpath, 5);
            if (bExists)
            {
                IWebElement cmdConfirmDelete = CommonFunctions.getElement(By.XPath(confirmDeleteXpath));
                CommonFunctions.ClickByJE(cmdConfirmDelete);
            }
            Thread.Sleep(2000);
            IList<IWebElement> lstAddAfter = CommonFunctions.getElements(By.XPath("//*/div[@class='targetContent']//tr[contains(@id,'target') and not(@style='display: none;')]//a[contains(@id,'lnkAddStep')]"));
            iCountAfter = lstAddAfter.Count;
            isMatched = iCountAfter == iCountBefor ? true : false;
            CancelStepTargets();
            return isMatched;
        }

        public static void ClickRestPlusData()
        {
            //Reset to PLUS Data
            IWebElement cmdResetToPLUSData = CommonFunctions.getElement(By.XPath("//*/div[contains(@aria-describedby,\"steps-dialog\")]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Reset to PLUS Data']"));
            CommonFunctions.ClickByJE(cmdResetToPLUSData);
            CommonFunctions.IsElementDisplayed("//tr[@id='target-7-1']//input[@id='Text3']", 20);

        }

        public static bool VerifyCopyFunctionality()
        {
            bool bExists = false;
            bool isMatched = false;
            string testingValue = "20";
            //click on Edit button.
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            ClickRestPlusData();
            IWebElement JanMon = CommonFunctions.getElement(By.XPath("//*/input[@id='txtTarget-1-1-1']"));
            CommonFunctions.ReplaceAndSetText(JanMon, testingValue);
            IWebElement JanFill = CommonFunctions.getElement(By.XPath("//a[@id='stepTargetFillBtn-1-1']"));
            CommonFunctions.ClickByJE(JanFill);
            IList<IWebElement> lstCopybtn = CommonFunctions.getElements(By.XPath("//*/div[@class='targetContent']//tr[contains(@id,'target')]//a[contains(@id,'lnkCopyStep')]"));
            lstCopybtn[0].Click();
            string btnCopyXpath = "//*/div[@aria-describedby=\"copystep-dialog\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Copy']";
            bExists = CommonFunctions.IsElementDisplayed(btnCopyXpath, 5);
            if (bExists)
            {
                IWebElement cmdCopy = CommonFunctions.getElement(By.XPath(btnCopyXpath));
                Thread.Sleep(1000);
                CommonFunctions.ClickByJE(cmdCopy);
                Thread.Sleep(1000);
            }
           // Thread.Sleep(3000);
            IWebElement DecMon = CommonFunctions.getElement(By.XPath("//*/input[@id='txtTarget-12-1-1']"));
            double dDecValue = Convert.ToDouble(DecMon.GetAttribute("value"));
            isMatched = dDecValue == Convert.ToDouble(testingValue);
            SaveStepTargets();
            //Click Edit
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            DecMon = CommonFunctions.getElement(By.XPath("//*/input[@id='txtTarget-12-1-1']"));
            string Dec = DecMon.GetAttribute("value");
            //isMatched = Convert.ToDouble(Dec) == Convert.ToDouble(testingValue);
            Console.WriteLine($"{Convert.ToDouble(Dec)}\n" +
                $"{Convert.ToDouble(testingValue)}");
            CancelStepTargets();
            return isMatched;
        }

        public static string VerifyMaximumReachedForMonth()
        {
            bool bExists;
            string OkXpath, Jan3DayMixValue;
            //Click Edit
            ForecastView_Standards.PLUSStdSV_FTEs.Edit();
            ClickRestPlusData();
            CommonFunctions.IsElementDisplayed("//tr[@id='target-7-1']//input[@id='Text3']", 20);


            IList<IWebElement> lstAdd = CommonFunctions.getElements(By.XPath("//*/div[@class='targetContent']//tr[contains(@id,'target')]//a[contains(@id,'lnkAddStep')]"));
            //Click 5 times on add btn to get the error dialog.
            for(int i = 0;i < 5; i++)
            {
                lstAdd[0].Click();

            }
            //Error dialog.
            OkXpath = "//*/div[@aria-describedby=\"warn-cannot-add\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Ok']";
            IWebElement cmdOk = CommonFunctions.getElement(By.XPath(OkXpath));
            CommonFunctions.ClickByJE(cmdOk);

            IWebElement Jan1From = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-1-from']"));
            CommonFunctions.ReplaceAndSetText(Jan1From, "0");
            IWebElement Jan1To = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-1-to']"));
            CommonFunctions.ReplaceAndSetText(Jan1To, "100");
            IWebElement Jan2From = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-2-from']"));
            CommonFunctions.ReplaceAndSetText(Jan2From, "101");
            IWebElement Jan2To = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-2-to']"));
            CommonFunctions.ReplaceAndSetText(Jan2To, "200");
            IWebElement Jan3From = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-3-from']"));
            CommonFunctions.ReplaceAndSetText(Jan3From, "201");
            IWebElement Jan3To = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-3-to']"));
            CommonFunctions.ReplaceAndSetText(Jan3To, "500");
            IWebElement Jan4From = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-4-from']"));
            CommonFunctions.ReplaceAndSetText(Jan4From, "501");
            IWebElement Jan4To = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-4-to']"));
            CommonFunctions.ReplaceAndSetText(Jan4To, "700");
            IWebElement Jan5From = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-5-from']"));
            CommonFunctions.ReplaceAndSetText(Jan5From, "701");
            IWebElement Jan5To = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-5-to']"));
            CommonFunctions.ReplaceAndSetText(Jan5To, "999999");
            IWebElement Jan3Sun = CommonFunctions.getElement(By.XPath("//input[@id='txtTarget-1-3-0']"));
            CommonFunctions.ReplaceAndSetText(Jan3Sun, "56.00");
            Jan5To.Click();
            Thread.Sleep(1000);
            IWebElement Jan3DayMix = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-1-3' and contains(@class,'forecast-step')]"));
            CommonFunctions.ClickByJE(Jan3DayMix);
            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement Jan3SelectedDayMix = CommonFunctions.getElement(By.XPath("//input[@id='txtBusinessDayMix-1-3' and contains(@class,'forecast-step')]"));
            Thread.Sleep(2000);
            Jan3DayMixValue = Jan3SelectedDayMix.GetAttribute("value");
            SaveStepTargets();
            return Jan3DayMixValue;
        }

        public static CopyTargetRow GetCopyTargetRowToOtherMonths()
        {
            Thread.Sleep(2000);
            By byVisible = By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]");
            CommonFunctions.IsElementDisplayed(byVisible, 10);
            CommonFunctions.WaitUntilPageIsAcive();
            //IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month1' and not(@disabled)]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month2' and not(@disabled)]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month3' and not(@disabled)]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month4' and not(@disabled)]"));
            IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month5' and not(@disabled)]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month6' and not(@disabled)]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month7' and not(@disabled)]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month8' and not(@disabled)]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month9' and not(@disabled)]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month10' and not(@disabled)]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month11' and not(@disabled)]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='copystep-dialog']//form//table)[2]//input[@id='month12' and not(@disabled)]"));
            return new CopyTargetRow
            {
                //Jan = Jan,
                Feb = Feb,
                Mar = Mar,
                Apr = Apr,
                May = May,
                Jun = Jun,
                Jul = Jul,
                Aug = Aug,
                Sep = Sep,
                Oct = Oct,
                Nov = Nov,
                Dec = Dec
            };
        }

        public static void ClickMonths(CopyTargetRow row, params string[] months)
        {
            bool bExists;
            foreach (var month in months)
            {
                IWebElement monthElement = month switch
                {
                    "Jan" => throw new InvalidOperationException("Jan is the source month and cannot be selected in the copy dialog."),
                    "Feb" => row.Feb,
                    "Mar" => row.Mar,
                    "Apr" => row.Apr,
                    "May" => row.May,
                    "Jun" => row.Jun,
                    "Jul" => row.Jul,
                    "Aug" => row.Aug,
                    "Sep" => row.Sep,
                    "Oct" => row.Oct,
                    "Nov" => row.Nov,
                    "Dec" => row.Dec,
                    _ => throw new ArgumentException($"Invalid month: {month}")
                };
                CommonFunctions.ClickByJE(monthElement);
                Thread.Sleep(500);
            }
            By byBtnCopyXpath = By.XPath("//*/div[@aria-describedby='copystep-dialog']//div[@class='ui-dialog-buttonset']//button[normalize-space()='Copy']");
            bExists = CommonFunctions.IsElementDisplayed(byBtnCopyXpath, 5);
            if (bExists)
            {
                IWebElement cmdCopy = CommonFunctions.getElement(byBtnCopyXpath);
                Thread.Sleep(1000);
                CommonFunctions.ClickByJE(cmdCopy);
                Thread.Sleep(1000);
            }
        }

        private static void UncheckMonths(CopyTargetRow row, params string[] months)
        {
            bool bExists;
            foreach (var month in months)
            {
                IWebElement monthElement = month switch
                {
                    "Jan" => row.Jan,
                    "Feb" => row.Feb,
                    "Mar" => row.Mar,
                    "Apr" => row.Apr,
                    "May" => row.May,
                    "Jun" => row.Jun,
                    "Jul" => row.Jul,
                    "Aug" => row.Aug,
                    "Sep" => row.Sep,
                    "Oct" => row.Oct,
                    "Nov" => row.Nov,
                    "Dec" => row.Dec,
                    _ => throw new ArgumentException($"Invalid month: {month}")
                };
                CommonFunctions.ClickByJE(monthElement);
            }
        }

        public static void UncheckAllMonths(CopyTargetRow row)
        {
            UncheckMonths(row, "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
        }

        public static void AddStepTargetRows(List<StepTargets> stepTargets)
        {
            CommonFunctions.AddTestStep("Add Step Target Rows", "Step Target Rows Added");
            var expected = new[]
            {
                new { From = "0", To = "1" },
                new { From = "2", To = "3" },
                new { From = "4", To = "999999" },
            };


            for(int i =0; i< expected.Length; i++)
            {
                CommonFunctions.SetText(stepTargets[i].From, expected[i].From);
                CommonFunctions.SetText(stepTargets[i].To, expected[i].To);
                CommonFunctions.SetText(stepTargets[i].Sun, CommonFunctions.GenerateSmallRandonNumber());
                CommonFunctions.SetText(stepTargets[i].Mon, CommonFunctions.GenerateSmallRandonNumber());
                CommonFunctions.SetText(stepTargets[i].Tue, CommonFunctions.GenerateSmallRandonNumber());
                CommonFunctions.SetText(stepTargets[i].Wed, CommonFunctions.GenerateSmallRandonNumber());
                CommonFunctions.SetText(stepTargets[i].Thur, CommonFunctions.GenerateSmallRandonNumber());
                CommonFunctions.SetText(stepTargets[i].Fri, CommonFunctions.GenerateSmallRandonNumber());
                CommonFunctions.SetText(stepTargets[i].Sat, CommonFunctions.GenerateSmallRandonNumber());
            }
        }
    }

    public class CopyTargetRow
    {
        public IWebElement Jan { get; set; }
        public IWebElement Feb { get; set; }
        public IWebElement Mar { get; set; }
        public IWebElement Apr { get; set; }
        public IWebElement May { get; set; }
        public IWebElement Jun { get; set; }
        public IWebElement Jul { get; set; }
        public IWebElement Aug { get; set; }
        public IWebElement Sep { get; set; }
        public IWebElement Oct { get; set; }
        public IWebElement Nov { get; set; }
        public IWebElement Dec { get; set; }
    }
}
