﻿using OpenQA.Selenium;
using System.Collections.Generic;
using System.Threading;

namespace ISAS_Regression_Automation
{
    public class ProductiveMinFTEs
    {

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/div[@aria-describedby=\"minftes-dialog\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Cancel']";
                return CommonFunctions.IsElementDisplayed(xpath, 30);
            }
        }

        public static MonthlyForcastView getByDayofWeekPerMonth(string MonthlyValue)
        {
            bool bExists;
            SelectTimeInterval("By Day of Week per Month");

            IWebElement Sun = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[@class='num int3dec3 min-hrs-default min-hrs-sun']"));
            CommonFunctions.SetText(Sun, MonthlyValue);
            IWebElement Mon = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[@class='num int3dec3 min-hrs-default min-hrs-mon']"));
            CommonFunctions.SetText(Mon, MonthlyValue);
            IWebElement Tue = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[@class='num int3dec3 min-hrs-default min-hrs-tue']"));
            CommonFunctions.SetText(Tue, MonthlyValue);
            IWebElement Wed = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[@class='num int3dec3 min-hrs-default min-hrs-wed']"));
            CommonFunctions.SetText(Wed, MonthlyValue);
            IWebElement Thu = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[@class='num int3dec3 min-hrs-default min-hrs-thu']"));
            CommonFunctions.SetText(Thu, MonthlyValue);
            IWebElement Fri = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[@class='num int3dec3 min-hrs-default min-hrs-fri']"));
            CommonFunctions.SetText(Fri, MonthlyValue);
            IWebElement Sat = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[@class='num int3dec3 min-hrs-default min-hrs-sat']"));
            CommonFunctions.SetText(Sat, MonthlyValue);

            IWebElement cmdresetAllMonthlyMinHoursToDefault = CommonFunctions.getElement(By.XPath("//*/button[@id='resetAllMonthlyMinHoursToDefaultBtn']"));
            CommonFunctions.ClickByJE(cmdresetAllMonthlyMinHoursToDefault);

            string confirmXpath = "//*/div[contains(@aria-labelledby,'ui-dialog-title-reset-all-months-min-hrs-confirm')]//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='Yes']/parent::button";
            bExists = CommonFunctions.IsElementDisplayed(confirmXpath, 3);
            if(bExists)
            {
                IWebElement cmdConfirm = CommonFunctions.getElement(By.XPath(confirmXpath));
                CommonFunctions.ClickByJE(cmdConfirm);
            }

            IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[0].ProductiveMin')]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[1].ProductiveMin')]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[2].ProductiveMin')]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[3].ProductiveMin')]"));
            IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[4].ProductiveMin')]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[5].ProductiveMin')]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[6].ProductiveMin')]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[7].ProductiveMin')]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[8].ProductiveMin')]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[9].ProductiveMin')]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[10].ProductiveMin')]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[11].ProductiveMin')]"));
            // IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='contractLaborDollarsTotal']"));
            
            var data = new MonthlyForcastView()
            {
                
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value"))
                //Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
            };
            saveByDay();
            return data;
        }

        public static MonthlyForcastView SetDayInDayofWeekPerMonth(IWebElement Eelement, string MonthlyValue)
        {
            bool bExists;
            SelectTimeInterval("By Day of Week per Month");
            
            IWebElement Mon = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[@class='num int3dec3 min-hrs-default min-hrs-mon']"));
            CommonFunctions.SetText(Eelement, MonthlyValue);

            IWebElement cmdresetAllMonthlyMinHoursToDefault = CommonFunctions.getElement(By.XPath("//*/button[@id='resetAllMonthlyMinHoursToDefaultBtn']"));
            CommonFunctions.ClickByJE(cmdresetAllMonthlyMinHoursToDefault);

            string confirmXpath = "//*/div[contains(@aria-labelledby,'ui-dialog-title-reset-all-months-min-hrs-confirm')]//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='Yes']/parent::button";
            bExists = CommonFunctions.IsElementDisplayed(confirmXpath, 3);
            if (bExists)
            {
                IWebElement cmdConfirm = CommonFunctions.getElement(By.XPath(confirmXpath));
                CommonFunctions.ClickByJE(cmdConfirm);
            }

            IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[0].ProductiveMin')]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[1].ProductiveMin')]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[2].ProductiveMin')]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[3].ProductiveMin')]"));
            IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[4].ProductiveMin')]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[5].ProductiveMin')]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[6].ProductiveMin')]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[7].ProductiveMin')]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[8].ProductiveMin')]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[9].ProductiveMin')]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[10].ProductiveMin')]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[11].ProductiveMin')]"));
            // IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='contractLaborDollarsTotal']"));

            var data = new MonthlyForcastView()
            {

                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value"))
                //Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
            };
            saveByDay();
            return data;
        }

        /// <summary>
        /// Change the monthly value in the Productive Min FTEs dialog
        /// </summary>
        /// <param name="MonthlyValue"></param>
        /// <returns></returns>
        public static MonthlyForcastView getMonthlyMinHrs(string MonthlyValue)
        {
            bool bExists = false;
            SelectTimeInterval("By Day of Week per Month");
            //Tick all checkboxes.
            IList<IWebElement> lstMonthCheckbox = CommonFunctions.getElements(By.XPath("(//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//div)[3]/table//input[@type='checkbox']"));
            foreach(var chk in lstMonthCheckbox)
            {
                if(!chk.Selected)
                { 
                    chk.Click();
                }
            }

            IWebElement JanHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[0].MinHoursSun')]"));
            IWebElement FebHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[1].MinHoursSun')]"));
            IWebElement MarHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[2].MinHoursSun')]"));
            IWebElement AprHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[3].MinHoursSun')]"));
            IWebElement MayHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[4].MinHoursSun')]"));
            IWebElement JunHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[5].MinHoursSun')]"));
            IWebElement JulHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[6].MinHoursSun')]"));
            IWebElement AugHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[7].MinHoursSun')]"));
            IWebElement SepHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[8].MinHoursSun')]"));
            IWebElement OctHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[9].MinHoursSun')]"));
            IWebElement NovHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[10].MinHoursSun')]"));
            IWebElement DecHrs = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[11].MinHoursSun')]"));

            CommonFunctions.SetText(JanHrs, MonthlyValue);
            CommonFunctions.SetText(FebHrs, MonthlyValue);
            CommonFunctions.SetText(MarHrs, MonthlyValue);
            CommonFunctions.SetText(AprHrs, MonthlyValue);
            CommonFunctions.SetText(MayHrs, MonthlyValue);
            CommonFunctions.SetText(JunHrs, MonthlyValue);
            CommonFunctions.SetText(JulHrs, MonthlyValue);
            CommonFunctions.SetText(AugHrs, MonthlyValue);
            CommonFunctions.SetText(SepHrs, MonthlyValue);
            CommonFunctions.SetText(OctHrs, MonthlyValue);
            CommonFunctions.SetText(NovHrs, MonthlyValue);
            CommonFunctions.SetText(DecHrs, MonthlyValue);

            IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[0].ProductiveMin')]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[1].ProductiveMin')]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[2].ProductiveMin')]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[3].ProductiveMin')]"));
            IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[4].ProductiveMin')]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[5].ProductiveMin')]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[6].ProductiveMin')]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[7].ProductiveMin')]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[8].ProductiveMin')]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[9].ProductiveMin')]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[10].ProductiveMin')]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//div[@id='minHoursByDayOfWeekPerMonth']//input[contains(@data-bind,'[11].ProductiveMin')]"));
            // IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='contractLaborDollarsTotal']"));

            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value"))
                //Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
            };

            saveByDay();
            return data;
        }

        public static List<WeeklyElements> getByDayOfWeekPerMonth_Months()        
        {
            Thread.Sleep(5000);
            CommonFunctions.WaitUntilPageIsAcive();
            List<WeeklyElements> weeklyElements = new List<WeeklyElements>();
            IList<IWebElement> lstWeeklyData = CommonFunctions.getElements(By.XPath("//*/tr[@id=\"defaultMinHoursValuesToBeSet\"]"));
            foreach(var row in  lstWeeklyData)
            {
                weeklyElements.Add(new WeeklyElements()
                {
                    Sun = row.FindElement(By.XPath("td//input[@day='1']")),
                    Mon = row.FindElement(By.XPath("td//input[@day='2']")),
                    Tue = row.FindElement(By.XPath("td//input[@day='3']")),
                    Wed = row.FindElement(By.XPath("td//input[@day='4']")),
                    Thu = row.FindElement(By.XPath("td//input[@day='5']")),
                    Fri = row.FindElement(By.XPath("td//input[@day='6']")),
                    Sat = row.FindElement(By.XPath("td//input[@day='7']")),
                    ProdMinFTEs = row.FindElement(By.XPath("td//input[@class='num int3dec3 dec3 min-hrs-prod-ftes']"))
                });
            }
            return weeklyElements;
        }

        public static bool CompareMonToFriObjectsAgainstValue(WeeklyElements firstObj, string input)
        {
            bool ismatched;
            return ismatched =
                CommonFunctions.ToDouble(firstObj.Mon.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Tue.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Wed.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Thu.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Fri.GetAttribute("value")) == CommonFunctions.ToDouble(input);
               
        }

        public static bool CompareWeeklyObjectAgainstInput(WeeklyElements firstObj, string input)
        {
            bool ismatched;
            return ismatched =
                CommonFunctions.ToDouble(firstObj.Sun.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Mon.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Tue.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Wed.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Thu.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Fri.GetAttribute("value")) == CommonFunctions.ToDouble(input) &&
                CommonFunctions.ToDouble(firstObj.Sat.GetAttribute("value")) == CommonFunctions.ToDouble(input);
        }

        public static WeeklyElements getByDayOfWeekPerMonth_DefaultToBeSet()
        {            
            return new WeeklyElements()
            {
                Sun = CommonFunctions.getElement(By.XPath("//*/tr[@id='defaultMinHoursValuesToBeSet']//td//input[@day='1']")),
                Mon = CommonFunctions.getElement(By.XPath("//*/tr[@id='defaultMinHoursValuesToBeSet']//td//input[@day='2']")),
                Tue = CommonFunctions.getElement(By.XPath("//*/tr[@id='defaultMinHoursValuesToBeSet']//td//input[@day='3']")),
                Wed = CommonFunctions.getElement(By.XPath("//*/tr[@id='defaultMinHoursValuesToBeSet']//td//input[@day='4']")),
                Thu = CommonFunctions.getElement(By.XPath("//*/tr[@id='defaultMinHoursValuesToBeSet']//td//input[@day='5']")),
                Fri = CommonFunctions.getElement(By.XPath("//*/tr[@id='defaultMinHoursValuesToBeSet']//td//input[@day='6']")),
                Sat = CommonFunctions.getElement(By.XPath("//*/tr[@id='defaultMinHoursValuesToBeSet']//td//input[@day='7']")),
                ProdMinFTEs = CommonFunctions.getElement(By.XPath("//*/tr[@id='defaultMinHoursValuesToBeSet']//td//input[@class='num min-hrs-prod-ftes-default']"))
            };
        }

        public static MonthElements getByDayMinHrs()
        {
            SelectTimeInterval("By Day");
            return new MonthElements()
            {
                Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='1']")),
                Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='2']")),
                Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='3']")),
                Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='4']")),
                May = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='5']")),
                Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='6']")),
                Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='7']")),
                Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='8']")),
                Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='9']")),
                Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='10']")),
                Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='11']")),
                Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='byDay']//input[@month='12']"))
            };
        }

        public static MonthlyForcastView getByDay(double MinHrsValue)
        {
            SelectTimeInterval("By Day");
            //SetText and double-click
            IWebElement JanMinHrs = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'by-day')])[1]"));
            CommonFunctions.SetText(JanMinHrs, MinHrsValue.ToString());
            //Insert value and double-click
            CommonFunctions.DoubleClickUsingWebElement(JanMinHrs);
            saveByDay();
            ForecastView_Standards.ProductiveMinFTEs.Edit();
            var bExists = ProductiveMinFTEs.IsAt;
            //Reopen the dialog 
            SelectTimeInterval("By Day");

            IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[1]"));
            IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[2]"));
            IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[3]"));
            IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[4]"));
            IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[5]"));
            IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[6]"));
            IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[7]"));
            IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[8]"));
            IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[9]"));
            IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[10]"));
            IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[11]"));
            IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='byDay']//input[contains(@class,'min-hrs-prod-ftes')])[12]"));

            var data = new MonthlyForcastView()
            {
                Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
            };
            CancelByDay();
            return data;
        }

        public static void SelectTimeInterval(string Value)
        {
            bool bExists = false;
            IWebElement mnuDefineMinHours = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby='minftes-dialog']//select[@id='minHoursChoiceList']"));
            CommonFunctions.SelectElementByValue(mnuDefineMinHours, Value);
            //CommonFunctions.SelectElementByIndex(mnuDefineMinHours, 2);
            string yesXpath = "//*/div[@aria-describedby=\"reset-all-months-min-hrs-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            bExists = CommonFunctions.IsElementDisplayed(yesXpath, 2);
            if (bExists)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(yesXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }
            string ConfirmChangeXpath = "//*/div[@aria-describedby=\"min-hrs-choice-change-from-mon-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            bExists = CommonFunctions.IsElementDisplayed(ConfirmChangeXpath, 2);
            if (bExists)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmChangeXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }
            CommonFunctions.WaitUntilPageIsAcive();
        }
        
        public static void CancelByDay()
        {
            bool bExist;
            CommonFunctions.WaitUntilPageIsAcive();
            string CancelXpath = "//*/div[@aria-describedby=\"minftes-dialog\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Cancel']";
            for(int i=0; i<3; i++)
            {
                bExist = CommonFunctions.IsElementDisplayed(CancelXpath, 1);
                if (bExist)
                {
                    Thread.Sleep(1000);
                    IWebElement cmdCancel = CommonFunctions.getElement(By.XPath(CancelXpath));
                    CommonFunctions.ClickByJE(cmdCancel);
                }
                else
                {
                    break;
                }
                

            }
            
        }
        
        public static void saveByDay()
        {
            Thread.Sleep(5000);
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby=\"minftes-dialog\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Save']"));
            CommonFunctions.ClickByJE(cmdSave);
            Thread.Sleep(1000);
            string confirmSave = "//*/div[@aria-describedby=\"save-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            var bExists = CommonFunctions.IsElementDisplayed(confirmSave, 5);
            if (bExists)
            {
                IWebElement cmdConfirmSave = CommonFunctions.getElement(By.XPath(confirmSave));
                CommonFunctions.ClickByJE(cmdConfirmSave);
                CommonFunctions.WaitUntilPageIsAcive();
            }
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static double getByDayOfWeek(string WeeklyValue)
        {

            SelectTimeInterval("By Day of Week");
            bool bExists = false;
            string ProdMinFTEsValue;

            IWebElement Sun = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[contains(@class,'min-hrs-sun')]"));
            CommonFunctions.SetText(Sun, WeeklyValue);
            IWebElement Mon = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[contains(@class,'min-hrs-mon')]"));
            CommonFunctions.SetText(Mon, WeeklyValue);
            IWebElement Tue = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[contains(@class,'min-hrs-tue')]"));
            CommonFunctions.SetText(Tue, WeeklyValue);
            IWebElement Wed = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[contains(@class,'min-hrs-wed')]"));
            CommonFunctions.SetText(Wed, WeeklyValue);
            IWebElement Thu = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[contains(@class,'min-hrs-thu')]"));
            CommonFunctions.SetText(Thu, WeeklyValue);
            IWebElement Fri = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[contains(@class,'min-hrs-fri')]"));
            CommonFunctions.SetText(Fri, WeeklyValue);
            IWebElement Sat = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[contains(@class,'min-hrs-sat')]"));
            CommonFunctions.SetText(Sat, WeeklyValue);

            IWebElement txtAllMonth = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[@value='All Months']"));  
            txtAllMonth.Click();
            Thread.Sleep(1000);

            IWebElement ProdMinFTEs = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursByDayOfWeek']//input[contains(@class,'min-hrs-prod-ftes')]"));
            ProdMinFTEsValue = ProdMinFTEs.GetAttribute("value");
            saveByDay();
            return CommonFunctions.ToDouble(ProdMinFTEsValue);
        }
    }
}
