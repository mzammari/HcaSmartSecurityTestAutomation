﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;

namespace ISAS_Regression_Automation
{
    public class ForecastView_PaidHrsAndFTEs
    {
        public class FcastEmplPaidHrs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='empPaidHrs-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getFcastEmplPaidHrsData()
            {
                CommonFunctions.AddTestStep("Get Fcast Empl Paid Hrs Data", "Fcast Empl Paid Hrs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='empPaidHrs-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='emplPaidHrsTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class FcastTotalPaidHrs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='totalPaidHrs-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getFcastTotalPaidHrsData()
            {
                CommonFunctions.AddTestStep("Get Fcast Total Paid Hrs Data", "Fcast Total Paid Hrs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrs-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidHrsTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class FcastTotalPaidFTEs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='totalPaidFtes-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getFcastTotalPaidFTEsData()
            {
                CommonFunctions.AddTestStep("Get Fcast Total Paid FTEs Data", "Fcast Total Paid FTEs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtes-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='totalPaidFtesTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

        }

        public class QMIRSTotalPaidFTEs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getQMIRSTotalPaidFTEsData()
            {
                CommonFunctions.AddTestStep("Get QMIRS Total Paid FTEs Data", "QMIRS Total Paid FTEs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalPaidFtes']//input[13]"));
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }
        }
    }
}
