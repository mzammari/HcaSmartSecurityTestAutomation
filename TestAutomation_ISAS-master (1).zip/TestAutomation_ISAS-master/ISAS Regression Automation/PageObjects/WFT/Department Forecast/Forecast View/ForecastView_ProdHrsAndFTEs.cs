﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class ForecastView_ProdHrsAndFTEs
    {
        public class FcastTotalProdHrs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='totalProdHrs-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getFcastTotalProdHrsData()
            {
                CommonFunctions.AddTestStep("Get Fcast Total Prod Hrs Data", "Fcast Total Prod Hrs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrs-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdHrsTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class FcastTotalProdFtes
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='totalProdFtes-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getFcastTotalProdFtesData()
            {
                CommonFunctions.AddTestStep("Get Fcast Total Prod Ftes Data", "Fcast Total Prod Ftes Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtes-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='totalProdFtesTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class FcastEmplProdHrs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='emplProdHrs-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getFcastEmplProdHrsData()
            {
                CommonFunctions.AddTestStep("Get Fcast Empl Prod Hrs Data", "Fcast Empl Prod Hrs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrs-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='emplProdHrsTotal']"));
                
                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class QMIRSTotalProdFTEs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistTotalProdFtes']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getQMIRSTotalProdFTEsData()
            {
                CommonFunctions.AddTestStep("Get QMIRS Total Prod FTEs Data", "QMIRS Total Prod FTEs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistTotalProdFtes']//input[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

        }
    }
}
