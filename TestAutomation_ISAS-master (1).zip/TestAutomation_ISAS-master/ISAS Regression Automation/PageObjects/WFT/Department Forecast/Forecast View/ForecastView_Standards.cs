﻿using System;
using AutomationCoreLite.Reporting;
using DocumentFormat.OpenXml.Office.Word;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class ForecastView_Standards
    {
        public class ProductiveMinFTEs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='txtProdMinFtes-3']");
                CommonFunctions.DoubleClickMonth(Mar);
                CommonFunctions.AddTestStep("Double-click on the March cell", "The cell is enabled and clickable");
            }

            public static void Edit()
            {
                string EditXpath = "//*/a[@id='prodMinFtesEditBtn']";
                bool bExist = false;
                bExist = CommonFunctions.IsElementDisplayed(EditXpath, 5);
                if (bExist)
                {
                    IWebElement cmdEdit = CommonFunctions.getElement(By.XPath(EditXpath));
                    CommonFunctions.ClickByJE(cmdEdit);
                    CommonFunctions.AddTestStep("Click on the edit button", "The edit button is enabled.");
                }
            }

            public static MonthlyForcastView getProductiveMinFTEsData()
            {
                CommonFunctions.AddTestStep("Get Productive Min FTEs Data", "Productive Min FTEs Data");
                string ProductiveMinFtesXpath = "//*/div[@id='divProductiveMinFtes']";
                return (CommonFunctions.getMonthlyData(ProductiveMinFtesXpath, 2));
            }

        }

        public class PLUSStdSV_FTEs
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='txtSemiVariable-3']");
                CommonFunctions.DoubleClickMonth(Mar);
                CommonFunctions.AddTestStep("Double-click on the March cell", "The cell is enabled and clickable");
            }

            public static void Edit()
            {
                string xpath = "//*/a[@name='Step Targets']";
                bool bDisplayed = CommonFunctions.IsElementDisplayed(xpath, 20);
                if(bDisplayed)
                {
                    IWebElement cmdEdit = CommonFunctions.getElement(By.XPath(xpath));
                    CommonFunctions.ClickByJE(cmdEdit);
                    CommonFunctions.AddTestStep("Click on the edit button", "The edit button is enabled.");
                }               
            }

            public static MonthlyForcastView getPLUSStdSV_FTEsData()
            {
                CommonFunctions.AddTestStep("Get PLUS Std SV FTEs Data", "PLUS Std SV FTEs Data");                
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariable-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='txtSemiVariableTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = Convert.ToDouble(Jan.GetAttribute("value")),
                    Feb = Convert.ToDouble(Feb.GetAttribute("value")),
                    Mar = Convert.ToDouble(Mar.GetAttribute("value")),
                    Apr = Convert.ToDouble(Apr.GetAttribute("value")),
                    May = Convert.ToDouble(May.GetAttribute("value")),
                    Jun = Convert.ToDouble(Jun.GetAttribute("value")),
                    Jul = Convert.ToDouble(Jul.GetAttribute("value")),
                    Aug = Convert.ToDouble(Aug.GetAttribute("value")),
                    Sep = Convert.ToDouble(Sep.GetAttribute("value")),
                    Oct = Convert.ToDouble(Oct.GetAttribute("value")),
                    Nov = Convert.ToDouble(Nov.GetAttribute("value")),
                    Dec = Convert.ToDouble(Dec.GetAttribute("value")),
                    Total = Convert.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }

        }

        public class FcastProdHrsUOS
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='prodHrsPerUos-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getFcastProdHrsUOSData()
            {
                CommonFunctions.AddTestStep("Get Fcast Prod Hrs UOS Data", "Fcast Prod Hrs UOS Data");
                string FcastProdHrsUOSXpath = "//*/div[@id='divForecastProdHoursPerUos']";
                return (CommonFunctions.getMonthlyData(FcastProdHrsUOSXpath, 3));
            }

        }

        public class QMIRSProdHrsUOS
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistProdHoursPerUos']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static MonthlyForcastView getQMIRSProdHrsUOSData()
            {
                CommonFunctions.AddTestStep("Get QMIRS Prod Hrs UOS Data", "QMIRS Prod Hrs UOS Data");
                string QMIRSProdHrsUosXpath = "//*/div[@id='divHistProdHoursPerUos']";
                return (CommonFunctions.getMonthlyData(QMIRSProdHrsUosXpath, 2));
            }

        }

        public class FcastVarStd
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//input[@id='txtPlusVarStd-3']");
                CommonFunctions.DoubleClickMonth(Mar);
                CommonFunctions.AddTestStep("Double-click on the March cell", "The cell is enabled and clickable");
            }

            public static void ClickFill()
            {
                IWebElement cmdFill = CommonFunctions.getElement(By.XPath("//a[@id='plusVarStdFillBtn']"));
                cmdFill.Click();
            }

            public static void ClickPlus()
            {
                IWebElement cmdPlus = CommonFunctions.getElement(By.XPath("//a[@id='resetPlusVarStdBtn']"));
                cmdPlus.Click();
            }

            public static void ClickQUMRIS()
            {
                IWebElement cmdQ = CommonFunctions.getElement(By.XPath("//a[@id='qmirsVarStdFill']"));
                cmdQ.Click();
            }

            public static void ClickSG()
            {
                IWebElement cmdSG = CommonFunctions.getElement(By.XPath("//a[@id='staffingGridVarStdFillBtn']"));
                cmdSG.Click();
            }

            public static bool isSgBold()
            {
                By sgBold =  By.XPath("//a[@id='staffingGridVarStdFillBtn' and contains(@style,'bold')]");
                return CommonFunctions.IsElementDisplayed(sgBold, 3);

            }
            public static bool isQumrisBold()
            {
                By QBold = By.XPath("//a[@id='qmirsVarStdFill' and contains(@style,'bold')]");
                return CommonFunctions.IsElementDisplayed(QBold, 3);

            }

            public static bool isPlusBold()
            {
                By PulsBold = By.XPath("//a[@id='resetPlusVarStdBtn' and contains(@style,'bold')]");
                return CommonFunctions.IsElementDisplayed(PulsBold, 3);

            }

            public static MonthlyForcastView getFcastVarStdData()
            {
                CommonFunctions.AddTestStep("Get Fcast Var Std Data", "Fcast Var Std Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                string FcastVarStdXpath = "//*/div[@id='divPlusVarStd']";
                return (CommonFunctions.getMonthlyData(FcastVarStdXpath, 3));
            }

            public static void EnterFirstMonth(string monthlyValue)
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//input[@id='txtPlusVarStd-1']"));
                CommonFunctions.SetText(Jan, monthlyValue);
                DeptForecastMenu.clickSaveAndRecalc();
            }
        }

        public class CyPLUSVarStd
        {
            public static MonthlyForcastView getCyPLUSVarStdData()
            {
                CommonFunctions.AddTestStep("Get Cy PLUS Var Std", "Cy PLUS Var StdData");
                string CyPLUSVarStdXpath = "//*/div[@id='divPlusVarStdNew']";
                return (CommonFunctions.getMonthlyData(CyPLUSVarStdXpath, 3));
            }
        }
    }
}
