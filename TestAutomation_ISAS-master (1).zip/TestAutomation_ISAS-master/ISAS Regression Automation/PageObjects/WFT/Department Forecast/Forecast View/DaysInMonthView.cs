﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DaysInMonthView
    {
        public class DaysInMonth
        {
            public int Jan { get; set; }
            public int Feb { get; set; }
            public int Mar { get; set; }
            public int Apr { get; set; }
            public int May { get; set; }
            public int Jun { get; set; }
            public int Jul { get; set; }
            public int Aug { get; set; }
            public int Sep { get; set; }
            public int Oct { get; set; }
            public int Nov { get; set; }
            public int Dec { get; set; }            
            public bool IsLeapYear { get; set; }
            
        }

        public static DaysInMonth GetDaysInMonth(string sYear)
        {
            
            int year = int.Parse(sYear);
            return new DaysInMonth()
            {
                Jan = DateTime.DaysInMonth(year, 1),
                Feb = DateTime.DaysInMonth(year, 2),
                Mar = DateTime.DaysInMonth(year, 3),
                Apr = DateTime.DaysInMonth(year, 4),
                May = DateTime.DaysInMonth(year, 5),
                Jun = DateTime.DaysInMonth(year, 6),
                Jul = DateTime.DaysInMonth(year, 7),
                Aug = DateTime.DaysInMonth(year, 8),
                Sep = DateTime.DaysInMonth(year, 9),
                Oct = DateTime.DaysInMonth(year, 10),
                Nov = DateTime.DaysInMonth(year, 11),
                Dec = DateTime.DaysInMonth(year, 12),
                IsLeapYear = DateTime.IsLeapYear(year),                
            };
        }
    }
}
