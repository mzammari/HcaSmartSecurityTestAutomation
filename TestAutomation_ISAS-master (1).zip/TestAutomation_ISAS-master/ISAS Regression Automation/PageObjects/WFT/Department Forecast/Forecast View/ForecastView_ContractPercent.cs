﻿using AutomationCoreLite.Reporting;
using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Spreadsheet;
using OpenQA.Selenium;
using System;
using System.Security.Permissions;
using System.Threading;
using static ISAS_Regression_Automation.AverageLaborRateCL;
using static ISAS_Regression_Automation.ForecastView_ProdHrsAndFTEs;

namespace ISAS_Regression_Automation
{
    public class ForecastView_ContractPercent
    {
        public static void Fill()
        {
            IWebElement cmdFill = CommonFunctions.getElement(By.XPath("//*/input[@id='clPercentFillBtn']"));
            CommonFunctions.ClickByJE(cmdFill);
        }

        public class QMIRS
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/div[@id='divHistContractPct']//input[3]");
                CommonFunctions.DoubleClickMonth(Mar);                
            }

            public static MonthElements QmirsRow()
            {
                return new MonthElements()
                {
                    Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[1]")),
                    Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[2]")),
                    Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[3]")),
                    Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[4]")),
                    May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[5]")),
                    Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[6]")),
                    Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[7]")),
                    Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[8]")),
                    Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[9]")),
                    Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[10]")),
                    Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[11]")),
                    Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[12]")),
                    Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[13]"))
                };
            }           

            public static MonthlyForcastView getQMIRSData()
            {
                CommonFunctions.AddTestStep("Get QMIRS Data", "Get QMIRS Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/div[@id='divHistContractPct']//input[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }
        }

        public class CLPercentFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='txtContractLaborPercent-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            }

            public static void SetMar(string value)
            {
                By byMar = By.XPath("//*/input[@id='txtContractLaborPercent-3']");                
                CommonFunctions.SetText(CommonFunctions.getElement(byMar), value);
                Thread.Sleep(1000);
            }

            public static MonthlyForcastView getCLPercentFcastData()
            {
                CommonFunctions.AddTestStep("get CL Percent Fcast Data", "CL Percent Fcast Data");
                Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
                return CommonFunctions.getMonthlyData("//*/div[@id='divClPct']", 2);
            }
        }

        public class CLHrsFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='clHrs-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            } 

            public static MonthlyForcastView getCLHrsFcastData()
            {
                CommonFunctions.AddTestStep("Get CL Hrs Fcast Data", "CL Hrs Fcast Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-1']"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-2']"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-3']"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-4']"));
                IWebElement May = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-5']"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-6']"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-7']"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-8']"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-9']"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-10']"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-11']"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrs-12']"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("//*/input[@id='clHrsTotal']"));
                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2),
                    Total = Math.Round(Convert.ToDouble(Total.GetAttribute("value")), 2)
                };
                return data;
            }

            private static MonthlyForcastView CalculateMonthlyCLHrsFcast()
            {
                //CL Hrs Fcast = Fcast Total Prod Hrs * (CL % fcast / 100.00)
                var FcastTotalProdHrsData = FcastTotalProdHrs.getFcastTotalProdHrsData();
                var CLPercentFcastData = CLPercentFcast.getCLPercentFcastData();
                var CLHrsFcastData = CLHrsFcast.getCLHrsFcastData();

                return new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(FcastTotalProdHrsData.Jan * (CLPercentFcastData.Jan / 100), 0),
                    Feb = CommonFunctions.ToDouble(FcastTotalProdHrsData.Feb * (CLPercentFcastData.Feb / 100), 0),
                    Mar = CommonFunctions.ToDouble(FcastTotalProdHrsData.Mar * (CLPercentFcastData.Mar / 100), 0),
                    Apr = CommonFunctions.ToDouble(FcastTotalProdHrsData.Apr * (CLPercentFcastData.Apr / 100), 0),
                    May = CommonFunctions.ToDouble(FcastTotalProdHrsData.May * (CLPercentFcastData.May / 100), 0),
                    Jun = CommonFunctions.ToDouble(FcastTotalProdHrsData.Jun * (CLPercentFcastData.Jun / 100), 0),
                    Jul = CommonFunctions.ToDouble(FcastTotalProdHrsData.Jul * (CLPercentFcastData.Jul / 100), 0),
                    Aug = CommonFunctions.ToDouble(FcastTotalProdHrsData.Aug * (CLPercentFcastData.Aug / 100), 0),
                    Sep = CommonFunctions.ToDouble(FcastTotalProdHrsData.Sep * (CLPercentFcastData.Sep / 100), 0),
                    Oct = CommonFunctions.ToDouble(FcastTotalProdHrsData.Oct * (CLPercentFcastData.Oct / 100), 0),
                    Nov = CommonFunctions.ToDouble(FcastTotalProdHrsData.Nov * (CLPercentFcastData.Nov / 100), 0),
                    Dec = CommonFunctions.ToDouble(FcastTotalProdHrsData.Dec * (CLPercentFcastData.Dec / 100), 0),
                    Total = CommonFunctions.ToDouble(FcastTotalProdHrsData.Total * (CLPercentFcastData.Total / 100), 0)
                };
            }

            public static bool VerifyCLHrsFcastCalculation()
            {
                var CLHrsFcastData = getCLHrsFcastData();
                var CalculateMonthlyCLHrsFcastData = CalculateMonthlyCLHrsFcast();

               return  CommonFunctions.CompareDataObjects(CLHrsFcastData, CalculateMonthlyCLHrsFcastData);
            }
        }
        
        public class ClFtesFcast
        {
            public static void DoubleClickMar()
            {
                By Mar = By.XPath("//*/input[@id='txtclFtesFixed-3']");
                CommonFunctions.DoubleClickMonth(Mar);
            } 

            public static MonthlyForcastView getClFtesFcastData()
            {
                CommonFunctions.AddTestStep("Get Cl Ftes Fcast Data", "Cl Ftes Fcast Data");
                return CommonFunctions.getMonthlyData("//*/div[@id='divClFtes']", 2);
            }

            private static MonthlyForcastView CalculateMonthlyClFtesFcast()
            {
                //CL FTEs fcast = CL Hrs Fcast / (40 / 7) / number of days in that month
                string nextYear = CommonFunctions.GetNextYear();
                var CLHrsFcastData = CLHrsFcast.getCLHrsFcastData();
                var DaysInMonthData = DaysInMonthView.GetDaysInMonth(nextYear);
                return new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(CLHrsFcastData.Jan / (40.0 / 7.0) / DaysInMonthData.Jan, 2),
                    Feb = CommonFunctions.ToDouble(CLHrsFcastData.Feb / (40.0 / 7.0) / DaysInMonthData.Feb, 2),
                    Mar = CommonFunctions.ToDouble(CLHrsFcastData.Mar / (40.0 / 7.0) / DaysInMonthData.Mar, 2),
                    Apr = CommonFunctions.ToDouble(CLHrsFcastData.Apr / (40.0 / 7.0) / DaysInMonthData.Apr, 2),
                    May = CommonFunctions.ToDouble(CLHrsFcastData.May / (40.0 / 7.0) / DaysInMonthData.May, 2),
                    Jun = CommonFunctions.ToDouble(CLHrsFcastData.Jun / (40.0 / 7.0) / DaysInMonthData.Jun, 2),
                    Jul = CommonFunctions.ToDouble(CLHrsFcastData.Jul / (40.0 / 7.0) / DaysInMonthData.Jul, 2),
                    Aug = CommonFunctions.ToDouble(CLHrsFcastData.Aug / (40.0 / 7.0) / DaysInMonthData.Aug, 2),
                    Sep = CommonFunctions.ToDouble(CLHrsFcastData.Sep / (40.0 / 7.0) / DaysInMonthData.Sep, 2),
                    Oct = CommonFunctions.ToDouble(CLHrsFcastData.Oct / (40.0 / 7.0) / DaysInMonthData.Oct, 2),
                    Nov = CommonFunctions.ToDouble(CLHrsFcastData.Nov / (40.0 / 7.0) / DaysInMonthData.Nov, 2),
                    Dec = CommonFunctions.ToDouble(CLHrsFcastData.Dec / (40.0 / 7.0) / DaysInMonthData.Dec, 2),
                    Total = CommonFunctions.ToDouble(CLHrsFcastData.Total / (40.0 / 7.0) / CommonFunctions.IsLeapYear(), 2)
                };
            }

            public static bool VerifyClFtesFcastCalculation()
            {
                var ClFtesFcastData = getClFtesFcastData();
                var CalculateMonthlyClFtesFcastData = CalculateMonthlyClFtesFcast();
                return CommonFunctions.CompareDataObjects(ClFtesFcastData, CalculateMonthlyClFtesFcastData);
            }
        }        
    }
}
