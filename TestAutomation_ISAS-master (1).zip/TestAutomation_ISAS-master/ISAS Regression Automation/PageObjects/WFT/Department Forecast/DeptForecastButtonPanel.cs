﻿using AutomationCoreLite.Reporting;
using MongoDB.Bson;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DeptForecastButtonPanel
    {
        public static bool ApprovePlan()
        {            
            By byApprove = By.XPath("//*/a[@id='btnApprove']");
            bool isDisplayed = CommonFunctions.IsElementDisplayed(byApprove, 2);
            if (isDisplayed)
            {
                IWebElement cmdApprove = CommonFunctions.getElement(byApprove);
                CommonFunctions.ClickByJE(cmdApprove);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Click the approve button", "The approve button is enabled and clickable");
                return true;
            }
            return false;
        }

        public static void RejectPlan()
        {
            bool bDisplayed;
            By ConfirmXpath = By.XPath("//*/div[@aria-describedby=\"comment-dialog\"]//div[@class='ui-dialog-buttonset']//button[text()='Reject']");
            IWebElement cmdReject = CommonFunctions.getElement(By.XPath("//*/a[@id='btnReject']"));
            CommonFunctions.ClickByJE(cmdReject);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click the reject button", "The reject button is enabled and clickable");
            //bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 10);
            //if (bDisplayed)
            //{
            //    IWebElement cmdRejct = CommonFunctions.getElement(ConfirmXpath);
            //    CommonFunctions.ClickByJE(cmdRejct);
            //    CommonFunctions.WaitUntilPageIsAcive();
            //    CommonFunctions.AddTestStep("Click the reject button for confirmation", "The reject button is enabled and clickable");
            //}
        }

        public static bool ReleasePlan()
        {
            bool bDisplayed;
            string ConfirmXpath = "//*/div[@aria-describedby=\"release-confirm\"]//div[@class='ui-dialog-buttonset']//button[text()='Yes']";
            By byRelease = By.XPath("//*/a[@id='btnRelease']");
            bDisplayed = CommonFunctions.IsElementDisplayed(byRelease, 2);
            if (bDisplayed)
            {
                IWebElement cmdRelease = CommonFunctions.getElement(byRelease);
                CommonFunctions.ClickByJE(cmdRelease);
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 10);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 20);
                    CommonFunctions.AddTestStep("Click the release button", "The release button is enabled and clickable");
                    return true;
                }
            }
            return false;
        }

        public static bool IsPlanReleased()
        {
            bool bDisplayed;
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(2000);
            bDisplayed = CommonFunctions.IsElementDisplayed("//input[@id='Text6' and contains(@value,'Released')]", 10);
            CommonFunctions.AddTestStep("Verify the plan is released", "the plan is released");
            return (bDisplayed);
        }

        public static bool IsPlanRejected()
        {
            bool bDisplayed;
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(2000);
            bDisplayed = CommonFunctions.IsElementDisplayed("//input[@id='Text6' and contains(@value,'Rejected')]", 4000);
            CommonFunctions.AddTestStep("Verify the plan is rejected", "the plan is rejected");
            return (bDisplayed);
        }

        public static bool IsPlanApproved()
        {
            bool bDisplayed;
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(2000);
            bDisplayed = CommonFunctions.IsElementDisplayed("//input[@id='Text6' and @value='Approved']", 30);
            CommonFunctions.AddTestStep("Verify the plan is approved", "the plan is approved");
            return (bDisplayed);
        }

        public static void GoToAdmin()
        {
            string FacStatXpath = "//a[@id='facilityStatsTabLnk']";
            string NavigateAwayXpath = "//*/div[@aria-describedby=\"dirtypage-nav-with-save-confirm\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='Yes']";
            By byGoToAdmin = By.XPath("//a[@id='btnNavigateToAdmin']");
            bool bDisplayed, isDisplayed;
            
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
            bDisplayed = CommonFunctions.IsElementDisplayed(NavigateAwayXpath, 2);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(NavigateAwayXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.WaitUntilPageIsAcive();
            }

            bDisplayed = CommonFunctions.IsElementDisplayed(byGoToAdmin,1);
            if (bDisplayed)
            {
                IWebElement cmdGoToAdmin = CommonFunctions.getElement(byGoToAdmin);
                CommonFunctions.ClickByJE(cmdGoToAdmin);
                // cmdGoToAdmin.Click();
                bDisplayed = CommonFunctions.IsElementDisplayed(NavigateAwayXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(NavigateAwayXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitUntilPageIsAcive();
                }
            }
            
            string OKXpath = "//*/div[@aria-describedby=\"host_volumes_diff\"]//div[@class='ui-dialog-buttonset']//button[normalize-space()='OK']";
            isDisplayed = CommonFunctions.IsElementDisplayed(OKXpath, 2);
            if (isDisplayed)
            {            
                IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OKXpath));
                CommonFunctions.ClickByJE(cmdOK);
                bDisplayed = CommonFunctions.IsElementDisplayed(FacStatXpath, 20);
            }
            CommonFunctions.AddTestStep("Go To Admin page", "Admin page is displayed");

        }

        public static void DownloadPlan()
        {
            IWebElement cmdDownload = CommonFunctions.getElement(By.XPath("//a[@id='btnDownload']"));
            CommonFunctions.ClickByJE(cmdDownload);
            Thread.Sleep(5000);
            CommonFunctions.AddTestStep("Click the download button", "The download button is enabled and clickable");
        }

        public static void clickSaveAndRecalc()
        {
            //Enter a note
            IWebElement txtNote = CommonFunctions.getElement(By.XPath("//*/textarea[@id='txtNotes']"));
            CommonFunctions.SetText(txtNote, $"This is a testing note {CommonFunctions.getRandomNumber}");            
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//*/div[@id='deptnotes']//input[@id='btnEdit']"));
            CommonFunctions.ClickByJE(cmdSave);
            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement cmdSaveRecalc = CommonFunctions.getElement(By.XPath("//*/a[@id='btnDeptSave']"));
            CommonFunctions.ClickByJE(cmdSaveRecalc);
            clickConfirmRecalc();
            CommonFunctions.AddTestStep("Click the save and calculate button", "The save and calculate button is enabled and clickable");
        }

        public static void clickDeptSaveAndRecalc()
        {
            bool bDisplayed;
            By byDeptSave = By.XPath("//a[@id='btnDeptSave']");
            CommonFunctions.WaitUntilPageIsAcive();
            bDisplayed = CommonFunctions.IsElementDisplayed(byDeptSave, 5);
            if (bDisplayed)
            {
                IWebElement cmdDeptSaveRecalc = CommonFunctions.getElement(byDeptSave);
                CommonFunctions.ClickByJE(cmdDeptSaveRecalc);
                clickConfirmRecalc();
                CommonFunctions.WaitSaveToastMsgDisappeared();
                CommonFunctions.AddTestStep("Click the save and calculate button", "The save and calculate button is enabled and clickable");
            }
        }

        private static void clickConfirmRecalc()
        {
            bool bDisplayed;

            By byYes = By.XPath("//*/div[@aria-describedby=\"save-confirm\"]//button[text()='Yes']");
            bDisplayed = CommonFunctions.IsElementDisplayed(byYes, 5);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(byYes);
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Click the Confirm Recalc button", "The Confirm Recalc button is enabled and clickable");
            }
        }
    }
}
