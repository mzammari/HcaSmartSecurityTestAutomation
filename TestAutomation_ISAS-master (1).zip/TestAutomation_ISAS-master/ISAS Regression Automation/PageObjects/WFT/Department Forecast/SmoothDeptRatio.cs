﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class SmoothDeptRatio
    {
        public static void GoTo()
        {
            IWebElement cmdSmoothDeptRatio = CommonFunctions.getElement(By.XPath("//*/a[@id='btnSmoothDeptRatio']"));
            CommonFunctions.ClickByJE(cmdSmoothDeptRatio);
            CommonFunctions.WaitUntilPageIsAcive();
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//*/div[@aria-describedby=\"smooth-ratio-confirmation\"]//div[@class='ui-dialog-buttonset']//button[text()='Yes']";
                return CommonFunctions.IsElementDisplayed(xpath, 120);
            }
        }
        public static void SelectSmoothDeptRatio(string Option)
        {
            switch (Option)
            {
                case "Current":
                    IWebElement rdCurrent = CommonFunctions.getElement(By.XPath("//*/div[@id='smooth-ratio-confirmation']//input[@value='1']"));
                    CommonFunctions.ClickByJE(rdCurrent);
                    break;
                case "Historical":
                    IWebElement rdHistorical = CommonFunctions.getElement(By.XPath("//*/div[@id='smooth-ratio-confirmation']//input[@value='2']"));
                    CommonFunctions.ClickByJE(rdHistorical);
                    break;
            }
            IWebElement cmdYes = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby=\"smooth-ratio-confirmation\"]//div[@class='ui-dialog-buttonset']//button[text()='Yes']"));
            CommonFunctions.ClickByJE(cmdYes);
            Thread.Sleep(10000);
            CommonFunctions.WaitUntilPageIsAcive();
        }
    }
}
