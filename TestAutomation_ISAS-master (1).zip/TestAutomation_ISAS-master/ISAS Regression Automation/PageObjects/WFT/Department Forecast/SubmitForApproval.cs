﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    public class SubmitForApproval
    {
        public static bool SubmitPlanForApproval()
        {
            bool bDispayed;
            CommonFunctions.AddTestStep("Submit a plan for approval", "The plan was submitted");
            string pendingApprovalXpath = "//*/input[@id='Text6' and @value='Pending Approval']";
            By bySubmitForApproval = By.XPath("//*/a[@id='btnSubmitForApproval']");
            By byBtnYes = By.XPath("//*/div[@aria-describedby='submit-for-approval-confirm']//div[@class='ui-dialog-buttonset']//button[text()='Yes']");
            bDispayed  = CommonFunctions.IsElementDisplayed(bySubmitForApproval, 2);
            if (bDispayed)
            {
                IWebElement SubmitForApproval = CommonFunctions.getElement(bySubmitForApproval);
                SubmitForApproval.Click();
                bDispayed = CommonFunctions.IsElementDisplayed(byBtnYes, 15);
                if (bDispayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(byBtnYes);
                    CommonFunctions.ClickByJE(cmdYes);
                }
                CommonFunctions.WaitUntilPageIsAcive();
                bDispayed = CommonFunctions.IsElementDisplayed(pendingApprovalXpath, 40);
                return bDispayed;
            }
            return false;
        }

        public static bool IsAt
        {
            get
            {                
                string xpath = "//input[@id='Text6' and @value='Pending Approval']";
                return CommonFunctions.IsElementDisplayed(xpath, 15);
            }
        }

        /// <summary>
        /// Verify the submission detail textbox contains last name. 
        /// </summary>
        /// <returns>True/false</returns>
        public static bool bLastNameDisplayedInSubmissionDetails()
        {
            CommonFunctions.AddTestStep("Verify last name is displayed in detail page", "The last name is displayed.");
            string SubmissionDetailsValue, WelcomeNote, LastName;
            bool bLastNameDisplayed;
            IWebElement txtSubmissionDetails = CommonFunctions.getElement(By.XPath("//input[@id='txtSubmittalInfo']"));
            SubmissionDetailsValue= txtSubmissionDetails.GetAttribute("value");
            IWebElement lblWelcomeNote = CommonFunctions.getElement(By.XPath("//div[@class='welcome-note']//span"));
            WelcomeNote = lblWelcomeNote.Text;
            string[] arrWelcomeNote = WelcomeNote.Split('|');
            var arrFirstPart = arrWelcomeNote[0].Replace("Welcome", " ").Split(',');
            LastName = arrFirstPart[0].Trim();
            bLastNameDisplayed = SubmissionDetailsValue.Contains(LastName);
            return bLastNameDisplayed;
        }

        public static void ApprovePlan()
        {
            IWebElement cmdApprove = CommonFunctions.getElement(By.XPath("//*/a[@id='btnApprove']"));
            CommonFunctions.ClickByJE(cmdApprove);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        


    }
}
