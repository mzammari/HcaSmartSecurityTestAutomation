﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class MonthlyForcastView
    {
        public double Jan { get; set; }
        public double Feb { get; set; }
        public double Mar { get; set; }
        public double Apr { get; set; }
        public double May { get; set; }
        public double Jun { get; set; }
        public double Jul { get; set; }
        public double Aug { get; set; }
        public double Sep { get; set; }
        public double Oct { get; set; }
        public double Nov { get; set; }
        public double Dec { get; set; }
        public double Total { get; set; }
        public string FacilityStatID { get; set; }
        public double getTotal()
        {
            return Jan + Feb + Mar + Apr + May + Jun + Jul + Aug + Sep + Oct + Nov + Dec;
        }
    }

    public class MonthElements
    {
        public IWebElement Jan { get; set; }
        public IWebElement Feb { get; set; }
        public IWebElement Mar { get; set; }
        public IWebElement Apr { get; set; }
        public IWebElement May { get; set; }
        public IWebElement Jun { get; set; }
        public IWebElement Jul { get; set; }
        public IWebElement Aug { get; set; }
        public IWebElement Sep { get; set; }
        public IWebElement Oct { get; set; }
        public IWebElement Nov { get; set; }
        public IWebElement Dec { get; set; }
        public IWebElement Total { get; set; }
    }

    public class WeeklyElements
    {
        public IWebElement Sun;
        public IWebElement Mon;
        public IWebElement Tue;
        public IWebElement Wed;
        public IWebElement Thu;
        public IWebElement Fri;
        public IWebElement Sat;
        public IWebElement ProdMinFTEs;
    }

    public class WeekElementsValues
    {
        public double Sun;
        public double Mon;
        public double Tue;
        public double Wed;
        public double Thu;
        public double Fri;
        public double Sat;
    }

    public class SemiVariableTargetDetatil
    {
        public string StepNum { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Sun { get; set; }
        public string Mon { get; set; }
        public string Tue { get; set; }
        public string Wed { get; set; }
        public string Thu { get; set; }
        public string Fri { get; set; }
        public string Sat { get; set; }
        public string Total { get; set; }
        public string ProdFTEs { get; set; }
    }

    public class objSemiVariableTargetDetatil
    {
        public double StepNum { get; set; }
        public double From { get; set; }
        public double To { get; set; }
        public double Sun { get; set; }
        public double Mon { get; set; }
        public double Tue { get; set; }
        public double Wed { get; set; }
        public double Thu { get; set; }
        public double Fri { get; set; }
        public double Sat { get; set; }
        public double Total { get; set; }
        public double ProdFTEs { get; set; }
    }

    public class BudgetExportHost
    {
        public string DeptCode { get; set; }
        public double Jan { get; set; }
        public double Feb { get; set; }
        public double Mar { get; set; }
        public double Apr { get; set; }
        public double May { get; set; }
        public double Jun { get; set; }
        public double Jul { get; set; }
        public double Aug { get; set; }
        public double Sep { get; set; }
        public double Oct { get; set; }
        public double Nov { get; set; }
        public double Dec { get; set; }
       
    }

    public class StepTargets
    {
        public IWebElement Add;
        public IWebElement Del;
        public IWebElement Copy;
        public IWebElement From;
        public IWebElement To;
        public IWebElement Sun;
        public IWebElement Mon;
        public IWebElement Tue;
        public IWebElement Wed;
        public IWebElement Thur;
        public IWebElement Fri;
        public IWebElement Sat;
        public IWebElement Total;
        public IWebElement ProdFTEs;
        public IWebElement DayMix;
    }

    public class SvStepTargets
    {
        public IWebElement Add;
        public IWebElement Del;
        public IWebElement Copy;
        public string From;
        public string To;
        public string Sun;
        public string Mon;
        public string Tue;
        public string Wed;
        public string Thur;
        public string Fri;
        public string Sat;
        public string Total;
        public string ProdFTEs;
        public string DayMix;
    }

    public class StepTargetsWeekDays
    {       
        public IWebElement Sun;
        public IWebElement Mon;
        public IWebElement Tue;
        public IWebElement Wed;
        public IWebElement Thu;
        public IWebElement Fri;
        public IWebElement Sat;
    }

}
