﻿using AutomationCoreLite.Reporting;
using DnsClient.Protocol;
using OpenQA.Selenium;
using System.Collections.Generic;
using System.Threading;

namespace ISAS_Regression_Automation
{
    public class Comments
    {
        public static void GoTo()
        {
            IWebElement cmdComments = CommonFunctions.getElement(By.XPath("//*/a[@id='btnLoadPlusData']"));
            CommonFunctions.ClickByJE(cmdComments);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
               // "//*/div[@aria-labelledby='ui-dialog-title-Load-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='OK']"
                string xpath = "//textarea[@id='txtComments']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public static CommentsCommand UserComment()
        {
            return new CommentsCommand();
        }

        public static bool VerifyPlanIDinComment(DeptForecastDepartmentDetails.DeptDetails deptDetails)
        {
            string commentValue;
            
            IList<IWebElement> comments = CommonFunctions.getElements(By.XPath("//*/div[contains(@style,'clear: right')]"));
            foreach (IWebElement comment in comments) 
            {
                commentValue = comment.Text;    
                if (commentValue.Contains(deptDetails.PlanID))
                {
                    return true;

                }
            }
            return false;
        }
    }

    #region: CommentsCommand
    public class CommentsCommand
    {
        private string description;

        public CommentsCommand withDescription(string Description)
        {
            this.description = Description;
            return this;
        }

        private void setDescription()
        {
            string descriptionMsg = $"Approving {description}";
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(2000);
            IWebElement txtDescription = CommonFunctions.getElement(By.XPath("//*/textarea[@id='txtComments']"));
            CommonFunctions.SetText(txtDescription, descriptionMsg);
        }
        private void clickSave()
        {
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-comment-dialog']//div[@class='ui-dialog-buttonset']//button/span[text()='Save']"));
            CommonFunctions.ClickByJE(cmdSave);
            Thread.Sleep(2000);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private void clickApprove()
        {
            By bybtnApprove = By.XPath("//*/div[@aria-describedby='comment-dialog']//div[@class='ui-dialog-buttonset']//button[text()='Approve']");
            IWebElement cmdApprove = CommonFunctions.getElement(bybtnApprove);
            CommonFunctions.ClickByJE(cmdApprove);
            CloseConfirmationPopup();
            Thread.Sleep(2000);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private void clickReject()
        {
            IWebElement cmdReject = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby=\"comment-dialog\"]//div[@class='ui-dialog-buttonset']//button[text()='Reject']"));
            CommonFunctions.ClickByJE(cmdReject);
            Thread.Sleep(2000);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private bool CloseConfirmationPopup()
        {
            string YesXpath = "//*/div[@aria-describedby='approval-confirm']//div[@class='ui-dialog-buttonset']//button[text()='Yes']";
            bool isDisplayed = CommonFunctions.IsElementDisplayed(YesXpath, 2);
            if (isDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(YesXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
                return true;
            }
            return false;
        }

        public void Save()
        {
            setDescription();
            clickSave();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public void Approve()
        {            
            setDescription();
            clickApprove();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Verify user can approve a plan", "The plan was approved. ");
        }

        public void Reject()
        {
            setDescription();
            clickReject();            
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Verify user can reject a plan", "The plan was rejected. ");
        }
    }
    #endregion
}
