﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class LoadNPPercent
    {
        public static void GoTo()
        {
            By byLoadNP = By.XPath("//*/a[@id='btnNpPct']");
            By byNpLoadTarget = By.XPath("//*/div[@id=\"np-pct-confirmation\"]");
            CommonFunctions.VerifyDialogVisible(byLoadNP, byNpLoadTarget);
            CommonFunctions.WaitUntilPageIsAcive();
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//*/div[@id=\"np-pct-confirmation\"]";
                return CommonFunctions.IsElementDisplayed(xpath, 120);
            }
        }
        public static void LoadNP(string NPOption)
        {
            switch (NPOption)
            {
                case "QMIRS":
                    IWebElement rdQMIRS = CommonFunctions.getElement(By.XPath("//div[@id='np-pct-confirmation']//input[@name='nppct' and @value='2']"));
                    CommonFunctions.ClickByJE(rdQMIRS);
                    break;
                case "PLUS":
                    IWebElement rdPLUS = CommonFunctions.getElement(By.XPath("//div[@id='np-pct-confirmation']//input[@name='nppct' and @value='3']"));
                    CommonFunctions.ClickByJE(rdPLUS);
                    break;
            }
            IWebElement cmdOK = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby=\"np-pct-confirmation\"]//div[@class='ui-dialog-buttonset']//button[text()='OK']"));
            CommonFunctions.ClickByJE(cmdOK);
            Thread.Sleep(10000);
            CommonFunctions.WaitUntilPageIsAcive();
            
        }
    }
}
