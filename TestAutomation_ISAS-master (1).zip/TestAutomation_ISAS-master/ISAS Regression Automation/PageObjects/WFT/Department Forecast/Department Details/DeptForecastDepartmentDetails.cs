﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System.Threading;

namespace ISAS_Regression_Automation
{
    public class DeptForecastDepartmentDetails
    {
        #region: Action
        public class DeptDetails
        {
           // public string? DeptName { get; set; }
            public string? DeptStat { get; set; }
            public string? DefaultFacilityStat { get; set; }
            public string? FacilityStatToUse { get; set; }
            public string? PLUSDeptType { get; set; }
            public string? PlanID { get; set; }
            public string? PlanYear { get; set; }
            public string? DeptTypeToUse { get; set; }
            public string? Description { get; set; }
            public string? RequiredApprovers { get; set; }
            public string? Status { get; set; }
            public string? Created { get; set; }
            public string? Volume { get; set; }
            public string? PaidFTEs { get; set; }
            public string? AvgRate { get; set; }
            public string? Avg { get; set; }
            public string? Flex { get; set; }
            public string? Median { get; set; }
            public string? DeptName { get; set; }
        }    

        public static DeptDetails GetDeptDetails(string Dept)
        {
            CommonFunctions.AddTestStep($"Select dept {Dept}", $"The dept {Dept} was selected.");
            Steps.AddScreenShot((Driver.Instance as ITakesScreenshot).GetScreenshot().AsBase64EncodedString);
            CommonFunctions.WaitUntilPageIsAcive();
            if (!string.IsNullOrEmpty(Dept))
            {
                IWebElement mnuDept = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlwftDepartments']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuDept, Dept);
                //Thread.Sleep(2000);
                CommonFunctions.WaitUntilPageIsAcive();
            }
            IWebElement deptStat = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptStat']"));
            IWebElement defaultFacilityStat = CommonFunctions.getElement(By.XPath("//input[@id='txtFacilityStat']"));
            IWebElement facilityStatToUse = CommonFunctions.getElement(By.XPath("//input[@id='txtFacilityStatToUse']"));
            IWebElement pLUSDeptType = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptTypeDesc']"));
            IWebElement deptTypeToUse = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptTypeToUse']"));
            IWebElement planID = CommonFunctions.getElement(By.XPath("//*/input[@id='txtModelPlanId']"));
            IWebElement planYear = CommonFunctions.getElement(By.XPath("//*/input[@id='txtModelPlanYear']"));
            IWebElement description = CommonFunctions.getElement(By.XPath("//input[@id='txtIdDesc']"));
            //IWebElement requiredApprovers = CommonFunctions.getElement(By.XPath("//input[@id='txtRequiredApprovers']"));
            IWebElement status = CommonFunctions.getElement(By.XPath("//input[@id='Text6']"));
            IWebElement created = CommonFunctions.getElement(By.XPath("//input[@id='lblCreatedByOn']"));
            IWebElement volume = CommonFunctions.getElement(By.XPath("//input[@id='txtPlanVolume']"));
            IWebElement paidFTEs = CommonFunctions.getElement(By.XPath("//input[@id='txtPlanPaidFtes']"));
            IWebElement avgRate = CommonFunctions.getElement(By.XPath("//input[@id='txtPlanAvgRate']"));
            IWebElement avg = CommonFunctions.getElement(By.XPath("//input[@id='paidFtesAverage']"));
            IWebElement flex = CommonFunctions.getElement(By.XPath("//input[@id='paidFtesFlex']"));
            IWebElement median = CommonFunctions.getElement(By.XPath("//input[@id='paidFtesMedian']"));
            IWebElement deptName = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlwftDepartments']"));

            DeptDetails deptDetails = new DeptDetails()
            {
                // DeptName = mnuDept.GetAttribute("value").ToString(),
                DeptStat = deptStat.GetAttribute("value").ToString(),
                DefaultFacilityStat = defaultFacilityStat.GetAttribute("value").ToString(),
                FacilityStatToUse = facilityStatToUse.GetAttribute("value").ToString(),
                PLUSDeptType = pLUSDeptType.GetAttribute("value").Replace("-", string.Empty).ToString(),
                DeptTypeToUse = deptTypeToUse.GetAttribute("value").Replace("-", string.Empty).ToString(),
                PlanID = planID.GetAttribute("value").ToString(),
                PlanYear = planYear.GetAttribute("value").ToString(),
                Description = description.GetAttribute("value").ToString(),
                //RequiredApprovers = requiredApprovers.GetAttribute("value").ToString(),
                Status = status.GetAttribute("value").ToString(),
                Created = created.GetAttribute("value").ToString(),
                Volume = volume.GetAttribute("value").ToString(),
                PaidFTEs = paidFTEs.GetAttribute("value").ToString(),
                AvgRate = avgRate.GetAttribute("value").ToString(),
                Avg = avg.GetAttribute("value").ToString(),
                Flex = flex.GetAttribute("value").ToString(),
                Median = median.GetAttribute("value").ToString(),
                DeptName = deptName.Text
            };
            return deptDetails;
        }

        public static DeptDetails GetDeptDetailsForDefaultDept()
        {
            bool bExists;
            CommonFunctions.WaitUntilPageIsAcive();            
            IWebElement deptStat = CommonFunctions.getElement(By.XPath("//*/input[@id='txtDeptStat']"));
            IWebElement defaultFacilityStat = CommonFunctions.getElement(By.XPath("//input[@id='txtFacilityStat']"));
            IWebElement facilityStatToUse = CommonFunctions.getElement(By.XPath("//input[@id='txtFacilityStatToUse']"));
            IWebElement pLUSDeptType = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptTypeDesc']"));
            IWebElement deptTypeToUse = CommonFunctions.getElement(By.XPath("//input[@id='txtDeptTypeToUse']"));
            IWebElement planID = CommonFunctions.getElement(By.XPath("//*/input[@id='txtModelPlanId']"));
            IWebElement planYear = CommonFunctions.getElement(By.XPath("//*/input[@id='txtModelPlanYear']"));
            IWebElement description = CommonFunctions.getElement(By.XPath("//input[@id='txtIdDesc']"));            
            IWebElement status = CommonFunctions.getElement(By.XPath("//input[@id='Text6']"));
            IWebElement created = CommonFunctions.getElement(By.XPath("//input[@id='lblCreatedByOn']"));
            IWebElement volume = CommonFunctions.getElement(By.XPath("//input[@id='txtPlanVolume']"));
            IWebElement paidFTEs = CommonFunctions.getElement(By.XPath("//input[@id='txtPlanPaidFtes']"));
            IWebElement avgRate = CommonFunctions.getElement(By.XPath("//input[@id='txtPlanAvgRate']"));
            IWebElement avg = CommonFunctions.getElement(By.XPath("//input[@id='paidFtesAverage']"));
            IWebElement flex = CommonFunctions.getElement(By.XPath("//input[@id='paidFtesFlex']"));
            IWebElement median = CommonFunctions.getElement(By.XPath("//input[@id='paidFtesMedian']"));
            IWebElement deptName = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlwftDepartments']"));

            DeptDetails deptDetails = new DeptDetails()
            {
                // DeptName = mnuDept.GetAttribute("value").ToString(),
                DeptStat = deptStat.GetAttribute("value").ToString(),
                DefaultFacilityStat = defaultFacilityStat.GetAttribute("value").ToString(),
                FacilityStatToUse = facilityStatToUse.GetAttribute("value").ToString(),
                PLUSDeptType = pLUSDeptType.GetAttribute("value").Replace("-", string.Empty).ToString(),
                DeptTypeToUse = deptTypeToUse.GetAttribute("value").Replace("-", string.Empty).ToString(),
                PlanID = planID.GetAttribute("value").ToString(),
                PlanYear = planYear.GetAttribute("value").ToString(),
                Description = description.GetAttribute("value").ToString(),
                //RequiredApprovers = requiredApprovers.GetAttribute("value").ToString(),
                Status = status.GetAttribute("value").ToString(),
                Created = created.GetAttribute("value").ToString(),
                Volume = volume.GetAttribute("value").ToString(),
                PaidFTEs = paidFTEs.GetAttribute("value").ToString(),
                AvgRate = avgRate.GetAttribute("value").ToString(),
                Avg = avg.GetAttribute("value").ToString(),
                Flex = flex.GetAttribute("value").ToString(),
                Median = median.GetAttribute("value").ToString(),
                DeptName = deptName.Text
            };
            return deptDetails;
        }

        public static void SelectDept(string Dept)
        {
            CommonFunctions.WaitUntilPageIsAcive();
            if (!string.IsNullOrEmpty(Dept))
            {
                IWebElement mnuDept = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlwftDepartments']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuDept, Dept);
                Thread.Sleep(2000);
                CommonFunctions.WaitUntilPageIsAcive();
            }
        }

        public static void LogNotes(string Notes)
        {
            IWebElement txtNotes = CommonFunctions.getElement(By.Id("txtNotes"));
            CommonFunctions.SetText(txtNotes, Notes);
            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//input[@id='btnEdit']"));
            CommonFunctions.ClickByJE(cmdSave);


        }


        #endregion
    }
}
    
