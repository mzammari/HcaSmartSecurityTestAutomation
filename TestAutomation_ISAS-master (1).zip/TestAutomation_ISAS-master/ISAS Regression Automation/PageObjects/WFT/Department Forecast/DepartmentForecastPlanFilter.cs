﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using AutomationCoreLite.Reporting;
using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Office2010.ExcelAc;
using MongoDB.Bson.Serialization.Conventions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace ISAS_Regression_Automation
{
    
    public class DepartmentForecastPlanFilter
    {
        public static void GoTo()
        {
            CommonFunctions.WaitUntilPageIsAcive();
            WFTMainMenu.WorkloadForecast.DepartmentForecast.SelectDepartmentForecast();
            CommonFunctions.AddTestStep("Verify Department Forecast Plan Filter", "Department Forecast Plan Filter");
            
        }

        public static bool IsAt
        {
            get
            {
                By xpath = By.XPath("//*/select[@id='ddlPlans']");
                WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(180));
                wait.Until(ExpectedConditions.ElementToBeClickable(xpath));
                return CommonFunctions.IsElementDisplayed(xpath, 30);
            }
        }           

        public static List<string> GetExistingPlanNames(string PlanType)
        {
            List<string> lstPlans = new List<string>();
            By byExistingPlanTypes = By.XPath($"//select[@id='ddlPlans']/option[contains(text(),'({PlanType.ToUpper()})')]");
            var lstPlanElements = CommonFunctions.getElements(byExistingPlanTypes);
            foreach (var plan in lstPlanElements)
            {
                lstPlans.Add(plan.Text.Trim());
            }
            return lstPlans;
        }

        public static string GetCurrentPlanName()
        {
            string planName;
            CommonFunctions.AddTestStep("Get Current Plan Name", "Get Current Plan Name");
            By byChoosePlanExpanded = By.XPath("//*/h3[@class='ui-accordion-header ui-helper-reset ui-state-active ui-corner-top']");
            var bExists = CommonFunctions.IsElementDisplayed(byChoosePlanExpanded, 1);
            if(!bExists)
            {
                IWebElement cmdChoosePlan = CommonFunctions.getElement(By.XPath("//*/a[contains(text(),'Choose a Plan')]"));
                CommonFunctions.ClickByJE(cmdChoosePlan);
                Thread.Sleep(500);
            }
            RunData.PlanID = AdminPlanDetail.getPlanID();
            planName = CommonFunctions.getElement(By.XPath($"//*/select[@id='ddlPlans']/option[@value='{RunData.PlanID}']")).Text.Trim();

            RunData.CurrentPlanName = planName;
            return planName;
        }

        public static DepartmentForecastPlanFilterCommand ExistingPlan()
        {
            return new DepartmentForecastPlanFilterCommand();
        }

        public static bool IsDeptInGroup(string Dept)
        {
            List<string> lstDepts = new List<string>();
            By byGroupXpath = By.XPath("//*/select[@id='ddlwftDepartments']/option[contains(text(),'(G)')]");
            var lstGroups = CommonFunctions.getElements(byGroupXpath);
            foreach (var group in lstGroups)
            {
                var arrDeptText = group.Text.Trim().Split('-');
                lstDepts.Add(arrDeptText[0].Trim());
            }
            return lstDepts.Contains(Dept);
        }
    }

    #region: DepartmentForecastPlanFilterCommand
    public class DepartmentForecastPlanFilterCommand
    {
        private string year;
        private string planStatus;
        private string plan;
        public DepartmentForecastPlanFilterCommand withYear(string Year)
        {
            this.year = Year;
            return this;
        }

        public DepartmentForecastPlanFilterCommand withPlanStatus(string PlanStatus)
        {
            this.planStatus = PlanStatus;
            return this;
        }

        public DepartmentForecastPlanFilterCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }

        private void setYear()
        {
            if (!string.IsNullOrEmpty(year))
            {
                IWebElement mnuYear = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlYears']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuYear, year);
            }
        }

        private void setPlanStatus() 
        {
            if (!string.IsNullOrEmpty(planStatus))
            {
                IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlPlanStatuses']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, planStatus);
            }            
        }

        private void setPlan()
        {
            if (!string.IsNullOrEmpty(plan))
            {
                IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlPlans']"));
                try
                {
                    CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
                }
                catch 
                {
                    CommonFunctions.SelectOptionValue(mnuPlan, plan);
                }
            }           
        }

        private void clickSelect()
        {
            IWebElement cmdSelect = CommonFunctions.getElement(By.XPath("//*/a[@id='btnView']"));
            CommonFunctions.ClickByJE(cmdSelect);
            Thread.Sleep(1000);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 30);
        }
        

        public void Select()
        {
            EnsureFilterVisible();
            setYear();
            setPlanStatus();
            setPlan();
            clickSelect();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//*/label[normalize-space()='Facility Stat']", 20);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep( $"Select a {planStatus} plan", $"The {planStatus} plan was selected and displayed.");
            
        }

        private void EnsureFilterVisible()
        {
            By byChoosePlanExpanded = By.XPath("//*/div[@id='choosePlanContainer']/h3[@aria-expanded='true']/a");
            var bExists = CommonFunctions.IsElementDisplayed(byChoosePlanExpanded, 3);
            if (!bExists)
            {
                IWebElement cmdChoosePlan = CommonFunctions.getElement(By.XPath("//*/div[@id='choosePlanContainer']//a[contains(text(),'Choose a Plan')]"));
                CommonFunctions.ClickByJE(cmdChoosePlan);
                Thread.Sleep(500);
            }
        }

        public bool IsPlanExist()
        {
            try
            {
                EnsureFilterVisible();
                setYear();
                setPlanStatus();
                setPlan();
                CommonFunctions.AddTestStep($"Verify a {planStatus} plans exists ", $"The {planStatus} plans exist.");
                return true;
            }
            catch
            { return false; }   
        }
    }
    #endregion

    public class ExistingPlan
    {
        private string year;
        private string planStatus;
        private string plan;
    }
}
