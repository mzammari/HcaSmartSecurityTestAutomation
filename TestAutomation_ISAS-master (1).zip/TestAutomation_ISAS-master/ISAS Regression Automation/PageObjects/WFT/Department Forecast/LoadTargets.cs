﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class LoadTargets
    {
        public static void GoTo()
        {
            IWebElement cmdLoadTargets = CommonFunctions.getElement(By.XPath("//*/a[@id='btnLoadPlusData']"));
            CommonFunctions.ClickByJE(cmdLoadTargets);
            CommonFunctions.WaitUntilPageIsAcive();
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "//*/div[@aria-describedby=\"Load-confirm\"]//div[@class='ui-dialog-buttonset']//button[text()='OK']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public static LoadTargetsCommand LoadTarget()
        {
            return new LoadTargetsCommand();
        }
    }


    #region:LoadTargetsCommand
    public class LoadTargetsCommand
    {
        private string loadProductivityTargets;
        private string pLUSTargetMonthFrom;
        private bool productiveMinFtes;
        private bool stepTargets;
        public LoadTargetsCommand withLoadProductivityTargets(string LoadProductivityTargets)
        {
            this.loadProductivityTargets = LoadProductivityTargets;
            return this;
        }

        public LoadTargetsCommand withPLUSTargetMonthFrom(string PLUSTargetMonthFrom)
        {
            this.pLUSTargetMonthFrom = PLUSTargetMonthFrom;
            return this;
        }

        public LoadTargetsCommand withProductiveMinFtes(bool ProductiveMinFtes)
        {
            this.productiveMinFtes = ProductiveMinFtes;
            return this;
        }

        public LoadTargetsCommand withStepTargets(bool StepTargets)
        {
            this.stepTargets = StepTargets;
            return this;
        }

        private void setLoadProductivityTargets()
        {
            IWebElement mnuLoadProductivityTargets = CommonFunctions.getElement(By.Id("ddlVariableHoursPerUOS"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuLoadProductivityTargets, loadProductivityTargets);
        }

        private void setPLUSTargetMonthFrom()
        {
            IWebElement mnuPLUSTargetMonthFrom = CommonFunctions.getElement(By.Id("ddlPlusTargetMonth"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuPLUSTargetMonthFrom, pLUSTargetMonthFrom);
        }

        private void setProductiveMinFtes()
        {
            
            IWebElement chkProductiveMinFtes = CommonFunctions.getElement(By.Id("chkproductiveminftes"));
            CommonFunctions.SetCheckbox(chkProductiveMinFtes, productiveMinFtes);
        }

        private void setStepTargets()
        {
           
            IWebElement chkStepTargets = CommonFunctions.getElement(By.Id("chkPLUSStdSVFTEs"));
            CommonFunctions.SetCheckbox(chkStepTargets, stepTargets);
            
        }

        private void clickOK()
        {
            IWebElement cmdOK = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby=\"Load-confirm\"]//div[@class='ui-dialog-buttonset']//button[text()='OK']"));
            CommonFunctions.ClickByJE(cmdOK);
            CommonFunctions.WaitUntilPageIsAcive();
        }
        private void clickConfirm()
        {
            IWebElement cmdYes = CommonFunctions.getElement(By.XPath("//*/div[@aria-describedby=\"Load-Confirmation\"]//div[@class='ui-dialog-buttonset']//button[text()='Yes']"));
            CommonFunctions.ClickByJE(cmdYes);
            CommonFunctions.WaitUntilPageIsAcive();
        }
       

        public void OK()
        {
            setLoadProductivityTargets();
            setPLUSTargetMonthFrom();
            setProductiveMinFtes();
            setStepTargets();
            clickOK();
            clickConfirm();
            CommonFunctions.WaitUntilPageIsAcive();
        }
    }
    #endregion
}
