﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class SummaryView
    {
        public static void GoTo()
        {
            IWebElement tbSummaryView = CommonFunctions.getElement(By.XPath("//a[@id='summaryTabLink']"));
            tbSummaryView.Click();
            CommonFunctions.WaitUntilPageIsAcive();
        }
        public static bool IsAt
        {
            get
            {
                string xpath = "(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[1]";
                return CommonFunctions.IsElementDisplayed(xpath, 120);
            }
        }
    }
}
