﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FacilityLaborExpenseSummary
    {
        public class TotSalAndWages
        {
            public static MonthlyForcastView getTotSalAndWagesData()
            {
                IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;

                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Sal & Wages($000)')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))

                    //Jan = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(2)')")),
                    //Feb = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(3)').value")),
                    //Mar = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(4)').value")),
                    //Apr = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(5)').value")),
                    //May = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(6)').value")),
                    //Jun = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(7)').value")),
                    //Jul = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(8)').value")),
                    //Aug = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(9)').value")),
                    //Sep = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(10)').value")),
                    //Oct = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(11)').value")),
                    //Nov = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(12)').value")),
                    //Dec = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(13)').value")),
                    //Total = Convert.ToDouble((string)js.ExecuteScript("return document.querySelector('#divFacility\\ Labor\\ Expense\\ Summary > div:nth-child(1) > input:nth-child(14)').value"))
                };
                return data;
            }
        }

        public class TotContractLabor
        {
            public static MonthlyForcastView getTotContractLaborData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Contract Labor($000)')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class TotLaborExpense
        {
            public static MonthlyForcastView getTotLaborExpenseData()
            {
                NumberFormatInfo provider = new NumberFormatInfo();
                provider.NumberDecimalSeparator = ", ";
                provider.NumberGroupSeparator = ".";
                provider.NumberGroupSizes = new int[] { 3 };

                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Tot Labor Expense($000)')]/parent::div//input)[13]"));
                

                var data = new MonthlyForcastView()
                {                    
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))

                };
                return data;
            }
        }

        public class EmployedLaborRate
        {
            public static MonthlyForcastView getEmployedLaborRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Employed Labor Rate')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class ContractLaborRate
        {
            public static MonthlyForcastView getContractLaborRateData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor Rate')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class OTPremiumDollars
        {
            public static MonthlyForcastView getOTPremiumDollarsData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'OT Premium Dollars')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class OvertimePercent
        {
            public static MonthlyForcastView getOvertimePercentData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime%')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class OvertimeFTEs
        {
            public static MonthlyForcastView getOvertimeFTEsData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Labor Expense Summary']/parent::fieldset//div//label[contains(text(),'Overtime FTEs')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }
    }
}
