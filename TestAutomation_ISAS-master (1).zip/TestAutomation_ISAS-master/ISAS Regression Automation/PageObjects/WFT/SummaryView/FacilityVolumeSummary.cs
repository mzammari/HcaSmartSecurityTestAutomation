﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FacilityVolumeSummary
    {
        public class Admissions
        {
            public static MonthlyForcastView getAdmissionsData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Admissions')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class AdjustedAdmissions
        {
            public static MonthlyForcastView getAdjustedAdmissionsData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Adjusted Admissions')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class PatientDays
        {
            public static MonthlyForcastView getPatientDaysData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'Patient Days')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class APD
        {
            public static MonthlyForcastView getAPDData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'APD')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class ERVisits
        {
            public static MonthlyForcastView getERVisitsData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'ER Visits')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class OutPatientVisits
        {
            public static MonthlyForcastView getOutPatientVisitsData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'OutPatient Visits')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class EEOB
        {
            public static MonthlyForcastView getEEOBData()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'EEOB')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class MHAA
        {
            public static MonthlyForcastView getMHAA_Data()
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility Volume Summary']/parent::fieldset//div//label[contains(text(),'MH/AA')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }
    }
}
