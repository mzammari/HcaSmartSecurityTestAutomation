﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FacilityFTESummary
    {
        public class EmployedProductiveFTEs
        {
            public static MonthlyForcastView getEmployedProductiveFTEsData()
            {
                CommonFunctions.AddTestStep("Get Employed Productive FTEs Data", "Employed Productive FTEs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed(Productive)FTEs')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class ContractLaborPercent
        {
            public static MonthlyForcastView getContractLaborPercentData()
            {
                CommonFunctions.AddTestStep("Get Contract Labor Percent Data", "Contract Labor Percent Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract Labor %')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class ContractFTEs
        {
            public static MonthlyForcastView getContractFTEsData()
            {
                CommonFunctions.AddTestStep("Get Contract FTEs Data", "Contract FTEs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Contract FTEs')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class TotalProductiveFTEs
        {
            public static MonthlyForcastView getTotalProductiveFTEsData()
            {
                CommonFunctions.AddTestStep("Get Total Productive FTEs Data", "Total Productive FTEs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total Productive FTEs')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class NonProductivePercent
        {
            public static MonthlyForcastView getNonProductivePercentData()
            {
                CommonFunctions.AddTestStep("Get Non-Productive Percent Data", "Non-Productive Percent Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive %')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = Convert.ToDouble(Jan.GetAttribute("value")),
                    Feb = Convert.ToDouble(Feb.GetAttribute("value")),
                    Mar = Convert.ToDouble(Mar.GetAttribute("value")),
                    Apr = Convert.ToDouble(Apr.GetAttribute("value")),
                    May = Convert.ToDouble(May.GetAttribute("value")),
                    Jun = Convert.ToDouble(Jun.GetAttribute("value")),
                    Jul = Convert.ToDouble(Jul.GetAttribute("value")),
                    Aug = Convert.ToDouble(Aug.GetAttribute("value")),
                    Sep = Convert.ToDouble(Sep.GetAttribute("value")),
                    Oct = Convert.ToDouble(Oct.GetAttribute("value")),
                    Nov = Convert.ToDouble(Nov.GetAttribute("value")),
                    Dec = Convert.ToDouble(Dec.GetAttribute("value")),
                    Total = Convert.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
           
        }

        public class NonProductiveFTEs
        {
            public static MonthlyForcastView getNonProductiveFTEsData()
            {
                CommonFunctions.AddTestStep("Get NonProductive FTEs Data", "NonProductive FTEs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Non-Productive FTEs')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class EmployedPaidFTEs
        {
            public static MonthlyForcastView getEmployedPaidFTEsData()
            {
                CommonFunctions.AddTestStep("Get Employed Paid FTEs Data", "Employed Paid FTEs Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Employed (Paid) FTEs')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }

        public class TotalFTEsPaidPlusContract
        {
            public static MonthlyForcastView getTotalFTEsPaidPlusContractData()
            {
                CommonFunctions.AddTestStep("Get Total FTEs Paid Plus Contract Data", "Total FTEs Paid Plus Contract Data");
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[1]"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[2]"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[3]"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[4]"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[5]"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[6]"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[7]"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[8]"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[9]"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[10]"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[11]"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[12]"));
                IWebElement Total = CommonFunctions.getElement(By.XPath("(//*/div[@id='divSummaryDetails']//fieldset//legend[text()='Facility FTE Summary']/parent::fieldset//div//label[contains(text(),'Total FTEs(Paid+Contract)')]/parent::div//input)[13]"));

                var data = new MonthlyForcastView()
                {
                    Jan = CommonFunctions.ToDouble(Jan.GetAttribute("value")),
                    Feb = CommonFunctions.ToDouble(Feb.GetAttribute("value")),
                    Mar = CommonFunctions.ToDouble(Mar.GetAttribute("value")),
                    Apr = CommonFunctions.ToDouble(Apr.GetAttribute("value")),
                    May = CommonFunctions.ToDouble(May.GetAttribute("value")),
                    Jun = CommonFunctions.ToDouble(Jun.GetAttribute("value")),
                    Jul = CommonFunctions.ToDouble(Jul.GetAttribute("value")),
                    Aug = CommonFunctions.ToDouble(Aug.GetAttribute("value")),
                    Sep = CommonFunctions.ToDouble(Sep.GetAttribute("value")),
                    Oct = CommonFunctions.ToDouble(Oct.GetAttribute("value")),
                    Nov = CommonFunctions.ToDouble(Nov.GetAttribute("value")),
                    Dec = CommonFunctions.ToDouble(Dec.GetAttribute("value")),
                    Total = CommonFunctions.ToDouble(Total.GetAttribute("value"))
                };
                return data;
            }
        }
    }
}
