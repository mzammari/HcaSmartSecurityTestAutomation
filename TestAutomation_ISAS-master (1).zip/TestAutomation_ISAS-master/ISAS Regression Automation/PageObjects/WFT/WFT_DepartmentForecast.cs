﻿using AventStack.ExtentReports;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{    
    public class WFT_DepartmentForecast : Driver
    {
        private IWebDriver driver;

        public WFT_DepartmentForecast(IWebDriver driver)
        {
            this.driver = driver;
        }

        // ** NAVIGATION ELEMENTS ***
        By WFT_WorkloadForecast = By.XPath("//*[@id=\"mainmenu\"]/ul/li[2]/a");
        By WFT_DeptForecast = By.XPath("//*[@id=\"mainmenu\"]/ul/li[2]/ul/li[2]/a");       

        // ** CHOOSE A PLAN ***
        By WFT_Year = By.XPath("//*[@id=\"ddlYears\"]");
        By WFT_Status = By.XPath("//*[@id=\"ddlPlanStatuses\"]");
        By WFT_Plan = By.XPath("//*[@id=\"ddlPlans\"]");
        By WFT_Select = By.XPath("//*[@id=\"btnView\"]");
        By WFT_Facility = By.XPath("//*[@id=\"ddlFacility\"]");

        // ** TABS
        By ForecastViewTab = By.XPath("//*[@id=\"forecastTabLink\"]");
        By SummaryViewTab = By.XPath("//*[@id=\"summaryTabLink\"]");

        // ** FORECAST VIEW LABELS ***
        By WFT_PlanDetailsLabel = By.XPath("//*[@id=\"divForecastHdr\"]/div/fieldset[1]/legend");
        By WFT_DepartmentDetailsLabel = By.XPath("//*[@id=\"divForecastHdr\"]/div/fieldset[2]/legend");
        By WFT_DepartmentForecastSummaryLabel = By.XPath("//*[@id=\"divForecastHdr\"]/div/fieldset[3]/legend/b");
        By WFT_DepartmentForecastPageTitle = By.XPath("//*[@id=\"mainmenu\"]/div");
        By WFT_SaveandRecalc = By.XPath("//*[@id=\"btnSaveBugdegetForecast\"]");
        By WFT_SaveandRecalc_YesR = By.XPath("//div[@aria-labelledby='ui-dialog-title-save-confirm']//div[3]/div/button[1]");

        // ** FORECAST VIEW SELECTION FIELDS AND BUTTONS ***
        By WFT_Dept = By.XPath("//*[@id=\"ddlwftDepartments\"]");
        By WFT_DeptLabel = By.XPath("//*[@id=\"monthly-header\"]/input");
        By WFT_ProductiveMinFTEsEdit = By.XPath("//*[@id=\"prodMinFtesEditBtn\"]");

        // ** PRODUCTIVE MIN FTEs BY DAY
        By WFT_ProductiveMinFTEsPopUp = By.XPath("//*[@id=\"ui-dialog-title-minftes-dialog\"]");
        By WFT_DefineMinHoursDropDown = By.XPath("//*[@id=\"minHoursChoiceList\"]");
        By WFT_DefineMinHoursTable_ByDay = By.XPath("//*[@id=\"byDay\"]/div/table/tbody");
        By WFT_DefineMinHoursSave_ByDay = By.XPath("//div[@aria-labelledby='ui-dialog-title-minftes-dialog']//div[3]/div/button[1]");
        By WFT_DefineMinHoursSave_ByDay_Cancel = By.XPath("//div[@aria-labelledby='ui-dialog-title-minftes-dialog']//div[3]/div/button[3]");
        By WFT_DefineMinHoursSave_ByDay_Yes = By.XPath("//div[@aria-labelledby='ui-dialog-title-save-confirm']//div[3]/div/button[1]");
        By WFT_DefineMinHoursSave_ByDay_No = By.XPath("//div[@aria-labelledby='ui-dialog-title-save-confirm']//div[3]/div/button[2]");
        // By WFT_DefineMinHoursSave_ByDay_Yes = By.XPath("//button[starts-with(@class,'ui-button')][7]");        

        // By WFT_DefineMinHoursSave_ByDay_Yes = By.ClassName("ui-button-text");
        By WFT_DefineMinHoursReset_ByDay = By.XPath("/html/body/div[180]/div[3]/div/button[2]");
        By WFT_DefineMinHoursCancel_ByDay = By.XPath("/html/body/div[180]/div[3]/div/button[3]");
        By SaveMessage = By.XPath("//*[@id=\"save-confirm\"]/p");
        
        // ** PRODUCTIVE MIN FTEs BY DAY OF THE WEEK
        By WFT_MinHrsMonthList = By.XPath("//*[@id=\"minHoursMonthsList\"]");
        By WFT_ChangeMinHrsDef_ToMonth = By.XPath("//div[@aria-labelledby='ui-dialog-title-min-hrs-choice-change-confirm']//div[3]/div/button[1]");
        By WFT_ChangeMinHrsDef_ToDayWeek = By.XPath("//div[@aria-labelledby='ui-dialog-title-min-hrs-choice-change-from-mon-confirm']//div[3]/div/button[1]");
        By WFT_MinHrs_FebValue = By.XPath("//*[@id=\"byDay\"]/div/table/tbody/tr[2]/td[2]/input");        
        By WFT_ProdMinFTEsTable = By.XPath("//*[@id=\"minHoursByDayOfWeek\"]/table/tbody");
        By WFT_ProdMinFTEsValue = By.XPath("//*[@id=\"minHoursByDayOfWeek\"]/table/tbody/tr/td[9]/input");
        By WFT_DefineMinHoursSave_ByDayOfWeek = By.XPath("/html/body/div[180]/div[3]/div/button[1]");
        By WFT_DefineMinHoursSave_ByDayOfWeek_Yes = By.XPath("/html/body/div[627]/div[3]/div/button[1]");

        // ** PRODUCTIVE MIN FTEs BY DAY OF THE MONTH
        By WFT_minHoursByDayOfWeekPerMonthTable = By.XPath("//*[@id=\"minHoursByDayOfWeekPerMonth\"]/div[2]/table/tbody");
        By WFT_minHoursByDayOfWeekPerDefaultTable = By.XPath("//*[@id=\"defaultMinHoursValuesToBeSet\"]");
        By WFT_DefineMinHoursSave_ByDayOfWeekperMonth = By.XPath("/html/body/div[180]/div[3]/div/button[1]");
        By WFT_DefineMinHoursReset_ByDayOfWeekperMonth = By.XPath("/html/body/div[180]/div[3]/div/button[2]");
        By WFT_DefineMinHoursCancel_ByDayOfWeekperMonth = By.XPath("/html/body/div[180]/div[3]/div/button[3]");
        By WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes = By.XPath("/html/body/div[5511]/div[3]/div/button[1]");
        By WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes1 = By.XPath("/html/body/div[5512]/div[3]/div/button[1]");
        By WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes2 = By.XPath("/html/body/div[5512]/div[3]/div/button[1]");
        By WFT_ResetAlltoDefault = By.XPath("//*[@id=\"resetAllMonthlyMinHoursToDefaultBtn\"]");
        By WFT_ResetAlltoDefault_Yes = By.XPath("/html/body/div[182]/div[3]/div/button[1]");
        By WFT_ResetSelectedtoDefault = By.XPath("//*[@id=\"resetSelectedMonthlyMinHoursToDefaultBtn\"]");
        By WFT_ResetSelectedtoDefault_Yes = By.XPath("/html/body/div[182]/div[3]/div/button[1]");

        // ** FCAST VAR STD
        By WFT_FcastVarStd_Row = By.XPath("//div[@aria-labelledby='ui-dialog-title-min-hrs-choice-change-confirm']//div[3]/div/button[1]");
        By WFT_FcastVarStdButtonF = By.XPath("//*[@id=\"plusVarStdFillBtn\"]");
        By WFT_FcastVarStdButtonP = By.XPath("//*[@id=\"resetPlusVarStdBtn\"]");
        By WFT_FcastVarStdButtonQ = By.XPath("//*[@id=\"qmirsVarStdFill\"]");

        // ** FCAST VAR STD        
        By Test1 = By.XPath("//div[@aria-labelledby='ui-dialog-title-steps-dialog600']//div[2]/div/table/tbody/tr[3]/td[9]");        
        By WFT_PLUSStdSVFTEsEdit = By.XPath("//*[@id=\"divPlusStdSemiVariableFtes\"]/a");
        By WFT_SVFTEStepTargets_Title = By.XPath("//*[@id=\"ui-dialog-title-steps-dialog600\"]");
        By WFT_SVFTEStepTargets_Save = By.XPath("//div[@aria-labelledby='ui-dialog-title-steps-dialog600']//div[11]/div/button[1]");
        By WFT_SVFTEStepTargets_Reset = By.XPath("//div[@aria-labelledby='ui-dialog-title-steps-dialog600']//div[11]/div/button[2]");
        By WFT_SVFTEStepTargets_Cancel = By.XPath("//div[@aria-labelledby='ui-dialog-title-steps-dialog600']//div[11]/div/button[3]");
        By WFT_SVFTEStepTargets_Save_Yes = By.XPath("//div[@aria-labelledby='ui-dialog-title-save-confirm']//div[3]/div/button[1]");
        By WFT_SVFTEStepTargets_Jan_Add = By.XPath("//*[@id=\"lnkAddStep-1-1\"]");
        By WFT_SVFTEStepTargets_Jan_OldTo = By.XPath("//*[@id=\"txtTarget-1-1-to\"]");
        By WFT_SVFTEStepTargets_Jan_NewFrom = By.XPath("//*[@id=\"txtTarget-1-2-from\"]");
        By WFT_SVFTEStepTargets_JanNewDel = By.XPath("//*[@id=\"lnkDeleteStep-1-2\"]");
        By WFT_SVFTEStepTargets_Feb_Mon = By.XPath("//*[@id=\"txtTarget-2-1-1\"]");
        By WFT_SVFTEStepTargets_FillButton = By.XPath("//*[@id=\"stepTargetFillBtn-2-1\"]");
        By WFT_SVFTEStepTargets_Mar_Sun = By.XPath("//*[@id=\"txtTarget-3-1-0\"]");
        By WFT_SVFTEStepTargets_Apr_Mon = By.XPath("//*[@id=\"txtTarget-4-1-1\"]");
        By WFT_SVFTEStepTargets_May_Sat = By.XPath("//*[@id=\"txtTarget-5-1-6\"]");
        By WFT_PLUSStdSVFTE_Save_Conf = By.XPath("//div[@aria-labelledby='ui-dialog-title-dirtypage-nav-with-save-confirm']//div[3]/div/button[1]");
        By WFT_SVFTEStepTargets_JanCopy = By.XPath("//*[@id=\"lnkCopyStep-1-1\"]");
        By WFT_SVFTEStepTargets_CopyButton = By.XPath("//div[@aria-labelledby='ui-dialog-title-copystep-dialog']//div[11]/div/button[1]");
        By WFT_SVFTEStepTargets_CancelConfirm = By.XPath("//div[@aria-labelledby='ui-dialog-title-action-confirm']//div[3]/div/button[1]");

        //** LOAD TARGETS
        By WFT_LoadTargets = By.XPath("//*[@id=\"btnLoadPlusData\"]");
        By WFT_LoadProductivityTargetsDropdwon = By.XPath("//*[@id=\"ddlVariableHoursPerUOS\"]");
        By WFT_LoadTargetsOKButton = By.XPath("//div[@aria-labelledby='ui-dialog-title-Load-confirm']//div[11]//div/button[1]");
        By WFT_LoadTargetsYesButton = By.XPath("//div[@aria-labelledby='ui-dialog-title-Load-Confirmation']//div[11]//div/button[1]");
        

        public void NavigateToDepartmentForecastPage()
        {
            try
            {
                driver.FindElement(WFT_WorkloadForecast).Click();
                Test.Log(Status.Info, "'Workload Forecaster' Tab is clicked");
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                wait.Until(ExpectedConditions.ElementIsVisible(WFT_DeptForecast));
                driver.FindElement(WFT_DeptForecast).Click();
                Test.Log(Status.Info, "'Department Forecast' option is Selected");
                wait.Until(ExpectedConditions.ElementIsVisible(WFT_Year));                
                Test.Log(Status.Info, "<b><font color=blue>Navigation to Department Forecast Page is Successful</font></b>");
            }
            catch (Exception ex) 
            {
                Test.Log(Status.Fail, "Test Failed: " + ex.Message);
            }
        }
        public void SelectExistingPlan()
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Facility));
                new SelectElement(driver.FindElement(WFT_Facility)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Facility"));
                
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Year));
                new SelectElement(driver.FindElement(WFT_Year)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Year"));
                
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Status));
                new SelectElement(driver.FindElement(WFT_Status)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "StatusDropdown"));
                
               // wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Plan));
               // new SelectElement(driver.FindElement(WFT_Plan)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Plan"));
                                
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Select));
                //Thread.Sleep(4000);
                driver.FindElement(WFT_Select).Click();
                wait.Until(ExpectedConditions.ElementIsVisible(WFT_Dept));
                Test.Log(Status.Info, "Facility, Year and Status are Selected from Dropdowns based on values from data sheet");
                Test.Log(Status.Info, "<b><font color=blue>Searching for Plan based on Year, Status and Plan is Successful</font></b>");                
            } 
            catch (Exception ex)
            {
                Test.Log(Status.Fail, "Test Failed: " + ex.Message);
            }
        }
        public void ValidateForecastViewPage()
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                wait.Until(ExpectedConditions.ElementIsVisible(WFT_DepartmentForecastPageTitle));
                Assert.AreEqual("Department Forecast", driver.FindElement(WFT_DepartmentForecastPageTitle).Text);
                Assert.AreEqual("Plan Details", driver.FindElement(WFT_PlanDetailsLabel).Text);
                Assert.AreEqual("Department Details", driver.FindElement(WFT_DepartmentDetailsLabel).Text);
                Assert.AreEqual("Department Forecast Summary", driver.FindElement(WFT_DepartmentForecastSummaryLabel).Text);
                Test.Log(Status.Info, "'Plan Details' section is visible and header is verified");
                Test.Log(Status.Info, "'Department Details' section is visible and header is verified");
                Test.Log(Status.Info, "'Department Forecast Summary' section is visible and header is verified");
                Test.Log(Status.Info, "<b><font color=blue>Forecast View Page load is successful and 'Department Forecast header is verified</font></b>");
            }
            catch (Exception ex) 
            {
                Test.Log(Status.Fail, "Test Failed: " + ex.Message);
            }            
        }
        public void SelectDepartment()
        {
            try
            {                
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
                new SelectElement(driver.FindElement(WFT_Dept)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_SemiVariable"));
                Test.Log(Status.Info, "<b><font color=blue>Semi Variable Type Department is Successfully Selected</font></b>");
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
                new SelectElement(driver.FindElement(WFT_Dept)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_Var_SemiVariable"));                // driver.FindElement(WFT_Dept).SendKeys(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_Var_SemiVariable"));
                Test.Log(Status.Info, "<b><font color=blue>Variable/ Semi Variable Type Department is Successfully Selected</font></b>");
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));                
            }
            catch (Exception ex)
            {
                Test.Log(Status.Fail, "Test Failed: " + ex.Message);
            }
        }
        public void Validate_ProductiveMinFTEs_DefineMinHours_ByDay_Save_Functionality()
        {
            try
            {
                Test.Log(Status.Info, "******       PROD MIN FTEs WITH BY DAY OPTION          *******");                
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                wait.Until(ExpectedConditions.ElementIsVisible(WFT_ProductiveMinFTEsEdit));
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProductiveMinFTEsEdit));                
                driver.FindElement(WFT_ProductiveMinFTEsEdit).Click();
                Test.Log(Status.Info, "Edit option next to Productive Min FTEs is Enabled and Selected");
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                Test.Log(Status.Info, "Define Min Hours Dropdown is Available");
                String selectedValue = new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectedOption.Text;
                if (selectedValue == "By Day of Week per Month")
                {
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                    new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectByText("By Day");
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ChangeMinHrsDef_ToDayWeek));
                    driver.FindElement(WFT_ChangeMinHrsDef_ToDayWeek).Click();
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                }
                else if(selectedValue == "By Day of Week")
                {
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                    new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectByText("By Day");
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ChangeMinHrsDef_ToMonth));
                    driver.FindElement(WFT_ChangeMinHrsDef_ToMonth).Click();
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                }

                Test.Log(Status.Info, "'By Day' option is selected from Define Min Hours Dropdown");
                Thread.Sleep(3000);
                List<String> ProdMinFTEValues = new List<String>();
                IWebElement table = driver.FindElement(WFT_DefineMinHoursTable_ByDay);
                
                Random random = new Random();
                String formattedvalue = "";
                double convertedValue;

                for (int i = 1; i < 13; i = i + 1)
                {
                    IList<IWebElement> ProdMinFTEs = table.FindElements(By.XPath("./tr[" + i + "]/td[3]/input"));
                    IList<IWebElement> MinHrs = table.FindElements(By.XPath("./tr[" + i + "]/td[2]/input"));
                    foreach (IWebElement label in MinHrs)
                    {
                        label.Click();
                        label.Clear();
                        double value = Math.Round(random.NextDouble() * 9 + 1, 3);
                        formattedvalue = value.ToString("0.000");
                        label.SendKeys(formattedvalue);                      
                    }
                    
                    foreach (IWebElement label2 in ProdMinFTEs)
                    {
                        label2.Click();
                        convertedValue = Math.Round(double.Parse(formattedvalue) / 5.714,3);
                        ProdMinFTEValues.Add(label2.GetAttribute("value"));
                        try
                        {
                            Assert.AreEqual(convertedValue.ToString("0.000"), label2.GetAttribute("value"));
                        }
                        catch
                        {
                            Test.Log(Status.Info, "'Assert Failed");
                        }                            
                    }
                }
                Test.Log(Status.Info, "'Min Hrs' are updated across all months with Random values generated");
                Test.Log(Status.Info, "'Prod Min FTEs' are against new 'Min Hrs' are captured for comparision after Save");
                driver.FindElement(WFT_DefineMinHoursSave_ByDay).Click();
                Test.Log(Status.Info, "'Save Button is Clicked");
                driver.SwitchTo().Window(driver.WindowHandles.Last());

                wait.Until(ExpectedConditions.ElementIsVisible(SaveMessage));
                driver.FindElement(SaveMessage).Click();
                Assert.AreEqual("Are you sure you want to save these changes?", driver.FindElement(SaveMessage).Text);
                Test.Log(Status.Info, "'Save Confirmation Page with message 'Are you sure you want to save these changes?' is Displayed");

                driver.FindElement(WFT_DefineMinHoursSave_ByDay_Yes).Click();
                Test.Log(Status.Info, "Yes option is slected to confirm the Save");
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                //Thread.Sleep(1000);
                Assert.AreEqual("Department Forecast", driver.FindElement(WFT_DepartmentForecastPageTitle).Text);

                wait.Until(ExpectedConditions.ElementToBeClickable(SummaryViewTab));

                for (int i = 1; i<=12;i++)
                {
                    String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    //wait.Until(ExpectedConditions.ElementToBeClickable(field));
                    Assert.AreEqual(ProdMinFTEValues[i - 1], field.GetAttribute("value"));
                    // Console.WriteLine("value is" + field.GetAttribute("value"));
                    // Console.WriteLine(ProdMinFTEValues[i-1]);
                }
                Thread.Sleep(3000);
                Test.Log(Status.Info, "Prod Min FTEs are saved under Standards section");

                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SaveandRecalc));
                driver.FindElement(WFT_SaveandRecalc).Click();                
                driver.SwitchTo().Window(driver.WindowHandles.Last());                

                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SaveandRecalc_YesR));
                Test.Log(Status.Info, "'Save and ReCalc' option is selected");
                driver.FindElement(WFT_SaveandRecalc_YesR).Click();
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                Test.Log(Status.Info, "'Save and ReCalc' option is saved");
                Thread.Sleep(6000);
                wait.Until(ExpectedConditions.ElementToBeClickable(SummaryViewTab));
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProductiveMinFTEsEdit));
                Test.Log(Status.Info, "'Re-Calculation done and the Prod Min FTEs are rounded with 2 decimals after decimal");
                

                for (int i = 1; i <= 12; i++)
                {
                    String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    //wait.Until(ExpectedConditions.ElementToBeClickable(field));
                    try
                    {
                        Assert.AreEqual(Math.Round(Double.Parse(ProdMinFTEValues[i - 1]), 2, MidpointRounding.AwayFromZero).ToString("0.00"), field.GetAttribute("value"));
                    }
                    catch
                    {
                        Test.Log(Status.Info, "'Assert Failed");
                    }
                    
                    // Console.WriteLine("value is" + field.GetAttribute("value"));
                    // Console.WriteLine(ProdMinFTEValues[i-1]);
                }
                Test.Log(Status.Info, "'Re-calculated values are verified");
                Test.Log(Status.Info, "<b><font color=blue>User can edit Productive Min FTEs by Day and successfully Save the changes </font></b>");
                Thread.Sleep(3000); 
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProductiveMinFTEsEdit));
                
            }
            catch (Exception ex)
            {
                Test.Log(Status.Fail, "Test Failed: " + ex.Message);
            }
        }
        public void Validate_ProductiveMinFTEs_DefineMinHours_ByDay_Cancel_Functionality()
        {
            try
            {
                Test.Log(Status.Info, "******       PROD MIN FTEs WITH BY DAY OPTION          *******");                
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                wait.Until(ExpectedConditions.ElementIsVisible(WFT_ProductiveMinFTEsEdit));
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProductiveMinFTEsEdit));                
                driver.FindElement(WFT_ProductiveMinFTEsEdit).Click();
                Test.Log(Status.Info, "Edit option next to Productive Min FTEs is Enabled and Selected");
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                Test.Log(Status.Info, "Define Min Hours Dropdown is Available");

                String selectedValue = new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectedOption.Text;

                if (selectedValue == "By Day of Week per Month")
                {
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                    new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectByText("By Day");
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ChangeMinHrsDef_ToDayWeek));
                    driver.FindElement(WFT_ChangeMinHrsDef_ToDayWeek).Click();
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                }
                else if (selectedValue == "By Day of Week")
                {
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                    new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectByText("By Day");
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ChangeMinHrsDef_ToDayWeek));
                    driver.FindElement(WFT_ChangeMinHrsDef_ToDayWeek).Click();
                    driver.SwitchTo().Window(driver.WindowHandles.Last());
                }

                Test.Log(Status.Info, "'By Day' option is selected from Define Min Hours Dropdown");

                List<String> ProdMinFTEValues = new List<String>();
                List<String> ProdMinFTEValues_Old = new List<String>();
                IWebElement table = driver.FindElement(WFT_DefineMinHoursTable_ByDay);

                Random random = new Random();
                String formattedvalue = "";
                double convertedValue;

                for (int i = 1; i < 13; i = i + 1)
                {
                    IList<IWebElement> ProdMinFTEs = table.FindElements(By.XPath("./tr[" + i + "]/td[3]/input"));
                    foreach (IWebElement label1 in ProdMinFTEs)
                    {
                        label1.Click();
                        ProdMinFTEValues_Old.Add(label1.GetAttribute("value"));
                    }

                    IList<IWebElement> MinHrs = table.FindElements(By.XPath("./tr[" + i + "]/td[2]/input"));
                    foreach (IWebElement label in MinHrs)
                    {
                        label.Click();
                        label.Clear();
                        double value = Math.Round(random.NextDouble() * 9 + 1, 3);
                        formattedvalue = value.ToString("0.000");
                        label.SendKeys(formattedvalue);
                    }
                    
                    foreach (IWebElement label2 in ProdMinFTEs)
                    {
                        label2.Click();
                        convertedValue = Math.Round(double.Parse(formattedvalue) / 5.714, 3);
                        ProdMinFTEValues.Add(label2.GetAttribute("value"));
                        try
                        {
                            Assert.AreEqual(convertedValue.ToString("0.000"), label2.GetAttribute("value"));
                        }
                        catch
                        {
                            Test.Log(Status.Info, "'Assert Failed");
                        }
                    }
                }
                Test.Log(Status.Info, "'Min Hrs' are updated across all months with Random values generated");
                Test.Log(Status.Info, "'Prod Min FTEs' are against new 'Min Hrs' are captured for comparision after Save");
                driver.FindElement(WFT_DefineMinHoursSave_ByDay).Click();
                Test.Log(Status.Info, "'Save Button is Clicked");
                driver.SwitchTo().Window(driver.WindowHandles.Last());

                driver.FindElement(WFT_DefineMinHoursSave_ByDay_No).Click();
                Test.Log(Status.Info, "No option is slected to cancel the Save");
                driver.SwitchTo().Window(driver.WindowHandles.Last());

                driver.FindElement(WFT_DefineMinHoursSave_ByDay_Cancel).Click();
                Test.Log(Status.Info, "'Cancel Button is Clicked");
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                Assert.AreEqual("Department Forecast", driver.FindElement(WFT_DepartmentForecastPageTitle).Text);

                wait.Until(ExpectedConditions.ElementToBeClickable(SummaryViewTab));

                for (int i = 1; i <= 12; i++)
                {
                    String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    try
                    {
                        Assert.AreEqual(Math.Round(Double.Parse(ProdMinFTEValues_Old[i - 1]), 2, MidpointRounding.AwayFromZero).ToString("0.00"), field.GetAttribute("value"));
                    }
                    catch
                    {
                        Test.Log(Status.Info, "'Assert Failed");
                    }
                }
                Thread.Sleep(3000);
                Test.Log(Status.Info, "Prod Min FTEs are NOT saved under Standards section");
                Test.Log(Status.Info, "<b><font color=blue>User can edit Productive Min FTEs by Day and successfully Cancel the changes </font></b>");
                Thread.Sleep(3000);                
            }
            catch (Exception ex)
            {
                Test.Log(Status.Fail, "Test Failed: " + ex.Message);
            }
        }
        public void Validate_ProductiveMinFTEs_DefineMinHours_ByDayOfWeek_Functionality()
        {
            try
            {
                Test.Log(Status.Info, "******   PROD MIN FTEs WITH BY DAY OF THE WEEK OPTION  *******");                
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
                new SelectElement(driver.FindElement(WFT_Dept)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_SemiVariable"));
                Test.Log(Status.Info, "Semi Variable Type Department is Successfully Selected");
                driver.SwitchTo().Window(driver.WindowHandles.Last());

                IWebElement popupTitle = driver.FindElement(By.XPath("//*[@id=\"ui-dialog-title-dirtypage-nav-with-save-confirm\"]"));
                if (popupTitle.Text == "Navigate away?")
                {
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTE_Save_Conf));
                    driver.FindElement(WFT_PLUSStdSVFTE_Save_Conf).Click();
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
                }

                new SelectElement(driver.FindElement(WFT_Dept)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_Var_SemiVariable"));                // driver.FindElement(WFT_Dept).SendKeys(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_Var_SemiVariable"));
                Test.Log(Status.Info, "Variable/ Semi Variable Type Department is Successfully Selected");

                Thread.Sleep(6000);
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProductiveMinFTEsEdit));            
                driver.FindElement(WFT_ProductiveMinFTEsEdit).Click();            
                Test.Log(Status.Info, "Edit option next to Productive Min FTEs is Enabled and Selected");                           
                driver.SwitchTo().Window(driver.WindowHandles.Last());
            
                var FebValue = driver.FindElement(WFT_MinHrs_FebValue).GetAttribute("value");

                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                Test.Log(Status.Info, "Define Min Hours Dropdown is Available");

                new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectByText("By Day of Week");
                Test.Log(Status.Info, "'By Day Of Week' option is selected from Define Min Hours Dropdown");

                driver.SwitchTo().Window(driver.WindowHandles.Last());
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_MinHrsMonthList));
                new SelectElement(driver.FindElement(WFT_MinHrsMonthList)).SelectByText("Feb");
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ChangeMinHrsDef_ToDayWeek));
                driver.FindElement(WFT_ChangeMinHrsDef_ToDayWeek).Click();
                
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProdMinFTEsTable));
                                
                IWebElement table = driver.FindElement(WFT_ProdMinFTEsTable);
                Thread.Sleep(5000);
                Random random = new Random();
                String formattedvalue = "";
                double convertedValue = 0.000;

                for (int i = 2; i <= 8; i = i + 1)
                {
                    IList<IWebElement> MinHrs = table.FindElements(By.XPath("./tr/td[" + i + "]/input"));
                    foreach (IWebElement label in MinHrs)
                    {
                        Thread.Sleep(1000);
                        label.Clear();
                        double value = Math.Round(random.NextDouble() * 9 + 1, 3);
                        formattedvalue = value.ToString("0.000");
                        label.SendKeys(formattedvalue);
                        convertedValue += double.Parse(formattedvalue);
                    }
                }

                double finalValue = Math.Round(convertedValue / 5.714, 3);
                Console.WriteLine("expected" + finalValue.ToString());

                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProdMinFTEsValue));
                driver.FindElement(WFT_ProdMinFTEsValue).Click();
                var ProdMinFTEs = driver.FindElement(WFT_ProdMinFTEsValue).GetAttribute("value");
                Console.WriteLine("actual" + ProdMinFTEs);

                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursSave_ByDayOfWeek));
                driver.FindElement(WFT_DefineMinHoursSave_ByDayOfWeek).Click();

                driver.SwitchTo().Window(driver.WindowHandles.Last());
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursSave_ByDayOfWeek_Yes));
                driver.FindElement(WFT_DefineMinHoursSave_ByDayOfWeek_Yes).Click();

                for (int i = 1; i <= 12; i++)
                {
                    String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    try
                    {
                        Assert.AreEqual(ProdMinFTEs, field.GetAttribute("value"));
                    }
                    catch
                    {
                        Test.Log(Status.Info, "'Assert Failed");
                    }                    
                }
                Test.Log(Status.Info, "Prod Min FTEs are saved under Standards section");
                Thread.Sleep(10000);
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SaveandRecalc));
                driver.FindElement(WFT_SaveandRecalc).Click();
                Thread.Sleep(2000);
                Test.Log(Status.Info, "'Save and ReCalc' option is selected");
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SaveandRecalc_YesR));
                driver.FindElement(WFT_SaveandRecalc_YesR).Click();
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                Thread.Sleep(10000);
                Test.Log(Status.Info, "'Re-Calculation done and the Prod Min FTEs are rounded with 2 decimals after decimal");
                for (int i = 1; i <= 12; i++)
                {
                    String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    try
                    {
                        Assert.AreEqual(Math.Round(Double.Parse(ProdMinFTEs), 2, MidpointRounding.AwayFromZero).ToString("0.00"), field.GetAttribute("value"));
                    }
                    catch
                    {
                        Test.Log(Status.Info, "'Assert Failed");
                    }                    
                }
                Test.Log(Status.Info, "'Re-calculated valies are verified");
                Test.Log(Status.Info, "<b><font color=blue>User can edit Productive Min FTEs by Week and successfully Save the changes </font></b>");
            }
            catch (Exception ex)
            {
                Test.Log(Status.Fail, "Test Failed: " + ex.Message);
            }
        }
        public void Validate_ProductiveMinFTEs_DefineMinHours_ByDayOfMonth_Functionality_AllMonths()
        {
            try
            {
                Test.Log(Status.Info, "******   PROD MIN FTEs WITH BY DAY OF THE MONTH OPTION  *******");
                Test.Log(Status.Info, "***************************************************************");
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProductiveMinFTEsEdit));
                driver.FindElement(WFT_ProductiveMinFTEsEdit).Click();
                Test.Log(Status.Info, "Edit option next to Productive Min FTEs is Enabled and Selected");
                driver.SwitchTo().Window(driver.WindowHandles.Last());                

                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
                Test.Log(Status.Info, "Define Min Hours Dropdown is Available");

                new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectByText("By Day of Week per Month");
                Test.Log(Status.Info, "'By Day Of Week per Month' option is selected from Define Min Hours Dropdown");

                driver.SwitchTo().Window(driver.WindowHandles.Last());
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ChangeMinHrsDef_ToMonth));
                driver.FindElement(WFT_ChangeMinHrsDef_ToMonth).Click();

                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_minHoursByDayOfWeekPerMonthTable));

                IWebElement table = driver.FindElement(WFT_minHoursByDayOfWeekPerMonthTable);                
                Random random = new Random();
                String formattedvalue = "";
                double convertedValue = 0.000;
                double finalValue = 0.000;
                List<double> ProdMinFTEValues = new List<double>();                
                // int year = 2024;
                int year = int.Parse(getDataParser().extractData("WFT_ForecastStandardModification", "Year"));

                Thread.Sleep(2000);
                for (int i = 1; i <= 12; i = i + 1)
                {
                    int[] weekdays = new int[7];
                    int daysInMonth = DateTime.DaysInMonth(year, i);
                    convertedValue = 0.000;
                    for (int day = 1; day <= daysInMonth; day++)
                    {
                        DateTime date = new DateTime(year, i, day);
                        int dayOfWeekNumber = (int)date.DayOfWeek;
                        weekdays[dayOfWeekNumber]++;
                    }

                    for (int j = 3; j <= 9; j = j + 1)
                    {
                        int str = weekdays[j - 3];
                        IList<IWebElement> MinHrs = table.FindElements(By.XPath("./tr[" + i + "]/td[" + j + "]/input"));
                        foreach (IWebElement label in MinHrs)
                        {
                            // Thread.Sleep(100);
                            double value = Math.Round(random.NextDouble() * 9 + 1, 3);
                            formattedvalue = value.ToString("0.000");
                            label.Clear();
                            label.SendKeys(formattedvalue);
                            convertedValue += double.Parse(formattedvalue) * weekdays[j - 3];
                            //Console.WriteLine("value entered" + formattedvalue);
                            //Console.WriteLine("addingup" + convertedValue);
                        }
                    }
                    IWebElement actualValue = table.FindElement(By.XPath("./tr[" + i + "]/td[10]/input"));
                    actualValue.Click();
                    finalValue = Math.Round(convertedValue / daysInMonth / 5.714, 3);
                    ProdMinFTEValues.Add(finalValue);
                    //Console.WriteLine("expected" + finalValue.ToString("0.000"));
                    //Console.WriteLine("actual" + actualValue.GetAttribute("value"));
                    Assert.AreEqual(finalValue.ToString("0.000"), actualValue.GetAttribute("value"));
                }
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursSave_ByDayOfWeekperMonth));
                driver.FindElement(WFT_DefineMinHoursSave_ByDayOfWeekperMonth).Click();
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes));
                driver.FindElement(WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes).Click();

                Test.Log(Status.Info, "Yes option is slected to confirm the Save");
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                Thread.Sleep(1000);
                Assert.AreEqual("Department Forecast", driver.FindElement(WFT_DepartmentForecastPageTitle).Text);

                for (int i = 1; i <= 12; i++)
                {
                    String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    try
                    {
                        Assert.AreEqual(ProdMinFTEValues[i - 1], double.Parse(field.GetAttribute("value")));
                    }
                    catch
                    {
                        Test.Log(Status.Info, "'Assert Failed");
                    }
                }
                Thread.Sleep(5000);
                Test.Log(Status.Info, "Prod Min FTEs are saved under Standards section");
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SaveandRecalc));
                driver.FindElement(WFT_SaveandRecalc).Click();

                driver.SwitchTo().Window(driver.WindowHandles.Last());
                Thread.Sleep(2000);

                wait.Until(ExpectedConditions.ElementIsVisible(SaveMessage));
                driver.FindElement(SaveMessage).Click();
                Console.WriteLine(driver.FindElement(SaveMessage).Text);
                driver.FindElement(WFT_SaveandRecalc_YesR).Click();
                driver.SwitchTo().Window(driver.WindowHandles.Last());
                Thread.Sleep(6000);
                Test.Log(Status.Info, "'Re-Calculation done and the Prod Min FTEs are rounded with 2 decimals after decimal");
                for (int i = 1; i <= 12; i++)
                {
                    String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    try
                    {
                        Assert.AreEqual(Math.Round(ProdMinFTEValues[i - 1], 2, MidpointRounding.AwayFromZero).ToString("0.00"), field.GetAttribute("value"));
                    }
                    catch
                    {
                        Test.Log(Status.Info, "'Assert Failed");
                    }
                }
                Thread.Sleep(10000);
                Test.Log(Status.Info, "'Re-calculated valies are verified");
                Test.Log(Status.Info, "***************************************************************");
            }
            catch (Exception ex)
            {
                Test.Log(Status.Fail, "Test Failed: " + ex.Message);
            }
        }
        public void Validate_ProductiveMinFTEs_DefineMinHours_ByDayOfMonth_Functionality_ResetAlltoDefault()
        {
            //try
            //{
            Thread.Sleep(5000);
            Test.Log(Status.Info, "******   PROD MIN FTEs WITH BY DAY OF THE MONTH OPTION  *******");
            Test.Log(Status.Info, "***************************************************************");
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProductiveMinFTEsEdit));
            driver.FindElement(WFT_ProductiveMinFTEsEdit).Click();
            Test.Log(Status.Info, "Edit option next to Productive Min FTEs is Enabled and Selected");
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
            //Test.Log(Status.Info, "Define Min Hours Dropdown is Available");

            //new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectByText("By Day of Week per Month");
            //Test.Log(Status.Info, "'By Day Of Week per Month' option is selected from Define Min Hours Dropdown");

            //driver.SwitchTo().Window(driver.WindowHandles.Last());
            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ChangeMinHrsDef_Yes));
            //driver.FindElement(WFT_ChangeMinHrsDef_Yes).Click();

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_minHoursByDayOfWeekPerDefaultTable));
            Thread.Sleep(3000);

            IWebElement defaultTable = driver.FindElement(WFT_minHoursByDayOfWeekPerDefaultTable);
            Random random = new Random();
            String formattedvalue = "";
            List<String> defaultValues = new List<String>();
            for (int j = 3; j <= 9; j = j + 1)
            {
                IList<IWebElement> MinHrs = defaultTable.FindElements(By.XPath("./td[" + j + "]/input"));
                foreach (IWebElement label in MinHrs)
                {
                    double value = Math.Round(random.NextDouble() * 9 + 1, 3);
                    formattedvalue = value.ToString("0.000");
                    defaultValues.Add(formattedvalue);
                    label.Clear();
                    label.SendKeys(formattedvalue);
                }
            }

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ResetAlltoDefault));
            driver.FindElement(WFT_ResetAlltoDefault).Click();

            driver.SwitchTo().Window(driver.WindowHandles.Last());

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ResetAlltoDefault_Yes));
            driver.FindElement(WFT_ResetAlltoDefault_Yes).Click();

            IWebElement table = driver.FindElement(WFT_minHoursByDayOfWeekPerMonthTable);


            double convertedValue = 0.000;
            double finalValue = 0.000;
            List<double> ProdMinFTEValues = new List<double>();            
            int year = int.Parse(getDataParser().extractData("WFT_ForecastStandardModification", "Year"));

            Thread.Sleep(2000);
            for (int i = 1; i <= 12; i = i + 1)
            {
                int[] weekdays = new int[7];
                int daysInMonth = DateTime.DaysInMonth(year, i);
                convertedValue = 0.000;
                for (int day = 1; day <= daysInMonth; day++)
                {
                    DateTime date = new DateTime(year, i, day);
                    int dayOfWeekNumber = (int)date.DayOfWeek;
                    weekdays[dayOfWeekNumber]++;
                }

                for (int j = 3; j <= 9; j = j + 1)
                {
                    int str = weekdays[j - 3];
                    IList<IWebElement> MinHrs = table.FindElements(By.XPath("./tr[" + i + "]/td[" + j + "]/input"));
                    foreach (IWebElement label in MinHrs)
                    {
                        Assert.AreEqual(label.GetAttribute("value"),defaultValues[j-3]);
                        convertedValue += double.Parse(defaultValues[j - 3]) * weekdays[j - 3];
                    }
                }
                IWebElement actualValue = table.FindElement(By.XPath("./tr[" + i + "]/td[10]/input"));
                actualValue.Click();
                finalValue = Math.Round(convertedValue / daysInMonth / 5.714, 3);
                ProdMinFTEValues.Add(finalValue);
                //Console.WriteLine("expected" + finalValue.ToString("0.000"));
                //Console.WriteLine("actual" + actualValue.GetAttribute("value"));
                Assert.AreEqual(finalValue.ToString("0.000"), actualValue.GetAttribute("value"));
            }
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursSave_ByDayOfWeekperMonth));
            driver.FindElement(WFT_DefineMinHoursSave_ByDayOfWeekperMonth).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes));
            driver.FindElement(WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes).Click();

            Test.Log(Status.Info, "Yes option is slected to confirm the Save");
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            Thread.Sleep(1000);
            Assert.AreEqual("Department Forecast", driver.FindElement(WFT_DepartmentForecastPageTitle).Text);

            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                try
                {
                    Assert.AreEqual(ProdMinFTEValues[i - 1], double.Parse(field.GetAttribute("value")));
                }
                catch
                {
                    Test.Log(Status.Info, "'Assert Failed");
                }
            }
            Thread.Sleep(5000);
            Test.Log(Status.Info, "Prod Min FTEs are saved under Standards section");
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SaveandRecalc));
            driver.FindElement(WFT_SaveandRecalc).Click();

            driver.SwitchTo().Window(driver.WindowHandles.Last());
            Thread.Sleep(2000);

            wait.Until(ExpectedConditions.ElementIsVisible(SaveMessage));
            driver.FindElement(SaveMessage).Click();
            Console.WriteLine(driver.FindElement(SaveMessage).Text);
            driver.FindElement(WFT_SaveandRecalc_YesR).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            Thread.Sleep(10000);
            Test.Log(Status.Info, "'Re-Calculation done and the Prod Min FTEs are rounded with 2 decimals after decimal");
            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                try
                {
                    Assert.AreEqual(Math.Round(ProdMinFTEValues[i - 1], 2, MidpointRounding.AwayFromZero).ToString("0.00"), field.GetAttribute("value"));
                }
                catch
                {
                    Test.Log(Status.Info, "'Assert Failed");
                }
            }
            Thread.Sleep(10000);
            Test.Log(Status.Info, "'Re-calculated valies are verified");
            Test.Log(Status.Info, "***************************************************************");
        }
        public void Validate_ProductiveMinFTEs_DefineMinHours_ByDayOfMonth_Functionality_ResetSelectedtoDefault()
        {
            //try
            //{
            Thread.Sleep(5000);
            Test.Log(Status.Info, "******   PROD MIN FTEs WITH BY DAY OF THE MONTH OPTION  *******");
            Test.Log(Status.Info, "***************************************************************");
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ProductiveMinFTEsEdit));
            driver.FindElement(WFT_ProductiveMinFTEsEdit).Click();
            Test.Log(Status.Info, "Edit option next to Productive Min FTEs is Enabled and Selected");
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursDropDown));
            //Test.Log(Status.Info, "Define Min Hours Dropdown is Available");

            //new SelectElement(driver.FindElement(WFT_DefineMinHoursDropDown)).SelectByText("By Day of Week per Month");
            //Test.Log(Status.Info, "'By Day Of Week per Month' option is selected from Define Min Hours Dropdown");

            //driver.SwitchTo().Window(driver.WindowHandles.Last());
            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ChangeMinHrsDef_Yes));
            //driver.FindElement(WFT_ChangeMinHrsDef_Yes).Click();
            //Test.Log(Status.Info, "'By Day Of Week per Month' Page Opnes Up");

            Thread.Sleep(3000);
            IWebElement table = driver.FindElement(WFT_minHoursByDayOfWeekPerMonthTable);
            String[] monthsSelection = new string[] { "Jan", "Mar", "Dec" };
            for (int i = 1; i <= 12; i = i + 1)
            {
                IWebElement checkBox = table.FindElement(By.XPath("./tr[" + i + "]/td[1]/input"));
                IWebElement monthName = table.FindElement(By.XPath("./tr[" + i + "]/td[2]/input"));
                Thread.Sleep(1000);
                foreach (String s in monthsSelection)
                {
                    if (s == monthName.GetAttribute("value"))
                    {
                        wait.Until(ExpectedConditions.ElementToBeClickable(checkBox));
                        checkBox.Click();
                    }
                }
            }
            Test.Log(Status.Info, "Specfic Months passed from data sheet are Selected");

            IWebElement defaultTable = driver.FindElement(WFT_minHoursByDayOfWeekPerDefaultTable);
            Random random = new Random();
            String formattedvalue = "";
            List<String> defaultValues = new List<String>();
            for (int j = 3; j <= 9; j = j + 1)
            {
                IList<IWebElement> MinHrs = defaultTable.FindElements(By.XPath("./td[" + j + "]/input"));
                foreach (IWebElement label in MinHrs)
                {
                    double value = Math.Round(random.NextDouble() * 9 + 1, 3);
                    formattedvalue = value.ToString("0.000");
                    defaultValues.Add(formattedvalue);
                    label.Clear();
                    label.SendKeys(formattedvalue);
                }
            }
            Test.Log(Status.Info, "Random Values are entered in the Default row on the top");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ResetSelectedtoDefault));
            driver.FindElement(WFT_ResetSelectedtoDefault).Click();

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_ResetSelectedtoDefault_Yes));
            driver.FindElement(WFT_ResetSelectedtoDefault_Yes).Click();

            
            Test.Log(Status.Info, "Reset Selected to Default is Clicked");

            double convertedValue = 0.000;
            double finalValue = 0.000;
            List<double> ProdMinFTEValues = new List<double>();
            int year = int.Parse(getDataParser().extractData("WFT_ForecastStandardModification", "Year"));

            Thread.Sleep(2000);
            for (int i = 1; i <= 12; i = i + 1)
            {
                int[] weekdays = new int[7];
                int daysInMonth = DateTime.DaysInMonth(year, i);
                convertedValue = 0.000;
                for (int day = 1; day <= daysInMonth; day++)
                {
                    DateTime date = new DateTime(year, i, day);
                    int dayOfWeekNumber = (int)date.DayOfWeek;
                    weekdays[dayOfWeekNumber]++;
                }

                for (int j = 3; j <= 9; j = j + 1)
                {
                    int str = weekdays[j - 3];
                    IWebElement checkBox = table.FindElement(By.XPath("./tr[" + i + "]/td[1]/input"));
                    IList<IWebElement> MinHrs = table.FindElements(By.XPath("./tr[" + i + "]/td[" + j + "]/input"));
                    foreach (IWebElement label in MinHrs)
                    {
                        if(checkBox.Selected) 
                        {
                            Assert.AreEqual(label.GetAttribute("value"), defaultValues[j - 3]);
                            convertedValue += double.Parse(defaultValues[j - 3]) * weekdays[j - 3];
                        }
                        else
                        {
                            convertedValue += double.Parse(label.GetAttribute("value")) * weekdays[j - 3];
                        }
                    }
                }
                IWebElement actualValue = table.FindElement(By.XPath("./tr[" + i + "]/td[10]/input"));
                actualValue.Click();
                finalValue = Math.Round(convertedValue / daysInMonth / 5.714, 3);
                ProdMinFTEValues.Add(finalValue);
                //Console.WriteLine("expected" + finalValue.ToString("0.000"));
                //Console.WriteLine("actual" + actualValue.GetAttribute("value"));
                Assert.AreEqual(finalValue.ToString("0.000"), actualValue.GetAttribute("value"));
            }

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursSave_ByDayOfWeekperMonth));
            driver.FindElement(WFT_DefineMinHoursSave_ByDayOfWeekperMonth).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes));
            driver.FindElement(WFT_DefineMinHoursSave_ByDayOfWeekperMonth_Yes).Click();

            Test.Log(Status.Info, "Yes option is slected to confirm the Save");
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            Thread.Sleep(1000);
            Assert.AreEqual("Department Forecast", driver.FindElement(WFT_DepartmentForecastPageTitle).Text);

            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                Assert.AreEqual(ProdMinFTEValues[i - 1], double.Parse(field.GetAttribute("value")));
                // Console.WriteLine("value is" + field.GetAttribute("value"));
                // Console.WriteLine(ProdMinFTEValues[i-1]);
            }
            Thread.Sleep(5000);
            Test.Log(Status.Info, "Prod Min FTEs are saved under Standards section");
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SaveandRecalc));
            driver.FindElement(WFT_SaveandRecalc).Click();

            driver.SwitchTo().Window(driver.WindowHandles.Last());
            Thread.Sleep(2000);

            wait.Until(ExpectedConditions.ElementIsVisible(SaveMessage));
            driver.FindElement(SaveMessage).Click();
            Console.WriteLine(driver.FindElement(SaveMessage).Text);
            driver.FindElement(WFT_SaveandRecalc_YesR).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            Thread.Sleep(8000);
            Test.Log(Status.Info, "'Re-Calculation done and the Prod Min FTEs are rounded with 2 decimals after decimal");
            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"txtProdMinFtes-{i}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                try
                {
                    Assert.AreEqual(Math.Round(ProdMinFTEValues[i - 1] + double.Epsilon, 2, MidpointRounding.AwayFromZero).ToString("0.00"), field.GetAttribute("value"));
                }
                catch
                {
                    Test.Log(Status.Info, "'Assert Failed");
                }
                
                // Console.WriteLine("value is" + field.GetAttribute("value"));
                // Console.WriteLine(ProdMinFTEValues[i-1]);
            }
            Thread.Sleep(10000);
            Test.Log(Status.Info, "'Re-calculated valies are verified");
            Test.Log(Status.Info, "***************************************************************");
        }
        public void Validate_FcastVarStd_Functionality()
        {
            Test.Log(Status.Info, "******************** Fcast Var. Std **************************");
            Test.Log(Status.Info, "***************************************************************");
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));

            Test.Log(Status.Info, "Fcast Var Std Row is Editable");
            Random random = new Random();
            String formattedValue;
            List<String> FcastVarStdValues = new List<String>();
            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"txtPlusVarStd-{i}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                field.Click();
                field.Clear();
                double value = Math.Round(random.NextDouble() * 9 + 1, 3);
                formattedValue = value.ToString("0.000");
                FcastVarStdValues.Add(formattedValue);
                field.SendKeys(formattedValue);
            }
            Thread.Sleep(6000);
            Test.Log(Status.Info, "***************************************************************");
            Test.Log(Status.Info, "Functionality associated with F button next to Fcast Var Std is validated");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_FcastVarStdButtonF));
            driver.FindElement(WFT_FcastVarStdButtonF).Click();
            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"txtPlusVarStd-{i}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                Assert.AreEqual(FcastVarStdValues[0], field.GetAttribute("value"));
            }
            Thread.Sleep(6000);
            Test.Log(Status.Info, "***************************************************************");
            Test.Log(Status.Info, "Functionality associated with P button next to Fcast Var Std is validated");
            List<String> CYPLUSVarStdValues = new List<String>();
            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"divPlusVarStdNew\"]/input[" + i + "]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                CYPLUSVarStdValues.Add(field.GetAttribute("value"));
            }
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_FcastVarStdButtonP));
            driver.FindElement(WFT_FcastVarStdButtonP).Click();
            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"txtPlusVarStd-{i}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                Assert.AreEqual(CYPLUSVarStdValues[i - 1], field.GetAttribute("value"));
            }
            Test.Log(Status.Info, "***************************************************************");
            Test.Log(Status.Info, "Functionality associated with Q button next to Fcast Var Std is validated");
            Test.Log(Status.Info, "***************************************************************");

            By WFT_QMIRSTotalProdFTEs = By.XPath("//*[@id=\"divHistTotalProdFtes\"]/input[13]");
            By WFT_PLUSStdSVFTEs = By.XPath("//*[@id=\"txtSemiVariableTotal\"]");
            // String Year = 
            By WFT_QMIRSStat6100 = By.XPath("//*[@id=\"divHistoricalDepartmentTotalUos\"]/input[13]");

            String QMIRSTotalProdFTEs = driver.FindElement(WFT_QMIRSTotalProdFTEs).GetAttribute("value");
            String PLUSStdSVFTEs = driver.FindElement(WFT_PLUSStdSVFTEs).GetAttribute("value");
            String QMIRSStat6100 = driver.FindElement(WFT_QMIRSStat6100).GetAttribute("value");

            double FcastVarStd = Math.Round(((double.Parse(QMIRSTotalProdFTEs) - double.Parse(PLUSStdSVFTEs)) *2080)/double.Parse(QMIRSStat6100),3,MidpointRounding.AwayFromZero);            
            
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_FcastVarStdButtonQ));
            driver.FindElement(WFT_FcastVarStdButtonQ).Click();
            for (int i = 1; i <= 12; i++)
            {
                String xpath = $"//*[@id=\"txtPlusVarStd-{i}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                Assert.AreEqual(FcastVarStd.ToString("0.000"), field.GetAttribute("value"));
            }
        }
        public void Validate_PLUSStdSVFTEs_Functionality()
        {
            Test.Log(Status.Info, "******************** PLUS Std (SV FTEs) **************************");
            Test.Log(Status.Info, "***************************************************************");
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTEsEdit));
            driver.FindElement(WFT_PLUSStdSVFTEsEdit).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            wait.Until(ExpectedConditions.ElementIsVisible(WFT_SVFTEStepTargets_Title));
            Console.WriteLine(driver.FindElement(WFT_SVFTEStepTargets_Title).Text);
            Test.Log(Status.Info, "Navigated to SV FTE Step Targets Page");

            Random random = new Random();
            String formattedValue;
            List<String> PLUSStdSVFTEs = new List<String>();
            for (int month = 1; month <= 12; month++)
            {
                for (int week = 0; week < 7; week++)
                {
                    String xpath = $"//*[@id=\"txtTarget-{month}-1-{week}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    field.Click();
                    field.Clear();
                    double value = Math.Round(random.NextDouble() * (9 - 0) + 0, 2);
                    formattedValue = value.ToString("00.00");
                    IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                    js.ExecuteScript("arguments[0].value = '" + formattedValue + "';", field);
                    field.Click();
                    Thread.Sleep(1000);
                }     
                String dayMixXPath = $"//*[@id=\"txtBusinessDayMix-{month}-1\"]";
                IWebElement dayMixX = driver.FindElement(By.XPath(dayMixXPath));
                dayMixX.Click();
                PLUSStdSVFTEs.Add(dayMixX.GetAttribute("value"));
                Thread.Sleep(1000);
            }
                        
            Thread.Sleep(1000);
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Save));
            driver.FindElement(WFT_SVFTEStepTargets_Save).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Save_Yes));
            driver.FindElement(WFT_SVFTEStepTargets_Save_Yes).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            Thread.Sleep(2000);
                        
            By popup = By.CssSelector("body > div.blockUI.blockMsg.blockPage");
            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(popup));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTEsEdit));

            for (int month = 1; month <= 12; month++)
            {
                String PLUSFTEs = $"//*[@id=\"txtSemiVariable-{month}\"]";
                IWebElement PLUSStdFTEs = driver.FindElement(By.XPath(PLUSFTEs));
                Console.WriteLine("After Save" + PLUSStdFTEs.GetAttribute("value"));
                Console.WriteLine("Before Save" + PLUSStdSVFTEs[month - 1]);
            }

            Test.Log(Status.Info, "***************************************************************");
            Test.Log(Status.Info, "Functionality associated with F button next to Fcast Var Std is validated");
        }
        public void Validate_PLUSStdSVFTEs_Add_Fill_Del_Functionality()
        {
            Test.Log(Status.Info, "******************** PLUS Std (SV FTEs) **************************");
            Test.Log(Status.Info, "***************************************************************");
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTEsEdit));
            driver.FindElement(WFT_PLUSStdSVFTEsEdit).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            wait.Until(ExpectedConditions.ElementIsVisible(WFT_SVFTEStepTargets_Title));
            Console.WriteLine(driver.FindElement(WFT_SVFTEStepTargets_Title).Text);
            Test.Log(Status.Info, "Navigated to SV FTE Step Targets Page");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Jan_Add));
            driver.FindElement(WFT_SVFTEStepTargets_Jan_Add).Click();
            Test.Log(Status.Info, "Add button next to Jan month is Clicked");

            Random random = new Random();
            String value = Math.Round(random.NextDouble() * (99 - 0) + 0, 2).ToString("00.00").TrimStart('0');

            IWebElement OldTo = driver.FindElement(WFT_SVFTEStepTargets_Jan_OldTo);
            IWebElement NewFrom = driver.FindElement(WFT_SVFTEStepTargets_Jan_NewFrom);
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("arguments[0].value = '400000';", OldTo);
            js.ExecuteScript("arguments[0].value = '400001';", NewFrom);

            Test.Log(Status.Info, "Update From and To Range for the 2 Jan Rows");

            List<String> PLUSStdSVFTEs = new List<String>();
            for (int jan = 1; jan <= 2; jan++)
            {
                for (int week = 0; week < 7; week++)
                {
                    String xpath = $"//*[@id=\"txtTarget-1-{jan}-{week}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    String value1 = Math.Round(random.NextDouble() * (99 - 0) + 0, 2).ToString("00.00").TrimStart('0');
                    js.ExecuteScript("arguments[0].value = '" + value1 + "';", field);
                    field.Click();
                    Thread.Sleep(500);
                }
            }
            Test.Log(Status.Info, "Random Values update for 2 Jan Rows");
            Test.Log(Status.Info, "*******************************************************************");

            String value2 = Math.Round(random.NextDouble() * (99 - 0) + 0, 2).ToString("00.00").TrimStart('0');
            IWebElement FebMon = driver.FindElement(WFT_SVFTEStepTargets_Feb_Mon);
            js.ExecuteScript("arguments[0].value = '" + value2 + "';", FebMon);
            FebMon.Click();
            Test.Log(Status.Info, "Value Entered into Feb Sunday");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_FillButton));
            driver.FindElement(WFT_SVFTEStepTargets_FillButton).Click();
            Test.Log(Status.Info, "Fill option next to Feb Row is Clicked");

            for (int week = 1; week < 6; week++)
            {
                String xpath = $"//*[@id=\"txtTarget-2-1-{week}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                if (week == 0 || week == 6)
                {
                    Assert.AreNotEqual(value2, field.GetAttribute("value"));
                }
                else
                {
                    Assert.AreEqual(value2, field.GetAttribute("value"));
                }
            }
            Test.Log(Status.Info, "Fill Button Functionality Verified");
            Test.Log(Status.Info, "*******************************************************************");

            Actions action = new Actions(driver);
            String valueForFill = Math.Round(random.NextDouble() * (99 - 0) + 0, 2).ToString("00.00").TrimStart('0');
            IWebElement MarSun = driver.FindElement(WFT_SVFTEStepTargets_Mar_Sun);
            IWebElement AprMon = driver.FindElement(WFT_SVFTEStepTargets_Apr_Mon);
            IWebElement MaySat = driver.FindElement(WFT_SVFTEStepTargets_May_Sat);
            js.ExecuteScript("arguments[0].value = '" + valueForFill + "';", MarSun);
            js.ExecuteScript("arguments[0].value = '" + valueForFill + "';", AprMon);
            js.ExecuteScript("arguments[0].value = '" + valueForFill + "';", MaySat);
            MarSun.Click();
            AprMon.Click();
            MaySat.Click();
            Test.Log(Status.Info, "Value Entered into March Sunday, April Monday and May Saturday");

            action.DoubleClick(MarSun).Perform();
            Test.Log(Status.Info, "Double Click March Sunday to validate that the value gets copied for ALL other days against the month");

            for (int week = 0; week <= 6; week++)
            {
                String xpath = $"//*[@id=\"txtTarget-3-1-{week}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                Assert.AreEqual(valueForFill, field.GetAttribute("value"));
            }

            action.DoubleClick(AprMon).Perform();
            Test.Log(Status.Info, "Double Click April Monday to validate that the value gets copied for ALL other WEEKDAYS against the Month");
            for (int week = 0; week <= 6; week++)
            {
                String xpath = $"//*[@id=\"txtTarget-4-1-{week}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                if (week == 0 || week == 6)
                {
                    Assert.AreNotEqual(valueForFill, field.GetAttribute("value"));
                }
                else
                {
                    Assert.AreEqual(valueForFill, field.GetAttribute("value"));
                }
            }

            action.DoubleClick(MaySat).Perform();
            Test.Log(Status.Info, "Double Click May Saturday to validate that the value gets copied to WEEKEND (Saturday and Sunday)");
            for (int week = 0; week <= 6; week++)
            {
                String xpath = $"//*[@id=\"txtTarget-5-1-{week}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                if (week == 0 || week == 6)
                {
                    Assert.AreEqual(valueForFill, field.GetAttribute("value"));
                }
                else
                {
                    Assert.AreNotEqual(valueForFill, field.GetAttribute("value"));
                }
            }

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Save));
            driver.FindElement(WFT_SVFTEStepTargets_Save).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Save_Yes));
            driver.FindElement(WFT_SVFTEStepTargets_Save_Yes).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            WebDriverWait wait1 = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
            By popup = By.CssSelector("body > div.blockUI.blockMsg.blockPage");
            wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(popup));

            Thread.Sleep(10000);
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
            new SelectElement(driver.FindElement(WFT_Dept)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_SemiVariable"));
            Test.Log(Status.Info, "Semi Variable Type Department is Successfully Selected");
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            IWebElement popupTitle = driver.FindElement(By.XPath("//*[@id=\"ui-dialog-title-dirtypage-nav-with-save-confirm\"]"));
            if (popupTitle.Text == "Navigate away?")
            {
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTE_Save_Conf));
                driver.FindElement(WFT_PLUSStdSVFTE_Save_Conf).Click();
                wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
            }

            new SelectElement(driver.FindElement(WFT_Dept)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_Var_SemiVariable"));                // driver.FindElement(WFT_Dept).SendKeys(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_Var_SemiVariable"));
            Test.Log(Status.Info, "Variable/ Semi Variable Type Department is Successfully Selected");

            Thread.Sleep(6000);
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTEsEdit));
            driver.FindElement(WFT_PLUSStdSVFTEsEdit).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            wait.Until(ExpectedConditions.ElementIsVisible(WFT_SVFTEStepTargets_Title));
            Console.WriteLine(driver.FindElement(WFT_SVFTEStepTargets_Title).Text);
            Test.Log(Status.Info, "Navigated to SV FTE Step Targets Page");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_JanNewDel));
            driver.FindElement(WFT_SVFTEStepTargets_JanNewDel).Click();
            IWebElement OldTo1 = driver.FindElement(WFT_SVFTEStepTargets_Jan_OldTo);
            js.ExecuteScript("arguments[0].value = '999999';", OldTo1);

            for (int week = 0; week < 7; week++)
            {
                String xpath = $"//*[@id=\"txtTarget-1-1-{week}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                String value1 = Math.Round(random.NextDouble() * (99 - 0) + 0, 2).ToString("00.00").TrimStart('0');
                js.ExecuteScript("arguments[0].value = '" + value1 + "';", field);
                field.Click();
                //action.DoubleClick(field).Perform();
                Thread.Sleep(500);
            }

            Test.Log(Status.Info, "Del button next to Jan month 2nd Row is Clicked");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Save));
            driver.FindElement(WFT_SVFTEStepTargets_Save).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Save_Yes));
            driver.FindElement(WFT_SVFTEStepTargets_Save_Yes).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            WebDriverWait wait2 = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
            //By popup = By.CssSelector("body > div.blockUI.blockMsg.blockPage");
            wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(popup));

            Thread.Sleep(10000);
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
            new SelectElement(driver.FindElement(WFT_Dept)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_SemiVariable"));
            Test.Log(Status.Info, "Semi Variable Type Department is Successfully Selected");

            try 
            {
                driver.SwitchTo().Window(driver.WindowHandles.Last());

                IWebElement popupTitle1 = driver.FindElement(By.XPath("//*[@id=\"ui-dialog-title-dirtypage-nav-with-save-confirm\"]"));
                if (popupTitle1.Text == "Navigate away?")
                {
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTE_Save_Conf));
                    driver.FindElement(WFT_PLUSStdSVFTE_Save_Conf).Click();
                    wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
                }
            }
            catch (Exception ex)
            {

            }

            new SelectElement(driver.FindElement(WFT_Dept)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_Var_SemiVariable"));                // driver.FindElement(WFT_Dept).SendKeys(getDataParser().extractData("WFT_ForecastStandardModification", "Dept_Var_SemiVariable"));
            Test.Log(Status.Info, "Variable/ Semi Variable Type Department is Successfully Selected");
                        
            Thread.Sleep(5000);
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTEsEdit));

            Test.Log(Status.Info, "***************************************************************");
            Test.Log(Status.Info, "Functionality associated with Add, Fill and Delete buttons is validated");
        }
        public void Validate_PLUSStdSVFTEs_Reset_Copy_Cancel_Functionality()
        {
            Test.Log(Status.Info, "******************** PLUS Std (SV FTEs) **************************");
            Test.Log(Status.Info, "***************************************************************");
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_PLUSStdSVFTEsEdit));
            driver.FindElement(WFT_PLUSStdSVFTEsEdit).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            wait.Until(ExpectedConditions.ElementIsVisible(WFT_SVFTEStepTargets_Title));
            Console.WriteLine(driver.FindElement(WFT_SVFTEStepTargets_Title).Text);
            Test.Log(Status.Info, "Navigated to SV FTE Step Targets Page");


            String[] defaultData = new string[12];
            for (int month = 1; month <= 12; month++)
            {
                String xpath = $"//*[@id=\"txtBusinessDayMix-{month}-1\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                defaultData[month - 1] = field.GetAttribute("value");                
            }
            Test.Log(Status.Info, "Copy Default Data for all months and weeks for validation of Cancel Functionality");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Reset));
            driver.FindElement(WFT_SVFTEStepTargets_Reset).Click();
            Test.Log(Status.Info, "Reset to Plus is Clicked");

            String[,] ResettoPLUSData = new string[12, 7];
            for (int month = 1; month <= 12; month++)
            {
                for (int week = 0; week < 7; week++)
                {
                    String xpath = $"//*[@id=\"txtTarget-{month}-1-{week}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));

                    ResettoPLUSData[month-1,week] = field.GetAttribute("value");
                }
            }

            Test.Log(Status.Info, "Copy PLUS data into a String");

            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            Random random = new Random();
            Actions action = new Actions(driver);
            String[] JanMonthRow = new string[7];
            for (int week = 0; week < 7; week++)
            {
                String xpath = $"//*[@id=\"txtTarget-1-1-{week}\"]";
                IWebElement field = driver.FindElement(By.XPath(xpath));
                String value1 = Math.Round(random.NextDouble() * (99 - 0) + 0, 2).ToString("00.00").TrimStart('0');
                js.ExecuteScript("arguments[0].value = '" + value1 + "';", field);
                field.Click();
                JanMonthRow[week] = value1;
                //action.DoubleClick(field).Perform();
                Thread.Sleep(500);
            }
            Test.Log(Status.Info, "Data Entered into Jan Month");


            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_JanCopy));
            driver.FindElement(WFT_SVFTEStepTargets_JanCopy).Click();
            Test.Log(Status.Info, "Copy button next to Jan month is Clicked");
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            for (int month = 1; month <= 12; month++)
            {
                String xpath = $"//*[@id=\"month{month}\"]";
                IWebElement checkbox = driver.FindElement(By.XPath(xpath));
                bool isChecked = checkbox.Selected;
                bool isEnabled = checkbox.Enabled;

                if (month == 1)
                {
                    Assert.IsFalse(isChecked);
                    Assert.IsFalse(isEnabled);
                }
                else
                {
                    Assert.IsTrue(isChecked);
                    Assert.IsTrue(isEnabled);
                }                
            }
            Test.Log(Status.Info, "Checkbox values of different months is validated from editability and enablement");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_CopyButton));
            driver.FindElement(WFT_SVFTEStepTargets_CopyButton).Click();
            Test.Log(Status.Info, "Copy button is clicked in Popup");

            for (int month = 1; month <= 12; month++)
            {
                for (int week = 0; week < 7; week++)
                {
                    String xpath = $"//*[@id=\"txtTarget-{month}-1-{week}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    Assert.AreEqual(
                        CommonFunctions.ConvertToDouble(JanMonthRow[week]),
                        CommonFunctions.ConvertToDouble(field.GetAttribute("value")),
                        $"Copy mismatch at month {month}, day index {week}");
                }
            }
            Test.Log(Status.Info, "<b><<font color = blue>Validation of the Copy functionality is successful</b></font>");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Reset));
            driver.FindElement(WFT_SVFTEStepTargets_Reset).Click();
            Test.Log(Status.Info, "Reset to PLUS Data button is clicked");

            for (int month = 1; month <= 12; month++)
            {
                for (int week = 0; week < 7; week++)
                {
                    String xpath = $"//*[@id=\"txtTarget-{month}-1-{week}\"]";
                    IWebElement field = driver.FindElement(By.XPath(xpath));
                    Assert.AreEqual(
                        CommonFunctions.ConvertToDouble(ResettoPLUSData[month-1,week]),
                        CommonFunctions.ConvertToDouble(field.GetAttribute("value")),
                        $"Reset mismatch at month {month}, day index {week}");
                }
            }
            Test.Log(Status.Info, "<b><<font color = blue>Validation of the Reset to PLUS Data functionality is successful</b></font>");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Cancel));
            driver.FindElement(WFT_SVFTEStepTargets_Cancel).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());
            Test.Log(Status.Info, "Cancel button is clicked");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_CancelConfirm));
            driver.FindElement(WFT_SVFTEStepTargets_CancelConfirm).Click();

            driver.SwitchTo().Window(driver.WindowHandles.Last());

            for (int month = 1; month <= 12; month++)
            {
                String PLUSFTEs = $"//*[@id=\"txtSemiVariable-{month}\"]";
                IWebElement PLUSStdFTEs = driver.FindElement(By.XPath(PLUSFTEs));
                Console.WriteLine("After Save" + PLUSStdFTEs.GetAttribute("value"));
                Console.WriteLine("Before Save" + defaultData[month - 1]);
            }
            Test.Log(Status.Info, "<b><<font color = blue>Validation of the Cancel functionality is successful</b></font>");
        }
        public void Validate_LoadTargets_Functionality()
        {
            Test.Log(Status.Info, "******************** Load Targets **************************");
            Test.Log(Status.Info, "***************************************************************");

            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            driver.FindElement(WFT_WorkloadForecast).Click();
            Test.Log(Status.Info, "'Workload Forecaster' Tab is clicked");
            wait.Until(ExpectedConditions.ElementIsVisible(WFT_DeptForecast));
            driver.FindElement(WFT_DeptForecast).Click();
            Test.Log(Status.Info, "'Department Forecast' option is Selected");
            wait.Until(ExpectedConditions.ElementIsVisible(WFT_Year));

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Facility));
            new SelectElement(driver.FindElement(WFT_Facility)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Facility"));

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Year));
            new SelectElement(driver.FindElement(WFT_Year)).SelectByText(getDataParser().extractData("WFT_ForecastStandardModification", "Year"));

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Status));
            new SelectElement(driver.FindElement(WFT_Status)).SelectByText("Working");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Select));
            driver.FindElement(WFT_Select).Click();
            wait.Until(ExpectedConditions.ElementIsVisible(WFT_Dept));

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Dept));
            new SelectElement(driver.FindElement(WFT_Dept)).SelectByText("660 - OB/GYN 1");
            Test.Log(Status.Info, "<b><font color=blue>Variable Type Department is Successfully Selected</font></b>");

            Thread.Sleep(5000);

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_LoadTargets));
            driver.FindElement(WFT_LoadTargets).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_LoadProductivityTargetsDropdwon));
            new SelectElement(driver.FindElement(WFT_LoadProductivityTargetsDropdwon)).SelectByText("PLUS: Hrs/UOS to WFT: Fcast Var. Std");

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_LoadTargetsOKButton));
            driver.FindElement(WFT_LoadTargetsOKButton).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_LoadTargetsYesButton));
            driver.FindElement(WFT_LoadTargetsYesButton).Click();
            driver.SwitchTo().Window(driver.WindowHandles.Last());

            //WebDriverWait wait1 = new WebDriverWait(driver, TimeSpan.FromSeconds(120));
            //By popup = By.CssSelector("body > div.blockUI.blockMsg.blockPage");
            //wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(popup));

            Thread.Sleep(10000);

            //wait.Until(ExpectedConditions.ElementIsVisible(WFT_SVFTEStepTargets_Title));
            //Console.WriteLine(driver.FindElement(WFT_SVFTEStepTargets_Title).Text);
            //Test.Log(Status.Info, "Navigated to SV FTE Step Targets Page");


            //String[] defaultData = new string[12];
            //for (int month = 1; month <= 12; month++)
            //{
            //    String xpath = $"//*[@id=\"txtBusinessDayMix-{month}-1\"]";
            //    IWebElement field = driver.FindElement(By.XPath(xpath));
            //    defaultData[month - 1] = field.GetAttribute("value");
            //}
            //Test.Log(Status.Info, "Copy Default Data for all months and weeks for validation of Cancel Functionality");

            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Reset));
            //driver.FindElement(WFT_SVFTEStepTargets_Reset).Click();
            //Test.Log(Status.Info, "Reset to Plus is Clicked");

            //String[,] ResettoPLUSData = new string[12, 7];
            //for (int month = 1; month <= 12; month++)
            //{
            //    for (int week = 0; week < 7; week++)
            //    {
            //        String xpath = $"//*[@id=\"txtTarget-{month}-1-{week}\"]";
            //        IWebElement field = driver.FindElement(By.XPath(xpath));

            //        ResettoPLUSData[month - 1, week] = field.GetAttribute("value");
            //    }
            //}

            //Test.Log(Status.Info, "Copy PLUS data into a String");

            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            //Random random = new Random();
            //Actions action = new Actions(driver);
            //String[] JanMonthRow = new string[7];
            //for (int week = 0; week < 7; week++)
            //{
            //    String xpath = $"//*[@id=\"txtTarget-1-1-{week}\"]";
            //    IWebElement field = driver.FindElement(By.XPath(xpath));
            //    String value1 = Math.Round(random.NextDouble() * (99 - 0) + 0, 2).ToString("00.00").TrimStart('0');
            //    js.ExecuteScript("arguments[0].value = '" + value1 + "';", field);
            //    field.Click();
            //    JanMonthRow[week] = value1;
            //    //action.DoubleClick(field).Perform();
            //    Thread.Sleep(500);
            //}
            //Test.Log(Status.Info, "Data Entered into Jan Month");


            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_JanCopy));
            //driver.FindElement(WFT_SVFTEStepTargets_JanCopy).Click();
            //Test.Log(Status.Info, "Copy button next to Jan month is Clicked");
            //driver.SwitchTo().Window(driver.WindowHandles.Last());

            //for (int month = 1; month <= 12; month++)
            //{
            //    String xpath = $"//*[@id=\"month{month}\"]";
            //    IWebElement checkbox = driver.FindElement(By.XPath(xpath));
            //    bool isChecked = checkbox.Selected;
            //    bool isEnabled = checkbox.Enabled;

            //    if (month == 1)
            //    {
            //        Assert.IsFalse(isChecked);
            //        Assert.IsFalse(isEnabled);
            //    }
            //    else
            //    {
            //        Assert.IsTrue(isChecked);
            //        Assert.IsTrue(isEnabled);
            //    }
            //}
            //Test.Log(Status.Info, "Checkbox values of different months is validated from editability and enablement");

            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_CopyButton));
            //driver.FindElement(WFT_SVFTEStepTargets_CopyButton).Click();
            //Test.Log(Status.Info, "Copy button is clicked in Popup");

            //for (int month = 1; month <= 12; month++)
            //{
            //    for (int week = 0; week < 7; week++)
            //    {
            //        String xpath = $"//*[@id=\"txtTarget-{month}-1-{week}\"]";
            //        IWebElement field = driver.FindElement(By.XPath(xpath));
            //        Assert.AreEqual(JanMonthRow[week], field.GetAttribute("value").TrimStart('0'));
            //    }
            //}
            //Test.Log(Status.Info, "<b><<font color = blue>Validation of the Copy functionality is successful</b></font>");

            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Reset));
            //driver.FindElement(WFT_SVFTEStepTargets_Reset).Click();
            //Test.Log(Status.Info, "Reset to PLUS Data button is clicked");

            //for (int month = 1; month <= 12; month++)
            //{
            //    for (int week = 0; week < 7; week++)
            //    {
            //        String xpath = $"//*[@id=\"txtTarget-{month}-1-{week}\"]";
            //        IWebElement field = driver.FindElement(By.XPath(xpath));
            //        Assert.AreEqual(ResettoPLUSData[month - 1, week], field.GetAttribute("value").TrimStart('0'));
            //    }
            //}
            //Test.Log(Status.Info, "<b><<font color = blue>Validation of the Reset to PLUS Data functionality is successful</b></font>");

            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_Cancel));
            //driver.FindElement(WFT_SVFTEStepTargets_Cancel).Click();
            //driver.SwitchTo().Window(driver.WindowHandles.Last());
            //Test.Log(Status.Info, "Cancel button is clicked");

            //wait.Until(ExpectedConditions.ElementToBeClickable(WFT_SVFTEStepTargets_CancelConfirm));
            //driver.FindElement(WFT_SVFTEStepTargets_CancelConfirm).Click();

            //driver.SwitchTo().Window(driver.WindowHandles.Last());

            //for (int month = 1; month <= 12; month++)
            //{
            //    String PLUSFTEs = $"//*[@id=\"txtSemiVariable-{month}\"]";
            //    IWebElement PLUSStdFTEs = driver.FindElement(By.XPath(PLUSFTEs));
            //    Console.WriteLine("After Save" + PLUSStdFTEs.GetAttribute("value"));
            //    Console.WriteLine("Before Save" + defaultData[month - 1]);
            //}
            //Test.Log(Status.Info, "<b><<font color = blue>Validation of the Cancel functionality is successful</b></font>");
        }
    }
}
