﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class PLUSMainMenu
    {
        public class Home
        {
            public static void SelectHome()
            {
                string HomeXpath = "//*/a[@href='/' and contains(text(),'Home')]";
                MenuSelectorLink.Select(HomeXpath);
            }
        }

        public class PLUS
        {
            public class Daily
            {
                public static void SelectContractHours()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Daily')]");
                    By link = By.XPath("//*/a[@href='/ContractLabor/Hours']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectSharedHours()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Daily')]");
                    By link = By.XPath("//*/a[@href='/SharedLabor/Hours']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectDailyStatisticVolumes()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Daily')]");
                    By link = By.XPath("//*/a[@href='/Stat/DailyStatisticVolumes']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
            }

            public class Maintenance
            {
                public static void SelectProductivityTargets()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[contains(text(),'Productivity Targets')]");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectProcedureMultiplier()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[@href='/ProcedureMultiplier']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectContractRates()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[@href='/ContractLabor/Rates']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectSharedRates()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[@href='/SharedLabor/Rates']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectDepartmentGroup()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[@href='/DepartmentGroup']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectStatisticAssignment()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[@href='/Stat/StatisticAssignment']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectStatisticDescriptions()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[@href='/Stat/Stats']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectFacilityOptions()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[@href='/Facility/FacilityOptions']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectDepartmentOptions()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Maintenance')]");
                    By link = By.XPath("//*/a[@href='/Department/Departments']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
            }

            public class Tools
            {
                public static void SelectAdministration()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[contains(text(),'Tools')]");
                    By link = By.XPath("//*/a[@href='/Administration']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }
            }
        }

        public class FPC
        {
            public static void SelectAdministration()
            {
                By TopMenuLevel = By.XPath("//*/a[contains(text(),'FPC')]");
                By link = By.XPath("//*/a[@href='/FpcAdministration/FpcAdministration']");
                MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
            }

            public static void SelectPlan()
            {
                By TopMenuLevel = By.XPath("//*/a[contains(text(),'FPC')]");
                By link = By.XPath("//*/a[@href='/FpcPlan']");
                MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
            }

            public static void SelectSummaryAndApproval()
            {
                By TopMenuLevel = By.XPath("//*/a[contains(text(),'FPC')]");
                By link = By.XPath("//*/a[@href='/FpcSummaryAndApproval']");
                MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
            }
        }
    }
}
