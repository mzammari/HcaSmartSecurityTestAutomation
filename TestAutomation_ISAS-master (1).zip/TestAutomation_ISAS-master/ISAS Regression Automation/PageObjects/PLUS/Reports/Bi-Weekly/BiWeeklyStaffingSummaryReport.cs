﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class BiWeeklyStaffingSummary
    {
        public string DeptGroupNum { get; set; }
        public string DepartmentGroupName { get; set; }
        public string StatisticDescription { get; set; }
        public decimal PaidIdxTargetActualFtesPercent { get; set; }
        public decimal UOSActual { get; set; }
        public decimal TargetProdHoursUOS { get; set; }
        public decimal ActualProdHoursUOS { get; set; }
        public decimal ActualNonProdPercent { get; set; }
        public decimal ProductiveFtesTarget { get; set; }
        public decimal ProductiveFtesActual { get; set; }
        public decimal ProductiveFtesVariance { get; set; }
        public decimal PaidFtesTarget { get; set; }
        public decimal PaidFtesActual { get; set; }
        public decimal PaidFtesVariance { get; set; }
        public decimal OvertimeFtes { get; set; }
        public decimal OvertimePercent { get; set; }
        public decimal OvertimeTargetPercent { get; set; }
        public decimal ContractFtes { get; set; }
        public decimal ContractPercent { get; set; }
        public decimal ContractTargetPercent { get; set; }
        public decimal PRNFtes { get; set; }
        public decimal PRNPercent { get; set; }
    }

    public class BiWeeklyStaffingSummaryReport
    {
        public static List<BiWeeklyStaffingSummary> ParseBiWeeklyStaffingSummaryReport(string filePath)
        {
            var result = new List<BiWeeklyStaffingSummary>();

            // Register the code page provider (required for .xls files)
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var allRows = new List<object[]>();

                    // Read all rows into memory
                    do
                    {
                        while (reader.Read())
                        {
                            var row = new object[reader.FieldCount];
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row[i] = reader.GetValue(i);
                            }
                            allRows.Add(row);
                        }
                    } while (reader.NextResult());

                    // Find the row that contains "Dept" in the first column
                    int startRowIndex = CommonFunctions.FindDeptRow("Num", allRows);

                    if (startRowIndex == -1)
                    {
                        throw new InvalidOperationException("Could not find 'Dept' in the first column");
                    }

                    // Process rows starting after the "Dept" header row
                    for (int i = startRowIndex + 1; i < allRows.Count; i++)
                    {
                        var row = allRows[i];

                        // Skip empty rows
                        if (CommonFunctions.IsEmptyRow(row))
                            continue;

                        var lstRows = new BiWeeklyStaffingSummary()
                        {
                            DeptGroupNum = CommonFunctions.GetStringValue(row, 1),
                            DepartmentGroupName = CommonFunctions.GetStringValue(row, 2),
                            StatisticDescription = CommonFunctions.GetStringValue(row, 3),
                            PaidIdxTargetActualFtesPercent = CommonFunctions.GetDecimalValue(row, 4),
                            UOSActual = CommonFunctions.GetDecimalValue(row, 5),
                            TargetProdHoursUOS = CommonFunctions.GetDecimalValue(row, 6),
                            ActualProdHoursUOS = CommonFunctions.GetDecimalValue(row, 7),
                            ActualNonProdPercent = CommonFunctions.GetDecimalValue(row, 8),
                            ProductiveFtesTarget = CommonFunctions.GetDecimalValue(row, 9),
                            ProductiveFtesActual = CommonFunctions.GetDecimalValue(row, 10),
                            ProductiveFtesVariance = CommonFunctions.GetDecimalValue(row, 11),
                            PaidFtesTarget = CommonFunctions.GetDecimalValue(row, 12),
                            PaidFtesActual = CommonFunctions.GetDecimalValue(row, 13),
                            PaidFtesVariance = CommonFunctions.GetDecimalValue(row, 14),
                            OvertimeFtes = CommonFunctions.GetDecimalValue(row, 15),
                            OvertimePercent = CommonFunctions.GetDecimalValue(row, 16),
                            OvertimeTargetPercent = CommonFunctions.GetDecimalValue(row, 17),
                            ContractFtes = CommonFunctions.GetDecimalValue(row, 18),
                            ContractPercent = CommonFunctions.GetDecimalValue(row, 19),
                            ContractTargetPercent = CommonFunctions.GetDecimalValue(row, 20),
                            PRNFtes = CommonFunctions.GetDecimalValue(row, 21),
                            PRNPercent = CommonFunctions.GetDecimalValue(row, 22),
                        };
                        result.Add(lstRows);
                    }
                }
            }

            return result;
        }
    }
}
