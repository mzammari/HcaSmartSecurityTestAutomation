﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class StatisticVolumes
    {
        public static void GoTo()
        {
            FPCMainMenu.PLUS.Daily.SelectStatisticVolumes();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to Daily > Statistic Volumes", "The page is loaded correctly");
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static void ClickChooseFile()
        {
            //IJavaScriptExecutor js = Driver.Instance as IJavaScriptExecutor;
            //var ele = (IWebElement) js.ExecuteScript("document.querySelector('#fileImport_statvolume');");
            By byChoosefile = By.XPath("//*/div[@id='dailyStatVolumesCriteria']//table//tbody//input[@accept]");
            //CommonFunctions.getElement(byChoosefile).Click();
            var btnChooseFile = CommonFunctions.getElement(byChoosefile);
            btnChooseFile.Click();  
            //CommonFunctions.ClickByJE(btnChooseFile);
            CommonFunctions.AddTestStep("Click on the choose file button", "The file explorer is opened");
        }

        public static void ClickImportFile()
        {
            By byImport = By.XPath("//input[@id='submitDailyStatByDept']");
            var btnImport = CommonFunctions.getElement(byImport);
            CommonFunctions.ClickByJE(btnImport);
            CommonFunctions.AddTestStep("Click on the choose file button", "The file explorer is opened");
        }


        public static StatisticVolumesDeptViewCommand DeptView()
        {
            return new StatisticVolumesDeptViewCommand();
        }

        public static StatisticVolumesDaysViewCommand DaysView()
        {
            return new StatisticVolumesDaysViewCommand();
        }

        public static StatisticVolumesFacilityLevelStatisticsViewCommand FacilityLevelStatisticsView()
        {
            return new StatisticVolumesFacilityLevelStatisticsViewCommand();
        }
    }

    #region: StatisticVolumesDeptViewCommand
    public class StatisticVolumesDeptViewCommand
    {
        private string department;
        private string payPeriod;

        public StatisticVolumesDeptViewCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public StatisticVolumesDeptViewCommand withPayPeriod(string PayPeriod)
        {
            this.payPeriod = PayPeriod;
            return this;
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        private void setPayPeriod()
        {
            string xpath = "//select[@id='payPeriodTypesList' and not(@disabled)]";
            bool bExists = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bExists)
            {
                IWebElement mnuPayPeriod = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPayPeriod, payPeriod);
            }
        }

        private void selectView()
        {
            IWebElement mnuViewBy = CommonFunctions.getElement(By.XPath("//select[@id='viewModeChoiceList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuViewBy, "DEPT");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//select[@id='deptList']", 10);
        }

        public void GetData()
        {
            selectView();
            setDepartment();
            setPayPeriod();
            CommonFunctions.AddTestStep("Set dept and pay period", "The dept and pay period are set correctly");
        }
    }
    #endregion

    #region: StatisticVolumesDaysViewCommand
    public class StatisticVolumesDaysViewCommand
    {
        private string date;
        private string payPeriod;
        private string statisticDescription;

        public StatisticVolumesDaysViewCommand withDate(string Date)
        {
            this.date = Date;
            return this;
        }

        public StatisticVolumesDaysViewCommand withPayPeriod(string PayPeriod)
        {
            this.payPeriod = PayPeriod;
            return this;
        }

        public StatisticVolumesDaysViewCommand withStatisticDescription(string StatisticDescription)
        {
            this.statisticDescription = StatisticDescription;
            return this;
        }

        private void setDate()
        {
            IWebElement mnuDate = CommonFunctions.getElement(By.XPath("//select[@id='payPeriodDatesList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDate, date);
        }

        private void setPayPeriod()
        {
            string xpath = "//select[@id='payPeriodTypesList' and not(@disabled)]";
            bool bExists = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bExists)
            {
                IWebElement mnuPayPeriod = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPayPeriod, payPeriod);
            }
        }

        private void setStatisticDescription()
        {
            IWebElement mnuStatisticDescription = CommonFunctions.getElement(By.XPath("//select[@id='statList' and not(@disabled)]"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuStatisticDescription, statisticDescription);
        }

        private void selectView()
        {
            IWebElement mnuViewBy = CommonFunctions.getElement(By.XPath("//select[@id='viewModeChoiceList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuViewBy, "DAYS - LISTING DEPTS");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//select[@id='deptList']", 10);
        }

        public void GetData()
        {
            selectView();
           // setDate();
            setPayPeriod();
            setStatisticDescription();
        }
    }
    #endregion

    #region: StatisticVolumesFacilityLevelStatisticsViewCommand
    public class StatisticVolumesFacilityLevelStatisticsViewCommand
    {
        private string payPeriod;
        private string date;

        public StatisticVolumesFacilityLevelStatisticsViewCommand withPayPeriod(string PayPeriod)
        {
            this.payPeriod = PayPeriod;
            return this;
        }

        public StatisticVolumesFacilityLevelStatisticsViewCommand withDate(string Date)
        {
            this.date = Date;
            return this;
        }

        private void setPayPeriod()
        {
            string xpath = "//select[@id='payPeriodTypesList' and not(@disabled)]";
            bool bExists = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bExists)
            {
                IWebElement mnuPayPeriod = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPayPeriod, payPeriod);
            }
        }

        private void setDate()
        {
            IWebElement mnuDate = CommonFunctions.getElement(By.XPath("//select[@id='payPeriodDatesList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDate, date);
        }

        private void selectView()
        {
            IWebElement mnuViewBy = CommonFunctions.getElement(By.XPath("//select[@id='viewModeChoiceList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuViewBy, "FACILITY LEVEL STATISTICS");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//select[@id='deptList']", 10);
        }

        public void GetData()
        {
            selectView();
            setPayPeriod();
            //setDate();
        }
    }
    #endregion
}
