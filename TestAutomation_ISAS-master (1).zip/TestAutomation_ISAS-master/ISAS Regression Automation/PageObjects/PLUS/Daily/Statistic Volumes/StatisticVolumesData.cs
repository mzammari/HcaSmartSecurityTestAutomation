﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.SharedHoursData;

namespace ISAS_Regression_Automation
{
    public class StatisticVolumesData
    {
        #region: Statistic Volumes Dept View Data
        public class StatisticVolumesDeptViewData
        {
            public string Date { get; set; }
            public string StatisticDescription { get; set; }
            public string StatisticVol { get; set; }
            public string AdjValue { get; set; }
            public string Total { get; set; }
            public string Department { get; set; }
            public string Faciltiy { get; set; }
        }  

        public static List<StatisticVolumesDeptViewData> GetStatisticVolumesDeptViewData()
        {
            List<StatisticVolumesDeptViewData> lstStatisticVolumesDeptViewData = new List<StatisticVolumesDeptViewData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='dailyStatVolumeResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstStatisticVolumesDeptViewData.Add(new StatisticVolumesDeptViewData()
                {
                    Date = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    StatisticDescription = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    StatisticVol = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    AdjValue = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    Total = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value")
                });
            }
            return lstStatisticVolumesDeptViewData;
        }

        public static void SetStatisticVolumesDeptViewData(double value)
        {

            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='dailyStatVolumeResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                CommonFunctions.SetText(row.FindElement(By.XPath("td[4]/input")), (value += 1).ToString());
                value++;
            }
            StatisticVolumesMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
        }
        #endregion

        #region: Statistic Volumes Days View Data
        public static List<StatisticVolumesDeptViewData> GetStatisticVolumesDaysViewData()
        {
            List<StatisticVolumesDeptViewData> lstStatisticVolumesDeptViewData = new List<StatisticVolumesDeptViewData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='dailyStatVolumeResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstStatisticVolumesDeptViewData.Add(new StatisticVolumesDeptViewData()
                {
                    Department = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    StatisticDescription = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    StatisticVol = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    AdjValue = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    Total = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value")
                });
            }
            return lstStatisticVolumesDeptViewData;
        }

        public static void SetStatisticVolumesDaysViewData(double value)
        {

            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='dailyStatVolumeResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                try
                {
                    CommonFunctions.SetText(row.FindElement(By.XPath("td[4]/input[not(@disabled)]")), (value += 1).ToString());
                    value++;
                }
                catch 
                {
                    continue;
                }
            }
            StatisticVolumesMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
        }
        #endregion

        #region: Statistic Volumes Facility Level statistics View Data
        public static List<StatisticVolumesDeptViewData> GetStatisticVolumesFacilityLevelStatisticsViewData()
        {
            List<StatisticVolumesDeptViewData> lstStatisticVolumesDeptViewData = new List<StatisticVolumesDeptViewData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='facilityLevelStatVolumesDetailsByDate']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstStatisticVolumesDeptViewData.Add(new StatisticVolumesDeptViewData()
                {
                    Faciltiy = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    StatisticDescription = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    StatisticVol = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    AdjValue = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    Total = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value")
                });
            }
            return lstStatisticVolumesDeptViewData;
        }

        public static void SetStatisticVolumesFacilityLevelStatisticsViewData(double value)
        {

            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='facilityLevelStatVolumesDetailsByDate']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                try
                {
                    CommonFunctions.SetText(row.FindElement(By.XPath("td[4]/input[not(@disabled)]")), (value += 1).ToString());
                    value++;
                }
                catch
                {
                    continue;
                }
            }
            StatisticVolumesMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        #endregion
    }
}
