﻿using OpenQA.Selenium;
using System.Collections.Generic;

namespace ISAS_Regression_Automation
{
    public class SharedHoursData
    {
        #region: SharedHoursDaysViewData
        public class SharedHoursDaysViewData
        {
            public string Department { get; set; }
            public string DayProdHours { get; set; }
            public string NightProdHours { get; set; }
            public string DayNonProdHours { get; set; }
            public string NightNonProdHours { get; set; }
            public string DayOtHours { get; set; }
            public string NightOtHours { get; set; }
        }

        public static List<SharedHoursDaysViewData> GetSharedHoursDaysViewData()
        {
            List<SharedHoursDaysViewData> lstSharedHoursDaysViewData = new List<SharedHoursDaysViewData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='sharedHoursDetailsByDate']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstSharedHoursDaysViewData.Add(new SharedHoursDaysViewData()
                {
                    Department = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    DayProdHours = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    NightProdHours = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    DayNonProdHours = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    NightNonProdHours = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                    DayOtHours = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                    NightOtHours = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value")
                });
            }
            return lstSharedHoursDaysViewData;
        }

        public static void SetSharedHoursDaysViewData(double value)
        {
            
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='sharedHoursDetailsByDate']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                CommonFunctions.SetText(row.FindElement(By.XPath("td[2]/input")), (value += 1).ToString());
                CommonFunctions.SetText(row.FindElement(By.XPath("td[4]/input")),(value += 2).ToString());
                CommonFunctions.SetText(row.FindElement(By.XPath("td[6]/input")),"4");
                value++;
            }
            SharedHoursMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
        }
        #endregion

        #region: Shared Hours Dept View Data
        public class SharedHoursDeptViewData
        {
            public string Date { get; set; }
            public string DayProdHours { get; set; }
            public string NightProdHours { get; set; }
            public string DayNonProdHours { get; set; }
            public string NightNonProdHours { get; set; }
            public string DayOtHours { get; set; }
            public string NightOtHours { get; set; }
        }

        public static List<SharedHoursDeptViewData> GetSharedHoursDeptViewData()
        {
            List<SharedHoursDeptViewData> lstSharedHoursDeptViewData = new List<SharedHoursDeptViewData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='sharedHoursDetailsResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstSharedHoursDeptViewData.Add(new SharedHoursDeptViewData()
                {
                    Date = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    DayProdHours = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    NightProdHours = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    DayNonProdHours = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    NightNonProdHours = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                    DayOtHours = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                    NightOtHours = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value")
                });
            }
            return lstSharedHoursDeptViewData;
        }

        public static void SetSharedHoursDeptViewData(double value)
        {

            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='sharedHoursDetailsResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                CommonFunctions.SetText(row.FindElement(By.XPath("td[2]/input")),(value += 1).ToString());
                CommonFunctions.SetText(row.FindElement(By.XPath("td[4]/input")),(value += 2).ToString());
                CommonFunctions.SetText(row.FindElement(By.XPath("td[6]/input")),"3");
                value++;
            }
           var firstCell =  CommonFunctions.getElement(By.XPath("//*/div[@id='sharedHoursDetailsResults']//table/tbody//tr/td[1]/input"));
            firstCell.Click();
            SharedHoursMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
        }
        #endregion
    }
}
