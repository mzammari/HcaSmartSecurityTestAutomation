﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class SharedHours
    {
        public static void GoTo()
        {
            FPCMainMenu.PLUS.Daily.SelectSharedHours();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static SharedHoursDeptCommand DeptView()
        {
            return new SharedHoursDeptCommand();
        }

        public static SharedHoursDaysViewCommand DaysView()
        {
            return new SharedHoursDaysViewCommand();
        }

    }

    #region: SharedHoursDeptCommand
    public class SharedHoursDeptCommand
    {
        private string direction;
        private string payPeriod;
        private string department;
        private string skillMix;

        public SharedHoursDeptCommand withDirection(string Direction)
        {
            this.direction = Direction;
            return this;
        }

        public SharedHoursDeptCommand withPayPeriod(string PayPeriod)
        {
            this.payPeriod = PayPeriod;
            return this;
        }

        public SharedHoursDeptCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public SharedHoursDeptCommand withSkillMix(string SkillMix)
        {
            this.skillMix = SkillMix;
            return this;
        }

        private void setDirection()
        {
            IWebElement mnuDirection = CommonFunctions.getElement(By.XPath("//select[@id='sharedLaborDirectionList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDirection, direction);
        }

        private void setPayPeriod()
        {
            string xpath = "//select[@id='payPeriodTypesList' and not(@disabled)]";
            bool bExists = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bExists)
            {
                IWebElement mnuPayPeriod = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPayPeriod, payPeriod);
            }
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        private void setSkillMix()
        {
            IWebElement mnuSkillMix = CommonFunctions.getElement(By.XPath("//select[@id='skillMixList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuSkillMix, skillMix);
        }

        private void selectView()
        {
            IWebElement mnuViewBy = CommonFunctions.getElement(By.XPath("//select[@id='viewModeChoiceList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuViewBy, "DEPT");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//select[@id='deptList']", 10);
        }

        public void GetData()
        {
            selectView();
            setDirection();
            setPayPeriod();
            setDepartment();
            setSkillMix();
            CommonFunctions.WaitUntilPageIsAcive();
        }
    }
    #endregion

    #region: SharedHoursDaysViewCommand
    public class SharedHoursDaysViewCommand
    {
        private string direction;
        private string payPeriod;
        private string date;
        private string skillMix;

        public SharedHoursDaysViewCommand withDirection(string Direction)
        {
            this.direction = Direction;
            return this;
        }

        public SharedHoursDaysViewCommand withPayPeriod(string PayPeriod)
        {
            this.payPeriod = PayPeriod;
            return this;
        }

        public SharedHoursDaysViewCommand withDate(string Date)
        {
            this.date = Date;
            return this;
        }

        public SharedHoursDaysViewCommand withSkillMix(string SkillMix)
        {
            this.skillMix = SkillMix;
            return this;
        }

        private void setDirection()
        {
            IWebElement mnuDirection = CommonFunctions.getElement(By.XPath("//select[@id='sharedLaborDirectionList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDirection, direction);
        }

        private void setPayPeriod()
        {
            string xpath = "//select[@id='payPeriodTypesList' and not(@disabled)]";
            bool bExists = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bExists)
            {
                IWebElement mnuPayPeriod = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPayPeriod, payPeriod);
            }
        }

        private void setDate()
        {
            IWebElement mnuDate = CommonFunctions.getElement(By.XPath("//select[@id='payPeriodDatesList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDate, date);
        }

        private void setSkillMix()
        {
            IWebElement mnuSkillMix = CommonFunctions.getElement(By.XPath("//select[@id='skillMixList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuSkillMix, skillMix);
        }

        private void selectView()
        {
            IWebElement mnuViewBy = CommonFunctions.getElement(By.XPath("//select[@id='viewModeChoiceList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuViewBy, "DAYS - LISTING DEPTS");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//select[@id='payPeriodDatesList']", 10);
        }

        public void GetData()
        {
            selectView();
            setDirection();
            setPayPeriod();
            //setDate();
            setSkillMix();
            CommonFunctions.WaitUntilPageIsAcive();
        }
    }
    #endregion
}
