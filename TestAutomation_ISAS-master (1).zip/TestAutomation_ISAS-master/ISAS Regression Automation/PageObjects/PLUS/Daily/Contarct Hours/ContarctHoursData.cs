﻿using OpenQA.Selenium;
using System.Collections.Generic;
using System.Threading;

namespace ISAS_Regression_Automation
{
    public class ContarctHoursData
    {
        public class DaysViewData
        {
            public string Department { get; set; }
            public string Rate { get; set; }
            public string InterfacedHours { get; set; }
            public string DayAdjHours	 { get; set; }
            public string NightAdjHours { get; set; }
            public string TotalHours	 { get; set; }
            public string TotalDollars  { get; set; }
            public string Date { get; set; }
        }

        #region: Action
        public static List<DaysViewData> GetDaysViewData()
        {
            List<DaysViewData> lstDaysViewData = new List<DaysViewData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='contractHoursDetailsByDate']//table/tbody//tr"));
            foreach(var row in lstRows)
            {
                lstDaysViewData.Add(new DaysViewData()
                {
                    Department = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    Rate = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    InterfacedHours = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    DayAdjHours = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    NightAdjHours = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                    TotalHours = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                    TotalDollars = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value")
                });
            }
            return lstDaysViewData;
        }

        public static List<DaysViewData> GetDeptarmentViewData()
        {
            List<DaysViewData> lstDaysViewData = new List<DaysViewData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='contractHoursDetailsResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstDaysViewData.Add(new DaysViewData()
                {
                    Date = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    Rate = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    InterfacedHours = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    DayAdjHours = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    NightAdjHours = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                    TotalHours = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                    TotalDollars = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value")
                });
            }
            return lstDaysViewData;
        }

        public static void SetDepartmentAdjHours(string hrs)
        {
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='contractHoursDetailsResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                IWebElement AdjHours = row.FindElement(By.XPath("td[4]/input"));
                CommonFunctions.SetText(AdjHours, hrs);
                Thread.Sleep(1000);
            }
            ContractHoursMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
        }

        public static void SetDaysAdjHours(string hrs)
        {
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='contractHoursDetailsResults']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                IWebElement AdjHours = row.FindElement(By.XPath("td[4]/input"));
                CommonFunctions.SetText(AdjHours, hrs);
                Thread.Sleep(1000);
            }
            ContractHoursMenu.Save();           
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
        }
        #endregion
    }
}
