﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class ContractHours
    {
        public static void GoTo()
        {
            FPCMainMenu.PLUS.Daily.SelectContractHours();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }


        public static ContractHoursDeptViewCommand DeptView()
        {
            return new ContractHoursDeptViewCommand();
        }

        public static ContractHoursDaysViewCommand DaysView()
        {
            return new ContractHoursDaysViewCommand();
        }
    }

    #region: ContractHoursDeptViewCommand
    public class ContractHoursDeptViewCommand
    {
        private string department;
        private string skillMix;

        public ContractHoursDeptViewCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public ContractHoursDeptViewCommand withSkillMix(string SkillMix)
        {
            this.skillMix = SkillMix;
            return this;
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        private void setSkillMix()
        {
            IWebElement mnuSkillMix = CommonFunctions.getElement(By.XPath("//select[@id='skillMixList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuSkillMix, skillMix);
        }
        private void selectView()
        {
            IWebElement mnuViewBy = CommonFunctions.getElement(By.XPath("//select[@id='viewModeChoiceList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuViewBy, "DEPT");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//select[@id='deptList']", 10);
        }

        public void getData()
        {
            selectView();
            setDepartment();
            setSkillMix();
        }
    }
    #endregion

    #region: ContractHoursDaysViewCommand
    public class ContractHoursDaysViewCommand
    {
        private string payPeriod;
        private string date;
        private string skillMix;

        public ContractHoursDaysViewCommand withPayPeriod(string PayPeriod)
        {
            this.payPeriod = PayPeriod;
            return this;
        }

        public ContractHoursDaysViewCommand withDate(string Date)
        {
            this.date = Date;
            return this;
        }

        public ContractHoursDaysViewCommand withSkillMix(string SkillMix)
        {
            this.skillMix = SkillMix;
            return this;
        }

        private void setPayPeriod()
        {
            string xpath = "//select[@id='payPeriodTypesList' and not(@disabled)]";
            bool bExists = CommonFunctions.IsElementDisplayed(xpath, 1);
            if(bExists)
            {
                IWebElement mnuPayPeriod = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPayPeriod, payPeriod);
            }
        }

        private void setDate()
        {
            IWebElement mnuDate = CommonFunctions.getElement(By.XPath("//select[@id='payPeriodDatesList']"));
           //CommonFunctions.SelectItemFromDropdownMenu(mnuDate, date);
        }

        private void setSkillMix()
        {
            IWebElement mnuSkillMix = CommonFunctions.getElement(By.XPath("//select[@id='skillMixList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuSkillMix, skillMix);
        }

        private void selectView()
        {
            IWebElement mnuViewBy = CommonFunctions.getElement(By.XPath("//select[@id='viewModeChoiceList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuViewBy, "DAYS - LISTING DEPTS");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.IsElementDisplayed("//select[@id='payPeriodDatesList']", 10);
        }

        public void GetData()
        {
            selectView();
            setPayPeriod();
            setDate();
            setSkillMix();
        }
    }
    #endregion
}
