﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class PlusMenu
    {
        public static void SetViewBy(string viewBy)
        {
            By byView = By.Id("viewModeChoiceList");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.SelectItemFromDropdownMenu(CommonFunctions.getElement(byView), viewBy);
        }
    }
}
