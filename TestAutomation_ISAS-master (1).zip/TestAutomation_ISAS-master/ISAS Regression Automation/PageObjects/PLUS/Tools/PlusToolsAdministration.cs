﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class PlusToolsAdministration
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Tools.SelectAdministration();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='actionTypes']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static PlusToolsAdministrationCommand Task()
        {
            return new PlusToolsAdministrationCommand();
        }

        public static TaskSummaryData getTaskSummaryData()
        {
            return new TaskSummaryData()
            {
                RequestedBy = CommonFunctions.getElement(By.XPath("//*/div[@id='taskDetaills']//table/tbody//tr/td/input[contains(@value,'Requested By')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                ApprovedBy = CommonFunctions.getElement(By.XPath("//*/div[@id='taskDetaills']//table/tbody//tr/td/input[contains(@value,'Approved By')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                Status = CommonFunctions.getElement(By.XPath("//*/div[@id='taskDetaills']//table/tbody//tr/td/input[contains(@value,'Status')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                Comments = CommonFunctions.getElement(By.XPath("//*/div[@id='taskDetaills']//table/tbody//tr/td/input[contains(@value,'Comments')]/parent::td/following-sibling::td[1]/textarea")).Text,
                RequestedOn = CommonFunctions.getElement(By.XPath("//*/div[@id='taskDetaills']//table/tbody//tr/td/input[contains(@value,'Requested On')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                ApprovedOn = CommonFunctions.getElement(By.XPath("//*/div[@id='taskDetaills']//table/tbody//tr/td/input[contains(@value,'Approved On')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value")
            };
        }
    }

    #region: PlusToolsAdministrationCommand
    public class PlusToolsAdministrationCommand
    {
        private string action;
        private string jobStatus;
        private string task;

        public PlusToolsAdministrationCommand withAction(string Action)
        {
            this.action = Action;
            return this;
        }

        public PlusToolsAdministrationCommand withJobStatus(string JobStatus)
        {
            this.jobStatus = JobStatus;
            return this;
        }

        public PlusToolsAdministrationCommand withTask(string Task)
        {
            this.task = Task;
            return this;
        }

        private void setAction()
        {
            IWebElement mnuAction = CommonFunctions.getElement(By.XPath("//select[@id='actionTypes']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuAction, action);
        }

        private void setJobStatus()
        {
            IWebElement mnuJobStatus = CommonFunctions.getElement(By.XPath("//select[@id='jobStatuses']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuJobStatus, jobStatus);
            CommonFunctions.WaitTillPageIsComplete();
        }

        private void setTask()
        {
            IWebElement mnuTask = CommonFunctions.getElement(By.XPath("//select[@id='tasks']"));
            CommonFunctions.SelectItemFromDropdownMenuByIndex(mnuTask, 1);
        }

        private void clickViewTask()
        {
            IWebElement cmdViewTask = CommonFunctions.getElement(By.XPath("//*/a[@id='viewTaskBtn']"));
            CommonFunctions.ClickByJE(cmdViewTask);
        }

        public void ViewTask()
        {
            setAction();
            setJobStatus();
            //setTask();
            clickViewTask();
            CommonFunctions.WaitUntilPageIsAcive();
        }
    }
    #endregion

    #region: Task Summary Data
    public class TaskSummaryData
    {
        public string RequestedBy { get; set; }
        public string ApprovedBy { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
        public string RequestedOn { get; set; }
        public string ApprovedOn { get; set; }
    }
    #endregion
}
