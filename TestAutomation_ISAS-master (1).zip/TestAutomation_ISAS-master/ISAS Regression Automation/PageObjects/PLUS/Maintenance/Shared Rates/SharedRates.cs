﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class SharedRates
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectSharedRates();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static List<clContractRatesData> GetSharedRatesData()
        {
            List<clContractRatesData> lstContractRatesData = new List<clContractRatesData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='sharedRatesDetailsByDept']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstContractRatesData.Add(new clContractRatesData()
                {
                    Code = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    SkillMix = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    AverageRate = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    OverrideRate = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    RateToUse = row.FindElement(By.XPath("td[5]/select/option[@selected]")).Text
                });
            }
            return lstContractRatesData;
        }

        public static void SetSharedRatesData(double OverrideRate, string RateToUse)
        {
            bool bExist;
            string tblXpath = "//*/div[@id='sharedRatesDetailsByDept']//table/tbody//tr";
            bExist = CommonFunctions.IsElementDisplayed(tblXpath, 2);
            if (bExist)
            {
                IWebElement mnuRateToUse = CommonFunctions.getElement(By.XPath("//*/div[@id='sharedRatesDetailsByDept']//table/tbody//tr[1]//td[5]/select"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuRateToUse, RateToUse.Trim());
                ContractRatesMenu.Save();
                CommonFunctions.WaitSaveToastMsgDisappeared();
            }

        }

        public static SharedRatesCommand SharedRate()
        {
            return new SharedRatesCommand();
        }
    }
    #region: SharedRatesCommand
    public class SharedRatesCommand
    {
        private string direction;
        private string department;
        private string skillMix;

        public SharedRatesCommand withDirection(string Direction)
        {
            this.direction = Direction;
            return this;
        }

        public SharedRatesCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public SharedRatesCommand withSkillMix(string SkillMix)
        {
            this.skillMix = SkillMix;
            return this;
        }

        private void setDirection()
        {
            IWebElement mnuDirection = CommonFunctions.getElement(By.XPath("//select[@id='sharedLaborDirectionList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDirection, direction);
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        private void setSkillMix()
        {
            for (int i = 0; i < 1; i++)
            {
                IWebElement mnuSkillMix = CommonFunctions.getElement(By.XPath("//*/select[@id='skillMixList']"));
                try
                {
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.SelectItemFromDropdownMenu(mnuSkillMix, skillMix);
                }
                catch
                {
                    try
                    {
                        CommonFunctions.SelectItemFromDropdownMenuByIndex(mnuSkillMix, 2);
                    }
                    catch 
                    {
                        break;
                    }
                }
            }
        }

        private void clickAdd()
        {
            bool bExist;
            var SharedRatesData = SharedRates.GetSharedRatesData();
            bExist = SharedRatesData.Exists(x => x.Code.Contains(skillMix));
            if (!bExist)
            {
                IWebElement cmdAdd = CommonFunctions.getElement(By.XPath("//*/a[@id='addSkillMixBtn']"));
                CommonFunctions.ClickByJE(cmdAdd);
                ConfirmAddtion();
            }
        }

        private void ConfirmAddtion()
        {
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-new-rate-addition-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
            CommonFunctions.ClickByJE(cmdYes);
        }

        public void Add()
        {
            setDirection();
            setDepartment();
            setSkillMix();
            clickAdd();
            ContractRatesMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
        }
    }
    #endregion
}
