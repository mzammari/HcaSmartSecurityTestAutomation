﻿using AventStack.ExtentReports.Model;
using ImageMagick;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.ContarctHoursData;
using static ISAS_Regression_Automation.WFTMainMenu.WFTReports;

namespace ISAS_Regression_Automation
{
    public class StatisticAssignment
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectStatisticAssignment();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static StatisticAssignmentDepartmentViewCommand DeptartmentView()
        {
            return new StatisticAssignmentDepartmentViewCommand();
        }

        public static StatisticAssignmentDepartmentView getStatisticAssignmentForDepartment()
        {
            StatisticAssignmentDepartmentView statisticAssignmentDepartmentView = new StatisticAssignmentDepartmentView();
            return new StatisticAssignmentDepartmentView()
            {
                DepartmentGroup = CommonFunctions.getElement(By.XPath("//*/div[@id='statisticAssignmentByDepartmentView']//table//tbody//tr[1]//td[2]/input")).GetAttribute("value"),
                DepartmentCategory = CommonFunctions.getElement(By.XPath("//*/div[@id='statisticAssignmentByDepartmentView']//table//tbody//tr[2]//td[2]/input")).GetAttribute("value"),
                Subfunction = CommonFunctions.getElement(By.XPath("//*/div[@id='statisticAssignmentByDepartmentView']//table//tbody//tr[3]//td[2]/input")).GetAttribute("value"),
                StatisticDescription = CommonFunctions.getElement(By.XPath("//*/div[@id='statisticAssignmentByDepartmentView']//table//tbody//tr[4]//td[2]/select/option[@selected]")).Text
            };
        }

        public static StatisticAssignmentGroupViewCommand GroupView()
        {
            return new StatisticAssignmentGroupViewCommand();
        }

        public static List<ExistingDepartmentsInGroup> getExistingDepartmentsInThisGroup()
        {
            List<ExistingDepartmentsInGroup> lstGroupViewData = new List<ExistingDepartmentsInGroup>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='statisticAssignmentByGroupView']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstGroupViewData.Add(new ExistingDepartmentsInGroup()
                {
                    AssignStatisticVolume = row.FindElement(By.XPath("td[1]/input")).Selected,
                    Department = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    Category = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    StatisticDescription = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    Subfunction = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value")
                });
            }
            return lstGroupViewData;

        }

    }

    #region: StatisticAssignmentDepartmentViewCommand
    public class StatisticAssignmentDepartmentViewCommand
    {
        private string department;

        public StatisticAssignmentDepartmentViewCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        public void View()
        {
            setDepartment();
        }
    }
    #endregion

    #region: StatisticAssignmentDepartmentView 
    public class StatisticAssignmentDepartmentView
    {
        public string DepartmentGroup { get; set; }
        public string DepartmentCategory { get; set; }
        public string Subfunction { get; set; }
        public string StatisticDescription { get; set; }
    }
    #endregion

    #region: StatisticAssignmentGroupViewCommand
    public class StatisticAssignmentGroupViewCommand
    {
        private string groupName;
        private string statisticVolumeBasedOn;
        private string statisticToUse;

        public StatisticAssignmentGroupViewCommand withGroupName(string GroupName)
        {
            this.groupName = GroupName;
            return this;
        }

        public StatisticAssignmentGroupViewCommand withStatisticVolumeBasedOn(string StatisticVolumeBasedOn)
        {
            this.statisticVolumeBasedOn = StatisticVolumeBasedOn;
            return this;
        }

        public StatisticAssignmentGroupViewCommand withStatisticToUse(string StatisticToUse)
        {
            this.statisticToUse = StatisticToUse;
            return this;
        }

        private void setGroupName()
        {
            IWebElement mnuGroupName = CommonFunctions.getElement(By.XPath("//select[@id='groupList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuGroupName, groupName);
        }

        private void setStatisticVolumeBasedOn()
        {
            IWebElement mnuStatisticVolumeBasedOn = CommonFunctions.getElement(By.XPath("//select[@id='statisticVolumeBasedOn']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuStatisticVolumeBasedOn, statisticVolumeBasedOn);
        }

        private void setStatisticToUse()
        {
            IWebElement mnuStatisticToUse = CommonFunctions.getElement(By.XPath("//select[@id='statisticTouse']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuStatisticToUse, statisticToUse);
        }

        private void selectViewBy()
        {
            IWebElement mnuViewBy = CommonFunctions.getElement(By.XPath("//select[@id='viewModeChoiceList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuViewBy, "Group");
        }

        public void View()
        {
            selectViewBy();
            CommonFunctions.WaitUntilPageIsAcive();
            setGroupName();
            setStatisticVolumeBasedOn();
            setStatisticToUse();
        }
    }
    #endregion

    #region: Gourp View Result
    public class ExistingDepartmentsInGroup
    {
        public bool AssignStatisticVolume { get; set; }
        public string Department { get; set; }
        public string Category { get; set; }
        public string StatisticDescription	 { get; set; }
        public string Subfunction { get; set; }
    }
    #endregion


}
