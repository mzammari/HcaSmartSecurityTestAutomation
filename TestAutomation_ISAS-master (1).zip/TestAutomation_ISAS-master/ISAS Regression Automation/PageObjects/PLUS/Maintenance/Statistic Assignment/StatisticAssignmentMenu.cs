﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class StatisticAssignmentMenu
    {
        public static void Save()
        {
            bool bDisplayed, bEnabled;
            string ConfirmSaveXpath = "//*/div[@aria-labelledby='ui-dialog-title-dept-stat-assignmentsave-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='No']";
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-save-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string SaveXpath = "//*/a[@id='saveAssignmentBtn' and not(@disabled)]"; //and not(@disabled)
            bEnabled = CommonFunctions.IsElementDisplayed(SaveXpath, 5);
            if (bEnabled)
            {
                IWebElement cmdSave = CommonFunctions.getElement(By.XPath(SaveXpath));
                CommonFunctions.ClickByJE(cmdSave);
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmSaveXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdOK = CommonFunctions.getElement(By.XPath(ConfirmSaveXpath));
                    CommonFunctions.ClickByJE(cmdOK);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdOK = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                    CommonFunctions.ClickByJE(cmdOK);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }
            }
        }
    }
}
