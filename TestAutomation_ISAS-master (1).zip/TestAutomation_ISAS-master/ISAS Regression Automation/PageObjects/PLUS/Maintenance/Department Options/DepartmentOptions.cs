﻿using Microsoft.VisualBasic;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.WFTMainMenu.WFTReports;

namespace ISAS_Regression_Automation
{
    public class DepartmentOptions
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectDepartmentOptions();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static DepartmentOptionsCommand DeptOptions()
        {
            return new DepartmentOptionsCommand();
        }

        public static DepartmentInformationData getDepartmentInformationData()
        {            
            return new DepartmentInformationData()
            {
                DepartmentGroup = CommonFunctions.getElement(By.XPath("//*/div[@id='departmentOptionsView']//table/tbody//tr/td/input[contains(@value,'Department Group')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                UpdatedBy = CommonFunctions.getElement(By.XPath("//*/div[@id='departmentOptionsView']//table/tbody//tr/td/input[contains(@value,'Updated By')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                SubfunctionNo = CommonFunctions.getElement(By.XPath("//*/div[@id='departmentOptionsView']//table/tbody//tr/td/input[contains(@value,'Subfunction No:')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                SubfunctionDescription = CommonFunctions.getElement(By.XPath("//*/div[@id='departmentOptionsView']//table/tbody//tr/td/input[contains(@value,'Subfunction Description')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                StatisticDescription = CommonFunctions.getElement(By.XPath("//*/div[@id='departmentOptionsView']//table/tbody//tr/td/input[contains(@value,'Statistic Description')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                TargetSource = CommonFunctions.getElement(By.XPath("//*/div[@id='departmentOptionsView']//table/tbody//tr/td/input[contains(@value,'Target Source')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                UpdatedOn = CommonFunctions.getElement(By.XPath("//*/div[@id='departmentOptionsView']//table/tbody//tr/td/input[contains(@value,'Updated On')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value")  
            };
        }
    }

    #region: DepartmentOptionsCommand
    public class DepartmentOptionsCommand
    {
        private string department;
        private string departmentCategory;
        private bool ignoreDepartment;
        private bool allowStatisticVolumeAdjustment;
        private bool allowPLUSSharedOutHourEntry;
        private bool freezeDepartmentPAVolumes;
        private string contractLaborPercentage;
        private string fixedNoOfFtes;

        public DepartmentOptionsCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public DepartmentOptionsCommand withDepartmentCategory(string DepartmentCategory)
        {
            this.departmentCategory = DepartmentCategory;
            return this;
        }

        public DepartmentOptionsCommand withIgnoreDepartment(bool IgnoreDepartment)
        {
            this.ignoreDepartment = IgnoreDepartment;
            return this;
        }

        public DepartmentOptionsCommand withAllowStatisticVolumeAdjustment(bool AllowStatisticVolumeAdjustment)
        {
            this.allowStatisticVolumeAdjustment = AllowStatisticVolumeAdjustment;
            return this;
        }

        public DepartmentOptionsCommand withAllowPLUSSharedOutHourEntry(bool AllowPLUSSharedOutHourEntry)
        {
            this.allowPLUSSharedOutHourEntry = AllowPLUSSharedOutHourEntry;
            return this;
        }

        public DepartmentOptionsCommand withFreezeDepartmentPAVolumes(bool FreezeDepartmentPAVolumes)
        {
            this.freezeDepartmentPAVolumes = FreezeDepartmentPAVolumes;
            return this;
        }

        public DepartmentOptionsCommand withContractLaborPercentage(string ContractLaborPercentage)
        {
            this.contractLaborPercentage = ContractLaborPercentage;
            return this;
        }

        public DepartmentOptionsCommand withFixedNoOfFtes(string FixedNoOfFtes)
        {
            this.fixedNoOfFtes = FixedNoOfFtes;
            return this;
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        private void setDepartmentCategory()
        {
            IWebElement mnuDepartmentCategory = CommonFunctions.getElement(By.XPath("//select[@id='deptCategory']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartmentCategory, departmentCategory);
        }

        private void setIgnoreDepartment()
        {
            string xpath = "//input[@id='ignoredDept' and not(@disabled)]";
            bool bExist;
            bExist = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bExist)
            {
                IWebElement chkIgnoreDepartment = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SetCheckbox(chkIgnoreDepartment, ignoreDepartment);
            }
        }

        private void setAllowStatisticVolumeAdjustment()
        {
            IWebElement chkAllowStatisticVolumeAdjustment = CommonFunctions.getElement(By.XPath("//input[@id='allowAllowVolumeAdjustment']"));
            CommonFunctions.SetCheckbox(chkAllowStatisticVolumeAdjustment, allowStatisticVolumeAdjustment);
        }

        private void setAllowPLUSSharedOutHourEntry()
        {
            IWebElement chkAllowPLUSSharedOutHourEntry = CommonFunctions.getElement(By.XPath("//input[@id='allowSohFlag']"));
            CommonFunctions.SetCheckbox(chkAllowPLUSSharedOutHourEntry, allowPLUSSharedOutHourEntry);
        }

        private void setFreezeDepartmentPAVolumes()
        {
            string xpath = "//input[@id='freezeDeptVolumes' and not(@disabled)]";
            bool bExist;
            bExist = CommonFunctions.IsElementDisplayed(xpath, 1);
            if (bExist)
            {
                IWebElement chkFreezeDepartmentPAVolumes = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.SetCheckbox(chkFreezeDepartmentPAVolumes, freezeDepartmentPAVolumes);
            }
        }

        private void setContractLaborPercentage()
        {
            IWebElement txtContractLaborPercentage = CommonFunctions.getElement(By.XPath("//input[@id='contractlaborpercent']"));
            CommonFunctions.ReplaceAndSetText(txtContractLaborPercentage, contractLaborPercentage);
        }

        private void setFixedNoOfFtes()
        {
            IWebElement txtFixedNoOfFtes = CommonFunctions.getElement(By.XPath("//input[@id='outsourcedftes']"));
            CommonFunctions.ReplaceAndSetText(txtFixedNoOfFtes, fixedNoOfFtes);
        }

        public void Save()
        {
            setDepartment();
            //setDepartmentCategory();
            setIgnoreDepartment();
            setAllowStatisticVolumeAdjustment();
            setAllowPLUSSharedOutHourEntry();
            setFreezeDepartmentPAVolumes();
            setContractLaborPercentage();
            setFixedNoOfFtes();
            DepartmentOptionsMenu.Save();   
        }
    }
    #endregion

    #region: Department Information data
    public class DepartmentInformationData
    {
        public string DepartmentGroup { get; set; }
        public string SubfunctionNo { get; set; }
        public string SubfunctionDescription { get; set; }
        public string StatisticDescription { get; set; }
        public string TargetSource { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedOn { get; set; }
    }
    #endregion
}
