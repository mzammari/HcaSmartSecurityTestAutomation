﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.ProcedureMultiplierData;

namespace ISAS_Regression_Automation
{
    public class ContractRates
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectContractRates();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to Contract Rates ", "Contract Rates page is loaded");
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static List<clContractRatesData> GetContractRatesData()
        {
            CommonFunctions.AddTestStep("Verify a user can get Contract Rates Data", "Contract Rates Data is retrieved");
            List<clContractRatesData> lstContractRatesData = new List<clContractRatesData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='contractRatesDetailsResultsContainer']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstContractRatesData.Add(new clContractRatesData()
                {
                    Code = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    SkillMix = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    AverageRate = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    OverrideRate = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    RateToUse = row.FindElement(By.XPath("td[5]/select/option[@selected]")).Text
                });
            }
            return lstContractRatesData;
        }

        public static void SetContractRatesData(double OverrideRate, string RateToUse)
        {
            CommonFunctions.AddTestStep($"Verify a user can set Contract Rates Data - OverrideRate {OverrideRate} - Rate To Use {RateToUse}", "Contract Rates Data is set correctly");
            bool bExist;
            string tblXpath = "//*/div[@id='contractRatesDetailsResultsContainer']//table/tbody//tr";
            bExist = CommonFunctions.IsElementDisplayed(tblXpath, 2);
            if (bExist)
            {
                IWebElement mnuRateToUse = CommonFunctions.getElement(By.XPath("//*/div[@id='contractRatesDetailsResultsContainer']//table/tbody//tr[1]//td[5]/select"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuRateToUse, RateToUse.Trim());
                ContractRatesMenu.Save();
                CommonFunctions.WaitUntilPageIsAcive();
            }
            
        }

        public static ContractRatesCommand ContractRate()
        {
            return new ContractRatesCommand();
        }
    }

    #region: ContractRatesCommand
    public class ContractRatesCommand
    {
        private string department;
        private string skillMix;

        public ContractRatesCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public ContractRatesCommand withSkillMix(string SkillMix)
        {
            this.skillMix = SkillMix;
            return this;
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
            CommonFunctions.AddTestStep($"Verify a user set department {department}", $"The {department} is selected");
        }

        private void setSkillMix()
        {
            for (int i = 0; i < 1; i++)
            {
                IWebElement mnuSkillMix = CommonFunctions.getElement(By.XPath("//*/select[@id='skillMixList']"));
                try
                {
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.SelectItemFromDropdownMenu(mnuSkillMix, skillMix);
                    CommonFunctions.AddTestStep($"Verify a user set skill mix {skillMix}", $"The {skillMix} is selected");
                }
                catch
                {
                    try
                    {
                        CommonFunctions.SelectItemFromDropdownMenuByIndex(mnuSkillMix, 2);
                    }
                    catch
                    {
                        break;
                    }
                }
            }
        }

        private void clickAdd()
        {
            bool bExist;
            var ContractRatesDetailsResultsData = ContractRatesDetail.getContractRatesDetailsResults();
            bExist = ContractRatesDetailsResultsData.Exists(x => x.Code.Contains(skillMix));
            if (!bExist)
            {
                IWebElement cmdAdd = CommonFunctions.getElement(By.XPath("//*/a[@id='addSkillMixBtn']"));
                CommonFunctions.ClickByJE(cmdAdd);
                ConfirmAddtion();
            }
            CommonFunctions.AddTestStep("Click the add button", "The add button is enabled");
        }

        private void ConfirmAddtion()
        {
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-new-rate-addition-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
            CommonFunctions.ClickByJE(cmdYes);
            CommonFunctions.AddTestStep("Click the confirm button", "The Yes button is enabled");
        }

        public void Add()
        {
            setDepartment();
            setSkillMix();
            clickAdd();
            ContractRatesMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
            CommonFunctions.AddTestStep("Verify a user can add skill mix", "Skill mix is added.");
        }
    }
    #endregion

    #region: ContractRatesData
    public class clContractRatesData
    {
        public string Code { get; set; }
        public string SkillMix { get; set; }
        public string AverageRate { get; set; }
        public string OverrideRate	 { get; set; }
        public string RateToUse { get; set; }
    }
    #endregion
}
