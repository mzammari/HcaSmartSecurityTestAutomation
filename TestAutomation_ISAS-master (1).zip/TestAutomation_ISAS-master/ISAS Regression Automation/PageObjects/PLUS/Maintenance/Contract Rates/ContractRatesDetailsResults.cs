﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class ContractRatesDetailsResults
    {
        public string Code { get; set; }
        public string SkillMix { get; set; }
        public string AverageRate { get; set; }
        public string OverrideRate { get; set; }
        public string RateToUse { get; set; }
    }

    public class ContractRatesDetail
    {
        public static List<ContractRatesDetailsResults> getContractRatesDetailsResults()
        {
            List<ContractRatesDetailsResults> lstContractRatesDetails = new List<ContractRatesDetailsResults>();
            By bylistResults = By.XPath("//*/tbody[@id='contractRatesResultsListing']//tr");
            var lstResults = CommonFunctions.getElements(bylistResults);
            foreach (var item in lstResults)
            {
                lstContractRatesDetails.Add( new ContractRatesDetailsResults()
                {
                    Code = item.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    SkillMix = item.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    AverageRate = item.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    OverrideRate = item.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    RateToUse = item.FindElement(By.XPath("td[5]/select/option[@selected]")).Text

                });
            }
            return lstContractRatesDetails;
        }
    }
}
