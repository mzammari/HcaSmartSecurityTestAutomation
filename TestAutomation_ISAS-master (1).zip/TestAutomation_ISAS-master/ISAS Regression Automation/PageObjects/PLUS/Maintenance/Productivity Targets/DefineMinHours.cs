﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DefineMinHours
    {
        public static MonthlyForcastView getPlusProdMinFTEsData()
        {
            bool bDisplayed;
            string activeXpath = "//*/div[@id='minHoursContainer']//h3[@class='ui-accordion-header ui-helper-reset ui-state-active ui-corner-top']";
            bDisplayed = CommonFunctions.IsElementDisplayed(activeXpath, 2);
            if (!bDisplayed)
            {
                IWebElement cmdExpand = CommonFunctions.getElement(By.XPath("//*/div[@id='minHoursContainer']//h3/a"));
                CommonFunctions.ClickByJE(cmdExpand);
            }

            var JanField = By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[1]//td[10]//input");
            if (CommonFunctions.IsElementDisplayed(JanField, 2))
            {
                IWebElement Jan = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[1]//td[10]//input"));
                IWebElement Feb = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[2]//td[10]//input"));
                IWebElement Mar = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[3]//td[10]//input"));
                IWebElement Apr = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[4]//td[10]//input"));
                IWebElement May = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[5]//td[10]//input"));
                IWebElement Jun = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[6]//td[10]//input"));
                IWebElement Jul = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[7]//td[10]//input"));
                IWebElement Aug = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[8]//td[10]//input"));
                IWebElement Sep = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[9]//td[10]//input"));
                IWebElement Oct = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[10]//td[10]//input"));
                IWebElement Nov = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[11]//td[10]//input"));
                IWebElement Dec = CommonFunctions.getElement(By.XPath("(//*/div[@id='minHoursByDayOfWeekPerMonth' and @style='display: block;']//table)[2]/tbody//tr[12]//td[10]//input"));


                var data = new MonthlyForcastView()
                {
                    Jan = Math.Round(Convert.ToDouble(Jan.GetAttribute("value")), 2),
                    Feb = Math.Round(Convert.ToDouble(Feb.GetAttribute("value")), 2),
                    Mar = Math.Round(Convert.ToDouble(Mar.GetAttribute("value")), 2),
                    Apr = Math.Round(Convert.ToDouble(Apr.GetAttribute("value")), 2),
                    May = Math.Round(Convert.ToDouble(May.GetAttribute("value")), 2),
                    Jun = Math.Round(Convert.ToDouble(Jun.GetAttribute("value")), 2),
                    Jul = Math.Round(Convert.ToDouble(Jul.GetAttribute("value")), 2),
                    Aug = Math.Round(Convert.ToDouble(Aug.GetAttribute("value")), 2),
                    Sep = Math.Round(Convert.ToDouble(Sep.GetAttribute("value")), 2),
                    Oct = Math.Round(Convert.ToDouble(Oct.GetAttribute("value")), 2),
                    Nov = Math.Round(Convert.ToDouble(Nov.GetAttribute("value")), 2),
                    Dec = Math.Round(Convert.ToDouble(Dec.GetAttribute("value")), 2)
                };
                return data;
            }
            else
            {
                return null;
            }
        }

    }
}
