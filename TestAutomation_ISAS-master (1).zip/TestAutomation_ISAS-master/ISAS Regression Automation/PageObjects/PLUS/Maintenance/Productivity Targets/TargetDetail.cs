﻿using AutomationCoreLite.Reporting;
using DocumentFormat.OpenXml.Bibliography;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.InteropServices.Marshalling;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class TargetDetail
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectProductivityTargets();
            CommonFunctions.AddTestStep("Select Productivity Targets", "Productivity Targets page is loaded");
        }

        public static bool IsAt
        {
            get
            {
                Thread.Sleep(3000);
                string xpath = "//a[contains(text(),'Target Details')]";
                CommonFunctions.AddTestStep("Verify that the target detail page is displayed", "The target detail page is displayed");
                return CommonFunctions.IsElementDisplayed(xpath, 15);
            }
        }

        public class TargetDetailMenu
        {
            public static void Save()
            {
                bool bDisplayed;
                By ValidationErr = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-validation-errors']//div[@class='ui-dialog-buttonset']//button/span[text()='OK']");
                By Confirm = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-save-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']");
                By Save = By.XPath("//*/a[@title='Save changes']");
                IWebElement cmdSave = CommonFunctions.getElement(Save);
                CommonFunctions.ClickByJE(cmdSave);
                bDisplayed = CommonFunctions.IsElementDisplayed(ValidationErr, 2);
                if (bDisplayed)
                {
                    IWebElement cmdOK = CommonFunctions.getElement(ValidationErr);
                    CommonFunctions.ClickByJE(cmdOK);
                }
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.ClickByJE(cmdSave);
                bDisplayed = CommonFunctions.IsElementDisplayed(Confirm, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(Confirm);
                    CommonFunctions.ClickByJE(cmdYes);
                }
                CommonFunctions.AddTestStep("Click the save button", "The save button is enabled");

                By byNoChangeWarning = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-no-changes-to-save-alert']//div[@class='ui-dialog-buttonset']//button/span[text()='OK']");
                bDisplayed = CommonFunctions.IsElementDisplayed(byNoChangeWarning, 5);
                if (bDisplayed)
                {
                    IWebElement cmdOK = CommonFunctions.getElement(byNoChangeWarning);
                    CommonFunctions.ClickByJE(cmdOK);
                }


            }

            public static selectDeptAndYearCommand SetTargetByAndYear()
            {
                return new selectDeptAndYearCommand();
            }
        }

        #region: selectDeptAndYearCommand 
        public class selectDeptAndYearCommand
        {
            private string selectby;
            private string year;

            public selectDeptAndYearCommand withSelectby(string Selectby)
            {
                this.selectby = Selectby;
                return this;
            }

            public selectDeptAndYearCommand withYear(string Year)
            {
                this.year = Year;
                return this;
            }

            private void setSelectby()
            {
                By byOption = By.XPath("//select[@id='viewModeChoiceList']");
                CommonFunctions.SelectItemFromDropdownMenu(CommonFunctions.getElement(byOption), selectby);
            }

            private void setYear()
            {
                By byYear = By.XPath("//select[@id='yearsList']");
                CommonFunctions.SelectItemFromDropdownMenu(CommonFunctions.getElement(byYear), year);
            }

            public void Select()
            {
                setSelectby();
                setYear();
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep($"Select {selectby} and {year}", $"Options are selected correctly.");
            }
        }
        #endregion

        public static void selectDept(string deptName)
        {            
            CommonFunctions.WaitUntilPageIsAcive();
            IWebElement mnuDept = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDept, deptName.Trim());
            Thread.Sleep(1000);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep($"Select dept {deptName}", $"{deptName} is selected");
        }

        private static void ExpandTargetDetailPanel()
        {
            bool bExists;
            string accordion = "//*/div[@id='targetDetailsFromWFTDiv']/h3/a";
            string TargetDetailPanelXpath = "//*/div[@id='targetDetailsFromWFTDiv']/h3[@id='targetDetailsFromWFT' and contains(@class, 'ui-state-active')]/a";
            bExists = CommonFunctions.IsElementDisplayed(TargetDetailPanelXpath, 2);
            if (!bExists)
            {
                IWebElement pnlTargetDetails = CommonFunctions.getElement(By.XPath(accordion));
                pnlTargetDetails.Click();
            }
            CommonFunctions.AddTestStep("Expand Target Detail Panel", "Target Detail Panel is expanded");
        }

        private static bool AreRowsDisplayed(string DeptName)
        {
            
            string fromXpath = "(//*/div//input[contains(@class,'step-from')])[1]";
            bool bExist,bExistsAfter;
            bExist = CommonFunctions.IsElementDisplayed(fromXpath, 2);
            if (!bExist)
            {
                selectDept(DeptName);
                ExpandTargetDetailPanel();
                IWebElement cmdShowStep = CommonFunctions.getElement(By.XPath("//*/div[@id='targetDetailsFromWFTDiv']//a[contains(@title,'Show all')]"));
                //CommonFunctions.ClickByJE(cmdShowStep);
                cmdShowStep.Click();
                bExistsAfter = CommonFunctions.IsElementDisplayed(fromXpath, 2);
                Console.WriteLine($"Is semi dept value = {bExistsAfter.ToString()}");
                return bExistsAfter ? true : false;
            }

            return true;
        }

        private static bool AreRowsDisplayed()
        {

            string fromXpath = "(//*/div//input[contains(@class,'step-from')])[1]";
            bool bExist, bExistsAfter;
            bExist = CommonFunctions.IsElementDisplayed(fromXpath, 2);
            if (!bExist)
            {
                ExpandTargetDetailPanel();
                IWebElement cmdShowStep = CommonFunctions.getElement(By.XPath("//*/div[@id='targetDetailsFromWFTDiv']//a[contains(@title,'Show all')]"));
                //CommonFunctions.ClickByJE(cmdShowStep);
                cmdShowStep.Click();
                bExistsAfter = CommonFunctions.IsElementDisplayed(fromXpath, 2);
                Console.WriteLine($"Is semi dept value = {bExistsAfter.ToString()}");
                ExpandTargetDetailPanel();
                return bExistsAfter ? true : false;
            }

            return true;
        }

        public class VariableDeptartment
        {
            public static MonthlyForcastView getHrsPerUOS(string DeptName)
            {
                //selectDept(DeptName);
               // CommonFunctions.WaitUntilPageIsAcive();
                ExpandTargetDetailPanel();
                string xpath = "(//*/div//input[contains(@class,'tgt-hrs-per-uos')])";
                CommonFunctions.AddTestStep("Get Hrs Per UOS Data", "Hrs Per UOS Data");
                return CommonFunctions.getTargetDetailsCategoryData(xpath);
            }

            
            public static string SetHrsPerUosMonth(string DeptName)
            {
                //selectDept(DeptName);
                SetFacilityFreezeTarget();
                ExpandTargetDetailPanel();
                CommonFunctions.WaitUntilPageIsAcive();
                string xpath = "(//*/div//input[contains(@class,'tgt-hrs-per-uos')])";
                CommonFunctions.AddTestStep($"Set Novemeber month data Hrs Per UOS Data", $"The Novemeber month data is for Hrs Per UOS");
                var lstUosMonths = CommonFunctions.getTargetDetailsElements(xpath);
                var rndNumber = CommonFunctions.GetDoubleRandomNumber();
                CommonFunctions.SetText(lstUosMonths.Nov, rndNumber.ToString());
                TargetDetailMenu.Save();
                CommonFunctions.WaitUntilPageIsAcive();
                return rndNumber.ToString();
            }


            public static MonthlyForcastView getTargetNPPercent(string DeptName)
            {
               // selectDept(DeptName);
                ExpandTargetDetailPanel();
                CommonFunctions.WaitUntilPageIsAcive();
                ExpandTargetDetailPanel();
                string xpath = "(//*/div//input[contains(@class,'tgt-np-pct')])";
                CommonFunctions.AddTestStep("Get Target NP Percent Data", "Target NP Percent Data");
                return CommonFunctions.getTargetDetailsCategoryData(xpath);
            }

            public static void SetNpPercentData()
            {
                ExpandTargetDetailPanel();
                SetFacilityFreezeTarget();
                string xpath = "(//*/div//input[contains(@class,'tgt-np-pct')])";
                CommonFunctions.AddTestStep("Set new target NP Percent Data", "Target NP Percent Data");
                var lstNpPercent = CommonFunctions.getTargetDetailsElements(xpath);
                CommonFunctions.SetText(lstNpPercent.Jan, CommonFunctions.GenerateSmallRandonNumber());
                CommonFunctions.SetText(lstNpPercent.Feb, CommonFunctions.GenerateSmallRandonNumber());
                TargetDetailMenu.Save();
                CommonFunctions.WaitUntilPageIsAcive();
            }

            private static void SetFacilityFreezeTarget()
            {
                By byfreezefacilitytargets = By.XPath("//input[@id='chkfreezefacilitytargets']");
                var chkfreezefacilitytargets = CommonFunctions.getElement(byfreezefacilitytargets);
                CommonFunctions.SetCheckbox(chkfreezefacilitytargets, false);
                CommonFunctions.AddTestStep("Set the freeze facility targets checkbox off", "The freeze facility targets checkbox is unchecked. ");
            }

            public static MonthlyForcastView getTargetOTPercent(string DeptName)
            {
                selectDept(DeptName);
                ExpandTargetDetailPanel();
                string xpath = "(//*/div//input[contains(@class,'tgt-ot-pct')])";
                CommonFunctions.AddTestStep("Get Target OT Percent Data", "Target OT Percent Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getTargetContractPercent(string DeptName)
            {
                selectDept(DeptName);
                ExpandTargetDetailPanel();
                string xpath = "(//*/div//input[contains(@class,'tgt-cont-pct')])";
                CommonFunctions.AddTestStep("Get Target Contract Percent Data", "Target- Contract Percent Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getTargetAvgRate(string DeptName)
            {
                selectDept(DeptName);
                ExpandTargetDetailPanel();
                string xpath = "(//*/div//input[contains(@class,'tgt-avg-rate')])";
                CommonFunctions.AddTestStep("Get Target Avg Rate Data", "Target Avg Rate Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }
        }

        public class SemiVariableDepartment
        {
            public static MonthlyForcastView getFromData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-from')])";
                CommonFunctions.AddTestStep("Get From Data", "From Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getToData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-to')])";
                CommonFunctions.AddTestStep("Get To Data", "To Data");
                return CommonFunctions.getMonthlyData(xpath, 3);

            }

            public static MonthlyForcastView getSunData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-sun')])";
                CommonFunctions.AddTestStep("Get Sun Data", "Sun Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getMonData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-mon')])";
                CommonFunctions.AddTestStep("Get Mon Data", "Mon Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getTueData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-tue')])";
                CommonFunctions.AddTestStep("Get Tue Data", "Tue Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getWedData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-wed')])";
                CommonFunctions.AddTestStep("Get Wed Data", "Wed Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getThuData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-thu')])";
                CommonFunctions.AddTestStep("Get Thu Data", "Thu Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getFriData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-fri')])";
                CommonFunctions.AddTestStep("Get Fri Data", "Fri Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getSatData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-sat')])";
                CommonFunctions.AddTestStep("Get Sat Data", "Sat Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getTotalData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-total')])";
                CommonFunctions.AddTestStep("Get Total Data", "Total Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static MonthlyForcastView getProdFTEsData(string DeptName)
            {
                ExpandTargetDetailPanel();
                AreRowsDisplayed(DeptName);
                string xpath = "(//*/div//input[contains(@class,'step-prod-ftes')])";
                CommonFunctions.AddTestStep("Get Prod FTEs Data", "Prod FTEs Data");
                return CommonFunctions.getMonthlyData(xpath, 3);
            }

            public static List<objSemiVariableTargetDetatil> AddSteps(string Month) 
            {
                bool bDisplayed;
                List<objSemiVariableTargetDetatil> lstSemiVariableTargetDetatils = new List<objSemiVariableTargetDetatil>();
                int counter = 0;
                int WeeklyCounter = 22;
                int iMaxSteps = 6;
                By AddStepAlert = By.XPath("//div[@id=\"max-steps-per-target-alert\"]/following-sibling::div//button");
                By byfreezefacilitytargets = By.XPath("//input[@id='chkfreezefacilitytargets']");
                By byStepRow = By.XPath($"(//*/div[contains(@class,'clearfix tgt-row-step-parent')])[{Month}]//tbody/tr");
                By byAddStep = By.XPath($"(//*/div[contains(@class,'clearfix tgt-row-step-parent')])[{Month}]//a[contains(text(),'Add Step')]");
                //set chkfreezefacilitytargets off
                var chkfreezefacilitytargets = CommonFunctions.getElement(byfreezefacilitytargets);
                CommonFunctions.SetCheckbox(chkfreezefacilitytargets, false);
                AreRowsDisplayed();
                var lstSteps = CommonFunctions.getElements(byStepRow);
                if(lstSteps.Count < iMaxSteps)
                {
                    for(int i = lstSteps.Count; i < iMaxSteps; i++)
                    {
                        CommonFunctions.ClickByJE(CommonFunctions.getElement(byAddStep));
                        bDisplayed = CommonFunctions.IsElementDisplayed(AddStepAlert, 1);
                        if(bDisplayed)
                        {
                            CommonFunctions.getElement(AddStepAlert).Click();
                            break;
                        }
                    }
                    //TargetDetailMenu.Save();
                    //CommonFunctions.WaitUntilPageIsAcive();
                }
                AreRowsDisplayed();
                lstSteps = CommonFunctions.getElements(byStepRow);
                foreach(var row in lstSteps)
                {
                    //get list of cells
                    var lstCells = row.FindElements(By.XPath("td/input[not (@readonly)]"));
                    CommonFunctions.SetText(lstCells[0], counter.ToString());
                    counter = counter += 1;
                    CommonFunctions.SetText(lstCells[1], counter.ToString());
                    counter++;
                    for(int i = 2; i < 9; i++)
                    {
                        CommonFunctions.SetText(lstCells[i], WeeklyCounter.ToString());
                        WeeklyCounter += 4;
                    }
                }
                //set 999,999 in the 5th row (To cell)
                By fifthRowTo = By.XPath($"(//*/div[contains(@class,'clearfix tgt-row-step-parent')])[{Month}]//tbody/tr[5]/td[3]/input");
                CommonFunctions.SetText(CommonFunctions.getElement(fifthRowTo), "999999");
                TargetDetailMenu.Save();
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.WaitSaveToastMsgDisappeared();
                //get values and return them
                AreRowsDisplayed();
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.Focus(fifthRowTo);
                lstSteps = CommonFunctions.getElements(byStepRow);
                foreach (var row in lstSteps)
                {
                    lstSemiVariableTargetDetatils.Add( new objSemiVariableTargetDetatil()
                    {
                        From = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[2]/input")).GetAttribute("value")),
                        To = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[3]/input")).GetAttribute("value")),
                        Sun = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[4]/input")).GetAttribute("value")),
                        Mon = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[5]/input")).GetAttribute("value")),
                        Tue = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[6]/input")).GetAttribute("value")),
                        Wed = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[7]/input")).GetAttribute("value")),
                        Thu = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[8]/input")).GetAttribute("value")),
                        Fri = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[9]/input")).GetAttribute("value")),
                        Sat = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[10]/input")).GetAttribute("value")),
                        Total = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[11]/input")).GetAttribute("value")),
                        ProdFTEs = CommonFunctions.ToDouble(row.FindElement(By.XPath("td[12]/input")).GetAttribute("value"))
                    });
                }
                CommonFunctions.AddTestStep("Add steps to a semi-variable dept in PLUS", "Steps are added correctly.");
                return lstSemiVariableTargetDetatils;
            }
        }
    }
}
