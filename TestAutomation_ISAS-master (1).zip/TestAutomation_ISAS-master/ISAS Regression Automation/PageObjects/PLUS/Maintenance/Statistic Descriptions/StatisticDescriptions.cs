﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.ContarctHoursData;

namespace ISAS_Regression_Automation
{
    public class StatisticDescriptions
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectStatisticDescriptions();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/input[@id='newstat']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static void SetStatisticDescriptions(string newStat)
        {
            IWebElement txtNewStat = CommonFunctions.getElement(By.XPath("//*/input[@id='newstat']"));
            CommonFunctions.ReplaceAndSetText(txtNewStat, newStat);
            Thread.Sleep(1000);
            txtNewStat.SendKeys(Keys.Tab);
            StatisticDescriptionsMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
        }

        public static List<StatisticDescriptionsData> getStatisticDescriptionsData()
        {
            List<StatisticDescriptionsData> lstStatisticDescriptionsData = new List<StatisticDescriptionsData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='existingStatDescriptions']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstStatisticDescriptionsData.Add(new StatisticDescriptionsData()
                {
                    Description = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    IsAutomated = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    Source = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value")
                });
            }
            return lstStatisticDescriptionsData;
        }
    }
    #region: StatisticDescriptionsData
    public class StatisticDescriptionsData
    {
        public string Description { get; set; }
        public string IsAutomated { get; set; }
        public string Source { get; set; }
    }
    #endregion

}
