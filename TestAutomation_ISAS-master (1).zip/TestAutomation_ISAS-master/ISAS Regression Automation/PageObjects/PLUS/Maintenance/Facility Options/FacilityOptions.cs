﻿using ImageMagick;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.ContarctHoursData;

namespace ISAS_Regression_Automation
{
    public class FacilityOptions
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectFacilityOptions();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/input[@id='chkfreezefacilitytargets']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static List<OutpatientFactorData> GetOutpatientFactorDataData()
        {
            List<OutpatientFactorData> lstOutpatientFactorData = new List<OutpatientFactorData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='FacilityOptionDetais']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstOutpatientFactorData.Add(new OutpatientFactorData()
                {
                    Option = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    PriorMonthQMIRS = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    MonthToDate = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    Override = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    FactorToUse = row.FindElement(By.XPath("td[5]/select/option[@selected]")).Text
                });
            }
            return lstOutpatientFactorData;
        }

        public static void SetOutpatientFactorDataData(string factorToUse)
        {
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='FacilityOptionDetais']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                //row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                CommonFunctions.SelectItemFromDropdownMenu(row.FindElement(By.XPath("td[5]/select")), factorToUse);    
            }
            FacilityOptionsMenu.Save();
            CommonFunctions.WaitSaveToastMsgDisappeared();
        }

        public static StatisticAndTargetAdministrationCommand StatisticAndTargetAdministration()
        {
            return new StatisticAndTargetAdministrationCommand();
        }
    }

    #region:Outpatient Factor Data
    public class OutpatientFactorData
    {
        public string Option { get; set; }
        public string PriorMonthQMIRS { get; set; }
        public string MonthToDate { get; set; }
        public string Override { get; set; }
        public string FactorToUse { get; set; }

    }
    #endregion

    #region: StatisticAndTargetAdministrationCommand
    public class StatisticAndTargetAdministrationCommand
    {
        private bool totalOperatingRoomMinutes;
        private bool totalAnesthesiaMinutes;
        //private bool totalENDOMinutes;
        private bool totalFirstAssistMinutes;
        //private bool phase1;
        //private bool phase2;
        //private bool preOPHolding;

        public StatisticAndTargetAdministrationCommand withTotalOperatingRoomMinutes(bool TotalOperatingRoomMinutes)
        {
            this.totalOperatingRoomMinutes = TotalOperatingRoomMinutes;
            return this;
        }

        public StatisticAndTargetAdministrationCommand withTotalAnesthesiaMinutes(bool TotalAnesthesiaMinutes)
        {
            this.totalAnesthesiaMinutes = TotalAnesthesiaMinutes;
            return this;
        }

        //public StatisticAndTargetAdministrationCommand withTotalENDOMinutes(bool TotalENDOMinutes)
        //{
        //    this.totalENDOMinutes = TotalENDOMinutes;
        //    return this;
        //}

        public StatisticAndTargetAdministrationCommand withTotalFirstAssistMinutes(bool TotalFirstAssistMinutes)
        {
            this.totalFirstAssistMinutes = TotalFirstAssistMinutes;
            return this;
        }

        //public StatisticAndTargetAdministrationCommand withPhase1(bool Phase1)
        //{
        //    this.phase1 = Phase1;
        //    return this;
        //}

        //public StatisticAndTargetAdministrationCommand withPhase2(bool Phase2)
        //{
        //    this.phase2 = Phase2;
        //    return this;
        //}

        //public StatisticAndTargetAdministrationCommand withPreOPHolding(bool PreOPHolding)
        //{
        //    this.preOPHolding = PreOPHolding;
        //    return this;
        //}

        private void setTotalOperatingRoomMinutes()
        {
            IWebElement chkTotalOperatingRoomMinutes = CommonFunctions.getElement(By.XPath("//input[@id='chkEnableTotalOperatingRoomMinutes']"));
            CommonFunctions.SetCheckbox(chkTotalOperatingRoomMinutes, totalOperatingRoomMinutes);
        }

        private void setTotalAnesthesiaMinutes()
        {
            IWebElement chkTotalAnesthesiaMinutes = CommonFunctions.getElement(By.XPath("//input[@id='chkEnableTotalAnesthesiaMinutes']"));
            CommonFunctions.SetCheckbox(chkTotalAnesthesiaMinutes, totalAnesthesiaMinutes);
        }

        //private void setTotalENDOMinutes()
        //{
        //    IWebElement chkTotalENDOMinutes = CommonFunctions.getElement(By.XPath("//input[@id='chkEnableTotalENDOMinutes']"));
        //    CommonFunctions.SetCheckbox(chkTotalENDOMinutes, totalENDOMinutes);
        //}

        private void setTotalFirstAssistMinutes()
        {
            IWebElement chkTotalFirstAssistMinutes = CommonFunctions.getElement(By.XPath("//input[@id='chkEnableTotalFirstAssistMinutes']"));
            CommonFunctions.SetCheckbox(chkTotalFirstAssistMinutes, totalFirstAssistMinutes);
        }

        //private void setPhase1()
        //{
        //    IWebElement chkPhase1 = CommonFunctions.getElement(By.XPath("//input[@id='chkEnableTotalRecoveryRoomMinutesPhase1']"));
        //    CommonFunctions.SetCheckbox(chkPhase1, phase1);
        //}

        //private void setPhase2()
        //{
        //    IWebElement chkPhase2 = CommonFunctions.getElement(By.XPath("//input[@id='chkEnableTotalRecoveryRoomMinutesPhase2']"));
        //    CommonFunctions.SetCheckbox(chkPhase2, phase2);
        //}

        //private void setPreOPHolding()
        //{
        //    IWebElement chkPreOPHolding = CommonFunctions.getElement(By.XPath("//input[@id='chkEnablePacuProcedures']"));
        //    CommonFunctions.SetCheckbox(chkPreOPHolding, preOPHolding);
        //}

        public void Save()
        {
            setTotalOperatingRoomMinutes();
            setTotalAnesthesiaMinutes();
            //setTotalENDOMinutes();
            setTotalFirstAssistMinutes();
            //setPhase1();
            //setPhase2();
            //setPreOPHolding();
            FacilityOptionsMenu.Save();
            CommonFunctions.WaitSaveToastMsgDisappeared();
        }
    }
    #endregion
}
