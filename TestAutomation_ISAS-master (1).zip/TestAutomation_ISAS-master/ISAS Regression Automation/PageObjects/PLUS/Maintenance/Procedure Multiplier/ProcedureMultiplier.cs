﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class ProcedureMultiplier
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectProcedureMultiplier();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//a[@id='applyFilter']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static void EnterMultiplierForAll(string Multiplier)
        {
            bool bDisplayed;
            string txtXpath = "//*/div[@aria-labelledby='ui-dialog-title-enter-multiplier-for-all-alert']//input[@id='txtmultiplierforall']";
            string OkXpath = "//*/div[@aria-labelledby='ui-dialog-title-enter-multiplier-for-all-alert']//div[@class='ui-dialog-buttonset']//button/span[text()='OK']";
            IWebElement btnEnterMultiplier = CommonFunctions.getElement(By.Id("entermultiplierforallbtn"));
            btnEnterMultiplier.Click();
            bDisplayed = CommonFunctions.IsElementDisplayed(OkXpath, 2);
            if (bDisplayed)
            {
                IWebElement txtProcedureMultiplier = CommonFunctions.getElement(By.XPath(txtXpath));
                txtProcedureMultiplier.SendKeys(Multiplier);                
                IWebElement cmdOK = CommonFunctions.getElement(By.XPath(OkXpath));
                CommonFunctions.ClickByJE(cmdOK);
                CommonFunctions.WaitUntilPageIsAcive();
                ProcedureMultiplierMenu.Save();
                CommonFunctions.WaitUntilPageIsAcive();
            }
        }

        public static ProcedureMultiplierCommand ProcedureProductivityMultipliers()
        {
            return new ProcedureMultiplierCommand();
        }
    }

    #region: ProcedureMultiplierCommand
    public class ProcedureMultiplierCommand
    {
        private string department;
        private string status;

        public ProcedureMultiplierCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public ProcedureMultiplierCommand withStatus(string Status)
        {
            this.status = Status;
            return this;
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        private void setStatus()
        {
            IWebElement mnuStatus = CommonFunctions.getElement(By.XPath("//select[@id='procedureStatusListing']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuStatus, status);
        }

        private void clickApplyFilter()
        {
            IWebElement cmdApplyFilter = CommonFunctions.getElement(By.XPath("//*/a[@id='applyFilter']"));
            CommonFunctions.ClickByJE(cmdApplyFilter);
        }

        private void clickRestFilter()
        {
            IWebElement cmdRestFilter = CommonFunctions.getElement(By.XPath("//*/a[@id='resetfilter']"));
            CommonFunctions.ClickByJE(cmdRestFilter);
        }

        public void ApplyFilter()
        {
            setDepartment();
            setStatus();
            clickApplyFilter();
        }

        public void ResetFilter()
        {
            clickRestFilter();
        }
    }
    #endregion
}
