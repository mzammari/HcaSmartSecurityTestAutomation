﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.ContarctHoursData;

namespace ISAS_Regression_Automation
{
    public class ProcedureMultiplierData
    {
        public class clProcedureMultiplierData
        {
            public string Department { get; set; }
            public string Procedure { get; set; }
            public string CPT { get; set; }
            public string HCPCS { get; set; }
            public string RevenueCode	 { get; set; }
            public string Multiplier { get; set; }
            public string Locked { get; set; }
            public string Status { get; set; }
        }

        public static List<clProcedureMultiplierData> GetProcedureMultiplierData()
        {
            List<clProcedureMultiplierData> lstProcedureMultiplierData = new List<clProcedureMultiplierData>();
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='procedureProductivityMultipliersResultContainer']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                lstProcedureMultiplierData.Add(new clProcedureMultiplierData()
                {
                    Department = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    Procedure = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    CPT = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    HCPCS = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    RevenueCode = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                    Multiplier = row.FindElement(By.XPath("td[6]/input[@id='procedureProductivityMultipliers_Multiplier']")).GetAttribute("value"),
                    Locked = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
                    Status = row.FindElement(By.XPath("td[8]/input")).GetAttribute("value")
                });
            }
            return lstProcedureMultiplierData;
        }

        public static void SetMultiplier(string multiplier)
        {
            IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='procedureProductivityMultipliersResultContainer']//table/tbody//tr"));
            foreach (var row in lstRows)
            {
                try
                {
                    IWebElement txtMultiplier = row.FindElement(By.XPath("td[6]/input[@id='procedureProductivityMultipliers_Multiplier']"));
                    CommonFunctions.ReplaceAndSetText(txtMultiplier, multiplier);
                    Thread.Sleep(1000);
                }
                catch 
                {
                    continue;
                }
            }
            ProcedureMultiplierMenu.Save();
            CommonFunctions.WaitUntilPageIsAcive();
        }
    }
}
