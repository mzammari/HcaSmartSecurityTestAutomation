﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DepartmentGroupsMenu
    {
        public static void Save()
        {
            CommonFunctions.AddTestStep("save");
            bool bDisplayed, bEnabled;
            string NavigateXpath = "//*/div[@aria-labelledby='ui-dialog-title-navigate-to-stat-assignment']//div[@class='ui-dialog-buttonset']//button/span[text()='No']";
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-save-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string SaveXpath = "//*/a[@id='saveDepartmentGroupsBtn' and not(@disabled)]"; //and not(@disabled)
            bEnabled = CommonFunctions.IsElementDisplayed(SaveXpath, 5);
            if (bEnabled)
            {
                IWebElement cmdSave = CommonFunctions.getElement(By.XPath(SaveXpath));
                CommonFunctions.ClickByJE(cmdSave);
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdOK = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                    CommonFunctions.ClickByJE(cmdOK);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                    bDisplayed = CommonFunctions.IsElementDisplayed(NavigateXpath, 2);
                    if(bDisplayed) 
                    {
                        IWebElement cmdNo = CommonFunctions.getElement(By.XPath(NavigateXpath));
                        CommonFunctions.ClickByJE(cmdNo);
                    }
                }
            }
        }

        public static void Delete()
        {
            CommonFunctions.AddTestStep("Click the delete button", "The delete button is enabled");
            bool bDisplayed, bEnabled;
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-delete-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string DeleteXpath = "//*/a[@id='deleteGroupBtn' and not(@disabled)]"; 
            bEnabled = CommonFunctions.IsElementDisplayed(DeleteXpath, 5);
            if (bEnabled)
            {
                IWebElement cmdDelete = CommonFunctions.getElement(By.XPath(DeleteXpath));
                CommonFunctions.ClickByJE(cmdDelete);
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                }
            }

        }
    }
}
