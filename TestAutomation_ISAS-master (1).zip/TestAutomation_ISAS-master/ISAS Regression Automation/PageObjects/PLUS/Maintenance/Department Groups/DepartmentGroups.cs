﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DepartmentGroups
    {
        public static void GoTo()
        {
            PLUSMainMenu.PLUS.Maintenance.SelectDepartmentGroup();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to Department Groups", "The DepartmentGroups page is loaded");
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//*/select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 10);
            }
        }

        public static DepartmentGroupsNewGroupCommand NewGroup()
        {
            return new DepartmentGroupsNewGroupCommand();
        }

        public static DeptarmentGroupModifyExistingGroupCommand ExistingGroup()
        {
            return new DeptarmentGroupModifyExistingGroupCommand();
        }
    }

    #region: DepartmentGroupsNewGroupCommand
    public class DepartmentGroupsNewGroupCommand
    {
        private string groupName;
        private bool kronosSharedOut;
        private string departmentNumber;

        public DepartmentGroupsNewGroupCommand withGroupName(string GroupName)
        {
            this.groupName = GroupName;
            return this;
        }

        public DepartmentGroupsNewGroupCommand withKronosSharedOut(bool KronosSharedOut)
        {
            this.kronosSharedOut = KronosSharedOut;
            return this;
        }

        public DepartmentGroupsNewGroupCommand withDepartmentNumber(string DepartmentNumber)
        {
            this.departmentNumber = DepartmentNumber;
            return this;
        }

        private void setGroupName()
        {
            IWebElement txtGroupName = CommonFunctions.getElement(By.XPath("//input[@id='newGroupName']"));
            CommonFunctions.SetText(txtGroupName, groupName);
            //CommonFunctions.AddTestStep($"Enter {groupName} in the group name", $"{groupName} is set correctly");
            CommonFunctions.AddTestStep(groupName, groupName, null);
        }

        private void setKronosSharedOut()
        {
            IWebElement chkKronosSharedOut = CommonFunctions.getElement(By.XPath("//*/div[@id='newGroupCreation']//input[@id='kronosSharedOutFlagForNewGroup']"));
            CommonFunctions.SetCheckbox(chkKronosSharedOut, kronosSharedOut); 
            CommonFunctions.AddTestStep(kronosSharedOut, kronosSharedOut.ToString(), null);
        }

        private void setDepartmentNumber()
        {
            for(int i= 1; i<4; i++)
            {
                IWebElement mnuDepartmentNumber = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
                CommonFunctions.SelectItemFromDropdownMenuByIndex(mnuDepartmentNumber, i);                
                clickAdd();
            }
        }

        private void clickAdd()
        {
            IWebElement cmdAdd = CommonFunctions.getElement(By.XPath("//*/a[@id='addDeptBtn']"));
            CommonFunctions.ClickByJE(cmdAdd);
            CommonFunctions.AddTestStep("Add");
            //CommonFunctions.AddTestStep("Add a couple of departments and click the add button", "The depts are added");
        }

        private void clickCreateNewGroup()
        {
            IWebElement cmdNewGroup = CommonFunctions.getElement(By.XPath("//*/input[@id='createNewGroupOption']"));
            CommonFunctions.ClickByJE(cmdNewGroup);
            CommonFunctions.AddTestStep("NewGroup");
            //CommonFunctions.AddTestStep("Verify a user can add new group", " The new group is added");
            Thread.Sleep(1000);
        }

        public void Save()
        {
            clickCreateNewGroup();
            setGroupName();
            setKronosSharedOut();
            setDepartmentNumber();
            DepartmentGroupsMenu.Save();
        }
    }
    #endregion

    #region: DeptarmentGroupModifyExistingGroupCommand
    public class DeptarmentGroupModifyExistingGroupCommand
    {
        private string groupName;
        private bool kronosSharedOut;
        private string departmentNumber;

        public DeptarmentGroupModifyExistingGroupCommand withGroupName(string GroupName)
        {
            this.groupName = GroupName;
            return this;
        }

        public DeptarmentGroupModifyExistingGroupCommand withKronosSharedOut(bool KronosSharedOut)
        {
            this.kronosSharedOut = KronosSharedOut;
            return this;
        }

        public DeptarmentGroupModifyExistingGroupCommand withDepartmentNumber(string DepartmentNumber)
        {
            this.departmentNumber = DepartmentNumber;
            return this;
        }

        private void clickModifyExistingGroup()
        {
            IWebElement cmdModifyExistingGroup = CommonFunctions.getElement(By.XPath("//*/input[@id='modifyExistingGroupOption']"));
            CommonFunctions.ClickByJE(cmdModifyExistingGroup);
            CommonFunctions.AddTestStep("ModifyExistingGroup");
        }

        private void setGroupName()
        {
            IWebElement mnuGroupName = CommonFunctions.getElement(By.XPath("//select[@id='deptGroupsList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuGroupName, groupName);
            CommonFunctions.AddTestStep(groupName, groupName, null);
        }

        private void setKronosSharedOut()
        {
            IWebElement chkKronosSharedOut = CommonFunctions.getElement(By.XPath("//*/div[@id='existingGroupsListing']//input[@id='kronosSharedOutFlag']"));
            CommonFunctions.SetCheckbox(chkKronosSharedOut, kronosSharedOut);
            CommonFunctions.AddTestStep(kronosSharedOut, kronosSharedOut.ToString(), null);
        }

        private void setDepartmentNumber()
        {
            clickRemove();
            for (int i = 1; i < 4; i++)
            {
                IWebElement mnuDepartmentNumber = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
                CommonFunctions.SelectItemFromDropdownMenuByIndex(mnuDepartmentNumber, i);
                clickAdd();
            }
        }

        private void clickRemove()
        {
            string lstRemoveBtnXpath = "//*/div[@id='departmentResultsView']//a[@class='button remove-btn']";
            bool bExist;
            bExist = CommonFunctions.IsElementDisplayed(lstRemoveBtnXpath, 2);
            if (bExist)
            {
                IList<IWebElement> lstRemovebtn = CommonFunctions.getElements(By.XPath(lstRemoveBtnXpath));
                foreach (IWebElement btn in lstRemovebtn)
                {
                    CommonFunctions.ClickByJE(btn);
                }
            }
        }
        private void clickAdd()
        {
            IWebElement cmdAdd = CommonFunctions.getElement(By.XPath("//*/a[@id='addDeptBtn']"));
            CommonFunctions.ClickByJE(cmdAdd);
            CommonFunctions.AddTestStep("Add");
        }

        public void Save()
        {
            clickModifyExistingGroup();
            //setGroupName();
            setKronosSharedOut();
            setDepartmentNumber();
            DepartmentGroupsMenu.Save();
        }
    }
    #endregion
}
