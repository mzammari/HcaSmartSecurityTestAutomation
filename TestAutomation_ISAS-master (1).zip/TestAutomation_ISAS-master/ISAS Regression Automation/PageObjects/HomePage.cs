﻿using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using SeleniumExtras.WaitHelpers;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading;
using AutomationCoreLite.Reporting;

namespace ISAS_Regression_Automation
{
    public class HomePage : Driver
    {
        private IWebDriver driver;

        public HomePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        By VolumeForcasting = By.XPath("//a[normalize-space()='Volume Forecasting']");
        By StaffingGrid = By.XPath("//a[normalize-space()='Staffing Grid']");
        By SG_FilterFacilitySelectionListDropdown = By.XPath("//*[@id=\"filterfacilitySelectionList\"]");
        By WorkloadForecaster = By.XPath("//a[normalize-space()='Workload Forecaster']");
        By WorkloadForecasterHome = By.XPath("//*/td[normalize-space()='Welcome to Workload Forecast Tool (WFT).']");
        By PLUS = By.XPath("//*/td[@align='center' and contains(text(),'PLUS')]");
        By FPC = By.XPath("//a[normalize-space()='FPC']");
        By WFT = By.XPath("//*/div[@id='mainmenu']");

        //Home - ISAS Portal
        //Home - Workload Forecast
        //Home - Volume Forecasting
        //Home - Staffing Grid
        //FPC Plan - PLUS
        //Home - PLUS

        public string SwitchToWindow(string tabName)
        {
            string TabTitle;
            List<string> tabs = new List<string>(driver.WindowHandles);
            foreach (var tab in tabs)
            {
                try
                {
                    TabTitle = driver.SwitchTo().Window(tab).Title;
                    if (TabTitle.Contains(tabName))
                    {
                        string wndHadle = driver.SwitchTo().Window(tab).CurrentWindowHandle;
                        CommonFunctions.AddTestStep($"Switch to {tabName}", $"{tabName} page is loaded");
                        return wndHadle;
                    }
                }
                catch (WebDriverException ex)
                {
                    Console.WriteLine($"Unable to switch to browser tab while looking for {tabName}: {ex.Message}");
                }
            }
            return null;
        }

        public void CloseAllTab()
        {
            CommonFunctions.AddTestStep("Close all tabs", "All tabs are closed");
            CommonFunctions.WaitUntilPageIsAcive();
            var windowHandleSet = driver.WindowHandles;
            List<string> tabs = new List<string>(windowHandleSet);
            foreach (var tab in tabs)
            {
                driver.Close();
                if(isAlertPresent())
                {
                    driver.SwitchTo().Alert().Accept();
                    Thread.Sleep(5000);
                }
            }
        }

        public bool isAlertPresent()
        { 
            try
            {
                var alert = driver.SwitchTo().Alert();
                String str = alert.Text; 
                return true;
            } 
            catch (NoAlertPresentException Ex)
            { 
                return false;
            }
        }

        public void LaunchISASApplication(String Environment)
        {
            //var builder = new ConfigurationBuilder()
            //.SetBasePath(Directory.GetCurrentDirectory())
            //.AddUserSecrets<Driver>()
            //.Build();

            //string username = builder["username"];
            //string ISASUAT = builder["ISASUAT"];
            //string ISASQA = builder["ISASQA"];
            //string password = builder["password"];


            //if (Environment == "QA")
            //{

            //    driver.Url = "https://" + username + ":" + password + "@" + ISASQA;                
            //}
            //else if (Environment == "UAT")
            //{
            //    driver.Url = ISASUAT;
            //}
            //            Test.Log(Status.Info, "Chrome Browser lauched");
            //CommonFunctions.AddTestStep($"Navigate to the following URL: {ISASQA}.", "User should be able to open www.google.com.");
        }

        public SG_NavigationPage SwitchToStaffingGridTab()
        {
            driver.SwitchTo().Window(driver.WindowHandles[1]);
            //Test.Log(Status.Info, "Browser Control Switched to Staffing Grid Application");      
            return new SG_NavigationPage(driver);
        }

        public void NavigateToWorkloadForecaster()
        {
            bool bDisplayed;
            string WndTitle;
            CommonFunctions.WaitUntilPageIsAcive();
            bDisplayed = CommonFunctions.IsElementDisplayed(WFT, 2);
            if (!bDisplayed)
            {
                //var windowHandlerSet = driver.WindowHandles;
                CommonFunctions.getElement(WorkloadForecaster).Click();
                Thread.Sleep(20000);
                // WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(120));
                IList<string> lstWindowHandles = new List<string>(Driver.Instance.WindowHandles);
                foreach (var item in lstWindowHandles)
                {

                    WndTitle = Driver.Instance.SwitchTo().Window(item).Title;
                    if (WndTitle.Contains("System Error"))
                    {
                        ReopenWFT();

                    }
                    if (WndTitle.Contains("Workload"))
                    {
                        CommonFunctions.IsElementDisplayed("//*/td[normalize-space()='Welcome to Workload Forecast Tool (WFT).']", 120);
                    }
                }
            }
            CommonFunctions.AddTestStep("Navigate To WorkloadForecaster", "WFT page is open");
        }

        public void NavigateToStaffingGrid()
        {
            bool bDisplayed;
            string WndTitle;
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate To SG", "SG page is open");
            bDisplayed = CommonFunctions.IsElementDisplayed(StaffingGrid, 2);
            if (bDisplayed)
            {
                //var windowHandlerSet = driver.WindowHandles;
                CommonFunctions.getElement(StaffingGrid).Click();
                Thread.Sleep(20000);
                // WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(120));
                IList<string> lstWindowHandles = new List<string>(Driver.Instance.WindowHandles);
                foreach (var item in lstWindowHandles)
                {

                    WndTitle = Driver.Instance.SwitchTo().Window(item).Title;
                    if (WndTitle.Contains("System Error"))
                    {
                        //ReopenWFT();

                    }
                    if (WndTitle.Contains("Staffing"))
                    {
                        CommonFunctions.IsElementDisplayed("//td[normalize-space()='Welcome to Staffing Grids.']", 120);
                    }
                }
                CommonFunctions.AddTestStep("Navigate To SG", "SG page is open");
            }
        }

        public void NavigateToVolumeForecasting()
        {
            bool bDisplayed;
            string WndTitle;
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate To Volume Forecasting", "Volume Forecasting page is open");
            bDisplayed = CommonFunctions.IsElementDisplayed(VolumeForcasting, 2);
            if (bDisplayed)
            {
                //var windowHandlerSet = driver.WindowHandles;
                CommonFunctions.getElement(VolumeForcasting).Click();
                Thread.Sleep(20000);
                // WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(120));
                IList<string> lstWindowHandles = new List<string>(Driver.Instance.WindowHandles);
                foreach (var item in lstWindowHandles)
                {

                    WndTitle = Driver.Instance.SwitchTo().Window(item).Title;
                    if (WndTitle.Contains("System Error"))
                    {
                        //ReopenWFT();

                    }
                    if (WndTitle.Contains("Volume Forecasting"))
                    {
                        CommonFunctions.IsElementDisplayed("//td[normalize-space()='Welcome to Volume Forecasting.']", 120);
                    }
                }
            }
        }

        private void ReopenWFT()
        {
            string wndHandle = SwitchToWindow("System Error");
            Driver.Instance.SwitchTo().Window(wndHandle).Close();
            SwitchToWindow("ISAS Portal");
            NavigateToWorkloadForecaster();
        }

        public void NavigateToPLUS()
        {
            bool bExists;
            string WndTitle;
            //var windowHandlerSet = driver.WindowHandles;
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.getElement(By.XPath("//*/a[normalize-space()='PLUS']")).Click();
            Thread.Sleep(20000);
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(120));
            IList<string> lstWindowHandles = new List<string>(Driver.Instance.WindowHandles);           
            foreach (var item in lstWindowHandles)
            {
                WndTitle = Driver.Instance.SwitchTo().Window(item).Title;
                bExists = CommonFunctions.IsElementDisplayed("//*/div[@class='sys-error-detail']", 3);

                if (WndTitle.Contains("System Error"))
                {
                    ReopenPLUS();

                }
                if(bExists)
                {
                    ReopenPLUSwithInvalidToken();
                }
                if (WndTitle.Contains("PLUS"))
                {
                    CommonFunctions.IsElementDisplayed("//*/td[@align='center' and contains(text(),'PLUS')]", 120);
                }
            }
            CommonFunctions.AddTestStep("Navigate to PLUS", "PLUS page is displayed");

        }

        private void ReopenPLUS()
        {
            string wndHandle = SwitchToWindow("System Error");
            Driver.Instance.SwitchTo().Window(wndHandle).Close();
            SwitchToWindow("ISAS Portal");
            NavigateToPLUS();
        }        

        private void ReopenPLUSwithInvalidToken()
        {
            string wndHandle = SwitchToWindow("PLUS");
            Driver.Instance.SwitchTo().Window(wndHandle).Close();
            SwitchToWindow("ISAS Portal");
            NavigateToPLUS();
        }

        public void NavigateToFPC()
        {
            string WndTitle;
            bool bExists;            
            CommonFunctions.WaitUntilPageIsAcive();
            //var windowHandlerSet = driver.WindowHandles;
            CommonFunctions.getElement(By.XPath("//a[normalize-space()='FPC']")).Click();
            Thread.Sleep(20000);
            // WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(120));
            IList<string> lstWindowHandles = new List<string>(Driver.Instance.WindowHandles);
            foreach (var item in lstWindowHandles)
            {
                WndTitle = Driver.Instance.SwitchTo().Window(item).Title;
                bExists = CommonFunctions.IsElementDisplayed("//*/div[@class='sys-error-detail']", 3);
                if (bExists) 
                {
                    ReopenFPC();
                }
                if (WndTitle.Contains("System Error"))
                {
                    ReopenFPC();

                }
                if (WndTitle.Contains("FPC Plan - PLUS"))
                {
                    CommonFunctions.IsElementDisplayed("//div[@class='page-content']//li//a[@id='commentBtn']", 120);
                    CommonFunctions.AddTestStep("Navigate To FPC", "FPC page is open");
                    break;
                }
            }
        }

        private void ReopenFPC()
        {
            string wndHandle = SwitchToWindow("PLUS");
            if (wndHandle != null)
                Driver.Instance.SwitchTo().Window(wndHandle).Close();

            string portalWindowHandle = SwitchToWindow("ISAS Portal");
            if (portalWindowHandle == null && Driver.Instance.WindowHandles.Count > 0)
                Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles[0]);

            NavigateToFPC();
        }
    }
}
