﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class SgMainMenu
    {        
        private static By Save = By.XPath("//a[@id='lnkSave']");
        private static By SaveConfirmation = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-save-confirm' and contains(@style,'block')]//button/span[text()='Yes']");
        private static By NextStep = By.XPath("//a[@id='lnkNavigateToDetails']");
        private static By NextStepConfirmation = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-1' and contains(@style,'block')]//button/span[text()='Yes']");
        private static By NextStepSave = By.XPath("//a[@id='lnkSaveRecalc']");
        private static By linkSubmitForApproval = By.XPath("//a[@id='linkSubmitForApproval']");
        private static By byUnsavedChanges = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-submit-for-approval-unsaved-changes' and contains(@style,'block')]//button/span[text()='OK']");
        private static By bySubmitForApprovalConfirmation = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-submit-for-approval-confirm' and contains(@style,'block')]//button/span[text()='Yes']");

        public static void SelectAdministration()
        {
            By TopMenuLevel = By.XPath("//*/a[contains(text(),'Staffing Grid')]");
            By link = By.XPath("//*/a[@href='/Administration']");
            MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
        }

        public static void SelectGrid()
        {
            By TopMenuLevel = By.XPath("//*/a[contains(text(),'Staffing Grid')]");
            By link = By.XPath("//*/a[@href='/StaffingGrid']");
            MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
        }

        public static void SelectSummaryAndApproval()
        {
            By TopMenuLevel = By.XPath("//*/a[contains(text(),'Staffing Grid')]");
            By link = By.XPath("//*/a[@href='/Approval']");
            MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
        }

        public static void clickSave()
        {
            bool bExist;
            bExist = CommonFunctions.IsElementDisplayed(Save, 3);
            if (bExist)
            {
                var cmdSave = CommonFunctions.getElement(Save);
                CommonFunctions.ClickByJE(cmdSave);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Save");
                    
            }
            else
            {
                var cmdNextStepSave = CommonFunctions.getElement(NextStepSave);
                CommonFunctions.ClickByJE(cmdNextStepSave);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("next step");

            }
            //Confirmation
            var cmdYes = CommonFunctions.getElement(SaveConfirmation);
            CommonFunctions.ClickByJE(cmdYes);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Yes");
        }

        public static void clickNextStep()
        {
            bool bDisplayed;
            var cmdNextStep = CommonFunctions.getElement(NextStep);
            CommonFunctions.ClickByJE(cmdNextStep);
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("next step");

            bDisplayed = CommonFunctions.IsElementDisplayed(NextStepConfirmation,5);
            if (bDisplayed)
            {
                var cmdNextStepComfirmation = CommonFunctions.getElement(NextStepConfirmation);
                CommonFunctions.ClickByJE(cmdNextStepComfirmation);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("next step confirmation");
            }
        }

        public static void clickSubmitForApproval()
        {
            bool bDisplayed;
            var cmdSubmitForApproval = CommonFunctions.getElement(linkSubmitForApproval);
            CommonFunctions.ClickByJE(cmdSubmitForApproval);
            CommonFunctions.AddTestStep("Submit-For-Approval");
            CommonFunctions.WaitUntilPageIsAcive();
            bDisplayed = CommonFunctions.IsElementDisplayed(bySubmitForApprovalConfirmation, 10);
            if (bDisplayed)
            {
                var cmdYes = CommonFunctions.getElement(bySubmitForApprovalConfirmation);
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Yes");
            }
        }

        public static void LoadFrequencyCount()
        {
            By byFrequencyCount = By.XPath("//a[@id='loadFrqCount']");
            By byConfirmation = By.XPath("//*/div[contains(@style,'display: block;')]//button/span[text()='Yes']");
            bool bDisplayed;
            var cmdLoadFrequencyCount = CommonFunctions.getElement(byFrequencyCount);
            CommonFunctions.ClickByJE(cmdLoadFrequencyCount);
            CommonFunctions.WaitUntilPageIsAcive();
            bDisplayed = CommonFunctions.IsElementDisplayed(byConfirmation, 10);
            if (bDisplayed)
            {
                var cmdYes = CommonFunctions.getElement(byConfirmation);
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Yes");
            }
            clickSave();
            CommonFunctions.AddTestStep("Load frequency count", "Frequency range is loaded correctly");



            
        }
    }
}
