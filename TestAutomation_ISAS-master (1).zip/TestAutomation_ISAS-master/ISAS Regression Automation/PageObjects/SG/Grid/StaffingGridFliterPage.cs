﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class StaffingGridFliterPage
    {

        public static StaffingGridFliterCommand SgFilter()
        {
            return new StaffingGridFliterCommand();
        }
    }

    #region: StaffingGridFliterCommand 
    public class StaffingGridFliterCommand
    {
        private string department;
        private string status;
        private string staffingGrid;

        public StaffingGridFliterCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public StaffingGridFliterCommand withStatus(string Status)
        {
            this.status = Status;
            return this;
        }

        public StaffingGridFliterCommand withStaffingGrid(string StaffingGrid)
        {
            this.staffingGrid = StaffingGrid;
            return this;
        }

        private void setDepartment()
        {
            if (!string.IsNullOrEmpty(department))
            {
                IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='ddlDepartments']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
            }
        }

        private void setStatus()
        {
            IWebElement mnuStatus = CommonFunctions.getElement(By.XPath("//select[@id='ddlStatus']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuStatus, status);
        }

        private bool setStaffingGrid()
        {
            try
            {
                if (!string.IsNullOrEmpty(staffingGrid))
                {
                    IWebElement mnuStaffingGrid = CommonFunctions.getElement(By.XPath("//select[@id='ddlStaffingGrids']"));
                    CommonFunctions.SelectItemFromDropdownMenu(mnuStaffingGrid, staffingGrid);
                    return true;
                }
            } 
            catch 
            {
                return false;
            }
            return false;
            
        }

        private void clickCreate()
        {
            IWebElement cmdCreate = CommonFunctions.getElement(By.XPath("//input[@id='btnView']"));
            CommonFunctions.ClickByJE(cmdCreate);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private void clickDelete()
        {
            IWebElement cmdDelete = CommonFunctions.getElement(By.XPath("//input[@id='btnDelete']"));
            CommonFunctions.ClickByJE(cmdDelete);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private bool clickView()
        {
            try
            {
                By byView = By.XPath("//input[@id='btnView' and not (@disabled)]");
                IWebElement cmdView = CommonFunctions.getElement(byView);
                CommonFunctions.ClickByJE(cmdView);
                CommonFunctions.WaitUntilPageIsAcive();
                return true;
            }
            catch
            {
                return false;
            }
        }

        
        public void Create()
        {
            setDepartment();
            setStatus();
            setStaffingGrid();
            clickCreate();
        }

        public void Delete()
        {
            setDepartment();
            setStatus();
            setStaffingGrid();
            clickDelete();
        }

        public void View()
        {
            setDepartment();
            setStatus();
            setStaffingGrid();
            clickView();
        }

        public bool IsPlanExist()
        {
            setDepartment();
            setStatus();
            return setStaffingGrid();
        }
    }
    #endregion
}
