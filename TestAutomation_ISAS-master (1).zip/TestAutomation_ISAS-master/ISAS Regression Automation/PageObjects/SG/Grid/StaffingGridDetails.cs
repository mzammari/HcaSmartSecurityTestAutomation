﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class StaffingGridDetails
    {
        private static By FreqCountColumn = By.XPath("//*/table[contains(@id,'tblVolumeRanges')]//tr//td[4]/input");
        private static By byFrequencyCountTotal = By.XPath("(//*/div[contains(@class,'div-total-section') and not (contains(@style,'none'))]// div[contains(@class,'div-total-section-left')]//table)[2]//tbody//td//input");
        private static By byVarProdHrsVolTotal = By.XPath("(//*/div[contains(@class,'div-total-section') and not (contains(@style,'none'))]//div[contains(@class,'div-total-section-right')]//table)[2]//input[contains(@id,'variableProductiveHoursByVolTotal')]");
        private static By byTotalProdHrsVolTotal = By.XPath("(//*/div[contains(@class,'div-total-section') and not (contains(@style,'none'))]//div[contains(@class,'div-total-section-right')]//table)[2]//input[contains(@id,'totalProductiveHoursByVolTotal')]");
        private static By byFteVarianceToTargeTotal = By.XPath("(//*/div[contains(@class,'div-total-section') and not (contains(@style,'none'))]//div[contains(@class,'div-total-section-right')]//table)[2]//input[contains(@id,'varianceToPlusTarget')]");

       

        //get the freq count cell which is more than zero
        private static int getFreqCount()
        {
            int count = 1;
            double value;
            var lstFreqCoundCell = CommonFunctions.getElements(FreqCountColumn);
            foreach(var freqCell in lstFreqCoundCell)
            {
                value = CommonFunctions.ToDouble(freqCell.GetAttribute("value"));
                if(value != 0)
                {
                    return count;
                }
                count++;
            }
            return 0;
        }

        public static StaffingGridDetailsTotals getStaffingGridDetailTotals()
        {
            SgMainMenu.LoadFrequencyCount();
            CommonFunctions.WaitUntilPageIsAcive();
            int row = getFreqCount();
            By tblDayShift = By.XPath($"(//*/table[contains(@id,'tblStaffingValues')]//table)[1]//tr[{row}]/td/input[not (@type='hidden')]");
            string countValue;
            var tblDayShiftSkills = CommonFunctions.getElements(tblDayShift);
            foreach( var skill in  tblDayShiftSkills)
            {
                countValue = CommonFunctions.GenerateSmallRandonNumber();
                CommonFunctions.SetText(skill, countValue);
            }
            SgMainMenu.clickSave();
            By byNoSave = By.XPath("//*/div[@aria-labelledby=\"ui-dialog-title-no-change-message\"]//button//span[text()='Ok']");
            var bExist = CommonFunctions.IsElementDisplayed(byNoSave, 3);
            if (bExist)
            {
                var cmdNoSave = CommonFunctions.getElement(byNoSave);
                CommonFunctions.ClickByJE(cmdNoSave);
            }

            return new StaffingGridDetailsTotals()
            {
                FrequencyCountTotal = Convert.ToDouble(CommonFunctions.getElement(byFrequencyCountTotal).GetAttribute("value")),
                VarProdHrsVolTotal = Convert.ToDouble(CommonFunctions.getElement(byVarProdHrsVolTotal).GetAttribute("value")),
                TotalProdHrsVolTotal = Convert.ToDouble(CommonFunctions.getElement(byTotalProdHrsVolTotal).GetAttribute("value")),
                FteVarianceToTargeTotal = Convert.ToDouble(CommonFunctions.getElement(byFteVarianceToTargeTotal).GetAttribute("value"))

            };
        }
    }

    public class StaffingGridDetailsTotals
    {
        public double VarProdHrsVolTotal;
        public double TotalProdHrsVolTotal; 
        public double FteVarianceToTargeTotal;
        public double FrequencyCountTotal;
    }
}
