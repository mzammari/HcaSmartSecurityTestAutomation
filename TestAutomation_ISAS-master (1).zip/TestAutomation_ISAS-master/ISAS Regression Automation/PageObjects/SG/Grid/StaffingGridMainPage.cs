﻿using AventStack.ExtentReports.Gherkin.Model;
using OpenQA.Selenium;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.SgMainMenu;

namespace ISAS_Regression_Automation
{
    public class StaffingGridMainPage
    {
        private static By byOtherProductiveResourcesSubTotals = By.XPath("//*/table[@id='tblotherProductiveContainer']//tfoot//tr//td/label[contains(@data-bind,'Subtotal')]");
        private static By byOrientationEducationSubTotals = By.XPath("//*/table[@id='tblorientaionContainer']//tfoot//tr//td/label[contains(@data-bind,'Subtotal')]");
        private static By byOtherProductiveResourcesSelectXpath = By.XPath("//*/table[@id='tblotherProductiveContainer']/tbody//tr/td/select");
        private static By byOtherProductiveResourcesXpath = By.XPath("//*/table[@id='tblotherProductiveContainer']/tbody//tr/td/input[contains(@data-bind,'Hours, visible') and not (@style='display: none;')]");
        private static By byOrientationAndEducationXpath = By.XPath("//*/table[@id='tblorientaionContainer']/tbody//tr/td/input[contains(@data-bind, 'Hours') and not (@class='readonly')]");
        private static By byGridID = By.XPath("//input[@id='lblGridId']");
        private static By byGridDescription = By.XPath("//input[@id='txtGridDescription']");
        private static By byGridStatus = By.XPath("//input[@id='lblGridStatus']");
        private static By byGridOption = By.XPath("//select[@id='ddlGridOptions']");
        private static By byGridType = By.XPath("//input[@id='lblGridType']");
        private static By bySubGridType = By.XPath("//input[@id='lblGridSubType']");
        private static By byScheduleStartDate = By.XPath("//input[@id='Dpicker']");
        private static By byProbableEndDate = By.XPath("//input[@id='lblGridEndDate']");
        private static By byRequiredApprovers = By.XPath("//input[@data-bind='value: Summary.RequiredApprovers']");
        private static By byDept = By.XPath("//input[@id='txtDeptDisplay']");
        private static By byDeptType = By.XPath("//input[@id='lblDeptType']");
        private static By byDeptStatDescription = By.XPath("//input[@id='txtDeptStatDescription']");
        private static By byPLUSTargetMonth = By.XPath("//select[@id='ddlPlusTargetMonthsToCompare']");
        private static By byVarProdHoursUOS = By.XPath("//input[@id='txtplusVariableProdHours']");
        private static By byAddNew = By.XPath("//*/a[contains(@onclick,'addNew')]");

        public static void SetPLUSTargetMonth(string month)
        {
            CommonFunctions.SelectItemFromDropdownMenu(
                CommonFunctions.getElement(byPLUSTargetMonth),
                month);
            SgMainMenu.clickSave();
            CommonFunctions.WaitSaveToastMsgDisappeared();
            CommonFunctions.WaitUntilPageIsAcive();

        }

        public static clsStaffingGridDetails GetStaffingGridDetails()
        {
            return new clsStaffingGridDetails()
            {
                GridID = CommonFunctions.getElement(byGridID).GetAttribute("value"),
                GridDescription = CommonFunctions.getElement(byGridDescription).GetAttribute("value"),
                GridStatus = CommonFunctions.getElement(byGridStatus).GetAttribute("value"),
                GridOption = CommonFunctions.getElement(byGridOption).GetAttribute("value"),
                GridType = CommonFunctions.getElement(byGridType).GetAttribute("value"),
                SubGridType = CommonFunctions.getElement(bySubGridType).GetAttribute("value"),
                ScheduleStartDate = CommonFunctions.getElement(byScheduleStartDate).GetAttribute("value"),
                ProbableEndDate = CommonFunctions.getElement(byProbableEndDate).GetAttribute("value"),
                RequiredApprovers = CommonFunctions.getElement(byRequiredApprovers).GetAttribute("value"),
                Dept = CommonFunctions.getElement(byDept).GetAttribute("value"),
                DeptType = CommonFunctions.getElement(byDeptType).GetAttribute("value"),
                DeptStatDescription = CommonFunctions.getElement(byDeptStatDescription).GetAttribute("value"),
                PLUSTargetMonth = CommonFunctions.getElement(byPLUSTargetMonth).GetAttribute("value"),
                VarProdHoursUOS = CommonFunctions.getElement(byVarProdHoursUOS).GetAttribute("value")
            };
        }

        public static WeekElementsValues SetOrientationAndEducation()
        {
            string x;
            var tblOrientationEducation = CommonFunctions.getElements(byOrientationAndEducationXpath);
            foreach( var row in tblOrientationEducation)
            {
                x = CommonFunctions.GenerateSmallRandonNumber();
                CommonFunctions.SetText(row, x);
            }

            var tblOtherProductiveResources = CommonFunctions.getElements(byOtherProductiveResourcesXpath);
            foreach (var row in tblOtherProductiveResources)
            {
                x = CommonFunctions.GenerateSmallRandonNumber();
                CommonFunctions.SetText(row, x);
            }

            var tblOtherProductiveResourcesSelect = CommonFunctions.getElements(byOtherProductiveResourcesSelectXpath);
            foreach (var menu in tblOtherProductiveResourcesSelect)
            {
                CommonFunctions.SelectItemFromDropdownMenuByIndex(menu, 2);
            }

           
            SgMainMenu.clickSave();
            CommonFunctions.WaitSaveToastMsgDisappeared();
            CommonFunctions.WaitUntilPageIsAcive();
            AddNote();

            //get each sub-total of each table. 
            var firstSubTotal = getOrientationEducationSubTotals();
            var secondSubTotal = getOtherProductiveResourcesSubTotals();
            var SumOfSubTotals = CommonFunctions.AddTwoWeekObjectsByText(firstSubTotal, secondSubTotal);
            CommonFunctions.AddTestStep("Verify a user can get the sum of the subtotals", "The sum of the subtotals is calculated");
            return SumOfSubTotals;
        }

        private static void AddNote()
        {
            //Enter a note
            IWebElement txtNote = CommonFunctions.getElement(By.XPath("//*/textarea[@id='txtNotes']"));
            CommonFunctions.SetText(txtNote, $"This is a testing note {CommonFunctions.getRandomNumber}");
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//input[@id='btnNoteEdit']"));
            CommonFunctions.ClickByJE(cmdSave);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private static WeeklyElements getOrientationEducationSubTotals()
        {
            CommonFunctions.AddTestStep("Verify user can get Orientation Education Sub Totals", "The sub-totals are fetched");
            var OrientationEducationSubTotals = CommonFunctions.getElements(byOrientationEducationSubTotals);
            return new WeeklyElements()
            {
                Sun = OrientationEducationSubTotals[0],
                Mon = OrientationEducationSubTotals[1],
                Tue = OrientationEducationSubTotals[2],
                Wed = OrientationEducationSubTotals[3],
                Thu = OrientationEducationSubTotals[4],
                Fri = OrientationEducationSubTotals[5],
                Sat = OrientationEducationSubTotals[6]
            };
        }

        private static WeeklyElements getOtherProductiveResourcesSubTotals()
        {
            CommonFunctions.AddTestStep("Verify user can get Other Productive Resources Sub Totals", "The sub-totals are fetched");
            var OtherProductiveResourcesSubTotals = CommonFunctions.getElements(byOtherProductiveResourcesSubTotals);
            return new WeeklyElements()
            {
                Sun = OtherProductiveResourcesSubTotals[0],
                Mon = OtherProductiveResourcesSubTotals[1],
                Tue = OtherProductiveResourcesSubTotals[2],
                Wed = OtherProductiveResourcesSubTotals[3],
                Thu = OtherProductiveResourcesSubTotals[4],
                Fri = OtherProductiveResourcesSubTotals[5],
                Sat = OtherProductiveResourcesSubTotals[6]
            };
        }

        public static void SetStaffingGridDetails(string date, string SgDescription)
        {            
            if (!string.IsNullOrEmpty(SgDescription))
            {
                var txtGridDescription = CommonFunctions.getElement(byGridDescription);
                CommonFunctions.SetText(txtGridDescription, SgDescription);
            }
            var txtStartDate = CommonFunctions.getElement(byScheduleStartDate);
            CommonFunctions.SetText(txtStartDate, date);
            txtStartDate.SendKeys(Keys.Tab);          
            var txtGridID = CommonFunctions.getElement(byGridID);
            CommonFunctions.ClickByJE(txtGridID);           
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(2000);
        }

        public static void AddNewResources(string NewResourceName, string skillMix, string shift)
        {
            By byNewResourceName = By.XPath("//*/table[@id='tblotherProductiveContainer']//tbody//tr//input[contains(@class,'sg-errors') and not(contains(@style,' none'))]");
            By byNewResourceMon = By.XPath("//*/table[@id='tblotherProductiveContainer']//tbody//tr//input[contains(@class,'sg-errors') and not(contains(@style,' none'))]/../following-sibling::td[2]/input[not(@class='readonly')]");
            By byNewResourceSkillMix = By.XPath("//*/table[@id='tblotherProductiveContainer']//tbody//tr//input[contains(@class,'sg-errors') and not(contains(@style,' none'))]/../following-sibling::td[10]//select[@name='skillMixList']");
            By byNewResourceShift = By.XPath("//*/table[@id='tblotherProductiveContainer']//tbody//tr//input[contains(@class,'sg-errors') and not(contains(@style,' none'))]/../following-sibling::td[11]//select[@name='plusShiftList']");
            var cmdAddNew = CommonFunctions.getElement(byAddNew);
            CommonFunctions.ClickByJE(cmdAddNew);
            CommonFunctions.WaitUntilPageIsAcive();

            CommonFunctions.SetText(
                CommonFunctions.getElement(byNewResourceName), 
                NewResourceName);

            var IwMon = CommonFunctions.getElement(byNewResourceMon);
            CommonFunctions.SetText(
                CommonFunctions.getElement(byNewResourceMon),
                CommonFunctions.GetDoubleRandomNumber().ToString());
            //Double-click on Mon cell
            CommonFunctions.DoubleClickUsingWebElement(IwMon);

            CommonFunctions.SelectItemFromDropdownMenu(
                CommonFunctions.getElement(byNewResourceSkillMix),
                skillMix);

            CommonFunctions.SelectItemFromDropdownMenu(
                CommonFunctions.getElement(byNewResourceShift),
                shift);

            SgMainMenu.clickSave();
        }
    }

    public class clsStaffingGridDetails
    {
        public string GridID { get; set; }
        public string GridDescription { get; set; }
        public string GridStatus { get; set; }
        public string GridOption { get; set; }
        public string GridType { get; set; }
        public string SubGridType { get; set; }
        public string ScheduleStartDate { get; set; }
        public string ProbableEndDate { get; set; }
        public string RequiredApprovers { get; set; }
        public string Dept { get; set; }
        public string DeptType { get; set; }
        public string DeptStatDescription { get; set; }
        public string PLUSTargetMonth { get; set; }
        public string VarProdHoursUOS { get; set; }
    }
}
