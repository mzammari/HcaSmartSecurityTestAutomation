using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyDeptLaborUtilizTrendValidator
    {
        public static void Validate(List<BiWeeklyDeptLaborUtilizTrendData> excelData, List<BiWeeklyDeptLaborUtilizTrendData> dbData)
        {
            Console.WriteLine("=== Bi-Weekly Dept Labor Utilization Trend Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                return;
            }

            var mismatches = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;
            int skippedRows = 0;
            int skippedFields = 0;

            foreach (var excelRow in excelData)
            {
                var dbRow = dbData.FirstOrDefault(d => IsSameRow(excelRow, d));
                if (dbRow == null)
                {
                    skippedRows++;
                    continue;
                }

                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.TotalUos), "UOS_ACT", "Total UOS", excelRow.TotalUos, dbRow.TotalUos);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.DailyAverageUos), "DAILY_AVG_UOS", "Daily Average UOS", excelRow.DailyAverageUos, dbRow.DailyAverageUos);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.TargetProdHoursUos), "PROD_HRS_UOS_TGT", "Target Prod Hrs/UOS", excelRow.TargetProdHoursUos, dbRow.TargetProdHoursUos);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.ActualProdHoursUos), "PROD_HRS_UOS_ACT", "Actual Prod Hrs/UOS", excelRow.ActualProdHoursUos, dbRow.ActualProdHoursUos);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.ActualNonProdPercent), "NON_PROD_PCT_ACT", "Actual Non-Prod %", excelRow.ActualNonProdPercent, dbRow.ActualNonProdPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesTarget), "PROD_FTES_TGT", "Productive FTEs Target", excelRow.ProductiveFtesTarget, dbRow.ProductiveFtesTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesActual), "PROD_FTES_ACT", "Productive FTEs Actual", excelRow.ProductiveFtesActual, dbRow.ProductiveFtesActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesVariance), "PROD_FTES_VAR", "Productive FTEs variance", excelRow.ProductiveFtesVariance, dbRow.ProductiveFtesVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesTarget), "PAID_FTES_TGT", "PAID FTEs Target", excelRow.PaidFtesTarget, dbRow.PaidFtesTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesActual), "PAID_FTES_ACT", "PAID FTEs Actual", excelRow.PaidFtesActual, dbRow.PaidFtesActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesVariance), "PAID_FTES_VAR", "PAID FTEs Variance", excelRow.PaidFtesVariance, dbRow.PaidFtesVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.OvertimeFtes), "OT_FTES_ACT", "Overtime FTEs", excelRow.OvertimeFtes, dbRow.OvertimeFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.OvertimePercent), "OT_PCT_ACT", "Overtime %", excelRow.OvertimePercent, dbRow.OvertimePercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.HwsFtes), "HWS_FTES_ACT", "HWS FTEs", excelRow.HwsFtes, dbRow.HwsFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.HwsPercent), "HWS_CONTR_PCT_ACT", "HWS %", excelRow.HwsPercent, dbRow.HwsPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.VendorFtes), "VEN_FTES_ACT", "VENDOR FTEs", excelRow.VendorFtes, dbRow.VendorFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.VendorPercent), "VEN_CONTR_PCT_ACT", "VENDOR %", excelRow.VendorPercent, dbRow.VendorPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.ContractFtes), "CONTR_FTES_ACT", "Contract FTEs", excelRow.ContractFtes, dbRow.ContractFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.ContractPercent), "CONTR_PCT_ACT", "Contract %", excelRow.ContractPercent, dbRow.ContractPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.PrnFtes), "PRN_FTE", "PRN FTEs", excelRow.PrnFtes, dbRow.PrnFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDeptLaborUtilizTrendData.PrnPercent), "PRN_FTE_PCT", "PRN %", excelRow.PrnPercent, dbRow.PrnPercent);
            }

            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine("Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");
            Console.WriteLine($"  Skipped Excel rows not present in DB: {skippedRows}");
            Console.WriteLine($"  Skipped fields not present in Excel: {skippedFields}");

            if (totalComparisons == 0)
            {
                Console.WriteLine("No matching Excel rows/columns were available for validation. Validation skipped.");
                return;
            }

            if (mismatches.Count > 0)
            {
                Console.WriteLine("\nMismatches:");
                Console.WriteLine($"{"COID",-8} {"Dept",-8} {"Pay Period",-12} {"DB Column",-24} {"Excel Column",-28} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 115));

                foreach (var mismatch in mismatches)
                    Console.WriteLine(mismatch);

                Assert.Fail($"Bi-Weekly Dept Labor Utilization Trend validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons.");
            }

            Console.WriteLine("\nBi-Weekly Dept Labor Utilization Trend validated successfully - all values match.");
        }

        private static void CompareField(
            List<string> mismatches,
            ref int totalComparisons,
            ref int matchCount,
            ref int skippedFields,
            BiWeeklyDeptLaborUtilizTrendData excelRow,
            string fieldName,
            string dbColumnName,
            string excelColumnName,
            decimal excelValue,
            decimal dbValue)
        {
            if (excelRow.AvailableFields.Any() && !excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            decimal roundedExcelValue = Math.Round(excelValue, 1, MidpointRounding.AwayFromZero);
            decimal roundedDbValue = Math.Round(dbValue, 1, MidpointRounding.AwayFromZero);

            if (roundedExcelValue == roundedDbValue)
            {
                matchCount++;
                return;
            }

            mismatches.Add($"{excelRow.Coid,-8} {excelRow.DeptOrGroupNum,-8} {excelRow.PayPeriodEndingDate:yyyy-MM-dd} {dbColumnName,-24} {excelColumnName,-28} {roundedExcelValue,12:N1} {roundedDbValue,12:N1}");
        }

        private static bool IsSameRow(BiWeeklyDeptLaborUtilizTrendData excelRow, BiWeeklyDeptLaborUtilizTrendData dbRow)
        {
            return string.Equals(NormalizeDigits(excelRow.Coid), NormalizeDigits(dbRow.Coid), StringComparison.OrdinalIgnoreCase)
                && string.Equals(NormalizeDigits(excelRow.DeptOrGroupNum), NormalizeDigits(dbRow.DeptOrGroupNum), StringComparison.OrdinalIgnoreCase)
                && excelRow.PayPeriodEndingDate.Date == dbRow.PayPeriodEndingDate.Date;
        }

        private static string NormalizeDigits(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            string digits = new string(value.Where(char.IsDigit).ToArray());
            return string.IsNullOrWhiteSpace(digits) ? value.Trim().ToUpperInvariant() : digits.TrimStart('0');
        }
    }
}
