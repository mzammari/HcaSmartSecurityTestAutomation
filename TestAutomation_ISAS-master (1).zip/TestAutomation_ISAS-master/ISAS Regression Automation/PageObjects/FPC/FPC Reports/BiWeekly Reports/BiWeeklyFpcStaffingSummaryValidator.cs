using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Validates BiWeekly FPC Staffing Summary data between Excel and Database.
    /// Compares DB rows against the matching Excel rows.
    /// </summary>
    public static class BiWeeklyFpcStaffingSummaryValidator
    {
        private const decimal TOLERANCE = 0.01m;

        /// <summary>
        /// Compare Excel data vs DB data and assert all values match.
        /// </summary>
        /// <param name="excelData">Data parsed from the downloaded Excel report</param>
        /// <param name="dbData">Data loaded from the database</param>
        public static void Validate(
            List<BiWeeklyFpcStaffingSummaryData> excelData,
            List<BiWeeklyFpcStaffingSummaryData> dbData)
        {
            Console.WriteLine("=== BiWeekly FPC Staffing Summary Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            var mismatches = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;

            foreach (var dbRow in dbData)
            {
                var excelRow = excelData.FirstOrDefault(e => IsSameRow(e, dbRow));

                if (excelRow == null)
                {
                    mismatches.Add($"DeptGroup {dbRow.DeptGroupNum} ({dbRow.DepartmentGroupName} / {dbRow.StatisticDescription}) - NOT FOUND in Excel");
                    continue;
                }

                // Compare each field
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "PaidIdxTargetActualFtesPercent", excelRow.PaidIdxTargetActualFtesPercent, dbRow.PaidIdxTargetActualFtesPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "UOSActual", excelRow.UOSActual, dbRow.UOSActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "TargetProdHoursUOS", excelRow.TargetProdHoursUOS, dbRow.TargetProdHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "ActualProdHoursUOS", excelRow.ActualProdHoursUOS, dbRow.ActualProdHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "ActualNonProdPercent", excelRow.ActualNonProdPercent, dbRow.ActualNonProdPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "ProductiveFtesTarget", excelRow.ProductiveFtesTarget, dbRow.ProductiveFtesTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "ProductiveFtesActual", excelRow.ProductiveFtesActual, dbRow.ProductiveFtesActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "ProductiveFtesVariance", excelRow.ProductiveFtesVariance, dbRow.ProductiveFtesVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "PaidFtesTarget", excelRow.PaidFtesTarget, dbRow.PaidFtesTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "PaidFtesActual", excelRow.PaidFtesActual, dbRow.PaidFtesActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "PaidFtesVariance", excelRow.PaidFtesVariance, dbRow.PaidFtesVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "OvertimeFtes", excelRow.OvertimeFtes, dbRow.OvertimeFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "OvertimePercent", excelRow.OvertimePercent, dbRow.OvertimePercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "OvertimeTargetPercent", excelRow.OvertimeTargetPercent, dbRow.OvertimeTargetPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "ContractFtes", excelRow.ContractFtes, dbRow.ContractFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "ContractPercent", excelRow.ContractPercent, dbRow.ContractPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "ContractTargetPercent", excelRow.ContractTargetPercent, dbRow.ContractTargetPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "PRNFtes", excelRow.PRNFtes, dbRow.PRNFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, excelRow.DeptGroupNum, "PRNPercent", excelRow.PRNPercent, dbRow.PRNPercent);
            }

            // Print summary
            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine($"Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");

            if (mismatches.Count > 0)
            {
                Console.WriteLine($"\nMismatches:");
                Console.WriteLine($"{"DeptGroup",-12} {"Field",-30} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 70));

                foreach (var mismatch in mismatches)
                {
                    Console.WriteLine(mismatch);
                }

                Assert.Fail($"BiWeekly FPC Staffing Summary validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons.");
            }
            else
            {
                Console.WriteLine($"\n? BiWeekly FPC Staffing Summary validated successfully - all values match!");
            }
        }

        private static void CompareField(
            List<string> mismatches,
            ref int totalComparisons,
            ref int matchCount,
            string deptGroupNum,
            string fieldName,
            decimal excelValue,
            decimal dbValue)
        {
            totalComparisons++;
            bool isMatch = Math.Abs(excelValue - dbValue) <= TOLERANCE;

            if (isMatch)
            {
                matchCount++;
            }
            else
            {
                mismatches.Add($"{deptGroupNum,-12} {fieldName,-30} {excelValue,12:N4} {dbValue,12:N4}");
            }
        }

        private static bool IsSameRow(BiWeeklyFpcStaffingSummaryData excelRow, BiWeeklyFpcStaffingSummaryData dbRow)
        {
            return Normalize(excelRow.DeptGroupNum) == Normalize(dbRow.DeptGroupNum)
                && Normalize(excelRow.DepartmentGroupName) == Normalize(dbRow.DepartmentGroupName)
                && Normalize(excelRow.StatisticDescription) == Normalize(dbRow.StatisticDescription);
        }

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : string.Join(" ", value.Trim().Split(' ').Where(s => !string.IsNullOrWhiteSpace(s))).ToUpperInvariant();
        }
    }
}
