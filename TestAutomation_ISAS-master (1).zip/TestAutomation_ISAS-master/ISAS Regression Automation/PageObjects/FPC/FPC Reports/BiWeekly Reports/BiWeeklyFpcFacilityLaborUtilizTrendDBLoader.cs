using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyFpcFacilityLaborUtilizTrendDBLoader
    {
        public static List<BiWeeklyFpcFacilityLaborUtilizTrendData> LoadFromDatabase(int year, DateTime startDate, DateTime endDate)
        {
            var result = new List<BiWeeklyFpcFacilityLaborUtilizTrendData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = BiWeeklyFpcFacilityLaborUtilizTrendSP.GetBiWeeklyFpcFacilityLaborUtilizTrendQuery(year, startDate, endDate);

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new BiWeeklyFpcFacilityLaborUtilizTrendData
                            {
                                PayPeriodEndingDate = GetDate(reader, "PP_END_DATE", "PayPeriodEndingDate"),
                                ADC = GetDecimal(reader, "ADC"),
                                EADC = GetDecimal(reader, "EADC"),
                                Admissions = GetDecimal(reader, "ADMISSIONS", "ADM"),
                                ProductiveFtesTarget = GetDecimal(reader, "PROD_FTES_TGT"),
                                ProductiveFtesActual = GetDecimal(reader, "PROD_FTES_ACT"),
                                ProductiveFtesVariance = GetDecimal(reader, "PROD_FTES_VAR"),
                                PaidFtesTarget = GetDecimal(reader, "PAID_FTES_TGT"),
                                PaidFtesActual = GetDecimal(reader, "PAID_FTES_ACT"),
                                PaidFtesVariance = GetDecimal(reader, "PAID_FTES_VAR"),
                                PaidEeobTarget = GetDecimal(reader, "PAID_EEOB_TGT"),
                                PaidEeobActual = GetDecimal(reader, "PAID_EEOB_ACT"),
                                PaidEeobVariance = GetDecimal(reader, "PAID_EEOB_VAR"),
                                PaidMhaaTarget = GetDecimal(reader, "PAID_MHAA_TGT"),
                                PaidMhaaActual = GetDecimal(reader, "PAID_MHAA_ACT"),
                                PaidMhaaVariance = GetDecimal(reader, "PAID_MHAA_VAR"),
                                OvertimeFtes = GetDecimal(reader, "OT_FTES_ACT"),
                                OvertimePercent = GetDecimal(reader, "OT_PCT_ACT"),
                                PRNFtes = GetDecimal(reader, "PRN_FTE"),
                                PRNPercent = GetDecimal(reader, "PRN_FTE_PCT")
                            });
                        }
                    }
                }
            }

            return result;
        }

        private static DateTime GetDate(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal))
                        return default;

                    var value = reader.GetValue(ordinal);
                    if (value is DateTime date)
                        return date.Date;

                    return DateTime.TryParse(value.ToString(), out DateTime parsed) ? parsed.Date : default;
                }
                catch (IndexOutOfRangeException)
                {
                }
            }

            return default;
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;

                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;

                    string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                    return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
                }
                catch
                {
                }
            }

            return 0m;
        }
    }
}
