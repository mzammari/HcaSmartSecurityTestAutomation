﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation

{
    internal class BiWeeklyDeptLaborUtilizReport
    {
        public static void GoTo()
        {
            FpcReportMenu.BiWeeklyReports.SelectBiWeeklyDeptLaborUtilizTrendReport();
            CommonFunctions.AddTestStep("Select Bi-Weekly Department Labor Utilization Report ", "The Bi-Weekly Department Labor Utilization Report is displayed");
        }

        public static bool IsAt
        {
            get
            {
                CommonFunctions.WaitUntilPageIsAcive();
                By byYearDropdown = By.XPath("//select[@id='monthOrYear']");
                CommonFunctions.AddTestStep("Verify the Bi-Weekly Department Labor Utilization Report page is active", "The Bi-Weekly Department Labor Utilization Report page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byYearDropdown, 40);
            }
        }

        public static BiWeeklyDeptLaborUtilizCommand BiWeeklyDeptLaborUtiliz()
        {
            return new BiWeeklyDeptLaborUtilizCommand();

        }
    }
#region: BiWeeklyDeptLaborUtilizCommand
public class BiWeeklyDeptLaborUtilizCommand
{
    private string year;
    private string deptGroupSelection;
    private string deptSelection;
    private string department;
    public BiWeeklyDeptLaborUtilizCommand withYear(string year)
    {
        this.year = year;
        return this;
    }
  
    public BiWeeklyDeptLaborUtilizCommand withDeptGroupSelection(string deptGroupSelection)
    {
        this.deptGroupSelection = deptGroupSelection;
        return this;
    }
    public BiWeeklyDeptLaborUtilizCommand withDeptSelection(string deptSelection)
    {
        this.deptSelection = deptSelection;
        return this;
    }
    public BiWeeklyDeptLaborUtilizCommand withDepartment(string department)
    {
        this.department = department;
        return this;
    }

    public void setYear()
    {
        By byYear= By.Id("monthOrYear");
        IWebElement mnuYear = CommonFunctions.getElement(byYear);
            mnuYear.Click();
        CommonFunctions.AddTestStep($"Verify a user can select {year} from Report year dropdown", $"The {year} is selected correctly");

    }
        public void setDeptGroupSelection()
        {
            By byDeptGroupSelection = By.Id("DeptGroupddl");
            IWebElement mnuDeptGroupSelection = CommonFunctions.getElement(byDeptGroupSelection);
            mnuDeptGroupSelection.Click();
            CommonFunctions.AddTestStep($"Verify a user can select {deptGroupSelection} from Department Group Selection dropdown", $"The {deptGroupSelection} is selected correctly");
        }
        public void setDeptSelection()
        {
            By byDeptSelection = By.Id("deptSelection");
            IWebElement mnuDeptSelection = CommonFunctions.getElement(byDeptSelection);
            mnuDeptSelection.Click();
            CommonFunctions.AddTestStep($"Verify a user can select {deptSelection} from Department Selection dropdown", $"The {deptSelection} is selected correctly");
        }

        public void setDepartment()
        {
            By byDepartment = By.Id("deptList");
            IWebElement mnuDepartment = CommonFunctions.getElement(byDepartment);
                     mnuDepartment.Click();
            CommonFunctions.AddTestStep($"Verify a user can select {department} from Department dropdown", $"The {department} is selected correctly");
        }
        private void clickExcel()
        {
            By byExcel = By.XPath("//img[@title='Excel Format']");
            IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
                CommonFunctions.Click(cmdExcel);
            CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
        }

        public void Excel()
        {
            setYear();
            setDeptGroupSelection();
            setDeptSelection();
            setDepartment();
            clickExcel();
        }

    }
    #endregion
}

