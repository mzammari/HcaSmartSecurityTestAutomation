using System;
using System;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyDivisionStaffingSummarySP
    {
        public static string GetBiWeeklyDivisionStaffingSummaryQuery(int divisionNumber, DateTime? payPeriodEndingDate)
        {
            string payPeriodFilter = payPeriodEndingDate.HasValue
                ? $@" AND CASE WHEN 0 = 1 THEN (LPR.PP_END_DATE - 3 DAYS) ELSE LPR.PP_END_DATE END = DATE('{payPeriodEndingDate.Value:yyyy-MM-dd}')"
                : string.Empty;

            return $@"SELECT FAC.CO_ID,
       FAC.FACILITY_NAME,
       CASE WHEN 0 = 1 THEN (LPR.PP_END_DATE - 3 DAYS) ELSE LPR.PP_END_DATE END AS PP_END_DATE,
       LPR.AVG_DLY_CENSUS,
       LPR.EQ_AVG_DLY_CENSUS,
       LPR.OP_FACTOR,
       LPR.EEOB_BDGT,
       LPR.EEOB_ACTUAL,
       LPR.EEOB_VAR,
       LPR.PCNT_CHG_EEOB,
       LPR.MANHOURS_AA_BDGT,
       LPR.MANHOURS_AA_ACTUAL,
       LPR.MANHOURS_AA_VAR,
       LPR.PCNT_CHG_MH_AA,
       LPR.AVG_HRLY_RATE_BDGT,
       LPR.AVG_HRLY_RATE_ACT,
       LPR.AVG_HRLY_RATE_VAR,
       LPR.PCNT_CHG_AVHR_RATE,
       LPR.TOT_OT_FTES,
       LPR.TOT_HWS_CONTR_FTES,
       LPR.TOT_VEN_CONTR_FTES,
       LPR.TOT_CONTR_FTES,
       LPR.PCNT_CHG_EADC,
       LPR.PCNT_CHG_PROD_FTES,
       LPR.PCNT_CHG_PAID_FTES
FROM H.LPR070 LPR
INNER JOIN H.LPBFAC FAC
    ON LPR.UNIT_NUM = FAC.UNIT_NUM
WHERE LPR.UNIT_NUM IN (SELECT FAC.UNIT_NUM
                       FROM H.LPBFAC FAC
                       WHERE FAC.DIVISION_NBR = {divisionNumber}
                         AND FAC.ROLLUP_REPORTING = 'Y')
{payPeriodFilter}
ORDER BY FAC.FACILITY_NAME";
        }

        public static bool IsSelectQuery(string query)
        {
            return !string.IsNullOrWhiteSpace(query)
                && query.TrimStart().StartsWith("SELECT", StringComparison.OrdinalIgnoreCase);
        }
    }
}
