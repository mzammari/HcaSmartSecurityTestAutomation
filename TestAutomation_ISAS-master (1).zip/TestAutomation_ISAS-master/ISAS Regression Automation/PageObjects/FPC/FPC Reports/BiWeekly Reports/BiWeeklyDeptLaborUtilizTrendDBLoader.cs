using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyDeptLaborUtilizTrendDBLoader
    {
        public static List<BiWeeklyDeptLaborUtilizTrendData> LoadFromDatabase(string coid, List<string> deptOrGroupNumbers, DateTime startDate, DateTime endDate)
        {
            var result = new List<BiWeeklyDeptLaborUtilizTrendData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = BiWeeklyDeptLaborUtilizTrendSP.GetBiWeeklyDeptLaborUtilizTrendQuery(coid, deptOrGroupNumbers, startDate, endDate);
            if (!BiWeeklyDeptLaborUtilizTrendSP.IsSelectQuery(sqlQuery))
                throw new InvalidOperationException("Bi-Weekly Dept Labor Utilization Trend DB validation skipped because the DB query is not a SELECT query.");

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new BiWeeklyDeptLaborUtilizTrendData
                            {
                                Coid = GetString(reader, "CO_ID"),
                                DeptOrGroupNum = GetString(reader, "DEPT_OR_GROUP_NUM"),
                                DeptOrGroupDescription = GetString(reader, "DEPT_OR_GROUP_DESC"),
                                PayPeriodEndingDate = GetDate(reader, "PP_END_DATE"),
                                TotalUos = GetDecimal(reader, "UOS_ACT"),
                                DailyAverageUos = GetDecimal(reader, "DAILY_AVG_UOS"),
                                TargetProdHoursUos = GetDecimal(reader, "PROD_HRS_UOS_TGT"),
                                ActualProdHoursUos = GetDecimal(reader, "PROD_HRS_UOS_ACT"),
                                ActualNonProdPercent = GetDecimal(reader, "NON_PROD_PCT_ACT"),
                                ProductiveFtesTarget = GetDecimal(reader, "PROD_FTES_TGT"),
                                ProductiveFtesActual = GetDecimal(reader, "PROD_FTES_ACT"),
                                ProductiveFtesVariance = GetDecimal(reader, "PROD_FTES_VAR"),
                                PaidFtesTarget = GetDecimal(reader, "PAID_FTES_TGT"),
                                PaidFtesActual = GetDecimal(reader, "PAID_FTES_ACT"),
                                PaidFtesVariance = GetDecimal(reader, "PAID_FTES_VAR"),
                                OvertimeFtes = GetDecimal(reader, "OT_FTES_ACT"),
                                OvertimePercent = GetDecimal(reader, "OT_PCT_ACT"),
                                HwsFtes = GetDecimal(reader, "HWS_FTES_ACT"),
                                HwsPercent = GetDecimal(reader, "HWS_CONTR_PCT_ACT"),
                                VendorFtes = GetDecimal(reader, "VEN_FTES_ACT"),
                                VendorPercent = GetDecimal(reader, "VEN_CONTR_PCT_ACT"),
                                ContractFtes = GetDecimal(reader, "CONTR_FTES_ACT"),
                                ContractPercent = GetDecimal(reader, "CONTR_PCT_ACT"),
                                PrnFtes = GetDecimal(reader, "PRN_FTE"),
                                PrnPercent = GetDecimal(reader, "PRN_FTE_PCT")
                            });
                        }
                    }
                }
            }

            return result;
        }

        private static string GetString(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    return reader.IsDBNull(ordinal) ? string.Empty : reader.GetValue(ordinal).ToString().Trim();
                }
                catch (IndexOutOfRangeException)
                {
                }
            }

            return string.Empty;
        }

        private static DateTime GetDate(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return default;
                    var value = reader.GetValue(ordinal);
                    if (value is DateTime date) return date.Date;
                    return DateTime.TryParse(value.ToString(), out DateTime parsed) ? parsed.Date : default;
                }
                catch (IndexOutOfRangeException)
                {
                }
            }

            return default;
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;
                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;
                    string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                    return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
                }
                catch
                {
                }
            }

            return 0m;
        }
    }
}
