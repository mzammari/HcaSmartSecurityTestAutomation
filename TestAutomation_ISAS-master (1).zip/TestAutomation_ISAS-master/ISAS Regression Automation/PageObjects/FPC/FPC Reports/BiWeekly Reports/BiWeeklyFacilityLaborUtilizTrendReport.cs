﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    internal class BiWeeklyFacilityLaborUtilizTrendReport
    {
        public static void GoTo()
        {
            FpcReportMenu.BiWeeklyReports.SelectBiWeeklyFacilityLaborUtilizTrendReport();
            CommonFunctions.AddTestStep("Select Bi-Weekly Facility Labor Utilization Report ", "The Bi-Weekly Department Labor Utilization Report is displayed");
        }

        public static bool IsAt
        {
            get
            {
                CommonFunctions.WaitUntilPageIsAcive();
                By byYearDropdown = By.XPath("//select[@id='monthOrYear']");
                CommonFunctions.AddTestStep("Verify the Bi-Weekly Facility Labor Utilization Report page is active", "The Bi-Weekly Facility Labor Utilization Report page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byYearDropdown, 40);
            }
        }

        #region: BiWeeklyFpcFacilityLaborUtilizTrendCommand
        public static BiWeeklyFpcFacilityLaborUtilizTrendCommand BiWeeklyFacilityLaborUtilizTrend()
        {
            return new BiWeeklyFpcFacilityLaborUtilizTrendCommand();
        }
    }
    public class BiWeeklyFpcFacilityLaborUtilizTrendCommand
    {
        private string year;
        public BiWeeklyFpcFacilityLaborUtilizTrendCommand withYear(string year)
        {
            this.year = year;
            return this;
        }



        public void setYear()
        {
            By byYear = By.Id("monthOrYear");
            IWebElement mnuYear = CommonFunctions.getElement(byYear);
            mnuYear.Click();
            CommonFunctions.AddTestStep($"Verify a user can select {year} from Report year dropdown", $"The {year} is selected correctly");

        }
        private void clickExcel()
        {
            By byExcel = By.XPath("//img[@title='Excel Format']");
            IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
            CommonFunctions.Click(cmdExcel);
            CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
        }

        public void Excel()
        {
            setYear();
            clickExcel();
        }



    }
        #endregion

    }
