using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    public class BiWeeklyDeptLaborUtilizTrendData
    {
        public string Coid { get; set; }
        public string DeptOrGroupNum { get; set; }
        public string DeptOrGroupDescription { get; set; }
        public DateTime PayPeriodEndingDate { get; set; }
        public decimal TotalUos { get; set; }
        public decimal DailyAverageUos { get; set; }
        public decimal TargetProdHoursUos { get; set; }
        public decimal ActualProdHoursUos { get; set; }
        public decimal ActualNonProdPercent { get; set; }
        public decimal ProductiveFtesTarget { get; set; }
        public decimal ProductiveFtesActual { get; set; }
        public decimal ProductiveFtesVariance { get; set; }
        public decimal PaidFtesTarget { get; set; }
        public decimal PaidFtesActual { get; set; }
        public decimal PaidFtesVariance { get; set; }
        public decimal OvertimeFtes { get; set; }
        public decimal OvertimePercent { get; set; }
        public decimal HwsFtes { get; set; }
        public decimal HwsPercent { get; set; }
        public decimal VendorFtes { get; set; }
        public decimal VendorPercent { get; set; }
        public decimal ContractFtes { get; set; }
        public decimal ContractPercent { get; set; }
        public decimal PrnFtes { get; set; }
        public decimal PrnPercent { get; set; }
        public HashSet<string> AvailableFields { get; set; } = new HashSet<string>();
    }

    public class BiWeeklyDeptLaborUtilizTrendReportCriteria
    {
        public string Coid { get; set; }
        public List<string> DeptOrGroupNumbers { get; set; } = new List<string>();
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public static class BiWeeklyDeptLaborUtilizTrendExcelReport
    {
        private static readonly Dictionary<string, string[]> FieldAliases = new Dictionary<string, string[]>
        {
            [nameof(BiWeeklyDeptLaborUtilizTrendData.Coid)] = new[] { "COID", "CO_ID" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.DeptOrGroupNum)] = new[] { "Dept", "Department", "Dept Num", "Department Num", "Dept/Group Num", "DEPT_OR_GROUP_NUM", "Num" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.DeptOrGroupDescription)] = new[] { "Dept Name", "Department Name", "Dept/Group", "Department", "DEPT_OR_GROUP_DESC" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.PayPeriodEndingDate)] = new[] { "Pay Period Ending Date", "PP_END_DATE", "Ending Date" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.TotalUos)] = new[] { "Total UOS", "UOS_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.DailyAverageUos)] = new[] { "Daily Average UOS", "DAILY_AVG_UOS" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.TargetProdHoursUos)] = new[] { "Target Prod Hrs/UOS", "PROD_HRS_UOS_TGT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.ActualProdHoursUos)] = new[] { "Actual Prod Hrs/UOS", "PROD_HRS_UOS_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.ActualNonProdPercent)] = new[] { "Actual Non-Prod %", "NON_PROD_PCT_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesTarget)] = new[] { "Productive FTEs Target", "PROD_FTES_TGT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesActual)] = new[] { "Productive FTEs Actual", "PROD_FTES_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesVariance)] = new[] { "Productive FTEs variance", "Productive FTEs Variance", "PROD_FTES_VAR" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesTarget)] = new[] { "PAID FTEs Target", "Paid FTEs Target", "PAID_FTES_TGT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesActual)] = new[] { "PAID FTEs Actual", "Paid FTEs Actual", "PAID_FTES_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesVariance)] = new[] { "PAID FTEs Variance", "Paid FTEs Variance", "PAID_FTES_VAR" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.OvertimeFtes)] = new[] { "Overtime FTEs", "OT_FTES_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.OvertimePercent)] = new[] { "Overtime %", "OT_PCT_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.HwsFtes)] = new[] { "HWS FTEs", "HWS_FTES_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.HwsPercent)] = new[] { "HWS %", "HWS_CONTR_PCT_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.VendorFtes)] = new[] { "VENDOR FTEs", "VEN_FTES_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.VendorPercent)] = new[] { "VENDOR %", "VEN_CONTR_PCT_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.ContractFtes)] = new[] { "Contract FTEs", "CONTR_FTES_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.ContractPercent)] = new[] { "Contract %", "CONTR_PCT_ACT" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.PrnFtes)] = new[] { "PRN FTEs", "PRN_FTE" },
            [nameof(BiWeeklyDeptLaborUtilizTrendData.PrnPercent)] = new[] { "PRN %", "PRN_FTE_PCT" }
        };

        public static bool HasValidationColumns(string filePath)
        {
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            if (headerRowIndex == -1)
                return false;

            var columnMap = BuildColumnMap(rows, headerRowIndex);
            return !string.IsNullOrWhiteSpace(FindDeptOrGroupNum(rows))
                && columnMap.ContainsKey(nameof(BiWeeklyDeptLaborUtilizTrendData.PayPeriodEndingDate))
                && columnMap.Keys.Any(k => k != nameof(BiWeeklyDeptLaborUtilizTrendData.DeptOrGroupNum)
                    && k != nameof(BiWeeklyDeptLaborUtilizTrendData.PayPeriodEndingDate)
                    && k != nameof(BiWeeklyDeptLaborUtilizTrendData.Coid));
        }

        public static List<BiWeeklyDeptLaborUtilizTrendData> ParseBiWeeklyDeptLaborUtilizTrendExcel(string filePath)
        {
            var result = new List<BiWeeklyDeptLaborUtilizTrendData>();
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            if (headerRowIndex == -1)
            {
                Console.WriteLine("Could not find Bi-Weekly Dept Labor Utilization Trend header row in the Excel file. Treating Excel report as no data.");
                return result;
            }

            var columnMap = BuildColumnMap(rows, headerRowIndex);
            if (!columnMap.TryGetValue(nameof(BiWeeklyDeptLaborUtilizTrendData.PayPeriodEndingDate), out int dateColumnIndex))
                return result;

            string headerCoid = FindCoid(rows, filePath);
            string headerDeptOrGroupNum = FindDeptOrGroupNum(rows);
            string headerDeptOrGroupDescription = FindDeptOrGroupDescription(rows);
            if (string.IsNullOrWhiteSpace(headerDeptOrGroupNum))
                return result;

            var availableFields = columnMap.Keys
                .Where(k => k != nameof(BiWeeklyDeptLaborUtilizTrendData.Coid)
                    && k != nameof(BiWeeklyDeptLaborUtilizTrendData.DeptOrGroupNum)
                    && k != nameof(BiWeeklyDeptLaborUtilizTrendData.DeptOrGroupDescription)
                    && k != nameof(BiWeeklyDeptLaborUtilizTrendData.PayPeriodEndingDate))
                .ToHashSet();

            for (int i = headerRowIndex + 1; i < rows.Count; i++)
            {
                var row = rows[i];
                if (CommonFunctions.IsEmptyRow(row) || IsSummaryRow(row))
                    continue;

                if (!TryGetDate(GetCell(row, dateColumnIndex), out DateTime payPeriodEndingDate))
                    continue;

                result.Add(new BiWeeklyDeptLaborUtilizTrendData
                {
                    Coid = GetString(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.Coid), headerCoid),
                    DeptOrGroupNum = headerDeptOrGroupNum,
                    DeptOrGroupDescription = GetString(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.DeptOrGroupDescription), headerDeptOrGroupDescription),
                    PayPeriodEndingDate = payPeriodEndingDate,
                    TotalUos = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.TotalUos)),
                    DailyAverageUos = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.DailyAverageUos)),
                    TargetProdHoursUos = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.TargetProdHoursUos)),
                    ActualProdHoursUos = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.ActualProdHoursUos)),
                    ActualNonProdPercent = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.ActualNonProdPercent)),
                    ProductiveFtesTarget = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesTarget)),
                    ProductiveFtesActual = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesActual)),
                    ProductiveFtesVariance = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.ProductiveFtesVariance)),
                    PaidFtesTarget = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesTarget)),
                    PaidFtesActual = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesActual)),
                    PaidFtesVariance = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.PaidFtesVariance)),
                    OvertimeFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.OvertimeFtes)),
                    OvertimePercent = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.OvertimePercent)),
                    HwsFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.HwsFtes)),
                    HwsPercent = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.HwsPercent)),
                    VendorFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.VendorFtes)),
                    VendorPercent = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.VendorPercent)),
                    ContractFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.ContractFtes)),
                    ContractPercent = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.ContractPercent)),
                    PrnFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.PrnFtes)),
                    PrnPercent = GetDecimal(row, columnMap, nameof(BiWeeklyDeptLaborUtilizTrendData.PrnPercent)),
                    AvailableFields = availableFields
                });
            }

            return result;
        }

        public static BiWeeklyDeptLaborUtilizTrendReportCriteria GetReportCriteria(string filePath)
        {
            var data = ParseBiWeeklyDeptLaborUtilizTrendExcel(filePath);
            if (!data.Any())
                throw new InvalidOperationException("Could not find data rows in the Bi-Weekly Dept Labor Utilization Trend Excel file.");

            var dates = data.Select(d => d.PayPeriodEndingDate.Date).Distinct().OrderBy(d => d).ToList();
            return new BiWeeklyDeptLaborUtilizTrendReportCriteria
            {
                Coid = data.Select(d => NormalizeDigits(d.Coid)).FirstOrDefault(c => !string.IsNullOrWhiteSpace(c)),
                DeptOrGroupNumbers = data.Select(d => NormalizeDigits(d.DeptOrGroupNum)).Where(d => !string.IsNullOrWhiteSpace(d)).Distinct().ToList(),
                StartDate = dates.First(),
                EndDate = dates.Last()
            };
        }

        private static int FindHeaderRow(List<object[]> rows)
        {
            for (int i = 0; i < rows.Count; i++)
            {
                var columnMap = BuildColumnMap(rows, i);
                bool hasDate = columnMap.ContainsKey(nameof(BiWeeklyDeptLaborUtilizTrendData.PayPeriodEndingDate));
                bool hasUos = columnMap.ContainsKey(nameof(BiWeeklyDeptLaborUtilizTrendData.TotalUos));

                if (hasDate && hasUos)
                    return i;
            }

            return -1;
        }

        private static Dictionary<string, int> BuildColumnMap(List<object[]> rows, int headerRowIndex)
        {
            var result = new Dictionary<string, int>();
            var headerRow = rows[headerRowIndex];
            var groupRow = headerRowIndex > 0 ? rows[headerRowIndex - 1] : Array.Empty<object>();
            int columnCount = Math.Max(headerRow.Length, groupRow.Length);
            var normalizedHeaders = new List<string>();
            string currentGroup = string.Empty;

            for (int i = 0; i < columnCount; i++)
            {
                string groupHeader = GetCellText(groupRow, i);
                string detailHeader = GetCellText(headerRow, i);

                if (!string.IsNullOrWhiteSpace(groupHeader))
                    currentGroup = groupHeader;

                string combinedHeader = string.IsNullOrWhiteSpace(detailHeader) ? currentGroup : $"{currentGroup} {detailHeader}";
                normalizedHeaders.Add(NormalizeHeader(combinedHeader));
            }

            foreach (var field in FieldAliases)
            {
                foreach (string alias in field.Value.Select(NormalizeHeader))
                {
                    int index = normalizedHeaders.FindIndex(h => h == alias || h.EndsWith(alias));
                    if (index >= 0)
                    {
                        result[field.Key] = index;
                        break;
                    }
                }
            }

            return result;
        }

        private static List<object[]> ReadRows(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var allRows = new List<object[]>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                do
                {
                    while (reader.Read())
                    {
                        var row = new object[reader.FieldCount];
                        for (int i = 0; i < reader.FieldCount; i++)
                            row[i] = reader.GetValue(i);

                        allRows.Add(row);
                    }
                } while (reader.NextResult());
            }

            return allRows;
        }

        private static string FindCoid(List<object[]> rows, string filePath)
        {
            string fileName = Path.GetFileNameWithoutExtension(filePath);
            var fileMatch = Regex.Match(fileName, @"\b(?<coid>\d{5})\b");
            if (fileMatch.Success)
                return fileMatch.Groups["coid"].Value;

            int headerRowIndex = FindHeaderRow(rows);
            var headerRows = headerRowIndex > 0 ? rows.Take(headerRowIndex) : rows.Take(10);
            string text = string.Join(" ", headerRows.SelectMany(r => r).Where(c => c != null).Select(c => c.ToString()));
            var headerMatch = Regex.Match(text, @"COID\s*[:\-]?\s*(?<coid>\d+)", RegexOptions.IgnoreCase);
            return headerMatch.Success ? headerMatch.Groups["coid"].Value : string.Empty;
        }

        private static string FindDeptOrGroupNum(List<object[]> rows)
        {
            string departmentGroupText = FindDepartmentGroupText(rows);
            var match = Regex.Match(departmentGroupText, @"Department/Group\s*[:\-]?\s*(?<dept>\d+)", RegexOptions.IgnoreCase);

            return match.Success ? match.Groups["dept"].Value.Trim() : string.Empty;
        }

        private static string FindDeptOrGroupDescription(List<object[]> rows)
        {
            string departmentGroupText = FindDepartmentGroupText(rows);
            var match = Regex.Match(departmentGroupText, @"Department/Group\s*[:\-]?\s*\d+\s*-\s*(?<description>.+)", RegexOptions.IgnoreCase);

            return match.Success ? match.Groups["description"].Value.Trim() : string.Empty;
        }

        private static string FindDepartmentGroupText(List<object[]> rows)
        {
            int headerRowIndex = FindHeaderRow(rows);
            var headerRows = headerRowIndex > 0 ? rows.Take(headerRowIndex) : rows.Take(12);

            foreach (var row in headerRows)
            {
                string rowText = string.Join(" ", row.Where(c => c != null).Select(c => c.ToString()));
                if (rowText.Contains("Department/Group", StringComparison.OrdinalIgnoreCase))
                    return rowText;
            }

            return string.Empty;
        }

        private static string GetString(object[] row, Dictionary<string, int> columnMap, string fieldName, string fallback = "")
        {
            return columnMap.TryGetValue(fieldName, out int index) ? GetString(row, index) : fallback;
        }

        private static string GetString(object[] row, int index)
        {
            object value = GetCell(row, index);
            return value?.ToString()?.Trim() ?? string.Empty;
        }

        private static object GetCell(object[] row, int index)
        {
            return index >= 0 && index < row.Length ? row[index] : null;
        }

        private static decimal GetDecimal(object[] row, Dictionary<string, int> columnMap, string fieldName)
        {
            if (!columnMap.TryGetValue(fieldName, out int index))
                return 0m;

            var value = GetCell(row, index);
            if (value == null) return 0m;
            if (value is decimal dec) return dec;
            if (value is double d) return (decimal)d;
            if (value is float f) return (decimal)f;
            if (value is int i) return i;
            if (value is long l) return l;

            string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(text)) return 0m;

            bool isNegative = text.StartsWith("(") && text.EndsWith(")");
            if (isNegative) text = text.Trim('(', ')');

            return decimal.TryParse(text, out decimal parsed) ? (isNegative ? -parsed : parsed) : 0m;
        }

        private static bool TryGetDate(object value, out DateTime date)
        {
            date = default;
            if (value == null) return false;
            if (value is DateTime dateValue)
            {
                date = dateValue.Date;
                return true;
            }

            if (value is double serialDate && serialDate > 30000 && serialDate < 80000)
            {
                date = DateTime.FromOADate(serialDate).Date;
                return true;
            }

            return DateTime.TryParse(value.ToString(), out date);
        }

        private static bool IsSummaryRow(object[] row)
        {
            string rowText = string.Join(" ", row.Where(c => c != null).Select(c => c.ToString()));
            return rowText.Contains("total", StringComparison.OrdinalIgnoreCase)
                || rowText.Contains("average", StringComparison.OrdinalIgnoreCase)
                || rowText.Contains("YTD", StringComparison.OrdinalIgnoreCase)
                || rowText.Contains("AVG/PP", StringComparison.OrdinalIgnoreCase);
        }

        private static List<string> GetNormalizedCells(object[] row)
        {
            return row.Where(c => c != null).Select(c => NormalizeHeader(c.ToString())).ToList();
        }

        private static string GetCellText(object[] row, int index)
        {
            object value = GetCell(row, index);
            return value?.ToString()?.Trim() ?? string.Empty;
        }

        private static string NormalizeHeader(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : Regex.Replace(value, @"[^A-Za-z0-9]", string.Empty).ToUpperInvariant();
        }

        private static string NormalizeDigits(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            string digits = new string(value.Where(char.IsDigit).ToArray());
            return string.IsNullOrWhiteSpace(digits) ? value.Trim() : digits.TrimStart('0');
        }
    }
}
