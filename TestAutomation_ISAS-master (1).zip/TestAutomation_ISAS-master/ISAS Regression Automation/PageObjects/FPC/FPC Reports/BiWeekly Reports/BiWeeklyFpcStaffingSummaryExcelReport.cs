using ExcelDataReader;
using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class BiWeeklyFpcStaffingSummaryData
    {
        public string DeptGroupNum { get; set; }
        public string DepartmentGroupName { get; set; }
        public string StatisticDescription { get; set; }
        public decimal PaidIdxTargetActualFtesPercent { get; set; }
        public decimal UOSActual { get; set; }
        public decimal TargetProdHoursUOS { get; set; }
        public decimal ActualProdHoursUOS { get; set; }
        public decimal ActualNonProdPercent { get; set; }
        public decimal ProductiveFtesTarget { get; set; }
        public decimal ProductiveFtesActual { get; set; }
        public decimal ProductiveFtesVariance { get; set; }
        public decimal PaidFtesTarget { get; set; }
        public decimal PaidFtesActual { get; set; }
        public decimal PaidFtesVariance { get; set; }
        public decimal OvertimeFtes { get; set; }
        public decimal OvertimePercent { get; set; }
        public decimal OvertimeTargetPercent { get; set; }
        public decimal ContractFtes { get; set; }
        public decimal ContractPercent { get; set; }
        public decimal ContractTargetPercent { get; set; }
        public decimal PRNFtes { get; set; }
        public decimal PRNPercent { get; set; }
    }

    public class BiWeeklyFpcStaffingSummaryExcelReport
    {
        public static List<BiWeeklyFpcStaffingSummaryData> ParseBiWeeklyFpcStaffingSummaryExcel(string filePath)
        {
            var result = new List<BiWeeklyFpcStaffingSummaryData>();

            // Register the code page provider (required for .xls files)
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var allRows = new List<object[]>();

                    // Read all rows into memory
                    do
                    {
                        while (reader.Read())
                        {
                            var row = new object[reader.FieldCount];
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row[i] = reader.GetValue(i);
                            }
                            allRows.Add(row);
                        }
                    } while (reader.NextResult());

                    // Find the row that contains "Num" in the header
                    int startRowIndex = CommonFunctions.FindDeptRow("Num", allRows);

                    if (startRowIndex == -1)
                    {
                        throw new InvalidOperationException("Could not find 'Num' header row in the Excel file");
                    }

                    // Process rows starting after the header row
                    for (int i = startRowIndex + 1; i < allRows.Count; i++)
                    {
                        var row = allRows[i];

                        // Skip empty rows
                        if (CommonFunctions.IsEmptyRow(row))
                            continue;

                        string deptGroupNum = CommonFunctions.GetStringValue(row, 0);
                        if (string.IsNullOrWhiteSpace(deptGroupNum))
                            continue;

                        var lstRows = new BiWeeklyFpcStaffingSummaryData()
                        {
                            DeptGroupNum = deptGroupNum,
                            DepartmentGroupName = CommonFunctions.GetStringValue(row, 1),
                            StatisticDescription = CommonFunctions.GetStringValue(row, 2),
                            PaidIdxTargetActualFtesPercent = CommonFunctions.GetDecimalValue(row, 3),
                            UOSActual = CommonFunctions.GetDecimalValue(row, 4),
                            TargetProdHoursUOS = CommonFunctions.GetDecimalValue(row, 5),
                            ActualProdHoursUOS = CommonFunctions.GetDecimalValue(row, 6),
                            ActualNonProdPercent = CommonFunctions.GetDecimalValue(row, 7),
                            ProductiveFtesTarget = CommonFunctions.GetDecimalValue(row, 8),
                            ProductiveFtesActual = CommonFunctions.GetDecimalValue(row, 9),
                            ProductiveFtesVariance = CommonFunctions.GetDecimalValue(row, 10),
                            PaidFtesTarget = CommonFunctions.GetDecimalValue(row, 11),
                            PaidFtesActual = CommonFunctions.GetDecimalValue(row, 12),
                            PaidFtesVariance = CommonFunctions.GetDecimalValue(row, 13),
                            OvertimeFtes = CommonFunctions.GetDecimalValue(row, 14),
                            OvertimePercent = CommonFunctions.GetDecimalValue(row, 15),
                            OvertimeTargetPercent = CommonFunctions.GetDecimalValue(row, 16),
                            ContractFtes = CommonFunctions.GetDecimalValue(row, 17),
                            ContractPercent = CommonFunctions.GetDecimalValue(row, 18),
                            ContractTargetPercent = CommonFunctions.GetDecimalValue(row, 19),
                            PRNFtes = CommonFunctions.GetDecimalValue(row, 20),
                            PRNPercent = CommonFunctions.GetDecimalValue(row, 21),
                        };
                        result.Add(lstRows);
                    }
                }
            }

            return result;
        }
    }
}
