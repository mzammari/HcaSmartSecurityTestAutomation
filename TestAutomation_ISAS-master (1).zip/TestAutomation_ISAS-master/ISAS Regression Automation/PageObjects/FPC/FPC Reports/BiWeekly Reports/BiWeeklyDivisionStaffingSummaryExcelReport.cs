using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    public class BiWeeklyDivisionStaffingSummaryData
    {
        public string Coid { get; set; }
        public string FacilityName { get; set; }
        public DateTime PayPeriodEndingDate { get; set; }
        public decimal AvgDailyCensus { get; set; }
        public decimal EqAvgDailyCensus { get; set; }
        public decimal OpFactor { get; set; }
        public decimal EeobBudget { get; set; }
        public decimal EeobActual { get; set; }
        public decimal EeobVariance { get; set; }
        public decimal EeobPercentChange { get; set; }
        public decimal ManhoursAaBudget { get; set; }
        public decimal ManhoursAaActual { get; set; }
        public decimal ManhoursAaVariance { get; set; }
        public decimal ManhoursAaPercentChange { get; set; }
        public decimal AvgHourlyRateBudget { get; set; }
        public decimal AvgHourlyRateActual { get; set; }
        public decimal AvgHourlyRateVariance { get; set; }
        public decimal AvgHourlyRatePercentChange { get; set; }
        public decimal PremiumOtFtes { get; set; }
        public decimal PremiumHwsFtes { get; set; }
        public decimal PremiumVendorFtes { get; set; }
        public decimal PremiumContractFtes { get; set; }
        public decimal EadcPercentChange { get; set; }
        public decimal ProductiveFtesPercentChange { get; set; }
        public decimal PaidFtesPercentChange { get; set; }
        public HashSet<string> AvailableFields { get; set; } = new HashSet<string>();
    }

    public class BiWeeklyDivisionStaffingSummaryReportCriteria
    {
        public string DivisionName { get; set; }
        public int DivisionNumber { get; set; }
        public DateTime? PayPeriodEndingDate { get; set; }
    }

    public static class BiWeeklyDivisionStaffingSummaryExcelReport
    {
        private static readonly Dictionary<string, string[]> FieldAliases = new Dictionary<string, string[]>
        {
            [nameof(BiWeeklyDivisionStaffingSummaryData.Coid)] = new[] { "COID", "CO_ID" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.FacilityName)] = new[] { "Facility", "FACILITY_NAME", "Facility Name" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.PayPeriodEndingDate)] = new[] { "Pay Period Ending Date", "PP_END_DATE", "PP End Date", "Ending Date" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.AvgDailyCensus)] = new[] { "ADC", "AVG_DLY_CENSUS" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.EqAvgDailyCensus)] = new[] { "EADC", "EQ_AVG_DLY_CENSUS" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.OpFactor)] = new[] { "OP Factor", "OP_FACTOR" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.EeobBudget)] = new[] { "EEOB BUDGET", "EEOB_BDGT" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.EeobActual)] = new[] { "EEOB Actual", "EEOB_ACTUAL" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.EeobVariance)] = new[] { "EEOB Variance", "EEOB_VAR" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.EeobPercentChange)] = new[] { "EEOB %CHG", "PCNT_CHG_EEOB" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaBudget)] = new[] { "MANHOURS/AA BUDGET", "MANHOURS_AA_BDGT" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaActual)] = new[] { "MANHOURS/AA Actual", "MANHOURS_AA_ACTUAL" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaVariance)] = new[] { "MANHOURS/AA Variance", "MANHOURS_AA_VAR" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaPercentChange)] = new[] { "ManHours/AA %CHG", "PCNT_CHG_MH_AA" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateBudget)] = new[] { "AVERAGE HOURLY RATE BUDGET", "AVG_HRLY_RATE_BDGT" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateActual)] = new[] { "AVERAGE HOURLY RATE Actual", "AVG_HRLY_RATE_ACT" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateVariance)] = new[] { "AVERAGE HOURLY RATE Variance", "AVG_HRLY_RATE_VAR" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRatePercentChange)] = new[] { "AVERAGE HOURLY RATE %CHG", "PCNT_CHG_AVHR_RATE" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.PremiumOtFtes)] = new[] { "Premium FTEs OT FTEs", "TOT_OT_FTES", "OT FTEs" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.PremiumHwsFtes)] = new[] { "Premium FTEs HWS FTEs", "TOT_HWS_CONTR_FTES", "HWS FTEs" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.PremiumVendorFtes)] = new[] { "Premium FTEs VENDOR FTEs", "TOT_VEN_CONTR_FTES", "VENDOR FTEs" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.PremiumContractFtes)] = new[] { "Premium FTEs COUNTER FTEs", "Premium FTEs CONTRACT FTEs", "TOT_CONTR_FTES", "COUNTER FTEs", "CONTRACT FTEs" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.EadcPercentChange)] = new[] { "%CHG EADC", "PCNT_CHG_EADC" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.ProductiveFtesPercentChange)] = new[] { "%CHG PROD FTEs", "PCNT_CHG_PROD_FTES" },
            [nameof(BiWeeklyDivisionStaffingSummaryData.PaidFtesPercentChange)] = new[] { "%CHG PAID FTEs", "PCNT_CHG_PAID_FTES" }
        };

        public static bool HasValidationColumns(string filePath)
        {
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            if (headerRowIndex == -1)
                return false;

            var columnMap = BuildColumnMap(rows, headerRowIndex);
            return columnMap.ContainsKey(nameof(BiWeeklyDivisionStaffingSummaryData.Coid))
                && columnMap.Keys.Any(k => k != nameof(BiWeeklyDivisionStaffingSummaryData.Coid)
                    && k != nameof(BiWeeklyDivisionStaffingSummaryData.FacilityName));
        }

        public static List<BiWeeklyDivisionStaffingSummaryData> ParseBiWeeklyDivisionStaffingSummaryExcel(string filePath)
        {
            var result = new List<BiWeeklyDivisionStaffingSummaryData>();
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);

            if (headerRowIndex == -1)
            {
                Console.WriteLine("Could not find Bi-Weekly Division Staffing Summary header row in the Excel file. Treating Excel report as no data.");
                return result;
            }

            var columnMap = BuildColumnMap(rows, headerRowIndex);
            if (!columnMap.TryGetValue(nameof(BiWeeklyDivisionStaffingSummaryData.Coid), out int coidColumnIndex))
                return result;

            var availableFields = columnMap.Keys
                .Where(k => k != nameof(BiWeeklyDivisionStaffingSummaryData.Coid)
                    && k != nameof(BiWeeklyDivisionStaffingSummaryData.FacilityName)
                    && k != nameof(BiWeeklyDivisionStaffingSummaryData.PayPeriodEndingDate))
                .ToHashSet();

            for (int i = headerRowIndex + 1; i < rows.Count; i++)
            {
                var row = rows[i];
                if (CommonFunctions.IsEmptyRow(row) || IsUiOnlySummaryRow(row))
                    continue;

                string coid = GetString(row, coidColumnIndex);
                if (string.IsNullOrWhiteSpace(coid) || coid.Contains("total", StringComparison.OrdinalIgnoreCase))
                    continue;

                result.Add(new BiWeeklyDivisionStaffingSummaryData
                {
                    Coid = coid,
                    FacilityName = GetString(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.FacilityName)),
                    PayPeriodEndingDate = GetDate(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.PayPeriodEndingDate)),
                    AvgDailyCensus = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.AvgDailyCensus)),
                    EqAvgDailyCensus = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.EqAvgDailyCensus)),
                    OpFactor = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.OpFactor)),
                    EeobBudget = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.EeobBudget)),
                    EeobActual = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.EeobActual)),
                    EeobVariance = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.EeobVariance)),
                    EeobPercentChange = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.EeobPercentChange)),
                    ManhoursAaBudget = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaBudget)),
                    ManhoursAaActual = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaActual)),
                    ManhoursAaVariance = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaVariance)),
                    ManhoursAaPercentChange = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaPercentChange)),
                    AvgHourlyRateBudget = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateBudget)),
                    AvgHourlyRateActual = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateActual)),
                    AvgHourlyRateVariance = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateVariance)),
                    AvgHourlyRatePercentChange = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRatePercentChange)),
                    PremiumOtFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.PremiumOtFtes)),
                    PremiumHwsFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.PremiumHwsFtes)),
                    PremiumVendorFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.PremiumVendorFtes)),
                    PremiumContractFtes = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.PremiumContractFtes)),
                    EadcPercentChange = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.EadcPercentChange)),
                    ProductiveFtesPercentChange = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.ProductiveFtesPercentChange)),
                    PaidFtesPercentChange = GetDecimal(row, columnMap, nameof(BiWeeklyDivisionStaffingSummaryData.PaidFtesPercentChange)),
                    AvailableFields = availableFields
                });
            }

            return result;
        }

        public static BiWeeklyDivisionStaffingSummaryReportCriteria GetReportCriteria(string filePath)
        {
            var rows = ReadRows(filePath);
            string divisionName = FindDivisionName(rows);
            int? divisionNumberFromFileName = FindDivisionNumberFromFileName(filePath);
            var dataRows = ParseBiWeeklyDivisionStaffingSummaryExcel(filePath);
            var payPeriodEndingDate = FindPayPeriodEndingDate(rows)
                ?? dataRows.Select(r => r.PayPeriodEndingDate).FirstOrDefault(d => d != default);

            return new BiWeeklyDivisionStaffingSummaryReportCriteria
            {
                DivisionName = divisionName,
                DivisionNumber = divisionNumberFromFileName ?? GetDivisionNumber(divisionName),
                PayPeriodEndingDate = payPeriodEndingDate == default ? null : payPeriodEndingDate
            };
        }

        private static int FindHeaderRow(List<object[]> rows)
        {
            for (int i = 0; i < rows.Count; i++)
            {
                var current = GetNormalizedCells(rows[i]);
                var previous = i > 0 ? GetNormalizedCells(rows[i - 1]) : new List<string>();
                var combined = current.Concat(previous).ToList();

                bool hasCoid = FieldAliases[nameof(BiWeeklyDivisionStaffingSummaryData.Coid)].Select(NormalizeHeader).Any(combined.Contains);
                bool hasFacility = FieldAliases[nameof(BiWeeklyDivisionStaffingSummaryData.FacilityName)].Select(NormalizeHeader).Any(combined.Contains);
                bool hasMetric = FieldAliases[nameof(BiWeeklyDivisionStaffingSummaryData.AvgDailyCensus)].Select(NormalizeHeader).Any(combined.Contains)
                    || FieldAliases[nameof(BiWeeklyDivisionStaffingSummaryData.EeobBudget)].Select(NormalizeHeader).Any(combined.Contains);

                if (hasCoid && hasFacility && hasMetric)
                    return i;
            }

            return -1;
        }

        private static Dictionary<string, int> BuildColumnMap(List<object[]> rows, int headerRowIndex)
        {
            var result = new Dictionary<string, int>();
            var headerRow = rows[headerRowIndex];
            var groupRow = headerRowIndex > 0 ? rows[headerRowIndex - 1] : Array.Empty<object>();
            int columnCount = Math.Max(headerRow.Length, groupRow.Length);
            var normalizedHeaders = new List<string>();
            string currentGroup = string.Empty;

            for (int i = 0; i < columnCount; i++)
            {
                string groupHeader = GetCellText(groupRow, i);
                string detailHeader = GetCellText(headerRow, i);

                if (!string.IsNullOrWhiteSpace(groupHeader))
                    currentGroup = groupHeader;

                string combinedHeader = string.IsNullOrWhiteSpace(detailHeader) ? currentGroup : $"{currentGroup} {detailHeader}";
                normalizedHeaders.Add(NormalizeHeader(combinedHeader));
            }

            foreach (var field in FieldAliases)
            {
                foreach (string alias in field.Value.Select(NormalizeHeader))
                {
                    int index = normalizedHeaders.FindIndex(h => h == alias || h.EndsWith(alias));
                    if (index >= 0)
                    {
                        result[field.Key] = index;
                        break;
                    }
                }
            }

            return result;
        }

        private static List<object[]> ReadRows(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var allRows = new List<object[]>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                do
                {
                    while (reader.Read())
                    {
                        var row = new object[reader.FieldCount];
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row[i] = reader.GetValue(i);
                        }

                        allRows.Add(row);
                    }
                } while (reader.NextResult());
            }

            return allRows;
        }

        private static string FindDivisionName(List<object[]> rows)
        {
            int headerRowIndex = FindHeaderRow(rows);
            var headerRows = headerRowIndex > 0 ? rows.Take(headerRowIndex) : rows.Take(10);

            foreach (var row in headerRows)
            {
                string rowText = string.Join(" ", row.Where(c => c != null).Select(c => c.ToString()));
                var match = Regex.Match(rowText, @"Division\s*[:\-]?\s*(?<division>.+?DIVISION)", RegexOptions.IgnoreCase);
                if (match.Success)
                    return match.Groups["division"].Value.Trim();
            }

            return string.Empty;
        }

        private static int? FindDivisionNumberFromFileName(string filePath)
        {
            string fileName = Path.GetFileNameWithoutExtension(filePath);
            var match = Regex.Match(fileName, @"(?:^|_)Div_(?<divisionNumber>\d+)(?:_|$)", RegexOptions.IgnoreCase);

            return match.Success && int.TryParse(match.Groups["divisionNumber"].Value, out int divisionNumber)
                ? divisionNumber
                : null;
        }

        private static DateTime? FindPayPeriodEndingDate(List<object[]> rows)
        {
            int headerRowIndex = FindHeaderRow(rows);
            var headerRows = headerRowIndex > 0 ? rows.Take(headerRowIndex) : rows.Take(10);

            foreach (var row in headerRows)
            {
                for (int i = 0; i < row.Length; i++)
                {
                    string cellText = row[i]?.ToString();
                    if (string.IsNullOrWhiteSpace(cellText)
                        || (!cellText.Contains("Pay Period", StringComparison.OrdinalIgnoreCase)
                            && !cellText.Contains("Ending Date", StringComparison.OrdinalIgnoreCase)))
                    {
                        continue;
                    }

                    for (int j = i; j < row.Length; j++)
                    {
                        if (TryGetDate(row[j], out DateTime date))
                            return date;
                    }
                }
            }

            return null;
        }

        private static int GetDivisionNumber(string divisionName)
        {
            if (string.IsNullOrWhiteSpace(divisionName))
                return 7;

            var numberMatch = Regex.Match(divisionName, @"\b\d+\b");
            if (numberMatch.Success && int.TryParse(numberMatch.Value, out int parsedDivision))
                return parsedDivision;

            var divisions = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
            {
                ["TRISTAR DIVISION"] = 7
            };

            string normalizedDivision = Regex.Replace(divisionName, @"\s+", " ").Trim();
            return divisions.TryGetValue(normalizedDivision, out int divisionNumber) ? divisionNumber : 7;
        }

        private static string GetString(object[] row, Dictionary<string, int> columnMap, string fieldName)
        {
            return columnMap.TryGetValue(fieldName, out int index) ? GetString(row, index) : string.Empty;
        }

        private static string GetString(object[] row, int index)
        {
            if (index < 0 || index >= row.Length || row[index] == null)
                return string.Empty;

            return row[index].ToString()?.Trim() ?? string.Empty;
        }

        private static DateTime GetDate(object[] row, Dictionary<string, int> columnMap, string fieldName)
        {
            if (!columnMap.TryGetValue(fieldName, out int index) || index < 0 || index >= row.Length || row[index] == null)
                return default;

            return TryGetDate(row[index], out DateTime date) ? date : default;
        }

        private static bool TryGetDate(object value, out DateTime date)
        {
            date = default;
            if (value == null)
                return false;

            if (value is DateTime dateValue)
            {
                date = dateValue.Date;
                return true;
            }

            if (value is double serialDate && serialDate > 30000 && serialDate < 80000)
            {
                date = DateTime.FromOADate(serialDate).Date;
                return true;
            }

            string text = value.ToString();
            if (string.IsNullOrWhiteSpace(text))
                return false;

            var match = Regex.Match(text, @"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}-\d{1,2}-\d{1,2}\b");
            if (match.Success && DateTime.TryParse(match.Value, out DateTime parsedFromText))
            {
                date = parsedFromText.Date;
                return true;
            }

            if (DateTime.TryParse(text, out DateTime parsed))
            {
                date = parsed.Date;
                return true;
            }

            return false;
        }

        private static decimal GetDecimal(object[] row, Dictionary<string, int> columnMap, string fieldName)
        {
            if (!columnMap.TryGetValue(fieldName, out int index) || index < 0 || index >= row.Length || row[index] == null)
                return 0m;

            var value = row[index];
            if (value is decimal dec) return dec;
            if (value is double d) return (decimal)d;
            if (value is float f) return (decimal)f;
            if (value is int i) return i;
            if (value is long l) return l;

            string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(text))
                return 0m;

            bool isNegative = text.StartsWith("(") && text.EndsWith(")");
            if (isNegative)
                text = text.Trim('(', ')');

            return decimal.TryParse(text, out decimal parsed) ? (isNegative ? -parsed : parsed) : 0m;
        }

        private static bool IsUiOnlySummaryRow(object[] row)
        {
            string rowText = string.Join(" ", row.Where(c => c != null).Select(c => c.ToString()));
            return rowText.Contains("total", StringComparison.OrdinalIgnoreCase)
                || rowText.Contains("average", StringComparison.OrdinalIgnoreCase);
        }

        private static List<string> GetNormalizedCells(object[] row)
        {
            return row.Where(c => c != null).Select(c => NormalizeHeader(c.ToString())).ToList();
        }

        private static string GetCellText(object[] row, int index)
        {
            if (index < 0 || index >= row.Length || row[index] == null)
                return string.Empty;

            return row[index].ToString()?.Trim() ?? string.Empty;
        }

        private static string NormalizeHeader(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            return Regex.Replace(value, @"[^A-Za-z0-9]", string.Empty).ToUpperInvariant();
        }
    }
}
