using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    internal class BiWeeklyDivisionStaffingSummaryReport
    {
        public static void GoTo()
        {
            FpcReportMenu.BiWeeklyReports.SelectBiWeeklyDivisionStaffingSummaryReport();
            CommonFunctions.AddTestStep("Select Bi-Weekly Division Staffing Summary Report", "The Bi-Weekly Division Staffing Summary Report is displayed");
        }

        public static bool IsAt
        {
            get
            {
                CommonFunctions.WaitUntilPageIsAcive();
                By byExcel = By.XPath("//img[@title='Excel Format']");
                CommonFunctions.AddTestStep("Verify the Bi-Weekly Division Staffing Summary Report page is active", "The Bi-Weekly Division Staffing Summary Report page loaded correctly.");
                return CommonFunctions.IsElementDisplayed(byExcel, 40);
            }
        }

        public static BiWeeklyDivisionStaffingSummaryCommand BiWeeklyDivisionStaffingSummary()
        {
            return new BiWeeklyDivisionStaffingSummaryCommand();
        }
    }

    public class BiWeeklyDivisionStaffingSummaryCommand
    {
        public void Excel()
        {
            By byExcel = By.XPath("//img[@title='Excel Format']");
            IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
            CommonFunctions.Click(cmdExcel);
            CommonFunctions.AddTestStep("Verify a user can click the Excel button", "The Excel button is enabled and clickable");
        }
    }
}
