using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyDivisionStaffingSummaryValidator
    {
        public static void Validate(List<BiWeeklyDivisionStaffingSummaryData> excelData, List<BiWeeklyDivisionStaffingSummaryData> dbData)
        {
            Console.WriteLine("=== Bi-Weekly Division Staffing Summary Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                return;
            }

            var mismatches = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;
            int skippedRows = 0;
            int skippedFields = 0;

            foreach (var excelRow in excelData)
            {
                var dbRow = dbData.FirstOrDefault(d => IsSameRow(excelRow, d));
                if (dbRow == null)
                {
                    skippedRows++;
                    continue;
                }

                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.AvgDailyCensus), "AVG_DLY_CENSUS", "ADC", excelRow.AvgDailyCensus, dbRow.AvgDailyCensus);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.EqAvgDailyCensus), "EQ_AVG_DLY_CENSUS", "EADC", excelRow.EqAvgDailyCensus, dbRow.EqAvgDailyCensus);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.OpFactor), "OP_FACTOR", "OP Factor", excelRow.OpFactor, dbRow.OpFactor);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.EeobBudget), "EEOB_BDGT", "EEOB BUDGET", excelRow.EeobBudget, dbRow.EeobBudget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.EeobActual), "EEOB_ACTUAL", "EEOB Actual", excelRow.EeobActual, dbRow.EeobActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.EeobVariance), "EEOB_VAR", "EEOB Variance", excelRow.EeobVariance, dbRow.EeobVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.EeobPercentChange), "PCNT_CHG_EEOB", "EEOB %CHG", excelRow.EeobPercentChange, dbRow.EeobPercentChange);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaBudget), "MANHOURS_AA_BDGT", "MANHOURS/AA BUDGET", excelRow.ManhoursAaBudget, dbRow.ManhoursAaBudget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaActual), "MANHOURS_AA_ACTUAL", "MANHOURS/AA Actual", excelRow.ManhoursAaActual, dbRow.ManhoursAaActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaVariance), "MANHOURS_AA_VAR", "MANHOURS/AA Variance", excelRow.ManhoursAaVariance, dbRow.ManhoursAaVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.ManhoursAaPercentChange), "PCNT_CHG_MH_AA", "ManHours/AA %CHG", excelRow.ManhoursAaPercentChange, dbRow.ManhoursAaPercentChange);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateBudget), "AVG_HRLY_RATE_BDGT", "AVERAGE HOURLY RATE BUDGET", excelRow.AvgHourlyRateBudget, dbRow.AvgHourlyRateBudget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateActual), "AVG_HRLY_RATE_ACT", "AVERAGE HOURLY RATE Actual", excelRow.AvgHourlyRateActual, dbRow.AvgHourlyRateActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRateVariance), "AVG_HRLY_RATE_VAR", "AVERAGE HOURLY RATE Variance", excelRow.AvgHourlyRateVariance, dbRow.AvgHourlyRateVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.AvgHourlyRatePercentChange), "PCNT_CHG_AVHR_RATE", "AVERAGE HOURLY RATE %CHG", excelRow.AvgHourlyRatePercentChange, dbRow.AvgHourlyRatePercentChange);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.PremiumOtFtes), "TOT_OT_FTES", "Premium FTEs OT FTEs", excelRow.PremiumOtFtes, dbRow.PremiumOtFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.PremiumHwsFtes), "TOT_HWS_CONTR_FTES", "Premium FTEs HWS FTEs", excelRow.PremiumHwsFtes, dbRow.PremiumHwsFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.PremiumVendorFtes), "TOT_VEN_CONTR_FTES", "Premium FTEs VENDOR FTEs", excelRow.PremiumVendorFtes, dbRow.PremiumVendorFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.PremiumContractFtes), "TOT_CONTR_FTES", "Premium FTEs COUNTER FTEs", excelRow.PremiumContractFtes, dbRow.PremiumContractFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.EadcPercentChange), "PCNT_CHG_EADC", "%CHG EADC", excelRow.EadcPercentChange, dbRow.EadcPercentChange);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.ProductiveFtesPercentChange), "PCNT_CHG_PROD_FTES", "%CHG PROD FTEs", excelRow.ProductiveFtesPercentChange, dbRow.ProductiveFtesPercentChange);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyDivisionStaffingSummaryData.PaidFtesPercentChange), "PCNT_CHG_PAID_FTES", "%CHG PAID FTEs", excelRow.PaidFtesPercentChange, dbRow.PaidFtesPercentChange);
            }

            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine("Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");
            Console.WriteLine($"  Skipped Excel rows not present in DB: {skippedRows}");
            Console.WriteLine($"  Skipped fields not present in Excel: {skippedFields}");

            if (totalComparisons == 0)
            {
                Console.WriteLine("No matching Excel columns were available for validation. Validation skipped.");
                return;
            }

            if (mismatches.Count > 0)
            {
                Console.WriteLine("\nMismatches:");
                Console.WriteLine($"{"COID",-8} {"DB Column",-24} {"Excel Column",-32} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 95));

                foreach (var mismatch in mismatches)
                {
                    Console.WriteLine(mismatch);
                }

                Assert.Fail($"Bi-Weekly Division Staffing Summary validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons.");
            }

            Console.WriteLine("\nBi-Weekly Division Staffing Summary validated successfully - all values match.");
        }

        private static void CompareField(
            List<string> mismatches,
            ref int totalComparisons,
            ref int matchCount,
            ref int skippedFields,
            BiWeeklyDivisionStaffingSummaryData excelRow,
            string fieldName,
            string dbColumnName,
            string excelColumnName,
            decimal excelValue,
            decimal dbValue)
        {
            if (excelRow.AvailableFields.Any() && !excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            decimal roundedExcelValue = Math.Round(excelValue, 1, MidpointRounding.AwayFromZero);
            decimal roundedDbValue = Math.Round(dbValue, 1, MidpointRounding.AwayFromZero);

            if (roundedExcelValue == roundedDbValue)
            {
                matchCount++;
                return;
            }

            mismatches.Add($"{excelRow.Coid,-8} {dbColumnName,-24} {excelColumnName,-32} {roundedExcelValue,12:N1} {roundedDbValue,12:N1}");
        }

        private static bool IsSameRow(BiWeeklyDivisionStaffingSummaryData excelRow, BiWeeklyDivisionStaffingSummaryData dbRow)
        {
            return string.Equals(NormalizeCoid(excelRow.Coid), NormalizeCoid(dbRow.Coid), StringComparison.OrdinalIgnoreCase);
        }

        private static string NormalizeCoid(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            string digits = new string(value.Where(char.IsDigit).ToArray());
            if (!string.IsNullOrWhiteSpace(digits))
                return digits.TrimStart('0');

            return value.Trim().ToUpperInvariant();
        }
    }
}
