using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyFpcFacilityLaborUtilizTrendValidator
    {
        public static void Validate(List<BiWeeklyFpcFacilityLaborUtilizTrendData> excelData, List<BiWeeklyFpcFacilityLaborUtilizTrendData> dbData)
        {
            Console.WriteLine("=== Bi-Weekly FPC Facility Labor Utilization Trend Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                return;
            }

            var mismatches = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;
            int skippedRows = 0;
            int skippedFields = 0;

            foreach (var dbRow in dbData)
            {
                var excelRow = excelData.FirstOrDefault(e => e.PayPeriodEndingDate.Date == dbRow.PayPeriodEndingDate.Date);
                if (excelRow == null)
                {
                    skippedRows++;
                    continue;
                }

                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ADC), "ADC", "ADC", excelRow.ADC, dbRow.ADC);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.EADC), "EADC", "EADC", excelRow.EADC, dbRow.EADC);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.Admissions), "ADMISSIONS", "ADM", excelRow.Admissions, dbRow.Admissions);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesTarget), "PROD_FTES_TGT", "Productive FTEs Target", excelRow.ProductiveFtesTarget, dbRow.ProductiveFtesTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesActual), "PROD_FTES_ACT", "Productive FTEs Actual", excelRow.ProductiveFtesActual, dbRow.ProductiveFtesActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesVariance), "PROD_FTES_VAR", "Productive FTEs Variance", excelRow.ProductiveFtesVariance, dbRow.ProductiveFtesVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesTarget), "PAID_FTES_TGT", "Paid FTEs Target", excelRow.PaidFtesTarget, dbRow.PaidFtesTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesActual), "PAID_FTES_ACT", "Paid FTEs Actual", excelRow.PaidFtesActual, dbRow.PaidFtesActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesVariance), "PAID_FTES_VAR", "Paid FTEs Variance", excelRow.PaidFtesVariance, dbRow.PaidFtesVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobTarget), "PAID_EEOB_TGT", "Paid EEOB Target", excelRow.PaidEeobTarget, dbRow.PaidEeobTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobActual), "PAID_EEOB_ACT", "Paid EEOB Actual", excelRow.PaidEeobActual, dbRow.PaidEeobActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobVariance), "PAID_EEOB_VAR", "Paid EEOB Variance", excelRow.PaidEeobVariance, dbRow.PaidEeobVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaTarget), "PAID_MHAA_TGT", "Paid ManHours/AA Target", excelRow.PaidMhaaTarget, dbRow.PaidMhaaTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaActual), "PAID_MHAA_ACT", "Paid ManHours/AA Actual", excelRow.PaidMhaaActual, dbRow.PaidMhaaActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaVariance), "PAID_MHAA_VAR", "Paid ManHours/AA Variance", excelRow.PaidMhaaVariance, dbRow.PaidMhaaVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.OvertimeFtes), "OT_FTES_ACT", "Overtime FTEs", excelRow.OvertimeFtes, dbRow.OvertimeFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.OvertimePercent), "OT_PCT_ACT", "Overtime %", excelRow.OvertimePercent, dbRow.OvertimePercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PRNFtes), "PRN_FTE", "PRN FTEs", excelRow.PRNFtes, dbRow.PRNFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PRNPercent), "PRN_FTE_PCT", "PRN %", excelRow.PRNPercent, dbRow.PRNPercent);
            }

            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine("Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");
            Console.WriteLine($"  Skipped DB rows not present in Excel: {skippedRows}");
            Console.WriteLine($"  Skipped fields not present in Excel: {skippedFields}");

            if (totalComparisons == 0)
            {
                Console.WriteLine("No matching Excel columns were available for validation. Validation skipped.");
                return;
            }

            if (mismatches.Count > 0)
            {
                Console.WriteLine("\nMismatches:");
                Console.WriteLine($"{"Pay Period",-12} {"DB Column",-18} {"Excel Column",-30} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 90));

                foreach (var mismatch in mismatches)
                {
                    Console.WriteLine(mismatch);
                }

                Assert.Fail($"Bi-Weekly FPC Facility Labor Utilization Trend validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons.");
            }

            Console.WriteLine("\nBi-Weekly FPC Facility Labor Utilization Trend validated successfully - all values match.");
        }

        private static void CompareField(
            List<string> mismatches,
            ref int totalComparisons,
            ref int matchCount,
            ref int skippedFields,
            BiWeeklyFpcFacilityLaborUtilizTrendData excelRow,
            string fieldName,
            string dbColumnName,
            string excelColumnName,
            decimal excelValue,
            decimal dbValue)
        {
            if (excelRow.AvailableFields.Any() && !excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            decimal roundedExcelValue = Math.Round(excelValue, 1, MidpointRounding.AwayFromZero);
            decimal roundedDbValue = Math.Round(dbValue, 1, MidpointRounding.AwayFromZero);

            if (roundedExcelValue == roundedDbValue)
            {
                matchCount++;
                return;
            }

            mismatches.Add($"{excelRow.PayPeriodEndingDate:yyyy-MM-dd} {dbColumnName,-18} {excelColumnName,-30} {roundedExcelValue,12:N1} {roundedDbValue,12:N1}");
        }
    }
}
