using System;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyFpcFacilityLaborUtilizTrendSP
    {
        public static string GetBiWeeklyFpcFacilityLaborUtilizTrendQuery(int year, DateTime activityStartDate, DateTime activityEndDate)
        {
            int unitNumber = GetUnitNumber();
            string startDateText = activityStartDate.ToString("yyyy-MM-dd");
            string endDateText = activityEndDate.ToString("yyyy-MM-dd");

            return $@"WITH PARAMS AS
(
    SELECT {unitNumber} AS UNIT_NUM,
           0 AS IS_FACILITY_WED_PP_END_DATE
    FROM SYSIBM.SYSDUMMY1
),
PROCESS_RANGE AS
(
    SELECT PPF.UNIT_NUM,
           MIN(PPF.PP_END_DATE) AS PROCESS_START_DATE,
           MAX(PPF.PP_END_DATE) AS PROCESS_END_DATE
    FROM H.LPBPPF PPF
    JOIN PARAMS P ON PPF.UNIT_NUM = P.UNIT_NUM
    WHERE PPF.PPE_DATE BETWEEN DATE('{startDateText}') AND DATE('{endDateText}')
    GROUP BY PPF.UNIT_NUM
)
SELECT CASE WHEN P.IS_FACILITY_WED_PP_END_DATE = 1 THEN (PPF.PP_END_DATE - 3 DAYS) ELSE PPF.PP_END_DATE END AS PP_END_DATE,
       PPF.AVG_DLY_CENSUS AS ADC,
       ROUND(PPF.EADC, 0) AS EADC,
       ROUND(PPF.ADMISSIONS, 0) AS ADMISSIONS,
       ROUND(PPF.TGT_PROD_FTES, 2) AS PROD_FTES_TGT,
       ROUND(PPF.TOT_PROD_FTES, 2) AS PROD_FTES_ACT,
       (ROUND(PPF.TGT_PROD_FTES, 2) - ROUND(PPF.TOT_PROD_FTES, 2)) AS PROD_FTES_VAR,
       ROUND(PPF.TGT_PAID_FTES, 2) AS PAID_FTES_TGT,
       ROUND(PPF.TOT_PAID_FTES, 2) AS PAID_FTES_ACT,
       (ROUND(PPF.TGT_PAID_FTES, 2) - ROUND(PPF.TOT_PAID_FTES, 2)) AS PAID_FTES_VAR,
       PPF.TGT_PAID_EEOB AS PAID_EEOB_TGT,
       PPF.PAID_EEOB AS PAID_EEOB_ACT,
       (PPF.TGT_PAID_EEOB - PPF.PAID_EEOB) AS PAID_EEOB_VAR,
       ROUND(PPF.TGT_PAID_MHAA, 0) AS PAID_MHAA_TGT,
       ROUND(PPF.PAID_MHAA, 0) AS PAID_MHAA_ACT,
       (ROUND(PPF.TGT_PAID_MHAA, 0) - ROUND(PPF.PAID_MHAA, 0)) AS PAID_MHAA_VAR,
       ROUND(PPF.TOT_OT_FTES, 2) AS OT_FTES_ACT,
       ROUND(CASE WHEN PPF.TOT_PROD_HRS = 0 THEN 0
                  WHEN ((ROUND(PPF.TOT_OT_HRS, 2) / ROUND(PPF.TOT_PROD_HRS, 2)) * 100) >= 999.99 THEN 999.99
                  WHEN ((ROUND(PPF.TOT_OT_HRS, 2) / ROUND(PPF.TOT_PROD_HRS, 2)) * 100) <= -999.99 THEN -999.99
                  ELSE ((ROUND(PPF.TOT_OT_HRS, 2) / ROUND(PPF.TOT_PROD_HRS, 2)) * 100)
             END, 2) AS OT_PCT_ACT,
       (SELECT DEC(ROUND(SUM(COALESCE(DDA.ACT_PRODHRS_PRN, 0) + COALESCE(DDA.ACT_OT_PRN, 0)) / 80, 2), 5, 2)
        FROM H.LPBDDAA DDA
        WHERE DDA.UNIT_NUM = PPF.UNIT_NUM
          AND DDA.ACTIVITY_DATE BETWEEN
              (CASE WHEN P.IS_FACILITY_WED_PP_END_DATE = 1 THEN ((PPF.PP_END_DATE - 3 DAYS) - 13 DAYS) ELSE (PPF.PP_END_DATE - 13 DAYS) END)
              AND (CASE WHEN P.IS_FACILITY_WED_PP_END_DATE = 1 THEN (PPF.PP_END_DATE - 3 DAYS) ELSE PPF.PP_END_DATE END)
       ) AS PRN_FTE,
       (SELECT DEC(ROUND(CASE WHEN ROUND(PPF.TOT_PROD_FTES, 2) = 0 THEN 0
                              WHEN ((ROUND(SUM(COALESCE(DDA.ACT_PRODHRS_PRN, 0) + COALESCE(DDA.ACT_OT_PRN, 0)) / 80, 2) / (PPF.TOT_PROD_FTES)) * 100) >= 999.99 THEN 999.99
                              WHEN ((ROUND((SUM(COALESCE(DDA.ACT_PRODHRS_PRN, 0) + COALESCE(DDA.ACT_OT_PRN, 0)) / 80), 2) / (PPF.TOT_PROD_FTES)) * 100) <= -999.99 THEN -999.99
                              ELSE ((ROUND((SUM(COALESCE(DDA.ACT_PRODHRS_PRN, 0) + COALESCE(DDA.ACT_OT_PRN, 0)) / 80), 2) / (PPF.TOT_PROD_FTES)) * 100)
                         END, 2), 5, 2)
        FROM H.LPBDDAA DDA
        WHERE DDA.UNIT_NUM = PPF.UNIT_NUM
          AND DDA.ACTIVITY_DATE BETWEEN
              (CASE WHEN P.IS_FACILITY_WED_PP_END_DATE = 1 THEN ((PPF.PP_END_DATE - 3 DAYS) - 13 DAYS) ELSE (PPF.PP_END_DATE - 13 DAYS) END)
              AND (CASE WHEN P.IS_FACILITY_WED_PP_END_DATE = 1 THEN (PPF.PP_END_DATE - 3 DAYS) ELSE PPF.PP_END_DATE END)
       ) AS PRN_FTE_PCT
FROM H.LPBPPF PPF
JOIN PARAMS P ON PPF.UNIT_NUM = P.UNIT_NUM
LEFT JOIN PROCESS_RANGE PR ON PPF.UNIT_NUM = PR.UNIT_NUM
WHERE PPF.UNIT_NUM = P.UNIT_NUM
  AND PPF.PP_END_DATE BETWEEN COALESCE(PR.PROCESS_START_DATE, DATE('1900-01-01')) AND COALESCE(PR.PROCESS_END_DATE, DATE('1900-01-01'))
  AND YEAR(CASE WHEN P.IS_FACILITY_WED_PP_END_DATE = 1 THEN (PPF.PP_END_DATE - 3 DAYS) ELSE PPF.PP_END_DATE END) = {year}
ORDER BY PPF.PP_END_DATE";
        }

        private static int GetUnitNumber()
        {
            string facility = RunData.Facility;
            if (!string.IsNullOrWhiteSpace(facility))
            {
                string digits = new string(facility.Where(char.IsDigit).ToArray());
                if (int.TryParse(digits, out int unitNumber))
                    return unitNumber;
            }

            return 1406;
        }
    }
}
