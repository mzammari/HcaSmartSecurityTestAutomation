using System;
using System.Collections.Generic;
using System.Data;
using IBM.Data.Db2;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Loads BiWeekly FPC Staffing Summary data from DB2 database.
    /// Uses inline query with @PayPeriod parameter.
    /// </summary>
    public static class BiWeeklyFpcStaffingSummaryDBLoader
    {
        /// <summary>
        /// Execute the inline query and return parsed DB data.
        /// </summary>
        /// <param name="payPeriod">Pay period value (e.g., "2024-01-14")</param>
        public static List<BiWeeklyFpcStaffingSummaryData> LoadFromDatabase(string payPeriod)
        {
            var result = new List<BiWeeklyFpcStaffingSummaryData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = BiWeeklyFpcStaffingSummarySP.GetBiWeeklyFpcStaffingSummaryQuery(payPeriod);

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var row = new BiWeeklyFpcStaffingSummaryData
                            {
                                DeptGroupNum = GetString(reader, "DeptGroupNum", "DEPT_OR_GROUP_NUM"),
                                DepartmentGroupName = GetString(reader, "DepartmentGroupName", "DEPT_OR_GROUP_DESC"),
                                StatisticDescription = GetString(reader, "StatisticDescription", "STAT_DESC"),
                                PaidIdxTargetActualFtesPercent = GetDecimal(reader, "PaidIdxTargetActualFtesPercent", "PAID_IDX_PCT"),
                                UOSActual = GetDecimal(reader, "UOSActual", "UOS_ACT"),
                                TargetProdHoursUOS = GetDecimal(reader, "TargetProdHoursUOS", "PROD_HRS_UOS_TGT"),
                                ActualProdHoursUOS = GetDecimal(reader, "ActualProdHoursUOS", "PROD_HRS_UOS_ACT"),
                                ActualNonProdPercent = GetDecimal(reader, "ActualNonProdPercent", "NON_PROD_PCT_ACT"),
                                ProductiveFtesTarget = GetDecimal(reader, "ProductiveFtesTarget", "PROD_FTES_TGT"),
                                ProductiveFtesActual = GetDecimal(reader, "ProductiveFtesActual", "PROD_FTES_ACT"),
                                ProductiveFtesVariance = GetDecimal(reader, "ProductiveFtesVariance", "PROD_FTES_VAR"),
                                PaidFtesTarget = GetDecimal(reader, "PaidFtesTarget", "PAID_FTES_TGT"),
                                PaidFtesActual = GetDecimal(reader, "PaidFtesActual", "PAID_FTES_ACT"),
                                PaidFtesVariance = GetDecimal(reader, "PaidFtesVariance", "PAID_FTES_VAR"),
                                OvertimeFtes = GetDecimal(reader, "OvertimeFtes", "OT_FTES_ACT"),
                                OvertimePercent = GetDecimal(reader, "OvertimePercent", "OT_PCT_ACT"),
                                OvertimeTargetPercent = GetDecimal(reader, "OvertimeTargetPercent", "OT_PCT_TGT"),
                                ContractFtes = GetDecimal(reader, "ContractFtes", "CONTR_FTES_ACT"),
                                ContractPercent = GetDecimal(reader, "ContractPercent", "CONTR_PCT_ACT"),
                                ContractTargetPercent = GetDecimal(reader, "ContractTargetPercent", "CONTR_PCT_TGT"),
                                PRNFtes = GetDecimal(reader, "PRNFtes", "PRN_FTE"),
                                PRNPercent = GetDecimal(reader, "PRNPercent", "PRN_FTE_PCT"),
                            };

                            result.Add(row);
                        }
                    }
                }
            }

            return result;
        }

        private static string GetString(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    return reader.IsDBNull(ordinal) ? string.Empty : reader.GetValue(ordinal).ToString().Trim();
                }
catch (IndexOutOfRangeException)
{
}
            }

            return string.Empty;
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;

                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;

                    if (decimal.TryParse(value.ToString(), out decimal parsed))
                        return parsed;

                    return 0m;
                }
                catch
                {
                }
            }

            return 0m;
        }
    }
}
