﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentFormat.OpenXml.Bibliography;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    internal class BiWeeklyFpcStaffingSummary
    {
        public static void GoTo()
        {
            FpcReportMenu.BiWeeklyReports.SelectBiWeeklyStaffingSummaryReport();
            CommonFunctions.AddTestStep("Select Bi-Weekly Department Labor Utilization Report ", "The Bi-Weekly Department Labor Utilization Report is displayed");
        }

        public static bool IsAt
        {
            get
            {
                CommonFunctions.WaitUntilPageIsAcive();
                By byYearDropdown = By.XPath("//select[@id='monthOrYear']");
                CommonFunctions.AddTestStep("Verify the Bi-Weekly Department Labor Utilization Report page is active", "The Bi-Weekly Department Labor Utilization Report page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byYearDropdown, 40);
            }
        }

        #region: BiWeeklyFpcStaffingSummaryCommand
        public static BiWeeklyFpcStaffingSummaryCommand BiWeeklyFpcStaffingSummaryReport()
        {
            return new BiWeeklyFpcStaffingSummaryCommand();
        } 
    }

        public class BiWeeklyFpcStaffingSummaryCommand
        {
            private string payPeriod;
       
            public BiWeeklyFpcStaffingSummaryCommand withPayPeriod(string payPeriod)
            {
                this.payPeriod = payPeriod;
                return this;
            }


            public void setPayPeriod()
            {
                By byYear = By.Id("monthOrYear");
                IWebElement mnuYear = CommonFunctions.getElement(byYear);
                mnuYear.Click();
                CommonFunctions.AddTestStep($"Verify a user can select {payPeriod} from Report year dropdown", $"The {payPeriod} is selected correctly");

            }

        private void clickExcel()
        {
            By byExcel = By.XPath("//img[@title='Excel Format']");
            IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
            CommonFunctions.Click(cmdExcel);
            CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
        }

        public void Excel()
        {
            setPayPeriod();
            clickExcel();
        }

    }
    #endregion

}

