using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    public class BiWeeklyFpcFacilityLaborUtilizTrendData
    {
        public DateTime PayPeriodEndingDate { get; set; }
        public decimal ADC { get; set; }
        public decimal EADC { get; set; }
        public decimal Admissions { get; set; }
        public decimal ProductiveFtesTarget { get; set; }
        public decimal ProductiveFtesActual { get; set; }
        public decimal ProductiveFtesVariance { get; set; }
        public decimal PaidFtesTarget { get; set; }
        public decimal PaidFtesActual { get; set; }
        public decimal PaidFtesVariance { get; set; }
        public decimal PaidEeobTarget { get; set; }
        public decimal PaidEeobActual { get; set; }
        public decimal PaidEeobVariance { get; set; }
        public decimal PaidMhaaTarget { get; set; }
        public decimal PaidMhaaActual { get; set; }
        public decimal PaidMhaaVariance { get; set; }
        public decimal OvertimeFtes { get; set; }
        public decimal OvertimePercent { get; set; }
        public decimal PRNFtes { get; set; }
        public decimal PRNPercent { get; set; }
        public HashSet<string> AvailableFields { get; set; } = new HashSet<string>();
    }

    public class BiWeeklyFpcFacilityLaborUtilizTrendReportCriteria
    {
        public int Year { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public static class BiWeeklyFpcFacilityLaborUtilizTrendExcelReport
    {
        private static readonly Dictionary<string, string[]> FieldAliases = new Dictionary<string, string[]>
        {
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PayPeriodEndingDate)] = new[] { "Pay Period Ending Date", "PP_END_DATE", "PPE Date", "PP End Date" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ADC)] = new[] { "ADC" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.EADC)] = new[] { "EADC" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.Admissions)] = new[] { "ADM", "Admissions" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesTarget)] = new[] { "Productive FTEs Target", "PROD_FTES_TGT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesActual)] = new[] { "Productive FTEs Actual", "PROD_FTES_ACT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesVariance)] = new[] { "Productive FTEs Variance", "PROD_FTES_VAR" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesTarget)] = new[] { "Paid FTEs Target", "PAID_FTES_TGT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesActual)] = new[] { "Paid FTEs Actual", "PAID_FTES_ACT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesVariance)] = new[] { "Paid FTEs Variance", "PAID_FTES_VAR" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobTarget)] = new[] { "Paid EEOB Target", "PAID_EEOB_TGT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobActual)] = new[] { "Paid EEOB Actual", "PAID_EEOB_ACT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobVariance)] = new[] { "Paid EEOB Variance", "PAID_EEOB_VAR" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaTarget)] = new[] { "Paid ManHours/AA Target", "PAID_MHAA_TGT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaActual)] = new[] { "Paid ManHours/AA Actual", "PAID_MHAA_ACT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaVariance)] = new[] { "Paid ManHours/AA Variance", "PAID_MHAA_VAR" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.OvertimeFtes)] = new[] { "Overtime FTEs", "OT_FTES_ACT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.OvertimePercent)] = new[] { "Overtime %", "OT_PCT_ACT" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PRNFtes)] = new[] { "PRN FTEs", "PRN FTE", "PRN_FTE" },
            [nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PRNPercent)] = new[] { "PRN %", "PRN_FTE_PCT" }
        };

        public static bool HasValidationColumns(string filePath)
        {
            var allRows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(allRows);
            if (headerRowIndex == -1)
                return false;

            var columnMap = BuildColumnMap(allRows, headerRowIndex);
            return columnMap.ContainsKey(nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PayPeriodEndingDate))
                && columnMap.Keys.Any(k => k != nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PayPeriodEndingDate));
        }

        public static List<BiWeeklyFpcFacilityLaborUtilizTrendData> ParseBiWeeklyFpcFacilityLaborUtilizTrendExcel(string filePath)
        {
            var result = new List<BiWeeklyFpcFacilityLaborUtilizTrendData>();
            var allRows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(allRows);

            if (headerRowIndex == -1)
            {
                Console.WriteLine("Could not find Bi-Weekly FPC Facility Labor Utilization Trend header row in the Excel file. Treating Excel report as no data.");
                return result;
            }

            var columnMap = BuildColumnMap(allRows, headerRowIndex);
            if (!columnMap.TryGetValue(nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PayPeriodEndingDate), out int dateColumnIndex))
                return result;

            var availableFields = columnMap.Keys.Where(k => k != nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PayPeriodEndingDate)).ToHashSet();

            for (int i = headerRowIndex + 1; i < allRows.Count; i++)
            {
                var row = allRows[i];
                if (CommonFunctions.IsEmptyRow(row))
                    continue;

                if (IsUiOnlySummaryRow(row))
                    continue;

                string firstCell = CommonFunctions.GetStringValue(row, 0);
                if (firstCell.Contains("total", StringComparison.OrdinalIgnoreCase))
                    continue;

                if (!TryGetDate(row, dateColumnIndex, out DateTime payPeriodEndingDate))
                    continue;

                result.Add(new BiWeeklyFpcFacilityLaborUtilizTrendData
                {
                    PayPeriodEndingDate = payPeriodEndingDate,
                    ADC = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ADC)),
                    EADC = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.EADC)),
                    Admissions = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.Admissions)),
                    ProductiveFtesTarget = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesTarget)),
                    ProductiveFtesActual = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesActual)),
                    ProductiveFtesVariance = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ProductiveFtesVariance)),
                    PaidFtesTarget = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesTarget)),
                    PaidFtesActual = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesActual)),
                    PaidFtesVariance = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidFtesVariance)),
                    PaidEeobTarget = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobTarget)),
                    PaidEeobActual = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobActual)),
                    PaidEeobVariance = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidEeobVariance)),
                    PaidMhaaTarget = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaTarget)),
                    PaidMhaaActual = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaActual)),
                    PaidMhaaVariance = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PaidMhaaVariance)),
                    OvertimeFtes = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.OvertimeFtes)),
                    OvertimePercent = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.OvertimePercent)),
                    PRNFtes = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PRNFtes)),
                    PRNPercent = GetDecimal(row, columnMap, nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PRNPercent)),
                    AvailableFields = availableFields
                });
            }

            return result;
        }

        public static BiWeeklyFpcFacilityLaborUtilizTrendReportCriteria GetReportCriteria(string filePath, int fallbackYear)
        {
            var rows = ParseBiWeeklyFpcFacilityLaborUtilizTrendExcel(filePath);
            if (!rows.Any())
                throw new InvalidOperationException("Could not find pay period ending dates in the Bi-Weekly FPC Facility Labor Utilization Trend Excel file.");

            var dates = rows.Select(r => r.PayPeriodEndingDate.Date).Distinct().OrderBy(d => d).ToList();
            return new BiWeeklyFpcFacilityLaborUtilizTrendReportCriteria
            {
                Year = FindReportYear(filePath) ?? dates.Last().Year,
                StartDate = dates.First(),
                EndDate = dates.Last()
            };
        }

        private static decimal GetDecimal(object[] row, Dictionary<string, int> columnMap, string fieldName)
        {
            return columnMap.TryGetValue(fieldName, out int index) ? GetDecimalValue(row, index) : 0m;
        }

        private static decimal GetDecimalValue(object[] row, int index)
        {
            if (index < 0 || index >= row.Length || row[index] == null)
                return 0m;

            var value = row[index];
            if (value is decimal dec) return dec;
            if (value is double d) return (decimal)d;
            if (value is float f) return (decimal)f;
            if (value is int i) return i;
            if (value is long l) return l;

            string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(text))
                return 0m;

            bool isNegative = text.StartsWith("(") && text.EndsWith(")");
            if (isNegative)
                text = text.Trim('(', ')');

            return decimal.TryParse(text, out decimal parsed) ? (isNegative ? -parsed : parsed) : 0m;
        }

        private static bool IsUiOnlySummaryRow(object[] row)
        {
            string rowText = string.Join(" ", row.Where(c => c != null).Select(c => c.ToString()));

            return rowText.Contains("YTD Totals", StringComparison.OrdinalIgnoreCase)
                || rowText.Contains("AVG/PP (YTD)", StringComparison.OrdinalIgnoreCase)
                || rowText.Contains("AVG/PP (4 PPs)", StringComparison.OrdinalIgnoreCase);
        }

        private static int FindHeaderRow(List<object[]> rows)
        {
            for (int i = 0; i < rows.Count; i++)
            {
                var normalizedCells = rows[i]
                    .Where(c => c != null)
                    .Select(c => NormalizeHeader(c.ToString()))
                    .ToList();

                bool hasDate = FieldAliases[nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.PayPeriodEndingDate)]
                    .Select(NormalizeHeader)
                    .Any(alias => normalizedCells.Contains(alias))
                    || normalizedCells.Contains(NormalizeHeader("Ending Date"));

                bool hasMetric = FieldAliases[nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ADC)]
                    .Select(NormalizeHeader)
                    .Any(alias => normalizedCells.Contains(alias));

                if (!hasMetric && i > 0)
                {
                    var previousRowCells = rows[i - 1]
                        .Where(c => c != null)
                        .Select(c => NormalizeHeader(c.ToString()))
                        .ToList();

                    hasMetric = FieldAliases[nameof(BiWeeklyFpcFacilityLaborUtilizTrendData.ADC)]
                        .Select(NormalizeHeader)
                        .Any(alias => previousRowCells.Contains(alias));
                }

                if (hasDate && hasMetric)
                    return i;
            }

            return -1;
        }

        private static Dictionary<string, int> BuildColumnMap(List<object[]> rows, int headerRowIndex)
        {
            var result = new Dictionary<string, int>();
            var headerRow = rows[headerRowIndex];
            var groupRow = headerRowIndex > 0 ? rows[headerRowIndex - 1] : Array.Empty<object>();
            int columnCount = Math.Max(headerRow.Length, groupRow.Length);
            var normalizedHeaders = new List<string>();
            string currentGroup = string.Empty;

            for (int i = 0; i < columnCount; i++)
            {
                string groupHeader = GetCellText(groupRow, i);
                string detailHeader = GetCellText(headerRow, i);

                if (!string.IsNullOrWhiteSpace(groupHeader))
                    currentGroup = groupHeader;

                string combinedHeader = string.IsNullOrWhiteSpace(detailHeader)
                    ? currentGroup
                    : $"{currentGroup} {detailHeader}";

                normalizedHeaders.Add(NormalizeHeader(combinedHeader));
            }

            foreach (var field in FieldAliases)
            {
                foreach (string alias in field.Value.Select(NormalizeHeader))
                {
                    int index = normalizedHeaders.FindIndex(h => h == alias);
                    if (index >= 0)
                    {
                        result[field.Key] = index;
                        break;
                    }
                }
            }

            return result;
        }

        private static string GetCellText(object[] row, int index)
        {
            if (index < 0 || index >= row.Length || row[index] == null)
                return string.Empty;

            return row[index].ToString()?.Trim() ?? string.Empty;
        }

        private static List<object[]> ReadRows(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var allRows = new List<object[]>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                do
                {
                    while (reader.Read())
                    {
                        var row = new object[reader.FieldCount];
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row[i] = reader.GetValue(i);
                        }

                        allRows.Add(row);
                    }
                } while (reader.NextResult());
            }

            return allRows;
        }

        private static bool TryGetDate(object[] row, int index, out DateTime date)
        {
            date = default;
            if (index < 0 || index >= row.Length || row[index] == null)
                return false;

            if (row[index] is DateTime dateValue)
            {
                date = dateValue.Date;
                return true;
            }

            if (row[index] is double serialDate && serialDate > 30000 && serialDate < 80000)
            {
                date = DateTime.FromOADate(serialDate).Date;
                return true;
            }

            string text = row[index].ToString();
            return DateTime.TryParse(text, out date);
        }

        private static int? FindReportYear(string filePath)
        {
            var allRows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(allRows);
            var headerRows = headerRowIndex > 0 ? allRows.Take(headerRowIndex) : allRows.Take(10);
            string headerText = string.Join(" ", headerRows.SelectMany(r => r).Where(c => c != null).Select(c => c.ToString()));

            var match = Regex.Match(headerText, @"\b(20\d{2})\b");
            return match.Success ? int.Parse(match.Groups[1].Value) : null;
        }

        private static string NormalizeHeader(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            return Regex.Replace(value, @"[^A-Za-z0-9]", string.Empty).ToUpperInvariant();
        }
    }
}
