using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyDeptLaborUtilizTrendSP
    {
        public static string GetBiWeeklyDeptLaborUtilizTrendQuery(string coid, List<string> deptOrGroupNumbers, DateTime activityStartDate, DateTime activityEndDate)
        {
            string normalizedCoid = NormalizeSqlLiteral(coid);
            string deptList = string.Join(", ", deptOrGroupNumbers.Select(NormalizeDeptNumber).Where(d => !string.IsNullOrWhiteSpace(d)).Distinct());
            if (string.IsNullOrWhiteSpace(deptList))
                deptList = "0";

            string startDateText = activityStartDate.ToString("yyyy-MM-dd");
            string endDateText = activityEndDate.ToString("yyyy-MM-dd");
            string unitNumExpression = $"(SELECT FAC.UNIT_NUM FROM H.LPBFAC FAC WHERE FAC.CO_ID = '{normalizedCoid}' FETCH FIRST 1 ROW ONLY)";

            return $@"SELECT FAC.CO_ID,
       PPD.DEPT_OR_GROUP_NUM,
       DPT1.DEPT_OR_GROUP_DESC,
       CASE WHEN 0 = 1 THEN (PPD.PP_END_DATE - 3 DAYS) ELSE PPD.PP_END_DATE END AS PP_END_DATE,
       PPD.TOT_UOS AS UOS_ACT,
       ROUND(PPD.TOT_UOS / 14, 0) AS DAILY_AVG_UOS,
       CASE WHEN PPD.TOT_UOS = 0 THEN 0 ELSE ROUND((PPD.TGT_PROD_HRS / PPD.TOT_UOS), 3) END AS PROD_HRS_UOS_TGT,
       CASE WHEN PPD.TOT_UOS = 0 THEN 0 ELSE ROUND((PPD.TOT_PROD_HRS / PPD.TOT_UOS), 3) END AS PROD_HRS_UOS_ACT,
       DEC(ROUND(CASE WHEN ROUND(PPD.TOT_PAID_HRS, 2) = 0 THEN 0
                      WHEN ((ROUND(PPD.TOT_NONPROD_HRS, 2) / ROUND(PPD.TOT_PAID_HRS, 2)) * 100) >= 999.99 THEN 999.99
                      WHEN ((ROUND(PPD.TOT_NONPROD_HRS, 2) / ROUND(PPD.TOT_PAID_HRS, 2)) * 100) <= -999.99 THEN -999.99
                      ELSE ((ROUND(PPD.TOT_NONPROD_HRS, 2) / ROUND(PPD.TOT_PAID_HRS, 2)) * 100)
                 END, 2), 5, 2) AS NON_PROD_PCT_ACT,
       ROUND(PPD.TGT_PROD_FTES, 2) AS PROD_FTES_TGT,
       ROUND(PPD.TOT_PROD_FTES, 2) AS PROD_FTES_ACT,
       (ROUND(PPD.TGT_PROD_FTES, 2) - ROUND(PPD.TOT_PROD_FTES, 2)) AS PROD_FTES_VAR,
       ROUND(PPD.TGT_PAID_FTES, 2) AS PAID_FTES_TGT,
       ROUND(PPD.TOT_PAID_FTES, 2) AS PAID_FTES_ACT,
       (ROUND(PPD.TGT_PAID_FTES, 2) - ROUND(PPD.TOT_PAID_FTES, 2)) AS PAID_FTES_VAR,
       ROUND(PPD.TOT_OT_FTES, 2) AS OT_FTES_ACT,
       DEC(ROUND(CASE WHEN ROUND(PPD.TOT_PROD_HRS, 2) = 0 THEN 0
                      WHEN ((ROUND(PPD.TOT_OT_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100) >= 999.99 THEN 999.99
                      WHEN ((ROUND(PPD.TOT_OT_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100) <= -999.99 THEN -999.99
                      ELSE ((ROUND(PPD.TOT_OT_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100)
                 END, 2), 5, 2) AS OT_PCT_ACT,
       ROUND(PPD.TOT_HWS_FTES, 2) AS HWS_FTES_ACT,
       DEC(ROUND(CASE WHEN ROUND(PPD.TOT_PROD_HRS, 2) = 0 THEN 0
                      WHEN ((ROUND(PPD.TOT_HWS_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100) >= 999.99 THEN 999.99
                      WHEN ((ROUND(PPD.TOT_HWS_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100) <= -999.99 THEN -999.99
                      ELSE ((ROUND(PPD.TOT_HWS_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100)
                 END, 2), 5, 2) AS HWS_CONTR_PCT_ACT,
       ROUND(PPD.TOT_VEN_FTES, 2) AS VEN_FTES_ACT,
       DEC(ROUND(CASE WHEN ROUND(PPD.TOT_PROD_HRS, 2) = 0 THEN 0
                      WHEN ((ROUND(PPD.TOT_VEN_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100) >= 999.99 THEN 999.99
                      WHEN ((ROUND(PPD.TOT_VEN_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100) <= -999.99 THEN -999.99
                      ELSE ((ROUND(PPD.TOT_VEN_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100)
                 END, 2), 5, 2) AS VEN_CONTR_PCT_ACT,
       ROUND(PPD.TOT_CONTR_FTES, 2) AS CONTR_FTES_ACT,
       DEC(ROUND(CASE WHEN ROUND(PPD.TOT_PROD_HRS, 2) = 0 THEN 0
                      WHEN ((ROUND(PPD.TOT_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100) >= 999.99 THEN 999.99
                      WHEN ((ROUND(PPD.TOT_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100) <= -999.99 THEN -999.99
                      ELSE ((ROUND(PPD.TOT_CONTR_HRS, 2) / ROUND(PPD.TOT_PROD_HRS, 2)) * 100)
                 END, 2), 5, 2) AS CONTR_PCT_ACT,
       (SELECT DEC(ROUND(SUM(COALESCE(DDA.ACT_PRODHRS_PRN, 0) + COALESCE(DDA.ACT_OT_PRN, 0)) / 80, 2), 5, 2)
          FROM H.LPBDDAA DDA
         WHERE DDA.UNIT_NUM = PPD.UNIT_NUM
           AND DDA.DEPT_OR_GROUP_NUM = PPD.DEPT_OR_GROUP_NUM
           AND DDA.ACTIVITY_DATE BETWEEN (PPD.PP_END_DATE - 13 DAYS) AND PPD.PP_END_DATE) AS PRN_FTE,
       (SELECT DEC(ROUND(CASE WHEN DEC((PPD.TOT_PROD_FTES), 5, 2) = 0 THEN 0
                              WHEN ((ROUND(SUM(COALESCE(DDA.ACT_PRODHRS_PRN, 0) + COALESCE(DDA.ACT_OT_PRN, 0)) / 80, 2) / DEC((PPD.TOT_PROD_FTES), 5, 2)) * 100) >= 999.99 THEN 999.99
                              WHEN ((ROUND((SUM(COALESCE(DDA.ACT_PRODHRS_PRN, 0) + COALESCE(DDA.ACT_OT_PRN, 0)) / 80), 2) / DEC((PPD.TOT_PROD_FTES), 5, 2)) * 100) <= -999.99 THEN -999.99
                              ELSE ((ROUND((SUM(COALESCE(DDA.ACT_PRODHRS_PRN, 0) + COALESCE(DDA.ACT_OT_PRN, 0)) / 80), 2) / DEC((PPD.TOT_PROD_FTES), 5, 2)) * 100)
                         END, 2), 5, 2)
          FROM H.LPBDDAA DDA
         WHERE DDA.UNIT_NUM = PPD.UNIT_NUM
           AND DDA.DEPT_OR_GROUP_NUM = PPD.DEPT_OR_GROUP_NUM
           AND DDA.ACTIVITY_DATE BETWEEN (PPD.PP_END_DATE - 13 DAYS) AND PPD.PP_END_DATE) AS PRN_FTE_PCT
FROM H.LPBPPD PPD
INNER JOIN H.LPBFAC FAC ON PPD.UNIT_NUM = FAC.UNIT_NUM
LEFT OUTER JOIN H.LPBDPT DPT ON PPD.UNIT_NUM = DPT.UNIT_NUM AND PPD.DEPT_OR_GROUP_NUM = DPT.DEPT_NUM
LEFT OUTER JOIN (
    SELECT DPT.UNIT_NUM, DPT.DEPT_NUM, DPT.DEPT_DESC AS DEPT_OR_GROUP_DESC
    FROM H.LPBDPT DPT
    WHERE DPT.UNIT_NUM = {unitNumExpression} AND DPT.DEPT_NUM IN ({deptList})
    UNION ALL
    SELECT GPD.UNIT_NUM, GPD.GROUP_NUM AS DEPT_NUM, GPD.GROUP_DESC AS DEPT_OR_GROUP_DESC
    FROM H.LPBGPD GPD
    WHERE GPD.UNIT_NUM = {unitNumExpression} AND GPD.GROUP_NUM IN ({deptList})
) DPT1 ON PPD.UNIT_NUM = DPT1.UNIT_NUM AND PPD.DEPT_OR_GROUP_NUM = DPT1.DEPT_NUM
WHERE PPD.UNIT_NUM = {unitNumExpression}
  AND PPD.DEPT_OR_GROUP_NUM IN ({deptList})
  AND PPD.PP_END_DATE BETWEEN (SELECT CASE WHEN PPF.PROCESS_START_DATE IS NULL THEN DATE('1900-01-01') ELSE PPF.PROCESS_START_DATE END
                               FROM H.LPBFAC FAC
                               LEFT OUTER JOIN (SELECT PPF.UNIT_NUM, MIN(PPF.PP_END_DATE) AS PROCESS_START_DATE, MAX(PPF.PP_END_DATE) AS PROCESS_END_DATE
                                                FROM H.LPBPPF PPF
                                                WHERE PPF.UNIT_NUM = {unitNumExpression}
                                                  AND PPF.PPE_DATE BETWEEN DATE('{startDateText}') AND DATE('{endDateText}')
                                                GROUP BY PPF.UNIT_NUM) PPF ON FAC.UNIT_NUM = PPF.UNIT_NUM
                               WHERE FAC.UNIT_NUM = {unitNumExpression})
                          AND (SELECT CASE WHEN PPF.PROCESS_END_DATE IS NULL THEN DATE('1900-01-01') ELSE PPF.PROCESS_END_DATE END
                               FROM H.LPBFAC FAC
                               LEFT OUTER JOIN (SELECT PPF.UNIT_NUM, MIN(PPF.PP_END_DATE) AS PROCESS_START_DATE, MAX(PPF.PP_END_DATE) AS PROCESS_END_DATE
                                                FROM H.LPBPPF PPF
                                                WHERE PPF.UNIT_NUM = {unitNumExpression}
                                                  AND PPF.PPE_DATE BETWEEN DATE('{startDateText}') AND DATE('{endDateText}')
                                                GROUP BY PPF.UNIT_NUM) PPF ON FAC.UNIT_NUM = PPF.UNIT_NUM
                               WHERE FAC.UNIT_NUM = {unitNumExpression})
  AND (DPT.IGNORE_DEPT IS NULL OR DPT.IGNORE_DEPT = 'N')
ORDER BY PPD.DEPT_OR_GROUP_NUM, PPD.PP_END_DATE";
        }

        public static bool IsSelectQuery(string query)
        {
            return !string.IsNullOrWhiteSpace(query)
                && query.TrimStart().StartsWith("SELECT", StringComparison.OrdinalIgnoreCase);
        }

        private static string NormalizeSqlLiteral(string value)
        {
            return (value ?? string.Empty).Replace("'", "''").Trim();
        }

        private static string NormalizeDeptNumber(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            string digits = new string(value.Where(char.IsDigit).ToArray());
            return string.IsNullOrWhiteSpace(digits) ? string.Empty : digits.TrimStart('0');
        }
    }
}
