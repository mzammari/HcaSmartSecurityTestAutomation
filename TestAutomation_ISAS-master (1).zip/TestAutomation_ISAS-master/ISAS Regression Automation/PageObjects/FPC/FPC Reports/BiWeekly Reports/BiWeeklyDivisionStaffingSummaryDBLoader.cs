using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;

namespace ISAS_Regression_Automation
{
    public static class BiWeeklyDivisionStaffingSummaryDBLoader
    {
        public static List<BiWeeklyDivisionStaffingSummaryData> LoadFromDatabase(int divisionNumber, DateTime? payPeriodEndingDate)
        {
            var result = new List<BiWeeklyDivisionStaffingSummaryData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = BiWeeklyDivisionStaffingSummarySP.GetBiWeeklyDivisionStaffingSummaryQuery(divisionNumber, payPeriodEndingDate);
            if (!BiWeeklyDivisionStaffingSummarySP.IsSelectQuery(sqlQuery))
                throw new InvalidOperationException("Bi-Weekly Division Staffing Summary DB validation skipped because the DB query is not a SELECT query.");

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new BiWeeklyDivisionStaffingSummaryData
                            {
                                Coid = GetString(reader, "CO_ID"),
                                FacilityName = GetString(reader, "FACILITY_NAME"),
                                PayPeriodEndingDate = GetDate(reader, "PP_END_DATE"),
                                AvgDailyCensus = GetDecimal(reader, "AVG_DLY_CENSUS"),
                                EqAvgDailyCensus = GetDecimal(reader, "EQ_AVG_DLY_CENSUS"),
                                OpFactor = GetDecimal(reader, "OP_FACTOR"),
                                EeobBudget = GetDecimal(reader, "EEOB_BDGT"),
                                EeobActual = GetDecimal(reader, "EEOB_ACTUAL"),
                                EeobVariance = GetDecimal(reader, "EEOB_VAR"),
                                EeobPercentChange = GetDecimal(reader, "PCNT_CHG_EEOB"),
                                ManhoursAaBudget = GetDecimal(reader, "MANHOURS_AA_BDGT"),
                                ManhoursAaActual = GetDecimal(reader, "MANHOURS_AA_ACTUAL"),
                                ManhoursAaVariance = GetDecimal(reader, "MANHOURS_AA_VAR"),
                                ManhoursAaPercentChange = GetDecimal(reader, "PCNT_CHG_MH_AA"),
                                AvgHourlyRateBudget = GetDecimal(reader, "AVG_HRLY_RATE_BDGT"),
                                AvgHourlyRateActual = GetDecimal(reader, "AVG_HRLY_RATE_ACT"),
                                AvgHourlyRateVariance = GetDecimal(reader, "AVG_HRLY_RATE_VAR"),
                                AvgHourlyRatePercentChange = GetDecimal(reader, "PCNT_CHG_AVHR_RATE"),
                                PremiumOtFtes = GetDecimal(reader, "TOT_OT_FTES"),
                                PremiumHwsFtes = GetDecimal(reader, "TOT_HWS_CONTR_FTES"),
                                PremiumVendorFtes = GetDecimal(reader, "TOT_VEN_CONTR_FTES"),
                                PremiumContractFtes = GetDecimal(reader, "TOT_CONTR_FTES"),
                                EadcPercentChange = GetDecimal(reader, "PCNT_CHG_EADC"),
                                ProductiveFtesPercentChange = GetDecimal(reader, "PCNT_CHG_PROD_FTES"),
                                PaidFtesPercentChange = GetDecimal(reader, "PCNT_CHG_PAID_FTES")
                            });
                        }
                    }
                }
            }

            return result;
        }

        private static string GetString(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    return reader.IsDBNull(ordinal) ? string.Empty : reader.GetValue(ordinal).ToString().Trim();
                }
                catch (IndexOutOfRangeException)
                {
                }
            }

            return string.Empty;
        }

        private static DateTime GetDate(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal))
                        return default;

                    var value = reader.GetValue(ordinal);
                    if (value is DateTime date)
                        return date.Date;

                    return DateTime.TryParse(value.ToString(), out DateTime parsed) ? parsed.Date : default;
                }
                catch (IndexOutOfRangeException)
                {
                }
            }

            return default;
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;

                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;

                    string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                    return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
                }
                catch
                {
                }
            }

            return 0m;
        }
    }
}
