﻿using AdoTestCasePlugin.Dtos;
using AventStack.ExtentReports.Gherkin.Model;
using Microsoft.VisualStudio.CodeCoverage;
using OpenQA.Selenium;
using RazorEngine.Compilation.ImpromptuInterface.Optimization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.FpcPlan.NonProductivePercentage;
using static ISAS_Regression_Automation.WFTMainMenu.WFTReports;

namespace ISAS_Regression_Automation
{
    public class FpcReportMenu
    {
        public class DailyTrendReport
        {
            public static void SelectDailyTrendReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily Trend Report')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDailyStaffingSummaryDivisionReport()
            {
                CommonFunctions.WaitUntilPageIsAcive();
                // Primary path: Reports(2) -> Staffing Summary - Division -> Daily Staffing Summary Division Report
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//a[normalize-space()='Daily Staffing Summary - Division']");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }
                




            public static void SelectDailyStaffingSummary()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily Staffing Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDailyStaffingSummaryIgnoreDeptReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily Staffing Summary-Ignore Dept')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDailyStaffingPaidHoursSummary()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily Staffing Paid Hours Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDailyUosErVisitsHolds()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily UOS – E/R Visits Weighted ER Holds')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);

            }

            public static void SelectDailyLaborDollarsSummary()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily Labor Dollars Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDailyLaborPaidDollarsSummary()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily Labor Paid Dollars Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDailyUosErVisitsWeightedErHolds()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily UOS – E/R Visits Weighted ER Holds')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }
        }

        public class BiWeeklyReports
        {
            public static void SelectBiWeeklyDeptLaborUtilizTrendReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                By link = By.XPath("//*/a[contains(text(),'Bi-Weekly Dept.Labor Utiliz.Trend')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectBiWeeklyStaffingSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                By link = By.XPath("//*/a[contains(text(),'Bi-Weekly Staffing Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectBiWeeklyFacilityLaborUtilizTrendReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                By link = By.XPath("//*/a[contains(text(),'Bi-Weekly Facility Labor Utiliz.Trend')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDailyTrendReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                By link = By.XPath("//*/a[contains(text(),'Bi-Weekly Dept.Labor Utiliz.Trend')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectBiWeeklyDivisionLaborUtilizTrendReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                By link = By.XPath("//*/a[contains(text(),'Bi-Weekly Division Labor Utiliz.Trend)]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectBiWeeklyDivisionStaffingSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                By link = By.XPath("//*/a[contains(text(),'Bi-Weekly Division Staffing Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectBiWeeklyGroupStaffingSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                By link = By.XPath("//*/a[contains(text(),'Bi-Weekly Group Staffing Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectBiWeeklyLaborManagementReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                By link = By.XPath("//*/a[contains(text(),'Bi-Weekly Labor Management')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }
        }

        public class ShiftSummaryReports
        {
            public static void SelectDailyTrendByShiftSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Shift Summary Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily Trend By Shift Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDailyStaffingByShiftSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Shift Summary Reports']");
                By link = By.XPath("//*/a[contains(text(),'Daily Staffing By Shift Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }
        }

        public class ContractLaborReports
        {
            public static void SelectContractLaborDetailBySkillMixReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                By link = By.XPath("//*/a[contains(text(),'Contract Labor Detail By Skill Mix')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectContractLaborPotentialOpportunityByDivisionReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                By link = By.XPath("//*/a[contains(text(),'Contract Labor Potential Opportunity By Division')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectContractLaborRatesByDepartmentReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                By link = By.XPath("//*/a[contains(text(),'Contract Labor Rates By Department')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectContractLaborSummaryDivisionByMonthReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                By link = By.XPath("//*/a[contains(text(),'Contract Labor Summary-Division(By Month)')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectContractLaborSummaryFacilityByMonthReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                By link = By.XPath("//*/a[contains(text(),'Contract Labor Summary-Facility(By Month)')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectContractLaborSummaryBySkillMixReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                By link = By.XPath("//*/a[contains(text(),'Contract Labor Summary By Skill Mix')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectContractAndEmployedLaborUsageByDepartmentReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                By link = By.XPath("//*/a[contains(text(),'Contract And Employed Labor Usage By Department')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

        }

        public class FPCReports
        {
            public static void SelectFPCDepartmentDetailReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Department Detail')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCDepartmentDetailPayPeriodReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Department Detail(Pay Period)')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCDivisionApprovedPlanSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Division Approved Plan Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCDivisionNeedsAnalysisReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Division Needs Analysis')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCFacilityApprovedPlanSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Facility Approved Plan Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCFacilityOpenReqsWithSkillMixVarianceReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Facility Open Reqs. with Skill Mix Variance')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCFacilitySkillMixVarByShiftSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Facility Skill Mix Var. by Shift Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCFacilityNeedsAnalysisReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Facility Needs Analysis')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCFacilityBusinessRulesAnalysisReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Facility Business Rules Analysis')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFPCPlanStatusSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                By link = By.XPath("//*/a[contains(text(),'FPC Plan Status Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

        }

        public class OtherReports
        {
            public static void SelectAnnualLaborProductivityTargetsReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Annual Labor Productivity Targets')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectSchedule8FacilityReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Schedule 8 Facility Report')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFunctionalDepartmentPaidManHoursReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Functional Department-Paid ManHours')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFunctionalDepartmentProductiveManHoursReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Functional Department-Productive ManHours')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFunctionalDepartmentExecutiveSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Functional Department Executive Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectMonthlySkillMixAnalysisReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Monthly Skill Mix Analysis')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectSkillMixOpportunityDivisionReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Skill Mix Reports']");
                By link = By.XPath("//*/a[contains(text(),'Opportunity Report - Division')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link, 120);
            }

            public static void SelectProcedureMultipliersReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Procedure Multipliers')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectFacilityUserReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Facility User Report')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectDepartmentUsageReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                By link = By.XPath("//*/a[contains(text(),'Department Usage')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }
        }

        public class SharedEmployeeReports
        {
            public static void SelectSharedEmployeeFacilitySummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Shared Employee Reports']");
                By link = By.XPath("//*/a[contains(text(),'Shared Employee Facility Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectSharedEmployeeSummaryByMonthReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Shared Employee Reports']");
                By link = By.XPath("//*/a[contains(text(),'Shared Employee Facility Summary(By Month)')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void SelectSharedEmployeeDivisionSummaryReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Shared Employee Reports']");
                By link = By.XPath("//*/a[contains(text(),'Shared Employee Division Summary')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }

            public static void EmployeeDivisionSummaryByMonthReport()
            {
                By TopMenuLevel = By.XPath("(//*/ul[@class='sf-menu sf-js-enabled sf-shadow']//a[contains(text(),'Reports')])[1]");
                By SecondMunuLevel = By.XPath("//*/a[text()='Shared Employee Reports']");
                By link = By.XPath("//*/a[contains(text(),'Shared Employee Division Summary(By Month)')]");
                MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
            }
        }
    }
}
