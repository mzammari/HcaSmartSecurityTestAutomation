using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class DailyTrendReportDBLoader
    {
        public static List<DailyTrendReportData> LoadFromDatabase(string reportType, string reportPeriod, string deptGroupSelection, string department, DateTime startDate, DateTime endDate)
        {
            var result = new List<DailyTrendReportData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = DailyTrendReportSP.GetDailyTrendReportQuery(reportType, reportPeriod, deptGroupSelection, department, startDate, endDate);

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        var columns = Enumerable.Range(0, reader.FieldCount)
                            .Select(i => new DailyTrendDbColumn
                            {
                                Ordinal = i,
                                OriginalName = reader.GetName(i),
                                NormalizedName = DailyTrendReportExcelReport.NormalizeHeader(reader.GetName(i))
                            })
                            .ToList();

                        while (reader.Read())
                        {
                            var row = new DailyTrendReportData();
                            row.Key = BuildKey(reader, columns);

                            foreach (var column in columns)
                            {
                                if (DailyTrendReportExcelReport.IsIdentifierHeader(column.NormalizedName))
                                    continue;

                                decimal value = GetDecimal(reader, column.Ordinal);
                                row.Values[column.NormalizedName] = value;
                            }

                            result.Add(row);
                        }
                    }
                }
            }

            return result;
        }

        private static string BuildKey(IDataRecord reader, List<DailyTrendDbColumn> columns)
        {
            string dateKey = GetDateKey(reader, "DT") ?? GetDateKey(reader, "ACTIVITY DATE") ?? GetDateKey(reader, "ACTIVITY_DATE");
            if (!string.IsNullOrWhiteSpace(dateKey))
                return DailyTrendReportExcelReport.NormalizeKey(dateKey);

            var keyParts = new List<string>();

            foreach (var column in columns)
            {
                string header = column.NormalizedName;
                string value = reader.IsDBNull(column.Ordinal) ? string.Empty : reader.GetValue(column.Ordinal).ToString()?.Trim();
                if (string.IsNullOrWhiteSpace(value))
                    continue;

                if (DailyTrendReportExcelReport.IsIdentifierHeader(header))
                    keyParts.Add(value);
            }

            if (keyParts.Count == 0 && reader.FieldCount > 0 && !reader.IsDBNull(0))
                keyParts.Add(reader.GetValue(0).ToString()?.Trim());

            return DailyTrendReportExcelReport.NormalizeKey(string.Join("|", keyParts.Where(p => !string.IsNullOrWhiteSpace(p))));
        }

        private class DailyTrendDbColumn
        {
            public int Ordinal { get; set; }
            public string OriginalName { get; set; }
            public string NormalizedName { get; set; }
        }

        private static string GetDateKey(IDataRecord reader, string columnName)
        {
            try
            {
                int ordinal = reader.GetOrdinal(columnName);
                return reader.IsDBNull(ordinal) ? null : reader.GetValue(ordinal)?.ToString();
            }
            catch
            {
                return null;
            }
        }

        private static decimal GetDecimal(IDataRecord reader, int ordinal)
        {
            try
            {
                if (reader.IsDBNull(ordinal)) return 0m;

                var value = reader.GetValue(ordinal);
                if (value is decimal dec) return dec;
                if (value is double d) return (decimal)d;
                if (value is float f) return (decimal)f;
                if (value is int i) return i;
                if (value is long l) return l;

                string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
            }
            catch
            {
                return 0m;
            }
        }
    }
}
