using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingPaidHoursSummaryValidator
    {
        private const decimal TOLERANCE = 0.01m;

        public static void Validate(List<DailyStaffingPaidHoursSummaryData> excelData, List<DailyStaffingPaidHoursSummaryData> dbData)
        {
            Console.WriteLine("=== Daily Staffing Paid Hours Summary Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                return;
            }

            var mismatches = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;
            int skippedRows = 0;
            int skippedFields = 0;

            foreach (var dbRow in dbData)
            {
                var excelRow = excelData.FirstOrDefault(e => IsSameRow(e, dbRow));

                if (excelRow == null)
                {
                    skippedRows++;
                    continue;
                }

                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.TargetProdHoursUOS), excelRow.TargetProdHoursUOS, dbRow.TargetProdHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.TargetPaidHoursUOS), excelRow.TargetPaidHoursUOS, dbRow.TargetPaidHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.TargetSvProdFtes), excelRow.TargetSvProdFtes, dbRow.TargetSvProdFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.ActualUOS), excelRow.ActualUOS, dbRow.ActualUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursTarget), excelRow.ProductiveHoursTarget, dbRow.ProductiveHoursTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursActual), excelRow.ProductiveHoursActual, dbRow.ProductiveHoursActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursVariance), excelRow.ProductiveHoursVariance, dbRow.ProductiveHoursVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.PaidHoursTarget), excelRow.PaidHoursTarget, dbRow.PaidHoursTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.PaidHoursActual), excelRow.PaidHoursActual, dbRow.PaidHoursActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.PaidHoursVariance), excelRow.PaidHoursVariance, dbRow.PaidHoursVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.CumulativeUOS), excelRow.CumulativeUOS, dbRow.CumulativeUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursTarget), excelRow.CumulativeProductiveHoursTarget, dbRow.CumulativeProductiveHoursTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursActual), excelRow.CumulativeProductiveHoursActual, dbRow.CumulativeProductiveHoursActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursTarget), excelRow.CumulativePaidHoursTarget, dbRow.CumulativePaidHoursTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursActual), excelRow.CumulativePaidHoursActual, dbRow.CumulativePaidHoursActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursVariance), excelRow.CumulativeProductiveHoursVariance, dbRow.CumulativeProductiveHoursVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursVariance), excelRow.CumulativePaidHoursVariance, dbRow.CumulativePaidHoursVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.CumulativeNegativeVariance), excelRow.CumulativeNegativeVariance, dbRow.CumulativeNegativeVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.OvertimeFtes), excelRow.OvertimeFtes, dbRow.OvertimeFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.OvertimePercent), excelRow.OvertimePercent, dbRow.OvertimePercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.HwsContractProdHours), excelRow.HwsContractProdHours, dbRow.HwsContractProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.VendorContractProdHours), excelRow.VendorContractProdHours, dbRow.VendorContractProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.ContractFtes), excelRow.ContractFtes, dbRow.ContractFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.ContractPercent), excelRow.ContractPercent, dbRow.ContractPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.ProductiveIndexPercent), excelRow.ProductiveIndexPercent, dbRow.ProductiveIndexPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.PaidIndexPercent), excelRow.PaidIndexPercent, dbRow.PaidIndexPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.TargetMinimumHours), excelRow.TargetMinimumHours, dbRow.TargetMinimumHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.PRNFtes), excelRow.PRNFtes, dbRow.PRNFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingPaidHoursSummaryData.PRNPercent), excelRow.PRNPercent, dbRow.PRNPercent);
            }

            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine("Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");
            Console.WriteLine($"  Skipped DB rows not present in Excel: {skippedRows}");
            Console.WriteLine($"  Skipped fields not present in Excel: {skippedFields}");

            if (totalComparisons == 0)
            {
                Console.WriteLine("No matching Excel columns were available for validation. Validation skipped.");
                return;
            }

            if (mismatches.Count > 0)
            {
                Console.WriteLine("\nMismatches:");
                Console.WriteLine($"{"DeptGroup",-12} {"Field",-40} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 82));

                foreach (var mismatch in mismatches)
                {
                    Console.WriteLine(mismatch);
                }

                Assert.Fail($"Daily Staffing Paid Hours Summary validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons.");
            }

            Console.WriteLine("\nDaily Staffing Paid Hours Summary validated successfully - all values match.");
        }

        private static void CompareField(
            List<string> mismatches,
            ref int totalComparisons,
            ref int matchCount,
            ref int skippedFields,
            DailyStaffingPaidHoursSummaryData excelRow,
            string fieldName,
            decimal excelValue,
            decimal dbValue)
        {
            if (excelRow.AvailableFields.Any() && !excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            bool isMatch = Math.Abs(excelValue - dbValue) <= TOLERANCE;

            if (isMatch)
            {
                matchCount++;
                return;
            }

            mismatches.Add($"{excelRow.DeptGroupNum,-12} {fieldName,-40} {excelValue,12:N4} {dbValue,12:N4}");
        }

        private static bool IsSameRow(DailyStaffingPaidHoursSummaryData excelRow, DailyStaffingPaidHoursSummaryData dbRow)
        {
            return Normalize(excelRow.DeptGroupNum) == Normalize(dbRow.DeptGroupNum)
                && Normalize(excelRow.StatisticDescription) == Normalize(dbRow.StatisticDescription);
        }

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : string.Join(" ", value.Trim().Split(' ').Where(s => !string.IsNullOrWhiteSpace(s))).ToUpperInvariant();
        }
    }
}
