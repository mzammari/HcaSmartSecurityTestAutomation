﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation.PageObjects.FPC.FPC_Reports.Daily_Reports
{
    internal class DailyStaffingPaidHoursSummaryReport
    {

        public static void GoTo()
        {
            FpcReportMenu.DailyTrendReport.SelectDailyStaffingPaidHoursSummary();
            CommonFunctions.AddTestStep("Select Daily Staffing Paid Hours Summary Report", "The Daily Staffing Paid Hours Summary Report is displayed");
        }
        public static bool IsAt
        {
            get
            {
                By byReportType = By.XPath("//select[@id='ddlReportType'] ");
                CommonFunctions.AddTestStep("Verify the Daily Staffing Paid Hours Summary Report page is active", "The plan page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byReportType, 20);
            }
        }

        public static DailyStaffingPaidHoursSummaryReportCommand dailyStaffingPaidHoursSummaryReport()
        {
            return new DailyStaffingPaidHoursSummaryReportCommand();
        }

        #region: DailyStaffingPaidHoursSummaryReportCommand            
        public class DailyStaffingPaidHoursSummaryReportCommand
        {
            private string reportType;
            private string reportPeriod;


            public DailyStaffingPaidHoursSummaryReportCommand withReportType(string ReportType)
            {
                this.reportType = ReportType;
                return this;

            }

            public DailyStaffingPaidHoursSummaryReportCommand withReportPeriod(string ReportPeriod)
            {
                this.reportPeriod = ReportPeriod;
                return this;
            }


            private void setReportType()
            {
                By byReportType = By.XPath("//select[@id='ddlReportType']");
                IWebElement mnuReportType = CommonFunctions.getElement(byReportType);
                CommonFunctions.SelectItemFromDropdownMenu(mnuReportType, reportType);
                CommonFunctions.AddTestStep($"Verify a user can select {reportType} from Report Type dropdown", $"The {reportType} is selected correctly");
            }

            private void setReportPeriod()
            {
                By byReportPeriod = By.XPath("//select[@id='payPeriodID']");
                IWebElement mnuReportPeriod = CommonFunctions.getElement(byReportPeriod);
                CommonFunctions.SelectItemFromDropdownMenu(mnuReportPeriod, reportPeriod);
                CommonFunctions.AddTestStep($"Verify a user can select {reportPeriod} from Report Period dropdown", $"The {reportPeriod} is selected correctly");
            }

          

            private void clickExcel()
            {
                By byExcel = By.XPath("//img[@title='Excel (new) Format']");
                IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
                //CommonFunctions.ClickByJE(cmdExcel);
                cmdExcel.Click();
                //Thread.Sleep(240000);
                CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
            }



            

            public void Excel()
            {
                setReportType();
                setReportPeriod();

                clickExcel();
                CommonFunctions.WaitUntilPageIsAcive();
            }


        }
    
}
    #endregion
}
