using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace ISAS_Regression_Automation
{
    public class DailyTrendReportData
    {
        public string Key { get; set; }
        public Dictionary<string, decimal> Values { get; set; } = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
    }

    public static class DailyTrendReportExcelReport
    {
        public static List<DailyTrendReportData> ParseDailyTrendReportExcel(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                var dataSet = reader.AsDataSet(new ExcelDataSetConfiguration
                {
                    ConfigureDataTable = _ => new ExcelDataTableConfiguration
                    {
                        UseHeaderRow = false
                    }
                });

                if (dataSet.Tables.Count == 0)
                    return new List<DailyTrendReportData>();

                var table = dataSet.Tables[0];
                var rawDbStyleRows = ParseStandardRows(table, false, true);
                if (rawDbStyleRows.Count > 0)
                    return rawDbStyleRows;

                var pivotedRows = ParsePivotedDateColumns(table);
                if (pivotedRows.Count > 0)
                    return pivotedRows;

                return ParseStandardRows(table, true, false);
            }
        }

        private static List<DailyTrendReportData> ParsePivotedDateColumns(DataTable table)
        {
            var result = new List<DailyTrendReportData>();
            int headerRowIndex = FindDateHeaderRow(table);
            if (headerRowIndex < 0)
                return result;

            var dateColumns = GetDateColumns(table.Rows[headerRowIndex]);
            if (dateColumns.Count == 0)
                return result;

            int metricColumn = FindMetricColumn(table, headerRowIndex, dateColumns.Keys.Min());
            if (metricColumn < 0)
                return result;

            foreach (var dateColumn in dateColumns)
            {
                result.Add(new DailyTrendReportData
                {
                    Key = NormalizeKey(dateColumn.Value)
                });
            }

            for (int rowIndex = headerRowIndex + 1; rowIndex < table.Rows.Count; rowIndex++)
            {
                var row = table.Rows[rowIndex];
                if (IsEmptyRow(row))
                    continue;

                string metricName = NormalizeHeader(row[metricColumn]?.ToString());
                if (string.IsNullOrWhiteSpace(metricName))
                    continue;

                foreach (var dateColumn in dateColumns)
                {
                    var reportRow = result.First(r => r.Key == NormalizeKey(dateColumn.Value));
                    reportRow.Values[metricName] = GetDecimal(row[dateColumn.Key]);
                }
            }

            return result.Where(r => r.Values.Count > 0).ToList();
        }

        private static List<DailyTrendReportData> ParseStandardRows(DataTable table, bool throwIfHeaderMissing, bool requireDateKey)
        {
            var result = new List<DailyTrendReportData>();
            int headerRowIndex = FindHeaderRow(table);

            if (headerRowIndex < 0)
            {
                if (!throwIfHeaderMissing)
                    return result;

                throw new InvalidOperationException("Could not find Daily Trend Report header row in the Excel file.");
            }

            var headers = GetHeaders(table.Rows[headerRowIndex]);
            if (headers.Count == 0)
            {
                if (!throwIfHeaderMissing)
                    return result;

                throw new InvalidOperationException("Could not read Daily Trend Report headers from the Excel file.");
            }

            for (int rowIndex = headerRowIndex + 1; rowIndex < table.Rows.Count; rowIndex++)
            {
                var row = table.Rows[rowIndex];
                if (IsEmptyRow(row))
                    continue;

                string key = BuildKey(row, headers);
                if (string.IsNullOrWhiteSpace(key))
                    continue;

                if (requireDateKey && !DateTime.TryParse(key, out _))
                    continue;

                var reportRow = new DailyTrendReportData { Key = key };

                foreach (var header in headers)
                {
                    if (header.Value >= row.ItemArray.Length)
                        continue;

                    if (IsIdentifierHeader(header.Key))
                        continue;

                    reportRow.Values[header.Key] = GetDecimal(row[header.Value]);
                }

                result.Add(reportRow);
            }

            return result;
        }

        private static int FindDateHeaderRow(DataTable table)
        {
            for (int rowIndex = 0; rowIndex < table.Rows.Count; rowIndex++)
            {
                var dateColumns = GetDateColumns(table.Rows[rowIndex]);
                if (dateColumns.Count >= 2)
                    return rowIndex;
            }

            return -1;
        }

        private static Dictionary<int, string> GetDateColumns(DataRow row)
        {
            var dateColumns = new Dictionary<int, string>();

            for (int col = 0; col < row.ItemArray.Length; col++)
            {
                string value = row[col]?.ToString()?.Trim();
                if (string.IsNullOrWhiteSpace(value))
                    continue;

                if (TryNormalizeDate(row[col], out string normalizedDate))
                    dateColumns[col] = normalizedDate;
            }

            return dateColumns;
        }

        private static int FindMetricColumn(DataTable table, int headerRowIndex, int firstDateColumn)
        {
            int bestColumn = -1;
            int bestScore = 0;

            for (int col = 0; col < firstDateColumn; col++)
            {
                int score = 0;
                for (int rowIndex = headerRowIndex + 1; rowIndex < table.Rows.Count; rowIndex++)
                {
                    string value = table.Rows[rowIndex][col]?.ToString()?.Trim();
                    if (!string.IsNullOrWhiteSpace(value) && !TryNormalizeDate(value, out _))
                        score++;
                }

                if (score > bestScore)
                {
                    bestScore = score;
                    bestColumn = col;
                }
            }

            return bestColumn;
        }

        private static int FindHeaderRow(DataTable table)
        {
            for (int rowIndex = 0; rowIndex < table.Rows.Count; rowIndex++)
            {
                var row = table.Rows[rowIndex];
                bool hasIdentifierHeader = row.ItemArray.Any(c => IsIdentifierHeader(c?.ToString()?.Trim() ?? string.Empty));
                bool hasNumericHeader = row.ItemArray.Any(c => IsNumericValueHeader(c?.ToString()?.Trim() ?? string.Empty));

                if (hasIdentifierHeader && hasNumericHeader)
                    return rowIndex;
            }

            return -1;
        }

        private static Dictionary<string, int> GetHeaders(DataRow row)
        {
            var headers = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            for (int col = 0; col < row.ItemArray.Length; col++)
            {
                string header = NormalizeHeader(row[col]?.ToString());
                if (string.IsNullOrWhiteSpace(header))
                    continue;

                string uniqueHeader = header;
                int suffix = 2;
                while (headers.ContainsKey(uniqueHeader))
                    uniqueHeader = $"{header}_{suffix++}";

                headers[uniqueHeader] = col;
            }

            return headers;
        }

        private static string BuildKey(DataRow row, Dictionary<string, int> headers)
        {
            string dateKey = GetDateKey(row, headers, "DT")
                ?? GetDateKey(row, headers, "ACTIVITY DATE")
                ?? GetDateKey(row, headers, "ACTIVITY_DATE")
                ?? GetDateKey(row, headers, "DATE");

            if (!string.IsNullOrWhiteSpace(dateKey))
                return NormalizeKey(dateKey);

            var keyParts = new List<string>();

            foreach (var header in headers)
            {
                if (header.Value >= row.ItemArray.Length)
                    continue;

                string headerName = header.Key;
                string value = row[header.Value]?.ToString()?.Trim();
                if (string.IsNullOrWhiteSpace(value))
                    continue;

                if (IsIdentifierHeader(headerName))
                    keyParts.Add(value);
            }

            if (keyParts.Count == 0)
                keyParts.Add(row[0]?.ToString()?.Trim());

            return NormalizeKey(string.Join("|", keyParts.Where(p => !string.IsNullOrWhiteSpace(p))));
        }

        private static string GetDateKey(DataRow row, Dictionary<string, int> headers, string headerName)
        {
            var header = headers.FirstOrDefault(h => h.Key.Equals(NormalizeHeader(headerName), StringComparison.OrdinalIgnoreCase)
                || h.Key.Equals(headerName, StringComparison.OrdinalIgnoreCase));

            if (string.IsNullOrWhiteSpace(header.Key) || header.Value >= row.ItemArray.Length)
                return null;

            return TryNormalizeDate(row[header.Value], out string normalizedDate) ? normalizedDate : null;
        }

        private static bool IsEmptyRow(DataRow row)
        {
            return row.ItemArray.All(c => c == null || string.IsNullOrWhiteSpace(c.ToString()));
        }

        private static decimal GetDecimal(object value)
        {
            if (value == null || value == DBNull.Value)
                return 0m;

            if (value is decimal dec) return dec;
            if (value is double d) return (decimal)d;
            if (value is float f) return (decimal)f;
            if (value is int i) return i;
            if (value is long l) return l;

            string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
            return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
        }

        internal static string NormalizeHeader(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : string.Join(" ", value.Trim()
                    .Replace("_", " ")
                    .Replace(":", string.Empty)
                    .Replace("*", string.Empty)
                    .Split(' ')
                    .Where(s => !string.IsNullOrWhiteSpace(s)));
        }

        internal static string NormalizeKey(string value)
        {
            if (TryNormalizeDate(value, out string normalizedDate))
                return normalizedDate;

            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : string.Join(" ", value.Trim().Split(' ').Where(s => !string.IsNullOrWhiteSpace(s))).ToUpperInvariant();
        }

        internal static bool IsIdentifierHeader(string headerName)
        {
            if (string.IsNullOrWhiteSpace(headerName))
                return false;

            return headerName.Contains("DEPT", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("NUM", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("GROUP", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("DESCRIPTION", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("STAT", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("DATE", StringComparison.OrdinalIgnoreCase)
                || headerName.Equals("DT", StringComparison.OrdinalIgnoreCase)
                || headerName.Equals("ACTIVITY DATE", StringComparison.OrdinalIgnoreCase)
                || headerName.Equals("DAY", StringComparison.OrdinalIgnoreCase);
        }

        private static bool TryNormalizeDate(object value, out string normalizedDate)
        {
            normalizedDate = string.Empty;
            if (value == null || value == DBNull.Value)
                return false;

            if (value is DateTime dateValue)
            {
                normalizedDate = dateValue.ToString("yyyy-MM-dd");
                return true;
            }

            if (value is double doubleValue && doubleValue > 30000 && doubleValue < 60000)
            {
                normalizedDate = DateTime.FromOADate(doubleValue).ToString("yyyy-MM-dd");
                return true;
            }

            if (value is int intValue && intValue > 30000 && intValue < 60000)
            {
                normalizedDate = DateTime.FromOADate(intValue).ToString("yyyy-MM-dd");
                return true;
            }

            string text = value.ToString()?.Trim();
            if (string.IsNullOrWhiteSpace(text) || text.Contains("#"))
                return false;

            if (DateTime.TryParse(text, out DateTime date))
            {
                normalizedDate = date.ToString("yyyy-MM-dd");
                return true;
            }

            string currentYearValue = $"{text}-{DateTime.Now.Year}";
            if (DateTime.TryParse(currentYearValue, out date))
            {
                normalizedDate = date.ToString("yyyy-MM-dd");
                return true;
            }

            return false;
        }

        private static bool IsNumericValueHeader(string headerName)
        {
            if (string.IsNullOrWhiteSpace(headerName))
                return false;

            return headerName.Contains("ACTUAL", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("TARGET", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("VARIANCE", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("VOLUME", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("UOS", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("HRS", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("HOURS", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("FTE", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("PROD", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("PAID", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("CONTRACT", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("OT", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("PERCENT", StringComparison.OrdinalIgnoreCase)
                || headerName.Contains("%", StringComparison.OrdinalIgnoreCase);
        }
    }
}
