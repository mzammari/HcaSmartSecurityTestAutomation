using System;
using System;
using System.Collections.Generic;

namespace ISAS_Regression_Automation
{
    public class DailyStaffingPaidHoursSummaryData
    {
        public string DeptGroupNum { get; set; }
        public string DepartmentGroupName { get; set; }
        public string StatisticDescription { get; set; }
        public decimal TargetProdHoursUOS { get; set; }
        public decimal TargetPaidHoursUOS { get; set; }
        public decimal TargetSvProdFtes { get; set; }
        public decimal ActualUOS { get; set; }
        public decimal ProductiveHoursTarget { get; set; }
        public decimal ProductiveHoursActual { get; set; }
        public decimal ProductiveHoursVariance { get; set; }
        public decimal PaidHoursTarget { get; set; }
        public decimal PaidHoursActual { get; set; }
        public decimal PaidHoursVariance { get; set; }
        public decimal CumulativeUOS { get; set; }
        public decimal CumulativeProductiveHoursTarget { get; set; }
        public decimal CumulativeProductiveHoursActual { get; set; }
        public decimal CumulativePaidHoursTarget { get; set; }
        public decimal CumulativePaidHoursActual { get; set; }
        public decimal CumulativeProductiveHoursVariance { get; set; }
        public decimal CumulativePaidHoursVariance { get; set; }
        public decimal CumulativeNegativeVariance { get; set; }
        public decimal OvertimeFtes { get; set; }
        public decimal OvertimePercent { get; set; }
        public decimal HwsContractProdHours { get; set; }
        public decimal VendorContractProdHours { get; set; }
        public decimal ContractFtes { get; set; }
        public decimal ContractPercent { get; set; }
        public decimal ProductiveIndexPercent { get; set; }
        public decimal PaidIndexPercent { get; set; }
        public decimal TargetMinimumHours { get; set; }
        public decimal PRNFtes { get; set; }
        public decimal PRNPercent { get; set; }
        public HashSet<string> AvailableFields { get; set; } = new HashSet<string>();
    }

    public class DailyStaffingPaidHoursSummaryReportCriteria
    {
        public string ReportType { get; set; }
        public string ReportPeriod { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
