﻿using OpenQA.Selenium;
using RazorEngine.Compilation.ImpromptuInterface.Optimization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
   public class DailyTrendReport
   {
        public static void GoTo()
        {
            FpcReportMenu.DailyTrendReport.SelectDailyTrendReport();
            CommonFunctions.AddTestStep("Select Daily Trend Report ", "The Daily Trend Report is displayed");
        }

        public static bool IsAt
        {
            get
            {
                By byReportType = By.XPath("//select[@id='ddlReportType'] ");
                CommonFunctions.AddTestStep("Verify the Daily Trend Report  page is active", "The plan page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byReportType, 20);
            }
        }

        public static DailyTrendReportCommand dailyTrendReport()
        {
            return new DailyTrendReportCommand();

        }

   }
    #region: DailyTrendReportCommand
    public class DailyTrendReportCommand
    {
        private string reportType;
        private string reportPeriod;
        private string deptgroupSelection;
        private string department;

        public DailyTrendReportCommand withReportType(string ReportType)
        {
            this.reportType = ReportType;
            return this;
        }

        public DailyTrendReportCommand withReportPeriod(string ReportPeriod)
        {
            this.reportPeriod = ReportPeriod;
            return this;
        }

        public DailyTrendReportCommand withDeptgroupSelection(string DeptgroupSelection)
        {
            this.deptgroupSelection = DeptgroupSelection;
            return this;
        }

        public DailyTrendReportCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        private void setReportType()
        {
            By byReportType = By.XPath("//select[@id='ddlReportType']");
            IWebElement mnuReportType = CommonFunctions.getElement(byReportType);
            CommonFunctions.SelectItemFromDropdownMenu(mnuReportType, reportType);
            CommonFunctions.AddTestStep($"Verify a user can select {reportType} from Report Type dropdown", $"The {reportType} is selected correctly");
        }

        private void setReportPeriod()
        {
            By byReportPeriod = By.XPath("//select[@id='payPeriodID']");
            IWebElement mnuReportPeriod = CommonFunctions.getElement(byReportPeriod);
            CommonFunctions.SelectItemFromDropdownMenu(mnuReportPeriod, reportPeriod);
            CommonFunctions.AddTestStep($"Verify a user can select {reportPeriod} from Report Period dropdown", $"The {reportPeriod} is selected correctly");
        }

        private void setDeptgroupSelection()
        {
            By byDeptgroupSelection = By.XPath("//select[@id='DeptGroupSelId']");
            IWebElement mnuDeptgroupSelection = CommonFunctions.getElement(byDeptgroupSelection);
            CommonFunctions.SelectItemFromDropdownMenu(mnuDeptgroupSelection, deptgroupSelection);
            CommonFunctions.AddTestStep($"Verify a user can select {deptgroupSelection} from DeptGroup Selection dropdown", $"The {deptgroupSelection} is selected correctly");
        }

        private void setDepartment()
        {
            By byDepartment = By.Id("deptList");
            IWebElement mnuDepartment = CommonFunctions.getElement(byDepartment);

            if (department.Equals("the first department in the menu", StringComparison.OrdinalIgnoreCase))
            {
                var option = mnuDepartment.FindElements(By.XPath("option"))
                    .FirstOrDefault(o => !string.IsNullOrWhiteSpace(o.Text)
                        && !o.Text.Contains("Select", StringComparison.OrdinalIgnoreCase)
                        && !string.IsNullOrWhiteSpace(o.GetAttribute("value")));

                if (option == null)
                    throw new InvalidOperationException("No selectable department was found in the Department dropdown.");

                option.Click();
                department = option.Text.Trim();
            }
            else
            {
                CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
            }

            CommonFunctions.WaitTillPageIsComplete();
            CommonFunctions.AddTestStep($"Verify a user can select {department} from Department dropdown", $"The {department} is selected correctly");
        }

        private void clickPDF()
        {
            By byPDF = By.XPath("//img[@title='PDF Format']");
            IWebElement cmdPDF = CommonFunctions.getElement(byPDF);
            CommonFunctions.ClickByJE(cmdPDF);
            CommonFunctions.AddTestStep($"Verify a user can click the PDF button", $"The PDF button is enabled and clickable");
        }

        private void clickExcel()
        {
            By byExcel = By.XPath("//img[@title='Excel Format']");
            IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
            CommonFunctions.ClickByJE(cmdExcel);
            CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
        }



        public void PDF()
        {
            setReportType();
            setReportPeriod();
            setDeptgroupSelection();
            setDepartment();
            clickPDF();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public void Excel()
        {
            setReportType();
            setReportPeriod();
            setDeptgroupSelection();
            setDepartment();
            clickExcel();
            CommonFunctions.WaitUntilPageIsAcive();
        }



    }
    #endregion
}
