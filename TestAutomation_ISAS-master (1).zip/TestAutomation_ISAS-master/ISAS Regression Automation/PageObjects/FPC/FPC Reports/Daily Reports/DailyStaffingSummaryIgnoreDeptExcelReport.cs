using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    public class DailyStaffingSummaryIgnoreDeptData
    {
        public string DeptGroupNum { get; set; }
        public string DepartmentGroupName { get; set; }
        public string StatisticDescription { get; set; }
        public decimal ProdIdxPct { get; set; }
        public decimal VarProdStdHoursUOS { get; set; }
        public decimal SemiVarProdStdFtes { get; set; }
        public decimal UOS { get; set; }
        public decimal TargetProdHours { get; set; }
        public decimal ActualProdHours { get; set; }
        public decimal VarProdHours { get; set; }
        public decimal DailyUOS { get; set; }
        public decimal TargetProdHoursCumulative { get; set; }
        public decimal ActualProdHoursCumulative { get; set; }
        public decimal VarProdHoursCumulative { get; set; }
        public decimal PRNProdHours { get; set; }
        public decimal PRNPercentValue { get; set; }
        public decimal OTProdHours { get; set; }
        public decimal OTPercentValue { get; set; }
        public decimal HwsCLProdHours { get; set; }
        public decimal VendorCLProdHours { get; set; }
        public decimal TotalCLProdHours { get; set; }
        public decimal TotalCLPercent { get; set; }
        public HashSet<string> AvailableFields { get; set; } = new HashSet<string>();
    }

    public class DailyStaffingSummaryIgnoreDeptReportCriteria
    {
        public string ReportType { get; set; }
        public string ReportPeriod { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public static class DailyStaffingSummaryIgnoreDeptExcelReport
    {
        public static List<DailyStaffingSummaryIgnoreDeptData> ParseDailyStaffingSummaryIgnoreDeptExcel(string filePath)
        {
            var result = new List<DailyStaffingSummaryIgnoreDeptData>();
            var allRows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(allRows);

            if (headerRowIndex == -1)
            {
                Console.WriteLine("Could not find Daily Staffing Summary Ignore Dept header row in the Excel file. Treating Excel report as no data.");
                return result;
            }

            var columnMap = BuildColumnMap(allRows[headerRowIndex]);
            int deptColumn = GetColumnIndex(columnMap, "Num", "Dept Group", "Dept Group Num", "Department Number");
            int statisticColumn = GetColumnIndex(columnMap, "Statistic Description", "Statistic");
            int firstMetricColumn = GetFirstMetricColumn(allRows[headerRowIndex], statisticColumn);

            if (deptColumn == -1)
            {
                Console.WriteLine("Could not find department number column in the Daily Staffing Summary Ignore Dept Excel file. Treating Excel report as no data.");
                return result;
            }

            for (int i = headerRowIndex + 1; i < allRows.Count; i++)
            {
                var row = allRows[i];
                if (CommonFunctions.IsEmptyRow(row))
                    continue;

                string deptGroupNum = CommonFunctions.GetStringValue(row, deptColumn);
                if (string.IsNullOrWhiteSpace(deptGroupNum))
                    continue;

                var reportRow = new DailyStaffingSummaryIgnoreDeptData
                {
                    DeptGroupNum = deptGroupNum,
                    DepartmentGroupName = GetStringValue(row, columnMap, "Department / Group Name", "Department Group Name", "Dept / Group Name"),
                    StatisticDescription = GetStringValue(row, columnMap, "Statistic Description", "Statistic"),
                    ProdIdxPct = GetDecimalValue(row, firstMetricColumn),
                    VarProdStdHoursUOS = GetDecimalValue(row, firstMetricColumn + 1),
                    SemiVarProdStdFtes = GetDecimalValue(row, firstMetricColumn + 2),
                    UOS = GetDecimalValue(row, firstMetricColumn + 3),
                    TargetProdHours = GetDecimalValue(row, firstMetricColumn + 4),
                    ActualProdHours = GetDecimalValue(row, firstMetricColumn + 5),
                    VarProdHours = GetDecimalValue(row, firstMetricColumn + 6),
                    DailyUOS = GetDecimalValue(row, firstMetricColumn + 7),
                    TargetProdHoursCumulative = GetDecimalValue(row, firstMetricColumn + 8),
                    ActualProdHoursCumulative = GetDecimalValue(row, firstMetricColumn + 9),
                    VarProdHoursCumulative = GetDecimalValue(row, firstMetricColumn + 10),
                    PRNProdHours = GetDecimalValue(row, firstMetricColumn + 11),
                    PRNPercentValue = GetDecimalValue(row, firstMetricColumn + 12),
                    OTProdHours = GetDecimalValue(row, firstMetricColumn + 13),
                    OTPercentValue = GetDecimalValue(row, firstMetricColumn + 14),
                    HwsCLProdHours = GetDecimalValue(row, firstMetricColumn + 15),
                    VendorCLProdHours = GetDecimalValue(row, firstMetricColumn + 16),
                    TotalCLProdHours = GetDecimalValue(row, firstMetricColumn + 17),
                    TotalCLPercent = GetDecimalValue(row, firstMetricColumn + 18),
                    AvailableFields = GetAvailableFields(allRows[headerRowIndex], firstMetricColumn)
                };

                result.Add(reportRow);
            }

            return result;
        }

        public static DailyStaffingSummaryIgnoreDeptReportCriteria GetReportCriteria(string filePath, string fallbackReportType, string fallbackReportPeriod)
        {
            var allRows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(allRows);
            var headerRows = headerRowIndex > 0 ? allRows.Take(headerRowIndex).ToList() : allRows.Take(10).ToList();
            string reportType = FindReportType(headerRows) ?? fallbackReportType;
            string reportPeriod = FindReportPeriod(headerRows) ?? fallbackReportPeriod;
            var dates = FindDates(headerRows).Distinct().OrderBy(d => d).ToList();

            if (dates.Count == 0)
                throw new InvalidOperationException("Could not find report date values in the Daily Staffing Summary Ignore Dept Excel file.");

            DateTime endDate = dates.Last();
            return new DailyStaffingSummaryIgnoreDeptReportCriteria
            {
                ReportType = reportType,
                ReportPeriod = reportPeriod,
                StartDate = GetStartDate(reportType, endDate),
                EndDate = endDate
            };
        }

        private static int FindHeaderRow(List<object[]> rows)
        {
            for (int i = 0; i < rows.Count; i++)
            {
                string rowText = NormalizeHeader(string.Join(" ", rows[i].Where(c => c != null).Select(c => c.ToString())));
                if ((rowText.Contains("NUM") || rowText.Contains("DEPTGROUP")) && rowText.Contains("STATISTIC"))
                    return i;
            }

            return -1;
        }

        private static Dictionary<string, int> BuildColumnMap(object[] headerRow)
        {
            var columnMap = new Dictionary<string, int>();
            for (int i = 0; i < headerRow.Length; i++)
            {
                string header = NormalizeHeader(headerRow[i]?.ToString());
                if (!string.IsNullOrWhiteSpace(header) && !columnMap.ContainsKey(header))
                    columnMap.Add(header, i);
            }

            return columnMap;
        }

        private static int GetColumnIndex(Dictionary<string, int> columnMap, params string[] headers)
        {
            foreach (string header in headers.Select(NormalizeHeader))
            {
                var match = columnMap.FirstOrDefault(c => c.Key == header || c.Key.Contains(header) || header.Contains(c.Key));
                if (!string.IsNullOrWhiteSpace(match.Key))
                    return match.Value;
            }

            return -1;
        }

        private static string GetStringValue(object[] row, Dictionary<string, int> columnMap, params string[] headers)
        {
            int columnIndex = GetColumnIndex(columnMap, headers);
            return columnIndex == -1 ? string.Empty : CommonFunctions.GetStringValue(row, columnIndex);
        }

        private static decimal GetDecimalValue(object[] row, int columnIndex)
        {
            return columnIndex < 0 || columnIndex >= row.Length ? 0m : CommonFunctions.GetDecimalValue(row, columnIndex);
        }

        private static int GetFirstMetricColumn(object[] headerRow, int statisticColumn)
        {
            int firstMetricColumn = statisticColumn == -1 ? 3 : statisticColumn + 1;
            if (firstMetricColumn < headerRow.Length && NormalizeHeader(headerRow[firstMetricColumn]?.ToString()).Contains("SUBFUNCTION"))
                firstMetricColumn++;

            return firstMetricColumn;
        }

        private static HashSet<string> GetAvailableFields(object[] headerRow, int firstMetricColumn)
        {
            var fields = new HashSet<string>();
            AddAvailableField(fields, headerRow, firstMetricColumn, 0, nameof(DailyStaffingSummaryIgnoreDeptData.ProdIdxPct));
            AddAvailableField(fields, headerRow, firstMetricColumn, 1, nameof(DailyStaffingSummaryIgnoreDeptData.VarProdStdHoursUOS));
            AddAvailableField(fields, headerRow, firstMetricColumn, 2, nameof(DailyStaffingSummaryIgnoreDeptData.SemiVarProdStdFtes));
            AddAvailableField(fields, headerRow, firstMetricColumn, 3, nameof(DailyStaffingSummaryIgnoreDeptData.UOS));
            AddAvailableField(fields, headerRow, firstMetricColumn, 4, nameof(DailyStaffingSummaryIgnoreDeptData.TargetProdHours));
            AddAvailableField(fields, headerRow, firstMetricColumn, 5, nameof(DailyStaffingSummaryIgnoreDeptData.ActualProdHours));
            AddAvailableField(fields, headerRow, firstMetricColumn, 6, nameof(DailyStaffingSummaryIgnoreDeptData.VarProdHours));
            AddAvailableField(fields, headerRow, firstMetricColumn, 7, nameof(DailyStaffingSummaryIgnoreDeptData.DailyUOS));
            AddAvailableField(fields, headerRow, firstMetricColumn, 8, nameof(DailyStaffingSummaryIgnoreDeptData.TargetProdHoursCumulative));
            AddAvailableField(fields, headerRow, firstMetricColumn, 9, nameof(DailyStaffingSummaryIgnoreDeptData.ActualProdHoursCumulative));
            AddAvailableField(fields, headerRow, firstMetricColumn, 10, nameof(DailyStaffingSummaryIgnoreDeptData.VarProdHoursCumulative));
            AddAvailableField(fields, headerRow, firstMetricColumn, 11, nameof(DailyStaffingSummaryIgnoreDeptData.PRNProdHours));
            AddAvailableField(fields, headerRow, firstMetricColumn, 12, nameof(DailyStaffingSummaryIgnoreDeptData.PRNPercentValue));
            AddAvailableField(fields, headerRow, firstMetricColumn, 13, nameof(DailyStaffingSummaryIgnoreDeptData.OTProdHours));
            AddAvailableField(fields, headerRow, firstMetricColumn, 14, nameof(DailyStaffingSummaryIgnoreDeptData.OTPercentValue));
            AddAvailableField(fields, headerRow, firstMetricColumn, 15, nameof(DailyStaffingSummaryIgnoreDeptData.HwsCLProdHours));
            AddAvailableField(fields, headerRow, firstMetricColumn, 16, nameof(DailyStaffingSummaryIgnoreDeptData.VendorCLProdHours));
            AddAvailableField(fields, headerRow, firstMetricColumn, 17, nameof(DailyStaffingSummaryIgnoreDeptData.TotalCLProdHours));
            AddAvailableField(fields, headerRow, firstMetricColumn, 18, nameof(DailyStaffingSummaryIgnoreDeptData.TotalCLPercent));
            return fields;
        }

        private static void AddAvailableField(HashSet<string> fields, object[] headerRow, int firstMetricColumn, int offset, string fieldName)
        {
            int columnIndex = firstMetricColumn + offset;
            if (columnIndex >= 0 && columnIndex < headerRow.Length && !string.IsNullOrWhiteSpace(headerRow[columnIndex]?.ToString()))
                fields.Add(fieldName);
        }

        private static List<object[]> ReadRows(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var allRows = new List<object[]>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                do
                {
                    while (reader.Read())
                    {
                        var row = new object[reader.FieldCount];
                        for (int i = 0; i < reader.FieldCount; i++)
                            row[i] = reader.GetValue(i);

                        allRows.Add(row);
                    }
                } while (reader.NextResult());
            }

            return allRows;
        }

        private static List<DateTime> FindDates(List<object[]> rows)
        {
            var dates = new List<DateTime>();
            foreach (var row in rows)
                foreach (var cell in row)
                    dates.AddRange(GetDatesFromCell(cell));

            return dates;
        }

        private static IEnumerable<DateTime> GetDatesFromCell(object cell)
        {
            if (cell == null)
                yield break;

            if (cell is DateTime date)
            {
                yield return date.Date;
                yield break;
            }

            if (cell is double serialDate && serialDate > 30000 && serialDate < 80000)
            {
                yield return DateTime.FromOADate(serialDate).Date;
                yield break;
            }

            if (cell is int serialDateNumber && serialDateNumber > 30000 && serialDateNumber < 80000)
            {
                yield return DateTime.FromOADate(serialDateNumber).Date;
                yield break;
            }

            string text = cell.ToString();
            if (string.IsNullOrWhiteSpace(text))
                yield break;

            foreach (Match match in Regex.Matches(text, @"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}-\d{1,2}-\d{1,2}\b"))
                if (DateTime.TryParse(match.Value, out DateTime parsedDate))
                    yield return parsedDate.Date;
        }

        private static string FindReportType(List<object[]> rows)
        {
            string text = GetHeaderText(rows);
            if (text.Contains("PAY PERIOD", StringComparison.OrdinalIgnoreCase)) return "Pay Period";
            if (text.Contains("MONTH", StringComparison.OrdinalIgnoreCase)) return "Month";
            if (text.Contains("WEEK", StringComparison.OrdinalIgnoreCase)) return "Week";
            if (text.Contains("DAY", StringComparison.OrdinalIgnoreCase)) return "Day";
            return null;
        }

        private static string FindReportPeriod(List<object[]> rows)
        {
            string text = GetHeaderText(rows);
            if (text.Contains("PREVIOUS", StringComparison.OrdinalIgnoreCase)) return "Previous";
            if (text.Contains("CURRENT", StringComparison.OrdinalIgnoreCase)) return "Current";
            return null;
        }

        private static DateTime GetStartDate(string reportType, DateTime endDate)
        {
            if (reportType.Equals("Month", StringComparison.OrdinalIgnoreCase)) return new DateTime(endDate.Year, endDate.Month, 1);
            if (reportType.Equals("Pay Period", StringComparison.OrdinalIgnoreCase) || reportType.Equals("PayPeriod", StringComparison.OrdinalIgnoreCase) || reportType.Equals("Pay_Period", StringComparison.OrdinalIgnoreCase)) return endDate.AddDays(-13);
            if (reportType.Equals("Week", StringComparison.OrdinalIgnoreCase)) return endDate.AddDays(-6);
            return endDate;
        }

        private static string GetHeaderText(List<object[]> rows)
        {
            return string.Join(" ", rows.SelectMany(r => r).Where(c => c != null).Select(c => c.ToString()));
        }

        private static string NormalizeHeader(string value)
        {
            return Regex.Replace(value ?? string.Empty, @"[^A-Za-z0-9]", string.Empty).ToUpperInvariant();
        }
    }

}
