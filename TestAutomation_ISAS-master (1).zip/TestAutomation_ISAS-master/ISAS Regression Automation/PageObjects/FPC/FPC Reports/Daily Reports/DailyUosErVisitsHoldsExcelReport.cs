using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    public static class DailyUosErVisitsHoldsExcelReport
    {
        public static List<DailyUosErVisitsHoldsData> ParseDailyUosErVisitsHoldsExcel(string filePath)
        {
            var result = new List<DailyUosErVisitsHoldsData>();
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);

            if (headerRowIndex == -1)
            {
                Console.WriteLine("Could not find Daily UOS ER Visits Holds column names in the Excel file. Validation will be skipped.");
                return result;
            }

            var columnMap = BuildColumnMap(rows[headerRowIndex]);
            if (!columnMap.ContainsKey(nameof(DailyUosErVisitsHoldsData.Date)))
            {
                Console.WriteLine("Date column is not available in Excel. Validation will be skipped.");
                return result;
            }

            for (int i = headerRowIndex + 1; i < rows.Count; i++)
            {
                var row = rows[i];
                if (CommonFunctions.IsEmptyRow(row))
                    continue;

                if (!TryGetDate(row, columnMap[nameof(DailyUosErVisitsHoldsData.Date)], out DateTime date))
                    continue;

                result.Add(new DailyUosErVisitsHoldsData
                {
                    Date = date,
                    UOS = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.UOS)),
                    ProductiveTargetHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ProductiveTargetHours)),
                    FtPtRegularHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.FtPtRegularHours)),
                    PrnRegularHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.PrnRegularHours)),
                    SharedInRegularHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.SharedInRegularHours)),
                    SharedOutRegularHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.SharedOutRegularHours)),
                    OvertimeHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.OvertimeHours)),
                    SharedInOvertimeHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.SharedInOvertimeHours)),
                    ContractHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ContractHours)),
                    ProductiveActualHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ProductiveActualHours)),
                    ProductiveHoursVariance = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ProductiveHoursVariance)),
                    ProductiveIndexPercent = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ProductiveIndexPercent)),
                    ProductiveFtes = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ProductiveFtes)),
                    ProductiveTargetHoursUOS = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ProductiveTargetHoursUOS)),
                    ProductiveActualHoursUOS = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ProductiveActualHoursUOS)),
                    SharedOutOvertimeHours = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.SharedOutOvertimeHours)),
                    ErVisits = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.ErVisits)),
                    MsHolds = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.MsHolds)),
                    IcuHolds = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.IcuHolds)),
                    WeightedMsVisits = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.WeightedMsVisits)),
                    WeightedIcuVisits = GetDecimal(row, columnMap, nameof(DailyUosErVisitsHoldsData.WeightedIcuVisits)),
                    AvailableFields = columnMap.Keys.ToHashSet()
                });
            }

            return result;
        }

        public static bool HasValidationColumns(string filePath)
        {
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            if (headerRowIndex == -1)
                return false;

            var columnMap = BuildColumnMap(rows[headerRowIndex]);
            return columnMap.ContainsKey(nameof(DailyUosErVisitsHoldsData.Date))
                && columnMap.Keys.Any(k => k != nameof(DailyUosErVisitsHoldsData.Date));
        }

        public static DailyUosErVisitsHoldsReportCriteria GetReportCriteria(string filePath, string fallbackReportType, string fallbackReportPeriod, int fallbackDepartmentNumber = 780)
        {
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            var headerRows = headerRowIndex > 0 ? rows.Take(headerRowIndex).ToList() : rows.Take(10).ToList();
            var excelData = ParseDailyUosErVisitsHoldsExcel(filePath);
            var dates = excelData.Select(r => r.Date).Distinct().OrderBy(d => d).ToList();

            if (dates.Count == 0)
                dates = FindDates(headerRows).Distinct().OrderBy(d => d).ToList();

            if (dates.Count == 0)
                throw new InvalidOperationException("Could not find report date values in the Daily UOS ER Visits Holds Excel file.");

            string reportType = FindReportType(headerRows) ?? fallbackReportType;

            return new DailyUosErVisitsHoldsReportCriteria
            {
                ReportType = reportType,
                ReportPeriod = FindReportPeriod(headerRows) ?? fallbackReportPeriod,
                DepartmentNumber = FindDepartmentNumber(headerRows) ?? fallbackDepartmentNumber,
                StartDate = dates.First(),
                EndDate = dates.Last()
            };
        }

        private static Dictionary<string, int> BuildColumnMap(object[] headerRow)
        {
            var columnMap = new Dictionary<string, int>();

            for (int i = 0; i < headerRow.Length; i++)
            {
                string header = NormalizeHeader(headerRow[i]?.ToString());
                if (string.IsNullOrWhiteSpace(header))
                    continue;

                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.Date), "DT", "DATE");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.UOS), "ACTUOS", "UOS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ProductiveTargetHours), "TGTPRODHRSTOTAL1", "PRODUCTIVETARGETHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.FtPtRegularHours), "ACTPRODHRSSTAFF", "FTPTREGULARHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.PrnRegularHours), "ACTPRODHRSPRN", "PRNREGULARHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.SharedInRegularHours), "PRODHOURSIN", "SHAREDINREGULARHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.SharedOutRegularHours), "PRODHOURSOUT", "SHAREDOUTREGULARHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.OvertimeHours), "ACTPRODHRSOT", "OVERTIMEHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.SharedInOvertimeHours), "OVERTIMEHOURSIN", "SHAREDINOVERTIMEHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ContractHours), "ACTPRODHRSCONTR", "CONTRACTHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ProductiveActualHours), "ACTPRODHRSTOTAL", "PRODUCTIVEACTUALHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ProductiveHoursVariance), "VARPRODHRS", "PRODUCTIVEHOURSVARIANCE");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ProductiveIndexPercent), "PCTPRODINDEX", "PRODUCTIVEINDEXTGTACT", "PRODUCTIVEINDEX");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ProductiveFtes), "ACTPRODFTES", "PRODUCTIVEFTES");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ProductiveTargetHoursUOS), "TGTPRODHRSUOS", "PRODUCTIVETARGETHOURSUOS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ProductiveActualHoursUOS), "ACTPRODHRSUOS", "PRODUCTIVEACTUALHOURSUOS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.SharedOutOvertimeHours), "OVERTIMEHOURSOUT", "SHAREDOUTOVERTIMEHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.ErVisits), "ERVISITS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.MsHolds), "MSHOLD", "MSHOLDS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.IcuHolds), "ICUHOLD", "ICUHOLDS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.WeightedMsVisits), "WEIGHTEDMSHOLD", "WEIGHTEDMSVISITS");
                AddIfMatches(columnMap, header, i, nameof(DailyUosErVisitsHoldsData.WeightedIcuVisits), "WEIGHTEDICUHOLD", "WEIGHTEDICUVISITS");
            }

            return columnMap;
        }

        private static void AddIfMatches(Dictionary<string, int> columnMap, string header, int index, string fieldName, params string[] aliases)
        {
            if (!columnMap.ContainsKey(fieldName) && aliases.Any(alias => header == alias))
                columnMap[fieldName] = index;
        }

        private static int FindHeaderRow(List<object[]> rows)
        {
            for (int i = 0; i < rows.Count; i++)
            {
                var row = rows[i];
                bool hasDate = row.Any(c => NormalizeHeader(c?.ToString()) == "DATE" || NormalizeHeader(c?.ToString()) == "DT");
                bool hasMetric = row.Any(c => NormalizeHeader(c?.ToString()) == "UOS" || NormalizeHeader(c?.ToString()) == "ACTUOS");

                if (hasDate && hasMetric)
                    return i;
            }

            return -1;
        }

        private static List<object[]> ReadRows(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var allRows = new List<object[]>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                do
                {
                    while (reader.Read())
                    {
                        var row = new object[reader.FieldCount];
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row[i] = reader.GetValue(i);
                        }

                        allRows.Add(row);
                    }
                } while (reader.NextResult());
            }

            return allRows;
        }

        private static decimal GetDecimal(object[] row, Dictionary<string, int> columnMap, string fieldName)
        {
            return columnMap.TryGetValue(fieldName, out int index) && index < row.Length
                ? CommonFunctions.GetDecimalValue(row, index)
                : 0m;
        }

        private static bool TryGetDate(object[] row, int index, out DateTime date)
        {
            date = default;
            if (index >= row.Length || row[index] == null)
                return false;

            if (row[index] is DateTime dateValue)
            {
                date = dateValue.Date;
                return true;
            }

            if (row[index] is double serialDate && serialDate > 30000 && serialDate < 80000)
            {
                date = DateTime.FromOADate(serialDate).Date;
                return true;
            }

            return DateTime.TryParse(row[index].ToString(), out date);
        }

        private static string FindReportType(List<object[]> rows)
        {
            string text = GetHeaderText(rows);

            if (text.Contains("PAY PERIOD", StringComparison.OrdinalIgnoreCase))
                return "Pay Period";

            if (text.Contains("MONTH", StringComparison.OrdinalIgnoreCase))
                return "Month";

            if (text.Contains("WEEK", StringComparison.OrdinalIgnoreCase))
                return "Week";

            if (text.Contains("DAY", StringComparison.OrdinalIgnoreCase))
                return "Day";

            return null;
        }

        private static string FindReportPeriod(List<object[]> rows)
        {
            string text = GetHeaderText(rows);

            if (text.Contains("PREVIOUS", StringComparison.OrdinalIgnoreCase))
                return "Previous";

            if (text.Contains("CURRENT", StringComparison.OrdinalIgnoreCase))
                return "Current";

            return null;
        }

        private static int? FindDepartmentNumber(List<object[]> rows)
        {
            string text = GetHeaderText(rows);
            var match = Regex.Match(text, @"(?:Department|Dept)\D+(\d{2,6})", RegexOptions.IgnoreCase);
            return match.Success && int.TryParse(match.Groups[1].Value, out int departmentNumber)
                ? departmentNumber
                : null;
        }

        private static List<DateTime> FindDates(List<object[]> rows)
        {
            var dates = new List<DateTime>();

            foreach (var row in rows)
            {
                foreach (var cell in row)
                {
                    dates.AddRange(GetDatesFromCell(cell));
                }
            }

            return dates;
        }

        private static IEnumerable<DateTime> GetDatesFromCell(object cell)
        {
            if (cell == null)
                yield break;

            if (cell is DateTime date)
            {
                yield return date.Date;
                yield break;
            }

            if (cell is double serialDate && serialDate > 30000 && serialDate < 80000)
            {
                yield return DateTime.FromOADate(serialDate).Date;
                yield break;
            }

            string text = cell.ToString();
            if (string.IsNullOrWhiteSpace(text))
                yield break;

            foreach (Match match in Regex.Matches(text, @"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}-\d{1,2}-\d{1,2}\b"))
            {
                if (DateTime.TryParse(match.Value, out DateTime parsedDate))
                    yield return parsedDate.Date;
            }
        }

        private static string GetHeaderText(List<object[]> rows)
        {
            return string.Join(" ", rows.SelectMany(r => r).Where(c => c != null).Select(c => c.ToString()));
        }

        private static string NormalizeHeader(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : Regex.Replace(value, "[^A-Za-z0-9]", string.Empty).ToUpperInvariant();
        }
    }
}
