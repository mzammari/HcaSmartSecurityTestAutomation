using System;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingSummaryIgnoreDeptSP
    {
        public static string GetDailyStaffingSummaryIgnoreDeptQuery(string reportType, string reportPeriod, DateTime startDate, DateTime endDate)
        {
            string startDateText = startDate.ToString("yyyy-MM-dd");
            string endDateText = endDate.ToString("yyyy-MM-dd");
            const int unitNumber = 1406;

            return $@"SELECT DDA.DEPT_OR_GROUP_NUM,
            DPT.DEPT_DESC                     AS DEPT_OR_GROUP_DESC,
            STRIP(SUBSTR(STA.STAT_DESC,1,30)) AS STAT_DESC,
            ROUND(DDA.TGT_PROD_HRS_UOS,3)     AS TGT_PROD_HRS_UOS,
            ROUND(DDA.TGT_SV_PROD_FTES,2)     AS TGT_SV_PROD_FTES,
            DDA.ACT_UOS,
            ROUND(DDA.TGT_PRODHRS_TOTAL, 2)   AS F_TGT,
            ROUND(DDA.ACT_PRODHRS_TOTAL, 2)   AS F_ACT,
            (ROUND(DDA.TGT_PRODHRS_TOTAL, 2) - 
             ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_VAR,
            DDA_BASE.F_CUM_UOS,
            DDA_BASE.F_CUM_TGT,
            DDA_BASE.F_CUM_ACT,
            (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT) AS F_CUM_VAR,
            DDA_BASE.F_CUM_OT,
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0
                  ELSE (DEC(DDA_BASE.F_CUM_OT,10,2) /
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100
             END) AS F_CUM_OT_PCT,
            DDA_BASE.F_CUM_HWS_CONTR, 
            DDA_BASE.F_CUM_VEN_CONTR, 
            DDA_BASE.F_CUM_CONTR,
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0
                  ELSE (DEC(DDA_BASE.F_CUM_CONTR,10,2) /
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100
             END) AS F_CUM_CONTR_PCT,
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0
                  ELSE (DEC(DDA_BASE.F_CUM_TGT,10,2) /
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100
             END) AS F_CUM_PROD_INDEX,
            CASE WHEN TGT.TARGET_MIN_HOURS IS NULL THEN 0
                 ELSE TGT.TARGET_MIN_HOURS
            END  AS TARGET_MIN_HOURS,
            DDA_BASE.F_CUM_PRN, 
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                  ELSE (DEC(DDA_BASE.F_CUM_PRN,10,2) / 
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
             END) AS F_CUM_PRN_PCT 
     FROM    H.LPBDDA DDA
            LEFT OUTER JOIN  H.LPBTGM TGM
              ON DDA.UNIT_NUM = TGM.UNIT_NUM AND
                 DDA.DEPT_OR_GROUP_NUM = TGM.DEPT_OR_GROUP_NUM AND
                 SUBSTR(VARCHAR(TGM.EFF_MONTH_DATE),1,7) = 
                   SUBSTR(VARCHAR('{endDateText}'),1,7)
            LEFT OUTER JOIN  H.LPBTGT TGT
              ON TGM.TARGET_ID = TGT.TARGET_ID
            INNER JOIN (SELECT DDA.UNIT_NUM,
                               DDA.DEPT_OR_GROUP_NUM,
                               SUM(DDA.ACT_UOS)                     AS F_CUM_UOS,
                               SUM(ROUND(DDA.TGT_PRODHRS_TOTAL, 2)) AS F_CUM_TGT,
                               SUM(ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_CUM_ACT,
                               SUM(ROUND(DDA.ACT_PRODHRS_OT, 2))    AS F_CUM_OT,
                               SUM(ROUND(DDA.ACT_HWS_PRODHRS_CONTR, 2)) AS F_CUM_HWS_CONTR, 
                               SUM(ROUND(DDA.ACT_VEN_PRODHRS_CONTR, 2)) AS F_CUM_VEN_CONTR, 
                               SUM(ROUND(DDA.ACT_PRODHRS_CONTR, 2)) AS F_CUM_CONTR,
                               SUM(ROUND(DDA.ACT_PRODHRS_PRN + DDA.ACT_OT_PRN, 2)) AS F_CUM_PRN 
                        FROM    H.LPBDDA DDA
                        WHERE  (DDA.UNIT_NUM = {unitNumber} AND
                                DDA.DEPT_OR_GROUP_NUM IN (SELECT DISTINCT
                                    CASE WHEN DPT.GROUP_NUM <> 0 THEN DPT.GROUP_NUM
                                         ELSE DPT.DEPT_NUM
                                    END AS DEPT_OR_GROUP_NUM
                                    FROM H.LPBDPT DPT
                                    WHERE DPT.UNIT_NUM = {unitNumber}
                                      AND DPT.IGNORE_DEPT = 'Y') AND
                                DDA.ACTIVITY_DATE BETWEEN '{startDateText}' AND '{endDateText}')
                        GROUP  BY DDA.UNIT_NUM,
                                  DDA.DEPT_OR_GROUP_NUM) DDA_BASE
              ON DDA.UNIT_NUM = DDA_BASE.UNIT_NUM AND
                 DDA.DEPT_OR_GROUP_NUM = DDA_BASE.DEPT_OR_GROUP_NUM
            INNER JOIN  H.LPBDPT DPT
              ON DDA.UNIT_NUM = DPT.UNIT_NUM AND
                 DDA.DEPT_OR_GROUP_NUM = DPT.DEPT_NUM
            LEFT OUTER JOIN  H.LPBGPD GPD
              ON DDA.UNIT_NUM = GPD.UNIT_NUM AND
                 DDA.DEPT_OR_GROUP_NUM = GPD.GROUP_NUM
            INNER JOIN  H.LPBSTA STA
              ON DPT.STAT_ID = STA.STAT_ID
     WHERE  (DDA.UNIT_NUM = {unitNumber} AND
             DDA.DEPT_OR_GROUP_NUM IN (SELECT DISTINCT
                CASE WHEN DPT.GROUP_NUM <> 0 THEN DPT.GROUP_NUM
                     ELSE DPT.DEPT_NUM
                END AS DEPT_OR_GROUP_NUM
                FROM H.LPBDPT DPT
                WHERE DPT.UNIT_NUM = {unitNumber}
                  AND DPT.IGNORE_DEPT = 'Y') AND
             DDA.ACTIVITY_DATE = '{endDateText}') AND
            (GPD.SHARED_OUT_FLAG IS NULL OR
             GPD.SHARED_OUT_FLAG <> 'Y')
     UNION ALL
     SELECT DDA.DEPT_OR_GROUP_NUM,
            GPD.GROUP_DESC                    AS DEPT_OR_GROUP_DESC,
            STRIP(SUBSTR(STA.STAT_DESC,1,30)) AS STAT_DESC,
            ROUND(DDA.TGT_PROD_HRS_UOS,3)     AS TGT_PROD_HRS_UOS,
            ROUND(DDA.TGT_SV_PROD_FTES,2)     AS TGT_SV_PROD_FTES,
            DDA.ACT_UOS,
            ROUND(DDA.TGT_PRODHRS_TOTAL, 2)   AS F_TGT,
            ROUND(DDA.ACT_PRODHRS_TOTAL, 2)   AS F_ACT,
            (ROUND(DDA.TGT_PRODHRS_TOTAL, 2) - 
             ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_VAR,
            DDA_BASE.F_CUM_UOS,
            DDA_BASE.F_CUM_TGT,
            DDA_BASE.F_CUM_ACT,
            (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT) AS F_CUM_VAR,
            DDA_BASE.F_CUM_OT,
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0
                  ELSE (DEC(DDA_BASE.F_CUM_OT,10,2) /
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100
             END) AS F_CUM_OT_PCT,
            DDA_BASE.F_CUM_HWS_CONTR, 
            DDA_BASE.F_CUM_VEN_CONTR, 
            DDA_BASE.F_CUM_CONTR,
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0
                  ELSE (DEC(DDA_BASE.F_CUM_CONTR,10,2) /
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100
             END) AS F_CUM_CONTR_PCT,
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0
                  ELSE (DEC(DDA_BASE.F_CUM_TGT,10,2) /
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100
             END) AS F_CUM_PROD_INDEX,
            CASE WHEN TGT.TARGET_MIN_HOURS IS NULL THEN 0
                 ELSE TGT.TARGET_MIN_HOURS
            END  AS TARGET_MIN_HOURS,
            DDA_BASE.F_CUM_PRN, 
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                  ELSE (DEC(DDA_BASE.F_CUM_PRN,10,2) / 
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
             END) AS F_CUM_PRN_PCT 
     FROM    H.LPBDDA DDA
            LEFT OUTER JOIN  H.LPBTGM TGM
              ON DDA.UNIT_NUM = TGM.UNIT_NUM AND
                 DDA.DEPT_OR_GROUP_NUM = TGM.DEPT_OR_GROUP_NUM AND
                 SUBSTR(VARCHAR(TGM.EFF_MONTH_DATE),1,7) = 
                   SUBSTR(VARCHAR('{endDateText}'),1,7)
            LEFT OUTER JOIN  H.LPBTGT TGT
              ON TGM.TARGET_ID = TGT.TARGET_ID
            INNER JOIN (SELECT DDA.UNIT_NUM,
                               DDA.DEPT_OR_GROUP_NUM,
                               SUM(DDA.ACT_UOS)                     AS F_CUM_UOS,
                               SUM(ROUND(DDA.TGT_PRODHRS_TOTAL, 2)) AS F_CUM_TGT,
                               SUM(ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_CUM_ACT,
                               SUM(ROUND(DDA.ACT_PRODHRS_OT, 2))    AS F_CUM_OT,
                               SUM(ROUND(DDA.ACT_HWS_PRODHRS_CONTR, 2)) AS F_CUM_HWS_CONTR, 
                               SUM(ROUND(DDA.ACT_VEN_PRODHRS_CONTR, 2)) AS F_CUM_VEN_CONTR, 
                               SUM(ROUND(DDA.ACT_PRODHRS_CONTR, 2)) AS F_CUM_CONTR,
                               SUM(ROUND(DDA.ACT_PRODHRS_PRN + DDA.ACT_OT_PRN, 2)) AS F_CUM_PRN 
                        FROM    H.LPBDDA DDA
                        WHERE  (DDA.UNIT_NUM = {unitNumber} AND
                                DDA.DEPT_OR_GROUP_NUM IN (SELECT DISTINCT
                                    CASE WHEN DPT.GROUP_NUM <> 0 THEN DPT.GROUP_NUM
                                         ELSE DPT.DEPT_NUM
                                    END AS DEPT_OR_GROUP_NUM
                                    FROM H.LPBDPT DPT
                                    WHERE DPT.UNIT_NUM = {unitNumber}
                                      AND DPT.IGNORE_DEPT = 'Y') AND
                                DDA.ACTIVITY_DATE BETWEEN '{startDateText}' AND '{endDateText}')
                        GROUP  BY DDA.UNIT_NUM,
                                  DDA.DEPT_OR_GROUP_NUM) DDA_BASE
              ON DDA.UNIT_NUM = DDA_BASE.UNIT_NUM AND
                 DDA.DEPT_OR_GROUP_NUM = DDA_BASE.DEPT_OR_GROUP_NUM
            INNER JOIN  H.LPBGPD GPD
              ON DDA.UNIT_NUM = GPD.UNIT_NUM AND
                 DDA.DEPT_OR_GROUP_NUM = GPD.GROUP_NUM
            INNER JOIN  H.LPBSTA STA
              ON GPD.STAT_ID = STA.STAT_ID
     WHERE  (DDA.UNIT_NUM = {unitNumber} AND
             DDA.DEPT_OR_GROUP_NUM IN (SELECT DISTINCT
                CASE WHEN DPT.GROUP_NUM <> 0 THEN DPT.GROUP_NUM
                     ELSE DPT.DEPT_NUM
                END AS DEPT_OR_GROUP_NUM
                FROM H.LPBDPT DPT
                WHERE DPT.UNIT_NUM = {unitNumber}
                  AND DPT.IGNORE_DEPT = 'Y') AND
             DDA.ACTIVITY_DATE = '{endDateText}') AND
            (GPD.SHARED_OUT_FLAG IS NULL OR
             GPD.SHARED_OUT_FLAG <> 'Y')
     ORDER BY DEPT_OR_GROUP_NUM";
        }

    }
}
