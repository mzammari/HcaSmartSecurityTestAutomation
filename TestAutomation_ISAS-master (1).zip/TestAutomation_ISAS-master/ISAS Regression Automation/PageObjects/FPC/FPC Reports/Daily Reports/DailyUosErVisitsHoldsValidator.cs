using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class DailyUosErVisitsHoldsValidator
    {
        public static void Validate(List<DailyUosErVisitsHoldsData> excelData, List<DailyUosErVisitsHoldsData> dbData)
        {
            Console.WriteLine("=== Daily UOS ER Visits Holds Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                return;
            }

            var mismatches = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;
            int skippedRows = 0;
            int skippedFields = 0;

            foreach (var dbRow in dbData)
            {
                var excelRow = excelData.FirstOrDefault(e => e.Date.Date == dbRow.Date.Date);

                if (excelRow == null)
                {
                    skippedRows++;
                    continue;
                }

                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.UOS), excelRow.UOS, dbRow.UOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ProductiveTargetHours), excelRow.ProductiveTargetHours, dbRow.ProductiveTargetHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.FtPtRegularHours), excelRow.FtPtRegularHours, dbRow.FtPtRegularHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.PrnRegularHours), excelRow.PrnRegularHours, dbRow.PrnRegularHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.SharedInRegularHours), excelRow.SharedInRegularHours, dbRow.SharedInRegularHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.SharedOutRegularHours), excelRow.SharedOutRegularHours, dbRow.SharedOutRegularHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.OvertimeHours), excelRow.OvertimeHours, dbRow.OvertimeHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.SharedInOvertimeHours), excelRow.SharedInOvertimeHours, dbRow.SharedInOvertimeHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ContractHours), excelRow.ContractHours, dbRow.ContractHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ProductiveActualHours), excelRow.ProductiveActualHours, dbRow.ProductiveActualHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ProductiveHoursVariance), excelRow.ProductiveHoursVariance, dbRow.ProductiveHoursVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ProductiveIndexPercent), excelRow.ProductiveIndexPercent, dbRow.ProductiveIndexPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ProductiveFtes), excelRow.ProductiveFtes, dbRow.ProductiveFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ProductiveTargetHoursUOS), excelRow.ProductiveTargetHoursUOS, dbRow.ProductiveTargetHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ProductiveActualHoursUOS), excelRow.ProductiveActualHoursUOS, dbRow.ProductiveActualHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.SharedOutOvertimeHours), excelRow.SharedOutOvertimeHours, dbRow.SharedOutOvertimeHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.ErVisits), excelRow.ErVisits, dbRow.ErVisits);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.MsHolds), excelRow.MsHolds, dbRow.MsHolds);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.IcuHolds), excelRow.IcuHolds, dbRow.IcuHolds);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.WeightedMsVisits), excelRow.WeightedMsVisits, dbRow.WeightedMsVisits);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyUosErVisitsHoldsData.WeightedIcuVisits), excelRow.WeightedIcuVisits, dbRow.WeightedIcuVisits);
            }

            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine("Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");
            Console.WriteLine($"  Skipped DB rows not present in Excel: {skippedRows}");
            Console.WriteLine($"  Skipped fields not present in Excel: {skippedFields}");

            if (totalComparisons == 0)
            {
                Console.WriteLine("No matching Excel columns were available for validation. Validation skipped.");
                return;
            }

            if (mismatches.Count > 0)
            {
                Console.WriteLine("\nMismatches:");
                Console.WriteLine($"{"Date",-12} {"Field",-35} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 75));

                foreach (var mismatch in mismatches)
                {
                    Console.WriteLine(mismatch);
                }

                Assert.Fail($"Daily UOS ER Visits Holds validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons.");
            }

            Console.WriteLine("\nDaily UOS ER Visits Holds validated successfully - all values match.");
        }

        private static void CompareField(
            List<string> mismatches,
            ref int totalComparisons,
            ref int matchCount,
            ref int skippedFields,
            DailyUosErVisitsHoldsData excelRow,
            string fieldName,
            decimal excelValue,
            decimal dbValue)
        {
            if (excelRow.AvailableFields.Any() && !excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            decimal roundedExcelValue = Math.Round(excelValue, 1, MidpointRounding.AwayFromZero);
            decimal roundedDbValue = Math.Round(dbValue, 1, MidpointRounding.AwayFromZero);

            if (roundedExcelValue == roundedDbValue)
            {
                matchCount++;
                return;
            }

            mismatches.Add($"{excelRow.Date:yyyy-MM-dd} {fieldName,-35} {roundedExcelValue,12:N1} {roundedDbValue,12:N1}");
        }
    }
}
