using System;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    /// <summary>
    /// Inline DB2 query for Daily Trend Report.
    /// Parameters from the UI flow: Report Type, Report Period, Dept/Group Selection, Department.
    /// </summary>
    public static class DailyTrendReportSP
    {
        public static string GetDailyTrendReportQuery(string reportType, string reportPeriod, string deptGroupSelection, string department, DateTime startDate, DateTime endDate)
        {
            string facility = RunData.Facility;
            string startDateText = startDate.ToString("yyyy-MM-dd");
            string endDateText = endDate.ToString("yyyy-MM-dd");

            var query = "-- TODO: Replace with actual Daily Trend DB2 inline query" + Environment.NewLine +
                        "-- UI parameters:" + Environment.NewLine +
                        $"-- ReportType = {reportType}" + Environment.NewLine +
                        $"-- ReportPeriod = {reportPeriod}" + Environment.NewLine +
                        $"-- DeptGroupSelection = {deptGroupSelection}" + Environment.NewLine +
                        $"-- Department = {department}" + Environment.NewLine +
                        $"-- Facility = {facility}" + Environment.NewLine +
                        $"-- StartDate = {startDateText}" + Environment.NewLine +
                        $"-- EndDate = {endDateText}" + Environment.NewLine +
                        "-- The query should return the same visible columns as the downloaded Excel report." + Environment.NewLine +
                        "SELECT\r\n    (A.TGT_PRODHRS_TOTAL - A.ACT_PRODHRS_TOTAL) AS Productive_Hours_Variance,\r\n    (A.ACT_PRODHRS_STAFF - ((A.PROD_HOURS_IN - A.PROD_HOURS_OUT) - (A.OVERTIME_HOURS_IN - A.OVERTIME_HOURS_OUT))) AS Productive_Actual_Hours_UOS,\r\n    (A.ACT_PRODHRS_TOTAL + A.ACT_NONPROD_HRS) AS PRODHRS_SUM,\r\n    (A.ACT_PRODHRS_STAFF - ((A.PROD_HOURS_IN - A.PROD_HOURS_OUT) - (A.OVERTIME_HOURS_IN - A.OVERTIME_HOURS_OUT))) AS Regular_Hours1,\r\n    (A.TGT_PRODHRS_TOTAL - A.ACT_PRODHRS_TOTAL) AS PRODHRS_DIFF,\r\n    (A.ACT_PRODHRS_TOTAL + A.ACT_NONPROD_HRS) AS PRODHRS_DIFF_N,\r\n    A.*\r\nFROM (\r\n    SELECT\r\n        X.DT,\r\n        DRV.*,\r\n        (CASE\r\n            WHEN (('2026-03-28' >= X.DT) AND (TGT_PRODHRS_TOTAL1 <= 0))\r\n            THEN 0\r\n            ELSE TGT_PRODHRS_TOTAL1\r\n        END) AS TGT_PRODHRS_TOTAL,\r\n        (CASE\r\n            WHEN (('2026-03-28' >= X.DT) AND (TGT_PRODHRS_TOTAL1 <= 0))\r\n            THEN 1\r\n            ELSE 0\r\n        END) AS ISSTAR_TGT_PRODHRS\r\n    FROM (\r\n        SELECT\r\n            DDA.ACTIVITY_DATE,\r\n            COALESCE(DDA.ACT_UOS, 0) AS ACT_UOS,\r\n            COALESCE(DDA.NON_PROD_HOURS_OUT, 0) AS NON_PROD_HOURS_OUT,\r\n            COALESCE((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR), 0) AS TGT_PRODHRS_TOTAL1,\r\n            '' AS LL3,\r\n            COALESCE((DDA.ACT_PRODHRS_STAFF - DDA.ACT_PRODHRS_PRN - ((DDA.PROD_HOURS_IN - DDA.PROD_HOURS_OUT) - (DDA.OVERTIME_HOURS_IN - DDA.OVERTIME_HOURS_OUT))), 0) AS ACT_PRODHRS_STAFF,\r\n            COALESCE(DDA.ACT_PRODHRS_PRN, 0) AS ACT_PRODHRS_PRN,\r\n            COALESCE((DDA.PROD_HOURS_IN - DDA.OVERTIME_HOURS_IN), 0) AS PROD_HOURS_IN,\r\n            COALESCE(0 - (DDA.PROD_HOURS_OUT - DDA.OVERTIME_HOURS_OUT), 0) AS PROD_HOURS_OUT,\r\n            COALESCE((DDA.ACT_PRODHRS_OT - (DDA.OVERTIME_HOURS_IN - DDA.OVERTIME_HOURS_OUT)), 0) AS ACT_PRODHRS_OT,\r\n            COALESCE(DDA.OVERTIME_HOURS_IN, 0) AS OVERTIME_HOURS_IN,\r\n            COALESCE(0 - DDA.OVERTIME_HOURS_OUT, 0) AS OVERTIME_HOURS_OUT_NEG,\r\n            COALESCE(DDA.ACT_HWS_PRODHRS_CONTR, 0) AS ACT_HWS_PRODHRS_CONTR,\r\n            COALESCE(DDA.ACT_VEN_PRODHRS_CONTR, 0) AS ACT_VEN_PRODHRS_CONTR,\r\n            COALESCE(DDA.ACT_PRODHRS_CONTR, 0) AS ACT_PRODHRS_CONTR,\r\n            COALESCE((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR), 0) AS ACT_PRODHRS_TOTAL,\r\n            COALESCE((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR - DDA.ACT_FTE_ORIENT_HOURS - DDA.ACT_FTE_EDUCAT_HOURS - DDA.ACT_PRN_ORIENT_HOURS - DDA.ACT_PRN_EDUCAT_HOURS), 0) AS ACT_PRODHRS_TOTAL_ExclEduOrie,\r\n            COALESCE(((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR) - (DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR)), 0) AS VAR_PRODHRS,\r\n            CASE\r\n                WHEN COALESCE((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR), 0) = 0 THEN 0\r\n                ELSE ((DEC((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR), 10, 2) /\r\n                       DEC((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR), 10, 2)) * 100)\r\n            END AS PCT_PROD_INDEX,\r\n            CASE\r\n                WHEN COALESCE((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR - DDA.ACT_FTE_ORIENT_HOURS - DDA.ACT_FTE_EDUCAT_HOURS - DDA.ACT_PRN_ORIENT_HOURS - DDA.ACT_PRN_EDUCAT_HOURS), 0) = 0 THEN 0\r\n                ELSE ((DEC((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR), 10, 2) /\r\n                       DEC((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR - DDA.ACT_FTE_ORIENT_HOURS - DDA.ACT_FTE_EDUCAT_HOURS - DDA.ACT_PRN_ORIENT_HOURS - DDA.ACT_PRN_EDUCAT_HOURS), 10, 2)) * 100)\r\n            END AS PCT_PROD_INDEX_EXCL_EDU_ORIENT,\r\n            COALESCE(DDA.ACT_PROD_FTES, 0) AS ACT_PROD_FTES,\r\n            CASE\r\n                WHEN COALESCE(DDA.ACT_UOS, 0) = 0 THEN 0\r\n                ELSE (DEC((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR), 10, 3) / DEC(DDA.ACT_UOS, 10, 3))\r\n            END AS TGT_PROD_HRS_UOS,\r\n            CASE\r\n                WHEN COALESCE(DDA.ACT_UOS, 0) = 0 THEN 0\r\n                ELSE (DEC((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR), 10, 3) / DEC(DDA.ACT_UOS, 10, 3))\r\n            END AS ACT_PROD_HRS_UOS,\r\n            '' AS LL13, '' AS CL14, '' AS CL15, '' AS CL16, '' AS CL17, '' AS LL18,\r\n            COALESCE((DDA.ACT_NONPROD_HRS - (DDA.NON_PROD_HOURS_IN - DDA.NON_PROD_HOURS_OUT)), 0) AS ACT_NONPROD_HRS,\r\n            COALESCE(NON_PROD_HOURS_IN, 0) AS NON_PROD_HOURS_IN,\r\n            0 - NON_PROD_HOURS_OUT AS NON_PROD_HOURS_OUT_NEG,\r\n            COALESCE((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR + DDA.ACT_NONPROD_HRS), 0) AS ACT_PAIDHRS_TOTAL,\r\n            COALESCE((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR + TGT_NONPROD_HRS), 0) AS TGT_PAIDHRS_TOTAL,\r\n            COALESCE(((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR + TGT_NONPROD_HRS) -\r\n                      (DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR + DDA.ACT_NONPROD_HRS)), 0) AS VAR_PAIDHRS,\r\n            CASE\r\n                WHEN COALESCE((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR + DDA.ACT_NONPROD_HRS), 0) = 0 THEN 0\r\n                ELSE ((DEC((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR + TGT_NONPROD_HRS), 10, 2) /\r\n                       DEC((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR + DDA.ACT_NONPROD_HRS), 10, 2)) * 100)\r\n            END AS PCT_PAID_INDEX,\r\n            (DEC((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR + DDA.ACT_NONPROD_HRS), 10, 2) / DEC(8, 10, 2)) AS ACT_PAID_FTES,\r\n            CASE\r\n                WHEN COALESCE(DDA.ACT_UOS, 0) = 0 THEN 0\r\n                ELSE (DEC((DDA.TGT_PRODHRS_STAFF + DDA.TGT_PRODHRS_OT + DDA.TGT_PRODHRS_CONTR + TGT_NONPROD_HRS), 10, 3) / DEC(DDA.ACT_UOS, 10, 3))\r\n            END AS TGT_PAID_HRS_UOS,\r\n            CASE\r\n                WHEN COALESCE(DDA.ACT_UOS, 0) = 0 THEN 0\r\n                ELSE (DEC((DDA.ACT_PRODHRS_STAFF + DDA.ACT_PRODHRS_OT + DDA.ACT_PRODHRS_CONTR + DDA.ACT_NONPROD_HRS), 10, 3) / DEC(DDA.ACT_UOS, 10, 3))\r\n            END AS ACT_PAID_HRS_UOS,\r\n            '' AS LL27, '' AS CL28, '' AS CL29, '' AS CL30, '' AS CL31,\r\n            (DDA.ACT_PRODHRS_STAFF - ((DDA.PROD_HOURS_IN - DDA.PROD_HOURS_OUT) - (DDA.OVERTIME_HOURS_IN - DDA.OVERTIME_HOURS_OUT))) AS Regular_Hours,\r\n            (DDA.ACT_PRODHRS_STAFF - ((DDA.PROD_HOURS_IN - DDA.PROD_HOURS_OUT) - (DDA.OVERTIME_HOURS_IN - DDA.OVERTIME_HOURS_OUT))) AS Productive_Actual_Hours_UOS_N,\r\n            DDA.OVERTIME_HOURS_OUT,\r\n            DDA.ACT_FTE_ORIENT_HOURS,\r\n            DDA.ACT_FTE_EDUCAT_HOURS,\r\n            DDA.ACT_PRN_ORIENT_HOURS,\r\n            DDA.ACT_PRN_EDUCAT_HOURS,\r\n            DDA.ACT_HWS_ORIENT_HOURS,\r\n            DDA.ACT_HWS_EDUCAT_HOURS,\r\n            DDA.ACT_VEN_ORIENT_HOURS,\r\n            DDA.ACT_VEN_EDUCAT_HOURS,\r\n\t\t\tCOALESCE (RHA.ER_VISITS,0) AS ER_VISITS,\r\n\t\t\tCOALESCE (RHA.MS_HOLD,0) AS MS_HOLD,\r\n\t\t\tCOALESCE (RHA.ICU_HOLD,0) AS ICU_HOLD,\r\n\t\t\tCOALESCE (RHA.WEIGHTED_MS_HOLD,0) AS WEIGHTED_MS_HOLD,\r\n\t\t\tCOALESCE (RHA.WEIGHTED_ICU_HOLD,0) AS WEIGHTED_ICU_HOLD\r\n        FROM H.LPBDDA DDA\r\n\t\tLEFT OUTER JOIN H.LPBERHA RHA on DDA.Unit_num = RHA.Unit_num and DDA.DEPT_OR_GROUP_NUM = RHA.Dept_Num and DDA.Activity_Date = RHA.Activity_Date\r\n\r\n\t\t\r\n        WHERE DDA.UNIT_NUM = 1406\r\n          AND DDA.DEPT_OR_GROUP_NUM IN (600)\r\n          AND DDA.ACTIVITY_DATE BETWEEN '2026-07-01' AND '2026-07-14'\r\n    ) AS DRV\r\n    RIGHT OUTER JOIN (\r\n        SELECT DATE('2026-07-01') + 0  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 1  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 2  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 3  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 4  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 5  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 6  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 7  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 8  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 9  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 10 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 11 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 12 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 13 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 14  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 15  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 16 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 17  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 18  DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 19 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 20 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 21 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 22 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 23 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 24 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 24 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 25 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 25 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 26 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 27 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 28 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 29 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        UNION\r\n        SELECT DATE('2026-07-01') + 30 DAY AS DT FROM SYSIBM.SYSDUMMY1\r\n        \r\n            ) X\r\n    ON X.DT = DRV.ACTIVITY_DATE\r\n) A; ";

            query = ApplyDateRange(query, startDate, endDate);
            return query;
        }

        private static string ApplyDateRange(string query, DateTime startDate, DateTime endDate)
        {
            string startDateText = startDate.ToString("yyyy-MM-dd");
            string endDateText = endDate.ToString("yyyy-MM-dd");

            query = Regex.Replace(
                query,
                @"DDA\.ACTIVITY_DATE\s+BETWEEN\s+'\d{4}-\d{2}-\d{2}'\s+AND\s+'\d{4}-\d{2}-\d{2}'",
                $"DDA.ACTIVITY_DATE BETWEEN '{startDateText}' AND '{endDateText}'",
                RegexOptions.IgnoreCase);

            query = Regex.Replace(
                query,
                @"\('\d{4}-\d{2}-\d{2}'\s*>=\s*X\.DT\)",
                $"(DATE('{endDateText}') >= X.DT)",
                RegexOptions.IgnoreCase);

            query = Regex.Replace(
                query,
                @"RIGHT\s+OUTER\s+JOIN\s*\(\s*SELECT\s+DATE\('\d{4}-\d{2}-\d{2}'\).*?\)\s*X\s*\r?\n\s*ON\s+X\.DT\s*=\s*DRV\.ACTIVITY_DATE",
                $"RIGHT OUTER JOIN (\r\n{BuildDateUnion(startDate, endDate)}\r\n    ) X\r\n    ON X.DT = DRV.ACTIVITY_DATE",
                RegexOptions.IgnoreCase | RegexOptions.Singleline);

            return query;
        }

        private static string BuildDateUnion(DateTime startDate, DateTime endDate)
        {
            var builder = new StringBuilder();
            int totalDays = (endDate.Date - startDate.Date).Days;

            for (int dayOffset = 0; dayOffset <= totalDays; dayOffset++)
            {
                if (dayOffset > 0)
                    builder.AppendLine("        UNION");

                builder.Append($"        SELECT DATE('{startDate:yyyy-MM-dd}') + {dayOffset} DAY AS DT FROM SYSIBM.SYSDUMMY1");

                if (dayOffset < totalDays)
                    builder.AppendLine();
            }

            return builder.ToString();
        }
    }
}
