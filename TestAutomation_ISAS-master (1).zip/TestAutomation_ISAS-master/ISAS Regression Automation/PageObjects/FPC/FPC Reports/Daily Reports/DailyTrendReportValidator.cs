using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace ISAS_Regression_Automation
{
    public static class DailyTrendReportValidator
    {
        private const int DECIMAL_PLACES = 1;

        public static void Validate(List<DailyTrendReportData> excelData, List<DailyTrendReportData> dbData)
        {
            Console.WriteLine("=== Daily Trend Report DB2 Reference Validation ===\n");
            Console.WriteLine("Validating Excel data with DB2 data as the source of truth.\n");

            var mismatches = new List<string>();
            int comparedValues = 0;
            int matchedValues = 0;

            for (int dbIndex = 0; dbIndex < dbData.Count; dbIndex++)
            {
                var dbRow = dbData[dbIndex];
                var excelRow = FindMatchingExcelRow(excelData, dbRow.Key, dbIndex, dbData.Count);

                if (excelRow == null)
                {
                    mismatches.Add($"Row '{dbRow.Key}' - NOT FOUND in Excel. Parsed Excel keys: {GetPreviewKeys(excelData)}");
                    continue;
                }

                int matchedColumnsForRow = 0;

                foreach (var dbValue in dbRow.Values)
                {
                    if (ShouldSkipDbColumn(dbValue.Key))
                        continue;

                    if (!TryGetExcelValue(excelRow.Values, dbValue.Key, out decimal excelValue, out string matchedExcelKey))
                    {
                        continue;
                    }

                    matchedColumnsForRow++;

                    decimal roundedExcelValue = Math.Round(Math.Abs(excelValue), DECIMAL_PLACES, MidpointRounding.AwayFromZero);
                    decimal roundedDbValue = Math.Round(Math.Abs(dbValue.Value), DECIMAL_PLACES, MidpointRounding.AwayFromZero);

                    comparedValues++;
                    if (roundedExcelValue == roundedDbValue)
                    {
                        matchedValues++;
                    }
                    else
                    {
                        mismatches.Add($"{dbRow.Key} | DB={dbValue.Key} / Excel={matchedExcelKey}: Excel={roundedExcelValue:N1}, DB={roundedDbValue:N1} (Raw Excel={excelValue:N4}, Raw DB={dbValue.Value:N4})");
                    }
                }

                if (matchedColumnsForRow == 0)
                    mismatches.Add($"Row '{dbRow.Key}' - NO DB2 COLUMNS MATCHED EXCEL METRIC COLUMNS");
            }

            Console.WriteLine("DB2 Reference Validation Summary:");
            Console.WriteLine($"  DB2 values checked in Excel: {comparedValues}");
            Console.WriteLine($"  Matching values: {matchedValues}");
            Console.WriteLine($"  Mismatches/missing values: {mismatches.Count}");

            if (mismatches.Count > 0)
            {
                Console.WriteLine("\nMismatches:");
                foreach (var mismatch in mismatches)
                    Console.WriteLine(mismatch);

                Assert.Fail($"Daily Trend Report validation failed: {mismatches.Count} DB2 reference values did not match Excel.");
            }

            Console.WriteLine("\nDaily Trend Report validated successfully - all DB2 reference values match Excel.");
        }

        private static DailyTrendReportData FindMatchingExcelRow(List<DailyTrendReportData> excelData, string dbKey, int dbIndex, int dbRowCount)
        {
            var exactMatch = excelData.FirstOrDefault(e => e.Key == dbKey);
            if (exactMatch != null)
                return exactMatch;

            if (DateTime.TryParse(dbKey, out DateTime dbDate))
            {
                var sameDateMatch = excelData.FirstOrDefault(e =>
                    DateTime.TryParse(e.Key, out DateTime excelDate) && excelDate.Date == dbDate.Date);

                if (sameDateMatch != null)
                    return sameDateMatch;

                var sameMonthDayMatch = excelData.FirstOrDefault(e =>
                    DateTime.TryParse(e.Key, out DateTime excelDate)
                    && excelDate.Month == dbDate.Month
                    && excelDate.Day == dbDate.Day);

                if (sameMonthDayMatch != null)
                    return sameMonthDayMatch;
            }

            if (excelData.Count == dbRowCount && dbIndex < excelData.Count)
                return excelData[dbIndex];

            return null;
        }

        private static string GetPreviewKeys(List<DailyTrendReportData> excelData)
        {
            return string.Join(", ", excelData.Take(10).Select(e => string.IsNullOrWhiteSpace(e.Key) ? "<blank>" : e.Key));
        }

        private static bool ShouldSkipDbColumn(string dbKey)
        {
            return dbKey.Equals("PRODUCTIVE ACTUAL HOURS UOS", StringComparison.OrdinalIgnoreCase)
                || dbKey.Equals("PCT PROD INDEX EXCL EDU ORIENT", StringComparison.OrdinalIgnoreCase)
                || dbKey.Equals("ACT PROD HRS UOS", StringComparison.OrdinalIgnoreCase)
                || dbKey.Equals("ACT PAID HRS UOS", StringComparison.OrdinalIgnoreCase);
        }

        private static bool TryGetExcelValue(Dictionary<string, decimal> excelValues, string dbKey, out decimal excelValue, out string matchedExcelKey)
        {
            foreach (var alias in GetExcelAliases(dbKey))
            {
                if (excelValues.TryGetValue(alias, out excelValue))
                {
                    matchedExcelKey = alias;
                    return true;
                }
            }

            if (excelValues.TryGetValue(dbKey, out excelValue))
            {
                matchedExcelKey = dbKey;
                return true;
            }

            excelValue = 0m;
            matchedExcelKey = null;
            return false;
        }

        private static IEnumerable<string> GetExcelAliases(string dbKey)
        {
            switch (dbKey.ToUpperInvariant())
            {
                // UOS Breakdown
                case "ACT UOS":
                    yield return "UOS";
                    break;
                case "ER VISITS":
                    yield return "E/R VISITS";
                    break;
                case "MS HOLD":
                    yield return "MS HOLDS";
                    break;
                case "WEIGHTED MS HOLD":
                    yield return "WEIGHTED MS VISITS";
                    break;
                case "ICU HOLD":
                    yield return "ICU HOLDS";
                    break;
                case "WEIGHTED ICU HOLD":
                    yield return "WEIGHTED ICU VISITS";
                    break;

                // Productive Hours Used
                case "TGT PRODHRS TOTAL":
                    yield return "PRODUCTIVE TARGET HOURS";
                    break;
                case "ACT PRODHRS STAFF":
                    yield return "FT & PT REGULAR HOURS";
                    break;
                case "ACT PRODHRS PRN":
                    yield return "PRN REGULAR HOURS";
                    break;
                case "ACT FTE ORIENT HOURS":
                    yield return "FULL TIME/PART TIME ORIENTATION";
                    break;
                case "ACT PRN ORIENT HOURS":
                    yield return "PRN ORIENTATION";
                    break;
                case "ACT HWS ORIENT HOURS":
                    yield return "HWS LABOR ORIENTATION";
                    break;
                case "ACT VEN ORIENT HOURS":
                    yield return "VENDOR LABOR ORIENTATION";
                    break;
                case "ACT FTE EDUCAT HOURS":
                    yield return "FULL TIME/PART TIME EDUCATION";
                    break;
                case "ACT PRN EDUCAT HOURS":
                    yield return "PRN EDUCATION";
                    break;
                case "ACT HWS EDUCAT HOURS":
                    yield return "HWS LABOR EDUCATION";
                    break;
                case "ACT VEN EDUCAT HOURS":
                    yield return "VENDOR LABOR EDUCATION";
                    break;
                case "ACT HWS PRODHRS CONTR":
                    yield return "HWS HOURS";
                    break;
                case "ACT VEN PRODHRS CONTR":
                    yield return "CONTRACT HOURS";
                    break;
                case "ACT PRODHRS TOTAL":
                    yield return "TOTAL PRODUCTIVE ACTUAL HOURS";
                    break;
                case "PRODUCTIVE HOURS VARIANCE":
                    yield return "DEPARTMENT PRODUCTIVE HOURS VARIANCE";
                    break;
                case "PCT PROD INDEX":
                    yield return "PRODUCTIVE INDEX > (TGT/ACT)";
                    break;
                case "PCT PROD INDEX EXCL EDU ORIENT":
                    // Excel: Productive Index % Excl. Edu. & Orient | DB2: PCT_PROD_INDEX_EXCL_EDU_ORIENT
                    yield return "PRODUCTIVE INDEX % EXCL. EDU. & ORIENT";
                    break;
                case "ACT PROD FTES":
                    yield return "PRODUCTIVE ACTUAL FTES";
                    break;
                case "TGT PROD HRS UOS":
                    yield return "PRODUCTIVE TARGET HOURS/UOS";
                    break;
                case "ACT PROD HRS UOS":
                    // Excel: Productive Actual Hours/UOS | DB2: ACT_PROD_HRS_UOS
                    yield return "PRODUCTIVE ACTUAL HOURS/UOS";
                    break;

                // Paid Hours Used
                case "ACT NONPROD HRS":
                    yield return "NON-PRODUCTIVE HOURS";
                    break;
                case "ACT PAIDHRS TOTAL":
                    yield return "PAID ACTUAL HOURS";
                    break;
                case "TGT PAIDHRS TOTAL":
                    yield return "PAID TARGET HOURS";
                    break;
                case "VAR PAIDHRS":
                    yield return "PAID HOURS VARIANCE";
                    break;
                case "PCT PAID INDEX":
                    yield return "PAID INDEX > (TGT/ACT)";
                    break;
                case "ACT PAID FTES":
                    yield return "PAID FTES";
                    break;
                case "TGT PAID HRS UOS":
                    yield return "PAID TARGET HOURS/UOS";
                    break;
                case "ACT PAID HRS UOS":
                    yield return "PAID ACTUAL HOURS/UOS";
                    break;
            }
        }
    }
}
