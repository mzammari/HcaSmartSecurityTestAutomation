using System;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingSummarySP
    {
        public static string GetDailyStaffingSummaryQuery(string reportType, string reportPeriod, DateTime startDate, DateTime endDate)
        {
            return GetDailyStaffingSummaryQuery(null, reportType, reportPeriod, startDate, endDate);
        }

        public static string GetDailyStaffingSummaryQuery(string division, string reportType, string reportPeriod, DateTime startDate, DateTime endDate)
        {
            if (!string.IsNullOrWhiteSpace(division))
                return GetDailyStaffingSummaryDivisionQuery(division, reportType, reportPeriod, startDate, endDate);

            string normalizedReportType = NormalizeSqlLiteral(reportType);
            string normalizedReportPeriod = NormalizeSqlLiteral(reportPeriod);
            string divisionFilter = GetDivisionFilter(division);
            string startDateText = startDate.ToString("yyyy-MM-dd");
            string endDateText = endDate.ToString("yyyy-MM-dd");

            return $@"SELECT DDA.DEPT_OR_GROUP_NUM,
     DPT.DEPT_DESC                     AS DEPT_OR_GROUP_DESC, 
     STRIP(SUBSTR(STA.STAT_DESC,1,30)) AS STAT_DESC, 
     ROUND(DDA.TGT_PROD_HRS_UOS,3)     AS TGT_PROD_HRS_UOS, 
     ROUND(DDA.TGT_SV_PROD_FTES,2)     AS TGT_SV_PROD_FTES, 
     DDA.ACT_UOS, 
     ROUND(DDA.TGT_PRODHRS_TOTAL, 2)   AS F_TGT, 
     ROUND(DDA.ACT_PRODHRS_TOTAL, 2)   AS F_ACT, 
     (ROUND(DDA.TGT_PRODHRS_TOTAL, 2) -  
     ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_VAR, 
     DDA_BASE.F_CUM_UOS, 
     DDA_BASE.F_CUM_TGT, 
     DDA_BASE.F_CUM_ACT, 
     (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT)       AS F_CUM_VAR, 
     (CASE WHEN (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT)<0 THEN (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT) ELSE 0 END) AS F_CUM_VAR_NEG, 
     DDA_BASE.F_CUM_OT, 
     (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
     ELSE (DEC(DDA_BASE.F_CUM_OT,10,2) / 
     DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
     END) AS F_CUM_OT_PCT, 
	 DDA_BASE.F_CUM_HWS_CONTR, 
	 DDA_BASE.F_CUM_VEN_CONTR, 
     DDA_BASE.F_CUM_CONTR, 
     (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
     ELSE (DEC(DDA_BASE.F_CUM_CONTR,10,2) / 
     DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
     END) AS F_CUM_CONTR_PCT, 
     (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
     ELSE (DEC(DDA_BASE.F_CUM_TGT,10,2) / 
     DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
     END) AS F_CUM_PROD_INDEX, 
            CASE WHEN TGT.TARGET_MIN_HOURS IS NULL THEN 0
                 ELSE TGT.TARGET_MIN_HOURS
            END  AS TARGET_MIN_HOURS,
             DDA_BASE.F_CUM_PRN, 
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                  ELSE (DEC(DDA_BASE.F_CUM_PRN,10,2) / 
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
             END) AS F_CUM_PRN_PCT 
     FROM    H.LPBDDA DDA 
     LEFT OUTER JOIN  H.LPBTGM TGM 
     ON DDA.UNIT_NUM = TGM.UNIT_NUM AND 
     DDA.DEPT_OR_GROUP_NUM = TGM.DEPT_OR_GROUP_NUM AND 
     SUBSTR(VARCHAR(TGM.EFF_MONTH_DATE),1,7) =  
     SUBSTR(VARCHAR('{endDateText}'),1,7) 
     LEFT OUTER JOIN  H.LPBTGT TGT 
     ON TGM.TARGET_ID = TGT.TARGET_ID 
     INNER JOIN (SELECT DDA.UNIT_NUM, 
                               DDA.DEPT_OR_GROUP_NUM, 
                               SUM(DDA.ACT_UOS)                     AS F_CUM_UOS, 
                               SUM(ROUND(DDA.TGT_PRODHRS_TOTAL, 2)) AS F_CUM_TGT, 
                               SUM(ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_CUM_ACT, 
                               SUM(ROUND(DDA.ACT_PRODHRS_OT, 2))    AS F_CUM_OT, 
	                           SUM(ROUND(DDA.ACT_HWS_PRODHRS_CONTR, 2)) AS F_CUM_HWS_CONTR, 
	                           SUM(ROUND(DDA.ACT_VEN_PRODHRS_CONTR, 2)) AS F_CUM_VEN_CONTR, 
                               SUM(ROUND(DDA.ACT_PRODHRS_CONTR, 2)) AS F_CUM_CONTR, 
                               SUM(ROUND(DDA.ACT_PRODHRS_PRN + DDA.ACT_OT_PRN, 2)) 	AS F_CUM_PRN 
                        FROM    H.LPBDDA DDA 
                        WHERE  (DDA.UNIT_NUM =   1406   AND 
                                DDA.DEPT_OR_GROUP_NUM IN (  SELECT DISTINCT
											CASE
												WHEN DPT.GROUP_NUM <> 0 THEN DPT.GROUP_NUM
												ELSE DPT.DEPT_NUM
											END AS DEPT_OR_GROUP_NUM
                                       FROM H.LPBDPT DPT JOIN H.LPBFAC FAC ON DPT.UNIT_NUM = FAC.UNIT_NUM WHERE FAC.UNIT_NUM = 1406  ) AND  
                                DDA.ACTIVITY_DATE BETWEEN '{startDateText}' AND '{endDateText}') 
                        GROUP  BY DDA.UNIT_NUM, 
                                  DDA.DEPT_OR_GROUP_NUM) DDA_BASE 
              ON DDA.UNIT_NUM = DDA_BASE.UNIT_NUM AND 
                 DDA.DEPT_OR_GROUP_NUM = DDA_BASE.DEPT_OR_GROUP_NUM 
            INNER JOIN  H.LPBDPT DPT 
              ON DDA.UNIT_NUM = DPT.UNIT_NUM AND 
                 DDA.DEPT_OR_GROUP_NUM = DPT.DEPT_NUM AND DPT.SUBFUNCTION_NUM NOT IN (131500)
            LEFT OUTER JOIN  H.LPBGPD GPD 
              ON DDA.UNIT_NUM = GPD.UNIT_NUM AND 
                 DDA.DEPT_OR_GROUP_NUM = GPD.GROUP_NUM 
            INNER JOIN  H.LPBSTA STA 
              ON DPT.STAT_ID = STA.STAT_ID 
     WHERE  (DDA.UNIT_NUM =   1406   AND 
             DDA.DEPT_OR_GROUP_NUM IN (  SELECT DISTINCT
											CASE
												WHEN DPT.GROUP_NUM <> 0 THEN DPT.GROUP_NUM
												ELSE DPT.DEPT_NUM
											END AS DEPT_OR_GROUP_NUM
                                       FROM H.LPBDPT DPT JOIN H.LPBFAC FAC ON DPT.UNIT_NUM = FAC.UNIT_NUM WHERE FAC.UNIT_NUM = 1406  ) AND  
             DDA.ACTIVITY_DATE = '{endDateText}') AND 
            (GPD.SHARED_OUT_FLAG IS NULL OR 
             GPD.SHARED_OUT_FLAG <> 'Y') 
             {divisionFilter}
     UNION ALL 
     SELECT DDA.DEPT_OR_GROUP_NUM, 
            GPD.GROUP_DESC                    AS DEPT_OR_GROUP_DESC, 
            STRIP(SUBSTR(STA.STAT_DESC,1,30)) AS STAT_DESC, 
            ROUND(DDA.TGT_PROD_HRS_UOS,3)     AS TGT_PROD_HRS_UOS, 
            ROUND(DDA.TGT_SV_PROD_FTES,2)     AS TGT_SV_PROD_FTES, 
            DDA.ACT_UOS, 
            ROUND(DDA.TGT_PRODHRS_TOTAL, 2)   AS F_TGT, 
            ROUND(DDA.ACT_PRODHRS_TOTAL, 2)   AS F_ACT, 
            (ROUND(DDA.TGT_PRODHRS_TOTAL, 2) -  
             ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_VAR, 
            DDA_BASE.F_CUM_UOS, 
            DDA_BASE.F_CUM_TGT, 
            DDA_BASE.F_CUM_ACT, 
            (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT)       AS F_CUM_VAR, 
     (CASE WHEN (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT)<0 THEN (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT) ELSE 0 END) AS F_CUM_VAR_NEG, 
            DDA_BASE.F_CUM_OT, 
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                  ELSE (DEC(DDA_BASE.F_CUM_OT,10,2) / 
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
             END) AS F_CUM_OT_PCT, 
	        DDA_BASE.F_CUM_HWS_CONTR, 
	        DDA_BASE.F_CUM_VEN_CONTR, 
            DDA_BASE.F_CUM_CONTR, 
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                  ELSE (DEC(DDA_BASE.F_CUM_CONTR,10,2) / 
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
             END) AS F_CUM_CONTR_PCT, 
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                  ELSE (DEC(DDA_BASE.F_CUM_TGT,10,2) / 
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
             END) AS F_CUM_PROD_INDEX, 
            CASE WHEN TGT.TARGET_MIN_HOURS IS NULL THEN 0
                 ELSE TGT.TARGET_MIN_HOURS
            END  AS TARGET_MIN_HOURS,
             DDA_BASE.F_CUM_PRN, 
            (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                  ELSE (DEC(DDA_BASE.F_CUM_PRN,10,2) / 
                        DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
             END) AS F_CUM_PRN_PCT 
     FROM    H.LPBDDA DDA 
            LEFT OUTER JOIN  H.LPBTGM TGM 
              ON DDA.UNIT_NUM = TGM.UNIT_NUM AND 
                 DDA.DEPT_OR_GROUP_NUM = TGM.DEPT_OR_GROUP_NUM AND 
                 SUBSTR(VARCHAR(TGM.EFF_MONTH_DATE),1,7) =  
                   SUBSTR(VARCHAR('{endDateText}'),1,7) 
            LEFT OUTER JOIN  H.LPBTGT TGT 
              ON TGM.TARGET_ID = TGT.TARGET_ID 
            INNER JOIN (SELECT DDA.UNIT_NUM, 
                               DDA.DEPT_OR_GROUP_NUM, 
                               SUM(DDA.ACT_UOS)                     AS F_CUM_UOS, 
                               SUM(ROUND(DDA.TGT_PRODHRS_TOTAL, 2)) AS F_CUM_TGT, 
                               SUM(ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_CUM_ACT, 
                               SUM(ROUND(DDA.ACT_PRODHRS_OT, 2))    AS F_CUM_OT, 
	                           SUM(ROUND(DDA.ACT_HWS_PRODHRS_CONTR, 2)) AS F_CUM_HWS_CONTR, 
	                           SUM(ROUND(DDA.ACT_VEN_PRODHRS_CONTR, 2)) AS F_CUM_VEN_CONTR, 
                               SUM(ROUND(DDA.ACT_PRODHRS_CONTR, 2)) AS F_CUM_CONTR, 
                               SUM(ROUND(DDA.ACT_PRODHRS_PRN + DDA.ACT_OT_PRN, 2)) 	AS F_CUM_PRN 
                        FROM    H.LPBDDA DDA 
                        WHERE  (DDA.UNIT_NUM =   1406   AND 
                                DDA.DEPT_OR_GROUP_NUM IN (  SELECT DISTINCT
											CASE
												WHEN DPT.GROUP_NUM <> 0 THEN DPT.GROUP_NUM
												ELSE DPT.DEPT_NUM
											END AS DEPT_OR_GROUP_NUM
                                       FROM H.LPBDPT DPT JOIN H.LPBFAC FAC ON DPT.UNIT_NUM = FAC.UNIT_NUM WHERE FAC.UNIT_NUM = 1406  ) AND  
                                DDA.ACTIVITY_DATE BETWEEN '{startDateText}' AND '{endDateText}') 
                        GROUP  BY DDA.UNIT_NUM, 
                                  DDA.DEPT_OR_GROUP_NUM) DDA_BASE 
              ON DDA.UNIT_NUM = DDA_BASE.UNIT_NUM AND 
                 DDA.DEPT_OR_GROUP_NUM = DDA_BASE.DEPT_OR_GROUP_NUM 
            INNER JOIN  H.LPBGPD GPD 
              ON DDA.UNIT_NUM = GPD.UNIT_NUM AND 
                 DDA.DEPT_OR_GROUP_NUM = GPD.GROUP_NUM 
            INNER JOIN  H.LPBSTA STA 
              ON GPD.STAT_ID = STA.STAT_ID 
     WHERE  (DDA.UNIT_NUM =   1406   AND 
             DDA.DEPT_OR_GROUP_NUM IN (  SELECT DISTINCT
											CASE
												WHEN DPT.GROUP_NUM <> 0 THEN DPT.GROUP_NUM
												ELSE DPT.DEPT_NUM
											END AS DEPT_OR_GROUP_NUM
                                       FROM H.LPBDPT DPT JOIN H.LPBFAC FAC ON DPT.UNIT_NUM = FAC.UNIT_NUM WHERE FAC.UNIT_NUM = 1406  ) AND  
             DDA.ACTIVITY_DATE =  '{endDateText}') AND 
            (GPD.SHARED_OUT_FLAG IS NULL OR 
             GPD.SHARED_OUT_FLAG <> 'Y') 
             {divisionFilter}
     ORDER BY DEPT_OR_GROUP_NUM ;
";
        }

        private static string GetDivisionFilter(string division)
        {
            if (string.IsNullOrWhiteSpace(division))
                return string.Empty;

            string normalizedDivision = NormalizeSqlLiteral(division.Trim());

            return $"AND UPPER(TRIM(COALESCE(GPD.GROUP_DESC, ''))) = UPPER('{normalizedDivision}')";
        }

        private static string GetDailyStaffingSummaryDivisionQuery(string division, string reportType, string reportPeriod, DateTime startDate, DateTime endDate)
        {
            int divisionNumber = GetDivisionNumber(division);
            string startDateText = startDate.ToString("yyyy-MM-dd");
            string endDateText = endDate.ToString("yyyy-MM-dd");

            return $@"SELECT RES.* FROM 
         (SELECT FAC.DIVISION_NBR,FAC.CO_ID,FAC.UNIT_NUM,FAC.FACILITY_NAME, DDA.DEPT_OR_GROUP_NUM, 
         DPT.SUBFUNCTION_NUM,SUB.SUB_FUNCTIONAL_DSC,DPT.DEPT_DESC  AS DEPT_OR_GROUP_DESC, 
         STRIP(SUBSTR(STA.STAT_DESC,1,30)) AS STAT_DESC, 
         ROUND(DDA.TGT_PROD_HRS_UOS,3)     AS TGT_PROD_HRS_UOS, 
         ROUND(DDA.TGT_SV_PROD_FTES,2)     AS TGT_SV_PROD_FTES, 
         DDA.ACT_UOS, 
         ROUND(DDA.TGT_PRODHRS_TOTAL, 2)   AS F_TGT, 
         ROUND(DDA.ACT_PRODHRS_TOTAL, 2)   AS F_ACT, 
         (ROUND(DDA.TGT_PRODHRS_TOTAL, 2) -  
         ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_VAR, 
         DDA_BASE.F_CUM_UOS, 
         DDA_BASE.F_CUM_TGT, 
         DDA_BASE.F_CUM_ACT, 
         (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT)       AS F_CUM_VAR, 
         (CASE WHEN (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT)<0 THEN (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT) ELSE 0 END) AS F_CUM_VAR_NEG, 
         DDA_BASE.F_CUM_OT, 
         (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
         ELSE (DEC(DDA_BASE.F_CUM_OT,10,2) / 
         DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
         END) AS F_CUM_OT_PCT, 
         DDA_BASE.F_CUM_HWS_CONTR, 
         DDA_BASE.F_CUM_VEN_CONTR, 
         DDA_BASE.F_CUM_CONTR, 
         (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
         ELSE (DEC(DDA_BASE.F_CUM_CONTR,10,2) / 
         DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
         END) AS F_CUM_CONTR_PCT, 
         (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
         ELSE (DEC(DDA_BASE.F_CUM_TGT,10,2) / 
         DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
         END) AS F_CUM_PROD_INDEX, 
                CASE WHEN TGT.TARGET_MIN_HOURS IS NULL THEN 0
                     ELSE TGT.TARGET_MIN_HOURS
                END  AS TARGET_MIN_HOURS,
                 DDA_BASE.F_CUM_PRN, 
                (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                      ELSE (DEC(DDA_BASE.F_CUM_PRN,10,2) / 
                            DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
                 END) AS F_CUM_PRN_PCT 
         FROM    H.LPBFAC FAC LEFT OUTER JOIN   H.LPBDDA DDA on FAC.UNIT_NUM=DDA.UNIT_NUM 
         LEFT OUTER JOIN  H.LPBTGM TGM 
         ON DDA.UNIT_NUM = TGM.UNIT_NUM AND 
         DDA.DEPT_OR_GROUP_NUM = TGM.DEPT_OR_GROUP_NUM AND 
         SUBSTR(VARCHAR(TGM.EFF_MONTH_DATE),1,7) =  
         SUBSTR(VARCHAR('{endDateText}'),1,7) 
         LEFT OUTER JOIN  H.LPBTGT TGT 
         ON TGM.TARGET_ID = TGT.TARGET_ID 
         INNER JOIN (SELECT DDA.UNIT_NUM, 
                                   DDA.DEPT_OR_GROUP_NUM, 
                                   SUM(DDA.ACT_UOS)                     AS F_CUM_UOS, 
                                   SUM(ROUND(DDA.TGT_PRODHRS_TOTAL, 2)) AS F_CUM_TGT, 
                                   SUM(ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_CUM_ACT, 
                                   SUM(ROUND(DDA.ACT_PRODHRS_OT, 2))    AS F_CUM_OT, 
                                   SUM(ROUND(DDA.ACT_HWS_PRODHRS_CONTR, 2)) AS F_CUM_HWS_CONTR, 
                                   SUM(ROUND(DDA.ACT_VEN_PRODHRS_CONTR, 2)) AS F_CUM_VEN_CONTR, 
                                   SUM(ROUND(DDA.ACT_PRODHRS_CONTR, 2)) AS F_CUM_CONTR, 
                                   SUM(ROUND(DDA.ACT_PRODHRS_PRN + DDA.ACT_OT_PRN, 2))     AS F_CUM_PRN 
                            FROM    H.LPBDDA DDA WHERE 
                                    DDA.ACTIVITY_DATE BETWEEN '{startDateText}' AND '{endDateText}' 
                            GROUP  BY DDA.UNIT_NUM, 
                                      DDA.DEPT_OR_GROUP_NUM) DDA_BASE 
                  ON DDA.UNIT_NUM = DDA_BASE.UNIT_NUM AND 
                     DDA.DEPT_OR_GROUP_NUM = DDA_BASE.DEPT_OR_GROUP_NUM 
                INNER JOIN  H.LPBDPT DPT 
                  ON DDA.UNIT_NUM = DPT.UNIT_NUM AND 
                     DDA.DEPT_OR_GROUP_NUM = DPT.DEPT_NUM AND DPT.SUBFUNCTION_NUM NOT IN (131500)
                    LEFT JOIN   H.QMFDFD SUB ON DPT.SUBFUNCTION_NUM = SUB.SUB_FUNCTIONAL_NBR  
                LEFT OUTER JOIN  H.LPBGPD GPD 
                  ON DDA.UNIT_NUM = GPD.UNIT_NUM AND 
                     DDA.DEPT_OR_GROUP_NUM = GPD.GROUP_NUM 
                INNER JOIN  H.LPBSTA STA 
                  ON DPT.STAT_ID = STA.STAT_ID 
            WHERE  DDA.ACTIVITY_DATE = '{endDateText}' AND FAC.DIVISION_NBR = {divisionNumber} AND FAC.LOB = 'HOS' and  FAC.SUB_LOB IN ('MED','PSY','RHB') 
             AND   (GPD.SHARED_OUT_FLAG IS NULL OR 
                 GPD.SHARED_OUT_FLAG <> 'Y') 
         UNION ALL 
         SELECT FAC.DIVISION_NBR,FAC.CO_ID,FAC.UNIT_NUM,FAC.FACILITY_NAME, DDA.DEPT_OR_GROUP_NUM, 
                DPT.SUBFUNCTION_NUM,SUB.SUB_FUNCTIONAL_DSC, GPD.GROUP_DESC  AS DEPT_OR_GROUP_DESC, 
                STRIP(SUBSTR(STA.STAT_DESC,1,30)) AS STAT_DESC, 
                ROUND(DDA.TGT_PROD_HRS_UOS,3)     AS TGT_PROD_HRS_UOS, 
                ROUND(DDA.TGT_SV_PROD_FTES,2)     AS TGT_SV_PROD_FTES, 
                DDA.ACT_UOS, 
                ROUND(DDA.TGT_PRODHRS_TOTAL, 2)   AS F_TGT, 
                ROUND(DDA.ACT_PRODHRS_TOTAL, 2)   AS F_ACT, 
                (ROUND(DDA.TGT_PRODHRS_TOTAL, 2) -  
                 ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_VAR, 
                DDA_BASE.F_CUM_UOS, 
                DDA_BASE.F_CUM_TGT, 
                DDA_BASE.F_CUM_ACT, 
                (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT)       AS F_CUM_VAR, 
         (CASE WHEN (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT)<0 THEN (DDA_BASE.F_CUM_TGT - DDA_BASE.F_CUM_ACT) ELSE 0 END) AS F_CUM_VAR_NEG, 
                DDA_BASE.F_CUM_OT, 
                (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                      ELSE (DEC(DDA_BASE.F_CUM_OT,10,2) / 
                            DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
                 END) AS F_CUM_OT_PCT, 
                DDA_BASE.F_CUM_HWS_CONTR, 
                DDA_BASE.F_CUM_VEN_CONTR, 
                DDA_BASE.F_CUM_CONTR, 
                (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                      ELSE (DEC(DDA_BASE.F_CUM_CONTR,10,2) / 
                            DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
                 END) AS F_CUM_CONTR_PCT, 
                (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                      ELSE (DEC(DDA_BASE.F_CUM_TGT,10,2) / 
                            DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
                 END) AS F_CUM_PROD_INDEX, 
                CASE WHEN TGT.TARGET_MIN_HOURS IS NULL THEN 0
                     ELSE TGT.TARGET_MIN_HOURS
                END  AS TARGET_MIN_HOURS,
                 DDA_BASE.F_CUM_PRN, 
                (CASE WHEN DDA_BASE.F_CUM_ACT = 0 THEN 0 
                      ELSE (DEC(DDA_BASE.F_CUM_PRN,10,2) / 
                            DEC(DDA_BASE.F_CUM_ACT,10,2))*100 
                 END) AS F_CUM_PRN_PCT 
         FROM    H.LPBFAC FAC LEFT OUTER JOIN  H.LPBDDA DDA on FAC.UNIT_NUM=DDA.UNIT_NUM 
                LEFT OUTER JOIN  H.LPBTGM TGM 
                  ON DDA.UNIT_NUM = TGM.UNIT_NUM AND 
                     DDA.DEPT_OR_GROUP_NUM = TGM.DEPT_OR_GROUP_NUM AND 
                     SUBSTR(VARCHAR(TGM.EFF_MONTH_DATE),1,7) =  
                       SUBSTR(VARCHAR('{endDateText}'),1,7) 
                LEFT OUTER JOIN  H.LPBTGT TGT 
                  ON TGM.TARGET_ID = TGT.TARGET_ID 
                INNER JOIN (SELECT DDA.UNIT_NUM, 
                                   DDA.DEPT_OR_GROUP_NUM, 
                                   SUM(DDA.ACT_UOS)                     AS F_CUM_UOS, 
                                   SUM(ROUND(DDA.TGT_PRODHRS_TOTAL, 2)) AS F_CUM_TGT, 
                                   SUM(ROUND(DDA.ACT_PRODHRS_TOTAL, 2)) AS F_CUM_ACT, 
                                   SUM(ROUND(DDA.ACT_PRODHRS_OT, 2))    AS F_CUM_OT, 
                                   SUM(ROUND(DDA.ACT_HWS_PRODHRS_CONTR, 2)) AS F_CUM_HWS_CONTR, 
                                   SUM(ROUND(DDA.ACT_VEN_PRODHRS_CONTR, 2)) AS F_CUM_VEN_CONTR, 
                                   SUM(ROUND(DDA.ACT_PRODHRS_CONTR, 2)) AS F_CUM_CONTR, 
                                   SUM(ROUND(DDA.ACT_PRODHRS_PRN + DDA.ACT_OT_PRN, 2))     AS F_CUM_PRN 
                            FROM    H.LPBDDA DDA WHERE 
                                    DDA.ACTIVITY_DATE BETWEEN '{startDateText}' AND '{endDateText}' 
                            GROUP  BY DDA.UNIT_NUM, 
                                      DDA.DEPT_OR_GROUP_NUM) DDA_BASE 
                  ON DDA.UNIT_NUM = DDA_BASE.UNIT_NUM AND 
                     DDA.DEPT_OR_GROUP_NUM = DDA_BASE.DEPT_OR_GROUP_NUM 
                         LEFT JOIN   H.LPBDPT DPT  
                      ON DDA.UNIT_NUM = DPT.UNIT_NUM AND  
                         DDA.DEPT_OR_GROUP_NUM = DPT.DEPT_NUM  
                    LEFT JOIN   H.QMFDFD SUB ON DPT.SUBFUNCTION_NUM = SUB.SUB_FUNCTIONAL_NBR  
                INNER JOIN  H.LPBGPD GPD 
                  ON DDA.UNIT_NUM = GPD.UNIT_NUM AND 
                     DDA.DEPT_OR_GROUP_NUM = GPD.GROUP_NUM 
                INNER JOIN  H.LPBSTA STA 
                  ON GPD.STAT_ID = STA.STAT_ID 
         WHERE  (FAC.DIVISION_NBR = {divisionNumber} AND FAC.LOB = 'HOS' and  FAC.SUB_LOB IN ('MED','PSY','RHB') AND 
                 DDA.ACTIVITY_DATE =  '{endDateText}') AND 
                (GPD.SHARED_OUT_FLAG IS NULL OR 
                 GPD.SHARED_OUT_FLAG <> 'Y'))RES INNER JOIN 
         (select FAC.CO_ID,DEPT.DEPT_NUM from  H.LPBFAC FAC left join   H.LPBDPT DEPT on FAC.UNIT_NUM=DEPT.UNIT_NUM  
         where FAC.DIVISION_NBR = {divisionNumber} AND FAC.LOB = 'HOS' and  FAC.SUB_LOB IN ('MED','PSY','RHB') and IGNORE_DEPt = 'N' and GROUP_NUM = 0 UNION  
         select FAC.CO_ID, GROUP_NUM  as DEPT_NUM from  H.LPBFAC FAC left join   H.LPBDPT DEPT   
         on FAC.UNIT_NUM=DEPT.UNIT_NUM    where FAC.DIVISION_NBR = {divisionNumber} AND FAC.LOB = 'HOS' and  FAC.SUB_LOB IN ('MED','PSY','RHB')and IGNORE_DEPt = 'N' and GROUP_NUM > 0)AuthDeptGrp on res.CO_ID=AuthDeptGrp.CO_ID and res.DEPT_OR_GROUP_NUM=AuthDeptGrp.DEPT_NUM  
         ORDER BY CO_ID,DEPT_OR_GROUP_NUM ;
";
        }

        private static int GetDivisionNumber(string division)
        {
            if (int.TryParse(division, out int divisionNumber))
                return divisionNumber;

            string digits = string.Empty;
            foreach (char value in division)
            {
                if (char.IsDigit(value))
                    digits += value;
            }

            if (int.TryParse(digits, out divisionNumber))
                return divisionNumber;

            for (int index = division.Length - 1; index >= 0; index--)
            {
                if (char.IsLetter(division[index]))
                    return char.ToUpperInvariant(division[index]) - 'A' + 1;
            }

            throw new ArgumentException($"Could not determine division number from '{division}'.", nameof(division));
        }

        private static string NormalizeSqlLiteral(string value)
        {
            return (value ?? string.Empty).Replace("'", "''");
        }
    }
}
