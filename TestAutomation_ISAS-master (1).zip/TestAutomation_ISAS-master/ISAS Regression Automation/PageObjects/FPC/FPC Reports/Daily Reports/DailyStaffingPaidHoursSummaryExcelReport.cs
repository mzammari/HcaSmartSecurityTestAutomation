using ExcelDataReader;
using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingPaidHoursSummaryExcelReport
    {
        public static List<DailyStaffingPaidHoursSummaryData> ParseDailyStaffingPaidHoursSummaryExcel(string filePath)
        {
            var result = new List<DailyStaffingPaidHoursSummaryData>();
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);

            if (headerRowIndex == -1)
            {
                Console.WriteLine("Could not find Daily Staffing Paid Hours Summary column names in the Excel file. Validation will be skipped.");
                return result;
            }

            var columnMap = BuildColumnMap(rows[headerRowIndex]);
            if (!columnMap.ContainsKey(nameof(DailyStaffingPaidHoursSummaryData.DeptGroupNum))
                || !columnMap.ContainsKey(nameof(DailyStaffingPaidHoursSummaryData.StatisticDescription)))
            {
                Console.WriteLine("Required key columns are not available in Excel. Validation will be skipped.");
                return result;
            }

            for (int i = headerRowIndex + 1; i < rows.Count; i++)
            {
                var row = rows[i];
                if (CommonFunctions.IsEmptyRow(row))
                    continue;

                string deptGroupNum = GetString(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.DeptGroupNum));
                string statisticDescription = GetString(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.StatisticDescription));

                if (string.IsNullOrWhiteSpace(deptGroupNum) || string.IsNullOrWhiteSpace(statisticDescription))
                    continue;

                result.Add(new DailyStaffingPaidHoursSummaryData
                {
                    DeptGroupNum = deptGroupNum,
                    DepartmentGroupName = GetString(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.DepartmentGroupName)),
                    StatisticDescription = statisticDescription,
                    TargetProdHoursUOS = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.TargetProdHoursUOS)),
                    TargetPaidHoursUOS = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.TargetPaidHoursUOS)),
                    TargetSvProdFtes = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.TargetSvProdFtes)),
                    ActualUOS = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.ActualUOS)),
                    ProductiveHoursTarget = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursTarget)),
                    ProductiveHoursActual = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursActual)),
                    ProductiveHoursVariance = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursVariance)),
                    PaidHoursTarget = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.PaidHoursTarget)),
                    PaidHoursActual = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.PaidHoursActual)),
                    PaidHoursVariance = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.PaidHoursVariance)),
                    CumulativeUOS = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.CumulativeUOS)),
                    CumulativeProductiveHoursTarget = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursTarget)),
                    CumulativeProductiveHoursActual = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursActual)),
                    CumulativePaidHoursTarget = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursTarget)),
                    CumulativePaidHoursActual = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursActual)),
                    CumulativeProductiveHoursVariance = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursVariance)),
                    CumulativePaidHoursVariance = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursVariance)),
                    CumulativeNegativeVariance = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.CumulativeNegativeVariance)),
                    OvertimeFtes = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.OvertimeFtes)),
                    OvertimePercent = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.OvertimePercent)),
                    HwsContractProdHours = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.HwsContractProdHours)),
                    VendorContractProdHours = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.VendorContractProdHours)),
                    ContractFtes = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.ContractFtes)),
                    ContractPercent = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.ContractPercent)),
                    ProductiveIndexPercent = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.ProductiveIndexPercent)),
                    PaidIndexPercent = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.PaidIndexPercent)),
                    TargetMinimumHours = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.TargetMinimumHours)),
                    PRNFtes = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.PRNFtes)),
                    PRNPercent = GetDecimal(row, columnMap, nameof(DailyStaffingPaidHoursSummaryData.PRNPercent)),
                    AvailableFields = columnMap.Keys.ToHashSet()
                });
            }

            return result;
        }

        public static DailyStaffingPaidHoursSummaryReportCriteria GetReportCriteria(string filePath, string fallbackReportType, string fallbackReportPeriod)
        {
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            var headerRows = headerRowIndex > 0 ? rows.Take(headerRowIndex).ToList() : rows.Take(10).ToList();
            string reportType = FindReportType(headerRows) ?? fallbackReportType;
            string reportPeriod = FindReportPeriod(headerRows) ?? fallbackReportPeriod;
            var dates = FindDates(headerRows).Distinct().OrderBy(d => d).ToList();

            if (dates.Count == 0)
                throw new InvalidOperationException("Could not find report date values in the Daily Staffing Paid Hours Summary Excel file.");

            DateTime endDate = dates.Last();
            return new DailyStaffingPaidHoursSummaryReportCriteria
            {
                ReportType = reportType,
                ReportPeriod = reportPeriod,
                StartDate = GetStartDate(reportType, endDate),
                EndDate = endDate
            };
        }

        public static bool HasValidationColumns(string filePath)
        {
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            if (headerRowIndex == -1)
                return false;

            var columnMap = BuildColumnMap(rows[headerRowIndex]);
            return columnMap.ContainsKey(nameof(DailyStaffingPaidHoursSummaryData.DeptGroupNum))
                && columnMap.ContainsKey(nameof(DailyStaffingPaidHoursSummaryData.StatisticDescription))
                && columnMap.Keys.Any(k => k != nameof(DailyStaffingPaidHoursSummaryData.DeptGroupNum)
                    && k != nameof(DailyStaffingPaidHoursSummaryData.DepartmentGroupName)
                    && k != nameof(DailyStaffingPaidHoursSummaryData.StatisticDescription));
        }

        private static Dictionary<string, int> BuildColumnMap(object[] headerRow)
        {
            var columnMap = new Dictionary<string, int>();
            var headerCounts = new Dictionary<string, int>();

            for (int i = 0; i < headerRow.Length; i++)
            {
                string header = NormalizeHeader(headerRow[i]?.ToString());
                if (string.IsNullOrWhiteSpace(header))
                    continue;

                headerCounts.TryGetValue(header, out int count);
                headerCounts[header] = ++count;

                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.DeptGroupNum), "DEPTORGROUPNUM", "DEPTGROUPNUM");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.DepartmentGroupName), "DEPTORGROUPDESC", "DEPARTMENTGROUPNAME");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.StatisticDescription), "STATDESC", "STATISTICDESCRIPTION");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.TargetProdHoursUOS), "TGTPRODHRSUOS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.TargetPaidHoursUOS), "TGTPAIDHRSUOS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.TargetSvProdFtes), "TGTSVPRODFTES", "SEMIVARPRODSTDFTES");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.ActualUOS), "ACTUOS", "UOSDAILYPROD");
                AddByOccurrence(columnMap, header, count, i, "TARGETPRODHOURS", nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursTarget), nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursTarget));
                AddByOccurrence(columnMap, header, count, i, "ACTUALPRODHOURS", nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursActual), nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursActual));
                AddByOccurrence(columnMap, header, count, i, "VARPRODHOURS", nameof(DailyStaffingPaidHoursSummaryData.ProductiveHoursVariance), nameof(DailyStaffingPaidHoursSummaryData.CumulativeProductiveHoursVariance));
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.PaidHoursTarget), "FTGTPAID");
                AddByOccurrence(columnMap, header, count, i, "ACTUALPAIDHOURS", nameof(DailyStaffingPaidHoursSummaryData.PaidHoursActual), nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursActual));
                AddByOccurrence(columnMap, header, count, i, "VARPAIDHOURS", nameof(DailyStaffingPaidHoursSummaryData.PaidHoursVariance), nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursVariance));
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.CumulativeUOS), "FCUMUOS", "UOSPRODHOURSSUMMARY");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.CumulativePaidHoursTarget), "FCUMTGTPAID", "TARGETPAIDHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.CumulativeNegativeVariance), "FCUMVARNEG");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.OvertimeFtes), "FCUMOT", "OTPRODHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.OvertimePercent), "FCUMOTPCT", "OT");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.HwsContractProdHours), "FCUMHWSCONTR", "HWSCLPRODHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.VendorContractProdHours), "FCUMVENCONTR", "VENDORCLPRODHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.ContractFtes), "FCUMCONTR", "TOTALCLPRODHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.ContractPercent), "FCUMCONTRPCT", "TOTALCL");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.ProductiveIndexPercent), "FCUMPRODINDEX", "PRODIDXPCT");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.PaidIndexPercent), "FCUMPAIDINDEX", "PAIDIDXPCT");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.TargetMinimumHours), "TARGETMINHOURS", "TARGETMINIMUMHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.PRNFtes), "FCUMPRN", "PRNPRODHOURS");
                AddIfMatches(columnMap, header, i, nameof(DailyStaffingPaidHoursSummaryData.PRNPercent), "FCUMPRNPCT", "PRN");
            }

            return columnMap;
        }

        private static void AddByOccurrence(Dictionary<string, int> columnMap, string header, int occurrence, int index, string headerName, string firstFieldName, string secondFieldName)
        {
            if (header != headerName)
                return;

            string fieldName = occurrence == 1 ? firstFieldName : secondFieldName;
            if (!columnMap.ContainsKey(fieldName))
                columnMap[fieldName] = index;
        }

        private static void AddIfMatches(Dictionary<string, int> columnMap, string header, int index, string fieldName, params string[] aliases)
        {
            if (!columnMap.ContainsKey(fieldName) && aliases.Any(alias => header == alias))
                columnMap[fieldName] = index;
        }

        private static int FindHeaderRow(List<object[]> rows)
        {
            for (int i = 0; i < rows.Count; i++)
            {
                string rowText = string.Join(" ", rows[i].Where(c => c != null).Select(c => c.ToString()));
                if (rowText.Contains("Dept", StringComparison.OrdinalIgnoreCase)
                    && rowText.Contains("Statistic", StringComparison.OrdinalIgnoreCase))
                    return i;
            }

            return -1;
        }

        private static List<object[]> ReadRows(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var allRows = new List<object[]>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                do
                {
                    while (reader.Read())
                    {
                        var row = new object[reader.FieldCount];
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row[i] = reader.GetValue(i);
                        }

                        allRows.Add(row);
                    }
                } while (reader.NextResult());
            }

            return allRows;
        }

        private static string GetString(object[] row, Dictionary<string, int> columnMap, string fieldName)
        {
            return columnMap.TryGetValue(fieldName, out int index) && index < row.Length
                ? CommonFunctions.GetStringValue(row, index)
                : string.Empty;
        }

        private static decimal GetDecimal(object[] row, Dictionary<string, int> columnMap, string fieldName)
        {
            return columnMap.TryGetValue(fieldName, out int index) && index < row.Length
                ? CommonFunctions.GetDecimalValue(row, index)
                : 0m;
        }

        private static string FindReportType(List<object[]> rows)
        {
            string text = GetHeaderText(rows);

            if (text.Contains("PAY PERIOD", StringComparison.OrdinalIgnoreCase))
                return "Pay Period";

            if (text.Contains("MONTH", StringComparison.OrdinalIgnoreCase))
                return "Month";

            if (text.Contains("WEEK", StringComparison.OrdinalIgnoreCase))
                return "Week";

            if (text.Contains("DAY", StringComparison.OrdinalIgnoreCase))
                return "Day";

            return null;
        }

        private static string FindReportPeriod(List<object[]> rows)
        {
            string text = GetHeaderText(rows);

            if (text.Contains("PREVIOUS", StringComparison.OrdinalIgnoreCase))
                return "Previous";

            if (text.Contains("CURRENT", StringComparison.OrdinalIgnoreCase))
                return "Current";

            return null;
        }

        private static List<DateTime> FindDates(List<object[]> rows)
        {
            var dates = new List<DateTime>();

            foreach (var row in rows)
            {
                foreach (var cell in row)
                {
                    dates.AddRange(GetDatesFromCell(cell));
                }
            }

            return dates;
        }

        private static IEnumerable<DateTime> GetDatesFromCell(object cell)
        {
            if (cell == null)
                yield break;

            if (cell is DateTime date)
            {
                yield return date.Date;
                yield break;
            }

            if (cell is double serialDate && serialDate > 30000 && serialDate < 80000)
            {
                yield return DateTime.FromOADate(serialDate).Date;
                yield break;
            }

            string text = cell.ToString();
            if (string.IsNullOrWhiteSpace(text))
                yield break;

            foreach (Match match in Regex.Matches(text, @"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}-\d{1,2}-\d{1,2}\b"))
            {
                if (DateTime.TryParse(match.Value, out DateTime parsedDate))
                    yield return parsedDate.Date;
            }
        }

        private static DateTime GetStartDate(string reportType, DateTime endDate)
        {
            if (reportType.Equals("Month", StringComparison.OrdinalIgnoreCase))
                return new DateTime(endDate.Year, endDate.Month, 1);

            if (reportType.Equals("Pay Period", StringComparison.OrdinalIgnoreCase)
                || reportType.Equals("PayPeriod", StringComparison.OrdinalIgnoreCase)
                || reportType.Equals("Pay_Period", StringComparison.OrdinalIgnoreCase))
                return endDate.AddDays(-13);

            if (reportType.Equals("Week", StringComparison.OrdinalIgnoreCase))
                return endDate.AddDays(-6);

            return endDate;
        }

        private static string GetHeaderText(List<object[]> rows)
        {
            return string.Join(" ", rows.SelectMany(r => r).Where(c => c != null).Select(c => c.ToString()));
        }

        private static string NormalizeHeader(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : Regex.Replace(value, "[^A-Za-z0-9]", string.Empty).ToUpperInvariant();
        }
    }
}
