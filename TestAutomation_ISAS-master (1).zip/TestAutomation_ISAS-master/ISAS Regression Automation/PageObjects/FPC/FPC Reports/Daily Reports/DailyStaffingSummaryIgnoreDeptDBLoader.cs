using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingSummaryIgnoreDeptDBLoader
    {
        public static List<DailyStaffingSummaryIgnoreDeptData> LoadFromDatabase(string reportType, string reportPeriod, DateTime startDate, DateTime endDate)
        {
            var result = new List<DailyStaffingSummaryIgnoreDeptData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = DailyStaffingSummaryIgnoreDeptSP.GetDailyStaffingSummaryIgnoreDeptQuery(reportType, reportPeriod, startDate, endDate);

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new DailyStaffingSummaryIgnoreDeptData
                            {
                                DeptGroupNum = GetString(reader, "DeptGroupNum", "DEPT_OR_GROUP_NUM"),
                                DepartmentGroupName = GetString(reader, "DepartmentGroupName", "DEPT_OR_GROUP_DESC"),
                                StatisticDescription = GetString(reader, "StatisticDescription", "STAT_DESC"),
                                ProdIdxPct = GetDecimal(reader, "F_CUM_PROD_INDEX"),
                                VarProdStdHoursUOS = GetDecimal(reader, "TGT_PROD_HRS_UOS"),
                                SemiVarProdStdFtes = GetDecimal(reader, "TGT_SV_PROD_FTES"),
                                UOS = GetDecimal(reader, "ACT_UOS"),
                                TargetProdHours = GetDecimal(reader, "F_TGT"),
                                ActualProdHours = GetDecimal(reader, "F_ACT"),
                                VarProdHours = GetDecimal(reader, "F_VAR"),
                                DailyUOS = GetDecimal(reader, "F_CUM_UOS"),
                                TargetProdHoursCumulative = GetDecimal(reader, "F_CUM_TGT"),
                                ActualProdHoursCumulative = GetDecimal(reader, "F_CUM_ACT"),
                                VarProdHoursCumulative = GetDecimal(reader, "F_CUM_VAR"),
                                PRNProdHours = GetDecimal(reader, "F_CUM_PRN"),
                                PRNPercentValue = GetDecimal(reader, "F_CUM_PRN_PCT"),
                                OTProdHours = GetDecimal(reader, "F_CUM_OT"),
                                OTPercentValue = GetDecimal(reader, "F_CUM_OT_PCT"),
                                HwsCLProdHours = GetDecimal(reader, "F_CUM_HWS_CONTR"),
                                VendorCLProdHours = GetDecimal(reader, "F_CUM_VEN_CONTR"),
                                TotalCLProdHours = GetDecimal(reader, "F_CUM_CONTR"),
                                TotalCLPercent = GetDecimal(reader, "F_CUM_CONTR_PCT")
                            });
                        }
                    }
                }
            }

            return result;
        }

        private static string GetString(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    return reader.IsDBNull(ordinal) ? string.Empty : reader.GetValue(ordinal).ToString().Trim();
                }
                catch (IndexOutOfRangeException)
                {
                }
            }

            return string.Empty;
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;

                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;

                    string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                    return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
                }
                catch
                {
                }
            }

            return 0m;


        }
    }
}
