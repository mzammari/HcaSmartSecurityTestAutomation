using System;
using System.Collections.Generic;

namespace ISAS_Regression_Automation
{
    public class DailyUosErVisitsHoldsData
    {
        public DateTime Date { get; set; }
        public decimal UOS { get; set; }
        public decimal ProductiveTargetHours { get; set; }
        public decimal FtPtRegularHours { get; set; }
        public decimal PrnRegularHours { get; set; }
        public decimal SharedInRegularHours { get; set; }
        public decimal SharedOutRegularHours { get; set; }
        public decimal OvertimeHours { get; set; }
        public decimal SharedInOvertimeHours { get; set; }
        public decimal ContractHours { get; set; }
        public decimal ProductiveActualHours { get; set; }
        public decimal ProductiveHoursVariance { get; set; }
        public decimal ProductiveIndexPercent { get; set; }
        public decimal ProductiveFtes { get; set; }
        public decimal ProductiveTargetHoursUOS { get; set; }
        public decimal ProductiveActualHoursUOS { get; set; }
        public decimal SharedOutOvertimeHours { get; set; }
        public decimal ErVisits { get; set; }
        public decimal MsHolds { get; set; }
        public decimal IcuHolds { get; set; }
        public decimal WeightedMsVisits { get; set; }
        public decimal WeightedIcuVisits { get; set; }
        public HashSet<string> AvailableFields { get; set; } = new HashSet<string>();
    }

    public class DailyUosErVisitsHoldsReportCriteria
    {
        public string ReportType { get; set; }
        public string ReportPeriod { get; set; }
        public int DepartmentNumber { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
