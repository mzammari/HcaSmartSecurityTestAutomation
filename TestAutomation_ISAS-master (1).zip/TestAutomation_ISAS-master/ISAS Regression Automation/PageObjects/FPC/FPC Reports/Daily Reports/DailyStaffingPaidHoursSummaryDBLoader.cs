using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingPaidHoursSummaryDBLoader
    {
        public static List<DailyStaffingPaidHoursSummaryData> LoadFromDatabase(string reportType, string reportPeriod, DateTime startDate, DateTime endDate)
        {
            var result = new List<DailyStaffingPaidHoursSummaryData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = DailyStaffingPaidHoursSummarySP.GetDailyStaffingPaidHoursSummaryQuery(reportType, reportPeriod, startDate, endDate);

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new DailyStaffingPaidHoursSummaryData
                            {
                                DeptGroupNum = GetString(reader, "DEPT_OR_GROUP_NUM"),
                                DepartmentGroupName = GetString(reader, "DEPT_OR_GROUP_DESC"),
                                StatisticDescription = GetString(reader, "STAT_DESC"),
                                TargetProdHoursUOS = GetDecimal(reader, "TGT_PROD_HRS_UOS"),
                                TargetPaidHoursUOS = GetDecimal(reader, "TGT_PAID_HRS_UOS"),
                                TargetSvProdFtes = GetDecimal(reader, "TGT_SV_PROD_FTES"),
                                ActualUOS = GetDecimal(reader, "ACT_UOS"),
                                ProductiveHoursTarget = GetDecimal(reader, "F_TGT"),
                                ProductiveHoursActual = GetDecimal(reader, "F_ACT"),
                                ProductiveHoursVariance = GetDecimal(reader, "F_VAR"),
                                PaidHoursTarget = GetDecimal(reader, "F_TGT_PAID"),
                                PaidHoursActual = GetDecimal(reader, "F_ACT_PAID"),
                                PaidHoursVariance = GetDecimal(reader, "F_VAR_PAID"),
                                CumulativeUOS = GetDecimal(reader, "F_CUM_UOS"),
                                CumulativeProductiveHoursTarget = GetDecimal(reader, "F_CUM_TGT"),
                                CumulativeProductiveHoursActual = GetDecimal(reader, "F_CUM_ACT"),
                                CumulativePaidHoursTarget = GetDecimal(reader, "F_CUM_TGT_PAID"),
                                CumulativePaidHoursActual = GetDecimal(reader, "F_CUM_ACT_PAID"),
                                CumulativeProductiveHoursVariance = GetDecimal(reader, "F_CUM_VAR"),
                                CumulativePaidHoursVariance = GetDecimal(reader, "F_CUM_VAR_PAID"),
                                CumulativeNegativeVariance = GetDecimal(reader, "F_CUM_VAR_NEG"),
                                OvertimeFtes = GetDecimal(reader, "F_CUM_OT"),
                                OvertimePercent = GetDecimal(reader, "F_CUM_OT_PCT"),
                                HwsContractProdHours = GetDecimal(reader, "F_CUM_HWS_CONTR"),
                                VendorContractProdHours = GetDecimal(reader, "F_CUM_VEN_CONTR"),
                                ContractFtes = GetDecimal(reader, "F_CUM_CONTR"),
                                ContractPercent = GetDecimal(reader, "F_CUM_CONTR_PCT"),
                                ProductiveIndexPercent = GetDecimal(reader, "F_CUM_PROD_INDEX"),
                                PaidIndexPercent = GetDecimal(reader, "F_CUM_PAID_INDEX"),
                                TargetMinimumHours = GetDecimal(reader, "TARGET_MIN_HOURS"),
                                PRNFtes = GetDecimal(reader, "F_CUM_PRN"),
                                PRNPercent = GetDecimal(reader, "F_CUM_PRN_PCT")
                            });
                        }
                    }
                }
            }

            return result;
        }

        private static string GetString(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    return reader.IsDBNull(ordinal) ? string.Empty : reader.GetValue(ordinal).ToString().Trim();
                }
                catch (IndexOutOfRangeException)
                {
                }
            }

            return string.Empty;
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;

                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;

                    string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                    return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
                }
                catch
                {
                }
            }

            return 0m;
        }
    }
}
