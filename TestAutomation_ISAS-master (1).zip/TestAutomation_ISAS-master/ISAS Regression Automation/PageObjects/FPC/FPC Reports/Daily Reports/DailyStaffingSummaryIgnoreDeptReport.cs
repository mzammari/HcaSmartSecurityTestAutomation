﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation.PageObjects.FPC.FPC_Reports.Daily_Reports
{
    internal class DailyStaffingSummaryIgnoreDeptReport
    {
        public static void GoTo()
        {
            FpcReportMenu.DailyTrendReport.SelectDailyStaffingSummaryIgnoreDeptReport();
            CommonFunctions.AddTestStep("Select Daily Staffing Summary Ignore Dept Report", "The Daily Staffing Summary Ignore Dept Report is displayed");
        }
        public static bool IsAt
        {
            get
            {
                By byReportType = By.XPath("//select[@id='ddlReportType'] ");
                CommonFunctions.AddTestStep("Verify the Daily Staffing Summary Ignore Dept Report page is active", "The plan page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byReportType, 20);
            }
        }

        public static DailyStaffingSummaryIgnoreDeptReportCommand dailyStaffingSummaryIgnoreDeptReport()
        {
            return new DailyStaffingSummaryIgnoreDeptReportCommand();
        }

        #region: DailyStaffingSummaryIgnoreDeptReportCommand            
        public class DailyStaffingSummaryIgnoreDeptReportCommand
        {
            private string reportType;
            private string reportPeriod;

            
            public DailyStaffingSummaryIgnoreDeptReportCommand withReportType(string ReportType)
            {
                this.reportType = ReportType;
                return this;

            }

            public DailyStaffingSummaryIgnoreDeptReportCommand withReportPeriod(string ReportPeriod)
            {
                this.reportPeriod = ReportPeriod;
                return this;
            }
          

            private void setReportType()
            {
                By byReportType = By.XPath("//select[@id='ddlReportType']");
                IWebElement mnuReportType = CommonFunctions.getElement(byReportType);
                CommonFunctions.SelectItemFromDropdownMenu(mnuReportType, reportType);
                CommonFunctions.AddTestStep($"Verify a user can select {reportType} from Report Type dropdown", $"The {reportType} is selected correctly");
            }

            private void setReportPeriod()
            {
                By byReportPeriod = By.XPath("//select[@id='payPeriodID']");
                IWebElement mnuReportPeriod = CommonFunctions.getElement(byReportPeriod);
                CommonFunctions.SelectItemFromDropdownMenu(mnuReportPeriod, reportPeriod);
                CommonFunctions.AddTestStep($"Verify a user can select {reportPeriod} from Report Period dropdown", $"The {reportPeriod} is selected correctly");
            }

            private void clickPDF()
            {
                By byPDF = By.XPath("//img[@title='PDF Format']");
                IWebElement cmdPDF = CommonFunctions.getElement(byPDF);
                CommonFunctions.ClickByJE(cmdPDF);
                CommonFunctions.AddTestStep($"Verify a user can click the PDF button", $"The PDF button is enabled and clickable");
            }

            private void clickExcel()
            {
                By byExcel = By.XPath("//img[@title='Excel Format']");
                IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
                //CommonFunctions.ClickByJE(cmdExcel);
                cmdExcel.Click();
                //Thread.Sleep(240000);
                CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
            }



            public void PDF()
            {
                setReportType();
                setReportPeriod();
             
                clickPDF();
                CommonFunctions.WaitUntilPageIsAcive();
            }

            public void Excel()
            {
                setReportType();
                setReportPeriod();
        
                clickExcel();
                CommonFunctions.WaitUntilPageIsAcive();
            }


        }
    }   
    #endregion
}
