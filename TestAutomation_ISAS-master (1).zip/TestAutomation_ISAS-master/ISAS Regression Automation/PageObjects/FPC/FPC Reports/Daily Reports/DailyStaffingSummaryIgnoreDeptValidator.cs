using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingSummaryIgnoreDeptValidator
    {
        private const decimal TOLERANCE = 0.01m;

        public static void Validate(List<DailyStaffingSummaryIgnoreDeptData> excelData, List<DailyStaffingSummaryIgnoreDeptData> dbData)
        {
            Console.WriteLine("=== Daily Staffing Summary Ignore Dept Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            var mismatches = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;
            int skippedRows = 0;
            int skippedFields = 0;

            foreach (var dbRow in dbData)
            {
                var excelRow = excelData.FirstOrDefault(e => IsSameRow(e, dbRow));
                if (excelRow == null)
                {
                    skippedRows++;
                    continue;
                }

                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.ProdIdxPct), excelRow.ProdIdxPct, dbRow.ProdIdxPct);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.VarProdStdHoursUOS), excelRow.VarProdStdHoursUOS, dbRow.VarProdStdHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.SemiVarProdStdFtes), excelRow.SemiVarProdStdFtes, dbRow.SemiVarProdStdFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.UOS), excelRow.UOS, dbRow.UOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.TargetProdHours), excelRow.TargetProdHours, dbRow.TargetProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.ActualProdHours), excelRow.ActualProdHours, dbRow.ActualProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.VarProdHours), excelRow.VarProdHours, dbRow.VarProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.DailyUOS), excelRow.DailyUOS, dbRow.DailyUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.TargetProdHoursCumulative), excelRow.TargetProdHoursCumulative, dbRow.TargetProdHoursCumulative);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.ActualProdHoursCumulative), excelRow.ActualProdHoursCumulative, dbRow.ActualProdHoursCumulative);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.VarProdHoursCumulative), excelRow.VarProdHoursCumulative, dbRow.VarProdHoursCumulative);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.PRNProdHours), excelRow.PRNProdHours, dbRow.PRNProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.PRNPercentValue), excelRow.PRNPercentValue, dbRow.PRNPercentValue);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.OTProdHours), excelRow.OTProdHours, dbRow.OTProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.OTPercentValue), excelRow.OTPercentValue, dbRow.OTPercentValue);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.HwsCLProdHours), excelRow.HwsCLProdHours, dbRow.HwsCLProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.VendorCLProdHours), excelRow.VendorCLProdHours, dbRow.VendorCLProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.TotalCLProdHours), excelRow.TotalCLProdHours, dbRow.TotalCLProdHours);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryIgnoreDeptData.TotalCLPercent), excelRow.TotalCLPercent, dbRow.TotalCLPercent);
            }

            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine("Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");
            Console.WriteLine($"  Skipped DB rows not present in Excel: {skippedRows}");
            Console.WriteLine($"  Skipped fields not present in Excel: {skippedFields}");

            if (totalComparisons == 0)
            {
                Console.WriteLine("No matching Excel columns were available for DB2 validation. Skipping validation.");
                return;
            }

            if (mismatches.Count > 0)
            {
                Console.WriteLine("\nMismatches:");
                Console.WriteLine($"{"DeptGroup",-12} {"Field",-30} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 70));

                foreach (var mismatch in mismatches)
                    Console.WriteLine(mismatch);

                Assert.Fail($"Daily Staffing Summary Ignore Dept validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons.");
            }

            Console.WriteLine("\nDaily Staffing Summary Ignore Dept validated successfully - all available values match.");
        }

        private static void CompareField(
            List<string> mismatches,
            ref int totalComparisons,
            ref int matchCount,
            ref int skippedFields,
            DailyStaffingSummaryIgnoreDeptData excelRow,
            string fieldName,
            decimal excelValue,
            decimal dbValue)
        {
            if (excelRow.AvailableFields.Any() && !excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            bool isMatch = Math.Abs(excelValue - dbValue) <= TOLERANCE;

            if (isMatch)
            {
                matchCount++;
                return;
            }

            mismatches.Add($"{excelRow.DeptGroupNum,-12} {fieldName,-30} {excelValue,12:N4} {dbValue,12:N4}");
        }

        private static bool IsSameRow(DailyStaffingSummaryIgnoreDeptData excelRow, DailyStaffingSummaryIgnoreDeptData dbRow)
        {
            return Normalize(excelRow.DeptGroupNum) == Normalize(dbRow.DeptGroupNum)
                && Normalize(excelRow.StatisticDescription) == Normalize(dbRow.StatisticDescription);
        }

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : string.Join(" ", value.Trim().Split(' ').Where(s => !string.IsNullOrWhiteSpace(s))).ToUpperInvariant();
        }
    }
}

