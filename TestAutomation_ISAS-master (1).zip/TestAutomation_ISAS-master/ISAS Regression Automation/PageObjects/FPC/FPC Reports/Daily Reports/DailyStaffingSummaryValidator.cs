using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingSummaryValidator
    {
        private const decimal TOLERANCE = 0.01m;

        public static void Validate(List<DailyStaffingSummaryData> excelData, List<DailyStaffingSummaryData> dbData)
        {
            Console.WriteLine("=== Daily Staffing Summary Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            var mismatches = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;
            int skippedRows = 0;
            int skippedFields = 0;

            foreach (var dbRow in dbData)
            {
                var excelRow = excelData.FirstOrDefault(e => IsSameRow(e, dbRow));

                if (excelRow == null)
                {
                    skippedRows++;
                    continue;
                }

                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.PaidIdxTargetActualFtesPercent), excelRow.PaidIdxTargetActualFtesPercent, dbRow.PaidIdxTargetActualFtesPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.UOSActual), excelRow.UOSActual, dbRow.UOSActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.TargetProdHoursUOS), excelRow.TargetProdHoursUOS, dbRow.TargetProdHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.ActualProdHoursUOS), excelRow.ActualProdHoursUOS, dbRow.ActualProdHoursUOS);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.ActualNonProdPercent), excelRow.ActualNonProdPercent, dbRow.ActualNonProdPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.ProductiveFtesTarget), excelRow.ProductiveFtesTarget, dbRow.ProductiveFtesTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.ProductiveFtesActual), excelRow.ProductiveFtesActual, dbRow.ProductiveFtesActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.ProductiveFtesVariance), excelRow.ProductiveFtesVariance, dbRow.ProductiveFtesVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.PaidFtesTarget), excelRow.PaidFtesTarget, dbRow.PaidFtesTarget);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.PaidFtesActual), excelRow.PaidFtesActual, dbRow.PaidFtesActual);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.PaidFtesVariance), excelRow.PaidFtesVariance, dbRow.PaidFtesVariance);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.OvertimeFtes), excelRow.OvertimeFtes, dbRow.OvertimeFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.OvertimePercent), excelRow.OvertimePercent, dbRow.OvertimePercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.OvertimeTargetPercent), excelRow.OvertimeTargetPercent, dbRow.OvertimeTargetPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.ContractFtes), excelRow.ContractFtes, dbRow.ContractFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.ContractPercent), excelRow.ContractPercent, dbRow.ContractPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.ContractTargetPercent), excelRow.ContractTargetPercent, dbRow.ContractTargetPercent);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.PRNFtes), excelRow.PRNFtes, dbRow.PRNFtes);
                CompareField(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(DailyStaffingSummaryData.PRNPercent), excelRow.PRNPercent, dbRow.PRNPercent);
            }

            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine("Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");
            Console.WriteLine($"  Skipped DB rows not present in Excel: {skippedRows}");
            Console.WriteLine($"  Skipped fields not present in Excel: {skippedFields}");

            if (mismatches.Count > 0)
            {
                Console.WriteLine("\nMismatches:");
                Console.WriteLine($"{"DeptGroup",-12} {"Field",-30} {"Excel",12} {"DB",12}");
                Console.WriteLine(new string('-', 70));

                foreach (var mismatch in mismatches)
                {
                    Console.WriteLine(mismatch);
                }

                Assert.Fail($"Daily Staffing Summary validation failed: {mismatches.Count} mismatches found out of {totalComparisons} comparisons.");
            }

            Console.WriteLine("\nDaily Staffing Summary validated successfully - all values match.");
        }

        private static void CompareField(
            List<string> mismatches,
            ref int totalComparisons,
            ref int matchCount,
            ref int skippedFields,
            DailyStaffingSummaryData excelRow,
            string fieldName,
            decimal excelValue,
            decimal dbValue)
        {
            if (excelRow.AvailableFields.Any() && !excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            bool isMatch = Math.Abs(excelValue - dbValue) <= TOLERANCE;

            if (isMatch)
            {
                matchCount++;
                return;
            }

            mismatches.Add($"{excelRow.DeptGroupNum,-12} {fieldName,-30} {excelValue,12:N4} {dbValue,12:N4}");
        }

        private static bool IsSameRow(DailyStaffingSummaryData excelRow, DailyStaffingSummaryData dbRow)
        {
            bool hasCoid = !string.IsNullOrWhiteSpace(excelRow.Coid) && !string.IsNullOrWhiteSpace(dbRow.Coid);

            return (!hasCoid || Normalize(excelRow.Coid) == Normalize(dbRow.Coid))
                && Normalize(excelRow.DeptGroupNum) == Normalize(dbRow.DeptGroupNum)
                && Normalize(excelRow.StatisticDescription) == Normalize(dbRow.StatisticDescription);
        }

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : string.Join(" ", value.Trim().Split(' ').Where(s => !string.IsNullOrWhiteSpace(s))).ToUpperInvariant();
        }
    }
}