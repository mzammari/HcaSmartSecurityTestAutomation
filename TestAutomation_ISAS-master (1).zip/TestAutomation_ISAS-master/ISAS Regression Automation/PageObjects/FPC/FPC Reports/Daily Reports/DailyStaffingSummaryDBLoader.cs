using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;

namespace ISAS_Regression_Automation
{
    public static class DailyStaffingSummaryDBLoader
    {
        public static List<DailyStaffingSummaryData> LoadFromDatabase(string division, string reportType, string reportPeriod, DateTime startDate, DateTime endDate)
        {
            return LoadFromDatabase(reportType, reportPeriod, startDate, endDate, division);
        }

        public static List<DailyStaffingSummaryData> LoadFromDatabase(string reportType, string reportPeriod, DateTime startDate, DateTime endDate)
        {
            return LoadFromDatabase(reportType, reportPeriod, startDate, endDate, null);
        }

        private static List<DailyStaffingSummaryData> LoadFromDatabase(string reportType, string reportPeriod, DateTime startDate, DateTime endDate, string division)
        {
            var result = new List<DailyStaffingSummaryData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = string.IsNullOrWhiteSpace(division)
                ? DailyStaffingSummarySP.GetDailyStaffingSummaryQuery(reportType, reportPeriod, startDate, endDate)
                : DailyStaffingSummarySP.GetDailyStaffingSummaryQuery(division, reportType, reportPeriod, startDate, endDate);

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new DailyStaffingSummaryData
                            {
                                Coid = GetString(reader, "Coid", "CO_ID"),
                                FacilityName = GetString(reader, "FacilityName", "FACILITY_NAME"),
                                DeptGroupNum = GetString(reader, "DeptGroupNum", "DEPT_OR_GROUP_NUM"),
                                DepartmentGroupName = GetString(reader, "DepartmentGroupName", "DEPT_OR_GROUP_DESC"),
                                StatisticDescription = GetString(reader, "StatisticDescription", "STAT_DESC"),
                                PaidIdxTargetActualFtesPercent = GetDecimal(reader, "PaidIdxTargetActualFtesPercent", "PAID_IDX_PCT", "F_CUM_PROD_INDEX"),
                                UOSActual = GetDecimal(reader, "UOSActual", "UOS_ACT", "ACT_UOS", "F_CUM_UOS"),
                                TargetProdHoursUOS = GetDecimal(reader, "TargetProdHoursUOS", "PROD_HRS_UOS_TGT", "TGT_PROD_HRS_UOS"),
                                ActualProdHoursUOS = GetDecimal(reader, "ActualProdHoursUOS", "PROD_HRS_UOS_ACT", "F_ACT"),
                                ActualNonProdPercent = GetDecimal(reader, "ActualNonProdPercent", "NON_PROD_PCT_ACT"),
                                ProductiveFtesTarget = GetDecimal(reader, "ProductiveFtesTarget", "PROD_FTES_TGT", "TGT_SV_PROD_FTES", "F_CUM_TGT"),
                                ProductiveFtesActual = GetDecimal(reader, "ProductiveFtesActual", "PROD_FTES_ACT", "F_CUM_ACT"),
                                ProductiveFtesVariance = GetDecimal(reader, "ProductiveFtesVariance", "PROD_FTES_VAR", "F_VAR", "F_CUM_VAR"),
                                PaidFtesTarget = GetDecimal(reader, "PaidFtesTarget", "PAID_FTES_TGT", "F_CUM_TGT"),
                                PaidFtesActual = GetDecimal(reader, "PaidFtesActual", "PAID_FTES_ACT", "F_CUM_ACT"),
                                PaidFtesVariance = GetDecimal(reader, "PaidFtesVariance", "PAID_FTES_VAR", "F_CUM_VAR"),
                                OvertimeFtes = GetDecimal(reader, "OvertimeFtes", "OT_FTES_ACT", "F_CUM_OT"),
                                OvertimePercent = GetDecimal(reader, "OvertimePercent", "OT_PCT_ACT", "F_CUM_OT_PCT"),
                                OvertimeTargetPercent = GetDecimal(reader, "OvertimeTargetPercent", "OT_PCT_TGT"),
                                ContractFtes = GetDecimal(reader, "ContractFtes", "CONTR_FTES_ACT", "F_CUM_CONTR"),
                                ContractPercent = GetDecimal(reader, "ContractPercent", "CONTR_PCT_ACT", "F_CUM_CONTR_PCT"),
                                ContractTargetPercent = GetDecimal(reader, "ContractTargetPercent", "CONTR_PCT_TGT"),
                                PRNFtes = GetDecimal(reader, "PRNFtes", "PRN_FTE", "F_CUM_PRN"),
                                PRNPercent = GetDecimal(reader, "PRNPercent", "PRN_FTE_PCT", "F_CUM_PRN_PCT"),
                            });
                        }
                    }
                }
            }

            return result;
        }

        private static string GetString(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    return reader.IsDBNull(ordinal) ? string.Empty : reader.GetValue(ordinal).ToString().Trim();
                }
                catch (IndexOutOfRangeException)
                {
                }
            }

            return string.Empty;
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;

                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;

                    string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                    return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
                }
                catch
                {
                }
            }

            return 0m;
        }
    }
}

