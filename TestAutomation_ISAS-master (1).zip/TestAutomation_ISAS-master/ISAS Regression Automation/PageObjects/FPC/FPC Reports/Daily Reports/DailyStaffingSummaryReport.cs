﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class DailyStaffingSummaryReport
    {
        public static void GoTo()
        {
            FpcReportMenu.DailyTrendReport.SelectDailyStaffingSummary();
            CommonFunctions.AddTestStep("Select Daily Staffing Summary Report ", "The Daily Staffing Summary Report is displayed");
        }

        public static bool IsAt
        {
            get
            {
                By byReportType = By.XPath("//select[@id='ddlReportType']");
                CommonFunctions.AddTestStep("Verify the Daily Staffing Summary Report  page is active", "The Daily Staffing Summary Report page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byReportType, 20);
            }
        }

        public static DailyStaffingSummaryCommand dailyStaffingSummaryReport()
        {
            return new DailyStaffingSummaryCommand();

        }
    }

    #region: DailyStaffingSummaryCommand
    public class DailyStaffingSummaryCommand
    {
        private string reportType;
        private string reportPeriod;
        private string dateInMonth;

        public DailyStaffingSummaryCommand withReportType(string ReportType)
        {
            this.reportType = ReportType;
            return this;
        }

        public DailyStaffingSummaryCommand withReportPeriod(string ReportPeriod)
        {
            this.reportPeriod = ReportPeriod;
            return this;
        }

        public DailyStaffingSummaryCommand withDateInMonth(string DateInMonth)
        {
            this.dateInMonth = DateInMonth;
            return this;
        }

        private void setReportType()
        {
            By byReportType = By.XPath("//select[@id='ddlReportType']");
            IWebElement mnuReportType = CommonFunctions.getElement(byReportType);
            CommonFunctions.SelectItemFromDropdownMenu(mnuReportType, reportType);
            CommonFunctions.AddTestStep($"Verify a user can select {reportType} from Report Type dropdown", $"The {reportType} is selected correctly");
        }

        private void setReportPeriod()
        {
            By byReportPeriod = By.XPath("//select[@id='payPeriodID']");
            IWebElement mnuReportPeriod = CommonFunctions.getElement(byReportPeriod);
            CommonFunctions.SelectItemFromDropdownMenu(mnuReportPeriod, reportPeriod);
            CommonFunctions.AddTestStep($"Verify a user can select {reportPeriod} from Report Period dropdown", $"The {reportPeriod} is selected correctly");
        }

        private void setDateInMonth()
        {
            By byDateInMonth = By.XPath("//input[@id='datePickerReportTo']");
            string getCurrentDate = CommonFunctions.getCurrentDate();
           // IWebElement mnuDateInMonth = CommonFunctions.getElement(byDateInMonth);
           // CommonFunctions.SetText(mnuDateInMonth, getCurrentDate);
            CommonFunctions.AddTestStep($"Verify a user can enter {getCurrentDate} in the Date In Month textbox", $"The {getCurrentDate} is set correctly");
        }

        private void clickPDF()
        {
            By byPDF = By.XPath("//img[@title='PDF Format']");
            IWebElement cmdPDF = CommonFunctions.getElement(byPDF);
            CommonFunctions.ClickByJE(cmdPDF);
            CommonFunctions.AddTestStep($"Verify a user can click the PDF button", $"The PDF button is enabled and clickable");
        }

        private void clickExcel()
        {
            By byExcel = By.XPath("//img[@title='Excel (new) Format']");
            IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
            CommonFunctions.ClickByJE(cmdExcel);
            CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
        }

        public void PDF()
        {
            setReportType();
            setReportPeriod();
            setDateInMonth();
            clickPDF();
        }

        public void Excel()
        {
            setReportType();
            setReportPeriod();
            setDateInMonth();
            clickExcel();
        }

    }
    #endregion
}
