﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation.PageObjects.FPC.FPC_Reports.Daily_Reports
{
    public class DailyStaffingSummaryDivisionReport
    {
        public static void GoTo()
        {
            FpcReportMenu.DailyTrendReport.SelectDailyStaffingSummaryDivisionReport();      
            CommonFunctions.AddTestStep("Select Daily Staffing Summary Division Report", "The Daily Staffing Summary Division Report is displayed");
        }
        public static bool IsAt
        {
            get
            {
                By byReportType = By.XPath("//select[@id='ddlReportType'] ");
                CommonFunctions.AddTestStep("Verify the Daily Summery Staffing Division Report  page is active", "The plan page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byReportType, 20);
            }
        }

        public static DailyStaffingSummaryDivisionReportCommand dailyStaffingSummaryDivisionReport()
        {
            return new DailyStaffingSummaryDivisionReportCommand();
        }



        #region: DailyStaffingSummaryDivisionReportCommand
        public class DailyStaffingSummaryDivisionReportCommand
        {
            private string division;
            private string reportType;
            private string reportPeriod;

            public DailyStaffingSummaryDivisionReportCommand withDivision(string Division)
            {
                this.division = Division;
                return this;
            }
            public DailyStaffingSummaryDivisionReportCommand withReportType(string ReportType)
            {
                this.reportType = ReportType;
                return this;
            }

            public DailyStaffingSummaryDivisionReportCommand withReportPeriod(string ReportPeriod)
            {
                this.reportPeriod = ReportPeriod;
                return this;
            }

            private void setDivision()
            {
                By byDivision = By.XPath("(//select[@id='ReportDivisionList'])[1]");
                IWebElement mnuDivision = CommonFunctions.getElement(byDivision);
                mnuDivision.Click();
                SelectDivisionFromDropdown(mnuDivision, division);
                CommonFunctions.AddTestStep($"Verify a user can select {division} from Division dropdown", $"The {division} is selected correctly");
            }

            private static void SelectDivisionFromDropdown(IWebElement dropdown, string division)
            {
                if (string.IsNullOrWhiteSpace(division))
                    throw new ArgumentException("Division value cannot be empty.", nameof(division));

                IWebElement option = null;
                DateTime timeout = DateTime.Now.AddSeconds(20);

                while (DateTime.Now < timeout && option == null)
                {
                    var options = dropdown.FindElements(By.TagName("option"));
                    option = options.FirstOrDefault(o => IsDivisionOptionMatch(o, division));

                    if (option == null)
                        Thread.Sleep(1000);
                }

                if (option == null)
                {
                    string availableOptions = string.Join(", ", dropdown.FindElements(By.TagName("option")).Select(o => $"Text='{o.Text}', Value='{o.GetAttribute("value")}'"));
                    throw new InvalidOperationException($"Could not find division '{division}' in the Division dropdown. Available options: {availableOptions}");
                }

                option.Click();
                CommonFunctions.WaitTillPageIsComplete();
            }

            private static bool IsDivisionOptionMatch(IWebElement option, string division)
            {
                string optionText = option.Text?.Trim() ?? string.Empty;
                string optionValue = option.GetAttribute("value")?.Trim() ?? string.Empty;
                string divisionText = division.Trim();
                string divisionNumber = GetDivisionNumberText(divisionText);

                return optionText.Equals(divisionText, StringComparison.OrdinalIgnoreCase)
                    || optionText.Contains(divisionText, StringComparison.OrdinalIgnoreCase)
                    || optionValue.Equals(divisionText, StringComparison.OrdinalIgnoreCase)
                    || (!string.IsNullOrWhiteSpace(divisionNumber)
                        && (optionValue.Equals(divisionNumber, StringComparison.OrdinalIgnoreCase)
                            || optionText.Equals(divisionNumber, StringComparison.OrdinalIgnoreCase)
                            || optionText.Contains($"Division {divisionNumber}", StringComparison.OrdinalIgnoreCase)));
            }

            private static string GetDivisionNumberText(string division)
            {
                if (int.TryParse(division, out int divisionNumber))
                    return divisionNumber.ToString();

                string digits = new string(division.Where(char.IsDigit).ToArray());
                if (!string.IsNullOrWhiteSpace(digits))
                    return digits;

                for (int index = division.Length - 1; index >= 0; index--)
                {
                    if (char.IsLetter(division[index]))
                        return (char.ToUpperInvariant(division[index]) - 'A' + 1).ToString();
                }

                return string.Empty;
            }

            private void setReportType()
            {
                By byReportType = By.XPath("//select[@id='ddlReportType']");
                IWebElement mnuReportType = CommonFunctions.getElement(byReportType);
                CommonFunctions.SelectItemFromDropdownMenu(mnuReportType, reportType);
                CommonFunctions.AddTestStep($"Verify a user can select {reportType} from Report Type dropdown", $"The {reportType} is selected correctly");
            }

            private void setReportPeriod()
            {
                By byReportPeriod = By.XPath("//select[@id='payPeriodID']");
                IWebElement mnuReportPeriod = CommonFunctions.getElement(byReportPeriod);
                CommonFunctions.SelectItemFromDropdownMenu(mnuReportPeriod, reportPeriod);
                CommonFunctions.AddTestStep($"Verify a user can select {reportPeriod} from Report Period dropdown", $"The {reportPeriod} is selected correctly");
            }

           

            private void clickPDF()
            {
                By byPDF = By.XPath("//img[@title='PDF Format']");
                IWebElement cmdPDF = CommonFunctions.getElement(byPDF);
                CommonFunctions.ClickByJE(cmdPDF);
                CommonFunctions.AddTestStep($"Verify a user can click the PDF button", $"The PDF button is enabled and clickable");
            }

            private void clickExcel()
            {
                By byExcel = By.XPath("//img[@title='Excel (new) Format']");
                IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
                //CommonFunctions.ClickByJE(cmdExcel);
                cmdExcel.Click();
                Thread.Sleep(240000);
                CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
            }



            public void PDF()
            {
                setReportType();
                setReportPeriod();
                setDivision();
                clickPDF();
                CommonFunctions.WaitUntilPageIsAcive();
            }

            public void Excel()
            {
                setReportType();
                setReportPeriod();
                setDivision();
                clickExcel();
                CommonFunctions.WaitUntilPageIsAcive();
            }



        }

    }
    #endregion

}