using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;

namespace ISAS_Regression_Automation
{
    public static class DailyUosErVisitsHoldsDBLoader
    {
        public static List<DailyUosErVisitsHoldsData> LoadFromDatabase(string reportType, string reportPeriod, int departmentNumber, DateTime startDate, DateTime endDate)
        {
            var result = new List<DailyUosErVisitsHoldsData>();

            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";

            string sqlQuery = DailyUosErVisitsHoldsSP.GetDailyUosErVisitsHoldsQuery(reportType, reportPeriod, departmentNumber, startDate, endDate);

            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();

                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 120;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new DailyUosErVisitsHoldsData
                            {
                                Date = GetDate(reader, "DT"),
                                UOS = GetDecimal(reader, "ACT_UOS"),
                                ProductiveTargetHours = GetDecimal(reader, "TGT_PRODHRS_TOTAL1"),
                                FtPtRegularHours = GetDecimal(reader, "ACT_PRODHRS_STAFF"),
                                PrnRegularHours = GetDecimal(reader, "ACT_PRODHRS_PRN"),
                                SharedInRegularHours = GetDecimal(reader, "PROD_HOURS_IN"),
                                SharedOutRegularHours = GetDecimal(reader, "PROD_HOURS_OUT"),
                                OvertimeHours = GetDecimal(reader, "ACT_PRODHRS_OT"),
                                SharedInOvertimeHours = GetDecimal(reader, "OVERTIME_HOURS_IN"),
                                ContractHours = GetDecimal(reader, "ACT_PRODHRS_CONTR"),
                                ProductiveActualHours = GetDecimal(reader, "ACT_PRODHRS_TOTAL"),
                                ProductiveHoursVariance = GetDecimal(reader, "VAR_PRODHRS"),
                                ProductiveIndexPercent = GetDecimal(reader, "PCT_PROD_INDEX"),
                                ProductiveFtes = GetDecimal(reader, "ACT_PROD_FTES"),
                                ProductiveTargetHoursUOS = GetDecimal(reader, "TGT_PROD_HRS_UOS"),
                                ProductiveActualHoursUOS = GetDecimal(reader, "ACT_PROD_HRS_UOS"),
                                SharedOutOvertimeHours = GetDecimal(reader, "OVERTIME_HOURS_OUT"),
                                ErVisits = GetDecimal(reader, "ER_VISITS"),
                                MsHolds = GetDecimal(reader, "MS_HOLD"),
                                IcuHolds = GetDecimal(reader, "ICU_HOLD"),
                                WeightedMsVisits = GetDecimal(reader, "WEIGHTED_MS_HOLD"),
                                WeightedIcuVisits = GetDecimal(reader, "WEIGHTED_ICU_HOLD")
                            });
                        }
                    }
                }
            }

            return result;
        }

        private static DateTime GetDate(IDataReader reader, string columnName)
        {
            try
            {
                int ordinal = reader.GetOrdinal(columnName);
                if (reader.IsDBNull(ordinal))
                    return default;

                var value = reader.GetValue(ordinal);
                if (value is DateTime date)
                    return date.Date;

                return DateTime.TryParse(value.ToString(), out DateTime parsed) ? parsed.Date : default;
            }
            catch
            {
                return default;
            }
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;

                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;

                    string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                    return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
                }
                catch
                {
                }
            }

            return 0m;
        }
    }
}
