using ExcelDataReader;
using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    public class DailyStaffingSummaryData
    {
        public string Coid { get; set; }
        public string FacilityName { get; set; }
        public string DeptGroupNum { get; set; }
        public string DepartmentGroupName { get; set; }
        public string StatisticDescription { get; set; }
        public decimal PaidIdxTargetActualFtesPercent { get; set; }
        public decimal UOSActual { get; set; }
        public decimal TargetProdHoursUOS { get; set; }
        public decimal ActualProdHoursUOS { get; set; }
        public decimal ActualNonProdPercent { get; set; }
        public decimal ProductiveFtesTarget { get; set; }
        public decimal ProductiveFtesActual { get; set; }
        public decimal ProductiveFtesVariance { get; set; }
        public decimal PaidFtesTarget { get; set; }
        public decimal PaidFtesActual { get; set; }
        public decimal PaidFtesVariance { get; set; }
        public decimal OvertimeFtes { get; set; }
        public decimal OvertimePercent { get; set; }
        public decimal OvertimeTargetPercent { get; set; }
        public decimal ContractFtes { get; set; }
        public decimal ContractPercent { get; set; }
        public decimal ContractTargetPercent { get; set; }
        public decimal PRNFtes { get; set; }
        public decimal PRNPercent { get; set; }
        public HashSet<string> AvailableFields { get; set; } = new HashSet<string>();
    }

    public class DailyStaffingSummaryReportCriteria
    {
        public string Division { get; set; }
        public string ReportType { get; set; }
        public string ReportPeriod { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public static class DailyStaffingSummaryExcelReport
    {
        public static List<DailyStaffingSummaryData> ParseDailyStaffingSummaryExcel(string filePath)
        {
            var result = new List<DailyStaffingSummaryData>();
            var allRows = ReadRows(filePath);

            int startRowIndex = FindDailyStaffingSummaryHeaderRow(allRows);

            if (startRowIndex == -1)
            {
                Console.WriteLine("Could not find Daily Staffing Summary header row in the Excel file. Treating Excel report as no data.");
                return result;
            }

            bool isDivisionReport = IsDivisionHeaderRow(allRows[startRowIndex]);

            for (int i = startRowIndex + 1; i < allRows.Count; i++)
            {
                var row = allRows[i];

                if (CommonFunctions.IsEmptyRow(row))
                    continue;

                string deptGroupNum = isDivisionReport ? CommonFunctions.GetStringValue(row, 2) : CommonFunctions.GetStringValue(row, 0);
                if (string.IsNullOrWhiteSpace(deptGroupNum))
                    continue;

                result.Add(isDivisionReport
                    ? GetDivisionReportRow(row, deptGroupNum)
                    : GetSummaryReportRow(row, deptGroupNum));
            }

            return result;
        }

        public static DailyStaffingSummaryReportCriteria GetReportCriteria(string filePath, string fallbackReportType, string fallbackReportPeriod, string fallbackDivision = null)
        {
            var allRows = ReadRows(filePath);
            int headerRowIndex = FindDailyStaffingSummaryHeaderRow(allRows);
            var headerRows = headerRowIndex > 0 ? allRows.Take(headerRowIndex).ToList() : allRows.Take(10).ToList();

            string division = FindDivision(headerRows) ?? fallbackDivision;
            string reportType = FindReportType(headerRows) ?? fallbackReportType;
            string reportPeriod = FindReportPeriod(headerRows) ?? fallbackReportPeriod;
            var dates = FindDates(headerRows).Distinct().OrderBy(d => d).ToList();

            if (dates.Count >= 1)
            {
                DateTime endDate = dates.Last();
                return new DailyStaffingSummaryReportCriteria
                {
                    Division = division,
                    ReportType = reportType,
                    ReportPeriod = reportPeriod,
                    StartDate = GetStartDate(reportType, endDate),
                    EndDate = endDate
                };
            }

            throw new InvalidOperationException("Could not find report date values in the Daily Staffing Summary Excel file.");
        }

        private static DailyStaffingSummaryData GetSummaryReportRow(object[] row, string deptGroupNum)
        {
            return new DailyStaffingSummaryData
            {
                DeptGroupNum = deptGroupNum,
                DepartmentGroupName = CommonFunctions.GetStringValue(row, 1),
                StatisticDescription = CommonFunctions.GetStringValue(row, 2),
                PaidIdxTargetActualFtesPercent = CommonFunctions.GetDecimalValue(row, 3),
                UOSActual = CommonFunctions.GetDecimalValue(row, 4),
                TargetProdHoursUOS = CommonFunctions.GetDecimalValue(row, 5),
                ActualProdHoursUOS = CommonFunctions.GetDecimalValue(row, 6),
                ActualNonProdPercent = CommonFunctions.GetDecimalValue(row, 7),
                ProductiveFtesTarget = CommonFunctions.GetDecimalValue(row, 8),
                ProductiveFtesActual = CommonFunctions.GetDecimalValue(row, 9),
                ProductiveFtesVariance = CommonFunctions.GetDecimalValue(row, 10),
                PaidFtesTarget = CommonFunctions.GetDecimalValue(row, 11),
                PaidFtesActual = CommonFunctions.GetDecimalValue(row, 12),
                PaidFtesVariance = CommonFunctions.GetDecimalValue(row, 13),
                OvertimeFtes = CommonFunctions.GetDecimalValue(row, 14),
                OvertimePercent = CommonFunctions.GetDecimalValue(row, 15),
                OvertimeTargetPercent = CommonFunctions.GetDecimalValue(row, 16),
                ContractFtes = CommonFunctions.GetDecimalValue(row, 17),
                ContractPercent = CommonFunctions.GetDecimalValue(row, 18),
                ContractTargetPercent = CommonFunctions.GetDecimalValue(row, 19),
                PRNFtes = CommonFunctions.GetDecimalValue(row, 20),
                PRNPercent = CommonFunctions.GetDecimalValue(row, 21),
                AvailableFields = GetAllValidationFields()
            };
        }

        private static DailyStaffingSummaryData GetDivisionReportRow(object[] row, string deptGroupNum)
        {
            return new DailyStaffingSummaryData
            {
                Coid = CommonFunctions.GetStringValue(row, 0),
                FacilityName = CommonFunctions.GetStringValue(row, 1),
                DeptGroupNum = deptGroupNum,
                DepartmentGroupName = CommonFunctions.GetStringValue(row, 3),
                StatisticDescription = CommonFunctions.GetStringValue(row, 4),
                PaidIdxTargetActualFtesPercent = CommonFunctions.GetDecimalValue(row, 6),
                UOSActual = CommonFunctions.GetDecimalValue(row, 10),
                TargetProdHoursUOS = CommonFunctions.GetDecimalValue(row, 11),
                ActualProdHoursUOS = CommonFunctions.GetDecimalValue(row, 12),
                ProductiveFtesVariance = CommonFunctions.GetDecimalValue(row, 13),
                PaidFtesTarget = CommonFunctions.GetDecimalValue(row, 15),
                PaidFtesActual = CommonFunctions.GetDecimalValue(row, 16),
                PaidFtesVariance = CommonFunctions.GetDecimalValue(row, 17),
                OvertimeFtes = CommonFunctions.GetDecimalValue(row, 18),
                OvertimePercent = CommonFunctions.GetDecimalValue(row, 19),
                ContractFtes = CommonFunctions.GetDecimalValue(row, 20),
                ContractPercent = CommonFunctions.GetDecimalValue(row, 21),
                PRNFtes = CommonFunctions.GetDecimalValue(row, 22),
                PRNPercent = CommonFunctions.GetDecimalValue(row, 23),
                AvailableFields = GetDivisionValidationFields()
            };
        }

        private static HashSet<string> GetAllValidationFields()
        {
            return new HashSet<string>
            {
                nameof(DailyStaffingSummaryData.PaidIdxTargetActualFtesPercent),
                nameof(DailyStaffingSummaryData.UOSActual),
                nameof(DailyStaffingSummaryData.TargetProdHoursUOS),
                nameof(DailyStaffingSummaryData.ActualProdHoursUOS),
                nameof(DailyStaffingSummaryData.ActualNonProdPercent),
                nameof(DailyStaffingSummaryData.ProductiveFtesTarget),
                nameof(DailyStaffingSummaryData.ProductiveFtesActual),
                nameof(DailyStaffingSummaryData.ProductiveFtesVariance),
                nameof(DailyStaffingSummaryData.PaidFtesTarget),
                nameof(DailyStaffingSummaryData.PaidFtesActual),
                nameof(DailyStaffingSummaryData.PaidFtesVariance),
                nameof(DailyStaffingSummaryData.OvertimeFtes),
                nameof(DailyStaffingSummaryData.OvertimePercent),
                nameof(DailyStaffingSummaryData.OvertimeTargetPercent),
                nameof(DailyStaffingSummaryData.ContractFtes),
                nameof(DailyStaffingSummaryData.ContractPercent),
                nameof(DailyStaffingSummaryData.ContractTargetPercent),
                nameof(DailyStaffingSummaryData.PRNFtes),
                nameof(DailyStaffingSummaryData.PRNPercent)
            };
        }

        private static HashSet<string> GetDivisionValidationFields()
        {
            return new HashSet<string>
            {
                nameof(DailyStaffingSummaryData.PaidIdxTargetActualFtesPercent),
                nameof(DailyStaffingSummaryData.UOSActual),
                nameof(DailyStaffingSummaryData.TargetProdHoursUOS),
                nameof(DailyStaffingSummaryData.ActualProdHoursUOS),
                nameof(DailyStaffingSummaryData.ProductiveFtesVariance),
                nameof(DailyStaffingSummaryData.PaidFtesTarget),
                nameof(DailyStaffingSummaryData.PaidFtesActual),
                nameof(DailyStaffingSummaryData.PaidFtesVariance),
                nameof(DailyStaffingSummaryData.OvertimeFtes),
                nameof(DailyStaffingSummaryData.OvertimePercent),
                nameof(DailyStaffingSummaryData.ContractFtes),
                nameof(DailyStaffingSummaryData.ContractPercent),
                nameof(DailyStaffingSummaryData.PRNFtes),
                nameof(DailyStaffingSummaryData.PRNPercent)
            };
        }

        private static int FindDailyStaffingSummaryHeaderRow(List<object[]> rows)
        {
            int standardHeaderRow = CommonFunctions.FindDeptRow("Num", rows);
            if (standardHeaderRow != -1)
                return standardHeaderRow;

            for (int i = 0; i < rows.Count; i++)
            {
                string rowText = GetRowText(rows[i]);
                if (rowText.Contains("Dept", StringComparison.OrdinalIgnoreCase)
                    && rowText.Contains("Group", StringComparison.OrdinalIgnoreCase)
                    && rowText.Contains("Statistic", StringComparison.OrdinalIgnoreCase))
                    return i;
            }

            return -1;
        }

        private static bool IsDivisionHeaderRow(object[] row)
        {
            string rowText = GetRowText(row);
            return rowText.Contains("COID", StringComparison.OrdinalIgnoreCase)
                && rowText.Contains("Facility", StringComparison.OrdinalIgnoreCase)
                && rowText.Contains("Dept", StringComparison.OrdinalIgnoreCase)
                && rowText.Contains("Group", StringComparison.OrdinalIgnoreCase);
        }

        private static string GetRowText(object[] row)
        {
            return string.Join(" ", row.Where(c => c != null).Select(c => c.ToString()));
        }

        private static List<object[]> ReadRows(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var allRows = new List<object[]>();

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                do
                {
                    while (reader.Read())
                    {
                        var row = new object[reader.FieldCount];
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row[i] = reader.GetValue(i);
                        }

                        allRows.Add(row);
                    }
                } while (reader.NextResult());
            }

            return allRows;
        }

        private static string FindReportType(List<object[]> rows)
        {
            string text = GetHeaderText(rows);

            if (text.Contains("PAY PERIOD", StringComparison.OrdinalIgnoreCase))
                return "Pay Period";

            if (text.Contains("MONTH", StringComparison.OrdinalIgnoreCase))
                return "Month";

            if (text.Contains("WEEK", StringComparison.OrdinalIgnoreCase))
                return "Week";

            if (text.Contains("DAY", StringComparison.OrdinalIgnoreCase))
                return "Day";

            return null;
        }

        private static string FindDivision(List<object[]> rows)
        {
            foreach (var row in rows)
            {
                for (int i = 0; i < row.Length; i++)
                {
                    string cellText = row[i]?.ToString();
                    if (string.IsNullOrWhiteSpace(cellText) || !cellText.Contains("Division", StringComparison.OrdinalIgnoreCase))
                        continue;

                    if (i + 1 < row.Length && !string.IsNullOrWhiteSpace(row[i + 1]?.ToString()))
                        return row[i + 1].ToString().Trim();

                    var match = Regex.Match(cellText, @"Division\s*[:\-]?\s*(.+)", RegexOptions.IgnoreCase);
                    if (match.Success && !string.IsNullOrWhiteSpace(match.Groups[1].Value))
                        return match.Groups[1].Value.Trim();
                }
            }

            return null;
        }

        private static string FindReportPeriod(List<object[]> rows)
        {
            string text = GetHeaderText(rows);

            if (text.Contains("PREVIOUS", StringComparison.OrdinalIgnoreCase))
                return "Previous";

            if (text.Contains("CURRENT", StringComparison.OrdinalIgnoreCase))
                return "Current";

            return null;
        }

        private static List<DateTime> FindDates(List<object[]> rows)
        {
            var dates = new List<DateTime>();

            foreach (var row in rows)
            {
                foreach (var cell in row)
                {
                    dates.AddRange(GetDatesFromCell(cell));
                }
            }

            return dates;
        }

        private static IEnumerable<DateTime> GetDatesFromCell(object cell)
        {
            if (cell == null)
                yield break;

            if (cell is DateTime date)
            {
                yield return date.Date;
                yield break;
            }

            if (cell is double serialDate && serialDate > 30000 && serialDate < 80000)
            {
                yield return DateTime.FromOADate(serialDate).Date;
                yield break;
            }

            if (cell is int serialDateNumber && serialDateNumber > 30000 && serialDateNumber < 80000)
            {
                yield return DateTime.FromOADate(serialDateNumber).Date;
                yield break;
            }

            string text = cell.ToString();
            if (string.IsNullOrWhiteSpace(text))
                yield break;

            foreach (Match match in Regex.Matches(text, @"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}-\d{1,2}-\d{1,2}\b"))
            {
                if (DateTime.TryParse(match.Value, out DateTime parsedDate))
                    yield return parsedDate.Date;
            }
        }

        private static DateTime GetStartDate(string reportType, DateTime endDate)
        {
            if (reportType.Equals("Month", StringComparison.OrdinalIgnoreCase))
                return new DateTime(endDate.Year, endDate.Month, 1);

            if (reportType.Equals("Pay Period", StringComparison.OrdinalIgnoreCase)
                || reportType.Equals("PayPeriod", StringComparison.OrdinalIgnoreCase)
                || reportType.Equals("Pay_Period", StringComparison.OrdinalIgnoreCase))
                return endDate.AddDays(-13);

            if (reportType.Equals("Week", StringComparison.OrdinalIgnoreCase))
                return endDate.AddDays(-6);

            return endDate;
        }

        private static string GetHeaderText(List<object[]> rows)
        {
            return string.Join(" ", rows.SelectMany(r => r).Where(c => c != null).Select(c => c.ToString()));
        }
    }
}
