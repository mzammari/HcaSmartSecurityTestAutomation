﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ISAS_Regression_Automation
{
    internal class DailyUosErVisitsHoldsReport
    {

        public static void GoTo()
        {
            FpcReportMenu.DailyTrendReport.SelectDailyUosErVisitsHolds();
            CommonFunctions.AddTestStep("Select Daily UOS ER Visits Holds Report", "The Daily UOS ER Visits Holds Report is displayed");
        }
        public static bool IsAt
        {
            get
            {
                By byReportType = By.XPath("//select[@id='ddlReportType'] ");
                CommonFunctions.AddTestStep("Verify the Daily UOS ER Visits Holds Report page is active", "The plan page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byReportType, 20);
            }
        }

        public static DailyUosErVisitsHoldsReportCommand dailyUosErVisitsHoldsReport()
        {
            return new DailyUosErVisitsHoldsReportCommand();
        }

        #region: DailyUosErVisitsHoldsReportCommand            
        public class DailyUosErVisitsHoldsReportCommand
        {
            private string reportType;
            private string reportPeriod;


            public DailyUosErVisitsHoldsReportCommand withReportType(string ReportType)
            {
                this.reportType = ReportType;
                return this;

            }

            public DailyUosErVisitsHoldsReportCommand withReportPeriod(string ReportPeriod)
            {
                this.reportPeriod = ReportPeriod;
                return this;
            }


            private void setReportType()
            {
                By byReportType = By.XPath("//select[@id='ddlReportType']");
                IWebElement mnuReportType = CommonFunctions.getElement(byReportType);
                CommonFunctions.SelectItemFromDropdownMenu(mnuReportType, reportType);
                CommonFunctions.AddTestStep($"Verify a user can select {reportType} from Report Type dropdown", $"The {reportType} is selected correctly");
            }

            private void setReportPeriod()
            {
                By byReportPeriod = By.XPath("//select[@id='payPeriodID']");
                IWebElement mnuReportPeriod = CommonFunctions.getElement(byReportPeriod);
                CommonFunctions.SelectItemFromDropdownMenu(mnuReportPeriod, reportPeriod);
                CommonFunctions.AddTestStep($"Verify a user can select {reportPeriod} from Report Period dropdown", $"The {reportPeriod} is selected correctly");
            }



            private void clickExcel()
            {
                By byExcel = By.XPath("//img[@title='Excel Format']");
                IWebElement cmdExcel = CommonFunctions.getElement(byExcel);
                //CommonFunctions.ClickByJE(cmdExcel);
                cmdExcel.Click();
                //Thread.Sleep(240000);
                CommonFunctions.AddTestStep($"Verify a user can click the Excel button", $"The Excel button is enabled and clickable");
            }

            private void clickPDF()
            {
                By byPDF = By.XPath("//img[@title='PDF Format']");
                IWebElement cmdPDF = CommonFunctions.getElement(byPDF);
                CommonFunctions.ClickByJE(cmdPDF);
                CommonFunctions.AddTestStep($"Verify a user can click the PDF button", $"The PDF button is enabled and clickable");
            }

            public void PDF()
            {
                setReportType();
                setReportPeriod();
                clickPDF();
                CommonFunctions.WaitUntilPageIsAcive();
            }

            public void Excel()
            {
                setReportType();
                setReportPeriod();
                clickExcel();
                CommonFunctions.WaitUntilPageIsAcive();
            }
        }
        #endregion
    }
}

