using NUnit.Framework;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ISAS_Regression_Automation
{
    public static class SkillMixOpportunityReportDivisionValidator
    {
        public static void Validate(List<SkillMixOpportunityReportDivisionData> excelData, List<SkillMixOpportunityReportDivisionData> dbData)
        {
            Console.WriteLine("=== Skill Mix Opportunity Division Validation ===\n");
            Console.WriteLine($"Excel rows: {excelData.Count} | DB rows: {dbData.Count}\n");

            if (!excelData.Any())
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                return;
            }

            var missingFields = excelData
                .SelectMany(row => SkillMixOpportunityReportDivisionExcelReport.RequiredValidationFields
                    .Except(row.AvailableFields))
                .Distinct()
                .ToList();
            if (missingFields.Any())
                Console.WriteLine($"Skipping fields without an Excel column mapping: {string.Join(", ", missingFields)}");

            var mismatches = new List<string>();
            var unmatchedRows = new List<string>();
            int totalComparisons = 0;
            int matchCount = 0;
            int skippedRows = 0;
            int skippedFields = 0;

            foreach (var excelRow in excelData)
            {
                string divisionName = SkillMixOpportunityReportDivisionExcelReport.NormalizeDivisionName(excelRow.DivisionName);
                var divisionRows = dbData.Where(d => !string.IsNullOrWhiteSpace(divisionName)
                    && SkillMixOpportunityReportDivisionExcelReport.NormalizeDivisionName(d.DivisionName) == divisionName).ToList();
                var departmentRows = divisionRows.Where(d => IsSameDepartment(excelRow, d)).ToList();
                var exactRows = departmentRows.Where(d => IsSameRow(excelRow, d)).ToList();
                var dbRow = exactRows.Count == 1 ? exactRows[0]
                    : departmentRows.Count == 1 ? departmentRows[0]
                    : SelectBestRow(excelRow, exactRows.Any() ? exactRows : departmentRows);
                if (dbRow == null)
                {
                    skippedRows++;
                    string reason = divisionRows.Count == 0 ? $"No matching DB2 division for Excel Div '{excelRow.DivisionName}'"
                        : departmentRows.Count == 0 ? "No matching DB2 department within the Excel division"
                        : $"Ambiguous DB2 department match ({departmentRows.Count} candidate rows, {exactRows.Count} exact identifier matches)";
                    unmatchedRows.Add($"{reason} for Excel {DescribeRow(excelRow)}.");
                    continue;
                }

                CompareText(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.DivisionName), "DIVISION_NAME", "Div", excelRow.DivisionName, dbRow.DivisionName);
                CompareText(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.Coid), "CO_ID", "COID/dept", GetExcelCoidForComparison(excelRow), dbRow.Coid);
                CompareText(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.UnitNumber), "UNIT_NUM", "unit number", excelRow.UnitNumber, dbRow.UnitNumber);
                CompareText(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.DeptNumber), "DEPT_NUM", "dep", excelRow.DeptNumber, dbRow.DeptNumber);
                CompareText(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.DeptDescription), "DEPT_DESC", "GL Dept Desc", excelRow.DeptDescription, dbRow.DeptDescription);
                CompareText(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.SubFunctionNumber), "SUBFUNCTION_NUM", "Sun fun", excelRow.SubFunctionNumber, dbRow.SubFunctionNumber);
                CompareText(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.Mapping), "MAPPING", "Mapping", excelRow.Mapping, dbRow.Mapping);
                CompareText(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.GridStatus), "GRID_DESC", "Grid Status", excelRow.GridStatus, dbRow.GridStatus);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.PaidActual), "PAID_ACTUAL", "PLUS 14 Day FTE Paid Actual", excelRow.PaidActual, dbRow.PaidActual);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.PaidVariance), "PAID_VAR", "PLUS 14 Day FTE Paid Var", excelRow.PaidVariance, dbRow.PaidVariance);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdActual), "PROD_ACTUAL", "PLUS 14 Day FTE Prod Actual", excelRow.ProdActual, dbRow.ProdActual);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdVariance), "PROD_VAR", "PLUS 14 Day FTE Prod var", excelRow.ProdVariance, dbRow.ProdVariance);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ClFtes), "CL_FTES", "PLUS 14 Day FTE CL FTEs", excelRow.ClFtes, dbRow.ClFtes);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.AhsgRn), "AHSGRN", "Approved/Approved Historical Staffing Grid RN", excelRow.AhsgRn, dbRow.AhsgRn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.AhsgPct), "AHSGPCT", "Approved/Approved Historical Staffing Grid PCT", excelRow.AhsgPct, dbRow.AhsgPct);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.AhsgLpn), "AHSGLPN", "Approved/Approved Historical Staffing Grid LPN", excelRow.AhsgLpn, dbRow.AhsgLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.AhsgClerical), "AHSGCLERICAL", "Approved/Approved Historical Staffing Grid Clerical", excelRow.AhsgClerical, dbRow.AhsgClerical);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.AhsgSpecialist), "AHSGSPECIALIST", "Approved/Approved Historical Staffing Grid Specialist", excelRow.AhsgSpecialist, dbRow.AhsgSpecialist);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.KronosRn), "KRONOSRN", "Kronos/PLUS Keyed in CL 14 Day Skill Mix RN", excelRow.KronosRn, dbRow.KronosRn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.KronosPct), "KRONOSPCT", "Kronos/PLUS Keyed in CL 14 Day Skill Mix PCT", excelRow.KronosPct, dbRow.KronosPct);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.KronosLpn), "KRONOSLPN", "Kronos/PLUS Keyed in CL 14 Day Skill Mix LPN", excelRow.KronosLpn, dbRow.KronosLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.KronosClerical), "KRONOSCLERICAL", "Kronos/PLUS Keyed in CL 14 Day Skill Mix Clerical", excelRow.KronosClerical, dbRow.KronosClerical);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.KronosSpecialist), "KRONOSSPECIALIST", "Kronos/PLUS Keyed in CL 14 Day Skill Mix Specialist", excelRow.KronosSpecialist, dbRow.KronosSpecialist);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.TargetRn), "TARGETRN", "RN Target", excelRow.TargetRn, dbRow.TargetRn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.TargetPct), "TARGETPCT", "PCT Target", excelRow.TargetPct, dbRow.TargetPct);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.TargetLpn), "TARGETLPN", "LPN Target", excelRow.TargetLpn, dbRow.TargetLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.TargetClerical), "TARGETCLERICAL", "Clerical Target", excelRow.TargetClerical, dbRow.TargetClerical);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.TargetSpecialist), "TARGETSPECIALIST", "Specialist Target", excelRow.TargetSpecialist, dbRow.TargetSpecialist);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ActualRn), "ACTUALRN", "RN Actual", excelRow.ActualRn, dbRow.ActualRn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ActualPct), "ACTUALPCT", "PCT Actual", excelRow.ActualPct, dbRow.ActualPct);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ActualLpn), "ACTUALLPN", "LPN Actual", excelRow.ActualLpn, dbRow.ActualLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ActualClerical), "ACTUALCLERICAL", "Clerical Actual", excelRow.ActualClerical, dbRow.ActualClerical);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ActualSpecialist), "ACTUALSPECIALIST", "Specialist Actual", excelRow.ActualSpecialist, dbRow.ActualSpecialist);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdRn), "PRODRN", "Prod FTE Variance by Skill Mix RN Var", excelRow.ProdRn, dbRow.ProdRn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdPct), "PRODPCT", "Prod FTE Variance by Skill Mix PCT Var", excelRow.ProdPct, dbRow.ProdPct);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdLpn), "PRODLPN", "Prod FTE Variance by Skill Mix LPN Var", excelRow.ProdLpn, dbRow.ProdLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdClerical), "PRODCLERICAL", "Prod FTE Variance by Skill Mix Clerical Var", excelRow.ProdClerical, dbRow.ProdClerical);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdSpecialist), "PRODSPECIALIST", "Specialist Var", excelRow.ProdSpecialist, dbRow.ProdSpecialist);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdIdxRn), "PRODIDX_RN", "Prod Index% RN", excelRow.ProdIdxRn, dbRow.ProdIdxRn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdIdxPct), "PRODIDX_PCT", "Prod Index% PCT", excelRow.ProdIdxPct, dbRow.ProdIdxPct);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdIdxLpn), "PRODIDX_LPN", "Prod Index% LPN", excelRow.ProdIdxLpn, dbRow.ProdIdxLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.ProdIdxClerical), "PRODIDX_CLERICAL", "Prod Index% Clerical", excelRow.ProdIdxClerical, dbRow.ProdIdxClerical);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.RnLpn), "RNLPN", "RN+LPN", excelRow.RnLpn, dbRow.RnLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.PctCle), "PCTCLE", "PCT + Clerical", excelRow.PctCle, dbRow.PctCle);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.TotalSkm), "TOTALSKM", "Total(RN+LPN+PCT+Clerical)", excelRow.TotalSkm, dbRow.TotalSkm);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.MtfRn), "MTF_RN", "Missed Target RN Missed FTEs", excelRow.MtfRn, dbRow.MtfRn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.MtfLpn), "MTF_LPN", "Missed Target LPN Missed FTEs", excelRow.MtfLpn, dbRow.MtfLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.MtfPct), "MTF_PCT", "Missed Target PCT Missed FTEs", excelRow.MtfPct, dbRow.MtfPct);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.MtfClerical), "MTF_CLERICAL", "Missed Target ClericalMissed FTEs", excelRow.MtfClerical, dbRow.MtfClerical);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.MissedTargetRnLpn), "MISSED_TGT_FTE_RN_LPN", "Missed Target RN+LPN Missed FTEs", excelRow.MissedTargetRnLpn, dbRow.MissedTargetRnLpn);
                Compare(mismatches, ref totalComparisons, ref matchCount, ref skippedFields, excelRow, nameof(SkillMixOpportunityReportDivisionData.MissingTargetPercent), "MISSING_TARGET_PER", "Missed Target RN+LPN Missed %", excelRow.MissingTargetPercent, dbRow.MissingTargetPercent);
            }

            double matchPercentage = totalComparisons > 0 ? (matchCount * 100.0) / totalComparisons : 0;
            Console.WriteLine("Validation Summary:");
            Console.WriteLine($"  Total Comparisons: {totalComparisons}");
            Console.WriteLine($"  Matches: {matchCount} ({matchPercentage:N1}%)");
            Console.WriteLine($"  Mismatches: {mismatches.Count}");
            Console.WriteLine($"  Unmatched Excel rows: {skippedRows}");
            Console.WriteLine($"  Skipped fields not present in Excel: {skippedFields}");

            if (unmatchedRows.Count > 0)
            {
                Console.WriteLine("Unmatched/ambiguous rows were ignored as requested:");
                foreach (var unmatched in unmatchedRows)
                    Console.WriteLine(unmatched);
            }

            if (mismatches.Count > 0)
            {
                foreach (var mismatch in mismatches)
                    Console.WriteLine(mismatch);
                Assert.Fail($"Skill Mix Opportunity Division validation failed: {mismatches.Count} mapped value mismatches out of {totalComparisons} comparisons.");
            }

            if (totalComparisons == 0)
                Console.WriteLine("No mapped fields were compared; validation did not fail because only mapped column mismatches should fail.");
        }

        private static void Compare(List<string> mismatches, ref int totalComparisons, ref int matchCount, ref int skippedFields, SkillMixOpportunityReportDivisionData excelRow, string fieldName, string dbColumnName, string excelColumnName, decimal excelValue, decimal dbValue)
        {
            if (!excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            decimal scale = fieldName == nameof(SkillMixOpportunityReportDivisionData.MissingTargetPercent) ? 100m : 1m;
            decimal roundedExcel = Math.Round(excelValue * scale, 1, MidpointRounding.AwayFromZero);
            decimal roundedDb = Math.Round(dbValue * scale, 1, MidpointRounding.AwayFromZero);
            if (roundedExcel == roundedDb)
            {
                matchCount++;
                return;
            }

            string format = "N1";
            mismatches.Add($"COID {excelRow.Coid} Dept {excelRow.DeptNumber} {dbColumnName}->{excelColumnName}: Excel={roundedExcel.ToString(format, CultureInfo.InvariantCulture)}, DB={roundedDb.ToString(format, CultureInfo.InvariantCulture)}");
        }

        private static void CompareText(List<string> mismatches, ref int totalComparisons, ref int matchCount, ref int skippedFields, SkillMixOpportunityReportDivisionData excelRow, string fieldName, string dbColumnName, string excelColumnName, string excelValue, string dbValue)
        {
            if (!excelRow.AvailableFields.Contains(fieldName))
            {
                skippedFields++;
                return;
            }

            totalComparisons++;
            bool isIdentifier = fieldName == nameof(SkillMixOpportunityReportDivisionData.Coid)
                || fieldName == nameof(SkillMixOpportunityReportDivisionData.UnitNumber)
                || fieldName == nameof(SkillMixOpportunityReportDivisionData.DeptNumber)
                || fieldName == nameof(SkillMixOpportunityReportDivisionData.SubFunctionNumber);
            string normalizedExcel = fieldName == nameof(SkillMixOpportunityReportDivisionData.DivisionName)
                ? SkillMixOpportunityReportDivisionExcelReport.NormalizeDivisionName(excelValue)
                : isIdentifier ? NormalizeDigits(excelValue) : Normalize(excelValue);
            string normalizedDb = fieldName == nameof(SkillMixOpportunityReportDivisionData.DivisionName)
                ? SkillMixOpportunityReportDivisionExcelReport.NormalizeDivisionName(dbValue)
                : isIdentifier ? NormalizeDigits(dbValue) : Normalize(dbValue);
            if (normalizedExcel == normalizedDb)
            {
                matchCount++;
                return;
            }

            mismatches.Add($"COID {excelRow.Coid} Dept {excelRow.DeptNumber} {dbColumnName}->{excelColumnName}: Excel={excelValue}, DB={dbValue}");
        }

        private static bool IsSameRow(SkillMixOpportunityReportDivisionData excelRow, SkillMixOpportunityReportDivisionData dbRow)
        {
            return IsSameDepartment(excelRow, dbRow)
                && (!excelRow.AvailableFields.Contains(nameof(SkillMixOpportunityReportDivisionData.UnitNumber))
                    || NormalizeDigits(excelRow.UnitNumber) == NormalizeDigits(dbRow.UnitNumber))
                && (!excelRow.AvailableFields.Contains(nameof(SkillMixOpportunityReportDivisionData.SubFunctionNumber))
                    || NormalizeDigits(excelRow.SubFunctionNumber) == NormalizeDigits(dbRow.SubFunctionNumber));
        }

        private static bool IsSameDepartment(SkillMixOpportunityReportDivisionData excelRow, SkillMixOpportunityReportDivisionData dbRow)
        {
            if (NormalizeDigits(excelRow.DeptNumber) != NormalizeDigits(dbRow.DeptNumber))
                return false;

            string excelCoidNumeric = GetNormalizedExcelCoid(excelRow.Coid, excelRow.DeptNumber);
            string dbCoidNumeric = ExtractDigits(dbRow.Coid?.Split('/')[0]);
            if (excelRow.AvailableFields.Contains(nameof(SkillMixOpportunityReportDivisionData.Coid))
                && !string.IsNullOrWhiteSpace(excelCoidNumeric)
                && !string.IsNullOrWhiteSpace(dbCoidNumeric))
                return excelCoidNumeric == dbCoidNumeric;

            if (!string.IsNullOrWhiteSpace(excelRow.FacilityName))
                return Normalize(excelRow.FacilityName) == Normalize(dbRow.FacilityName);

            if (excelRow.AvailableFields.Contains(nameof(SkillMixOpportunityReportDivisionData.Coid)))
                return Normalize(excelRow.Coid) == Normalize(dbRow.Coid);

            return true;
        }

        private static SkillMixOpportunityReportDivisionData SelectBestRow(SkillMixOpportunityReportDivisionData excelRow,
            List<SkillMixOpportunityReportDivisionData> candidates)
        {
            if (candidates == null || candidates.Count == 0)
                return null;
            if (candidates.Count == 1)
                return candidates[0];

            var ranked = candidates.Select(c => new
            {
                Row = c,
                Score = ScoreMatch(excelRow, c)
            }).ToList();

            int bestScore = ranked.Max(r => r.Score);
            var best = ranked.Where(r => r.Score == bestScore).Select(r => r.Row).ToList();
            return best.Count == 1 ? best[0] : null;
        }

        private static int ScoreMatch(SkillMixOpportunityReportDivisionData excelRow, SkillMixOpportunityReportDivisionData dbRow)
        {
            int score = 0;
            if (excelRow.AvailableFields.Contains(nameof(SkillMixOpportunityReportDivisionData.UnitNumber))
                && !string.IsNullOrWhiteSpace(excelRow.UnitNumber)
                && NormalizeDigits(excelRow.UnitNumber) == NormalizeDigits(dbRow.UnitNumber))
                score += 4;

            if (excelRow.AvailableFields.Contains(nameof(SkillMixOpportunityReportDivisionData.SubFunctionNumber))
                && !string.IsNullOrWhiteSpace(excelRow.SubFunctionNumber)
                && NormalizeDigits(excelRow.SubFunctionNumber) == NormalizeDigits(dbRow.SubFunctionNumber))
                score += 4;

            if (!string.IsNullOrWhiteSpace(excelRow.FacilityName)
                && Normalize(excelRow.FacilityName) == Normalize(dbRow.FacilityName))
                score += 2;

            string excelCoidNumeric = GetNormalizedExcelCoid(excelRow.Coid, excelRow.DeptNumber);
            string dbCoidNumeric = ExtractDigits(dbRow.Coid?.Split('/')[0]);
            if (!string.IsNullOrWhiteSpace(excelCoidNumeric)
                && !string.IsNullOrWhiteSpace(dbCoidNumeric)
                && excelCoidNumeric == dbCoidNumeric)
                score += 2;

            return score;
        }

        private static string DescribeRow(SkillMixOpportunityReportDivisionData row)
        {
            return $"Division '{row.DivisionName}', COID '{row.Coid}', COID Name '{row.FacilityName}', Dept '{row.DeptNumber}', Unit '{row.UnitNumber}', Subfunction '{row.SubFunctionNumber}'"
                + $" [normalized COID '{GetNormalizedExcelCoid(row.Coid, row.DeptNumber)}', Dept '{NormalizeDigits(row.DeptNumber)}']";
        }

        private static string GetExcelCoidForComparison(SkillMixOpportunityReportDivisionData excelRow)
        {
            return GetNormalizedExcelCoid(excelRow.Coid, excelRow.DeptNumber);
        }

        private static string GetNormalizedExcelCoid(string coidValue, string deptValue)
        {
            if (string.IsNullOrWhiteSpace(coidValue)) return string.Empty;

            string raw = coidValue.Trim();
            if (raw.Contains('/'))
                return ExtractDigits(raw.Split('/')[0]);

            string coidDigits = ExtractDigits(raw);
            string deptDigits = ExtractDigits(deptValue);
            if (!string.IsNullOrWhiteSpace(coidDigits)
                && !string.IsNullOrWhiteSpace(deptDigits)
                && coidDigits.Length > deptDigits.Length
                && coidDigits.EndsWith(deptDigits, StringComparison.Ordinal))
            {
                string trimmed = coidDigits.Substring(0, coidDigits.Length - deptDigits.Length);
                if (!string.IsNullOrWhiteSpace(trimmed))
                    return trimmed;
            }

            return coidDigits;
        }

        private static string NormalizeDigits(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            if (decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal number)
                && number == decimal.Truncate(number))
                return number.ToString("0", CultureInfo.InvariantCulture);
            string digits = new string(value.Where(char.IsDigit).ToArray());
            return string.IsNullOrWhiteSpace(digits) ? value.Trim().ToUpperInvariant() : digits.TrimStart('0');
        }

        private static string ExtractDigits(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            string digits = new string(value.Where(char.IsDigit).ToArray()).TrimStart('0');
            return string.IsNullOrWhiteSpace(digits) ? string.Empty : digits;
        }

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : string.Join(" ", value.Trim().Split(' ').Where(s => !string.IsNullOrWhiteSpace(s))).ToUpperInvariant();
        }
    }
}
