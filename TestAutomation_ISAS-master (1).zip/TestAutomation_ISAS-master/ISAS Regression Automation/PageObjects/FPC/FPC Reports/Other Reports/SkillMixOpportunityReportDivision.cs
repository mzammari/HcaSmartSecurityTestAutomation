using OpenQA.Selenium;
using System;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace ISAS_Regression_Automation
{
    internal class SkillMixOpportunityReportDivision
    {
        internal static readonly By DivisionSelector = By.XPath("//select[contains(translate(@id,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'division') or contains(translate(@name,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'division')]");
        private static readonly By BusyOverlay = By.CssSelector(".blockUI.blockOverlay");

        public static void GoTo()
        {
            FpcReportMenu.OtherReports.SelectSkillMixOpportunityDivisionReport();
            CommonFunctions.AddTestStep("Select Skill Mix Opportunity Division Report", "The Skill Mix Opportunity Division Report is displayed");
        }

        public static bool IsAt
        {
            get
            {
                try
                {
                    WaitForControl(DivisionSelector, "Division filter");
                }
                catch (WebDriverTimeoutException)
                {
                    return false;
                }
                CommonFunctions.AddTestStep("Verify the Skill Mix Opportunity Division Report page is active", "The Skill Mix Opportunity Division Report page loaded correctly.");
                return true;
            }
        }

        internal static IWebElement WaitForControl(By selector, string description)
        {
            var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(180));
            wait.Message = $"The {description} was not ready for the Skill Mix Opportunity Division Report.";
            wait.IgnoreExceptionTypes(typeof(StaleElementReferenceException));
            return wait.Until(driver =>
            {
                var control = driver.FindElements(selector).FirstOrDefault(e => e.Displayed && e.Enabled);
                return control != null && !driver.FindElements(BusyOverlay).Any(e => e.Displayed)
                    ? control : null;
            });
        }

        public static SkillMixOpportunityReportDivisionCommand SkillMixOpportunityDivisionReport()
        {
            return new SkillMixOpportunityReportDivisionCommand();
        }
    }

    public class SkillMixOpportunityReportDivisionCommand
    {
        private string division;

        public SkillMixOpportunityReportDivisionCommand withDivision(string division)
        {
            this.division = division;
            return this;
        }

        private void setDivision()
        {
            IWebElement mnuDivision = SkillMixOpportunityReportDivision.WaitForControl(
                SkillMixOpportunityReportDivision.DivisionSelector, "Division filter");
            CommonFunctions.SelectItemFromDropdownMenu(mnuDivision, division);
            CommonFunctions.AddTestStep($"Verify a user can select {division} from Division dropdown", $"The {division} is selected correctly");
        }

        private void clickExcel()
        {
            By byExcel = By.XPath("//*[self::img or self::input or self::button or self::a][contains(@title,'Excel') or contains(@alt,'Excel') or contains(@value,'Excel') or contains(normalize-space(.),'Excel')]");
            IWebElement cmdExcel = SkillMixOpportunityReportDivision.WaitForControl(byExcel, "Excel export control");
            CommonFunctions.ClickByJE(cmdExcel);
            CommonFunctions.AddTestStep("Verify a user can click the Excel button", "The Excel button is enabled and clickable");
        }

        public void Excel()
        {
            setDivision();
            clickExcel();
        }
    }
}
