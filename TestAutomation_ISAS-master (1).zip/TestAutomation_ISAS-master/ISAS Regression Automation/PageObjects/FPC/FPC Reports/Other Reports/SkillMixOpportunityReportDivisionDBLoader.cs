using IBM.Data.Db2;
using IBM.Data.Db2;
using System;
using System.Collections.Generic;
using System.Data;

namespace ISAS_Regression_Automation
{
    public static class SkillMixOpportunityReportDivisionDBLoader
    {
        public static List<SkillMixOpportunityReportDivisionData> LoadFromDatabase(int divisionNumber, DateTime? startDate = null, DateTime? endDate = null)
        {
            var result = new List<SkillMixOpportunityReportDivisionData>();
            string connectionString = $"Server={RunData.FpcServerName};" +
                                      $"Database={RunData.FpcDatabaseName};" +
                                      $"UserID={RunData.UserName};" +
                                      $"Password={RunData.FpcPassword};" +
                                      "Authentication=Server;";
            string sqlQuery = SkillMixOpportunityReportDivisionSP.GetSkillMixOpportunityReportDivisionQuery(divisionNumber, startDate, endDate);
            using (var connection = new DB2Connection(connectionString))
            {
                connection.Open();
                using (var command = new DB2Command(sqlQuery, connection))
                {
                    command.CommandTimeout = 0; // Wait for this long-running report query without a command timeout.
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new SkillMixOpportunityReportDivisionData
                            {
                                DivisionName = GetString(reader, "DIVISION_NAME"),
                                GroupName = GetString(reader, "GROUP_NAME"),
                                Coid = GetString(reader, "CO_ID"),
                                FacilityName = GetString(reader, "FACILITY_NAME"),
                                UnitNumber = GetString(reader, "UNIT_NUM"),
                                DeptNumber = GetString(reader, "DEPT_NUM"),
                                DeptDescription = GetString(reader, "DEPT_DESC"),
                                SubFunctionNumber = GetString(reader, "SUBFUNCTION_NUM"),
                                Mapping = GetString(reader, "MAPPING"),
                                PaidActual = GetDecimal(reader, "PAID_ACTUAL"),
                                PaidVariance = GetDecimal(reader, "PAID_VAR"),
                                ProdActual = GetDecimal(reader, "PROD_ACTUAL"),
                                ProdVariance = GetDecimal(reader, "PROD_VAR"),
                                ClFtes = GetDecimal(reader, "CL_FTES"),
                                GridStatus = GetString(reader, "GRID_DESC"),
                                AhsgRn = GetDecimal(reader, "AHSGRN"),
                                AhsgPct = GetDecimal(reader, "AHSGPCT"),
                                AhsgLpn = GetDecimal(reader, "AHSGLPN"),
                                AhsgClerical = GetDecimal(reader, "AHSGCLERICAL"),
                                AhsgSpecialist = GetDecimal(reader, "AHSGSPECIALIST"),
                                KronosRn = GetDecimal(reader, "KRONOSRN"),
                                KronosPct = GetDecimal(reader, "KRONOSPCT"),
                                KronosLpn = GetDecimal(reader, "KRONOSLPN"),
                                KronosClerical = GetDecimal(reader, "KRONOSCLERICAL"),
                                KronosSpecialist = GetDecimal(reader, "KRONOSSPECIALIST"),
                                TargetRn = GetDecimal(reader, "TARGETRN"),
                                TargetPct = GetDecimal(reader, "TARGETPCT"),
                                TargetLpn = GetDecimal(reader, "TARGETLPN"),
                                TargetClerical = GetDecimal(reader, "TARGETCLERICAL"),
                                TargetSpecialist = GetDecimal(reader, "TARGETSPECIALIST"),
                                ActualRn = GetDecimal(reader, "ACTUALRN"),
                                ActualPct = GetDecimal(reader, "ACTUALPCT"),
                                ActualLpn = GetDecimal(reader, "ACTUALLPN"),
                                ActualClerical = GetDecimal(reader, "ACTUALCLERICAL"),
                                ActualSpecialist = GetDecimal(reader, "ACTUALSPECIALIST"),
                                ProdRn = GetDecimal(reader, "PRODRN"),
                                ProdPct = GetDecimal(reader, "PRODPCT"),
                                ProdLpn = GetDecimal(reader, "PRODLPN"),
                                ProdClerical = GetDecimal(reader, "PRODCLERICAL"),
                                ProdSpecialist = GetDecimal(reader, "PRODSPECIALIST"),
                                ProdIdxRn = GetDecimal(reader, "PRODIDX_RN"),
                                ProdIdxPct = GetDecimal(reader, "PRODIDX_PCT"),
                                ProdIdxLpn = GetDecimal(reader, "PRODIDX_LPN"),
                                ProdIdxClerical = GetDecimal(reader, "PRODIDX_CLERICAL"),
                                RnLpn = GetDecimal(reader, "RNLPN"),
                                PctCle = GetDecimal(reader, "PCTCLE"),
                                TotalSkm = GetDecimal(reader, "TOTALSKM"),
                                MtfRn = GetDecimal(reader, "MTF_RN"),
                                MtfLpn = GetDecimal(reader, "MTF_LPN"),
                                MtfPct = GetDecimal(reader, "MTF_PCT"),
                                MtfClerical = GetDecimal(reader, "MTF_CLERICAL"),
                                MissedTargetRnLpn = GetDecimal(reader, "MISSED_TGT_FTE_RN_LPN"),
                                MissingTargetPercent = GetDecimal(reader, "MISSING_TARGET_PER")
                            });
                        }
                    }
                }
            }
            return result;
        }

        private static string GetString(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    return reader.IsDBNull(ordinal) ? string.Empty : reader.GetValue(ordinal).ToString().Trim();
                }
                catch (IndexOutOfRangeException) { }
            }
            return string.Empty;
        }

        private static decimal GetDecimal(IDataReader reader, params string[] columnNames)
        {
            foreach (var columnName in columnNames)
            {
                try
                {
                    int ordinal = reader.GetOrdinal(columnName);
                    if (reader.IsDBNull(ordinal)) return 0m;
                    var value = reader.GetValue(ordinal);
                    if (value is decimal dec) return dec;
                    if (value is double d) return (decimal)d;
                    if (value is float f) return (decimal)f;
                    if (value is int i) return i;
                    if (value is long l) return l;
                    string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
                    return decimal.TryParse(text, out decimal parsed) ? parsed : 0m;
                }
                catch { }
            }
            return 0m;
        }
    }
}
