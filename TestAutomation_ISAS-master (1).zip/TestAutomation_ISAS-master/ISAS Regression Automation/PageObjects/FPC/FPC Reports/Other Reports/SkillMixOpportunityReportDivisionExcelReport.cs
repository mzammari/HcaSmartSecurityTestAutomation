using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ISAS_Regression_Automation
{
    public class SkillMixOpportunityReportDivisionData
    {
        public string DivisionName { get; set; }
        public string GroupName { get; set; }
        public string Coid { get; set; }
        public string FacilityName { get; set; }
        public string UnitNumber { get; set; }
        public string DeptNumber { get; set; }
        public string DeptDescription { get; set; }
        public string SubFunctionNumber { get; set; }
        public string Mapping { get; set; }
        public decimal PaidActual { get; set; }
        public decimal PaidVariance { get; set; }
        public decimal ProdActual { get; set; }
        public decimal ProdVariance { get; set; }
        public decimal ClFtes { get; set; }
        public string GridStatus { get; set; }
        public decimal AhsgRn { get; set; }
        public decimal AhsgPct { get; set; }
        public decimal AhsgLpn { get; set; }
        public decimal AhsgClerical { get; set; }
        public decimal AhsgSpecialist { get; set; }
        public decimal KronosRn { get; set; }
        public decimal KronosPct { get; set; }
        public decimal KronosLpn { get; set; }
        public decimal KronosClerical { get; set; }
        public decimal KronosSpecialist { get; set; }
        public decimal TargetRn { get; set; }
        public decimal TargetPct { get; set; }
        public decimal TargetLpn { get; set; }
        public decimal TargetClerical { get; set; }
        public decimal TargetSpecialist { get; set; }
        public decimal ActualRn { get; set; }
        public decimal ActualPct { get; set; }
        public decimal ActualLpn { get; set; }
        public decimal ActualClerical { get; set; }
        public decimal ActualSpecialist { get; set; }
        public decimal ProdRn { get; set; }
        public decimal ProdPct { get; set; }
        public decimal ProdLpn { get; set; }
        public decimal ProdClerical { get; set; }
        public decimal ProdSpecialist { get; set; }
        public decimal ProdIdxRn { get; set; }
        public decimal ProdIdxPct { get; set; }
        public decimal ProdIdxLpn { get; set; }
        public decimal ProdIdxClerical { get; set; }
        public decimal RnLpn { get; set; }
        public decimal PctCle { get; set; }
        public decimal TotalSkm { get; set; }
        public decimal MtfRn { get; set; }
        public decimal MtfLpn { get; set; }
        public decimal MtfPct { get; set; }
        public decimal MtfClerical { get; set; }
        public decimal MissedTargetRnLpn { get; set; }
        public decimal MissingTargetPercent { get; set; }
        public HashSet<string> AvailableFields { get; set; } = new HashSet<string>();
    }

    public class SkillMixOpportunityReportDivisionCriteria
    {
        public string DivisionName { get; set; }
        public int DivisionNumber { get; set; }
        public string ReportType { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }

    public static class SkillMixOpportunityReportDivisionExcelReport
    {
        private const int HeaderLookbackRows = 6;
        private static readonly Dictionary<string, string[]> FieldAliases = new Dictionary<string, string[]>
        {
            [nameof(SkillMixOpportunityReportDivisionData.DivisionName)] = new[] { "Div", "Division", "DIVISION_NAME" },
            [nameof(SkillMixOpportunityReportDivisionData.Coid)] = new[] { "COID/dept", "COID", "CO_ID" },
            [nameof(SkillMixOpportunityReportDivisionData.FacilityName)] = new[] { "COID Name" },
            [nameof(SkillMixOpportunityReportDivisionData.UnitNumber)] = new[] { "unit number", "UNIT_NUM" },
            [nameof(SkillMixOpportunityReportDivisionData.DeptNumber)] = new[] { "dep", "DEPT_NUM", "Dept" },
            [nameof(SkillMixOpportunityReportDivisionData.DeptDescription)] = new[] { "GL Dept Desc", "DEPT_DESC" },
            [nameof(SkillMixOpportunityReportDivisionData.SubFunctionNumber)] = new[] { "Sun fun", "Sub fun", "SUBFUNCTION_NUM" },
            [nameof(SkillMixOpportunityReportDivisionData.Mapping)] = new[] { "Mapping", "MAPPING" },
            [nameof(SkillMixOpportunityReportDivisionData.PaidActual)] = new[] { "PLUS 14 Day FTE Paid Actual", "PAID_ACTUAL" },
            [nameof(SkillMixOpportunityReportDivisionData.PaidVariance)] = new[] { "PLUS 14 Day FTE Paid Var", "PAID_VAR" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdActual)] = new[] { "PLUS 14 Day FTE Prod Actual", "PROD_ACTUAL" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdVariance)] = new[] { "PLUS 14 Day FTE Prod var", "PROD_VAR" },
            [nameof(SkillMixOpportunityReportDivisionData.ClFtes)] = new[] { "PLUS 14 Day FTE CL FTEs", "CL_FTES" },
            [nameof(SkillMixOpportunityReportDivisionData.GridStatus)] = new[] { "Grid Status", "GRID_DESC" },
            [nameof(SkillMixOpportunityReportDivisionData.AhsgRn)] = new[] { "Approved/Approved Historical Staffing Grid RN", "Approved Historical Staffing Grid RN", "Approved Staffing Grid RN", "AHSGRN" },
            [nameof(SkillMixOpportunityReportDivisionData.AhsgPct)] = new[] { "Approved/Approved Historical Staffing Grid PCT", "Approved Historical Staffing Grid PCT", "Approved Staffing Grid PCT", "AHSGPCT" },
            [nameof(SkillMixOpportunityReportDivisionData.AhsgLpn)] = new[] { "Approved/Approved Historical Staffing Grid LPN", "Approved Historical Staffing Grid LPN", "Approved Staffing Grid LPN", "AHSGLPN" },
            [nameof(SkillMixOpportunityReportDivisionData.AhsgClerical)] = new[] { "Approved/Approved Historical Staffing Grid Clerical", "Approved Historical Staffing Grid Clerical", "Approved Staffing Grid Clerical", "AHSGCLERICAL" },
            [nameof(SkillMixOpportunityReportDivisionData.AhsgSpecialist)] = new[] { "Approved/Approved Historical Staffing Grid Specialist", "Approved Historical Staffing Grid Specialist", "Approved Staffing Grid Specialist", "AHSGSPECIALIST" },
            [nameof(SkillMixOpportunityReportDivisionData.KronosRn)] = new[] { "Kronos/PLUS Keyed in CL 14 Day Skill Mix RN", "KRONOSRN" },
            [nameof(SkillMixOpportunityReportDivisionData.KronosPct)] = new[] { "Kronos/PLUS Keyed in CL 14 Day Skill Mix PCT", "KRONOSPCT" },
            [nameof(SkillMixOpportunityReportDivisionData.KronosLpn)] = new[] { "Kronos/PLUS Keyed in CL 14 Day Skill Mix LPN", "KRONOSLPN" },
            [nameof(SkillMixOpportunityReportDivisionData.KronosClerical)] = new[] { "Kronos/PLUS Keyed in CL 14 Day Skill Mix Clerical", "KRONOSCLERICAL" },
            [nameof(SkillMixOpportunityReportDivisionData.KronosSpecialist)] = new[] { "Kronos/PLUS Keyed in CL 14 Day Skill Mix Specialist", "KRONOSSPECIALIST" },
            [nameof(SkillMixOpportunityReportDivisionData.TargetRn)] = new[] { "RN Target", "TARGETRN" },
            [nameof(SkillMixOpportunityReportDivisionData.TargetPct)] = new[] { "PCT Target", "TARGETPCT" },
            [nameof(SkillMixOpportunityReportDivisionData.TargetLpn)] = new[] { "LPN Target", "TARGETLPN" },
            [nameof(SkillMixOpportunityReportDivisionData.TargetClerical)] = new[] { "Clerical Target", "TARGETCLERICAL" },
            [nameof(SkillMixOpportunityReportDivisionData.TargetSpecialist)] = new[] { "Specialist Target", "TARGETSPECIALIST" },
            [nameof(SkillMixOpportunityReportDivisionData.ActualRn)] = new[] { "RN Actual", "ACTUALRN" },
            [nameof(SkillMixOpportunityReportDivisionData.ActualPct)] = new[] { "PCT Actual", "ACTUALPCT" },
            [nameof(SkillMixOpportunityReportDivisionData.ActualLpn)] = new[] { "LPN Actual", "ACTUALLPN" },
            [nameof(SkillMixOpportunityReportDivisionData.ActualClerical)] = new[] { "Clerical Actual", "ACTUALCLERICAL" },
            [nameof(SkillMixOpportunityReportDivisionData.ActualSpecialist)] = new[] { "Specialist Actual", "ACTUALSPECIALIST" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdRn)] = new[] { "Prod FTE Variance by Skill Mix RN Var", "PRODRN" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdPct)] = new[] { "Prod FTE Variance by Skill Mix PCT Var", "PRODPCT" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdLpn)] = new[] { "Prod FTE Variance by Skill Mix LPN Var", "PRODLPN" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdClerical)] = new[] { "Prod FTE Variance by Skill Mix Clerical Var", "PRODCLERICAL" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdSpecialist)] = new[] { "Specialist Var", "PRODSPECIALIST" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdIdxRn)] = new[] { "Prod Index% RN", "PRODIDX_RN" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdIdxPct)] = new[] { "Prod Index% PCT", "PRODIDX_PCT" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdIdxLpn)] = new[] { "Prod Index% LPN", "PRODIDX_LPN" },
            [nameof(SkillMixOpportunityReportDivisionData.ProdIdxClerical)] = new[] { "Prod Index% Clerical", "PRODIDX_CLERICAL" },
            [nameof(SkillMixOpportunityReportDivisionData.RnLpn)] = new[] { "RN+LPN", "RNLPN" },
            [nameof(SkillMixOpportunityReportDivisionData.PctCle)] = new[] { "PCT + Clerical", "PCTCLE" },
            [nameof(SkillMixOpportunityReportDivisionData.TotalSkm)] = new[] { "Total(RN+LPN+PCT+Clerical)", "TOTALSKM" },
            [nameof(SkillMixOpportunityReportDivisionData.MtfRn)] = new[] { "Missed Target RN Missed FTEs", "Missed Target Missed FTEs RN", "MTF_RN" },
            [nameof(SkillMixOpportunityReportDivisionData.MtfLpn)] = new[] { "Missed Target LPN Missed FTEs", "Missed Target Missed FTEs LPN", "MTF_LPN" },
            [nameof(SkillMixOpportunityReportDivisionData.MtfPct)] = new[] { "Missed Target PCT Missed FTEs", "Missed Target Missed FTEs PCT", "MTF_PCT" },
            [nameof(SkillMixOpportunityReportDivisionData.MtfClerical)] = new[] { "Missed Target ClericalMissed FTEs", "Missed Target Clerical Missed FTEs", "Missed Target Missed FTEs Clerical", "MTF_CLERICAL" },
            [nameof(SkillMixOpportunityReportDivisionData.MissedTargetRnLpn)] = new[] { "Missed Target RN+LPN Missed FTEs", "Missed Target Missed FTEs RN+LPN", "MISSED_TGT_FTE_RN_LPN" },
            [nameof(SkillMixOpportunityReportDivisionData.MissingTargetPercent)] = new[] { "Missed Target RN+LPN Missed %", "Missed Target Missed % RN+LPN", "MISSING_TARGET_PER" }
        };

        internal static IEnumerable<string> RequiredValidationFields => FieldAliases.Keys
            .Where(field => field != nameof(SkillMixOpportunityReportDivisionData.FacilityName));

        private static bool HasRowIdentity(Dictionary<string, int> columnMap)
        {
            return columnMap.ContainsKey(nameof(SkillMixOpportunityReportDivisionData.DeptNumber))
                && (columnMap.ContainsKey(nameof(SkillMixOpportunityReportDivisionData.Coid))
                    || columnMap.ContainsKey(nameof(SkillMixOpportunityReportDivisionData.FacilityName)));
        }

        public static bool HasValidationColumns(string filePath)
        {
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            if (headerRowIndex == -1)
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                return false;
            }

            var columnMap = BuildColumnMap(rows, headerRowIndex);
            return HasRowIdentity(columnMap)
                && columnMap.Keys.Any(k => RequiredValidationFields.Contains(k)
                    && k != nameof(SkillMixOpportunityReportDivisionData.Coid)
                    && k != nameof(SkillMixOpportunityReportDivisionData.DeptNumber));
        }

        public static List<SkillMixOpportunityReportDivisionData> ParseSkillMixOpportunityReportDivisionExcel(string filePath)
        {
            var result = new List<SkillMixOpportunityReportDivisionData>();
            var rows = ReadRows(filePath);
            int headerRowIndex = FindHeaderRow(rows);
            if (headerRowIndex == -1)
            {
                Console.WriteLine("Report is downloaded but there is no data to validate.");
                return result;
            }

            var columnMap = BuildColumnMap(rows, headerRowIndex);
            var availableFields = columnMap.Keys.ToHashSet();
            Console.WriteLine("Skill Mix Opportunity Division Excel column mapping: "
                + string.Join(", ", columnMap.Select(c => $"{c.Key}=column {c.Value + 1}")));

            for (int i = headerRowIndex + 1; i < rows.Count; i++)
            {
                var row = rows[i];
                if (CommonFunctions.IsEmptyRow(row) || IsSummaryRow(row))
                    continue;

                string coid = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.Coid));
                string facilityName = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.FacilityName));
                string dept = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.DeptNumber));
                if ((string.IsNullOrWhiteSpace(coid) && string.IsNullOrWhiteSpace(facilityName))
                    || string.IsNullOrWhiteSpace(dept))
                    continue;

                result.Add(new SkillMixOpportunityReportDivisionData
                {
                    DivisionName = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.DivisionName)),
                    GroupName = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.GroupName)),
                    Coid = coid,
                    FacilityName = facilityName,
                    UnitNumber = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.UnitNumber)),
                    DeptNumber = dept,
                    DeptDescription = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.DeptDescription)),
                    SubFunctionNumber = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.SubFunctionNumber)),
                    Mapping = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.Mapping)),
                    PaidActual = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.PaidActual)),
                    PaidVariance = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.PaidVariance)),
                    ProdActual = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdActual)),
                    ProdVariance = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdVariance)),
                    ClFtes = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ClFtes)),
                    GridStatus = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.GridStatus)),
                    AhsgRn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.AhsgRn)),
                    AhsgPct = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.AhsgPct)),
                    AhsgLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.AhsgLpn)),
                    AhsgClerical = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.AhsgClerical)),
                    AhsgSpecialist = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.AhsgSpecialist)),
                    KronosRn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.KronosRn)),
                    KronosPct = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.KronosPct)),
                    KronosLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.KronosLpn)),
                    KronosClerical = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.KronosClerical)),
                    KronosSpecialist = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.KronosSpecialist)),
                    TargetRn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.TargetRn)),
                    TargetPct = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.TargetPct)),
                    TargetLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.TargetLpn)),
                    TargetClerical = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.TargetClerical)),
                    TargetSpecialist = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.TargetSpecialist)),
                    ActualRn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ActualRn)),
                    ActualPct = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ActualPct)),
                    ActualLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ActualLpn)),
                    ActualClerical = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ActualClerical)),
                    ActualSpecialist = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ActualSpecialist)),
                    ProdRn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdRn)),
                    ProdPct = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdPct)),
                    ProdLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdLpn)),
                    ProdClerical = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdClerical)),
                    ProdSpecialist = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdSpecialist)),
                    ProdIdxRn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdIdxRn)),
                    ProdIdxPct = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdIdxPct)),
                    ProdIdxLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdIdxLpn)),
                    ProdIdxClerical = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.ProdIdxClerical)),
                    RnLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.RnLpn)),
                    PctCle = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.PctCle)),
                    TotalSkm = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.TotalSkm)),
                    MtfRn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.MtfRn)),
                    MtfLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.MtfLpn)),
                    MtfPct = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.MtfPct)),
                    MtfClerical = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.MtfClerical)),
                    MissedTargetRnLpn = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.MissedTargetRnLpn)),
                    MissingTargetPercent = GetDecimal(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.MissingTargetPercent)),
                    AvailableFields = availableFields
                });
            }

            return result;
        }

        public static SkillMixOpportunityReportDivisionCriteria GetReportCriteria(string filePath, string fallbackDivision)
        {
            var rows = ReadRows(filePath);
            string division = FindDivisionName(rows) ?? fallbackDivision;
            int? divisionNumber = FindDivisionNumber(rows) ?? GetDivisionNumber(division);
            if (!divisionNumber.HasValue
                && !string.IsNullOrWhiteSpace(division)
                && NormalizeDivisionName(division) == NormalizeDivisionName(fallbackDivision))
                divisionNumber = GetDivisionNumber(fallbackDivision);

            if (!divisionNumber.HasValue)
                throw new InvalidOperationException($"Cannot determine the division number from the Detail sheet or UI selection for '{division}'.");

            var period = GetReportPeriod(rows);
            return new SkillMixOpportunityReportDivisionCriteria
            {
                DivisionName = division,
                DivisionNumber = divisionNumber.Value,
                ReportType = period.ReportType,
                StartDate = period.StartDate,
                EndDate = period.EndDate
            };
        }

        private static (string ReportType, DateTime? StartDate, DateTime? EndDate) GetReportPeriod(List<object[]> rows)
        {
            int headerRowIndex = FindHeaderRow(rows);
            var headerRows = headerRowIndex >= 0 ? rows.Take(headerRowIndex) : rows.Take(10);
            string text = string.Join(" ", headerRows.SelectMany(row => row)
                .Where(cell => cell != null).Select(cell => cell.ToString()));
            var rollingType = Regex.Match(text, @"\bRolling\s+\d+\s+Day\b", RegexOptions.IgnoreCase);
            var labelledType = Regex.Match(text, @"\bReport\s*Type\s*[:=]\s*(?<type>Month|Monthly|Year|Yearly|Bi[- ]?Weekly|Daily)\b", RegexOptions.IgnoreCase);
            string reportType = rollingType.Success ? rollingType.Value
                : labelledType.Success ? labelledType.Groups["type"].Value : null;
            var range = Regex.Match(text,
                @"(?<start>\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2})\s*(?:[-�]|to|through)\s*(?<end>\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2})",
                RegexOptions.IgnoreCase);
            if (!range.Success)
                return (reportType, null, null);

            var formats = new[] { "M/d/yyyy", "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "yyyy-MM-dd" };
            if (!DateTime.TryParseExact(range.Groups["start"].Value, formats,
                System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out DateTime startDate)
                || !DateTime.TryParseExact(range.Groups["end"].Value, formats,
                    System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out DateTime endDate)
                || startDate > endDate)
                throw new InvalidOperationException($"Invalid date range in the Detail report header: '{range.Value}'.");

            return (reportType, startDate.Date, endDate.Date);
        }

        private static int FindHeaderRow(List<object[]> rows)
        {
            for (int i = 0; i < rows.Count; i++)
            {
                var columnMap = BuildColumnMap(rows, i);
                if (HasRowIdentity(columnMap))
                {
                    int bestRow = i;
                    int bestCount = columnMap.Count;
                    for (int next = i + 1; next < Math.Min(i + HeaderLookbackRows + 1, rows.Count); next++)
                    {
                        var nextMap = BuildColumnMap(rows, next);
                        if (HasRowIdentity(nextMap) && nextMap.Count > bestCount)
                        {
                            bestRow = next;
                            bestCount = nextMap.Count;
                        }
                    }
                    return bestRow;
                }
            }
            return -1;
        }

        private static Dictionary<string, int> BuildColumnMap(List<object[]> rows, int headerRowIndex)
        {
            var result = new Dictionary<string, int>();
            var headerRow = rows[headerRowIndex];
            int firstRow = Math.Max(0, headerRowIndex - HeaderLookbackRows);
            var headerRows = rows.Skip(firstRow).Take(headerRowIndex - firstRow + 1).ToArray();
            int columnCount = headerRows.Max(r => r.Length);
            var candidates = Enumerable.Range(0, columnCount).Select(_ => new HashSet<string>()).ToArray();
            var groups = new string[headerRows.Length - 1];
            for (int column = 0; column < columnCount; column++)
            {
                for (int level = 0; level < groups.Length; level++)
                {
                    string text = GetCellText(headerRows[level], column);
                    if (!string.IsNullOrWhiteSpace(text))
                    {
                        groups[level] = text;
                        for (int lower = level + 1; lower < groups.Length; lower++)
                            groups[lower] = string.Empty;
                    }
                }
                string detail = GetCellText(headerRow, column);
                candidates[column].Add(NormalizeHeader(detail));
                for (int mask = 1; mask < (1 << groups.Length); mask++)
                {
                    string prefix = string.Join(" ", groups.Where((g, level) => (mask & (1 << level)) != 0)
                        .Where(g => !string.IsNullOrWhiteSpace(g)).Distinct());
                    candidates[column].Add(NormalizeHeader($"{prefix} {detail}"));
                    candidates[column].Add(NormalizeHeader($"{detail} {prefix}"));
                }
            }
            var usedColumns = new HashSet<int>();
            foreach (var field in FieldAliases)
            {
                foreach (string alias in field.Value.Select(NormalizeHeader).OrderByDescending(a => a.Length))
                {
                    int index = Enumerable.Range(0, columnCount)
                        .FirstOrDefault(c => !usedColumns.Contains(c) && candidates[c].Contains(alias), -1);
                    if (index >= 0)
                    {
                        result[field.Key] = index;
                        usedColumns.Add(index);
                        break;
                    }
                }
            }
            return result;
        }

        private sealed class PercentageCell
        {
            public decimal Value { get; }

            public PercentageCell(decimal value)
            {
                Value = value;
            }

            public override string ToString()
            {
                return (Value * 100m).ToString(System.Globalization.CultureInfo.InvariantCulture) + "%";
            }
        }

        private static List<object[]> ReadRows(string filePath)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var rows = new List<object[]>();
            bool hasDetailSheet = false;
            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                do
                {
                    bool isDetail = string.Equals(reader.Name?.Trim(), "Detail", StringComparison.OrdinalIgnoreCase);
                    if (!isDetail)
                        continue;
                    hasDetailSheet = true;
                    var sheetRows = new List<object[]>();
                    while (reader.Read())
                    {
                        var row = new object[reader.FieldCount];
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            object value = reader.GetValue(i);
                            string numberFormat = reader.GetNumberFormatString(i) ?? string.Empty;
                            string numericFormat = Regex.Replace(numberFormat, @"""[^""]*""|\\.", string.Empty);
                            bool isNumeric = value is double || value is float || value is decimal
                                || value is int || value is long;
                            row[i] = isNumeric && numericFormat.Contains('%')
                                ? new PercentageCell(Convert.ToDecimal(value, System.Globalization.CultureInfo.InvariantCulture))
                                : value;
                        }
                        sheetRows.Add(row);
                    }
                    foreach (var range in reader.MergeCells ?? Array.Empty<CellRange>())
                    {
                        if (range.FromRow >= sheetRows.Count || range.FromColumn >= sheetRows[range.FromRow].Length)
                            continue;
                        object value = sheetRows[range.FromRow][range.FromColumn];
                        for (int rowIndex = range.FromRow; rowIndex <= range.ToRow && rowIndex < sheetRows.Count; rowIndex++)
                        {
                            var row = sheetRows[rowIndex];
                            for (int column = range.FromColumn; column <= range.ToColumn && column < row.Length; column++)
                                row[column] ??= value;
                        }
                    }
                    rows.AddRange(sheetRows);
                } while (reader.NextResult());
            }
            if (!hasDetailSheet)
                throw new InvalidOperationException("The workbook does not contain the required Detail sheet. Hospital Level data cannot be used for department validation.");
            return rows;
        }

        private static string FindDivisionName(List<object[]> rows)
        {
            int headerRowIndex = FindHeaderRow(rows);
            if (headerRowIndex >= 0)
            {
                var columnMap = BuildColumnMap(rows, headerRowIndex);
                foreach (var row in rows.Skip(headerRowIndex + 1).Where(r => !IsSummaryRow(r)))
                {
                    string division = GetString(row, columnMap, nameof(SkillMixOpportunityReportDivisionData.DivisionName));
                    if (!string.IsNullOrWhiteSpace(division) && !int.TryParse(division, out _))
                        return division;
                }
            }

            var headerRows = headerRowIndex > 0 ? rows.Take(headerRowIndex) : rows.Take(10);
            foreach (var row in headerRows)
            {
                string text = string.Join(" ", row.Where(c => c != null).Select(c => c.ToString()));
                var match = Regex.Match(text, @"Division\s*[:\-]?\s*(?<division>(?:\d+\s*-\s*)?.+?DIVISION)", RegexOptions.IgnoreCase);
                if (match.Success)
                    return match.Groups["division"].Value.Trim();
            }
            return null;
        }

        private static int? FindDivisionNumber(List<object[]> rows)
        {
            var numberHeaders = new[] { "DIVISIONNBR", "DIVISIONNUMBER", "DIVISIONNUM", "DIVNBR", "DIVNUM", "VDIVNUM" };
            int headerRowIndex = FindHeaderRow(rows);
            for (int rowIndex = 0; rowIndex < rows.Count; rowIndex++)
            {
                var row = rows[rowIndex];
                for (int i = 0; i < row.Length; i++)
                {
                    string cell = GetCellText(row, i);
                    string header = NormalizeHeader(cell);
                    bool numberHeader = numberHeaders.Contains(header);
                    bool divisionHeader = header == "DIV" || header == "DIVISION";
                    if (numberHeader || divisionHeader)
                    {
                        if ((headerRowIndex < 0 || rowIndex < headerRowIndex)
                            && int.TryParse(GetCellText(row, i + 1), out int labelledNumber)
                            && labelledNumber > 0)
                            return labelledNumber;

                        foreach (var dataRow in rows.Skip(rowIndex + 1).Where(r => !IsSummaryRow(r)))
                        {
                            if (int.TryParse(GetCellText(dataRow, i), out int columnNumber) && columnNumber > 0)
                                return columnNumber;
                            if (!string.IsNullOrWhiteSpace(GetCellText(dataRow, i)))
                                break;
                        }
                    }

                    var match = Regex.Match(cell, @"^\s*(?:Division\s*(?:Number|Nbr|Num)?\s*[:=]\s*|v_div_Num\s*[:=]\s*)(?<number>\d+)\b", RegexOptions.IgnoreCase);
                    if (match.Success && int.TryParse(match.Groups["number"].Value, out int explicitNumber) && explicitNumber > 0)
                        return explicitNumber;
                }
            }

            return null;
        }

        private static int? GetDivisionNumber(string division)
        {
            if (string.IsNullOrWhiteSpace(division)) return null;
            var numberMatch = Regex.Match(division, @"^\s*(?<number>\d+)(?:\s*-\s*|\s*$)");
            if (numberMatch.Success && int.TryParse(numberMatch.Groups["number"].Value, out int parsed) && parsed > 0)
                return parsed;
            return NormalizeDivisionName(division) == "TRISTAR" ? 7 : (int?)null;
        }

        internal static string NormalizeDivisionName(string division)
        {
            if (string.IsNullOrWhiteSpace(division)) return string.Empty;
            string name = Regex.Replace(division.Trim(), @"^\d+\s*-?\s*", string.Empty);
            name = Regex.Replace(name, @"\s+DIVISION\s*$", string.Empty, RegexOptions.IgnoreCase);
            return NormalizeHeader(name);
        }

        private static string GetString(object[] row, Dictionary<string, int> map, string fieldName)
        {
            return map.TryGetValue(fieldName, out int index) && index < row.Length ? row[index]?.ToString()?.Trim() ?? string.Empty : string.Empty;
        }

        private static decimal GetDecimal(object[] row, Dictionary<string, int> map, string fieldName)
        {
            if (!map.TryGetValue(fieldName, out int index) || index >= row.Length || row[index] == null) return 0m;
            var value = row[index];
            if (value is PercentageCell percentage)
                return fieldName == nameof(SkillMixOpportunityReportDivisionData.MissingTargetPercent)
                    ? percentage.Value : percentage.Value * 100m;
            if (value is decimal dec) return dec;
            if (value is double d) return (decimal)d;
            if (value is float f) return (decimal)f;
            if (value is int i) return i;
            if (value is long l) return l;
            bool isPercentageText = value.ToString()?.Contains('%') == true;
            string text = value.ToString()?.Replace("$", string.Empty).Replace(",", string.Empty).Replace("%", string.Empty).Trim();
            bool isNegative = text.StartsWith("(") && text.EndsWith(")");
            if (isNegative) text = text.Trim('(', ')');
            if (!decimal.TryParse(text, System.Globalization.NumberStyles.Number,
                System.Globalization.CultureInfo.InvariantCulture, out decimal parsed))
                return 0m;
            if (isNegative) parsed = -parsed;
            return isPercentageText && fieldName == nameof(SkillMixOpportunityReportDivisionData.MissingTargetPercent)
                ? parsed / 100m : parsed;
        }

        private static bool IsSummaryRow(object[] row)
        {
            return row.Take(2).Any(c => Regex.IsMatch(c?.ToString()?.Trim() ?? string.Empty,
                @"^(?:(?:grand\s+)?total|average)(?:\s|$)", RegexOptions.IgnoreCase));
        }

        private static string GetCellText(object[] row, int index)
        {
            return index >= 0 && index < row.Length ? row[index]?.ToString()?.Trim() ?? string.Empty : string.Empty;
        }

        private static string NormalizeHeader(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : Regex.Replace(value, @"[^A-Za-z0-9]", string.Empty).ToUpperInvariant()
                .Replace("MISSEDTARGETS", "MISSEDTARGET")
                .Replace("PRODFTEVARIANCEBYSKILLMIX", "PRODFTEVARIANCE");
        }
    }
}
