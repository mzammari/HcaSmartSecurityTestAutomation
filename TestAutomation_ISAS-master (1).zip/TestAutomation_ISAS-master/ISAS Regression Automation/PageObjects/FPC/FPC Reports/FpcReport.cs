﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FpcReportSummary
    {
        public string Dept { get; set; }
        public string DeptDescription { get; set; }
        public decimal TotalFtespaidAndContractBudgeted2026 { get; set; }
        public decimal TotalFtespaidAndContractHistorical2025 { get; set; }
        public decimal TotalFtespaidAndContractPercentChange { get; set; }
        public decimal DepartmentVolumeBudgeted2026 { get; set; }
        public decimal DepartmentVolumeHistorical2025 { get; set; }
        public decimal DepartmentVolumePercentChange { get; set; }
        public decimal TotalProductiveHourspercentuosBudgeted2026 { get; set; }
        public decimal TotalProductiveHourspercentuosHistorical2025 { get; set; }
        public decimal TotalProductiveHourspercentuosPercentChange { get; set; }
        public decimal CurrentPLUSTargetProductiveHourspercentuos { get; set; }
    }


    public class FpcReportExcelReport
    {
        public static List<FpcReportSummary> ParseAnnualBudgetSummaryExcelReport(string filePath)
        {
            var result = new List<FpcReportSummary>();

            // Register the code page provider (required for .xls files)
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var allRows = new List<object[]>();

                    // Read all rows into memory
                    do
                    {
                        while (reader.Read())
                        {
                            var row = new object[reader.FieldCount];
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row[i] = reader.GetValue(i);
                            }
                            allRows.Add(row);
                        }
                    } while (reader.NextResult());

                    // Find the row that contains "Dept" in the first column
                    int startRowIndex = CommonFunctions.FindDeptRow("Dept", allRows);

                    if (startRowIndex == -1)
                    {
                        throw new InvalidOperationException("Could not find 'Dept' in the first column");
                    }

                    // Process rows starting after the "Dept" header row
                    for (int i = startRowIndex + 1; i < allRows.Count; i++)
                    {
                        var row = allRows[i];

                        // Skip empty rows
                        if (CommonFunctions.IsEmptyRow(row))
                            continue;

                        var lstRows = new FpcReportSummary()
                        {
                            Dept = CommonFunctions.GetStringValue(row, 0),
                            DeptDescription = CommonFunctions.GetStringValue(row, 1),
                            TotalFtespaidAndContractBudgeted2026 = CommonFunctions.GetDecimalValue(row, 2),
                            TotalFtespaidAndContractHistorical2025 = CommonFunctions.GetDecimalValue(row, 3),
                            TotalFtespaidAndContractPercentChange = CommonFunctions.GetDecimalValue(row, 4),
                            DepartmentVolumeBudgeted2026 = CommonFunctions.GetDecimalValue(row, 5),
                            DepartmentVolumeHistorical2025 = CommonFunctions.GetDecimalValue(row, 6),
                            DepartmentVolumePercentChange = CommonFunctions.GetDecimalValue(row, 7),
                            TotalProductiveHourspercentuosBudgeted2026 = CommonFunctions.GetDecimalValue(row, 8),
                            TotalProductiveHourspercentuosHistorical2025 = CommonFunctions.GetDecimalValue(row, 9),
                            TotalProductiveHourspercentuosPercentChange = CommonFunctions.GetDecimalValue(row, 10),
                            CurrentPLUSTargetProductiveHourspercentuos = CommonFunctions.GetDecimalValue(row, 11),
                        };

                        result.Add(lstRows);
                    }
                }
            }
            return result;
        }
    }
}
