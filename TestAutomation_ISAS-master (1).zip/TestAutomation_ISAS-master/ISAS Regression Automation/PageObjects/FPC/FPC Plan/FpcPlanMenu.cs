﻿using AutomationCoreLite.Reporting;
using AventStack.ExtentReports.Gherkin.Model;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FpcPlanMenu
    {
        #region: Action
        public static void Save()
        {
            bool bDisplayed, bEnabled;
            By allowedOver = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-core-fte-variance-greater-than-allowed-alert']//button/span[text()='Yes']");
            By byNoChanges = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-no-changes-to-save-alert']//button/span[text()='OK']");
            By byProceedWithSaving = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-targetProductiveFtes-atAverage-greaterthan-atPeak-confirm']//button/span[text()='Yes']");
            
            string SubmitXpath = "//*/div[@aria-labelledby='ui-dialog-title-lawson-warnings-save-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-save-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string OverrideXpath = "//*/div[@aria-labelledby='ui-dialog-title-core-fte-variance-greater-than-allowed-alert']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string SaveXpath = "//*/a[@id='savePlanBtn' and not(@disabled)]";
            
            bEnabled = CommonFunctions.IsElementDisplayed(SaveXpath, 5);
            if (bEnabled)
            {
                IWebElement cmdSave = CommonFunctions.getElement(By.XPath(SaveXpath));
                CommonFunctions.ClickByJE(cmdSave);
                bDisplayed = CommonFunctions.IsElementDisplayed(SubmitXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(SubmitXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                }

                bDisplayed = CommonFunctions.IsElementDisplayed(byProceedWithSaving, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(byProceedWithSaving);
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                }

                bDisplayed = CommonFunctions.IsElementDisplayed(OverrideXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(OverrideXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }

                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }

                bDisplayed = CommonFunctions.IsElementDisplayed(byNoChanges, 2);
                if (bDisplayed)
                {
                    IWebElement cmdOK = CommonFunctions.getElement(byNoChanges);
                    CommonFunctions.ClickByJE(cmdOK);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }

                bDisplayed = CommonFunctions.IsElementDisplayed(allowedOver, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(allowedOver);
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.WaitSaveToastMsgDisappeared();
                CommonFunctions.AddTestStep("Click on the save button", "The page is saved");
            }
        }        

        public static void UpdateReqInfo()
        {
            bool bDisplayed, bEnabled;           
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-update-lawson-req-infromation-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";          
            string updateXpath = "//*/a[@id='uptLawsonBtn' and not(@disabled)]";
            bEnabled = CommonFunctions.IsElementDisplayed(updateXpath, 5);
            if (bEnabled)
            {
                IWebElement cmdUpdateReqInfo = CommonFunctions.getElement(By.XPath(updateXpath));
                CommonFunctions.ClickByJE(cmdUpdateReqInfo);
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    CommonFunctions.AddTestStep("Click on the UpdateReqInfo button", "The button is enaled.");
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                    FpcPlanMenu.Save();
                    CommonFunctions.WaitUntilPageIsAcive();
                }
            }
        }

        public static void AddMissingReqs()
        {
            bool bDisplayed, bEnabled;
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-add-missing-lawson-req-infromation-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string updateXpath = "//*/a[@id='addMissedLawsonBtn' and not(@disabled)]";
            bEnabled = CommonFunctions.IsElementDisplayed(updateXpath, 5);
            if (bEnabled)
            {
                IWebElement cmdAddMissingReqs = CommonFunctions.getElement(By.XPath(updateXpath));
                CommonFunctions.ClickByJE(cmdAddMissingReqs);
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    CommonFunctions.AddTestStep("Click on the AddMissingReqs button", "The button is enabled");
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }
            }
            Save();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
            //CommonFunctions.BrowserRefresh();
            //CommonFunctions.WaitUntilPageIsAcive();
            //FpcPlanFilter.ViewPlanDetail();
            //CommonFunctions.WaitUntilPageIsAcive();
            //CommonFunctions.WaitUntilPageIsAcive();
        }

        public static clFpcComments Submit()
        {
            string comment = "Submitting a plan";
            string errorXpath = "//*/div[@aria-labelledby='ui-dialog-title-lawson-warnings-save-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='No']";
            bool bDisplayed, bEnabled;
            string SubmitFutureTargetMonthXpath = "//*/div[@aria-labelledby='ui-dialog-title-futuretargetMonth-Submit' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string SubmitXpath = "//*/a[@id='submitPlanBtn' and not(@disabled)]";
            By ConfirmSubmitting = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-submit-plan-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']");
            bEnabled = CommonFunctions.IsElementDisplayed(SubmitXpath, 5);
            if (bEnabled)
            {
                Timer.Start();
                IWebElement cmdSubmit = CommonFunctions.getElement(By.XPath(SubmitXpath));
                CommonFunctions.ClickByJE(cmdSubmit);

                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmSubmitting, 2);
                if(bDisplayed)
                {
                    CommonFunctions.ClickByJE(CommonFunctions.getElement(ConfirmSubmitting));
                }

                bDisplayed = CommonFunctions.IsElementDisplayed(SubmitFutureTargetMonthXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(SubmitFutureTargetMonthXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }

                bDisplayed = CommonFunctions.IsElementDisplayed(errorXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(errorXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    UpdateReqInfo();
                    cmdSubmit = CommonFunctions.getElement(By.XPath(SubmitXpath));
                    CommonFunctions.ClickByJE(cmdSubmit);
                    bDisplayed = CommonFunctions.IsElementDisplayed(SubmitFutureTargetMonthXpath, 2);
                    if (bDisplayed)
                    {
                        cmdYes = CommonFunctions.getElement(By.XPath(SubmitFutureTargetMonthXpath));
                        CommonFunctions.ClickByJE(cmdYes);
                        CommonFunctions.WaitUntilPageIsAcive();
                        CommonFunctions.WaitSaveToastMsgDisappeared();
                    }
                }                
            }
            CommonFunctions.AddTestStep("Submit the plan", "Plan is submitted");
            var FpcCommentData = FpcCommentDialog.SetFpcComment(comment);
            Timer.Stop();
            CommonFunctions.WriteToFile($"Submit plan {Timer.GetElapsedTime()}");
            return FpcCommentData;
        }

        public static clFpcComments Approve(string Comment)
        {
            bool bDisplayed, bEnabled;
            By byProceedWithSavingPlan = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-include-inactive-in-fte-calc-mismatch-on-admin-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']");
            string SubmitFutureTargetMonthXpath = "//*/div[@aria-labelledby='ui-dialog-title-futuretargetMonth-Approve' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string SubmitXpath = "//*/a[@id='aproveBtn' and not(@disabled)]";
            bEnabled = CommonFunctions.IsElementDisplayed(SubmitXpath, 5);
            if (bEnabled)
            {               
                IWebElement cmdUpdateReqInfo = CommonFunctions.getElement(By.XPath(SubmitXpath));
                CommonFunctions.ClickByJE(cmdUpdateReqInfo);
                bDisplayed = CommonFunctions.IsElementDisplayed(SubmitFutureTargetMonthXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(SubmitFutureTargetMonthXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                   
                }

                bDisplayed = CommonFunctions.IsElementDisplayed(SubmitFutureTargetMonthXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(SubmitFutureTargetMonthXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }                
            }
            CommonFunctions.AddTestStep("Approve the plan", "Plan is approved");
            var FpcCommentData = FpcCommentDialog.SetFpcComment(Comment);

            bDisplayed = CommonFunctions.IsElementDisplayed(byProceedWithSavingPlan, 2);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(byProceedWithSavingPlan);
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }
            return FpcCommentData;
        }

        public static clFpcComments Reject(string Comment)
        {
            CommonFunctions.AddTestStep("Verify reecting a plan", "The plan is rejected");
            bool bDisplayed, bEnabled;
            string SubmitFutureTargetMonthXpath = "//*/div[@aria-labelledby='ui-dialog-title-futuretargetMonth-Approve' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string RejectXpath = "//*/a[@id='rejectBtn' and not(@disabled)]";
            bEnabled = CommonFunctions.IsElementDisplayed(RejectXpath, 5);
            if (bEnabled)
            {
                IWebElement cmdUpdateReqInfo = CommonFunctions.getElement(By.XPath(RejectXpath));
                CommonFunctions.ClickByJE(cmdUpdateReqInfo);
                bDisplayed = CommonFunctions.IsElementDisplayed(SubmitFutureTargetMonthXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(SubmitFutureTargetMonthXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }
                var FpcCommentData = FpcCommentDialog.SetFpcComment(Comment);
                return FpcCommentData;
            }
            return null;
        }        
        #endregion
    }
}
