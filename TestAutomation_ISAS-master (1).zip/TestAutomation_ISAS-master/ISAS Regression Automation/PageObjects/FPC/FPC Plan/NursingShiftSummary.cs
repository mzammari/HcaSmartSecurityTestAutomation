﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class NursingShiftSummary
    {
        public class NursingDeptShiftSummary
        {
            public decimal RNResidentBlueLineDay { get; set; }
            public decimal RNResidentBlueLineDayPercent { get; set; }
            public decimal RNResidentBlueLineEve { get; set; }
            public decimal RNResidentBlueLineEvePercent { get; set; }
            public decimal RNResidentBlueLineNight { get; set; }
            public decimal RNResidentBlueLineNightPercent { get; set; }
            public decimal RNResidentBlueLineTotal { get; set; }
            public decimal RNResidentBlueLineTotalPercent { get; set; }

            public decimal RnExpBlueLineDay { get; set; }
            public decimal RnExpBlueLineDayPercent { get; set; }
            public decimal RnExpBlueLineEve { get; set; }
            public decimal RnExpBlueLineEvePercent { get; set; }
            public decimal RnExpBlueLineNight { get; set; }
            public decimal RnExpBlueLineNightPercent { get; set; }
            public decimal RnExpBlueLineTotal { get; set; }
            public decimal RnExpBlueLineTotalPercent { get; set; }

            public decimal TotalReqsDay { get; set; }
            public decimal TotalReqsEve { get; set; }
            public decimal TotalReqsNight { get; set; }
            public decimal TotalReqsTotal { get; set; }

            public decimal RNResidentGrayLineDay { get; set; }
            public decimal RNResidentGrayLineDayPercent { get; set; }
            public decimal RNResidentGrayLineEve { get; set; }
            public decimal RNResidentGrayLineEvePercent { get; set; }
            public decimal RNResidentGrayLineNight { get; set; }
            public decimal RNResidentGrayLineNightPercent { get; set; }
            public decimal RNResidentGrayLineTotal { get; set; }
            public decimal RNResidentGrayLineTotalPercent { get; set; }

            public decimal RnExpGrayLineDay { get; set; }
            public decimal RnExpGrayLineDayPercent { get; set; }
            public decimal RnExpGrayLineEve { get; set; }
            public decimal RnExpGrayLineEvePercent { get; set; }
            public decimal RnExpGrayLineNight { get; set; }
            public decimal RnExpGrayLineNightPercent { get; set; }
            public decimal RnExpGrayLineTotal { get; set; }
            public decimal RnExpGrayLineTotalPercent { get; set; }

            public decimal HiredInTotalDay { get; set; }
            public decimal HiredInTotalEve { get; set; }
            public decimal HiredInTotalNight { get; set; }
            public decimal HiredInTotalTotal { get; set; }

        }

        private void isShiftSummaryLoaded()
        {
            bool isLoaded;
            By bybtnShiftSummarytoggle = By.XPath("//*/button[@id='toggleBtn']");
            By byShiftSummarytoggleExpanded = By.XPath("//*/button[@id='toggleBtn' and text()='+']");
            isLoaded =  CommonFunctions.IsElementDisplayed(byShiftSummarytoggleExpanded, 2);
            if(!isLoaded)
            {
                CommonFunctions.getElement(bybtnShiftSummarytoggle).Click();
                Thread.Sleep(1000);
            }
            CommonFunctions.AddTestStep("Verified Nursing Shift Summary is loaded", "Nursing Shift Summary is loaded");
        }

        public NursingDeptShiftSummary getNursingDeptShiftSummary()
        {
            isShiftSummaryLoaded();
            CommonFunctions.AddTestStep("Return Nursing Shift Summary data", "Nursing Shift Summary data is fetched");

            By byRNResidentBlueLineDay = By.Id("txtDayBlueRnResCoreFtesSum");
            By byRNResidentBlueLineDayPercent = By.Id("txtDayBlueRnResCoreFtesSumPer");
            By byRNResidentBlueLineEve = By.Id("txtEveningBlueRnResCoreFtesSum");
            By byRNResidentBlueLineEvePercent = By.Id("txtEveningBlueRnResCoreFtesSumPer");
            By byRNResidentBlueLineNight = By.Id("txtNightBlueRnResCoreFtesSum");
            By byRNResidentBlueLineNightPercent = By.Id("txtNightBlueRnResCoreFtesSumPer");
            By byRNResidentBlueLineTotal = By.Id("txtTotalBlueRnResCoreFtesSum");
            By byRNResidentBlueLineTotalPercent = By.Id("txtTotalBlueRnResCoreFtesSumPer");

            By byRNExpBlueLineDay = By.Id("txtDayBlueRnExpCoreFtesSum");
            By byRNExpBlueLineDayPercent = By.Id("txtDayBlueRnExpCoreFtesSumPer");
            By byRNExpBlueLineEve = By.Id("txtEveningBlueRnExpCoreFtesSum");
            By byRNExpBlueLineEvePercent = By.Id("txtEveningBlueRnExpCoreFtesSumPer");
            By byRNExpBlueLineNight = By.Id("txtNightBlueRnExpCoreFtesSum");
            By byRNExpBlueLineNightPercent = By.Id("txtNightBlueRnExpCoreFtesSumPer");
            By byRNExpBlueLineTotal = By.Id("txtTotalBlueRnExpCoreFtesSum");
            By byRNExpBlueLineTotalPercent = By.Id("txtTotalBlueRnExpCoreFtesSumPer");

            By byTotalReqsDay = By.Id("txtTotalReqDay");
            By byTotalReqsEve = By.Id("txtTotalReqEvening");
            By byTotalReqsNight = By.Id("txtTotalReqNight");
            By byTotalReqsTotal = By.Id("txtTotalReqTot");

            By byRNResidentGrayLineDay = By.Id("txtDayGrayRnResCoreFtesSum");
            By byRNResidentGrayLineDayPercent = By.Id("txtDayGrayRnResCoreFtesSumPer");
            By byRNResidentGrayLineEve = By.Id("txtEveningGrayRnResCoreFtesSum");
            By byRNResidentGrayLineEvePercent = By.Id("txtEveningGrayRnResCoreFtesSumPer");
            By byRNResidentGrayLineNight = By.Id("txtNightGrayRnResCoreFtesSum");
            By byRNResidentGrayLineNightPercent = By.Id("txtNightGrayRnResCoreFtesSumPer");
            By byRNResidentGrayLineTotal = By.Id("txtTotalGrayRnResCoreFtesSum");
            By byRNResidentGrayLineTotalPercent = By.Id("txtTotalGrayRnResCoreFtesSumPer");

            By byRNExpGrayLineDay = By.Id("txtDayGrayRnExpCoreFtesSum");
            By byRNExpGrayLineDayPercent = By.Id("txtDayGrayRnExpCoreFtesSumPer");
            By byRNExpGrayLineEve = By.Id("txtEveningGrayRnExpCoreFtesSum");
            By byRNExpGrayLineEvePercent = By.Id("txtEveningGrayRnExpCoreFtesSumPer");
            By byRNExpGrayLineNight = By.Id("txtNightGrayRnExpCoreFtesSum");
            By byRNExpGrayLineNightPercent = By.Id("txtNightGrayRnExpCoreFtesSumPer");
            By byRNExpGrayLineTotal = By.Id("txtTotalGrayRnExpCoreFtesSum");
            By byRNExpGrayLineTotalPercent = By.Id("txtTotalGrayRnExpCoreFtesSumPer");

            By byHiredInTotalDay = By.Id("txtHrdInTotReqDay");
            By byHiredInTotalEve = By.Id("txtHrdInTotReqEvening");
            By byHiredInTotalNight = By.Id("txtHrdInTotReqNight");
            By byHiredInTotal = By.Id("txtHrdInTotReqTot");


            return new NursingDeptShiftSummary()
            {
                RNResidentBlueLineDay = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentBlueLineDay).Text),
                RNResidentBlueLineDayPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentBlueLineDayPercent).Text),
                RNResidentBlueLineEve = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentBlueLineEve).Text),
                RNResidentBlueLineEvePercent = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentBlueLineEvePercent).Text),
                RNResidentBlueLineNight = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentBlueLineNight).Text),
                RNResidentBlueLineNightPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentBlueLineNightPercent).Text),
                RNResidentBlueLineTotal = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentBlueLineTotal).Text),
                RNResidentBlueLineTotalPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentBlueLineTotalPercent).Text),

                RnExpBlueLineDay = Convert.ToDecimal(CommonFunctions.getElement(byRNExpBlueLineDay).Text),
                RnExpBlueLineDayPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNExpBlueLineDayPercent).Text),
                RnExpBlueLineEve = Convert.ToDecimal(CommonFunctions.getElement(byRNExpBlueLineEve).Text),
                RnExpBlueLineEvePercent = Convert.ToDecimal(CommonFunctions.getElement(byRNExpBlueLineEvePercent).Text),
                RnExpBlueLineNight = Convert.ToDecimal(CommonFunctions.getElement(byRNExpBlueLineNight).Text),
                RnExpBlueLineNightPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNExpBlueLineNightPercent).Text),
                RnExpBlueLineTotal = Convert.ToDecimal(CommonFunctions.getElement(byRNExpBlueLineTotal).Text),
                RnExpBlueLineTotalPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNExpBlueLineTotalPercent).Text),

                TotalReqsDay = Convert.ToDecimal(CommonFunctions.getElement(byTotalReqsDay).Text),
                TotalReqsEve = Convert.ToDecimal(CommonFunctions.getElement(byTotalReqsEve).Text),
                TotalReqsNight = Convert.ToDecimal(CommonFunctions.getElement(byTotalReqsNight).Text),
                TotalReqsTotal = Convert.ToDecimal(CommonFunctions.getElement(byTotalReqsTotal).Text),

                RNResidentGrayLineDay = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentGrayLineDay).Text),
                RNResidentGrayLineDayPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentGrayLineDayPercent).Text),
                RNResidentGrayLineEve = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentGrayLineEve).Text),
                RNResidentGrayLineEvePercent = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentGrayLineEvePercent).Text),
                RNResidentGrayLineNight = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentGrayLineNight).Text),
                RNResidentGrayLineNightPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentGrayLineNightPercent).Text),
                RNResidentGrayLineTotal = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentGrayLineTotal).Text),
                RNResidentGrayLineTotalPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNResidentGrayLineTotalPercent).Text),

                RnExpGrayLineDay = Convert.ToDecimal(CommonFunctions.getElement(byRNExpGrayLineDay).Text),
                RnExpGrayLineDayPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNExpGrayLineDayPercent).Text),
                RnExpGrayLineEve = Convert.ToDecimal(CommonFunctions.getElement(byRNExpGrayLineEve).Text),
                RnExpGrayLineEvePercent = Convert.ToDecimal(CommonFunctions.getElement(byRNExpGrayLineEvePercent).Text),
                RnExpGrayLineNight = Convert.ToDecimal(CommonFunctions.getElement(byRNExpGrayLineNight).Text),
                RnExpGrayLineNightPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNExpGrayLineNightPercent).Text),
                RnExpGrayLineTotal = Convert.ToDecimal(CommonFunctions.getElement(byRNExpGrayLineTotal).Text),
                RnExpGrayLineTotalPercent = Convert.ToDecimal(CommonFunctions.getElement(byRNExpGrayLineTotalPercent).Text),

                HiredInTotalDay = Convert.ToDecimal(CommonFunctions.getElement(byHiredInTotalDay).Text),
                HiredInTotalEve = Convert.ToDecimal(CommonFunctions.getElement(byHiredInTotalEve).Text),
                HiredInTotalNight = Convert.ToDecimal(CommonFunctions.getElement(byHiredInTotalNight).Text),
                HiredInTotalTotal = Convert.ToDecimal(CommonFunctions.getElement(byHiredInTotal).Text)
            };
        }
    }
}
