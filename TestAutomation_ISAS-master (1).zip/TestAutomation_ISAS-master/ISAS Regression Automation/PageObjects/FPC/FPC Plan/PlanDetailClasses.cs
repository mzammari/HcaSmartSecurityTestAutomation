﻿using OpenQA.Selenium;
using System;

namespace ISAS_Regression_Automation
{
    public class ViewPlanDetailSummary
    {
        public string PlanID { get; set; }
        public string DeptSubfunction { get; set; }
        public string DeptType { get; set; }
        public string UpdatedBy { get; set; }
        public string SubmittedBy { get; set; }
        public string ApprovalsReceived { get; set; }
        public string PlanDescription { get; set; }
        public string StaffingGridDetail { get; set; }
        public string StatDesc { get; set; }
        public string UpdatedOn { get; set; }
        public string SubmittedOn { get; set; }
        public string HRRefreshedOn { get; set; }
    }

    public class PlanDetailFteSummaryClass
    {
        public string TotalTargetPaidFTEs_Core { get; set; }
        public string TotalTargetPaidFTEs_Average { get; set; }
        public string TotalTargetPaidFTEs_Peak { get; set; }
        public string TotalDepartmentPaidFTEs_Core { get; set; }
        public string TotalDepartmentPaidFTEs_Average { get; set; }
        public string TotalDepartmentPaidFTEs_Peak { get; set; }
        public string Variance_Core { get; set; }
        public string Variance_Average { get; set; }
        public string Variance_Peak { get; set; }
        public string AverageDailyVolume_Core { get; set; }
        public string AverageDailyVolume_Average { get; set; }
        public string AverageDailyVolume_Peak { get; set; }
        public string HiredInFTE { get; set; }
        public string AllowableFteVariance { get; set; }
        public string OPEN_Total { get; set; }
        public string OPEN_FTE { get; set; }
        public string PendingApproval_Total { get; set; }
        public string PendingApproval_FTE { get; set; }
        public string PendingStart_Total { get; set; }
        public string PendingStart_FTE { get; set; }
        public string Working_Total { get; set; }
        public string Working_FTE { get; set; }
    }

    public class tbPlanDetailData
    {
        public IWebElement Delete;
        public string Shift { get; set; }
        public string SkillMix { get; set; }
        public string Type { get; set; }
        public string LastName	 { get; set; }
        public string FirstName	 { get; set; }
        public string PositionDescription { get; set; }
        public string HiredInDate { get; set; }
        public string Status { get; set; }
        public IWebElement IncludeInactive; 
        public string HiredInFTE { get; set; }
        public string Core { get; set; }
        public string Avg { get; set; }
        public string Peak { get; set; }
        public string ReqNumber { get; set; }
        public string Notes { get; set; }
        public string Headcount { get; set; }
        public string FTEs_HiredInDate { get; set; }
        public string FTEs_Core { get; set; }
        public string FTEs_Avg { get; set; }
        public string FTEs_Peak { get; set; }
        public string JobCode { get; set; }
    }

    public class PlanDetailsSubtotals
    {
        public decimal HeaderHeadcounts { get; set; }
        public decimal FooterHeadcounts { get; set; }
        public decimal HeaderHiredInFteSubtotal { get; set; }
        public decimal HeaderCoreSubtotal { get; set; }
        public decimal HeaderAvgSubtotal { get; set; }
        public decimal HeaderPeakSubtotal { get; set; }
        public decimal FooterHiredInFteSubtotal { get; set; }
        public decimal FooterCoreSubtotal { get; set; }
        public decimal FooterAvgSubtotal { get; set; }
        public decimal FooterPeakSubtotal { get; set; }
    }

    public class tbPlanDetailElements
    {
        public IWebElement Delete;
        public IWebElement Shift { get; set; }
        public IWebElement SkillMix { get; set; }
        public IWebElement Type { get; set; }
        public IWebElement LastName { get; set; }
        public IWebElement FirstName { get; set; }
        public IWebElement PositionDescription { get; set; }
        public IWebElement HiredInDate { get; set; }
        public IWebElement Status { get; set; }
        public IWebElement IncludeInactive;
        public IWebElement HiredInFTE { get; set; }
        public IWebElement Core { get; set; }
        public IWebElement Avg { get; set; }
        public IWebElement Peak { get; set; }
        public IWebElement ReqNumber { get; set; }
        public IWebElement Notes { get; set; }
        public IWebElement Headcount { get; set; }
        public IWebElement FTEs_HiredInDate { get; set; }
        public IWebElement FTEs_Core { get; set; }
        public IWebElement FTEs_Avg { get; set; }
        public IWebElement FTEs_Peak { get; set; }
    }

    public class tbContractLaborData
    {
        public string CandidateName { get; set; }
        public string Skill { get; set; }
        public string MatchStatus { get; set; }
        public string PositionType { get; set; }
        public string Vendor { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ShiftStart { get; set; }
        public string BillRate { get; set; }
        public string WeeksLeft { get; set; }
        public string Extension { get; set; }
        public string GuaranteedFTEs { get; set; }
        public string NextApprover { get; set; }
        public string PositionID { get; set; }
        public string MatchID { get; set; }
        public string RemainingPositions { get; set; }
        public string AvlOnCurrentMonth { get; set; }
        public string AvlOnNextMonth { get; set; }
        public string TotalWeeks { get; set; }
        public decimal FTEs { get; set; }
        public string ApprovalStatus { get; set; }
        public string AvlOnCurrentDate { get; set; }
        public string AvlOnFollowingMonthDate { get; set; }

    }

    public class clFpcComments
    {
        public string PlanID { get; set; }
        public string PlanStatus { get; set; }
        public string CommentType { get; set; }
        public string PlanDescription { get; set; }
        public string Department { get; set; }
        public IWebElement Comment { get; set; }
        public IWebElement Save;
    }
    
}
