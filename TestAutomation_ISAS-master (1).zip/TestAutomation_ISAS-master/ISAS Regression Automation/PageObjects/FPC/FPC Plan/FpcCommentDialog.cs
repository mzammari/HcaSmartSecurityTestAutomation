﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FpcCommentDialog
    {
        #region: Action

        public static clFpcComments SetFpcComment(string Comment)
        {
            CommonFunctions.AddTestStep("Verify user can add comment and save", "Comment is added and saved");
            bool bExist;
            By bySubmitDialog = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Plan ID')]/parent::td/following-sibling::td[1]/input");
            bExist = CommonFunctions.IsElementDisplayed(bySubmitDialog, 3);
            //submit dialog
            if (bExist)
            {
                clFpcComments clFpcComments = new clFpcComments()
                {
                    PlanID = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Plan ID')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                    PlanDescription = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Plan Description')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                    PlanStatus = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Plan Status')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                    Department = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Department')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                    CommentType = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Comment Type')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value")
                };
                IWebElement txtComment = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Comment')]/parent::td/following-sibling::td[1]/textarea"));
                CommonFunctions.ReplaceAndSetText(txtComment, Comment);
                By bySave = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Save']");
                By bySubmit = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-override-comment' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Submit']");
                bExist = CommonFunctions.IsElementDisplayed(bySubmit, 2);
                if (bExist)
                {
                    CommonFunctions.getElement(bySubmit).Click();
                }
                bExist = CommonFunctions.IsElementDisplayed(bySave, 2);
                if (bExist)
                {
                    CommonFunctions.getElement(bySave).Click();
                }
                return clFpcComments;
            }
            //Approve dialog
            else
            {
                By byPlan = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Plan ID')]/parent::td/following-sibling::td[1]/input");
                bExist = CommonFunctions.IsElementDisplayed(byPlan, 2);
                if (bExist)
                {
                    clFpcComments clFpcComments = new clFpcComments()
                    {
                        PlanID = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Plan ID')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        PlanDescription = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Plan Description')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        PlanStatus = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Plan Status')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        Department = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Department')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        CommentType = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Comment Type')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value")
                    };
                    IWebElement txtComment = CommonFunctions.getElement(By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//table//td//input[contains(@value,'Comment')]/parent::td/following-sibling::td[1]/textarea"));
                    CommonFunctions.ReplaceAndSetText(txtComment, Comment);
                    By bySave = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Save']");
                    By bySubmit = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-CommentsLoad' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Submit']");
                    bExist = CommonFunctions.IsElementDisplayed(bySubmit, 2);
                    if (bExist)
                    {
                        CommonFunctions.getElement(bySubmit).Click();
                    }
                    bExist = CommonFunctions.IsElementDisplayed(bySave, 2);
                    if (bExist)
                    {
                        CommonFunctions.getElement(bySave).Click();
                    }
                    return clFpcComments;
                }
                return null;
            }

        }
        #endregion
    }
}
