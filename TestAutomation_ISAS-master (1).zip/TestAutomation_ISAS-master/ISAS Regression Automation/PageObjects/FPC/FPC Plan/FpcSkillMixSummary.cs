﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FpcSkillMixSummary
    {
        public class StaffingGridSkillMixBreakdownPercentage
        {
            public string SkillMix { get; set; }
            public double Day { get; set; }
            public double Evening { get; set; }
            public double Night { get; set; }
            public double SumOfDayEveningNight { get; set; }
            public double TotalDay { get; set; }
            public double TotalEvening { get; set; }
            public double TotalNight { get; set; }
            public double Total { get; set; }
        }

        #region: Action
        public static void GoTo()
        {
            By bySkillMixtab = By.XPath("//*/a[@href='#skillMix']");
            CommonFunctions.ClickByJE(CommonFunctions.getElement(bySkillMixtab));
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click Skill Mix Summary", "Skill Mix Summary page is loaded");
        }

        public static bool IsAt
        {
            get
            {
                By byTable = By.XPath("//*/table[@id='fpcSkillMixDetails']/tbody/tr");
                CommonFunctions.AddTestStep("Verify the Skill Mix Summary page", "Skill Mix Summary page is loaded");
                return CommonFunctions.IsElementDisplayed(byTable, 20);
            }
        }
        #endregion

        public static List<StaffingGridSkillMixBreakdownPercentage> getSkillMixDataBreakdown()
        {
            CommonFunctions.AddTestStep("Get skill mix breakdown data", "Data is retrieved");
            List<StaffingGridSkillMixBreakdownPercentage> lstskillMixbreakdown = new List<StaffingGridSkillMixBreakdownPercentage>();
            By byTable = By.XPath("//*/table[@id='fpcSkillMixDetails']/tbody/tr");
            By bySkillMix = By.XPath("td/input[@id='skillMixDisplay']");
            By byDay = By.XPath("td/input[@id='brkDownPercDay']");
            By byEvening = By.XPath("td/input[@id='brkDownPercEvening']");
            By byNight = By.XPath("td/input[@id='brkDownPercNight']");
            By bySumOfDayEveningNight = By.XPath("td/input[@id='brkDownPercTotal']");

            var lstSkillMix = CommonFunctions.getElements(byTable);
            foreach(var skillMix in lstSkillMix)
            {
                lstskillMixbreakdown.Add(new StaffingGridSkillMixBreakdownPercentage()
                {
                    SkillMix = skillMix.FindElement(bySkillMix).GetAttribute("value"),
                    Day = ConvertData(skillMix.FindElement(byDay).GetAttribute("value")),
                    Evening = ConvertData(skillMix.FindElement(byEvening).GetAttribute("value")),
                    Night = ConvertData(skillMix.FindElement(byNight).GetAttribute("value")),
                    SumOfDayEveningNight = ConvertData(skillMix.FindElement(bySumOfDayEveningNight).GetAttribute("value"))
                });

            }
            return lstskillMixbreakdown;
        }

        private static double ConvertData(string data)
        {
            if(!string.IsNullOrEmpty(data))
            {
                return Convert.ToDouble(data.Replace('%', ' '));
            }
            return 0;
        }

        public static bool VerifyTotalSkillMixBreakdown()
        {
            var listSkillMix =  getSkillMixDataBreakdown();
            CommonFunctions.AddTestStep("Verify the total value == sum of day, evening, and night values", "Values match correctly");

            foreach (var skillMix in listSkillMix)
            {
                double total = 0;
                total = skillMix.Day + skillMix.Evening + skillMix.Night;
                if (total != skillMix.SumOfDayEveningNight) 
                {
                    CommonFunctions.AddTestStep($"{skillMix.SkillMix} total didn't match", $"{total} does not equal {skillMix.SumOfDayEveningNight}");
                    return false;
                }

            }
            return true;
        }
    }
}
