﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    using IBM.Data.Db2;
    using System.Collections.Generic;

    public class CoDept
    {
        public string CoId { get; set; }
        public string DeptNum { get; set; }
    }

    public class Db2DataService
    {
                
        public static List<CoDept> GetFacilityAndDeptList()
        {
            var results = new List<CoDept>();

           var _connectionString = "Server=dsnt.es.medcity.net:446;" +
                                "Database=DSNT;" +
                                $"UserID={RunData.UserName};" +
                                $"Password={RunData.Password};";

            using (var connection = new DB2Connection(_connectionString))
            {
                connection.Open();

                string query = "select * from H.LPBWTN where  Position_TYpe like '%International%' and Match_Status like '%Working%'  order by Co_ID, dept_Num;";

                using (var command = new DB2Command(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        results.Add(new CoDept
                        {
                            CoId = reader["CO_ID"].ToString(),
                            DeptNum = reader["DEPT_NUM"].ToString()
                        });
                    }
                }
            }

            return results;
        }
    }
}
