﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FpcContractLabor
    {
        public static void GoTo()
        {
            By byTbContractLabor = By.XPath("//a[normalize-space()='Contract Labor']");
            CommonFunctions.ClickByJE(CommonFunctions.getElement(byTbContractLabor));
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click on the Contract Labor tab ", "The tab is enabled");
        }

        public static bool IsAt
        {
            get
            {
                By byContractLaborTable = By.XPath("//*/table[@id='contractLaborDetails']//tbody/tr");
                CommonFunctions.AddTestStep("Verify plan page is active", "The plan page loaded correctly. ");
                return CommonFunctions.IsElementDisplayed(byContractLaborTable, 20);
            }
        }
        public class tblContractLabor
        {
            public string CandidateName { get; set; }
            public string Skill { get; set; }
            public string MatchStatus { get; set; }
            public string PositionType { get; set; }
            public string Vendor { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }
            public string ShiftStart { get; set; }
            public string BillRate { get; set; }
            public string WeeksLeft { get; set; }
            public string Extension { get; set; }
            public string GuaranteedFTEs { get; set; }
            public string NextApprover { get; set; }
            public string PositionID { get; set; }
            public string MatchID { get; set; }
            public string RemainingPositions { get; set; }
            public string PositionTypeBackgroundColor { get; set; }
        }

        public static List<tblContractLabor> GetContractLaborData()
        {
            try
            {
                CommonFunctions.AddTestStep("Get Contract Labor data ", "Contract Labor Data are captured");
                List<tblContractLabor> lstContractLaborData = new List<tblContractLabor>();
                By byContractLaborTable = By.XPath("//*/table[@id='contractLaborDetails']//tbody/tr[@style='display: table-row;']");
                var lstRows = CommonFunctions.getElements(byContractLaborTable);
                foreach (var row in lstRows)
                {
                    lstContractLaborData.Add(new tblContractLabor()
                    {
                        CandidateName = row.FindElement(By.XPath("td[1]")).GetAttribute("value"),
                        Skill = row.FindElement(By.XPath("td[2]")).GetAttribute("value"),
                        MatchStatus = row.FindElement(By.XPath("td[3]")).GetAttribute("value"),
                        PositionType = row.FindElement(By.XPath("td[4]")).GetAttribute("value"),
                        Vendor = row.FindElement(By.XPath("td[5]")).GetAttribute("value"),
                        StartDate = row.FindElement(By.XPath("td[6]")).GetAttribute("value"),
                        EndDate = row.FindElement(By.XPath("td[7]")).GetAttribute("value"),
                        ShiftStart = row.FindElement(By.XPath("td[8]")).GetAttribute("value"),
                        BillRate = row.FindElement(By.XPath("td[9]")).GetAttribute("value"),
                        WeeksLeft = row.FindElement(By.XPath("td[10]")).GetAttribute("value"),
                        Extension = row.FindElement(By.XPath("td[11]")).GetAttribute("value"),
                        GuaranteedFTEs = row.FindElement(By.XPath("td[12]")).GetAttribute("value"),
                        NextApprover = row.FindElement(By.XPath("td[13]")).GetAttribute("value"),
                        PositionID = row.FindElement(By.XPath("td[14]")).GetAttribute("value"),
                        MatchID = row.FindElement(By.XPath("td[15]")).GetAttribute("value"),
                        RemainingPositions = row.FindElement(By.XPath("td[16]")).GetAttribute("value"),
                        PositionTypeBackgroundColor = row.FindElement(By.XPath("td[4]")).GetCssValue("background-color")
                    });
                }
                return lstContractLaborData;
            }
            catch
            {
                return null;
            }
        }
    }
}
