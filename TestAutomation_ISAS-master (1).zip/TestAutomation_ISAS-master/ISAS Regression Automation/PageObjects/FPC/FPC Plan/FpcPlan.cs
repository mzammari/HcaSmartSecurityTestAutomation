﻿using AutomationCoreLite.Reporting;
using DocumentFormat.OpenXml.Drawing;
using MongoDB.Driver.Core.Operations;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Xml.XPath;
using static ISAS_Regression_Automation.FacilityLaborExpenseSummary;

namespace ISAS_Regression_Automation
{
    public class FpcPlan
    {
        
        #region: Action

        #region: Plan Summary
        public class PlanSummary
        {
            public string PlanID { get; set; }
            public string DeptSubfunction { get; set; }
            public string DeptType { get; set; }
            public string UpdatedBy { get; set; }
            public string CoreBusinessRule { get; set; }
            public string PlanDescription { get; set; }
            public string StaffingGridDetails { get; set; }
            public string StatDesc { get; set; }
            public string UpdatedOn { get; set; }
            public string PeakBusinessRule { get; set; }
            public string LastUpdate {  get; set; }
        }

        public static PlanSummary GetPlanViewSummary()
        {
            expandPlanSummaryPanel();
            CommonFunctions.AddTestStep("Get Plan Summary data", "Plan Summary data");
            return new PlanSummary()
            {
                PlanID = CommonFunctions.getElement(By.XPath("//input[@id='planId']")).GetAttribute("value"),
                DeptSubfunction = CommonFunctions.getElement(By.XPath("//input[@id='deptSubFunc']")).GetAttribute("value"),
                DeptType = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table//tr[3]/td[2]/input")).GetAttribute("value"),
                UpdatedBy = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table//tr[4]/td[2]/input")).GetAttribute("value"),
                CoreBusinessRule = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table//tr[5]/td[2]/input")).GetAttribute("value"),
                PlanDescription = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table//tr[1]/td[4]/input")).GetAttribute("value"),
                StaffingGridDetails = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table//tr[2]/td[4]/input")).GetAttribute("value"),
                StatDesc = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table//tr[3]/td[4]/input")).GetAttribute("value"),
                UpdatedOn = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table//tr[4]/td[4]/input")).GetAttribute("value"),
                PeakBusinessRule = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table//tr[5]/td[4]/input")).GetAttribute("value"),
                LastUpdate = CommonFunctions.getElement(By.XPath("//div[@id='lastupdate']")).Text
            };
        }

        public static void expandPlanSummaryPanel()
        {
            By btnPlanSummary = By.XPath("//h3[@role='tab']//a[contains(text(),'Plan Summary')]");
            By tblPlanSummary = By.XPath("//*/div[@id=\"planSummary\"]//div[contains(@style,'display: block;')]//table//td/input[contains(@value,'Plan ID')]");            
            CommonFunctions.VerifyDialogVisible(btnPlanSummary, tblPlanSummary);
        }

        public static string GetFpcNoteText()
        {
            By byNoteTextarea = By.XPath("//textarea[@id='txt_note']");
            return CommonFunctions.GetTextareaText(byNoteTextarea);
        }

        public static string AppendTextToFpcNote()
        {
            bool bDisplayed;
            List<string> NoteTextAndLastUpdateData = new List<string>();
            By byNoteTextarea = By.XPath("//textarea[@id='txt_note']");
            By byNoteSaveButton = By.XPath("//button[@id='savenoteFpcBtn']");
            By ConfirmXpath = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-save-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']");
            By byLastUpdate = By.XPath("//div[@id='lastupdate']");
            CommonFunctions.WaitUntilPageIsAcive();
            string noteText = $"This is a testing note - {CommonFunctions.getRandomNumber().ToString()}.";
            bDisplayed = CommonFunctions.IsElementDisplayed(byNoteTextarea, 1);
            if (bDisplayed)
            {
                var FpcNote = CommonFunctions.getElement(byNoteTextarea);
                CommonFunctions.AppendText(FpcNote, noteText);
                CommonFunctions.ClickByJE(CommonFunctions.getElement(byNoteSaveButton));
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(ConfirmXpath);
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }
            }
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.WaitSaveToastMsgDisappeared();
            return CommonFunctions.getElement(byNoteTextarea).Text;
        }

        public static List<string> AddFpcNotes()
        {
            bool bDisplayed;
            List<string> NoteTextAndLastUpdateData = new List<string>();
            By byNoteTextarea = By.XPath("//textarea[@id='txt_note']");
            By byNoteSaveButton = By.XPath("//button[@id='savenoteFpcBtn']");
            By ConfirmXpath = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-save-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']");
            By byLastUpdate = By.XPath("//div[@id='lastupdate']");
            CommonFunctions.WaitUntilPageIsAcive();
            string noteText = $"This is a testing note - {CommonFunctions.getRandomNumber().ToString()}.";
            bDisplayed = CommonFunctions.IsElementDisplayed(byNoteTextarea, 1);
            if (bDisplayed)
            {
                var FpcNote = CommonFunctions.getElement(byNoteTextarea);
                CommonFunctions.SetText(FpcNote, noteText);
                CommonFunctions.ClickByJE(CommonFunctions.getElement(byNoteSaveButton));
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(ConfirmXpath);
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.WaitSaveToastMsgDisappeared();
                }
            }
            var lastUpdate = CommonFunctions.getElement(byLastUpdate).Text;
            NoteTextAndLastUpdateData.Add(noteText);
            NoteTextAndLastUpdateData.Add(lastUpdate);
            return NoteTextAndLastUpdateData;

        }

        public static List<string> getFpcNoteText()
        {
            By byNoteTextarea = By.XPath("//textarea[@id='txt_note']");
            By byBastUpdate = By.XPath("//div[@id='lastupdate']");
            List<string> NoteTextAndLastUpdateData = new List<string>();

            var FpcNote = CommonFunctions.getElement(byNoteTextarea).Text;
            var lastUpdate = CommonFunctions.getElement(byBastUpdate).Text;
            NoteTextAndLastUpdateData.Add(FpcNote);
            NoteTextAndLastUpdateData.Add(lastUpdate);
            return NoteTextAndLastUpdateData;

        }
        #endregion

        #region: FTEs Summary
        public class FTEsSummary
        {
            public class clFTEsSummary
            {
                public string TotalTargetProductiveFTEsCore { get; set; }
                public string TotalTargetProductiveFTEsAverage { get; set; }
                public string TotalTargetProductiveFTEsPeak { get; set; }
                public string TotalTargetPaidFTEsCore { get; set; }
                public string TotalTargetPaidFTEsAverage { get; set; }
                public string TotalTargetPaidFTEsPeak { get; set; }
                public string AverageDailyVolumeCore { get; set; }
                public string AverageDailyVolumeAverage { get; set; }
                public string AverageDailyVolumePeak { get; set; }
                public string TargetMonth { get; set; }

            }

            public static clFTEsSummary GetFTEsSummary()
            {
                CommonFunctions.AddTestStep("Verify user can retrieve FTEs summary data", "Data is retrieved");
                return new clFTEsSummary()
                {
                    TotalTargetProductiveFTEsCore = CommonFunctions.getElement(By.XPath("//*/input[@id='tgtCoreProductiveFtes']")).GetAttribute("value"),
                    TotalTargetProductiveFTEsAverage = CommonFunctions.getElement(By.XPath("//*/input[@id='tgtAverageProductiveFtes']")).GetAttribute("value"),
                    TotalTargetProductiveFTEsPeak = CommonFunctions.getElement(By.XPath("//*/input[@id='tgtPeakProductiveFtes']")).GetAttribute("value"),
                    TotalTargetPaidFTEsCore = CommonFunctions.getElement(By.XPath("//*/input[@id='tgtCorePaidFtes']")).GetAttribute("value"),
                    TotalTargetPaidFTEsAverage = CommonFunctions.getElement(By.XPath("//*/input[@id='tgtAveragePaidFtes']")).GetAttribute("value"),
                    TotalTargetPaidFTEsPeak = CommonFunctions.getElement(By.XPath("//*/input[@id='tgtPeakPaidFtes']")).GetAttribute("value"),
                    AverageDailyVolumeCore = CommonFunctions.getElement(By.XPath("//*/input[@id='coreAvgDailyVolume']")).GetAttribute("value"),
                    AverageDailyVolumeAverage = CommonFunctions.getElement(By.XPath("//*/input[@id='averageDailyVolume']")).GetAttribute("value"),
                    AverageDailyVolumePeak = CommonFunctions.getElement(By.XPath("//*/input[@id='peakAvgDailyVolume']")).GetAttribute("value"),
                    TargetMonth = CommonFunctions.getElement(By.XPath("//*/select[@class='setTargetMonthId']")).Text
                };
            }

            public static void SetTargetMonth(string date)
            {
                CommonFunctions.AddTestStep("Verify user can set target month date", $"Target month date {date} is set ");
                IWebElement mnuTargetMonth = CommonFunctions.getElement(By.XPath("//*/select[@class='setTargetMonthId']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuTargetMonth, date);
                FpcPlanMenu.Save();
            }

        }
        #endregion

        #region: Override Min FTEs and Hours/UOS
        public class OverrideMinFTEsAndHoursUOS
        {
            public string ProductiveMinFTEsTarget { get; set; }
            public string ProductiveMinFTEsOverride { get; set; }
            public string ProductiveHoursUOSTarget { get; set; }
            public string ProductiveHoursUOSOverride { get; set; }
        }

        public static OverrideMinFTEsAndHoursUOS getOverrideMinFTEsAndHoursUOS()
        {
            CommonFunctions.AddTestStep("Verify user can get Override Min FTEs And Hours UOS data", "Override Min FTEs And Hours UOS data was retrieved.");
            return new OverrideMinFTEsAndHoursUOS()
            {
                ProductiveMinFTEsTarget = CommonFunctions.getElement(By.XPath("//*/input[@id='tgtMinFtes']")).GetAttribute("value"),
                ProductiveMinFTEsOverride = CommonFunctions.getElement(By.XPath("//*/input[@id='overrideMinFtes']")).GetAttribute("value"),
                ProductiveHoursUOSTarget = CommonFunctions.getElement(By.XPath("//*/input[@id='tgtproductHoursPerUos']")).GetAttribute("value"),
                ProductiveHoursUOSOverride = CommonFunctions.getElement(By.XPath("//*/input[@id='overrideHoursPerUos']")).GetAttribute("value")
            };
        }
        #endregion
        
        #region: Semi-Variable Steps
        public class SemiVariableSteps
        {
            public string Step { get; set; }
            public string DailyVolumeRange { get; set; }
            public string MonthlyTargetProductiveFtes { get; set; }
            public string OverrideMonthlyTargetProductiveFtes { get; set; }
            public IWebElement Core;
            public IWebElement Average;
            public IWebElement Peak;
        }

        public static List<SemiVariableSteps> getSemiVariableSteps()
        {
            CommonFunctions.AddTestStep("Verify user can get Semi-Variable Steps ", "Semi-Variable Steps data was retrieved");
            List<SemiVariableSteps> semiVariableSteps = new List<SemiVariableSteps>();
            IList<IWebElement> lstSemiVarSteps = CommonFunctions.getElements(By.XPath("//*/div[@id='semiVariableStepsSummary']//table/tbody//tr"));
            foreach (IWebElement row in lstSemiVarSteps)
            {
                semiVariableSteps.Add( new SemiVariableSteps()
                {
                    Step = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                    DailyVolumeRange = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                    MonthlyTargetProductiveFtes = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                    OverrideMonthlyTargetProductiveFtes = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                    Core = row.FindElement(By.XPath("td[5]/input")),
                    Average = row.FindElement(By.XPath("td[6]/input")),
                    Peak = row.FindElement(By.XPath("td[7]/input"))
                });
            }
            return semiVariableSteps;
        }

        public static bool IsStepSelectedNotAllowed()
        {
            bool isDisplayed;
            By byOk = By.XPath("//*/div[contains(@style,'display: block;') and @aria-labelledby='ui-dialog-title-step-selection-rule']//div[@class='ui-dialog-buttonset']//button/span[normalize-space()='OK']");
            isDisplayed = CommonFunctions.IsElementDisplayed(byOk, 5);
            if (isDisplayed)
            {
                CommonFunctions.AddTestStep("Verify an error msg is displayed", "Average checkbox selected must be for a Step that is greater than or equal to the Core Step's selected checkbox");
                IWebElement cmdOK = CommonFunctions.getElement(byOk);
                CommonFunctions.ClickByJE(cmdOK);
                CommonFunctions.WaitUntilPageIsAcive();
               
                return true;
            }
            return false;
        }

        #endregion

        #region: Volume
        public class Volume
        {
            public class Bud
            {
                public static MonthlyForcastView getBudData()
                {
                   string xpath = "//*/div[@id='volume-budget']";
                   CommonFunctions.AddTestStep("Get Bud data", "return data");
                   return CommonFunctions.getMonthlyData(xpath, 0);
                }
            }

            public class Act
            {
                public static MonthlyForcastView getPriorActData()
                {
                    string xpath = "//*/div[@id='volume-hist']";
                    CommonFunctions.AddTestStep("Get Act data", "return data");
                    return CommonFunctions.getMonthlyData(xpath, 0);
                }
            }

            public class OverrideVolume
            {
                public static MonthlyForcastView getOverrideData()
                {
                    string xpath = "//*/div[@id='volume-override']";
                    CommonFunctions.AddTestStep("Get volume override data", "return data");
                    return CommonFunctions.getMonthlyData(xpath, 0);
                }

            }

            public class UsedVolume
            {
                public static MonthlyForcastView getUsedVolumeData()
                {
                    CommonFunctions.AddTestStep("Get Used Volume Data ", "Used Volume Data");
                    return CommonFunctions.getMonthlyData("//*/div[@id='volume-used']", 2);                                     
                }
            }

            public class AvgDailyVolume
            {
                public static MonthlyForcastView getAvgDailyVolumeData()
                {
                    CommonFunctions.AddTestStep("Get Avg Daily Volume Data ", "Avg Daily Volume Data");
                    return CommonFunctions.getMonthlyData("//*/div[@id='avg-daily-volume']", 2);                                  
                }


                public static MonthlyForcastView getBusinessCalendarDaysData()
                {
                    CommonFunctions.AddTestStep("Get Business/Calendar Days for each month", "The month's days are retrieved");
                    return new MonthlyForcastView()
                    {
                        Jan = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[1]"))),
                        Feb = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[2]"))),
                        Mar = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[3]"))),
                        Apr = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[4]"))),
                        May = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[5]"))),
                        Jun = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[6]"))),
                        Jul = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[7]"))),
                        Aug = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[8]"))),
                        Sep = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[9]"))),
                        Oct = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[10]"))),
                        Nov = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[11]"))),
                        Dec = getDaysValue(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'avgDailyVolume')])[12]")))
                    };
                }

                private static double getDaysValue(IWebElement element)
                {
                    var value = element.GetAttribute("title");
                    var arr = value.Split('(');
                    var arr1 = arr[1].Split(')');
                    return CommonFunctions.ToDouble(arr1[0]);
                }
            }

            public class CurrentActualVolume
            {
                public static MonthlyForcastView getCurrentActualVolumeData()
                {
                    return new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'currentActualVolume')])[12]")).GetAttribute("value"))
                    };
                }
            }
        }
        #endregion

        #region: Non-Productive Percentage
        public class NonProductivePercentage
        {
            public class Target
            {
                public static MonthlyForcastView getTragetData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'tgtNpPercent')])[12]")).GetAttribute("value"))
                    };
                    return data;
                }
            }

            public class Act //Historical
            {
                public static MonthlyForcastView getActData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'hisNpPercent')])[12]")).GetAttribute("value"))
                    };
                    return data;
                }
            }

            public class Override 
            {
                public static MonthlyForcastView getOverrideData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'overrideNpPercent')])[12]")).GetAttribute("value"))
                    };
                    return data;
                }
            }

            public class Used
            {
                public static MonthlyForcastView getUsedData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//input[contains(@id,'usedNpPercent')])[12]")).GetAttribute("value"))
                    };
                    return data;
                }
            }

            public class CurrAct
            {
                public static MonthlyForcastView getCurrActData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='nppercent-historical']/input)[12]")).GetAttribute("value"))
                    };
                    return data;
                }
            }
        }
        #endregion

        #region: OT & CL FTEs (Informative Use Only)
        public class OtAndCFtes
        {
            public class TgtOT
            {
                public static MonthlyForcastView getTgtOTData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-Tgt']/input)[12]")).GetAttribute("value"))
                    };
                    return data;
                }

            }

            public class ActOT
            {
                public static MonthlyForcastView getActOTData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='ot-hist']/input)[12]")).GetAttribute("value"))
                    };
                    return data;
                }

            }

            public class TgtCL
            {
                public static MonthlyForcastView getTgtCLData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-tgt']/input)[12]")).GetAttribute("value"))
                    };
                    return data;
                }

            }

            public class ActCL
            {
                public static MonthlyForcastView getActCLData()
                {
                    var data = new MonthlyForcastView()
                    {
                        Jan = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[1]")).GetAttribute("value")),
                        Feb = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[2]")).GetAttribute("value")),
                        Mar = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[3]")).GetAttribute("value")),
                        Apr = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[4]")).GetAttribute("value")),
                        May = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[5]")).GetAttribute("value")),
                        Jun = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[6]")).GetAttribute("value")),
                        Jul = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[7]")).GetAttribute("value")),
                        Aug = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[8]")).GetAttribute("value")),
                        Sep = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[9]")).GetAttribute("value")),
                        Oct = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[10]")).GetAttribute("value")),
                        Nov = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[11]")).GetAttribute("value")),
                        Dec = CommonFunctions.ToDouble(CommonFunctions.getElement(By.XPath("(//*/div[@id='cl-hist']/input)[12]")).GetAttribute("value"))
                    };
                    return data;
                }

            }
        }
        #endregion

        #region: View Plan Detail
        public class PlanDetail
        {
            public class PlanDetailSummary
            {
                public static ViewPlanDetailSummary getViewPlanDetailSummary()
                {
                    return new ViewPlanDetailSummary()
                    {
                        PlanID = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Plan ID')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        DeptSubfunction = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Dept Subfunction')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        DeptType = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Dept Type')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        UpdatedBy = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Updated By')]/parent::td/following-sibling::td[1]/textarea")).Text,
                        SubmittedBy = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Submitted By')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        ApprovalsReceived = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Approvals Received')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        PlanDescription = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Plan Description')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        StaffingGridDetail = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Staffing Grid Detail')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        StatDesc = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Stat Desc')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        UpdatedOn = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Updated On')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        SubmittedOn = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'Submitted On')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value"),
                        HRRefreshedOn = CommonFunctions.getElement(By.XPath("//*/div[@id='planSummary']//table/tbody//tr/td/input[contains(@value,'HR Refreshed On')]/parent::td/following-sibling::td[1]/input")).GetAttribute("value")

                    };
                }
            }

            public class PlanDetailFteSummary
            {
                public static PlanDetailFteSummaryClass getPlanDetailFteSummary()
                {
                    return new PlanDetailFteSummaryClass()
                    {
                        TotalTargetPaidFTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='totTgtCorePaidFtes']")).GetAttribute("value"),
                        TotalTargetPaidFTEs_Average = CommonFunctions.getElement(By.XPath("//input[@id='totTgtAvgPaidFtes']")).GetAttribute("value"),
                        TotalTargetPaidFTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='totTgtPeakPaidFtes']")).GetAttribute("value"),
                        TotalDepartmentPaidFTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='totalDeptPaidFtesCore']")).GetAttribute("value"),
                        TotalDepartmentPaidFTEs_Average = CommonFunctions.getElement(By.XPath("//input[@id='totalDeptPaidFtesAverage']")).GetAttribute("value"),
                        TotalDepartmentPaidFTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='totalDeptPaidFtesPeak']")).GetAttribute("value"),
                        Variance_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesVariance']")).GetAttribute("value"),
                        Variance_Average = CommonFunctions.getElement(By.XPath("//input[@id='averageFtesVariance']")).GetAttribute("value"),
                        Variance_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesVariance']")).GetAttribute("value"),
                        AverageDailyVolume_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreAvgDailyVolume']")).GetAttribute("value"),
                        AverageDailyVolume_Average = CommonFunctions.getElement(By.XPath("//input[@id='averageDailyVolume']")).GetAttribute("value"),
                        AverageDailyVolume_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakAvgDailyVolume']")).GetAttribute("value"),
                        HiredInFTE = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotalColumn']")).GetAttribute("value"),
                        AllowableFteVariance = CommonFunctions.getElement(By.XPath("//input[@id='variance']")).GetAttribute("value"),
                        OPEN_Total = CommonFunctions.getElement(By.XPath("//*/div[@id='ftesDiv']//table/tbody//tr//td[contains(text(),'Open')]/parent::tr/td[2]")).Text,
                        OPEN_FTE = CommonFunctions.getElement(By.XPath("//*/div[@id='ftesDiv']//table/tbody//tr//td[contains(text(),'Open')]/parent::tr/td[3]")).Text,
                        PendingApproval_Total = CommonFunctions.getElement(By.XPath("//*/div[@id='ftesDiv']//table/tbody//tr//td[contains(text(),'Pending Approval')]/parent::tr/td[2]")).Text,
                        PendingApproval_FTE = CommonFunctions.getElement(By.XPath("//*/div[@id='ftesDiv']//table/tbody//tr//td[contains(text(),'Pending Approval')]/parent::tr/td[3]")).Text,
                        PendingStart_Total = CommonFunctions.getElement(By.XPath("//*/div[@id='ftesDiv']//table/tbody//tr//td[contains(text(),'Pending Start')]/parent::tr/td[2]")).Text,
                        PendingStart_FTE = CommonFunctions.getElement(By.XPath("//*/div[@id='ftesDiv']//table/tbody//tr//td[contains(text(),'Pending Start')]/parent::tr/td[3]")).Text,
                        Working_Total = CommonFunctions.getElement(By.XPath("//*/div[@id='ftesDiv']//table/tbody//tr//td[contains(text(),'Working')]/parent::tr/td[2]")).Text,
                        Working_FTE = CommonFunctions.getElement(By.XPath("//*/div[@id='ftesDiv']//table/tbody//tr//td[contains(text(),'Working')]/parent::tr/td[3]")).Text
                    };
                }
            }

            public class PlanDetailTab
            {
               

                public class PlanDetailFTESummaryDepartment
                {
                    public decimal TotalTargetPaidFTEs_Core { get; set; }
                    public decimal TotalTargetPaidFTEs_Average { get; set; }
                    public decimal TotalTargetPaidFTEs_Peak { get; set; }
                    public decimal TotalTargetPaidFTEs_Variance { get; set; }
                    public string TotalTargetPaidFTEs_CoreToPeakVariance { get; set; }

                    public decimal TotalDepartmentPaidFTEs_Core { get; set; }
                    public decimal TotalDepartmentPaidFTEs_Average { get; set; }
                    public decimal TotalDepartmentPaidFTEs_Peak { get; set; }
                    public decimal TotalDepartmentPaidFTEs_Variance { get; set; }
                    public string TotalDepartmentPaidFTEs_CoreToPeakVariance { get; set; }

                    public string Variance_Core { get; set; }
                    public string Variance_Average { get; set; }
                    public string Variance_Peak { get; set; }

                    public decimal CalendarDayAverageVolume_Core { get; set; }
                    public decimal CalendarDayAverageVolume_Average { get; set; }
                    public decimal CalendarDayAverageVolume_Peak { get; set; }
                    public string CalendarDayAverageVolume_CoreToPeakVariance { get; set; }

                    public decimal ContractLabor_PendingStart_FTE { get; set; }
                    public decimal ContractLabor_PendingStart_Total { get; set; }
                    public decimal ContractLabor_Working_FTE { get; set; }
                    public decimal ContractLabor_Working_Total { get; set; }
                    public decimal ContractLabor_Open_FTE { get; set; }
                    public decimal ContractLabor_Open_Total { get; set; }
                    public decimal ContractLabor_PendingApproval_FTE { get; set; }
                    public decimal ContractLabor_PendingApproval_Total { get; set; }
                    public decimal ContractLabor_Embedded_FTE { get; set; }
                    public decimal ContractLabor_Embedded_Total { get; set; }
                    public decimal ContractLabor_TotalWorking_FTE { get; set; }
                    public decimal ContractLabor_TotalWorking_Total { get; set; }
                }

                // Function to extract data from the second table format (Department FTEs)
                public static PlanDetailFTESummaryDepartment GetPlanDetailFTESummaryDepartment()
                {
                    var summary = new PlanDetailFTESummaryDepartment();
                    

                    try
                    {
                        By byPlanDetailSummary = By.XPath("//input[@id='totTgtCorePaidFtes']");
                        CommonFunctions.IsElementDisplayed(byPlanDetailSummary, 5);

                        // Extract Total Target Paid FTEs
                        summary.TotalTargetPaidFTEs_Core = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='totTgtCorePaidFtes']")));
                        summary.TotalTargetPaidFTEs_Average = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='totTgtAvgPaidFtes']")));
                        summary.TotalTargetPaidFTEs_Peak = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='totTgtPeakPaidFtes']")));
                        summary.TotalTargetPaidFTEs_Variance = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='totTgtPaidFteVar']")));
                        summary.TotalTargetPaidFTEs_CoreToPeakVariance = CommonFunctions.getElement(By.XPath("//input[@id='totTgtCoreToPeakVar']")).GetAttribute("value");

                        // Extract Total Department Paid FTEs
                        summary.TotalDepartmentPaidFTEs_Core = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='totalDeptPaidFtesCore']")));
                        summary.TotalDepartmentPaidFTEs_Average = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='totalDeptPaidFtesAverage']")));
                        summary.TotalDepartmentPaidFTEs_Peak = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='totalDeptPaidFtesPeak']")));
                        summary.TotalDepartmentPaidFTEs_Variance = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='tgtDeptPaidFteVar']")));
                        summary.TotalDepartmentPaidFTEs_CoreToPeakVariance =  CommonFunctions.getElement(By.XPath("//input[@id='tgtDeptPaidCoreToPeakVar']")).GetAttribute("value");

                        // Extract Variance
                        summary.Variance_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesVariance']")).GetAttribute("value"); 
                        summary.Variance_Average = CommonFunctions.getElement(By.XPath("//input[@id='averageFtesVariance']")).GetAttribute("value"); 
                        summary.Variance_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesVariance']")).GetAttribute("value"); 

                        // Extract Calendar Day Average Volume
                        summary.CalendarDayAverageVolume_Core = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='coreAvgDailyVolume']")));
                        summary.CalendarDayAverageVolume_Average = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='averageDailyVolume']")));
                        summary.CalendarDayAverageVolume_Peak = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(By.XPath("//input[@id='peakAvgDailyVolume']")));
                        summary.CalendarDayAverageVolume_CoreToPeakVariance = CommonFunctions.getElement(By.XPath("//input[@id='avgDailyVolVar']")).GetAttribute("value");

                        // Extract Contract Labor data
                        summary.ContractLabor_Open_FTE = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[1]/td[3]")).Text);
                        summary.ContractLabor_Open_Total = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[1]/td[2]")).Text);
                        summary.ContractLabor_PendingApproval_FTE = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[2]/td[3]")).Text);
                        summary.ContractLabor_PendingApproval_Total = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[2]/td[2]")).Text);
                        summary.ContractLabor_PendingStart_FTE = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[3]/td[3]")).Text);
                        summary.ContractLabor_PendingStart_Total = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[3]/td[2]")).Text);
                        summary.ContractLabor_Embedded_FTE = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[4]/td[3]")).Text);
                        summary.ContractLabor_Embedded_Total = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[4]/td[2]")).Text);
                        summary.ContractLabor_Working_FTE = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[5]/td[3]")).Text);
                        summary.ContractLabor_Working_Total = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[5]/td[2]")).Text);
                        summary.ContractLabor_TotalWorking_FTE = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[6]/td[3]")).Text);
                        summary.ContractLabor_TotalWorking_Total = Convert.ToDecimal(CommonFunctions.getElement(By.XPath("(//*/div[@id=\"ftesDiv\"]//tbody//tr[@class=\"odd-emp-row\"])[6]/td[2]")).Text);
                    }
                    catch (Exception ex)
                    {
                        throw new Exception($"Error extracting Department FTE data: {ex.Message}", ex);
                    }

                    return summary;
                }

                public static void GoTo()
                {
                    IWebElement tbPlanDetail = CommonFunctions.getElement(By.XPath("//a[normalize-space()='Plan Detail']"));
                    CommonFunctions.ClickByJE(tbPlanDetail);
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.AddTestStep("Go to the detail tab", "The detail plan page is displayed.");
                }

                public static bool IsAt
                {
                    get
                    {
                        string xpath = "//a[@id='addEmployeeBtn']";
                        return CommonFunctions.IsElementDisplayed(xpath, 10);
                    }
                }

                public static List<tbPlanDetailData> GetPlanDetailTabData()
                {
                    CommonFunctions.AddTestStep("Get the plan detail tab Data", "The data is retrieved.");
                    List<tbPlanDetailData> lstPlanDetailTab = new List<tbPlanDetailData>();
                    IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[@style='display: table-row;']"));
                    foreach (var row in lstRows)
                    {
                        try
                        {
                            var bDisplayed = row.FindElement(By.XPath("td[@class='un col-delete']/a")).Displayed;
                            if (bDisplayed)
                            {
                                lstPlanDetailTab.Add(new tbPlanDetailData()
                                {
                                    Delete = row.FindElement(By.XPath("td[16]/a")),
                                    Shift = row.FindElement(By.XPath("td[1]/select")).Text,
                                    SkillMix = row.FindElement(By.XPath("td[2]/select")).Text,
                                    Type = row.FindElement(By.XPath("td[3]/select")).Text,
                                    LastName = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                                    FirstName = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                                    PositionDescription = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                                    HiredInDate = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
                                    Status = row.FindElement(By.XPath("td[8]/select")).Text,
                                    IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                    HiredInFTE = row.FindElement(By.XPath("td[10]/input")).GetAttribute("value"),
                                    Core = row.FindElement(By.XPath("td[11]/input")).GetAttribute("value"),
                                    Avg = row.FindElement(By.XPath("td[12]/input")).GetAttribute("value"),
                                    Peak = row.FindElement(By.XPath("td[13]/input")).GetAttribute("value"),
                                    ReqNumber = row.FindElement(By.XPath("td[14]/input")).GetAttribute("value"),
                                    Notes = row.FindElement(By.XPath("td[15]/input")).GetAttribute("value"),
                                    FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")).GetAttribute("value"),
                                    FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")).GetAttribute("value"),
                                    FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")).GetAttribute("value"),
                                    FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']")).GetAttribute("value")
                                });
                            }
                        }
                        catch
                        {
                            continue;
                        }
                    
                    }
                    return lstPlanDetailTab;
                }

                public static List<tbPlanDetailElements> GetPlanDetailTabElements()
                {
                    CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                    List<tbPlanDetailElements> lstPlanDetailTab = new List<tbPlanDetailElements>();
                    IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[@style='display: table-row;']"));
                    foreach (var row in lstRows)
                    {
                        try
                        {
                            var bDisplayed = row.FindElement(By.XPath("td[@class='un col-delete']/a")).Displayed;
                            if (bDisplayed)
                            {
                                lstPlanDetailTab.Add(new tbPlanDetailElements()
                                {
                                    Delete = row.FindElement(By.XPath("td[16]/a")),
                                    Shift = row.FindElement(By.XPath("td[1]/select")),
                                    SkillMix = row.FindElement(By.XPath("td[2]/select")),
                                    Type = row.FindElement(By.XPath("td[3]/select")),
                                    LastName = row.FindElement(By.XPath("td[4]/input")),
                                    FirstName = row.FindElement(By.XPath("td[5]/input")),
                                    PositionDescription = row.FindElement(By.XPath("td[6]/input")),
                                    HiredInDate = row.FindElement(By.XPath("td[7]/input")),
                                    Status = row.FindElement(By.XPath("td[8]/select")),
                                    IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                    HiredInFTE = row.FindElement(By.XPath("td[10]/input")),
                                    Core = row.FindElement(By.XPath("td[11]/input")),
                                    Avg = row.FindElement(By.XPath("td[12]/input")),
                                    Peak = row.FindElement(By.XPath("td[13]/input")),
                                    ReqNumber = row.FindElement(By.XPath("td[14]/input")),
                                    Notes = row.FindElement(By.XPath("td[15]/input")),
                                    FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")),
                                    FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")),
                                    FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")),
                                    FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']"))
                                });
                            }
                        }
                        catch
                        {
                            continue;
                        }

                    }
                    return lstPlanDetailTab;
                }

                public static List<tbPlanDetailElements> GetPlanDetailTabElementsBlueLinesIncludingActiveAndInactive()
                {
                    try
                    {
                        CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                        List<tbPlanDetailElements> lstPlanDetailTab = new List<tbPlanDetailElements>();
                        IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'user-added')]"));
                        foreach (var row in lstRows)
                        {
                            try
                            {

                                lstPlanDetailTab.Add(new tbPlanDetailElements()
                                {
                                    Shift = row.FindElement(By.XPath("td[1]/select")),
                                    SkillMix = row.FindElement(By.XPath("td[2]/select")),
                                    Type = row.FindElement(By.XPath("td[3]/select")),
                                    LastName = row.FindElement(By.XPath("td[4]/input")),
                                    FirstName = row.FindElement(By.XPath("td[5]/input")),
                                    PositionDescription = row.FindElement(By.XPath("td[6]/input")),
                                    HiredInDate = row.FindElement(By.XPath("td[7]/input")),
                                    Status = row.FindElement(By.XPath("td[8]/select")),
                                    IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                    HiredInFTE = row.FindElement(By.XPath("td[10]/input")),
                                    Core = row.FindElement(By.XPath("td[11]/input")),
                                    Avg = row.FindElement(By.XPath("td[12]/input")),
                                    Peak = row.FindElement(By.XPath("td[13]/input")),
                                    ReqNumber = row.FindElement(By.XPath("td[14]/input")),
                                    Notes = row.FindElement(By.XPath("td[15]/input")),
                                    Delete = row.FindElement(By.XPath("td[16]/a")),
                                    FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")),
                                    FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")),
                                    FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")),
                                    FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']"))
                                });

                            }
                            catch
                            {
                                continue;
                            }

                        }
                        return lstPlanDetailTab;
                    }
                    catch
                    {
                        return null;
                    }
                }


                public static List<tbPlanDetailElements> GetPlanDetailTabElementsBlueLines()
                {
                    try
                    {
                        CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                        List<tbPlanDetailElements> lstPlanDetailTab = new List<tbPlanDetailElements>();
                        IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'user-added')]"));
                        foreach (var row in lstRows)
                        {                            
                            try
                            {

                                lstPlanDetailTab.Add(new tbPlanDetailElements()
                                {
                                    Shift = row.FindElement(By.XPath("td[1]/select")),
                                    SkillMix = row.FindElement(By.XPath("td[2]/select")),
                                    Type = row.FindElement(By.XPath("td[3]/select")),
                                    LastName = row.FindElement(By.XPath("td[4]/input")),
                                    FirstName = row.FindElement(By.XPath("td[5]/input")),
                                    PositionDescription = row.FindElement(By.XPath("td[6]/input")),
                                    HiredInDate = row.FindElement(By.XPath("td[7]/input")),
                                    Status = row.FindElement(By.XPath("td[8]/select[not(@disabled)]")),
                                    IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                    HiredInFTE = row.FindElement(By.XPath("td[10]/input")),
                                    Core = row.FindElement(By.XPath("td[11]/input")),
                                    Avg = row.FindElement(By.XPath("td[12]/input")),
                                    Peak = row.FindElement(By.XPath("td[13]/input")),
                                    ReqNumber = row.FindElement(By.XPath("td[14]/input")),
                                    Notes = row.FindElement(By.XPath("td[15]/input")),
                                    Delete = row.FindElement(By.XPath("td[16]/a")),
                                    FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")),
                                    FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")),
                                    FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")),
                                    FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']"))
                                });

                            }
                            catch
                            {
                                continue;
                            }

                        }
                        return lstPlanDetailTab;
                    }
                    catch
                    {
                        return null;
                    }
                }

                public static List<tbPlanDetailElements> GetPlanDetailTabElementsGreenLines()
                {
                    try
                    {
                        CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                        List<tbPlanDetailElements> lstPlanDetailTab = new List<tbPlanDetailElements>();
                        IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'emp-row international_travel_row')]"));
                        foreach (var row in lstRows)
                        {
                            try
                            {

                                lstPlanDetailTab.Add(new tbPlanDetailElements()
                                {
                                    Shift = row.FindElement(By.XPath("td[1]/select")),
                                    SkillMix = row.FindElement(By.XPath("td[2]/select")),
                                    Type = row.FindElement(By.XPath("td[3]/select")),
                                    LastName = row.FindElement(By.XPath("td[4]/input")),
                                    FirstName = row.FindElement(By.XPath("td[5]/input")),
                                    PositionDescription = row.FindElement(By.XPath("td[6]/input")),
                                    HiredInDate = row.FindElement(By.XPath("td[7]/input")),
                                    Status = row.FindElement(By.XPath("td[8]/select[not(@disabled)]")),
                                    IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                    HiredInFTE = row.FindElement(By.XPath("td[10]/input")),
                                    Core = row.FindElement(By.XPath("td[11]/input")),
                                    Avg = row.FindElement(By.XPath("td[12]/input")),
                                    Peak = row.FindElement(By.XPath("td[13]/input")),
                                    ReqNumber = row.FindElement(By.XPath("td[14]/input")),
                                    Notes = row.FindElement(By.XPath("td[15]/input")),
                                    Delete = row.FindElement(By.XPath("td[16]/a")),
                                    FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")),
                                    FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")),
                                    FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")),
                                    FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']"))
                                });

                            }
                            catch
                            {
                                continue;
                            }

                        }
                        return lstPlanDetailTab;
                    }
                    catch
                    {
                        return null;
                    }
                }

                public static List<tbPlanDetailElements> GetPlanDetailTabElementsBlueLinesWithRequisitionStatus(string reqState)
                {
                    try
                    {
                        CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                        List<tbPlanDetailElements> lstPlanDetailTab = new List<tbPlanDetailElements>();
                        IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'user-added')]"));
                        foreach (var row in lstRows)
                        {
                            try
                            {

                                lstPlanDetailTab.Add(new tbPlanDetailElements()
                                {
                                    Shift = row.FindElement(By.XPath("td[1]/select")),
                                    SkillMix = row.FindElement(By.XPath("td[2]/select")),
                                    Type = row.FindElement(By.XPath("td[3]/select")),
                                    LastName = row.FindElement(By.XPath("td[4]/input")),
                                    FirstName = row.FindElement(By.XPath("td[5]/input")),
                                    PositionDescription = row.FindElement(By.XPath("td[6]/input")),
                                    HiredInDate = row.FindElement(By.XPath("td[7]/input")),
                                    Status = row.FindElement(By.XPath("td[8]/select[not(@disabled)]")),
                                    IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                    HiredInFTE = row.FindElement(By.XPath("td[10]/input")),
                                    Core = row.FindElement(By.XPath("td[11]/input")),
                                    Avg = row.FindElement(By.XPath("td[12]/input")),
                                    Peak = row.FindElement(By.XPath("td[13]/input")),
                                    ReqNumber = row.FindElement(By.XPath($"td[14]/input[@title='{reqState}']")),
                                    Notes = row.FindElement(By.XPath("td[15]/input")),
                                    Delete = row.FindElement(By.XPath("td[16]/a")),
                                    FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")),
                                    FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")),
                                    FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")),
                                    FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']"))
                                });

                            }
                            catch
                            {
                                continue;
                            }

                        }
                        return lstPlanDetailTab;
                    }
                    catch
                    {
                        return null;
                    }
                }

                public static List<tbPlanDetailElements> GetPlanDetailTabElementsBlueLinesWithRequisitionNumber(string reqNum)
                {
                    try
                    {
                        CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                        List<tbPlanDetailElements> lstPlanDetailTab = new List<tbPlanDetailElements>();
                        IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'user-added')]"));
                        foreach (var row in lstRows)
                        {
                            try
                            {

                                lstPlanDetailTab.Add(new tbPlanDetailElements()
                                {
                                    Shift = row.FindElement(By.XPath("td[1]/select")),
                                    SkillMix = row.FindElement(By.XPath("td[2]/select")),
                                    Type = row.FindElement(By.XPath("td[3]/select")),
                                    LastName = row.FindElement(By.XPath("td[4]/input")),
                                    FirstName = row.FindElement(By.XPath("td[5]/input")),
                                    PositionDescription = row.FindElement(By.XPath("td[6]/input")),
                                    HiredInDate = row.FindElement(By.XPath("td[7]/input")),
                                    Status = row.FindElement(By.XPath("td[8]/select[not(@disabled)]")),
                                    IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                    HiredInFTE = row.FindElement(By.XPath("td[10]/input")),
                                    Core = row.FindElement(By.XPath("td[11]/input")),
                                    Avg = row.FindElement(By.XPath("td[12]/input")),
                                    Peak = row.FindElement(By.XPath("td[13]/input")),
                                    ReqNumber = row.FindElement(By.XPath($"td[14]/input[@value='{reqNum}']")),
                                    Notes = row.FindElement(By.XPath("td[15]/input")),
                                    Delete = row.FindElement(By.XPath("td[16]/a")),
                                    FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")),
                                    FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")),
                                    FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")),
                                    FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']"))
                                });

                            }
                            catch
                            {
                                continue;
                            }

                        }
                        return lstPlanDetailTab;
                    }
                    catch
                    {
                        return null;
                    }
                }

                public static List<tbPlanDetailData> GetPlanDetailTabDataForGreenLines()
                {
                    CommonFunctions.AddTestStep("Get the plan detail tab Data", "The data is retrieved.");
                    List<tbPlanDetailData> lstPlanDetailTab = new List<tbPlanDetailData>();
                    IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'emp-row international_travel_row')]"));
                    foreach (var row in lstRows)
                    {
                        try
                        {
                            var bDisplayed = row.FindElement(By.XPath("td[@class='un col-delete']/a")).Displayed;
                            if (bDisplayed)
                            {
                                lstPlanDetailTab.Add(new tbPlanDetailData()
                                {                                    
                                    Shift = row.FindElement(By.XPath("td[1]/select")).Text,
                                    SkillMix = row.FindElement(By.XPath("td[2]/select")).Text,
                                    Type = row.FindElement(By.XPath("td[3]/select")).Text,
                                    LastName = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                                    FirstName = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                                    PositionDescription = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                                    HiredInDate = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
                                    Status = row.FindElement(By.XPath("td[8]/select")).Text,
                                    IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                    HiredInFTE = row.FindElement(By.XPath("td[10]/input")).GetAttribute("value"),
                                    Core = row.FindElement(By.XPath("td[11]/input")).GetAttribute("value"),
                                    Avg = row.FindElement(By.XPath("td[12]/input")).GetAttribute("value"),
                                    Peak = row.FindElement(By.XPath("td[13]/input")).GetAttribute("value"),
                                    ReqNumber = row.FindElement(By.XPath("td[14]/input")).GetAttribute("value"),
                                    Notes = row.FindElement(By.XPath("td[15]/input")).GetAttribute("value"),
                                    FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")).GetAttribute("value"),
                                    FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")).GetAttribute("value"),
                                    FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")).GetAttribute("value"),
                                    FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']")).GetAttribute("value")
                                });
                            }
                        }
                        catch
                        {
                            continue;
                        }

                    }
                    return lstPlanDetailTab;
                }

                public static List<tbPlanDetailElements> GetPlanDetailTabElementsBlueLinesActiveAndInactive()
                {
                    CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                    List<tbPlanDetailElements> lstPlanDetailTab = new List<tbPlanDetailElements>();
                    IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'user-added')]"));
                    foreach (var row in lstRows)
                    {
                        try
                        {

                            lstPlanDetailTab.Add(new tbPlanDetailElements()
                            {
                                
                                Shift = row.FindElement(By.XPath("td[1]/select")),
                                SkillMix = row.FindElement(By.XPath("td[2]/select")),
                                Type = row.FindElement(By.XPath("td[3]/select")),
                                LastName = row.FindElement(By.XPath("td[4]/input")),
                                FirstName = row.FindElement(By.XPath("td[5]/input")),
                                PositionDescription = row.FindElement(By.XPath("td[6]/input")),
                                HiredInDate = row.FindElement(By.XPath("td[7]/input")),
                                Status = row.FindElement(By.XPath("td[8]/select")),
                                IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                                HiredInFTE = row.FindElement(By.XPath("td[10]/input")),
                                Core = row.FindElement(By.XPath("td[11]/input")),
                                Avg = row.FindElement(By.XPath("td[12]/input")),
                                Peak = row.FindElement(By.XPath("td[13]/input")),
                                ReqNumber = row.FindElement(By.XPath("td[14]/input")),
                                Notes = row.FindElement(By.XPath("td[15]/input")),
                                Delete = row.FindElement(By.XPath("td[16]/a")),
                                FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")),
                                FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")),
                                FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")),
                                FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']"))
                               
                            });

                        }
                        catch
                        {
                            continue;
                        }

                    }
                    return lstPlanDetailTab;
                }

                public static List<tbPlanDetailElements> GetPlanDetailTabElementsGrayLines()
                {
                    CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                    List<tbPlanDetailElements> lstPlanDetailTab = new List<tbPlanDetailElements>();
                    IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[not(contains(@class,'user-added')) and @style='display: table-row;']"));
                    foreach (var row in lstRows)
                    {
                                                    
                        lstPlanDetailTab.Add(new tbPlanDetailElements()
                        {
                            // Delete = row.FindElement(By.XPath("td[16]/a")),
                            Shift = row.FindElement(By.XPath("td[1]/select")),
                            SkillMix = row.FindElement(By.XPath("td[2]/input")),
                            Type = row.FindElement(By.XPath("td[3]/input")),
                            LastName = row.FindElement(By.XPath("td[4]/input")),
                            FirstName = row.FindElement(By.XPath("td[5]/input")),
                            PositionDescription = row.FindElement(By.XPath("td[6]/input")),
                            HiredInDate = row.FindElement(By.XPath("td[7]/input")),
                            Status = row.FindElement(By.XPath("td[8]/input")),
                            IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                            HiredInFTE = row.FindElement(By.XPath("td[10]/input")),
                            Core = row.FindElement(By.XPath("td[11]/input")),
                            Avg = row.FindElement(By.XPath("td[12]/input")),
                            Peak = row.FindElement(By.XPath("td[13]/input")),
                            ReqNumber = row.FindElement(By.XPath("td[14]/input")),
                            Notes = row.FindElement(By.XPath("td[15]/input")),
                            FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")),
                            FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")),
                            FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")),
                            FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']"))
                        });
                    }
                    return lstPlanDetailTab;
                }

                public static List<tbPlanDetailData> GetGrayLinesValues()
                {
                    Thread.Sleep(3000);
                    CommonFunctions.AddTestStep("Get the plan detail tab ", "The data is retrieved.");
                    List<tbPlanDetailData> lstPlanDetailTab = new List<tbPlanDetailData>();
                    IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[not(contains(@class,'user-added')) and @style='display: table-row;']"));
                    foreach (var row in lstRows)
                    {

                        lstPlanDetailTab.Add(new tbPlanDetailData()
                        {
                            //Delete = row.FindElement(By.XPath("td[16]/a")),
                            Shift = row.FindElement(By.XPath("td[1]/select/option[@selected]")).Text,
                            SkillMix = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                            Type = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                            LastName = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                            FirstName = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                            PositionDescription = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                            HiredInDate = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
                            JobCode = row.FindElement(By.XPath("td[6]/input")).GetAttribute("title").Split(':').ElementAt(1).Trim(),
                            Status = row.FindElement(By.XPath("td[8]/input")).GetAttribute("value").Trim(),
                            IncludeInactive = row.FindElement(By.XPath("td[9]/input")),
                            HiredInFTE = row.FindElement(By.XPath("td[10]/input")).GetAttribute("value"),                           
                            Core = row.FindElement(By.XPath("td[11]/input")).GetAttribute("value"),
                            Avg = row.FindElement(By.XPath("td[12]/input")).GetAttribute("value"),
                            Peak = row.FindElement(By.XPath("td[13]/input")).GetAttribute("value"),
                            ReqNumber = row.FindElement(By.XPath("td[14]/input")).GetAttribute("value"),
                            Notes = row.FindElement(By.XPath("td[15]/input")).GetAttribute("value"),
                            FTEs_HiredInDate = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotal']")).GetAttribute("value"),
                            FTEs_Core = CommonFunctions.getElement(By.XPath("//input[@id='coreFtesSubtotal']")).GetAttribute("value"),
                            FTEs_Avg = CommonFunctions.getElement(By.XPath("//input[@id='avgFtesSubtotal']")).GetAttribute("value"),
                            FTEs_Peak = CommonFunctions.getElement(By.XPath("//input[@id='peakFtesSubtotal']")).GetAttribute("value")
                        });
                    }
                    return lstPlanDetailTab;
                }

                public static PlanDetailsSubtotals getPlanDetailsSubtotals()
                {
                    By byHeaderHiredinFteSubtotal = By.XPath("//input[@id='hiredInFtesSubtotalTop']");
                    By byHeaderCoreSubtotal = By.XPath("//input[@id='coreFtesSubtotalTop']");
                    By byHeaderAvgSubtotal = By.XPath("//input[@id='avgFtesSubtotalTop']");
                    By byHeaderPeakSubtotal = By.XPath("//input[@id='peakFtesSubtotalTop']");
                    By byFooterhiredInFtesSubtotal = By.XPath("//input[@id='hiredInFtesSubtotal']");
                    By byFooterCoreSubtotal = By.XPath("//input[@id='coreFtesSubtotal']");
                    By byFooterAvgSubtotal = By.XPath("//input[@id='avgFtesSubtotal']");
                    By byFooterPeakSubtotal = By.XPath("//input[@id='peakFtesSubtotal']");
                    By byHeaderHeadcount = By.XPath("//input[@id='headcountSubtotalTop']");
                    By byFooterHeadcount = By.XPath("//input[@id='headcountSubtotal']");

                    return new PlanDetailsSubtotals()
                    {
                        
                        HeaderHeadcounts = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byHeaderHeadcount)),
                        HeaderCoreSubtotal = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byHeaderCoreSubtotal)),
                        HeaderHiredInFteSubtotal = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byHeaderHiredinFteSubtotal)),
                        HeaderAvgSubtotal = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byHeaderAvgSubtotal)),
                        HeaderPeakSubtotal = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byHeaderPeakSubtotal)),
                        FooterHeadcounts = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byFooterHeadcount)),
                        FooterHiredInFteSubtotal = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byFooterhiredInFtesSubtotal)),
                        FooterCoreSubtotal = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byFooterCoreSubtotal)),
                        FooterAvgSubtotal = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byFooterAvgSubtotal)),
                        FooterPeakSubtotal = CommonFunctions.GetDecimalValue(CommonFunctions.getElement(byFooterPeakSubtotal))
                    };
                }

                public static void AddNewEmployee(string FirstName, string LastName)
                {
                    CommonFunctions.AddTestStep($"Add new employee {FirstName} {LastName}", "The employee is added");
                    string coreValue = "0.15";
                    IWebElement cmdAddEmployee = CommonFunctions.getElement(By.XPath("//a[@id='addEmployeeBtn']"));
                    CommonFunctions.ClickByJE(cmdAddEmployee);
                    Thread.Sleep(1000);
                    var PlanDetailTabElements = GetPlanDetailTabElementsBlueLinesActiveAndInactive();
                    CommonFunctions.SetText(PlanDetailTabElements[0].FirstName, FirstName);
                    CommonFunctions.SetText(PlanDetailTabElements[0].LastName, LastName);                    
                    CommonFunctions.SetText(PlanDetailTabElements[0].Core, coreValue);
                    CommonFunctions.SetText(PlanDetailTabElements[0].Avg, coreValue);
                    CommonFunctions.SetText(PlanDetailTabElements[0].Peak, coreValue);
                    FpcPlanMenu.Save();
                }

                public static string ModifyExistingDeptPlanDetail()
                {
                    CommonFunctions.AddTestStep("Modify Existing Dept Plan Detail", "Data is modified");
                    string reqNumber;
                    IList<IWebElement> lstPlanRows = CommonFunctions.getElements(By.XPath("//*/table[@id='filteredEmployees']//tbody//tr//td[14]/input[@title='Approved']"));
                    reqNumber = lstPlanRows[0].GetAttribute("value");
                    var shift = lstPlanRows[0].FindElement(By.XPath("ancestor::tr/td[1]/select"));
                    //get unselected options
                    IList<IWebElement> lstOptions = CommonFunctions.getElements(By.XPath("(//*/table[@id='filteredEmployees']//tbody//tr//td[14]/input[@title='Approved']/ancestor::tr/td[1])[1]/select/option[not(@selected)]"));
                    CommonFunctions.SelectItemFromDropdownMenu(shift, lstOptions[0].Text);
                    FpcPlanMenu.Save();
                    return reqNumber.Trim();
                }

                public static void ModifyExistingDeptPlanDetail(string reqNum)
                {
                    CommonFunctions.AddTestStep("Modify Existing Dept Plan Detail", "Data is modified");
                    By byGhrReq = By.XPath($"(//*/table[@id='filteredEmployees']//tbody//tr//td[14]/input[@value='{reqNum}']/ancestor::tr/td[1])[1]/select/option[not(@selected)]");
                   
                    IList<IWebElement> lstPlanRows = CommonFunctions.getElements(By.XPath($"//*/table[@id='filteredEmployees']//tbody//tr//td[14]/input[@value='{reqNum}']"));
                   
                    var shift = lstPlanRows[0].FindElement(By.XPath("ancestor::tr/td[1]/select"));
                    //get unselected options
                    IList<IWebElement> lstOptions = CommonFunctions.getElements(byGhrReq);
                    CommonFunctions.SelectItemFromDropdownMenu(shift, lstOptions[0].Text);
                    //FpcPlanMenu.Save();
                }

                public static void IncludeInactiveEmpInDeptPlanDetail()
                {
                    var BlueLinesEmp = GetPlanDetailTabElementsBlueLines();
                    CommonFunctions.SelectItemFromDropdownMenu(BlueLinesEmp[0].Status, "A");
                    FpcPlanMenu.Save();
                    CommonFunctions.WaitUntilPageIsAcive();
                    var Core = CommonFunctions.GetDecimalValue(BlueLinesEmp[0].Core);
                    var Avg = CommonFunctions.GetDecimalValue(BlueLinesEmp[0].Avg);
                    var Peak = CommonFunctions.GetDecimalValue(BlueLinesEmp[0].Peak);
                    
                    //Get the subtotal before selecting active/inactive status
                    var beforePlanDetailsSubtotals = getPlanDetailsSubtotals();
                    //Calculations
                    var InactiveCore = beforePlanDetailsSubtotals.HeaderCoreSubtotal - Core;
                    var InactiveAvg = beforePlanDetailsSubtotals.HeaderCoreSubtotal - Avg;
                    var InactivePeak = beforePlanDetailsSubtotals.HeaderCoreSubtotal - Peak;

                    //Select inactive status
                    CommonFunctions.SelectItemFromDropdownMenu(BlueLinesEmp[0].Status, "I");
                    FpcPlanMenu.Save();
                    CommonFunctions.WaitUntilPageIsAcive();

                    //Get the subtotal before selecting active/inactive status
                    var AfterSelectingInactiveEmpSubtotals = getPlanDetailsSubtotals();




                    bool bExist;
                    By bychkInactive = By.XPath("(//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr//td[16]/a/ancestor::tr//td[8]/select)[1]/parent::td/following-sibling::td[1]/input[not(@disabled)]");
                    CommonFunctions.AddTestStep("Include Inactive Emp In Dept Plan Detail", "The inactive employees are included in calculation");
                    string reqNumber;
                    IList<IWebElement> lstStatusRows = CommonFunctions.getElements(By.XPath("//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr//td[16]/a/ancestor::tr//td[8]/select"));
                    var mnuStatus = lstStatusRows[0];
                    //Set inactive status
                    
                    
                    //CommonFunctions.BrowserRefresh();
                    //CommonFunctions.WaitUntilPageIsAcive();
                    //FpcPlanFilter.ViewPlanDetail();
                    //CommonFunctions.WaitUntilPageIsAcive();
                    bExist = CommonFunctions.IsElementDisplayed(bychkInactive, 5);
                    if (bExist) 
                    {
                        IWebElement chk = CommonFunctions.getElement(bychkInactive);
                        //var chkIncludeInactive = lstStatusRows[0].FindElement(By.XPath("parent::td/following-sibling::td[1]/input[not(@disabled)]"));                    
                        chk.Click();
                        //CommonFunctions.SetCheckbox(chk, true);
                        FpcPlanMenu.Save();
                        CommonFunctions.WaitUntilPageIsAcive();
                        CommonFunctions.BrowserRefresh();
                        FpcPlanFilter.ViewPlanDetail();
                        CommonFunctions.WaitUntilPageIsAcive();
                        FpcPlanFilter.ViewPlanDetail();
                        CommonFunctions.WaitUntilPageIsAcive();

                    }
                    else
                    {
                        var lstPlanDetailRows = GetPlanDetailTabElements();



                    }
                    
                    
                }

                public static bool IncludeInactiveEmpInDeptPlanDetailBlueLines()
                {
                    CommonFunctions.AddTestStep("Include Inactive Emp In Dept Plan Detail", "The inactive employees are included in calculation");
                    var BlueLinesEmp = GetPlanDetailTabElementsBlueLines();
                    CommonFunctions.SelectItemFromDropdownMenu(BlueLinesEmp[0].Status, "A");
                    FpcPlanMenu.Save();
                    CommonFunctions.WaitUntilPageIsAcive();
                    //CommonFunctions.BrowserRefresh();
                    //FpcPlanFilter.ViewPlanDetail();
                    CommonFunctions.WaitUntilPageIsAcive();
                    BlueLinesEmp = GetPlanDetailTabElementsBlueLines();
                    var Core = CommonFunctions.GetDecimalValue(BlueLinesEmp[0].Core);
                    var Avg = CommonFunctions.GetDecimalValue(BlueLinesEmp[0].Avg);
                    var Peak = CommonFunctions.GetDecimalValue(BlueLinesEmp[0].Peak);

                    //Get the subtotal before selecting active/inactive status
                    var beforePlanDetailsSubtotals = getPlanDetailsSubtotals();
                    //Calculations
                    var InactiveCore = beforePlanDetailsSubtotals.HeaderCoreSubtotal - Core;                    
                    var InactiveAvg = beforePlanDetailsSubtotals.HeaderAvgSubtotal - Avg;
                    var InactivePeak = beforePlanDetailsSubtotals.HeaderPeakSubtotal- Peak;

                    System.Console.WriteLine($"Expected Core subtotal after I = {InactiveCore} ");
                    System.Console.WriteLine($"Expected Avg subtotal after I = {InactiveAvg} ");
                    System.Console.WriteLine($"Expected Pead subtotal after I = {InactivePeak} ");

                    //Select inactive status
                    CommonFunctions.SelectItemFromDropdownMenu(BlueLinesEmp[0].Status, "I");
                    FpcPlanMenu.Save();
                    CommonFunctions.WaitUntilPageIsAcive();
                    CommonFunctions.BrowserRefresh();
                    FpcPlanFilter.ViewPlanDetail();
                    CommonFunctions.WaitUntilPageIsAcive();
                    FpcPlanFilter.ViewPlanDetail();
                    CommonFunctions.WaitUntilPageIsAcive();
                    //Get the subtotal before selecting active/inactive status
                    var AfterSelectingInactiveEmpSubtotals = getPlanDetailsSubtotals();
                    System.Console.WriteLine($"Actual Core subtotal selecting I = {AfterSelectingInactiveEmpSubtotals.HeaderCoreSubtotal}");
                    System.Console.WriteLine($"Actual Avg subtotal selecting I = {AfterSelectingInactiveEmpSubtotals.HeaderAvgSubtotal}");
                    System.Console.WriteLine($"Actual Peak subtotal selecting I = {AfterSelectingInactiveEmpSubtotals.HeaderPeakSubtotal}");

                    var bMatched = Math.Round(AfterSelectingInactiveEmpSubtotals.HeaderCoreSubtotal, 2) == Math.Round(InactiveCore, 2) &&
                        Math.Round(AfterSelectingInactiveEmpSubtotals.HeaderAvgSubtotal, 2) == Math.Round(InactiveAvg, 2) &&
                        Math.Round(AfterSelectingInactiveEmpSubtotals.HeaderPeakSubtotal, 2) == Math.Round(InactivePeak, 2);
                    return bMatched;
                }

                public static string DeleteExistingDeptPlanDetail()
                {
                    int iCount;
                    string reqNumber, ConfirmXpath;
                    bool bDisplayed;
                    ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-delete-emp-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
                    IList<IWebElement> lstPlanRows = CommonFunctions.getElements(By.XPath("//*/table[@id='filteredEmployees']//tbody//tr//td[14]/input[@title]"));
                    iCount = lstPlanRows.Count;
                    reqNumber = lstPlanRows[iCount-1].GetAttribute("value");
                    var cmdDelete = lstPlanRows[iCount - 1].FindElement(By.XPath("ancestor::tr/td[16]/a"));
                    CommonFunctions.Click(cmdDelete);
                    bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                    if (bDisplayed)
                    {
                        IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                        CommonFunctions.ClickByJE(cmdYes);
                    }
                    FpcPlanMenu.Save();
                    return reqNumber.Trim();
                }

                public static void DeleteExistingDeptPlanDetail(string reqNum)
                {
                    int iCount;
                    string reqNumber, ConfirmXpath;
                    bool bDisplayed;
                    ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-delete-emp-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
                    var cmdDelete = CommonFunctions.getElement(By.XPath($"//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'user-added')]//td[14]/input[@value='{reqNum}']/../../td[16]/a"));  
                    CommonFunctions.Click(cmdDelete);
                    bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                    if (bDisplayed)
                    {
                        IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                        CommonFunctions.ClickByJE(cmdYes);
                    }
                    FpcPlanMenu.Save();
                }

                public static void DeleteExistingRequisition(string reqNum)
                {
                    int iCount;
                    string reqNumber, ConfirmXpath;
                    bool bDisplayed;
                    ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-delete-emp-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
                    var cmdDelete = CommonFunctions.getElement(By.XPath($"//*/div[@id='employeeResults']//table[@id='filteredEmployees']//tbody//tr[contains(@class,'user-added')]//td[14]/input[@value='{reqNum}']/../../td[16]/a"));
                    CommonFunctions.Click(cmdDelete);
                    bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                    if (bDisplayed)
                    {
                        IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                        CommonFunctions.ClickByJE(cmdYes);
                    }
                    FpcPlanMenu.Save();
                }

                public static void AddMissingReqisition()
                {
                    int iCount;
                    string reqNumber, ConfirmXpath;
                    bool bDisplayed;
                    ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-add-missing-lawson-req-infromation-confirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
                    var cmdAddMissingRequisition = CommonFunctions.getElement(By.XPath("//a[@id='addMissedLawsonBtn']"));
                    CommonFunctions.Click(cmdAddMissingRequisition);
                    bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                    if (bDisplayed)
                    {
                        IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                        CommonFunctions.ClickByJE(cmdYes);
                        CommonFunctions.AddTestStep("Add Missing Requisition", "The missing requisition is added in the plan details");
                    }
                    FpcPlanMenu.Save();
                }

                public static PlanDetailFiltersCommand Filters()
                {
                    return new PlanDetailFiltersCommand();
                }

                public static PlanDetailResultsFiltersCommands EmployeeResultFilters()
                {
                    return new PlanDetailResultsFiltersCommands();
                }

                #region: PlanDetailFiltersCommand
                public class PlanDetailFiltersCommand
                {
                    private string subtotalBy;
                    private string filterBy;
                    private string filterByStatus;
                    private string filterByType;

                    public PlanDetailFiltersCommand withSubtotalBy(string SubtotalBy)
                    {
                        this.subtotalBy = SubtotalBy;
                        return this;
                    }

                    public PlanDetailFiltersCommand withFilterBy(string FilterBy)
                    {
                        this.filterBy = FilterBy;
                        return this;
                    }

                    public PlanDetailFiltersCommand withFilterByStatus(string FilterByStatus)
                    {
                        this.filterByStatus = FilterByStatus;
                        return this;
                    }

                    public PlanDetailFiltersCommand withFilterByType(string FilterByType)
                    {
                        this.filterByType = FilterByType;
                        return this;
                    }

                    private void setSubtotalBy()
                    {
                        if (!string.IsNullOrEmpty(subtotalBy))
                        {
                            By bySubtotalBy = By.XPath("//select[@id='subtotalByListing']");
                            IWebElement mnuSubtotalBy = CommonFunctions.getElement(bySubtotalBy);
                            CommonFunctions.SelectItemFromDropdownMenu(mnuSubtotalBy, subtotalBy);
                            CommonFunctions.AddTestStep($"Verify a user can select {subtotalBy} from subtotal By dropdown", $"The {subtotalBy} is selected correctly");
                        }
                    }

                    private void setFilterBy()
                    {
                        if (!string.IsNullOrEmpty(filterBy))
                        {
                            By byFilterBy = By.XPath("//select[@id='filterByListing']");
                            IWebElement mnuFilterBy = CommonFunctions.getElement(byFilterBy);
                            CommonFunctions.SelectItemFromDropdownMenu(mnuFilterBy, filterBy);
                            CommonFunctions.AddTestStep($"Verify a user can select {filterBy} from Filter By dropdown", $"The {filterBy} is selected correctly");
                        }
                    }

                    private void setFilterByStatus()
                    {
                        if (!string.IsNullOrEmpty(filterByStatus))
                        {
                            By byFilterByStatus = By.XPath("//select[@id='employeeStatusListing']");
                            IWebElement mnuFilterByStatus = CommonFunctions.getElement(byFilterByStatus);
                            CommonFunctions.SelectItemFromDropdownMenu(mnuFilterByStatus, filterByStatus);
                            CommonFunctions.AddTestStep($"Verify a user can select {filterByStatus} from Filter By Status dropdown", $"The {filterByStatus} is selected correctly");
                        }
                    }

                    private void setFilterByType()
                    {
                        if (!string.IsNullOrEmpty(filterByType))
                        {
                            By byFilterByType = By.XPath("//select[@id='employeeTypeListing']");
                            IWebElement mnuFilterByType = CommonFunctions.getElement(byFilterByType);
                            CommonFunctions.SelectItemFromDropdownMenu(mnuFilterByType, filterByType);
                            CommonFunctions.AddTestStep($"Verify a user can select {filterByType} from Filter By Type dropdown", $"The {filterByType} is selected correctly");
                        }
                    }

                    public void SetFilterBy()
                    {
                        setSubtotalBy();
                        setFilterBy();
                        setFilterByStatus();
                        setFilterByType();
                        CommonFunctions.WaitUntilPageIsAcive();
                        Thread.Sleep(2000);
                    }
                }
                #endregion

                #region: PlanDetailResultsFiltersCommands
                public class PlanDetailResultsFiltersCommands
                {
                    private string shiftFilter;
                    private string skillMixFilter;
                    private string typeFilter;
                    private string lastNameFilter;
                    private string firstNameFilter;
                    private string positionDescriptionFilter;
                    private string hiredInDateFilter;
                    private string statusFilter;
                    private string includeInactiveFilter;
                    private string hiredInFTEFilter;
                    private string coreFilter;
                    private string avgFilter;
                    private string peakFilter;
                    private string reqNumberFilter;
                    private string notesFilter;

                    public PlanDetailResultsFiltersCommands withShiftFilter(string ShiftFilter)
                    {
                        this.shiftFilter = ShiftFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withSkillMixFilter(string SkillMixFilter)
                    {
                        this.skillMixFilter = SkillMixFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withTypeFilter(string TypeFilter)
                    {
                        this.typeFilter = TypeFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withLastNameFilter(string LastNameFilter)
                    {
                        this.lastNameFilter = LastNameFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withFirstNameFilter(string FirstNameFilter)
                    {
                        this.firstNameFilter = FirstNameFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withPositionDescriptionFilter(string PositionDescriptionFilter)
                    {
                        this.positionDescriptionFilter = PositionDescriptionFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withHiredInDateFilter(string HiredInDateFilter)
                    {
                        this.hiredInDateFilter = HiredInDateFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withStatusFilter(string StatusFilter)
                    {
                        this.statusFilter = StatusFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withIncludeInactiveFilter(string IncludeInactiveFilter)
                    {
                        this.includeInactiveFilter = IncludeInactiveFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withHiredInFTEFilter(string HiredInFTEFilter)
                    {
                        this.hiredInFTEFilter = HiredInFTEFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withCoreFilter(string CoreFilter)
                    {
                        this.coreFilter = CoreFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withAvgFilter(string AvgFilter)
                    {
                        this.avgFilter = AvgFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withPeakFilter(string PeakFilter)
                    {
                        this.peakFilter = PeakFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withReqNumberFilter(string ReqNumberFilter)
                    {
                        this.reqNumberFilter = ReqNumberFilter;
                        return this;
                    }

                    public PlanDetailResultsFiltersCommands withNotesFilter(string NotesFilter)
                    {
                        this.notesFilter = NotesFilter;
                        return this;
                    }

                    private void setShiftFilter()
                    {
                        By byShiftFilter = By.XPath("//td[@class='col-shift']//select[@class='table-filter']");
                        IWebElement mnuShiftFilter = CommonFunctions.getElement(byShiftFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuShiftFilter, shiftFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {shiftFilter} from Shift Filter dropdown", $"The {shiftFilter} is selected correctly");
                    }

                    private void setSkillMixFilter()
                    {
                        By bySkillMixFilter = By.XPath("//td[@class='col-shift']//select[@class='table-filter']");
                        IWebElement mnuSkillMixFilter = CommonFunctions.getElement(bySkillMixFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuSkillMixFilter, skillMixFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {skillMixFilter} from Skill Mix Filter dropdown", $"The {skillMixFilter} is selected correctly");
                    }

                    private void setTypeFilter()
                    {
                        By byTypeFilter = By.XPath("//td[@class='col-emp-type']//select[@class='table-filter']");
                        IWebElement mnuTypeFilter = CommonFunctions.getElement(byTypeFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuTypeFilter, typeFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {typeFilter} from Type Filter dropdown", $"The {typeFilter} is selected correctly");
                    }

                    private void setLastNameFilter()
                    {
                        By byLastNameFilter = By.XPath("//td[@class='col-last-nm']//select[@class='table-filter']");
                        IWebElement mnuLastNameFilter = CommonFunctions.getElement(byLastNameFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuLastNameFilter, lastNameFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {lastNameFilter} from Last Name Filter dropdown", $"The {lastNameFilter} is selected correctly");
                    }

                    private void setFirstNameFilter()
                    {
                        By byFirstNameFilter = By.XPath("//td[@class='col-first-nm']//select[@class='table-filter']");
                        IWebElement mnuFirstNameFilter = CommonFunctions.getElement(byFirstNameFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuFirstNameFilter, firstNameFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {firstNameFilter} from First Name Filter dropdown", $"The {firstNameFilter} is selected correctly");
                    }

                    private void setPositionDescriptionFilter()
                    {
                        By byPositionDescriptionFilter = By.XPath("//td[@class='col-position-desc']//select[@class='table-filter']");
                        IWebElement mnuPositionDescriptionFilter = CommonFunctions.getElement(byPositionDescriptionFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuPositionDescriptionFilter, positionDescriptionFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {positionDescriptionFilter} from Position Description Filter dropdown", $"The {positionDescriptionFilter} is selected correctly");
                    }

                    private void setHiredInDateFilter()
                    {
                        By byHiredInDateFilter = By.XPath("//td[@class='col-hired-in-date']//select[@class='table-filter']");
                        IWebElement mnuHiredInDateFilter = CommonFunctions.getElement(byHiredInDateFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuHiredInDateFilter, hiredInDateFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {hiredInDateFilter} from Hired In Date Filter dropdown", $"The {hiredInDateFilter} is selected correctly");
                    }

                    private void setStatusFilter()
                    {
                        By byStatusFilter = By.XPath("//td[@class='col-status']//select[@class='table-filter']");
                        IWebElement mnuStatusFilter = CommonFunctions.getElement(byStatusFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuStatusFilter, statusFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {statusFilter} from Status Filter dropdown", $"The {statusFilter} is selected correctly");
                    }

                    private void setIncludeInactiveFilter()
                    {
                        By byIncludeInactiveFilter = By.XPath("//td[@class='col-include-inactive']//select[@class='table-filter']");
                        IWebElement mnuIncludeInactiveFilter = CommonFunctions.getElement(byIncludeInactiveFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuIncludeInactiveFilter, includeInactiveFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {includeInactiveFilter} from Include Inactive Filter dropdown", $"The {includeInactiveFilter} is selected correctly");
                    }

                    private void setHiredInFTEFilter()
                    {
                        By byHiredInFTEFilter = By.XPath("//td[@class='col-hired-in-fte']//select[@class='table-filter']");
                        IWebElement mnuHiredInFTEFilter = CommonFunctions.getElement(byHiredInFTEFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuHiredInFTEFilter, hiredInFTEFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {hiredInFTEFilter} from Hired In FTE Filter dropdown", $"The {hiredInFTEFilter} is selected correctly");
                    }

                    private void setCoreFilter()
                    {
                        By byCoreFilter = By.XPath("//td[@class='col-core-fte']//select[@class='table-filter']");
                        IWebElement mnuCoreFilter = CommonFunctions.getElement(byCoreFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuCoreFilter, coreFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {coreFilter} from Core Filter dropdown", $"The {coreFilter} is selected correctly");
                    }

                    private void setAvgFilter()
                    {
                        By byAvgFilter = By.XPath("//td[@class='col-avg-fte']//select[@class='table-filter']");
                        IWebElement mnuAvgFilter = CommonFunctions.getElement(byAvgFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuAvgFilter, avgFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {avgFilter} from Avg Filter dropdown", $"The {avgFilter} is selected correctly");
                    }

                    private void setPeakFilter()
                    {
                        By byPeakFilter = By.XPath("//td[@class='col-peak-fte']//select[@class='table-filter']");
                        IWebElement mnuPeakFilter = CommonFunctions.getElement(byPeakFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuPeakFilter, peakFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {peakFilter} from Peak Filter dropdown", $"The {peakFilter} is selected correctly");
                    }

                    private void setReqNumberFilter()
                    {
                        By byReqNumberFilter = By.XPath("//td[@class='col-req-num']//select[@class='table-filter']");
                        IWebElement mnuReqNumberFilter = CommonFunctions.getElement(byReqNumberFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuReqNumberFilter, reqNumberFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {reqNumberFilter} from Req Number Filter dropdown", $"The {reqNumberFilter} is selected correctly");
                    }

                    private void setNotesFilter()
                    {
                        By byNotesFilter = By.XPath("//td[@class='col-note']//select[@class='table-filter']");
                        IWebElement mnuNotesFilter = CommonFunctions.getElement(byNotesFilter);
                        CommonFunctions.SelectItemFromDropdownMenu(mnuNotesFilter, notesFilter);
                        CommonFunctions.AddTestStep($"Verify a user can select {notesFilter} from Notes Filter dropdown", $"The {notesFilter} is selected correctly");
                    }

                    public void Set()
                    {
                        setShiftFilter();
                        setSkillMixFilter();
                        setTypeFilter();
                        setLastNameFilter();
                        setFirstNameFilter();
                        setPositionDescriptionFilter();
                        setHiredInDateFilter();
                        setStatusFilter();
                        setIncludeInactiveFilter();
                        setHiredInFTEFilter();
                        setCoreFilter();
                        setAvgFilter();
                        setPeakFilter();
                        setReqNumberFilter();
                        setNotesFilter();
                    }



                }
                #endregion
            }

            public class RequisitionsTab
            {
                public class RequistionData
                {
                    public string LawsonReqs { get; set; }
                    public string GHRReqs { get; set; }
                    public string ReqStatus { get; set; }
                    public string Opened { get; set; }
                    public string Closed { get; set; }
                    public string PositionDescription { get; set; }
                    public string Status { get; set; }
                    public string JobClass { get; set; }
                    public string JobClassDescription { get; set; }
                    public decimal OpenFTE { get; set; }
                    public string WorkScheduleDescription { get; set; }
                    public string ReplacingName { get; set; }
                    public string ReplacingNameEIN { get; set; }
                    public string PendingName { get; set; }
                    public string PendingNameEIN { get; set; }
                }

                public static List<RequistionData> getRequistionTabData()
                {
                    CommonFunctions.AddTestStep("Get the requistion tab data", "The data was retrieved");
                    List<RequistionData> requistionDatas = new List<RequistionData>();
                    By byRows = By.XPath("//*/table[@id='lawsonRequisitionDetails']//tbody//tr");
                    var RowData = CommonFunctions.getElements(byRows);
                    foreach ( var row in RowData )
                    {
                        requistionDatas.Add(new RequistionData()
                        {
                            LawsonReqs = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                            GHRReqs = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                            ReqStatus = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                            Opened = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                            Closed = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                            PositionDescription = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                            Status = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
                            JobClass = row.FindElement(By.XPath("td[8]/input")).GetAttribute("value"),
                            JobClassDescription = row.FindElement(By.XPath("td[9]/input")).GetAttribute("value"),
                            OpenFTE = CommonFunctions.ConvertToDecimal(row.FindElement(By.XPath("td[10]/input")).GetAttribute("value"),2),
                            WorkScheduleDescription = row.FindElement(By.XPath("td[11]/input")).GetAttribute("value"),
                            ReplacingName = row.FindElement(By.XPath("td[12]/input")).GetAttribute("value"),
                            ReplacingNameEIN = row.FindElement(By.XPath("td[13]/input")).GetAttribute("value"),
                            PendingName = row.FindElement(By.XPath("td[14]/input")).GetAttribute("value"),
                            //PendingNameEIN = row.FindElement(By.XPath("td[15]/input")).GetAttribute("value")
                        });
                    }
                    return requistionDatas;
                }

                public static List<RequistionData> getRequistionTabData(string requistionNum)
                {
                    CommonFunctions.AddTestStep("Get the requistion tab data", "The data was retrieved");
                    List<RequistionData> requistionDatas = new List<RequistionData>();
                    By byRows = By.XPath("//*/table[@id='lawsonRequisitionDetails']//tbody//tr");
                    var RowData = CommonFunctions.getElements(byRows);
                    foreach (var row in RowData)
                    {
                        try
                        {
                            requistionDatas.Add(new RequistionData()
                            {
                                LawsonReqs = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                                GHRReqs = row.FindElement(By.XPath($"td[2]/input[contains(@value,'{requistionNum}')]")).GetAttribute("value"),
                                ReqStatus = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                                Opened = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                                Closed = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                                PositionDescription = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                                Status = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
                                JobClass = row.FindElement(By.XPath("td[8]/input")).GetAttribute("value"),
                                JobClassDescription = row.FindElement(By.XPath("td[9]/input")).GetAttribute("value"),
                                OpenFTE = CommonFunctions.ConvertToDecimal(row.FindElement(By.XPath("td[10]/input")).GetAttribute("value"), 2),
                                WorkScheduleDescription = row.FindElement(By.XPath("td[11]/input")).GetAttribute("value"),
                                ReplacingName = row.FindElement(By.XPath("td[12]/input")).GetAttribute("value"),
                                ReplacingNameEIN = row.FindElement(By.XPath("td[13]/input")).GetAttribute("value"),
                                PendingName = row.FindElement(By.XPath("td[14]/input")).GetAttribute("value"),
                                //PendingNameEIN = row.FindElement(By.XPath("td[15]/input")).GetAttribute("value")
                            });
                        }
                        catch
                        {
                            continue;
                        }
                    }
                    return requistionDatas;
                }


                public static void GoTo()
                {
                    CommonFunctions.AddTestStep("Go to requisitions tab", "The requisitions tab was selected");
                    IWebElement tbPlanDetail = CommonFunctions.getElement(By.XPath("//a[normalize-space()='Requisitions']"));
                    CommonFunctions.ClickByJE(tbPlanDetail);
                    CommonFunctions.WaitUntilPageIsAcive();
                }

                public static bool IsAt
                {
                    get
                    {
                        string xpath = "//select[@id='reqStatusByListing']";
                        return CommonFunctions.IsElementDisplayed(xpath, 10);
                    }
                }

                public static bool VerifyShiftErrorInRequistion(string reqNumber)
                {
                    CommonFunctions.AddTestStep($"Verify Shift Error in Requistion for requistion {reqNumber}", "The error is verified");
                    string xpath = $"//*/table[@id='lawsonRequisitionDetails']//tbody//tr/td/input[@value='{reqNumber}']/ancestor::tr/td[11]/input[@title]";
                    bool bExist = CommonFunctions.IsElementDisplayed(xpath, 2);
                    return bExist;
                }

                public static bool VerifyDeletionErrorInRequistion(string reqNumber)
                {
                    CommonFunctions.AddTestStep($"Verify Deletion Error for requistion {reqNumber}", "The error was verified.");
                    bool bLawsonReqsErr, bGHRReqsErr;
                    string LawsonReqsXpath = $"//*/table[@id='lawsonRequisitionDetails']//tbody//tr/td/input[@value='{reqNumber}']/ancestor::tr/td[1]/input[@title]";
                    bLawsonReqsErr = CommonFunctions.IsElementDisplayed(LawsonReqsXpath, 2);
                    string GHRReqsXpath = $"//*/table[@id='lawsonRequisitionDetails']//tbody//tr/td/input[@value='{reqNumber}']/ancestor::tr/td[2]/input[@title]";
                    bGHRReqsErr = CommonFunctions.IsElementDisplayed(GHRReqsXpath, 2);
                    return bLawsonReqsErr && bGHRReqsErr;
                }
            }

            public class ContractLaborTab
            {
                public static void GoTo()
                {
                    CommonFunctions.AddTestStep("Go to the contract labodr tab", "The contract labor tab is enabled and selected.");
                    IWebElement tbContractLabor = CommonFunctions.getElement(By.XPath("//a[normalize-space()='Contract Labor']"));
                    CommonFunctions.ClickByJE(tbContractLabor);
                    CommonFunctions.WaitUntilPageIsAcive();
                }

                public static bool IsAt
                {
                    get
                    {
                        string xpath = "//th[normalize-space()='Candidate Name']";
                        return CommonFunctions.IsElementDisplayed(xpath, 10);
                    }
                }

                public class StatusSummary
                {
                    public string Status { get; set; }
                    public decimal Count { get; set; }
                    public decimal TotalFTEs { get; set; }
                }
                public static List<tbContractLaborData> getContractLaborData()
                {
                    CommonFunctions.AddTestStep("get Contract Labor Data", "The Contract Labor data was retrieved");
                    List<tbContractLaborData> lstContractLaborDatas= new List<tbContractLaborData>();
                    IList<IWebElement> lstRows = CommonFunctions.getElements(By.XPath("//table[@id='contractLaborDetails']/tbody//tr"));
                    foreach (var row in lstRows)
                    {
                        lstContractLaborDatas.Add(new tbContractLaborData()
                        {
                            CandidateName = row.FindElement(By.XPath("td[1]/input")).GetAttribute("value"),
                            Skill = row.FindElement(By.XPath("td[2]/input")).GetAttribute("value"),
                            ShiftStart = row.FindElement(By.XPath("td[3]/input")).GetAttribute("value"),
                            WeeksLeft = row.FindElement(By.XPath("td[4]/input")).GetAttribute("value"),
                            AvlOnCurrentMonth = row.FindElement(By.XPath("td[5]/input")).GetAttribute("value"),
                            AvlOnNextMonth = row.FindElement(By.XPath("td[6]/input")).GetAttribute("value"),
                            TotalWeeks = row.FindElement(By.XPath("td[7]/input")).GetAttribute("value"),
                            PositionType = row.FindElement(By.XPath("td[8]/input")).GetAttribute("value"),
                            Vendor = row.FindElement(By.XPath("td[9]/input")).GetAttribute("value"),
                            MatchStatus = row.FindElement(By.XPath("td[10]/input")).GetAttribute("value"),
                            StartDate = row.FindElement(By.XPath("td[11]/input")).GetAttribute("value"),
                            EndDate = row.FindElement(By.XPath("td[12]/input")).GetAttribute("value"),
                            BillRate = row.FindElement(By.XPath("td[13]/input")).GetAttribute("value"),
                            FTEs = CommonFunctions.GetDecimalValue(row.FindElement(By.XPath("td[14]/input"))),
                            NextApprover = row.FindElement(By.XPath("td[15]/input")).GetAttribute("value"),
                            ApprovalStatus = row.FindElement(By.XPath("td[16]/input")).GetAttribute("value"),
                            PositionID = row.FindElement(By.XPath("td[17]/input")).GetAttribute("value"),
                            MatchID = row.FindElement(By.XPath("td[18]/input")).GetAttribute("value"),
                            RemainingPositions = row.FindElement(By.XPath("td[19]/input")).GetAttribute("value"),
                            AvlOnCurrentDate = CommonFunctions.getElement(By.XPath("//table[@id='contractLaborDetails']/thead//th[5]")).Text,
                            AvlOnFollowingMonthDate = CommonFunctions.getElement(By.XPath("//table[@id='contractLaborDetails']/thead//th[6]")).Text
                        });                        
                    }
                    return lstContractLaborDatas;
                }

                private static StatusSummary getContractLaborStatusSummary(string status)
                {
                    var ContractLaborData = ContractLaborTab.getContractLaborData();
                    if (string.Equals(status, "Open", StringComparison.OrdinalIgnoreCase))
                    {
                        var resultsByMatchedStatus = ContractLaborData
                            .Where(e => string.Equals(e.MatchStatus, status, StringComparison.OrdinalIgnoreCase))
                            .GroupBy(e => e.MatchStatus)
                            .Select(g => new StatusSummary()
                            {
                                Status = g.Key,
                                Count = g.Sum(e => Convert.ToDecimal(e.RemainingPositions)),
                                TotalFTEs = g.Sum(e => Convert.ToDecimal(e.RemainingPositions)) * 0.9m

                            }).FirstOrDefault();
                        return resultsByMatchedStatus;

                    }
                    else
                    {
                        var resultsByMatchedStatus = ContractLaborData
                            .Where(e => string.Equals(e.MatchStatus, status, StringComparison.OrdinalIgnoreCase))
                            .GroupBy(e => e.MatchStatus)
                            .Select(g => new StatusSummary()
                            {
                                Status = g.Key,
                                Count = Convert.ToDecimal(g.Count()),
                                TotalFTEs = g.Sum(e => e.FTEs)

                            }).FirstOrDefault();
                        return resultsByMatchedStatus;
                    }
                    
                }

                private static bool verifyContrcatLaborStatusTotalAndFteValues(string status)
                {
                    bool bMatched;
                    var planFteSummary = PlanDetailTab.GetPlanDetailFTESummaryDepartment();
                    var result = getContractLaborStatusSummary(status);
                    switch (status)
                    {
                        case "Open":
                            bMatched = planFteSummary.ContractLabor_Open_FTE == result.TotalFTEs &&
                                planFteSummary.ContractLabor_Open_Total == result.Count ;
                            return bMatched;
                        case "Pending - Approval":
                            bMatched = planFteSummary.ContractLabor_PendingApproval_FTE == result.TotalFTEs &&
                                planFteSummary.ContractLabor_PendingApproval_Total == result.Count;
                            return bMatched;
                        case "Pending Start":
                            bMatched = planFteSummary.ContractLabor_PendingStart_FTE == result.TotalFTEs &&
                                planFteSummary.ContractLabor_PendingStart_Total == result.Count;
                            return bMatched;
                        case "Embedded":
                            bMatched = planFteSummary.ContractLabor_Embedded_FTE == result.TotalFTEs &&
                                planFteSummary.ContractLabor_Embedded_Total == result.Count;
                            return bMatched;
                        case "Working":
                            bMatched = planFteSummary.ContractLabor_Working_FTE == result.TotalFTEs &&
                                planFteSummary.ContractLabor_Working_Total == result.Count;
                            return bMatched;
                        case "Total Working":
                            var EmbeddedResult = getContractLaborStatusSummary("Embedded");
                            var WorkingResult = getContractLaborStatusSummary("Working");
                            var SumOfEmbeddedAndWorkingFtes = EmbeddedResult.TotalFTEs + WorkingResult.TotalFTEs;
                            var SumOfEmbeddedAndWorkingCount = EmbeddedResult.Count + WorkingResult.Count;
                            bMatched = planFteSummary.ContractLabor_TotalWorking_FTE == SumOfEmbeddedAndWorkingFtes &&
                                planFteSummary.ContractLabor_TotalWorking_Total == SumOfEmbeddedAndWorkingCount;
                            return bMatched;
                    }
                    return true;
                }

                public static bool verifyContrcatLaborTableInSummaryView()
                {
                    List<bool> boolList = new List<bool>();
                    string[] arrStatus = ["Open", "Pending Approval", "Pending Start", "Total Working"];                    
                    foreach (string status in arrStatus)
                    {
                        boolList.Add(verifyContrcatLaborStatusTotalAndFteValues(status));
                    }
                    var hasFalse = boolList.Any(x => x == false);
                    return hasFalse;
                }
            }
        }
        #endregion

        #endregion
    }
}
