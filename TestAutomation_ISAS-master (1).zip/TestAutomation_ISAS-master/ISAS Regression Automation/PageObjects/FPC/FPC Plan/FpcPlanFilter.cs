﻿using AutomationCoreLite.Reporting;
using AventStack.ExtentReports.Gherkin.Model;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.FpcPlan;
using static ISAS_Regression_Automation.WFTMainMenu.WorkloadForecast;

namespace ISAS_Regression_Automation
{
    public class FpcPlanFilter
    {
        #region: Navigation and validation
        public static void GoTo()
        {
            FPCMainMenu.FPC.SelectPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Navigate to FPC plan filter", "Filter is displayed");
        }

        public static bool IsAt
        {
            get
            {                
                string xpath = "//a[@id='getPlanDetailsBtn']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public static void ViewPlanDetail()
        {
            bool bExists;
            Timer.Start();
            IWebElement cmdViewPlanDetail = CommonFunctions.getElement(By.XPath("//a[@id='getViewPlanDetailsBtn']"));
            CommonFunctions.ClickByJE(cmdViewPlanDetail);
            
            bExists = PlanDetail.PlanDetailTab.IsAt;
            if(bExists)
            {
                Timer.Stop();
               //CommonFunctions.WriteToFile($"Plan detail view: {Timer.GetElapsedTime()}");
            }
            CommonFunctions.AddTestStep("Click View Plan Detail button", "The button is enabled");
        }

        public static void ViewPlan()
        {            
            By byViewPlan = By.XPath("//a[@id='getPlanDetailsBtn']");            
            CommonFunctions.ClickByJE(CommonFunctions.getElement(byViewPlan));
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Click View Plan button", "The button is enabled");
        }

        public static bool IsPlanDeleted()
        {
            bool isDeleted;
            By byNoPlan = By.XPath("//*/div[@id='noPlansInfoDiv' and @style='display: block;']");
            CommonFunctions.WaitUntilPageIsAcive();
            isDeleted = CommonFunctions.IsElementDisplayed(byNoPlan, 10);
            CommonFunctions.AddTestStep("Veify a plan is deleted", $"The plan is deleted == {isDeleted}");
            return (isDeleted);
            
        }

        public static List<string> GetAllDepts()
        {
            By byDept = By.XPath("//select[@id='deptList']/option");
            var FpcDepts = CommonFunctions.GetDropdownOptionByValue(byDept);
            return FpcDepts;
        }       

        public static void ClickNext()
        {
            By byNextDept = By.XPath("//a[@id='btnNextDept']");
            CommonFunctions.getElement(byNextDept).Click();
        }
        public static void ClickPrevious()
        {
            By byPrevDept = By.XPath("//a[@id='btnPrevDept']");
            CommonFunctions.getElement(byPrevDept).Click();
        }

        public static string getCurrentDeptValue()
        {
            By byCurrentDept = By.XPath("//input[@id='deptNumberUserEntry']");
            return CommonFunctions.getElementValue(byCurrentDept);

        }


        public static FpcPlanFilterCommand PlanFilter()
        {
            return new FpcPlanFilterCommand();
        }
        #endregion

    }
    #region: Action
    #region: FpcPlanFilterCommand
    public class FpcPlanFilterCommand
    {
        private string department;
        private string planStatus;
        private string plan;

        public FpcPlanFilterCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public FpcPlanFilterCommand withPlanStatus(string PlanStatus)
        {
            this.planStatus = PlanStatus;
            return this;
        }

        public FpcPlanFilterCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }

        private void setDepartment()
        {
            CommonFunctions.AddTestStep($"Select dept {department}", $"{department} was selected");
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        private void setPlanStatus()
        {
            if (!string.IsNullOrEmpty(planStatus))
            {
                CommonFunctions.AddTestStep($"Select plan status {planStatus}", $"{planStatus} was selected");
                IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//select[@id='planStatusList']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, planStatus);
            }
        }

        private bool setPlan()
        {
            try
            {
                if (!string.IsNullOrEmpty(plan))
                {
                    IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//select[@id='planList']"));
                    CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
                    return true;
                }
            }
            catch
            {
                return false; 
            }
            return false;
            
        }

        public void clickViewPlan()
        {
            bool bDisplayed;
            By byPlanID = By.XPath("//input[@value='Plan ID:']");
            Timer.Start();
            IWebElement cmdViewPlan = CommonFunctions.getElement(By.XPath("//a[@id='getPlanDetailsBtn' and not(@disabled)]"));
            CommonFunctions.ClickByJE(cmdViewPlan);
            CancelNavigateAwayPopup();
            bDisplayed = CommonFunctions.IsElementDisplayed(byPlanID, 10);
            if(bDisplayed)
            {
                Timer.Stop();
                CommonFunctions.WriteToFile($"Navigate to view plan page: {Timer.GetElapsedTime()}");
            }
        }

        private void CancelNavigateAwayPopup()
        {
            bool bDisplayed;
            By byNavigateAway = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-dirtypage-nav-with-save-confirm']//button/span[text()='Yes']");            
            bDisplayed = CommonFunctions.IsElementDisplayed(byNavigateAway, 1);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(byNavigateAway);
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }
        }

        public void clickViewPlanDetail()
        {
            Timer.Start();
            IWebElement cmdViewPlanDetail = CommonFunctions.getElement(By.XPath("//a[@id='getViewPlanDetailsBtn']"));
            CommonFunctions.ClickByJE(cmdViewPlanDetail);
            ConfirmNewPlan();
            var bDisplayed = FpcPlanFilter.IsAt;
            if (bDisplayed)
            {
                Timer.Stop();
                //CommonFunctions.WriteToFile($"View plan detail: {Timer.GetElapsedTime()}");
            }
        }

        private void clickEditPlan()
        {
            IWebElement cmdEditPlan = CommonFunctions.getElement(By.XPath("//a[@id='getPlanDetailsBtn']"));
            CommonFunctions.ClickByJE(cmdEditPlan);
        }

        private void clickDeletePlan()
        {
            Thread.Sleep(2000);
            string xpath = "//a[@id='deletePlanDetailsBtn' and not (@disabled)]";
            bool bExists = CommonFunctions.IsElementDisplayed(xpath, 2);
            if (bExists)
            {
                IWebElement cmdDeletePlan = CommonFunctions.getElement(By.XPath(xpath));
                CommonFunctions.ClickByJE(cmdDeletePlan);
                CommonFunctions.AddTestStep("Click Deleted button", "The button is enabled");
            }
        }

        private void ConfirmPlanDeletion()
        {
            bool bDisplayed;
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-deletePlanConfirm']//button/span[text()='Yes']";
            bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.AddTestStep("Click Yes button to confirm the plan deletion.", "The button is enabled");
            }
        }

        private void ConfirmNewPlan()
        {
            bool bDisplayed;
            By byNavigateAway = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-dirtypage-nav-with-save-confirm']//button/span[text()='Yes']");                
            By byProceedWithSaving = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-targetProductiveFtes-atAverage-greaterthan-atPeak-confirm']//button/span[text()='Yes']");
            By byActualVolumes = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-default-actual-alert' and contains(@style,'display: block')]//button/span[text()='Ok']");
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-default-actual-alert']//button/span[text()='Ok']";
            bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }

            bDisplayed = CommonFunctions.IsElementDisplayed(byNavigateAway, 2);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(byNavigateAway);
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }

            bDisplayed = CommonFunctions.IsElementDisplayed(byProceedWithSaving, 2);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(byProceedWithSaving);
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
            }

            bDisplayed = CommonFunctions.IsElementDisplayed(byActualVolumes, 2);
            if (bDisplayed)
            {
                IWebElement cmdOk = CommonFunctions.getElement(byActualVolumes);
                CommonFunctions.ClickByJE(cmdOk);
                CommonFunctions.WaitUntilPageIsAcive();
            }
        }

        private void SaveNewPlan()
        {
            By byTgtMinFtes = By.XPath("//input[@id='tgtMinFtes']");
            bool bDisplayed;
            bDisplayed = CommonFunctions.IsElementDisplayed(byTgtMinFtes, 2);
            if (bDisplayed)
            {
                CommonFunctions.ClickByJE(CommonFunctions.getElement(byTgtMinFtes));
                Thread.Sleep(1000);
                FpcPlanMenu.Save();
                CommonFunctions.AddTestStep("Click the save button to the new plan or changes", "The save button is enabled");
            }
        }

        public void ViewPlan()
        {
            setDepartment();
            setPlanStatus();
            setPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            clickViewPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            Thread.Sleep(1000);
            CommonFunctions.AddTestStep("View current plan", "Current plan is loaded");
        }

        public void ViewPlanDetail()
        {
           // FpcPlanMenu.Save();
            setDepartment();
            setPlanStatus();
            setPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            clickViewPlanDetail();
            Thread.Sleep(2000);
            clickViewPlanDetail();
            CommonFunctions.AddTestStep("Verify view plan detail page", "The view plan detail page is displayed.");
        }

        private void isPlanActive()
        {
            By byTargetEnabled = By.XPath("//select[@class='setTargetMonthId' and not(@disabled)]");
            CommonFunctions.IsElementDisplayed(byTargetEnabled, 25);
        }

        public void EditPlan()
        {
            setDepartment();
            setPlanStatus();
            setPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            Timer.Start();
            clickEditPlan();
            By bySgValue = By.XPath("//*/input[@id='deptSubFunc']");
            CommonFunctions.WaitForElementValueToBeNonEmpty(bySgValue);
            CommonFunctions.WaitUntilPageIsAcive();
            VerifyNoadministrativeDeptOptionsDefinedModel();
            ConfirmNewPlan();
            CommonFunctions.WaitUntilPageIsAcive();
            //Thread.Sleep(5000);
            //SaveNewPlan();
           // Thread.Sleep(5000);
            isPlanActive();
            Timer.Stop();
            //CommonFunctions.WriteToFile($"Edit plan = {Timer.GetElapsedTime()}");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Create a new FPC plan", "A new FPC plan was created.");
        }

        public void DeletePlan()
        {
            setDepartment();
            setPlanStatus();
            CommonFunctions.WaitUntilPageIsAcive();
            setPlan();
            clickDeletePlan();
            ConfirmPlanDeletion();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Delete an FPC plan", "An FPC plan was deleted.");
        }

        public bool IsPlanTypeExist()
        {
            
            bool bExist;
            By ByPlanList = By.XPath("//select[@id='planList' and @disabled]");
            setDepartment();
            setPlanStatus();
            CommonFunctions.WaitUntilPageIsAcive();
            bExist = CommonFunctions.IsElementDisplayed(ByPlanList, 5);
            CommonFunctions.AddTestStep("Verify if a plan type exists for a department", $"The plan type exists == {bExist}");
            return bExist? false : true;
        }

        private bool VerifyNoadministrativeDeptOptionsDefinedModel()
        {
            By byNoadministrativeDefined = By.XPath("//*/div[@aria-labelledby='ui-dialog-title-no-dept-admin-options-navigate-adminstration' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']");
            bool bDisaplyed;
            bDisaplyed = CommonFunctions.IsElementDisplayed(byNoadministrativeDefined,2);
            if (bDisaplyed)
            {
                CommonFunctions.AddTestStep("Verify creating a new FPC plan for a dept that does not have any existing plan at all",
                    "The FPC admin page is displayed.");
                CommonFunctions.ClickByJE(CommonFunctions.getElement(byNoadministrativeDefined));
                bDisaplyed = FpcAdministration.IsAt;
                bDisaplyed = FpcAdministration.IsAt ? true : false; 
                if(bDisaplyed)
                    return true;
            }
            return false;
        }
    }
    #endregion
    #endregion
}

