﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.FpcPlan.FTEsSummary;

namespace ISAS_Regression_Automation
{
    public class SummaryAndApproval
    {
        #region: Action
        public static void GoTo()
        {
            FPCMainMenu.FPC.SelectSummaryAndApproval();
            CommonFunctions.WaitUntilPageIsAcive();
        }

        public static bool IsAt
        {
            get
            {
                string xpath = "//select[@id='deptList']";
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }

        public static clSummaryAndApprovalFTEsSummary GetSummaryAndApprovalFTEsSummary()
        {
            return new clSummaryAndApprovalFTEsSummary()
            {
                TotalTargetProductiveFTEsCore = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[1]/td[2]")).GetAttribute("value"),
                TotalTargetProductiveFTEsAverage = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[1]/td[3]")).GetAttribute("value"),
                TotalTargetProductiveFTEsPeak = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[1]/td[4]")).GetAttribute("value"),
                TotalDepartmentPaidFTEsCore = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[2]/td[2]")).GetAttribute("value"),
                TotalDepartmentPaidFTEsAverage = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[2]/td[3]")).GetAttribute("value"),
                TotalDepartmentPaidFTEsPeak = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[2]/td[4]")).GetAttribute("value"),
                VarianceCore = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[3]/td[2]")).GetAttribute("value"),
                VarianceAverage = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[3]/td[3]")).GetAttribute("value"),
                VariancePeak = CommonFunctions.getElement(By.XPath("//*/div[@id='planFtesSummary']//table/tbody/tr[3]/td[4]")).GetAttribute("value"),
                AllowableFTEVariance = CommonFunctions.getElement(By.XPath("//input[@id='variance']")).GetAttribute("value"),
                HiredInFTE = CommonFunctions.getElement(By.XPath("//input[@id='hiredInFtesSubtotalColumn']")).GetAttribute("value")

            };
        }

        public static clSummaryAndApprovalApproval GetSummaryAndApprovalComments()
        {
            return new clSummaryAndApprovalApproval()
            {
                IDs = CommonFunctions.getElements(By.XPath("//*/div[@id='planSummaryApprovalDetails']//tr[contains(@class,'fpc-comment')]/td[@rowspan]")),
                CommentsAndApprovers = CommonFunctions.getElements(By.XPath("//*/div[@id='planSummaryApprovalDetails']//tr[contains(@class,'fpc-comment')]/td[2]")),
                Dates = CommonFunctions.getElements(By.XPath("//*/div[@id='planSummaryApprovalDetails']//tr[contains(@class,'fpc-comment')]/td[3]"))
            };
        }
        #endregion
    }
}
