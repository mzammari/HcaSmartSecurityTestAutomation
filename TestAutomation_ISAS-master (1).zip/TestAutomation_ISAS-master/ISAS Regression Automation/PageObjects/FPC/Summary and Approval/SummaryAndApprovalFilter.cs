﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class SummaryAndApprovalFilter
    {
        public static SummaryAndApprovalFilterCommand Filter()
        {
            return new SummaryAndApprovalFilterCommand();
        }
    }
    #region: Action
    #region: SummaryAndApprovalFilterCommand
    public class SummaryAndApprovalFilterCommand
    {
        private string planStatus;
        private string department;
        private string plan;

        public SummaryAndApprovalFilterCommand withPlanStatus(string PlanStatus)
        {
            this.planStatus = PlanStatus;
            return this;
        }

        public SummaryAndApprovalFilterCommand withDepartment(string Department)
        {
            this.department = Department;
            return this;
        }

        public SummaryAndApprovalFilterCommand withPlan(string Plan)
        {
            this.plan = Plan;
            return this;
        }

        private void setPlanStatus()
        {
            IWebElement mnuPlanStatus = CommonFunctions.getElement(By.XPath("//select[@id='planStatusList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, "Working");
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.SelectItemFromDropdownMenu(mnuPlanStatus, planStatus);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private void setDepartment()
        {
            IWebElement mnuDepartment = CommonFunctions.getElement(By.XPath("//select[@id='deptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDepartment, department);
        }

        private void setPlan()
        {
            if (!string.IsNullOrEmpty(plan))
            {
                IWebElement mnuPlan = CommonFunctions.getElement(By.XPath("//select[@id='planList']"));
                CommonFunctions.SelectItemFromDropdownMenu(mnuPlan, plan);
            }
        }

        private void clickViewPlan()
        {
            IWebElement cmdViewPlan = CommonFunctions.getElement(By.XPath("//*/a[@id='getPlanDetailsBtn']"));
            CommonFunctions.ClickByJE(cmdViewPlan);
            CommonFunctions.WaitUntilPageIsAcive();
        }

        private void clickDeletePlan()
        {
            bool bDisplayed;
            string confirmedXpath = "//*/div[@aria-labelledby='ui-dialog-title-deletePlanConfirm' and contains(@style,'display: block;')]//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            IWebElement cmdDeletePlan = CommonFunctions.getElement(By.XPath("//*/a[@id='deletePlanDetailsBtn']"));
            CommonFunctions.ClickByJE(cmdDeletePlan);
            bDisplayed = CommonFunctions.IsElementDisplayed(confirmedXpath, 2);
            if (bDisplayed)
            {
                IWebElement cmdYes = CommonFunctions.getElement(By.XPath(confirmedXpath));
                CommonFunctions.ClickByJE(cmdYes);
                CommonFunctions.WaitUntilPageIsAcive();
                CommonFunctions.WaitSaveToastMsgDisappeared();
            }
        }

        public void ViewPlan()
        {
            setPlanStatus();
            setDepartment();
            setPlan();
            clickViewPlan();
        }

        public void DeletePlan()
        {
            setPlanStatus();
            setDepartment();
            setPlan();
            clickDeletePlan();
        }
    }

    #endregion
    #endregion
}
