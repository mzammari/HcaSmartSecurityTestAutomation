﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ISAS_Regression_Automation.WFTMainMenu.WFTReports;
using static System.Net.WebRequestMethods;

namespace ISAS_Regression_Automation
{
    public class clSummaryAndApprovalFTEsSummary
    {
        public string TotalTargetProductiveFTEsCore { get; set; }
        public string TotalTargetProductiveFTEsAverage { get; set; }
        public string TotalTargetProductiveFTEsPeak { get; set; }
        public string TotalDepartmentPaidFTEsCore { get; set; }
        public string TotalDepartmentPaidFTEsAverage { get; set; }
        public string TotalDepartmentPaidFTEsPeak { get; set; }
        public string VarianceCore { get; set; }
        public string VarianceAverage { get; set; }
        public string VariancePeak { get; set; }
        public string AllowableFTEVariance { get; set; }
        public string HiredInFTE { get; set; }
    }

    public class clSummaryAndApprovalApproval
    {
        public IList<IWebElement> IDs;
        public IList<IWebElement> CommentsAndApprovers;
        public IList<IWebElement> Dates;

    }
}
