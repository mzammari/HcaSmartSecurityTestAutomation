﻿using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutomationCoreLite.Reporting;

namespace ISAS_Regression_Automation
{
    public class FPCMainMenu
    {
        #region: Action
        public class Home
        {
            public static void SelectHome()
            {
                MenuSelectorByLink.SelectTop("Home");
                By byFPCHome = By.XPath("//*/td[contains(text(),'Welcome to PLUS')]");
                WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.ElementIsVisible(byFPCHome));
                CommonFunctions.AddTestStep("Select ISAS home page", "the home page is loaded");
            }
        }

        public class FPC
        {
            public static void SelectAdministration()
            {
                By TopMenuLevel = By.XPath("//*/a[contains(text(),'FPC')]");
                By link = By.XPath("//*/a[@href='/FpcAdministration/FpcAdministration']");
                MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
                CommonFunctions.AddTestStep("Select FPC Admin menu option", "The option is clicked");
            }

            public static void SelectPlan()
            {
                By TopMenuLevel = By.XPath("//*/a[contains(text(),'FPC')]");
                By link = By.XPath("//*/a[@href='/FpcPlan']");
                MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
                CommonFunctions.AddTestStep("Select FPC Plan menu option", "The option is clicked");
            }

            public static void SelectPlanB()
            {
                By TopMenuLevel = By.XPath("//*/a[contains(text(),'FPC')]");
                By link = By.XPath("//*/a[@href='/FpcPlan']");
                MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
                CommonFunctions.AddTestStep("Select FPC Plan menu option", "The option is clicked");
            }

            public static void SelectSummaryAndApproval()
            {
                By TopMenuLevel = By.XPath("//*/a[contains(text(),'FPC')]");
                By link = By.XPath("//*/a[@href='/FpcSummaryAndApproval']");
                MenuLinkSelectorTwolevels.SelectBy(TopMenuLevel, link);
                CommonFunctions.AddTestStep("Select FPC Summary And Approval menu option", "The option is clicked");
            }
        }

        public class Reports
        {
            public class DailyReports
            {
                public static void SelectDailyTrendReport()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                    By link = By.XPath("//*/a[@href='/Report/DailyTrendReport']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Daily Trend Report", "The report page is open");
                }

                public static void SelectDailyStaffingSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                    By link = By.XPath("//*/a[@href='/Report/DailyStaffingSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Daily Staffing Summary Report", "The report page is open");
                }

                public static void SelectDailyStaffingSummaryIgnoreDept()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                    By link = By.XPath("//*/a[@href='/Report/DailyStaffingSummaryIgnoreDept']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Daily Staffing Summary Ignore Dept report", "The report page is open");
                }

                public static void SelectDailyStaffingPaidHoursSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                    By link = By.XPath("//*/a[@href='/Report/DailyStaffingPaidHoursSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Daily Staffing Paid Hours Summary report", "The report page is open");
                }

                public static void SelectDailyLaborDollarsSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                    By link = By.XPath("//*/a[@href='/Report/DailyLaborDollarsSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Daily Labor Dollars Summary report", "The report page is open");
                }

                public static void SelectDailyLaborPaidDollarsSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                    By link = By.XPath("//*/a[@href='/Report/DailyLaborPaidDollarsSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Daily Labor Dollars Summary report", "The report page is open");
                }

                public static void SelectDailyUosErVisitsHolds()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily Reports']");
                    By link = By.XPath("//*/a[@href='/Report/DailyUosErVisitsHolds']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Daily Uos Er Visits Holds report", "The report page is open");
                }
            }

            public class BiWeeklyReports
            {
                public static void SelectBiWeeklyDeptLaborUtilizTrend()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                    By link = By.XPath("//*/a[@href='/Report/BiWeeklyDeptLaborUtilizTrend']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Bi Weekly Dept Labor Utiliz Trend report", "The report page is open");
                }

                public static void SelectBiWeeklyStaffingSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                    By link = By.XPath("//*/a[@href='/Report/BiWeeklyStaffingSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC BiWeekly Staffing Summary report", "The report page is open");
                }

                public static void SelectBiWeeklyFacilityLaborUtilizTrend()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                    By link = By.XPath("//*/a[@href='/Report/BiWeeklyFacilityLaborUtilizTrend']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC BiWeekly Facility Labor Utiliz Trend report", "The report page is open");
                }

                public static void SelectBiWeeklyDivisionLaborUtilizTrend()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                    By link = By.XPath("//*/a[@href='/Report/BiWeeklyDivisionLaborUtilizTrend']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC BiWeekly Division Labor Utiliz Trend report", "The report page is open");
                }

                public static void SelectBiWeeklyDivisionStaffingSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                    By link = By.XPath("//*/a[@href='/Report/BiWeeklyDivisionStaffingSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC BiWeekly Division Staffing Summary report", "The report page is open");
                }

                public static void SelectBiWeeklyGroupStaffingSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                    By link = By.XPath("//*/a[@href='/Report/BiWeeklyGroupStaffingSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC BiWeekly Group Staffing Summary report", "The report page is open");
                }

                public static void SelectBiWeeklyLaborManagement()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Bi-Weekly Reports']");
                    By link = By.XPath("//*/a[@href='/Report/BiWeeklyLaborManagement']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC BiWeeklyLaborManagement report", "The report page is open");
                }
            }

            public class ContractLaborReports
            {
                public static void SelectContractLaborDetailBySkillMix()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                    By link = By.XPath("//*/a[@href='/Report/ContractLaborDetailBySkillMix']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Contract Labor Detail By Skill Mix report", "The report page is open");
                }

                public static void SelectContractLaborPotentialOpportunityByDivision()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                    By link = By.XPath("//*/a[@href='/Report/ContractLaborPotentialOpportunityByDivision']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Contract Labor Potential Opportunity By Division report", "The report page is open");
                }

                public static void SelectContractLaborRatesByDepartment()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                    By link = By.XPath("//*/a[@href='/Report/ContractLaborRatesByDepartment']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC ContractLaborRatesByDepartment report", "The report page is open");
                }

                public static void SelectContractLaborSummaryDivisionByMonth()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                    By link = By.XPath("//*/a[@href='/Report/ContractLaborSummaryDivisionByMonth']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Contract Labor Summary Division By Month report", "The report page is open");
                }

                public static void SelectContractLaborSummaryFacilityByMonth()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                    By link = By.XPath("//*/a[@href='/Report/ContractLaborSummaryFacilityByMonth']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Contract Labor Summary Division By Month report", "The report page is open");
                }

                public static void SelectContractLaborSummaryBySkillMix()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                    By link = By.XPath("//*/a[@href='/Report/ContractLaborSummaryBySkillMix']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC ContractLaborSummaryBySkillMix report", "The report page is open");
                }

                public static void SelectContractedAndEmployedLaborUsageByDepartment()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Contract Labor Reports']");
                    By link = By.XPath("//*/a[@href='/Report/ContractedAndEmployedLaborUsageByDepartment']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Contracted And Employed Labor Usage By Department report", "The report page is open");
                }
            }

            public class FPCReports
            {
                public static void SelectFpcDepartmentDetail()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FpcDepartmentDetail']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Fpc Department Detail report", "The report page is open");
                }

                public static void SelectFpcDepartmentDetailPayPeriod()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FpcDepartmentDetailPayPeriod']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Fpc Department Detail Pay Period report", "The report page is open");
                }

                public static void SelectFpcDivisionApprovedPlanSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FpcDivisionApprovedPlanSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Fpc Division Approved Plan Summary report", "The report page is open");
                }

                public static void SelectFpcDivisionNeedsAnalysis()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FpcDivisionNeedsAnalysis']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Fpc Division Needs Analysis report", "The report page is open");
                }

                public static void SelectFpcFacilityApprovedPlanSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FpcFacilityApprovedPlanSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC FpcFacilityApprovedPlanSummary report", "The report page is open");
                }

                public static void SelectFpcFacilityNeedsAnalysis()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FpcFacilityNeedsAnalysis']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Fpc Facility Needs Analysis report", "The report page is open");
                }

                public static void SelectFpcFacilityBusinessRulesAnalysis()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FpcFacilityBusinessRulesAnalysis']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Fpc Facility Business Rules Analysis report", "The report page is open");
                }

                public static void SelectFpcPlanStatusSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='FPC Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FpcPlanStatusSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Fpc Plan Status Summary report", "The report page is open");
                }
            }

            public class OtherReports
            {
                public static void SelectAnnualLaborProductivityTarget()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                    By link = By.XPath("//*/a[@href='/Report/AnnualLaborProductivityTarget']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC AnnualLaborProductivityTarget report", "The report page is open");
                }

                public static void SelectFunctionalDepartmentPaidManHours()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FunctionalDepartmentPaidManHours']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC FunctionalDepartmentPaidManHours report", "The report page is open");
                }

                public static void SelectFunctionalDepartmentProductiveManHours()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FunctionalDepartmentProductiveManHours']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Functional Department Productive Man Hours report", "The report page is open");
                }

                public static void SelectFunctionalDepartmentExecutiveSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FunctionalDepartmentExecutiveSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC FunctionalDepartmentExecutiveSummary report", "The report page is open");
                }

                public static void SelectMonthlySkillMixAnalysis()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                    By link = By.XPath("//*/a[@href='/Report/MonthlySkillMixAnalysis']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Monthly Skill Mix Analysis report", "The report page is open");
                }

                public static void SelectProcedureMultipliers()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                    By link = By.XPath("//*/a[@href='/Report/ProcedureMultipliers']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC ProcedureMultipliers report", "The report page is open");
                }

                public static void SelectFacilityUserReport()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                    By link = By.XPath("//*/a[@href='/Report/FacilityUserReport']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Facility User Report report", "The report page is open");
                }

                public static void SelectDepartmentUsage()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Other Reports']");
                    By link = By.XPath("//*/a[@href='/Report/DepartmentUsage']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Department Usage report", "The report page is open");
                }
            }

            public class SharedEmployeeReports
            {
                public static void SelectSharedEmployeeFacilitySummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Shared Employee Reports']");
                    By link = By.XPath("//*/a[@href='/Report/SharedEmployeeFacilitySummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Shared Employee Facility Summary report", "The report page is open");
                }

                public static void SelectSharedEmployeeFacilitySummaryByMonth()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Shared Employee Reports']");
                    By link = By.XPath("//*/a[@href='/Report/SharedEmployeeFacilitySummaryByMonth']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Shared Employee Facility Summary By Month report", "The report page is open");
                }

                public static void SelectSharedEmployeeDivisionSummary()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Shared Employee Reports']");
                    By link = By.XPath("//*/a[@href='/Report/SharedEmployeeDivisionSummary']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Shared Employee Division Summary report", "The report page is open");
                }

                public static void SelectSharedEmployeeDivisionSummaryByMonth()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'Reports')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Shared Employee Reports']");
                    By link = By.XPath("//*/a[@href='/Report/SharedEmployeeDivisionSummaryByMonth']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Shared Employee Division Summary By Month report", "The report page is open");
                }
            }
        }

        public class PLUS
        {
            public class Daily
            {
                public static void SelectContractHours()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily']");
                    By link = By.XPath("//*/a[@href='/ContractLabor/Hours']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                }

                public static void SelectSharedHours()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily']");
                    By link = By.XPath("//*/a[@href='/SharedLabor/Hours']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Shared Hours report", "The report page is open");
                }

                public static void SelectStatisticVolumes()
                {
                    By TopMenuLevel = By.XPath("//*/a[contains(text(),'PLUS')]");
                    By SecondMunuLevel = By.XPath("//*/a[text()='Daily']");
                    By link = By.XPath("//*/a[@href='/Stat/DailyStatisticVolumes']");
                    MenuLinkSelectorThreeLevels.SelectBy(TopMenuLevel, SecondMunuLevel, link);
                    CommonFunctions.AddTestStep("Select FPC Daily Statistic Volumes report", "The report page is open");
                }
            }
        }
        #endregion

    }
}
