﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FpcAdministration
    {
        #region: Action
        public static void GoTo()
        {
            FPCMainMenu.FPC.SelectAdministration();
            CommonFunctions.WaitUntilPageIsAcive();
            CommonFunctions.AddTestStep("Select FPC admin", "FPC admin page is loaded");
        }

        public static bool IsAt
        {
            get
            {
                // "//*/div[@aria-labelledby='ui-dialog-title-Load-confirm']//div[@class='ui-dialog-buttonset']//button/span[text()='OK']"
                string xpath = "//*/select[@id='IsFreezeFpcAdministration']";
                CommonFunctions.AddTestStep("Verify the FPC Admin page", "FPC page is loaded");
                return CommonFunctions.IsElementDisplayed(xpath, 20);
            }
        }
        #endregion
    }
}
