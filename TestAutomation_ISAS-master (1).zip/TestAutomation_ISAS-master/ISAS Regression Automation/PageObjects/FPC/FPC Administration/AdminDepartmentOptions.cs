﻿using AngleSharp.Attributes;
using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class AdminDepartmentOptions
    {
        public static AdminDepartmentFilterCommand DepartmentFilter()
        {
            return new AdminDepartmentFilterCommand();
        }

        public static AdminDepartmentOptionsCommand DepartmentOption(string Department) 
        { 
            return new AdminDepartmentOptionsCommand(Department);
        }
    }
    #region: Action
    #region AdminDepartmentFilterCommand
    public class AdminDepartmentFilterCommand
    {
        private string from;
        private string to;

        public AdminDepartmentFilterCommand withFrom(string From)
        {
            this.from = From;
            return this;
        }

        public AdminDepartmentFilterCommand withTo(string To)
        {
            this.to = To;
            return this;
        }

        private void setFrom()
        {
            CommonFunctions.AddTestStep($"Select dept {from}", $"The dept {from} was selected");
            IWebElement mnuFrom = CommonFunctions.getElement(By.XPath($"//*/select[@id='fromDeptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuFrom, from);
        }

        private void setTo()
        {
            CommonFunctions.AddTestStep($"Select dept {to}", $"The dept {to} was selected");
            IWebElement mnuTo = CommonFunctions.getElement(By.XPath($"//*/select[@id='toDeptList']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuTo, to);
        }

        private void clickView()
        {
            IWebElement cmdView = CommonFunctions.getElement(By.XPath($"//*/a[@id='viewbtn']"));
            CommonFunctions.ClickByJE(cmdView);
        }

        public void View()
        {
            setFrom();
            setTo();
            clickView();
            CommonFunctions.AddTestStep("View FPC plan", "The FPC is displayed");
        }
    }
    #endregion

    #region: AdminDepartmentOptionsCommand
    public class AdminDepartmentOptionsCommand
    {
        private string dept;
        private string variance;
        private bool setDepartmentLevelCoreAndPeakRules;
        private string coreRulesByDailyAverage;
        private string peakRulesByDailyAverage;
        private bool allowSelectableTargetMonth;
        private string defaultTargetMonth;
        private bool overrideHrsuos;
        private bool overrideProductiveMinimumHours;
        private bool overrideMonthlyTargetedSemiVariableProductiveFtes;
        private bool includeAllInactiveEmployeesInFtesCalculation;
        private bool useCurrentActualVolumesForCalculatingFtesInApprovedPlans;
        private string allowSavingIfCoreFtesAreOverAllowableFTEVariance;
        private bool volumeBudget;
        private bool volumeHistorical;
        private bool volumeOverride;
        private bool nonproductiveTarget;
        private bool nonproductiveHistorical;
        private bool nonproductiveOverride;
        private string calculateDailyAverageVolumesBasedOn;

        public AdminDepartmentOptionsCommand(string Department)
        {
            this.dept = Department;
        }      

        public AdminDepartmentOptionsCommand withVariance(string Variance)
        {
            this.variance = Variance;
            return this;
        }

        public AdminDepartmentOptionsCommand withSetDepartmentLevelCoreAndPeakRules(bool SetDepartmentLevelCoreAndPeakRules)
        {
            this.setDepartmentLevelCoreAndPeakRules = SetDepartmentLevelCoreAndPeakRules;
            return this;
        }

        public AdminDepartmentOptionsCommand withCoreRulesByDailyAverage(string CoreRulesByDailyAverage)
        {
            this.coreRulesByDailyAverage = CoreRulesByDailyAverage;
            return this;
        }

        public AdminDepartmentOptionsCommand withPeakRulesByDailyAverage(string PeakRulesByDailyAverage)
        {
            this.peakRulesByDailyAverage = PeakRulesByDailyAverage;
            return this;
        }

        public AdminDepartmentOptionsCommand withCalculateDailyAverageVolumesBasedOn(string CalculateDailyAverageVolumesBasedOn)
        {
            this.calculateDailyAverageVolumesBasedOn = CalculateDailyAverageVolumesBasedOn;
            return this;
        }

        public AdminDepartmentOptionsCommand withAllowSelectableTargetMonth(bool AllowSelectableTargetMonth)
        {
            this.allowSelectableTargetMonth = AllowSelectableTargetMonth;
            return this;
        }

        public AdminDepartmentOptionsCommand withDefaultTargetMonth(string DefaultTargetMonth)
        {
            this.defaultTargetMonth = DefaultTargetMonth;
            return this;
        }       

        public AdminDepartmentOptionsCommand withOverrideHrsuos(bool OverrideHrsuos)
        {
            this.overrideHrsuos = OverrideHrsuos;
            return this;
        }

        public AdminDepartmentOptionsCommand withOverrideProductiveMinimumHours(bool OverrideProductiveMinimumHours)
        {
            this.overrideProductiveMinimumHours = OverrideProductiveMinimumHours;
            return this;
        }

        public AdminDepartmentOptionsCommand withOverrideMonthlyTargetedSemiVariableProductiveFtes(bool OverrideMonthlyTargetedSemiVariableProductiveFtes)
        {
            this.overrideMonthlyTargetedSemiVariableProductiveFtes = OverrideMonthlyTargetedSemiVariableProductiveFtes;
            return this;
        }

        public AdminDepartmentOptionsCommand withIncludeAllInactiveEmployeesInFtesCalculation(bool IncludeAllInactiveEmployeesInFtesCalculation)
        {
            this.includeAllInactiveEmployeesInFtesCalculation = IncludeAllInactiveEmployeesInFtesCalculation;
            return this;
        }

        public AdminDepartmentOptionsCommand withUseCurrentActualVolumesForCalculatingFtesInApprovedPlans(bool UseCurrentActualVolumesForCalculatingFtesInApprovedPlans)
        {
            this.useCurrentActualVolumesForCalculatingFtesInApprovedPlans = UseCurrentActualVolumesForCalculatingFtesInApprovedPlans;
            return this;
        }

        public AdminDepartmentOptionsCommand withAllowSavingIfCoreFtesAreOverAllowableFTEVariance(string AllowSavingIfCoreFtesAreOverAllowableFTEVariance)
        {
            this.allowSavingIfCoreFtesAreOverAllowableFTEVariance = AllowSavingIfCoreFtesAreOverAllowableFTEVariance;
            return this;
        }

        public AdminDepartmentOptionsCommand withVolumeBudget(bool VolumeBudget)
        {
            this.volumeBudget = VolumeBudget;
            return this;
        }

        public AdminDepartmentOptionsCommand withVolumeHistorical(bool VolumeHistorical)
        {
            this.volumeHistorical = VolumeHistorical;
            return this;
        }

        public AdminDepartmentOptionsCommand withVolumeOverride(bool VolumeOverride)
        {
            this.volumeOverride = VolumeOverride;
            return this;
        }

        public AdminDepartmentOptionsCommand withNonproductiveTarget(bool NonproductiveTarget)
        {
            this.nonproductiveTarget = NonproductiveTarget;
            return this;
        }

        public AdminDepartmentOptionsCommand withNonproductiveHistorical(bool NonproductiveHistorical)
        {
            this.nonproductiveHistorical = NonproductiveHistorical;
            return this;
        }

        public AdminDepartmentOptionsCommand withNonproductiveOverride(bool NonproductiveOverride)
        {
            this.nonproductiveOverride = NonproductiveOverride;
            return this;
        }

        private void setVariance()
        {
            IWebElement txtVariance = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and contains(@class,'Variance')]"));
            CommonFunctions.SetText(txtVariance, variance);
        }

        private void setSetDepartmentLevelCoreAndPeakRules()
        {
            IWebElement chkSetDepartmentLevelCoreAndPeakRules = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='business-rules-dept-level']"));
            CommonFunctions.SetCheckbox(chkSetDepartmentLevelCoreAndPeakRules, setDepartmentLevelCoreAndPeakRules);
        }

        private void setCoreRulesByDailyAverage()
        {
            IWebElement mnuCoreRulesByDailyAverage = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//select[@deptnumber='{dept}' and contains(@id,'ddlCoreBusinessRules')]"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuCoreRulesByDailyAverage, coreRulesByDailyAverage);
        }

        private void setPeakRulesByDailyAverage()
        {
            IWebElement mnuPeakRulesByDailyAverage = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//select[@deptnumber='{dept}' and contains(@id,'ddlPeakBusinessRules')]"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuPeakRulesByDailyAverage, peakRulesByDailyAverage);
        }

        private void setCalculateDailyAverageVolumesBasedOn()
        {
            IWebElement mnuCalculateDailyAverageVolumesBasedOn = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//select[@deptnumber='{dept}' and contains(@id,'ddlBusinessOrCalendarDays')]"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuCalculateDailyAverageVolumesBasedOn, calculateDailyAverageVolumesBasedOn);
        }

        private void setAllowSelectableTargetMonth()
        {
            IWebElement chkAllowSelectableTargetMonth = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='TargetMonthSel']"));
            CommonFunctions.SetCheckbox(chkAllowSelectableTargetMonth, allowSelectableTargetMonth);
        }

        private void setDefaultTargetMonth()
        {
            IWebElement mnuDefaultTargetMonth = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//select[@deptnumber='{dept}' and @class='setTargetMonthId']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuDefaultTargetMonth, defaultTargetMonth);
        }

        private void setOverrideHrsuos()
        {
            IWebElement chkOverrideHrsuos = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='override-hrs-uos']"));
            CommonFunctions.SetCheckbox(chkOverrideHrsuos, overrideHrsuos);
        }

        private void setOverrideProductiveMinimumHours()
        {
            IWebElement chkOverrideProductiveMinimumHours = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='override-prod-min-hours']"));
            CommonFunctions.SetCheckbox(chkOverrideProductiveMinimumHours, overrideProductiveMinimumHours);
        }

        private void setOverrideMonthlyTargetedSemiVariableProductiveFtes()
        {
            IWebElement chkOverrideMonthlyTargetedSemiVariableProductiveFtes = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='override-monthly-target-ftes']"));
            CommonFunctions.SetCheckbox(chkOverrideMonthlyTargetedSemiVariableProductiveFtes, overrideMonthlyTargetedSemiVariableProductiveFtes);
        }

        private void setIncludeAllInactiveEmployeesInFtesCalculation()
        {
            By byIncludeAllInactiveEmp = By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='include-inactive-in-ftes-calc']");
            bool bExist = CommonFunctions.IsElementDisplayed(byIncludeAllInactiveEmp, 2);
            if (bExist)
            {                
                CommonFunctions.SetCheckbox(CommonFunctions.getElement(byIncludeAllInactiveEmp),
                    includeAllInactiveEmployeesInFtesCalculation);
            }
        }

        private void setUseCurrentActualVolumesForCalculatingFtesInApprovedPlans()
        {
        
            IWebElement chkUseCurrentActualVolumesForCalculatingFtesInApprovedPlans = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='use-act-vol-to-calc-ftes']"));
            CommonFunctions.SetCheckbox(chkUseCurrentActualVolumesForCalculatingFtesInApprovedPlans, useCurrentActualVolumesForCalculatingFtesInApprovedPlans);
        }

        private void setAllowSavingIfCoreFtesAreOverAllowableFTEVariance()
        {
            IWebElement mnuAllowSavingIfCoreFtesAreOverAllowableFTEVariance = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//select[@deptnumber='{dept}' and contains(@id,'ddlAllowNegativeVar')]"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuAllowSavingIfCoreFtesAreOverAllowableFTEVariance, allowSavingIfCoreFtesAreOverAllowableFTEVariance);
        }

        private void setVolumeBudget()
        {
            IWebElement chkVolumeBudget = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='volume-budget']"));
            CommonFunctions.SetCheckbox(chkVolumeBudget, volumeBudget);
        }

        private void setVolumeHistorical()
        {
            IWebElement chkVolumeHistorical = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='volume-historical']"));
            CommonFunctions.SetCheckbox(chkVolumeHistorical, volumeHistorical);
        }

        private void setVolumeOverride()
        {
            IWebElement chkVolumeOverride = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='volume-override']"));
            CommonFunctions.SetCheckbox(chkVolumeOverride, volumeOverride);
        }

        private void setNonproductiveTarget()
        {
            IWebElement chkNonproductiveTarget = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='non-prod-target']"));
            CommonFunctions.SetCheckbox(chkNonproductiveTarget, nonproductiveTarget);
        }

        private void setNonproductiveHistorical()
        {
            IWebElement chkNonproductiveHistorical = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='non-prod-historical']"));
            CommonFunctions.SetCheckbox(chkNonproductiveHistorical, nonproductiveHistorical);
        }

        private void setNonproductiveOverride()
        {
            IWebElement chkNonproductiveOverride = CommonFunctions.getElement(By.XPath($"//*/div[@deptnumber='{dept}']//input[@deptnumber='{dept}' and @id='non-prod-override']"));
            CommonFunctions.SetCheckbox(chkNonproductiveOverride, nonproductiveOverride);
        }

        public void Save()
        {
            setVariance();
            setSetDepartmentLevelCoreAndPeakRules();
            setCoreRulesByDailyAverage();
            setPeakRulesByDailyAverage();
            setCalculateDailyAverageVolumesBasedOn();
            setAllowSelectableTargetMonth();
            setDefaultTargetMonth();
            setOverrideHrsuos();
            setOverrideProductiveMinimumHours();
            setOverrideMonthlyTargetedSemiVariableProductiveFtes();
            setIncludeAllInactiveEmployeesInFtesCalculation();
            setUseCurrentActualVolumesForCalculatingFtesInApprovedPlans();
            setAllowSavingIfCoreFtesAreOverAllowableFTEVariance();
            setVolumeBudget();
            setVolumeHistorical();
            setVolumeOverride();
            setNonproductiveTarget();
            setNonproductiveHistorical();
            setNonproductiveOverride();
            FpcAdministrationMenu.Save();
            CommonFunctions.AddTestStep("Add different options to the Admin page", "Options are saved");
        }
    }
    #endregion
    #endregion
}
