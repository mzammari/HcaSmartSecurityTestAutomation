﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class AdminFacilityOptions
    {
        public static AdminFacilityOptionsCommand FacilityOptions()
        {
            return new AdminFacilityOptionsCommand();
        }
    }

    #region:Action
    #region: AdminFacilityOptionsCommand
    public class AdminFacilityOptionsCommand
    {
        private string freezeFPCAdministration;

        public AdminFacilityOptionsCommand withFreezeFPCAdministration(string FreezeFPCAdministration)
        {
            this.freezeFPCAdministration = FreezeFPCAdministration;
            return this;
        }

        private void setFreezeFPCAdministration()
        {
            IWebElement mnuFreezeFPCAdministration = CommonFunctions.getElement(By.XPath("//*/select[@id='IsFreezeFpcAdministration']"));
            CommonFunctions.SelectItemFromDropdownMenu(mnuFreezeFPCAdministration, freezeFPCAdministration);
        }

        private void clickSave()
        {
            IWebElement cmdSave = CommonFunctions.getElement(By.XPath("//*/select[@id='ddlIsFreezeEmployeeTypes1to4']"));
            CommonFunctions.ClickByJE(cmdSave);
        }

        public void Save()
        {
            setFreezeFPCAdministration();
            FpcAdministrationMenu.Save();
            CommonFunctions.AddTestStep("Set Freeze FPC Administration option", "Option is selected");
        }
    }
    #endregion
    #endregion


}
