﻿using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class FpcAdministrationMenu
    {
        #region: Action
        public static void Save()
        {
            bool bDisplayed, bEnabled;
            string ConfirmXpath = "//*/div[@aria-labelledby='ui-dialog-title-save-changes-alert']//div[@class='ui-dialog-buttonset']//button/span[text()='Yes']";
            string SaveXpath = "//*/a[@id='saveFpcAdministrationBtn' and not(@disabled)]";
            bEnabled = CommonFunctions.IsElementDisplayed(SaveXpath, 5);
            if (bEnabled)
            {
                IWebElement cmdSave = CommonFunctions.getElement(By.XPath(SaveXpath));
                CommonFunctions.ClickByJE(cmdSave);
                bDisplayed = CommonFunctions.IsElementDisplayed(ConfirmXpath, 2);
                if (bDisplayed)
                {
                    IWebElement cmdYes = CommonFunctions.getElement(By.XPath(ConfirmXpath));
                    CommonFunctions.ClickByJE(cmdYes);
                    CommonFunctions.WaitUntilPageIsAcive();
                }
            }
            CommonFunctions.AddTestStep("Click the save button", "The save button is enabled");
        }
        #endregion
    }
}
