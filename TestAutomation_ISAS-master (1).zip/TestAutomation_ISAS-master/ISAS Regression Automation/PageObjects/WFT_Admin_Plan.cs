﻿using AutomationCoreLite.Reporting;
using ISAS_Regression_Automation;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ISAS_Regression_Automation
{
    public class WFT_Admin_Plan : Driver
    {
        private IWebDriver driver;

        public WFT_Admin_Plan(IWebDriver driver)
        {
            this.driver = driver;
        }

        // ** NAVIGATION ELEMENTS ***
        By WFT_WorkloadForecast = By.XPath("//*[@id=\"mainmenu\"]/ul/li[2]/a");
        By WFT_Administration = By.XPath("//*[@id=\"mainmenu\"]/ul/li[2]/ul/li[1]/a");        
        By WFT_PlanButton = By.XPath("//*[@id=\"mainmenu\"]/ul/li[2]/ul/li[1]/ul/li[1]/a");

        // ** EXISTING PLAN ***
        By WFT_Year = By.XPath("//*[@id=\"existingPlanYearDropdown\"]");
        By WFT_Status = By.XPath("//*[@id=\"existingPlanStatus\"]");
        By WFT_Plan = By.XPath("//*[@id=\"existingPlanDescriptionDropdown\"]");
        By WFT_Select = By.XPath("//*[@id=\"selectExistingPlanBtn\"]");
        By WFT_Facility = By.XPath("//*[@id=\"ddlFacility\"]");

        // ** FACILITY GOALS ***
        By WFT_FacilityGoals = By.XPath("//*[@id=\"facilityGoalsTabLink\"]");
        By WFT_FacilityGoalsTable = By.XPath("/html/body/div[2]/form/div[2]/div[3]/div[3]/div[3]/div[1]/div");

        // ** AVERAGE LABOR RATE - EMPL ***
        //By WFT_DeptSelection = By.XPath("//*[@id=\"ddlwftDepartments\"]");
        //By WFT_FacilityGoalsTable = By.XPath("/html/body/div[2]/form/div[2]/div[3]/div[3]/div[3]/div[1]/div");

        public void NavigateToAdminPlanPage()
        {
            CommonFunctions.WaitUntilPageIsAcive();
            driver.FindElement(WFT_WorkloadForecast).Click();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(WFT_Administration));
            driver.FindElement(WFT_Administration).Click();            
            wait.Until(ExpectedConditions.ElementIsVisible(WFT_PlanButton));
            driver.FindElement(WFT_PlanButton).Click();            
            wait.Until(ExpectedConditions.ElementIsVisible(WFT_Select));
            CommonFunctions.AddTestStep("Navigate To Admin Plan Page", "Admin Plan Page");
        }
        public void SelectExistingPlan()
        {
            CommonFunctions.WaitUntilPageIsAcive();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(45));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Facility));
            driver.FindElement(WFT_Facility).SendKeys(getDataParser().extractData("WFT_Admin_Plan", "Facility"));            
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Select));
            driver.FindElement(WFT_Year).SendKeys(getDataParser().extractData("WFT_Admin_Plan", "Year"));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Select));
            driver.FindElement(WFT_Plan).SendKeys(getDataParser().extractData("WFT_Admin_Plan", "Plan"));
            wait.Until(ExpectedConditions.ElementToBeClickable(WFT_Select));
            Thread.Sleep(4000);
            driver.FindElement(WFT_Select).Click();
            wait.Until(ExpectedConditions.ElementIsVisible(WFT_FacilityGoals));
        }
        public void ValidateFacilityGoalsSection()
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(45));
            wait.Until(ExpectedConditions.ElementIsVisible(WFT_FacilityGoalsTable));   

            String[] FacilityGoalsRows = getDataParser().extractDataArray("WFT_Admin_Plan", "FacilityGoalsRows");
            String[] FacilityGoalsColumns = getDataParser().extractDataArray("WFT_Admin_Plan", "FacilityGoalsColumns");

            // Validate the labels of different rows
            IWebElement table = driver.FindElement(WFT_FacilityGoalsTable);
            for (int i = 2; i<22; i = i +1)
            {
                IList<IWebElement> rows = table.FindElements(By.XPath("./div[" + i + "]/label"));                
                foreach (IWebElement label in rows)
                {
                    Assert.AreEqual(label.Text,FacilityGoalsRows[i-2]);
                }
            }

            // Validate the labels of different columns
            for (int i = 1; i < 3; i = i + 1)
            {
                IList<IWebElement> columns = table.FindElements(By.XPath("./div[1]/label[" + i + "]"));
                foreach (IWebElement label in columns)
                {
                    Assert.AreEqual(label.Text, FacilityGoalsColumns[i - 1]);
                }
            }
        }
    }
}
